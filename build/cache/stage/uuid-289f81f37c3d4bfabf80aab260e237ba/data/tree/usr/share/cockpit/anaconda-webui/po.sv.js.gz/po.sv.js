cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 fel",
  "$0 flera fel"
 ],
 "$0 installation": [
  null,
  "$0 Installation"
 ],
 "$0 installer": [
  null,
  "$0 Installationsprogrammet"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 är en MBR utökad partition som innehåller logiska partitioner. Om du tar bort alla logiska partitioner tas också den utökade partitionen bort automatiskt."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 är obligatoriskt, men endast $1 är tillgänglig."
 ],
 "$0 warning": [
  null,
  "$0 varning",
  "$0 varningar"
 ],
 "$0 will be deleted": [
  null,
  "$0 kommer att raderas"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' filsystem kan inte vara på en krypterad block-enhet"
 ],
 "'$0' must be assigned to $1": [
  null,
  "\"$0\" måste vara tilldelad till \"$1\""
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "\"$0\" måste vara på en enhet som är formaterad till \"$1\""
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' måste vara på en EFI-systempartition. Den valda partitionen använder ett FAT-filsystem, men är inte markerad som ESP. Ställ in partitionstypen till EFI-system och aktivera esp-flaggan."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "'$0' partition på MDRAID enhet $1 hittades. Bootloader-partitioner på MDRAID-enheter stöds inte."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Ett standardanvändarkonto med administratörsåtkomst för att göra systemomfattande ändringar."
 ],
 "Abort installation": [
  null,
  "Avbryt Installation"
 ],
 "About": [
  null,
  "Om"
 ],
 "Account": [
  null,
  "Konto"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Add another server...": [
  null,
  "Lägg en annan server..."
 ],
 "Add mount": [
  null,
  "Lägg till montering"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Tillägg för din valda miljö"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Tillägg inte specifikt för din miljö"
 ],
 "Additional languages": [
  null,
  "Ytterligare språk"
 ],
 "Additional software for the selected environment": [
  null,
  "Ytterligare programvara för den valda miljön"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Alla ändringar som görs i lagringsredigeraren träder i kraft omedelbart."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Alla enheter som använder denna lösenfras kommer att låsas upp"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Webb UI"
 ],
 "Anaconda project page": [
  null,
  "Anaconda projekt sida"
 ],
 "Apply mount point assignment and install": [
  null,
  "Tillämpa monteringspunktstilldelningar och installera"
 ],
 "Applying changes...": [
  null,
  "Tillämpar ändringar.."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Tilldela partitioner till monteringspunkter. Användbart för förkonfigurerade anpassade layouter."
 ],
 "Automatic log file upload": [
  null,
  "Automatisk uppladdning av loggfiler"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Ställ in datum och tid automatiskt med hjälp av tidsservrar"
 ],
 "Automatically set timezone": [
  null,
  "Ställ in tidszon automatiskt"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Tillgängligt fritt utrymme: $0. Installationen behöver: $1."
 ],
 "Back": [
  null,
  "Tillbaka"
 ],
 "Base environment": [
  null,
  "Basmiljö"
 ],
 "Brief description of the issue": [
  null,
  "Kort beskrivning av problemet"
 ],
 "Bug report details": [
  null,
  "Felrapport detaljer"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API-nyckel"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Genom att fortsätta använda denna programvara förstår och accepterar du riskerna med förutsläppt programvara, att du avser att använda denna endast för test- och utvecklingssyften och är villig att rapportera eventuella buggar eller problem för att förbättra detta arbete."
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change destination": [
  null,
  "Ändra destination"
 ],
 "Change hostname": [
  null,
  "Ändra värdnamn"
 ],
 "Change partition layout": [
  null,
  "Ändra partitionslayout"
 ],
 "Change system keyboard layout": [
  null,
  "Ändra systemets tangentbordslayout"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Ändringar som görs här kommer omedelbart att påverka systemet. Det finns ingen \"ångra\"."
 ],
 "Checking installation configuration...": [
  null,
  "Kontrollerar installationskonfiguration …"
 ],
 "Checking storage configuration": [
  null,
  "Kontrollerar lagringskonfiguration"
 ],
 "Clear search": [
  null,
  "Rensa sökning"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Klicka på 'Nästa' igen för att fortsätta oavsett dessa varningar."
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Close storage editor": [
  null,
  "Stäng lagringsredigerare"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpitlagring gav inte lösenfrasen för att låsa upp krypterad enhet."
 ],
 "Completed": [
  null,
  "Färdig"
 ],
 "Configuration is incomplete": [
  null,
  "Konfiguration är ofullständig"
 ],
 "Configure NTP servers": [
  null,
  "Konfigurera NTP-servrar"
 ],
 "Configure custom NTP servers": [
  null,
  "Konfigurera anpassade NTP-servrar"
 ],
 "Configure network": [
  null,
  "Konfigurera nätverk"
 ],
 "Configure storage": [
  null,
  "Konfigurera lagring"
 ],
 "Configure storage again": [
  null,
  "Konfigurera lagring igen"
 ],
 "Confirm passphrase": [
  null,
  "Bekräfta lösenfras"
 ],
 "Continue": [
  null,
  "Fortsätt"
 ],
 "Continue installation": [
  null,
  "Fortsätt installation"
 ],
 "Continue installation?": [
  null,
  "Fortsätt installation?"
 ],
 "Continue with installation": [
  null,
  "Fortsätt med installation"
 ],
 "Correct these issues before continuing.": [
  null,
  "Åtgärda dessa problem innan du fortsätter."
 ],
 "Create Account": [
  null,
  "Skapa konto"
 ],
 "Create account": [
  null,
  "Skapa konto"
 ],
 "Currently installed: $0": [
  null,
  "Nuvarande installerat: $0"
 ],
 "Custom": [
  null,
  "Anpassad"
 ],
 "Date": [
  null,
  "Datum"
 ],
 "Date and time": [
  null,
  "Datum och tid"
 ],
 "Delete partition": [
  null,
  "Ta bort partition"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Att radera vissa partitioner kan hindra $0 från att starta: $1"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Destination": [
  null,
  "Destination"
 ],
 "Destination is encrypted": [
  null,
  "Destination är krypterad"
 ],
 "Detailed description of the issue": [
  null,
  "Detaljerad beskrivning av problemet"
 ],
 "Detected valid storage layout:": [
  null,
  "Upptäckt giltig lagringslayout:"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Duplicate device.": [
  null,
  "Duplicera enhet."
 ],
 "Duplicate mount point.": [
  null,
  "Duplicera monteringspunkt."
 ],
 "Enable root account": [
  null,
  "Aktivera root-konto"
 ],
 "Encrypt my data": [
  null,
  "Kryptera min data"
 ],
 "Encrypted": [
  null,
  "Krypterad"
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "Enter PIN": [
  null,
  "Ange PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Ange PIN-kod för att komma åt installationsprogrammet"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Ange din Bugzilla API-nyckel för att skapa en felrapport. Du kommer att kunna granska och redigera felinformationen i nästa steg."
 ],
 "Environment": [
  null,
  "Miljö"
 ],
 "Erase data and install": [
  null,
  "Radera data och installera"
 ],
 "Error details": [
  null,
  "Feldetaljer"
 ],
 "Exit to live desktop": [
  null,
  "Avsluta till live skrivbord"
 ],
 "Extended partition": [
  null,
  "Utökad partition"
 ],
 "Failed to report issue": [
  null,
  "Misslyckades att rapportera problem"
 ],
 "Failed to save layouts": [
  null,
  "Misslyckades med att spara layouterna"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux kräver minst $0 diskutrymme."
 ],
 "Finalization": [
  null,
  "Slutför"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Slutför: Systemkonfigurationen är klar. Den slutförande installationen kan ta en stund."
 ],
 "Find layout": [
  null,
  "Hitta layout"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "För bättre säkerhet, undvik att använda root-kontot direkt. Använd istället det lokala kontot ovan för att hantera systemet."
 ],
 "Full name": [
  null,
  "Fullständigt namn"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Det fullständiga namnet får inte innehålla kolontecken"
 ],
 "Helper text": [
  null,
  "Hjälptext"
 ],
 "Hide API key": [
  null,
  "Dölj API-nyckel"
 ],
 "Hide PIN": [
  null,
  "Dölj PIN"
 ],
 "Hide confirmed password": [
  null,
  "Dölj bekräftat lösenord"
 ],
 "Hide passphrase": [
  null,
  "Dölj lösenfras"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Hostname": [
  null,
  "Värdnamn"
 ],
 "How would you like to install?": [
  null,
  "Hur vill du installera?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Jag förstår att all befintlig data kommer att raderas",
  "Jag förstår att all befintlig data kommer att raderas från de valda diskarna"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Jag förstår att någon befintliga data kan komma att raderas"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Jag förstår att vissa partitioner kommer att modifieras"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Om det är tomt kommer värdnamnet att vara tillfälligt och ställas in av nätverksinformation."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Om inget av alternativen ovan gäller, använd lagringsredigeraren för att skapa en anpassad partitionering innan du fortsätter."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Om du konfigurerar partitioner krävs följande:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Om du inte samtycker till automatisk uppladdning av loggfiler kan du göra det $0 istället. Manuell rapportering låter dig granska och bifoga loggfiler själv."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Om du inte förstår eller accepterar riskerna, vänligen avsluta detta program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Om ditt problem matchar en av buggarna ovan kan du öppna den och lägga till din information där istället för att skapa en duplicerad rapport."
 ],
 "In progress": [
  null,
  "Pågående"
 ],
 "Initializing...": [
  null,
  "Initialiserar..."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Installation completed": [
  null,
  "Installationen är klar"
 ],
 "Installation failed": [
  null,
  "installationen misslyckades"
 ],
 "Installation method": [
  null,
  "Installationsmetod"
 ],
 "Installation of the system failed": [
  null,
  "installationen av systemet misslyckades"
 ],
 "Installation of the system failed: $0": [
  null,
  "installationen av systemet misslyckades: $0"
 ],
 "Installation type": [
  null,
  "Installationstyp"
 ],
 "Installing": [
  null,
  "Installerar"
 ],
 "Insufficient disk space": [
  null,
  "Inte tillräckligt med diskutrymme"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Ogiltig PIN-kod. Försök igen."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Ogiltig RAID konfiguration upptäckt. Om din RAID-array skapas direkt ovanpå diskar måste en partitionstabell skapas på arrayen. Om din RAID-array skapas ovanpå partitioner måste den innehålla ett enda filsystem eller format (t.ex. LVM PV). Alla befintliga partitioner på denna array kommer att ignoreras."
 ],
 "Invalid hostname": [
  null,
  "Ogiltigt värdnamn"
 ],
 "Jump to first incomplete step": [
  null,
  "Hoppa till första ofullständiga steg"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Behåll nuvarande disklayout och använd tillgängligt utrymme för att dubbeluppstarta med ett annat operativsystem."
 ],
 "Keyboard": [
  null,
  "Tangentbord"
 ],
 "Keyboard layout during boot": [
  null,
  "Tangentbordslayout under uppstart"
 ],
 "Language": [
  null,
  "Språk"
 ],
 "Launch storage editor": [
  null,
  "Starta lagringsredigerare"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Läs mer om begränsad åtkomst i konfigurationen"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Lämna båda lösenfrasfälten tomma om du vill använda ett tomt lösenord."
 ],
 "Location": [
  null,
  "Plats"
 ],
 "Locked devices": [
  null,
  "Upplåsta enheter"
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Make current": [
  null,
  "Gör nuvarande"
 ],
 "Manual disk configuration": [
  null,
  "Manuell diskkonfiguration"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manuell diskkonfiguration: Mappning av monteringspunkter"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Kan innehålla bokstäver, siffror och bindestreck."
 ],
 "May need more free space": [
  null,
  "Kan behöva mer ledigt utrymme"
 ],
 "Medium": [
  null,
  "Medium"
 ],
 "Minimum of $0 required": [
  null,
  "Minst $0 krävs"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Felaktig överensstämmelse mellan överordnad enhet och underordnad enhet vid omformateringsval."
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "Mount point assignment": [
  null,
  "Monteringspunkt tilldelning"
 ],
 "Move down": [
  null,
  "Flytta ned"
 ],
 "Move up": [
  null,
  "Flytta upp"
 ],
 "Must be at least $0 characters": [
  null,
  "Måste vara minst $0 tecken"
 ],
 "My issue is different, continue": [
  null,
  "Mitt problem är annorlunda, fortsätt"
 ],
 "NTP Servers": [
  null,
  "NTP-servrar"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Needs at least $0": [
  null,
  "Kräver åtminstone $0"
 ],
 "Network": [
  null,
  "Nätverk"
 ],
 "Network Configuration": [
  null,
  "Nätverkskonfiguration"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Nätverk ej tillgängligt. Konfigurera nätverket i menyn överst för att rapportera problemet."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Nätverk ej tillgängligt. Konfigurera nätverket för att rapportera problemet."
 ],
 "Network plugin failed": [
  null,
  "Nätverks insticksmodul misslyckades"
 ],
 "Next": [
  null,
  "Nästa"
 ],
 "No devices": [
  null,
  "Inga enheter"
 ],
 "No disks available": [
  null,
  "Inga diskar tillgängliga"
 ],
 "No disks selected": [
  null,
  "Inga diskar valda"
 ],
 "No keyboard layouts selected": [
  null,
  "Inga tangentbordslayouter valda"
 ],
 "No layouts selected yet": [
  null,
  "Inga layouter valda ännu"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Ingen giltig VConsole-tangentuppsättning kan erhållas för den valda tangentbordslayouten. Välj en annan tangentbordslayout."
 ],
 "Not enough available free space": [
  null,
  "Inte tillräckligt med ledigt utrymme"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Inte tillräckligt med ledigt utrymme på de valda diskarna."
 ],
 "Not enough space on selected disks.": [
  null,
  "Inte tillräckligt med utrymme på de valda diskarna."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Observera: Detta är förutgiven programvara som endast är avsedd för utvecklings- och testsyften. Använd INTE denna programvara för kritiskt arbete eller för produktionsmiljöer."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Öppna Bugzilla-felanmälningsformuläret"
 ],
 "Operating system": [
  null,
  "Operativsystem"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other keyboards": [
  null,
  "Andra tangentbord"
 ],
 "Partitions (advanced)": [
  null,
  "Partitioner (avancerat)"
 ],
 "Passphrase": [
  null,
  "Lösenfras"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Lösenfrasen matchade inte någon låst enhet"
 ],
 "Passphrases must match": [
  null,
  "Lösenfraserna måste matcha varandra"
 ],
 "Pending": [
  null,
  "Väntande"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Bifoga loggfilen $0 till problemrapporten."
 ],
 "Please enter a PIN": [
  null,
  "Ange en PIN-kod"
 ],
 "Please select at least one disk to continue": [
  null,
  "Välj minst en disk för att fortsätta"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Potentiella dubbletter av buggar hittades"
 ],
 "Powered by Anaconda": [
  null,
  "Drivs av Anaconda"
 ],
 "Pre-release": [
  null,
  "Förhandsutgåva"
 ],
 "Prefer to report manually? $0": [
  null,
  "Föredrar du att rapportera manuellt? $0"
 ],
 "Proceed with installation": [
  null,
  "Fortsätt med installationen"
 ],
 "Quit": [
  null,
  "Avsluta"
 ],
 "Quit installer?": [
  null,
  "Avsluta installationsprogrammet?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Misslyckades att läsa information om operativsystemet."
 ],
 "Reading information about the computer failed.": [
  null,
  "Läsa information om datorn misslyckades."
 ],
 "Reading installer configuration failed.": [
  null,
  "Läsa installationskonfigurationen misslyckades."
 ],
 "Reading installer version information failed.": [
  null,
  "Läsa installation version information misslyckades."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Riktigt värdnamn kan bara innehålla tecken, siffror, bindestreck (inte börja eller avslutas med ett tecken) och punkter"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Riktiga värdnamn måste bestå av 64 tecken eller mindre"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Starta om till Windows för att ändra storlek på BitLocker-krypterade partitioner. Se till att minst $0 ledigt utrymme tillgängligt för installation."
 ],
 "Reboot system?": [
  null,
  "Starta om systemet?"
 ],
 "Reclaim additional space": [
  null,
  "Återvinn ytterligare utrymme"
 ],
 "Reclaim space": [
  null,
  "Återvinn utrymme"
 ],
 "Reclaim space (required)": [
  null,
  "Återvinn utrymme (nödvändigt)"
 ],
 "Recommended": [
  null,
  "Rekommenderad"
 ],
 "Recommended partitions:": [
  null,
  "Rekommenderade partitioner:"
 ],
 "Reformat": [
  null,
  "Formatera om"
 ],
 "Reinstall Fedora": [
  null,
  "Installera om Fedora"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Ta bort alla partitioner på de valda enheterna, inklusive befintliga operativsystem."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Ta bort eller byt storlek på befintliga filsystem för att frigöra utrymme för installationen."
 ],
 "Remove server": [
  null,
  "Ta bort server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Om du tar bort ett filsystem raderas all data den innehåller permanent. Att ändra storlek på en partition kan frigöra oanvänt utrymme, men det är inte riskfritt. Se till att ha säkerhetskopior av allt viktigt innan du tar tillbaka utrymme."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Ersätt nuvarande installation, men behåll filerna i hemkatalogen."
 ],
 "Report Issue": [
  null,
  "Rapportera problem"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Rapportera ett problem eller ge feedback genom att öppna Bugzilla-felrapportsformuläret $0."
 ],
 "Report issue": [
  null,
  "Rapportera problem"
 ],
 "Reporting issue...": [
  null,
  "Rapporterar problem..."
 ],
 "Required": [
  null,
  "Krävs"
 ],
 "Requirements": [
  null,
  "Krav"
 ],
 "Rescan devices": [
  null,
  "Skanna enheter på nytt"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Omsökning av diskarna misslyckades."
 ],
 "Resize": [
  null,
  "Ändra storlek"
 ],
 "Resize partition": [
  null,
  "Ändra storlek på partition"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Ändrar storlek på följande partitioner från $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Begränsa åtkomsten till rapporten"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Begränsar rapporten till $0-gruppen. $1"
 ],
 "Return to installation": [
  null,
  "Återgå till installation"
 ],
 "Return to storage editor": [
  null,
  "Återgå till lagringsredigerare"
 ],
 "Review and install": [
  null,
  "Granska och installera"
 ],
 "Root account has been configured": [
  null,
  "Root-konto har konfigurerats"
 ],
 "Root account is enabled": [
  null,
  "Root-konto är aktiverat"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root-konto är aktiverat, men inget användarkonto har konfigurerats"
 ],
 "Root password has been set.": [
  null,
  "Root-lösenordet har satts."
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Skanna QR-koden med din telefon eller besök:"
 ],
 "Search for a language": [
  null,
  "Sök efter ett språk"
 ],
 "Search for additional software": [
  null,
  "Sök efter ytterligare programvara"
 ],
 "Search for an environment": [
  null,
  "Sök efter en miljö"
 ],
 "Search keyboard layout": [
  null,
  "Sök efter tangentbordslayout"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Säkra din data med hjälp av diskbaserad kryptering. Gäller endast nya partitioner"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "Select a device": [
  null,
  "Välj en enhet"
 ],
 "Select city": [
  null,
  "Välj stad"
 ],
 "Select destination": [
  null,
  "Välj destination"
 ],
 "Select region": [
  null,
  "Välj region"
 ],
 "Selected (top = current)": [
  null,
  "Vald (överst = nuvarande)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Den valda enhetens format '$0' kan inte formateras om."
 ],
 "Send us feedback on your installation": [
  null,
  "Skicka oss feedback om din installation"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server är inte nåbar"
 ],
 "Set custom hostname": [
  null,
  "Ställ in ett anpassat värdnamn"
 ],
 "Share disk with other operating systems": [
  null,
  "Dela disk med andra operativsystem"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Dela disk med annat operativsystem: $0"
 ],
 "Show AM/PM": [
  null,
  "Visa AM/PM"
 ],
 "Show API key": [
  null,
  "Visa API-nyckel"
 ],
 "Show PIN": [
  null,
  "Visa PIN"
 ],
 "Show confirmed password": [
  null,
  "Visa bekräftat lösenord"
 ],
 "Show passphrase": [
  null,
  "Visa lösenfras"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Software installation": [
  null,
  "Programvaruinstallation"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Programvaruinstallation: Lagringskonfigurationen är klar. Programvaran installeras nu på din enhet."
 ],
 "Software selection": [
  null,
  "Programval"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Vissa installationssteg måste fortfarande slutföras innan du kan fortsätta."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Vissa nödvändiga partitioner saknas: $0"
 ],
 "Space": [
  null,
  "Utrymme"
 ],
 "Stacktrace": [
  null,
  "Stackspår"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Storage configuration": [
  null,
  "Lagringskonfiguration"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Lagringskonfiguration: Lagring konfigureras för närvarande."
 ],
 "Storage editor": [
  null,
  "Lagringsredigerare"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Lagring baseras på konfigurationen från \"Modifera lagring\"."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Lagringslayout definieras av Kickstart fil. Den planerade partitioneringslayouten kan granskas i sammanfattningssteget."
 ],
 "Storage plugin failed": [
  null,
  "Lagringsinsticksmodul misslyckades"
 ],
 "Storage requirements not met": [
  null,
  "Lagringskraven uppfylls inte"
 ],
 "Strong": [
  null,
  "Starkt"
 ],
 "Successfully installed": [
  null,
  "Installationen lyckades"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 har låsts upp."
 ],
 "Suggested keyboards": [
  null,
  "Föreslagna tangentbord"
 ],
 "Suggested languages": [
  null,
  "Föreslagna språk"
 ],
 "System": [
  null,
  "System"
 ],
 "System configuration": [
  null,
  "Systemkonfiguration"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Systemkonfiguration: Programvaruinstallationen är klar. Systemet håller nu på att konfigureras."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Installationen med anaconda har oväntat stoppats."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Följande öppna buggar kan vara relaterade till ditt problem. Vänligen granska dem innan du skapar en ny rapport."
 ],
 "The following user will be created:": [
  null,
  "Följande användare kommer att skapas:",
  "Följande användare kommer att skapas:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Installationen behöver $0 diskutrymme; dock är kapaciteten för de valda diskarna endast $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Installationsprogrammet kan inte fortsätta på grund av ett kritiskt fel."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Installationsprogrammet kan inte fortsätta på grund av ett kritiskt fel: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Tangentbordslayouten har ändrats sedan lösenfrasen för diskkryptering angavs. Ange lösenfrasen på nytt."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Lösenfrasen du har gett innehåller icke-ASCII-tecken. Du kan kanske inte byta mellan tangentbordslayouter när du skriver den."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Den valda standardtangentbordslayouten stöder inte ASCII-tecken. Välj en ASCII-kompatibel layout som standard."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Lagringsredigeraren låter dig ändra storlek, ta bort och skapa partitioner. Det kan konfigurera LVM och mycket mer. Det är tänkt att användas som ett avancerat verktyg och inte avsett att användas i en typisk installation."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Dessa loggfiler kan innehålla känslig information som till exempel IP-adresser, användarnamn eller andra systemdetaljer."
 ],
 "This hostname can't be submitted": [
  null,
  "Detta värdnamn kan inte skickas in"
 ],
 "This is unstable, pre-release software": [
  null,
  "Detta är en instabil förhandsutgåva av programvaran"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Denna layout kommer att användas för att låsa upp ditt system vid uppstart"
 ],
 "This may take a moment": [
  null,
  "Detta kan ta en stund"
 ],
 "This will take a few moments": [
  null,
  "Detta kommer att ta en stund"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Timezone": [
  null,
  "Tidszon"
 ],
 "Title": [
  null,
  "Titel"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "För att börja använda $0, starta om ditt system."
 ],
 "To continue, select the devices to install to.": [
  null,
  "För att fortsätta, välj enheterna att installera på."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "För att använda det här alternativet, ändra storlek på eller ta bort befintliga partitioner för att frigöra minst $0."
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Det gick inte att schemalägga borttagning av $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Det gick inte att schemalägga storleksändring av $0"
 ],
 "Undo last action": [
  null,
  "Ångra senaste åtgärd"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Unlock encrypted devices": [
  null,
  "Lås upp krypterade enheter"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Lås upp krypterade partitioner för att behålla befintlig data och visa fler installationsmetoder."
 ],
 "Use configured storage": [
  null,
  "Använd konfigurerad lagring"
 ],
 "Use entire disk": [
  null,
  "Använd hela disken"
 ],
 "Use free space": [
  null,
  "Använd ledigt utrymme"
 ],
 "Use local account": [
  null,
  "Använd lokalt konto"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Använd RAID-enheten för automatisk partitionering"
 ],
 "User creation": [
  null,
  "Skapande av användare"
 ],
 "User name": [
  null,
  "Användarnamn"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Användarnamn får bara innehålla: bokstäver från a-z, siffror 0-9, bindestreck $0, punkt $1, understreck $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Användarnamn får inte ha ett reserverat ord"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Användarnamn måste vara kortare än 33 tecken"
 ],
 "Validating...": [
  null,
  "Validerar..."
 ],
 "Weak": [
  null,
  "Svagt"
 ],
 "Welcome": [
  null,
  "Välkommen"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Välkommen till Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Välkommen. Låt oss installera $0 nu."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "När du skickar in den här felrapporten kommer följande loggfiler att laddas upp automatiskt: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Det går inte att ändra storlek på Windows partitioner med BitLocker kryptering"
 ],
 "You can close this browser window now.": [
  null,
  "Du kan stänga detta webbläsarfönster nu."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Du kan antingen frigöra tillräckligt med utrymme här och låta installationsprogrammet sköta resten eller manuellt sätta upp partitioner."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Du kan generera API-nyckeln för ditt Bugzilla-konto $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Du måste aktivera root-kontot eller skapa ett lokalt användarkonto för att fortsätta."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Du måste vara ansluten till ett nätverk för att aktivera automatisk datum och tid."
 ],
 "Your progress will not be saved.": [
  null,
  "Ditt förlopp kommer inte att sparas."
 ],
 "completed step": [
  null,
  "färdigt steg"
 ],
 "current step": [
  null,
  "aktuellt steg"
 ],
 "delete": [
  null,
  "ta bort"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "encrypt": [
  null,
  "kryptera"
 ],
 "encrypted": [
  null,
  "krypterad"
 ],
 "extended partition": [
  null,
  "utökad partition"
 ],
 "format as $0": [
  null,
  "Formatera som $0"
 ],
 "here": [
  null,
  "här"
 ],
 "incomplete": [
  null,
  "ofullständig"
 ],
 "mount": [
  null,
  "montering"
 ],
 "pending step": [
  null,
  "väntande steg"
 ],
 "report the issue manually": [
  null,
  "rapportera problemet manuellt"
 ],
 "resized from $0": [
  null,
  "storleksändrad från $0"
 ],
 "shrink": [
  null,
  "krymp"
 ],
 "shrink to $0": [
  null,
  "krymp till $0"
 ],
 "transient, will use DHCP": [
  null,
  "obeständigt, kommer att använda DHCP"
 ],
 "undo": [
  null,
  "ångra"
 ]
});
