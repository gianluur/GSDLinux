cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Unlock": [
  null,
  "Odemknout"
 ],
 "Add key": [
  null,
  "Přidat klíč"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Select": [
  null,
  "Vybrat"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "Set": [
  null,
  "Nastavit"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "Permission denied": [
  null,
  "Přístup zamítnut"
 ],
 "Clear input value": [
  null,
  "Vymazat vstupní hodnotu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky pomocí NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticky pomocí dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky pomocí konkrétních NTP serverů"
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "Create $0": [
  null,
  "Vytvořit $0"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nejsou k dispozici žádné metody pro získání přístupu pro správu (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "$0 will be installed.": [
  null,
  "Bude nainstalováno $0."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásilo chybový kód $0"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Chyba při inicializaci"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Home": [
  null,
  "Domovská složka"
 ],
 "Downloads": [
  null,
  "Stahování"
 ],
 "Not a directory": [
  null,
  "Nejedná se o složku"
 ],
 "All files": [
  null,
  "Všechny soubory"
 ],
 "Recent": [
  null,
  "Nedávné"
 ],
 "No recent directories": [
  null,
  "Žádné nedávné složky"
 ],
 "No recent files": [
  null,
  "Žádné nedávné soubory"
 ],
 "Type to filter": [
  null,
  "Filtrujte psaním"
 ],
 "File chooser actions": [
  null,
  "Akce dialogu výběru souboru"
 ],
 "Open in file browser": [
  null,
  "Otevřít v procházení souborů"
 ],
 "Hide hidden files": [
  null,
  "Nezobrazovat skryté soubory"
 ],
 "Show hidden files": [
  null,
  "Zobrazit skryté soubory"
 ],
 "Filesystem": [
  null,
  "Souborový systém"
 ],
 "Clear filters": [
  null,
  "Vyčistit filtry"
 ],
 "Directory is empty": [
  null,
  "Složka je prázdná"
 ],
 "Directory has no sub-directories": [
  null,
  "Složka nemá žádné podsložky"
 ],
 "This directory contains only hidden files": [
  null,
  "Tato složka obsahuje pouze skryté soubory"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "Folder": [
  null,
  "Složka"
 ],
 "File": [
  null,
  "Soubor"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Select an option": [
  null,
  "Vyberte možnost"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "View logs": [
  null,
  "Zobrazit záznamy událostí"
 ],
 "Dismiss": [
  null,
  "Zahodit"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Využití"
 ],
 "none": [
  null,
  "nic"
 ],
 "Not found": [
  null,
  "Nenalezeno"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "Not running": [
  null,
  "Není spuštěné"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte smazání $0"
 ],
 "Username": [
  null,
  "Uživatelské jméno"
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Started": [
  null,
  "Spuštěno"
 ],
 "Delete group": [
  null,
  "Smazat skupinu"
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Lock": [
  null,
  "Uzamknout"
 ],
 "Use $0": [
  null,
  "Použít $0"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Disconnect": [
  null,
  "Odpojit"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chybí",
  "$0 disky chybí",
  "$0 disků chybí"
 ],
 "Location": [
  null,
  "Umístění"
 ],
 "Compression": [
  null,
  "Komprese"
 ],
 "Storage logs": [
  null,
  "Záznamy událostí úložiště"
 ],
 "Name cannot be empty.": [
  null,
  "Název je třeba vyplnit."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Název nemůže být delší než 127 znaků."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Název nemůže obsahovat znak „$0“."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Název nemůže obsahovat prázdný znak."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Název nemůže být delší než $0 znaků"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Název nemůže být delší než $0 bajtů"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Fond pro thin logické svazky"
 ],
 "Thin logical volume": [
  null,
  "Tenký logický svazek"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logický svazek (zachycený stav)"
 ],
 "Logical volume": [
  null,
  "Logický svazek"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID zařízení $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 skupina svazků $0"
 ],
 "VDO device $0": [
  null,
  "VDO zařízení $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Šifrovaný logický svazek na $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Šifrovaný oddíl na $0"
 ],
 "Logical volume of $0": [
  null,
  "Logický svazek na $0"
 ],
 "Partition of $0": [
  null,
  "Oddíl na $0"
 ],
 "Encrypted $0": [
  null,
  "Šifrované $0"
 ],
 "unpartitioned space on $0": [
  null,
  "nerozdělené místo na $0"
 ],
 "unmount": [
  null,
  "odpojit (unmount)"
 ],
 "mount": [
  null,
  "mount"
 ],
 "remove from btrfs volume": [
  null,
  "odebrat z btrfs svazku"
 ],
 "stop": [
  null,
  "zastavit"
 ],
 "remove from MDRAID": [
  null,
  "odebrat z MDRAID"
 ],
 "remove from LVM2": [
  null,
  "odebrat z LVM2"
 ],
 "btrfs device": [
  null,
  "btrfs zařízení"
 ],
 "btrfs volume": [
  null,
  "btrfs svazek"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Název nemůže být delší než 255 znaků."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Název nemůže obsahovat znak „/“."
 ],
 "Create and mount": [
  null,
  "Vytvořit a připojit"
 ],
 "Create only": [
  null,
  "Pouze vytvořit"
 ],
 "Create subvolume": [
  null,
  "Vytvořit dílčí svazek"
 ],
 "Mount Point": [
  null,
  "Přípojný bod"
 ],
 "delete": [
  null,
  "smazat"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Nenávratně smazat dílčí svazek $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Smazání vymaže veškerá data na tomto dílčím svazku a všech jemu podřízeným."
 ],
 "Edit mount point": [
  null,
  "Upravit přípojný bod"
 ],
 "Unmount": [
  null,
  "Odpojit"
 ],
 "Mount": [
  null,
  "Připojit (mount)"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Je třeba, aby byl připojený alespoň jeden dílčí svazek"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Poslední zbývající připojený dílčí svazek možné smazat"
 ],
 "btrfs subvolume": [
  null,
  "btrfs dílčí svazek"
 ],
 "Snapshot origin": [
  null,
  "Původ zachyceného stavu"
 ],
 "Mount point": [
  null,
  "Přípojný bod"
 ],
 "No subvolumes": [
  null,
  "Žádné dílčí svazky"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs dílčí svazky"
 ],
 "Snapshots": [
  null,
  "Zachycené stavy"
 ],
 "No snapshots found": [
  null,
  "Nenalezeny žádné zachycené stavy"
 ],
 "snapshot": [
  null,
  "zachycený stav"
 ],
 "$0 is in use": [
  null,
  "$0 je používáno"
 ],
 "Permanently delete $0?": [
  null,
  "Nenávratně smazat $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Smazání vymaže veškerá data v btrfs svazku."
 ],
 "Delete filesystem": [
  null,
  "Smazat souborový systém"
 ],
 "Change label": [
  null,
  "Změnit štítek"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Souborový systém je připojen pouze pro čtení"
 ],
 "Label": [
  null,
  "Štítek"
 ],
 "Capacity": [
  null,
  "Kapacita"
 ],
 "btrfs devices": [
  null,
  "btrfs zařízení"
 ],
 "No devices found": [
  null,
  "Nenalezena žádná zařízení"
 ],
 "btrfs filesystem": [
  null,
  "souborový systém btrfs"
 ],
 "Successful": [
  null,
  "Úspěšné"
 ],
 "Aborted": [
  null,
  "Přerušeno"
 ],
 "In progress": [
  null,
  "Probíhá"
 ],
 "Interrupted": [
  null,
  "Přerušeno"
 ],
 "Did not complete": [
  null,
  "Nedokončeno"
 ],
 "Failed (Unknown)": [
  null,
  "Selhalo (neznámé)"
 ],
 "Failed (Electrical)": [
  null,
  "Selhalo (elektricky)"
 ],
 "Failed (Servo)": [
  null,
  "Selhalo (servomotor)"
 ],
 "Failed (Read)": [
  null,
  "Selhalo (čtení)"
 ],
 "Failed (Damaged)": [
  null,
  "Selhalo (poškozené)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Přerušeno úrovní řadiče reset"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Zrušeno kvůli odebrání jmenného prostoru z inventáře takových prostorů"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Přerušeno kvůli zpracovávání NVM příkazu formátování"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "V průběhu operace samotestování došlo k fatální chybě"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Dokončeno se segmentem, který selhal, přičemž který to byl není známo"
 ],
 "Completed with one or more failed segments": [
  null,
  "Dokončeno s jedním nebo vícero selhavšími segmenty"
 ],
 "Aborted for unknown reason": [
  null,
  "Přerušeno z neznámého důvodu"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Přerušeno kvůli operaci vymazávání"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Náhradní kapacita poklesla pod prahovou hranici"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Teplota je mimo doporučený rozsah"
 ],
 "Degraded": [
  null,
  "Degradované"
 ],
 "All media is in read-only mode": [
  null,
  "Celé médium je v režimu pouze pro čtení"
 ],
 "Volatile memory backup failed": [
  null,
  "Zálohování obsahu netrvalé paměti se nezdařilo"
 ],
 "Persistent memory has become read-only": [
  null,
  "Trvalá paměť se stala pouze pro čtení"
 ],
 "Run short test": [
  null,
  "Spustit krátký test"
 ],
 "Run extended test": [
  null,
  "Spustit rozšíření test"
 ],
 "Abort test": [
  null,
  "Přerušit test"
 ],
 "Disk is failing": [
  null,
  "Disk selhává"
 ],
 "Disk is OK": [
  null,
  "Disk je OK"
 ],
 "Assessment": [
  null,
  "Posouzení"
 ],
 "Power on hours": [
  null,
  "Hodin v provozu"
 ],
 "$0 hours": [
  null,
  "$0 hodiny"
 ],
 "Self-test status": [
  null,
  "Stav samotestu"
 ],
 "Number of bad sectors": [
  null,
  "Počet vadných sektorů"
 ],
 "Attributes failing": [
  null,
  "Selhávající atributy"
 ],
 "Media drive": [
  null,
  "Jednotka média"
 ],
 "Solid State Drive": [
  null,
  "Jednotka bez pohyblivých částí"
 ],
 "Hard Disk Drive": [
  null,
  "Jednotka pevného disku"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI jednotka"
 ],
 "Drive": [
  null,
  "Jednotka"
 ],
 "Device health (SMART)": [
  null,
  "Stav zařízení (SMART)"
 ],
 "Firmware version": [
  null,
  "Verze firmware"
 ],
 "Serial number": [
  null,
  "Sériové číslo"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "Není vloženo žádné médium"
 ],
 "Device file": [
  null,
  "Soubor představující zařízení"
 ],
 "Multipathed devices": [
  null,
  "Zařízení s vícero cestami (multipath)"
 ],
 "Free space": [
  null,
  "Volné místo"
 ],
 "Create partition": [
  null,
  "Vytvořit oddíl"
 ],
 "Extended partition": [
  null,
  "Rozšířený oddíl"
 ],
 "$0 partitions": [
  null,
  "$0 oddíly"
 ],
 "Partitions": [
  null,
  "Oddíly"
 ],
 "No partitions found": [
  null,
  "Nenalezeny žádné oddíly"
 ],
 "Unexpected partitions": [
  null,
  "Neočekávané oddíly"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Na tomto blokovém zařízení nejsou oddíly podporované. Pokud slouží jako disk pro virtuální stroj, je třeba, aby oddíly byly spravovány operačním systémem uvnitř virtuálního stroje."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Smazání oddílu vymaže veškerá data na něm."
 ],
 "No free space after this partition": [
  null,
  "Za tímto oddílem už není žádné volné místo"
 ],
 "EFI system partition": [
  null,
  "Systémový oddíl EFI"
 ],
 "BIOS boot partition": [
  null,
  "Oddíl pro BIOS zavádění"
 ],
 "Partition": [
  null,
  "Oddíl"
 ],
 "Shrink": [
  null,
  "Zmenšit"
 ],
 "Grow": [
  null,
  "Zvětšit"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Zaváděcí oddíl PReP architektury PowerPC"
 ],
 "Linux swap space": [
  null,
  "Odkládací prostor Linux"
 ],
 "Linux filesystem data": [
  null,
  "Data linuxového souborového systému"
 ],
 "Logical Volume Manager partition": [
  null,
  "Oddíl správy logických svazků"
 ],
 "Custom": [
  null,
  "Uživatelsky určené"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Je třeba, aby typ obsahoval právě dva šestnáctkové znaky (0 až 9, A až F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ může obsahovat pouze znaky 0 až 9, A až F, a „-“ (mínus, spojovník)."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Je třeba, aby typ měl podobu NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Nastavit typ oddílu na $0"
 ],
 "Custom type": [
  null,
  "Uživatelsky určený typ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Změna typů oddílů může bránit nastartování systému."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Tento oddíl není zcela využíván obsahem, který se na něm nachází."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Velikost oddílu je $0. Velikost obsahu na něm je $1."
 ],
 "Shrink partition": [
  null,
  "Zmenšit oddíl"
 ],
 "Grow content": [
  null,
  "Zvětšit obsah"
 ],
 "initialize": [
  null,
  "inicializovat"
 ],
 "Initialize disk $0": [
  null,
  "Inicializovat disk $0"
 ],
 "Partitioning": [
  null,
  "Vytváření oddílů"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibilní se všemi systémy a zařízeními (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibilní s moderním systémem a pevnými disky > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Žádný oddíl"
 ],
 "Overwrite": [
  null,
  "Přepsat"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Přepsat existující data nulami (pomalejší)"
 ],
 "Initialize": [
  null,
  "inicializovat"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inicializace vymaže veškerá data na disku."
 ],
 "Device is read-only": [
  null,
  "Zařízení je pouze pro čtení"
 ],
 "Create partition table": [
  null,
  "Vytvořit tabulku rozdělení na oddíly"
 ],
 "Size must be a number": [
  null,
  "Je třeba, aby velikost byla číslo"
 ],
 "Size cannot be zero": [
  null,
  "Velikost nemůže být nula"
 ],
 "Size cannot be negative": [
  null,
  "Velikost nemůže být záporná"
 ],
 "Size is too large": [
  null,
  "Příliš velké"
 ],
 "Size must be at least $0": [
  null,
  "Je třeba, aby velikost byla alespoň $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fyzický svazek LVM2 skupiny svazků"
 ],
 "member of MDRAID device": [
  null,
  "člen MDRAID zařízení"
 ],
 "backing device for VDO device": [
  null,
  "zařízení, na kterém je VDO zařízení založeno"
 ],
 "member of Stratis pool": [
  null,
  "člen Stratis fondu"
 ],
 "Filesystem outside the target": [
  null,
  "Souborový systém vně cíle"
 ],
 "device of btrfs volume": [
  null,
  "zařízení btrfs svazku"
 ],
 "This device is currently in use.": [
  null,
  "Toto zařízení je v tuto chvíli používáno."
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Use": [
  null,
  "Použít"
 ],
 "Services using the location": [
  null,
  "Služby využívající toto umístění"
 ],
 "Processes using the location": [
  null,
  "Procesy využívající toto umístění"
 ],
 "Currently in use": [
  null,
  "Nepoužíváno"
 ],
 "(Not part of target)": [
  null,
  "(Není součástí cíle)"
 ],
 "These changes will be made:": [
  null,
  "Budou učiněny tyto změny:"
 ],
 "Action": [
  null,
  "Akce"
 ],
 "Important data might be deleted:": [
  null,
  "Může se stát, že budou smazána důležitá data:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Související procesy a služby budou vynuceně zastaveny."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Související procesy budou vynuceně zastaveny."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Související služby budou vynuceně zastaveny."
 ],
 "Checking filesystem usage": [
  null,
  "Zjišťování využití souborového systému"
 ],
 "$0 used, $1 total": [
  null,
  "$0 použito, $1 celkem"
 ],
 "Device contains unrecognized data": [
  null,
  "Zařízení obsahuje nerozpoznaná data"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Je možné, že uzamčené šifrované zařízení obsahuje data"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Potvrzuji, že chci tato data natrvalo ztratit"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Přípojný bod $0 je používán následujícími procesy:"
 ],
 "PID": [
  null,
  "Identif. procesu"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Přípojný bod $0 je používán následujícími službami:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Uvedené procesy a služby budou vynuceně zastaveny."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Uvedené procesy budou vynuceně zastaveny."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Uvedené služby budou vynuceně zastaveny."
 ],
 "Sorry": [
  null,
  "Promiňte"
 ],
 "Usage of $0": [
  null,
  "Využití $0"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO fond"
 ],
 "Data used": [
  null,
  "Využito dat"
 ],
 "Metadata used": [
  null,
  "Využito metadat"
 ],
 "Use compression": [
  null,
  "Komprimovat"
 ],
 "Deduplication": [
  null,
  "Deduplikace"
 ],
 "Use deduplication": [
  null,
  "Deduplikovat"
 ],
 "Rename volume group": [
  null,
  "Přejmenovat skupinu svazků"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Tato skupina svazků obsahuje kořenový souborový systém (/). Přejmenování této skupiny může vyžadovat provedení změn v nastavení zavaděče systému a/nebo příkazového řádku, předávanému jádru systému při zavádění."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Smazání vymaže veškerá data ve skupině svazků."
 ],
 "Create snapshot": [
  null,
  "Pořídit zachycený stav"
 ],
 "Add disks": [
  null,
  "Přidat disky"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "No disks are available.": [
  null,
  "Nejsou k dispozici žádné disky."
 ],
 "At least one disk is needed.": [
  null,
  "Je vyžadován alespoň jeden disk."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Skupině svazků chybí fyzické svazky"
 ],
 "No free space": [
  null,
  "Žádné volné místo"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 skupina svazků"
 ],
 "Add physical volume": [
  null,
  "Přidat fyzický svazek"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 logické oddíly"
 ],
 "Create new logical volume": [
  null,
  "Vytvořit nový logický svazek"
 ],
 "No logical volumes": [
  null,
  "Žádné logické svazky"
 ],
 "Remove missing physical volumes?": [
  null,
  "Odebrat chybějící fyzické svazky?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Této skupině svazků chybí některé fyzické svazky."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Skupinu svazků, ve které chybí fyzické svazky, není možné přejmenovat."
 ],
 "Physical volumes": [
  null,
  "Fyzické svazky"
 ],
 "No physical volumes found": [
  null,
  "Nenalezeny žádné fyzické svazky"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fyzické svazky"
 ],
 "Rename logical volume": [
  null,
  "Přejmenovat logický svazek"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Nenávratně smazat logický svazek $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Smazání logického svazku vymaže veškerá data na něm."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Nepodařilo se opravit logický svazek $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Není k dispozici dostatek prostoru, který by bylo možné použít pro opravu. Na fyzických svazcích je zapotřebí přinejmenším $0, které ještě nejsou použity pro logický svazek."
 ],
 "An additional $0 must be selected": [
  null,
  "Je třeba vybrat další $0"
 ],
 "Repair logical volume $0": [
  null,
  "Opravit logický svazek $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Vyberte fyzické svazky, které mají být použity pro opravu logického svazku. Je zapotřebí alespoň $0."
 ],
 "Physical Volumes": [
  null,
  "Fyzické svazky"
 ],
 "Repair": [
  null,
  "Opravit"
 ],
 "deactivate": [
  null,
  "deaktivovat"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Deaktivovat logický svazek $0/$1?"
 ],
 "Deactivate": [
  null,
  "Deaktivovat"
 ],
 "Not enough space to grow": [
  null,
  "Pro zvětšení není k dispozici dostatek prostoru"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 logický svazek"
 ],
 "Striped (RAID 0)": [
  null,
  "Proužkované (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Zrcadlené (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Proužkované a zrcadlené (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Vyhrazená parita (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuovaná parita (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dvojitá distribuovaná parita (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Tento logický svazek není zcela využíván obsahem, který se na něm nachází."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Velikost svazku je $0. Velikost obsahu na něm je $1."
 ],
 "Shrink volume": [
  null,
  "Zmenšit oddíl"
 ],
 "Layout": [
  null,
  "Rozvržení"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky a už ho není možné používat. Je třeba ho smazat a vytvořit nový na jeho místě."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky, ale zatím ještě nedošlo ke ztrátě žádných dat. Měli byste ho opravit a obnovit tak jeho původní odolnost."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Tento logický svazek ztratil některé své fyzické svazky, ale nejspíš ještě neztratil žádná data. Měli byste být schopní ho opravit."
 ],
 "Stripes": [
  null,
  "Proužky"
 ],
 "$0 synchronized": [
  null,
  "$0 synchronizováno"
 ],
 "Create volume group": [
  null,
  "Vytvořit skupinu svazků"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fyzický svazek"
 ],
 "Last cannot be removed": [
  null,
  "Poslední zbývající není možné odebrat"
 ],
 "Not enough free space": [
  null,
  "Nedostatek volného prostoru"
 ],
 "Volume group": [
  null,
  "Skupina oddílů"
 ],
 "Create thin volume": [
  null,
  "Vytvořit tence poskytovaný (thin provided) svazek"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tence poskytované LVM2 logické svazky"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Vytvořit nový tence (thin) poskytovaný logický svazek"
 ],
 "Not enough space": [
  null,
  "Nedostatek prostoru"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Fond pro tence poskytované LVM2 logické svazky"
 ],
 "Inactive logical volume": [
  null,
  "Neaktivní logický svazek"
 ],
 "Activate": [
  null,
  "Aktivovat"
 ],
 "Unsupported logical volume": [
  null,
  "Nepodporovaný logický svazek"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "VNITŘNÍ CHYBA – Tento logický svazek je označen jako aktivní a měl by mít přiřazené blokové zařízení. Žádné takové blokové zařízení však nebylo nalezeno."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Instalace $0 by odebrala $1."
 ],
 "Installing packages": [
  null,
  "Instalují se balíčky"
 ],
 "Block device for filesystems": [
  null,
  "Blokové zařízení pro souborové systémy"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Fond pro tence poskytované svazky"
 ],
 "Linear": [
  null,
  "Lineární"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Svazek VDO souborového systému (komprese/deduplikace)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích bez jakékoli dodatečné odolnosti či zlepšení výkonu."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích střídavě, což zlepší výkon. Je třeba vybrat alespoň dva svazky."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data budou ukládána jako dvě či více kopií na vybraných fyzických svazcích, což zlepší spolehlivost. Je třeba vybrat alespoň dva svazky."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data budou ukládána jako dvě kopie a ty pak střídavě na označených fyzických svazcích, což zlepší jak spolehlivost, tak výkon. Je třeba vybrat alespoň 4 svazky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné jeden z nich ztratit, aniž by to postihlo data. Je třeba vybrat alespoň tři svazky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné jeden z nich ztratit, aniž by to postihlo data. Bude také zlepšen výkon ukládáním dat střídavě. Je třeba vybrat alespoň tři svazky."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data budou ukládána na vybraných fyzických svazcích tak, že bude možné ztratit až dva naráz, aniž by to postihlo data. Bude také zlepšen výkon ukládáním dat střídavě. Je třeba vybrat alespoň pět svazků."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Všech $0 vybraných fyzických svazků je třeba pro zvolené rozvržení."
 ],
 "Create logical volume": [
  null,
  "Vytvořit logický svazek"
 ],
 "Purpose": [
  null,
  "Účel"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Pro vytváření VDO zařízení bude nainstalován balíček $0."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Pro RAID 10 je třeba sudý počet fyzických svazků"
 ],
 "Logical size": [
  null,
  "Logická velikost"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Šetřit prostorem komprimováním jednotlivých bloků pomocí LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Šetřit prostorem tím, že stejné bloky dat budou ukládány pouze jednou"
 ],
 "Creating VDO device": [
  null,
  "Vytváří se VDO zařízení"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Toto NFS připojení je používáno a měnit je možné jen jeho předvolby."
 ],
 "NFS mount": [
  null,
  "NFS připojení"
 ],
 "New NFS mount": [
  null,
  "Nové NFS připojení"
 ],
 "Server address": [
  null,
  "Adresa serveru"
 ],
 "Server cannot be empty.": [
  null,
  "Server je třeba vyplnit."
 ],
 "Path on server": [
  null,
  "Popis umístění na serveru"
 ],
 "Path on server cannot be empty.": [
  null,
  "Popis umístění na serveru je třeba vyplnit."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Je třeba, aby popis umístění na serveru začínal na „/“."
 ],
 "Local mount point": [
  null,
  "Místní přípojný bod"
 ],
 "Mount point cannot be empty.": [
  null,
  "Přípojný bod je třeba vyplnit."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Je třeba, aby popis přípojného bodu začínal na „/“."
 ],
 "Mount options": [
  null,
  "Předvolby připojení"
 ],
 "Mount at boot": [
  null,
  "Připojit při startu"
 ],
 "Mount read only": [
  null,
  "Připojit pouze pro čtení"
 ],
 "Custom mount options": [
  null,
  "Uživatelsky určené předvolby připojení"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nedaří se odpojit souborový systém"
 ],
 "Stop and unmount": [
  null,
  "Zastavit a odpojit"
 ],
 "Unable to remove mount": [
  null,
  "Účet se nedaří odebrat"
 ],
 "Stop and remove": [
  null,
  "Zastavit a odebrat"
 ],
 "(not mounted)": [
  null,
  "(nepřipojeno)"
 ],
 "Start multipath": [
  null,
  "Spustit multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "V systému jsou zařízení s vícero cestami, ale služba multipath není spuštěná."
 ],
 "Show all $0 rows": [
  null,
  "Zobrazit všech $0 řádků"
 ],
 "Category": [
  null,
  "Kategorie"
 ],
 "more info": [
  null,
  "další informace"
 ],
 "Encryption": [
  null,
  "Šifrování"
 ],
 "encrypted": [
  null,
  "šifrováno"
 ],
 "Last modified: $0": [
  null,
  "Naposledy zkontrolováno: $0"
 ],
 "Stored passphrase": [
  null,
  "Uložená heslová fráze"
 ],
 "Encryption options": [
  null,
  "Předvolby šifrování"
 ],
 "Encryption type": [
  null,
  "Typ šifrování"
 ],
 "Cleartext device": [
  null,
  "Znakové zařízení"
 ],
 "yes": [
  null,
  "ano"
 ],
 "Disk passphrase": [
  null,
  "Heslová fráze k disku"
 ],
 "Passphrase cannot be empty": [
  null,
  "Heslovou frázi je třeba vyplnit"
 ],
 "Unlocking disk": [
  null,
  "Odemykání disku"
 ],
 "Checking for $0 package": [
  null,
  "Zjišťování pro $0 balíček"
 ],
 "The $0 package must be installed.": [
  null,
  "Je třeba, aby byl nainstalovaný balíček $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Balíček $0 není k dispozici v žádném z repozitářů."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Chyba při instalování $0: PackageKit nebo dnf5daemon-server není nainstalovaný"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Neočekávaná chyba správy balíčků v průběhu instalace $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Zjišťování přítomnosti podpory NBDE v initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Je třeba znovu vytvořit initrd."
 ],
 "Regenerating initrd": [
  null,
  "Znovuvytváření initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Přidává se rd.neednet=1 do parametrů zavádění jádra"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Přidává se „$0“ do možností souborového systému"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Přidává se „$0“ do možností šifrování"
 ],
 "Enabling $0": [
  null,
  "Povoluje se $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Přidat šifrování disku vázané na síť"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systém v tuto chvíli nepodporuje odemykání kořenového souborového systému pomocí Tang serveru s klíči."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systém v tuto chvíli nepodporuje odemykání souborového systému pomocí Tang serveru s klíči v průběhu zavádění systému."
 ],
 "These additional steps are necessary:": [
  null,
  "Jsou nezbytné tyto další kroky:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uložení nové heslové fráze vyžaduje odemknutí disku. Zadejte stávající heslovou frázi k disku."
 ],
 "Fix NBDE support": [
  null,
  "Opravit podporu pro NBDE"
 ],
 "Adding key": [
  null,
  "Přidává se klíč"
 ],
 "Key source": [
  null,
  "Zdroj klíče"
 ],
 "Repeat passphrase": [
  null,
  "Zopakovat heslovou frázi"
 ],
 "Passphrase": [
  null,
  "Heslová fráze"
 ],
 "Tang keyserver": [
  null,
  "Tang server s klíči"
 ],
 "New passphrase": [
  null,
  "Nová heslová fráze"
 ],
 "Passphrases do not match": [
  null,
  "Zadání heslové fráze se neshodují"
 ],
 "Keyserver address": [
  null,
  "Adresa serveru s klíči"
 ],
 "Change passphrase": [
  null,
  "Změnit heslovou frázi"
 ],
 "Old passphrase": [
  null,
  "Původní heslová fráze"
 ],
 "Edit Tang keyserver": [
  null,
  "Upravit Tang server s klíči"
 ],
 "Verify key": [
  null,
  "Ověřit klíč"
 ],
 "Trust key": [
  null,
  "Důvěryhodný klíč"
 ],
 "Passphrase can not be empty": [
  null,
  "Heslovou frázi je třeba vyplnit"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Odebrání heslové fráze může bránit odemknutí $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potvrdit odebrání pomocí alternativní heslové fráze"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Odebrání heslové fráze bez potvrzení jiné heslové fráze může bránit v odemknutí nebo správě klíčů, pokud jsou ostatní heslové fráze zapomenuty nebo ztraceny."
 ],
 "Passphrase from any other key slot": [
  null,
  "Heslová fráze z libovolného jiného slotu s klíčem"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Odebrat heslovou frázi v slotu na klíč $0?"
 ],
 "Remove $0?": [
  null,
  "Odebrat $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Odebrání může zabránit odemčení $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Odebrat Tang server s klíči?"
 ],
 "Remove key in slot $0?": [
  null,
  "Odebrat klíč v slotu $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Stávající uživatel není oprávněn zobrazovat informace o klíčích."
 ],
 "No keys added": [
  null,
  "Nepřidány žádné klíče"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "K upravení klíče je zapotřebí volného slotu"
 ],
 "The last key slot can not be removed": [
  null,
  "Poslední zbývající slot klíče není možné odebrat"
 ],
 "Keyserver": [
  null,
  "Server s klíči"
 ],
 "Unknown type": [
  null,
  "Neznámý typ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sloty klíčů s neznámým typem zde není možné upravovat"
 ],
 "Keys": [
  null,
  "Klíče"
 ],
 "$0 slot remains": [
  null,
  "$0 slot zbývá",
  "$0 sloty zbývají",
  "$0 slotů zbývá"
 ],
 "No available slots": [
  null,
  "Nejsou k dispozici žádné sloty"
 ],
 "No free key slots": [
  null,
  "Žádné volné sloty klíčů"
 ],
 "Locked data": [
  null,
  "Uzamčená data"
 ],
 "lock": [
  null,
  "zamknout"
 ],
 "Lock $0?": [
  null,
  "Uzamknout $0?"
 ],
 "Address cannot be empty": [
  null,
  "Adresu je třeba vyplnit"
 ],
 "Address is not a valid URL": [
  null,
  "Do adresy nebyla vyplněná platná URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Zkontrolovat otisk klíče vůči Tang serveru."
 ],
 "How to check": [
  null,
  "Jak zkontrolovat"
 ],
 "In a terminal, run: ": [
  null,
  "V terminálu spusťte: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Úspěšně zkopírováno do schránky!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Zkontrolujte, že se SHA-256 nebo SHA-1 otisk z příkazu shoduje s tímto dialogem."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs dílčí svazke $0 z $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Je třeba vyplnit přípojný bod"
 ],
 "Mount point is already used for $0": [
  null,
  "Přípojný bod už je používán pro $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Do tohoto přípojného bodu už jsou připojené souborové systémy."
 ],
 "Please unmount them first.": [
  null,
  "Prosím nejprve je odpojte."
 ],
 "read only": [
  null,
  "pouze pro čtení"
 ],
 "never mount at boot": [
  null,
  "nikdy nepřipojovat při startu systému"
 ],
 "after network": [
  null,
  "po síti"
 ],
 "ignore failure": [
  null,
  "ignorovat nezdar"
 ],
 "stop boot on failure": [
  null,
  "při nezdaru zastavit start systému"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Souborový systém nemá přiřazen přípojný bod."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Souborový systém nemá trvalý přípojný bod."
 ],
 "The filesystem is not mounted.": [
  null,
  "Souborový systém není připojený."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Souborový systém bude odemčen při příštím startu systému. To může vyžadovat zadání heslové fráze."
 ],
 "(no assigned mount point)": [
  null,
  "(nepřiřazen žádný přípojný bod)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Souborový systém je nyní připojený v $0, ale po příštím startu systému bude připojený v $1."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Při startu systému automaticky připojit do $0"
 ],
 "Mount on $0 now": [
  null,
  "Připojit do $0 nyní"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Souborový systém nyní není připojený, ale po příštím startu systému už bude."
 ],
 "Do not mount automatically on boot": [
  null,
  "Nepřipojovat automaticky při startu systému"
 ],
 "Mount now": [
  null,
  "Připojit nyní"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Souborový systém je nyní připojený, ale po příštím startu systému už nebude."
 ],
 "Mount also automatically on boot": [
  null,
  "Připojovat také automaticky při startu systému"
 ],
 "Unmount now": [
  null,
  "Odpojit nyní"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Souborový systém je nyní připojený v $0, ale po příštím startu systému už nebude připojený vůbec."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Souborový systém je nastavený tak, aby byl automaticky připojován při startu systému, ale šifrovaný kontejner, ve kterém se nachází, nebude v tu dobu odemčený."
 ],
 "Unlock automatically on boot": [
  null,
  "Automaticky odemknout při startu systému"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Nekonzistentní připojení souborového systému"
 ],
 "$0 filesystem": [
  null,
  "$0 souborový systém"
 ],
 "Filesystem name": [
  null,
  "Název souborového systému"
 ],
 "Filesystem is locked": [
  null,
  "Souborový systém je uzamčen"
 ],
 "Mounts before services start": [
  null,
  "Připojit před spuštěním služeb"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Příhodné pro kriticky důležité přípojné body, jako např. /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Pokud souborový systém nebude připojen, start operačního systému se nezdaří a nebude tak možný vzdálený přístup"
 ],
 "Mounts in parallel with services": [
  null,
  "Bude připojeno souběžně se službami"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Start operačního systému se zdaří i když souborový systém nebude připojen"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Připojuje souběžně se službami, ale až poté, co je k dispozici síť"
 ],
 "Does not mount during boot": [
  null,
  "Nepřipojuje se při startu systému"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Užitečné pro připojení která jsou volitelná nebo vyžadují interakci (jako např. heslovou frázi)"
 ],
 "At boot": [
  null,
  "Při startu systému"
 ],
 "Mount before services start": [
  null,
  "Připojit před spuštěním služeb"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Připojit bez čekání, ignorovat nezdar"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Připojit až bude síť k dispozici, ignorovat nezdar"
 ],
 "Do not mount": [
  null,
  "Nepřipojovat"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Toto zařízení nelze využít pro cíl instalace."
 ],
 "Mount filesystem": [
  null,
  "Připojit souborový systém"
 ],
 "Unmount filesystem $0": [
  null,
  "Odpojit souborový systém $0"
 ],
 "Mount configuration": [
  null,
  "Nastavení připojení (mount)"
 ],
 "Swap": [
  null,
  "Odkládací oddíl"
 ],
 "Used": [
  null,
  "Využito"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odemknout šifrovaný Stratis fond"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Zadejte heslovou frázi pro fond na těchto blokových zařízeních:"
 ],
 "Stratis pool": [
  null,
  "Stratis fond"
 ],
 "stopped": [
  null,
  "zastaveno"
 ],
 "Block devices": [
  null,
  "Bloková zařízení"
 ],
 "No block devices found": [
  null,
  "Nenalezena žádná bloková zařízení"
 ],
 "Stratis block devices": [
  null,
  "Stratis bloková zařízení"
 ],
 "Stratis block device": [
  null,
  "Stratis blokové zařízení"
 ],
 "data": [
  null,
  "data"
 ],
 "cache": [
  null,
  "mezipaměť"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Zadejte stávající heslovou frázi k fondu."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Pokud server s klíči na $0 není dosažitelný, je možné zadat existující heslovou frázi."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Pokud není dosažitelný žádný ze serverů s klíči, je možné zadat existující heslovou frázi."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Pokud není funkční žádná z neinteraktivních metod odemykání, je možné zadat existující heslovou frázi."
 ],
 "Pool passphrase": [
  null,
  "Heslová fráze k fondu"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Je třeba, aby server s klíči $0 byl dosažitelný."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Je třeba, aby byl dosažitelný alespoň jeden server s klíči."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Je třeba, aby byla funkční alespoň jedna z neinteraktivních metod odemykání."
 ],
 "Create filesystem": [
  null,
  "Vytvořit souborový systém"
 ],
 "Stratis filesystem": [
  null,
  "Stratis souborový systém"
 ],
 "Set initial size": [
  null,
  "Nastavit počáteční velikost"
 ],
 "Limit size": [
  null,
  "Omezit velikost"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Smazání Stratis fondu vymaže veškerá data na něm."
 ],
 "Rename Stratis pool": [
  null,
  "Přejmenovat Stratis fond"
 ],
 "Add block devices": [
  null,
  "Přidat blokové zařízení"
 ],
 "Tier": [
  null,
  "Tier"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Cache": [
  null,
  "Mezipaměť"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Přidání blokových zařízení vyžaduje odemknutí fondu."
 ],
 "Encrypted Stratis pool": [
  null,
  "Šifrovaný Stratis fond"
 ],
 "Delete pool": [
  null,
  "Smazat fond"
 ],
 "Encryption tokens": [
  null,
  "Tokeny šifrování"
 ],
 "Stratis filesystems": [
  null,
  "Stratis souborové systémy"
 ],
 "Create new filesystem": [
  null,
  "Vytvořit nový souborový systém"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Tento fond nevyužívá ze svých podkladových zařízení všechen prostor."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Velikost některých blokových zařízení byla po vytvoření fondu zvětšena. Fond je možné bezpečně zvětšit a využít tak nově dostupné místo."
 ],
 "Grow the pool to take all space": [
  null,
  "Zvětšit fond tak, aby využil veškerý dostupný prostor"
 ],
 "This pool is in a degraded state.": [
  null,
  "Tento fond se nachází v degradovaném stavu."
 ],
 "No filesystems": [
  null,
  "Žádné souborové systémy"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis fond souborových systémů"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Tato heslová fráze je jediným způsobem jak fond odemknout a proto jí není možné odebrat."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tento server s klíči je jediný způsob jak fond odemknout a není ho proto možné odebrat."
 ],
 "Add passphrase": [
  null,
  "Přidat heslovou frázi"
 ],
 "Add keyserver": [
  null,
  "Přidat server s klíči"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis „$0“"
 ],
 "Last token can not be removed": [
  null,
  "Poslední zbývající token není možné odebrat"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Nezbývá žádný další prostor pro heslové fráze či servery s klíči."
 ],
 "Confirm": [
  null,
  "Potvrdit"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Přidání heslové fráze vyžaduje odemknutí fondu."
 ],
 "Remove passphrase?": [
  null,
  "Odebrat heslovou frázi?"
 ],
 "Add Tang keyserver": [
  null,
  "Přidat Tang server s klíči"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Přidání serveru s klíči vyžaduje odemknutí fondu."
 ],
 "Remove Clevis token?": [
  null,
  "Odebrat Clevis token?"
 ],
 "Metadata format": [
  null,
  "Formát metadat"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Fondy s formátem metadat verze 1 jsou omezené na nejvýše jednu heslovou frázi a jeden server s klíči."
 ],
 "Overprovisioning": [
  null,
  "Přidělování více prostředků, než je k dispozici"
 ],
 "Allow overprovisioning": [
  null,
  "Umožnit přidělování více prostředků, než je k dispozici"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Virtuální velikosti souborových systémů jsou větší než fond. Přidělování více prostředků, než je k dispozici proto není možné vypnout."
 ],
 "Allocated": [
  null,
  "Přiděleno"
 ],
 "Name can not be empty.": [
  null,
  "Název je třeba vyplnit."
 ],
 "A pool with this name exists already.": [
  null,
  "Fond s tímto názvem už existuje."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Souborový systém s tímto názvem už v tomto fondu existuje."
 ],
 "Create Stratis pool": [
  null,
  "Vytvořit Stratis fond úložiště"
 ],
 "No block devices are available.": [
  null,
  "Nejsou k dispozici žádná bloková zařízení."
 ],
 "At least one block device is needed.": [
  null,
  "Je vyžadováno alespoň jedno blokové zařízení."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Šifrovat data pomocí heslové fráze"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Šifrovat data pomocí Tang serveru s klíči"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Pořídit zachycený stav souborového systému $0"
 ],
 "Create snapshot and mount": [
  null,
  "Pořídit zachycený stav a připojit ho"
 ],
 "Create snapshot only": [
  null,
  "Pouze pořídit zachycený stav"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Smazání souborového systému vymaže veškerá data na něm."
 ],
 "Snapshot": [
  null,
  "Zachycený stav"
 ],
 "Rename filesystem": [
  null,
  "Přejmenovat souborový systém"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Nastavit omezení virtuální velikosti souborového systému"
 ],
 "Limit virtual filesystem size": [
  null,
  "Omezit virtuální velikost souborového systému"
 ],
 "Virtual size limit": [
  null,
  "Omezení virtuální velikosti"
 ],
 "Virtual size": [
  null,
  "Virtuální velikost"
 ],
 "Create RAID device": [
  null,
  "Vytvořit RAID zařízení"
 ],
 "RAID level": [
  null,
  "RAID úroveň"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (proužkování)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (zrcadlení)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (vyhrazená parita)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuovaná parita)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dvojitá distribuovaná parita)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (proužkování zrcadel)"
 ],
 "Chunk size": [
  null,
  "Velikost bloku"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Je vyžadován alespoň $0 disk.",
  "Jsou vyžadovány alespoň $0 disky.",
  "Je vyžadováno alespoň $0 disků."
 ],
 "MDRAID disk": [
  null,
  "MDRAID disk"
 ],
 "In sync": [
  null,
  "Synchronní"
 ],
 "Spare": [
  null,
  "Náhradní"
 ],
 "Recovering": [
  null,
  "Zotavování"
 ],
 "Write-mostly": [
  null,
  "Převážně zápis"
 ],
 "Blocked": [
  null,
  "Blokované"
 ],
 "Unknown ($0)": [
  null,
  "Neznámé ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Je třeba, aby MDRAID zařízení bylo spuštěné"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID zařízení se zotavuje"
 ],
 "Need a spare disk": [
  null,
  "Potřebujete rezervní disk"
 ],
 "Last disk can not be removed": [
  null,
  "Poslední zbývající disk není možné odebrat"
 ],
 "MDRAID device": [
  null,
  "MDRAID zařízení"
 ],
 "Confirm stopping of $0": [
  null,
  "Potvrďte zastavení $0"
 ],
 "Stop device": [
  null,
  "Zastavit zařízení"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Smazání vymaže veškerá data na MDRAID zařízení."
 ],
 "MDRAID device must be running": [
  null,
  "Je třeba, aby MDRAID zařízení bylo spuštěné"
 ],
 "Add disk": [
  null,
  "Přidat disk"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 disky"
 ],
 "$0 chunk size": [
  null,
  "$0 velikost bloku dat"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID zařízení je v degradovaném stavu"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Toto MDRAID zařízení nemá bitovou mapu pro write-intent. Taková mapa může významně zkrátit časy potřebné k synchronizaci."
 ],
 "Add a bitmap": [
  null,
  "Přidat bitovou mapu"
 ],
 "No disks found": [
  null,
  "Nenalezeny žádné disky"
 ],
 "MDRAID disks": [
  null,
  "MDRAID disky"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Smazání vymaže veškerá data na VDO zařízení."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Vytváření tohoto VDO zařízení není dokončeno a proto ho nelze použít."
 ],
 "Remove device": [
  null,
  "Odebrat zařízení"
 ],
 "Grow to take all space": [
  null,
  "Zvětšit tak, aby využilo veškerý dostupný prostor"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Toto VDO zařízení nepoužívá ze svého podkladového zařízení vše."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Je použito pouze $0 z $1."
 ],
 "Grow logical size of $0": [
  null,
  "Zvětšit logickou velikost $0"
 ],
 "Physical": [
  null,
  "Fyzické"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 režie využito z $2 ($3)"
 ],
 "Logical": [
  null,
  "Logický"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "použito $0 z $1 ($2 ušetřeno)"
 ],
 "Index memory": [
  null,
  "Paměť indexu"
 ],
 "SMART self-test of $target": [
  null,
  "SMART samotest $target"
 ],
 "Ejecting $target": [
  null,
  "Vysouvání $target"
 ],
 "Unlocking $target": [
  null,
  "Odemyká se $target"
 ],
 "Locking $target": [
  null,
  "Uzamyká se $target"
 ],
 "Modifying $target": [
  null,
  "Upravuje se $target"
 ],
 "Resizing $target": [
  null,
  "Mění se velikost $target"
 ],
 "Starting swapspace $target": [
  null,
  "Spouštění odkládacího prostoru $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Zastavování odkládacího prostoru $target"
 ],
 "Mounting $target": [
  null,
  "Připojování $target"
 ],
 "Unmounting $target": [
  null,
  "Odpojování $target"
 ],
 "Checking $target": [
  null,
  "Kontroluje se $target"
 ],
 "Repairing $target": [
  null,
  "Opravuje se $target"
 ],
 "Erasing $target": [
  null,
  "Vymazává se $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Vytváří se souborový systém na $target"
 ],
 "Setting up loop device $target": [
  null,
  "Nastavování zařízení zpětné smyčky $target"
 ],
 "Deleting $target": [
  null,
  "Maže se $target"
 ],
 "Creating partition $target": [
  null,
  "Vytváří se oddíl $target"
 ],
 "Cleaning up for $target": [
  null,
  "Čištění pro $target"
 ],
 "Securely erasing $target": [
  null,
  "Zaručené vymazávání $target"
 ],
 "Very securely erasing $target": [
  null,
  "Velmi zaručené vymazávání $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Zastavování MDRAID zařízení $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Spouštění MDRAID zařízení $target"
 ],
 "Marking $target as faulty": [
  null,
  "Označování $target jako vadný"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Odebírání $target z MDRAID zařízení"
 ],
 "Creating MDRAID device $target": [
  null,
  "Vytváří se MDRAID zařízení $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Kontroluje se RAID zařízení $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontroluje a opravuje se MDRAID zařízení $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Zotavování MDRAID zařízení $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronizuje se MDRAID zařízení $target"
 ],
 "Activating $target": [
  null,
  "Aktivuje se $target"
 ],
 "Deactivating $target": [
  null,
  "Deaktivuje se $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Pořizování zachyceného stavu $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Vytváří se LVM2 skupina svazků $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Maže se LVM2 skupina svazků $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Přidává se fyzický svazek do $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Odebírání fyzického svazku z $target"
 ],
 "Emptying $target": [
  null,
  "Vyprazdňuje se $target"
 ],
 "Creating logical volume $target": [
  null,
  "Vytváří se logický svazek $target"
 ],
 "Renaming $target": [
  null,
  "Přejmenovává se $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operace „$operation“ na $target"
 ],
 "unknown target": [
  null,
  "neznámý cíl"
 ],
 "Jobs": [
  null,
  "Úlohy"
 ],
 "Reading": [
  null,
  "Čtení"
 ],
 "Writing": [
  null,
  "Zapisování"
 ],
 "Install Stratis support": [
  null,
  "Nainstalovat podporu pro Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Pro vytváření Stratis fondu je třeba, aby byl nainstalovaný balíček $0."
 ],
 "Install NFS support": [
  null,
  "Nainstalovat podporu pro NFS"
 ],
 "Create MDRAID device": [
  null,
  "Vytvořit MDRAID zařízení"
 ],
 "Create LVM2 volume group": [
  null,
  "Vytvořit LVM2 skupinu svazků"
 ],
 "Change iSCSI initiator name": [
  null,
  "Změnit název iSCSI iniciátoru"
 ],
 "Add iSCSI portal": [
  null,
  "Přidat iSCSI portál"
 ],
 "Local storage": [
  null,
  "Lokální úložiště"
 ],
 "Networked storage": [
  null,
  "Síťové úložiště"
 ],
 "Create storage device": [
  null,
  "Vytvořit zařízení úložiště"
 ],
 "No storage found": [
  null,
  "Nenalezeno žádné úložiště"
 ],
 "Server address cannot be empty.": [
  null,
  "Adresu serveru je třeba vyplnit."
 ],
 "Next": [
  null,
  "Další"
 ],
 "Invalid username or password": [
  null,
  "Neplatné uživatelské jméno a heslo"
 ],
 "Unknown host name": [
  null,
  "Neznámý název stroje"
 ],
 "Unable to reach server": [
  null,
  "Server se nedaří dosáhnout"
 ],
 "Available targets on $0": [
  null,
  "Cíle dostupné na $0"
 ],
 "Authentication required": [
  null,
  "Nutné ověření se"
 ],
 "iSCSI portal": [
  null,
  "iSCSI portál"
 ],
 "iSCSI drives": [
  null,
  "iSCSI jednotky"
 ],
 "No drives found": [
  null,
  "Nenalezeny žádné jednotky"
 ],
 "Target": [
  null,
  "Cíl"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Zařízení, která jsou podkladem pro VDO, není možné zmenšovat"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Bloková zařízení Stratis není možné zmenšovat"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nerozpoznaná data zde nelze zmenšit."
 ],
 "Unlock before resizing": [
  null,
  "Odemknout před změnou velikosti"
 ],
 "$0 can not be resized here": [
  null,
  "$0 zde není možné změnit velikost"
 ],
 "$0 can not be resized": [
  null,
  "$0 není možné změnit velikost"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 není možné zmenšit"
 ],
 "$0 can not be made larger": [
  null,
  "$0 není možné zvětšit"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Zde není možné měnit velikost fyzických svazků"
 ],
 "Swap can not be resized here": [
  null,
  "Velikost odkládacího prostoru nelze změnit zde"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Nerozpoznaná data zde nelze zmenšit"
 ],
 "Activate before resizing": [
  null,
  "Aktivujte před změnou velikosti"
 ],
 "Grow logical volume": [
  null,
  "Zvětšit logický svazek"
 ],
 "Grow partition": [
  null,
  "Zvětšit oddíl"
 ],
 "grow": [
  null,
  "zvětšit"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Je třeba vybrat přesně $0 fyzických svazků"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Změna velikost šifrovaného souborového systému vyžaduje jeho odemčení. Zadejte heslovou frázi."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Je třeba vybrat přesně $0 fyzických svazků – jeden pro každý z proužků logického svazku."
 ],
 "Shrink logical volume": [
  null,
  "Zmenšit logický svazek"
 ],
 "shrink": [
  null,
  "zmenšit"
 ],
 "Unformatted data": [
  null,
  "Neformátovaná data"
 ],
 "Block device": [
  null,
  "Blokové zařízení"
 ],
 "Device number": [
  null,
  "Číslo zařízení"
 ],
 "Create partition on $0": [
  null,
  "Vytvořit oddíl na $0"
 ],
 "Format $0": [
  null,
  "Naformátovat $0"
 ],
 "No filesystem": [
  null,
  "Žádný souborový systém"
 ],
 "(recommended)": [
  null,
  "(doporučeno)"
 ],
 "No encryption": [
  null,
  "Bez šifrování"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Použít stávající šifrování ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Použít stávající šifrování"
 ],
 "format": [
  null,
  "formátovat"
 ],
 "Format and mount": [
  null,
  "Naformátovat a připojit"
 ],
 "Format only": [
  null,
  "Pouze naformátovat"
 ],
 "Format": [
  null,
  "Formát"
 ],
 "Create and start": [
  null,
  "Vytvořit a spustit"
 ],
 "Format and start": [
  null,
  "Naformátovat a spustit"
 ],
 "Store passphrase": [
  null,
  "Uložit heslovou frázi"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Aby ho bylo možné naformátovat, disk je třeba odemknout. Zadejte stávající heslovou frázi."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formátování vymaže všechna data na úložném zařízení."
 ],
 "Unrecognized data": [
  null,
  "Nerozpoznaná data"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Úložiště není na tomto systému možné spravovat."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bajtů"
 ]
});
