cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ca",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 error",
  "$0 errors"
 ],
 "$0 installation": [
  null,
  "$0 instal·lació"
 ],
 "$0 installer": [
  null,
  "$0 instal·lador"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 és una partició estesa MBR que conté particions lògiques. Eliminar totes les particions lògiques també eliminarà automàticament la partició estesa."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Es requereix $0, però només hi ha $1 disponible."
 ],
 "$0 warning": [
  null,
  "$0 avís",
  "$0 avisos"
 ],
 "$0 will be deleted": [
  null,
  "$0 se suprimirà"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "El sistema de fitxers '$0' no pot estar en un dispositiu de bloc xifrat"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' ha d'estar en un dispositiu amb el format '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "S'ha trobat la partició '$0' al dispositiu MDRAID $1. Les particions del bootloader als dispositius MDRAID no són compatibles."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Un compte d'usuari estàndard amb accés d'administrador per fer canvis a tot el sistema."
 ],
 "About": [
  null,
  "Quant a"
 ],
 "Account": [
  null,
  "Compte"
 ],
 "Actions": [
  null,
  "Accions"
 ],
 "Add another server...": [
  null,
  "Afegeix un altre servidor..."
 ],
 "Add mount": [
  null,
  "Afegeix muntatge"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Complements per a l'entorn que heu triat"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Complements no específics del vostre entorn"
 ],
 "Additional languages": [
  null,
  "Llengües addicionals"
 ],
 "Additional software for the selected environment": [
  null,
  "Programari addicional per a l'entorn seleccionat"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Tots els canvis fets a l'editor d'emmagatzematge tenen efecte immediatament."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Es desbloquejaran tots els dispositius que utilitzin aquesta contrasenya"
 ],
 "Anaconda Web UI": [
  null,
  "Interfície d'usuari web d'Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Pàgina del projecte Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aplica l'assignació del punt de muntatge i instal·la"
 ],
 "Applying changes...": [
  null,
  "Aplicant canvis..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Assigna particions als punts de muntatge. Útil per a disposicions personalitzades preconfigurades."
 ],
 "Automatic log file upload": [
  null,
  "Pujada automàtica de fitxers de registre"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Estableix automàticament la data i l'hora mitjançant servidors de temps"
 ],
 "Automatically set timezone": [
  null,
  "Estableix la zona horària automàticament"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Espai lliure disponible: $0. La instal·lació requereix: $1."
 ],
 "Back": [
  null,
  "Enrere"
 ],
 "Base environment": [
  null,
  "Entorn base"
 ],
 "Brief description of the issue": [
  null,
  "Descripció breu del problema"
 ],
 "Bug report details": [
  null,
  "Detalls de l'informe de l'error"
 ],
 "Bugzilla API key": [
  null,
  "Clau d'API de Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "En continuar utilitzant aquest programari, enteneu i accepteu els riscos associats amb el programari encara no llançat, que teniu la intenció d'utilitzar-lo només amb finalitats de prova i desenvolupament i que esteu disposat a informar qualsevol error o problema per millorar aquest treball."
 ],
 "Cancel": [
  null,
  "Cancel·la"
 ],
 "Change": [
  null,
  "Canvia"
 ],
 "Change destination": [
  null,
  "Canvia destinació"
 ],
 "Change hostname": [
  null,
  "Canvia el nom d'amfitrió"
 ],
 "Change partition layout": [
  null,
  "Canvia la disposició de la partició"
 ],
 "Change system keyboard layout": [
  null,
  "Canvia la disposició del teclat del sistema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Els canvis fets aquí afectaran immediatament el sistema. No hi ha 'desfer'."
 ],
 "Checking installation configuration...": [
  null,
  "Es comprova la configuració de la instal·lació..."
 ],
 "Checking storage configuration": [
  null,
  "S'està comprovant la configuració de l'emmagatzematge"
 ],
 "Clear search": [
  null,
  "Esborrar la cerca"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Torneu a fer clic a 'Següent' per continuar malgrat aquests avisos."
 ],
 "Close": [
  null,
  "Tanca"
 ],
 "Close storage editor": [
  null,
  "Tanca l'editor d'emmagatzematge"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "L'emmagatzematge de la cabina no va proporcionar la contrasenya per desbloquejar el dispositiu xifrat."
 ],
 "Completed": [
  null,
  "Completat"
 ],
 "Configuration is incomplete": [
  null,
  "La configuració no és completa"
 ],
 "Configure NTP servers": [
  null,
  "Configura els servidors NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurar els servidors NTP personalitzats"
 ],
 "Configure network": [
  null,
  "Configura la xarxa"
 ],
 "Configure storage": [
  null,
  "Configura l'emmagatzematge"
 ],
 "Configure storage again": [
  null,
  "Torneu a configurar l'emmagatzematge"
 ],
 "Confirm passphrase": [
  null,
  "Confirmeu la paraula de pas"
 ],
 "Continue": [
  null,
  "Continua"
 ],
 "Continue installation": [
  null,
  "Continueu la instal·lació"
 ],
 "Continue with installation": [
  null,
  "Continueu amb la instal·lació"
 ],
 "Correct these issues before continuing.": [
  null,
  "Corregiu aquests problemes abans de continuar."
 ],
 "Create Account": [
  null,
  "Crea Compte"
 ],
 "Create account": [
  null,
  "Crea un compte"
 ],
 "Currently installed: $0": [
  null,
  "Instal·lat actualment: $0"
 ],
 "Custom": [
  null,
  "Personalitzat"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data i hora"
 ],
 "Delete partition": [
  null,
  "Esborrar la partició"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "La supressió de certes particions pot impedir que $0 arrenqui: $1"
 ],
 "Description": [
  null,
  "Descripció"
 ],
 "Destination": [
  null,
  "Destinació"
 ],
 "Destination is encrypted": [
  null,
  "El destí està xifrat"
 ],
 "Detailed description of the issue": [
  null,
  "Descripció detallada del problema"
 ],
 "Detected valid storage layout:": [
  null,
  "S'ha detectat una disposició d'emmagatzematge vàlida:"
 ],
 "Device": [
  null,
  "Dispositiu"
 ],
 "Duplicate device.": [
  null,
  "Dispositiu duplicat."
 ],
 "Duplicate mount point.": [
  null,
  "Punt de muntatge duplicat."
 ],
 "Enable root account": [
  null,
  "Habilita el compte root"
 ],
 "Encrypt my data": [
  null,
  "Xifra les meves dades"
 ],
 "Encrypted": [
  null,
  "Xifrat"
 ],
 "Encryption": [
  null,
  "Xifratge"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Introdueix la teva clau d'API de Bugzilla per crear un informe d'error. Podràs revisar i editar els detalls de l'error al pas següent."
 ],
 "Environment": [
  null,
  "Entorn"
 ],
 "Erase data and install": [
  null,
  "Esborra les dades i instal·la"
 ],
 "Error details": [
  null,
  "Detalls de l'error"
 ],
 "Exit to live desktop": [
  null,
  "Surt de l'escriptori live"
 ],
 "Extended partition": [
  null,
  "Partició estesa"
 ],
 "Failed to report issue": [
  null,
  "No s'ha pogut informar de l'error"
 ],
 "Failed to save layouts": [
  null,
  "No s'ha pogut desar les disposicions"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux requereix almenys $0 d'espai de disc."
 ],
 "Finalization": [
  null,
  "Finalització"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalitzant: La configuració del sistema s'ha completat. Finalitzar la instal·lació pot trigar uns moments."
 ],
 "Find layout": [
  null,
  "Cerca una disposició"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Per a una millor seguretat, eviteu utilitzar directament el compte root. En comptes d'això, utilitzeu el compte local anterior per gestionar el sistema."
 ],
 "Full name": [
  null,
  "Nom complet"
 ],
 "Full name cannot contain colon characters": [
  null,
  "El nom complet no pot contenir el caràcter dos punts"
 ],
 "Helper text": [
  null,
  "Text d'ajuda"
 ],
 "Hide API key": [
  null,
  "Amaga la clau de l'API"
 ],
 "Hide confirmed password": [
  null,
  "Amaga la contrasenya confirmada"
 ],
 "Hide passphrase": [
  null,
  "Amaga la paraula de pas"
 ],
 "Hide password": [
  null,
  "Oculta la contrasenya"
 ],
 "Hostname": [
  null,
  "Nom d'amfitrió"
 ],
 "How would you like to install?": [
  null,
  "Com t'agradaria instal·lar?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Entenc que totes les dades existents s'esborraran",
  "Entenc que totes les dades existents s'esborraran dels discs seleccionats"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Entenc que s'esborraran algunes dades existents"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Entenc que algunes particions seran modificades"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Si està buit, el nom de l'amfitrió serà transitori i establert per la informació de la xarxa."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Si esteu configurant les particions, cal el següent:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Si no consenteixes la pujada automàtica de fitxers de registre, pots optar per $0 en el seu lloc. El procés manual et permetrà revisar i adjuntar selectivament els fitxers de registre per tu mateix."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Si no enteneu o accepteu els riscos, sortiu d'aquest programa."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "En progrés"
 ],
 "Initializing...": [
  null,
  "Inicialitzant..."
 ],
 "Install": [
  null,
  "_Instal·la"
 ],
 "Installation failed": [
  null,
  "La instal·lació ha fallat"
 ],
 "Installation method": [
  null,
  "Mètode d'instal·lació"
 ],
 "Installation of the system failed": [
  null,
  "La instal·lació del sistema ha fallat"
 ],
 "Installation of the system failed: $0": [
  null,
  "La instal·lació del sistema ha fallat: $0"
 ],
 "Installation type": [
  null,
  "Tipus d'instal·lació"
 ],
 "Installing": [
  null,
  "S'instal·la"
 ],
 "Insufficient disk space": [
  null,
  "Espai en disc insuficient"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "S'ha detectat una configuració de RAID no vàlida. Si la matriu RAID es crea directament sobre els discs, s'ha de crear una taula de particions a la matriu. Si la matriu RAID es crea a sobre de les particions, ha de contenir un únic sistema de fitxers o format (p. ex., LVM PV). Qualsevol partició existent en aquesta matriu s'ignorarà."
 ],
 "Invalid hostname": [
  null,
  "El nom d'amfitrió no és vàlid"
 ],
 "Jump to first incomplete step": [
  null,
  "Ves al primer pas incomplet"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Mantén la disposició actual del disc i utilitza l'espai disponible, per a arrencar amb dual-boot amb un altre sistema operatiu."
 ],
 "Keyboard": [
  null,
  "Teclat"
 ],
 "Keyboard layout during boot": [
  null,
  "Disposició del teclat durant l'arrencada"
 ],
 "Language": [
  null,
  "Idioma"
 ],
 "Launch storage editor": [
  null,
  "Inicieu l'editor d'emmagatzematge"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Conegueu més detalls quant a l'accés restringit en la configuració"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Ubicació"
 ],
 "Locked devices": [
  null,
  "Dispositius bloquejats"
 ],
 "Make current": [
  null,
  "Estableix com a actual"
 ],
 "Manual disk configuration": [
  null,
  "Configuració manual del disc"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuració manual del disc: mapatge de punts de muntatge"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Pot contenir lletres, números i guions."
 ],
 "May need more free space": [
  null,
  "Pot necessitar més espai lliure"
 ],
 "Medium": [
  null,
  "Mitjà"
 ],
 "Minimum of $0 required": [
  null,
  "Cal un mínim de $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "No coincideix el dispositiu pare i la selecció del reformat del dispositiu fill."
 ],
 "Mount point": [
  null,
  "Punt de muntatge"
 ],
 "Mount point assignment": [
  null,
  "Assignació del punt de muntatge"
 ],
 "Move down": [
  null,
  "Moure cap avall"
 ],
 "Move up": [
  null,
  "Moure cap a dalt"
 ],
 "Must be at least $0 characters": [
  null,
  "Ha de tenir com a mínim $0 caràcters"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Servidors NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Needs at least $0": [
  null,
  "Necessita com a mínim $0"
 ],
 "Network": [
  null,
  "Xarxa"
 ],
 "Network Configuration": [
  null,
  "Configuració de Xarxa"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "La xarxa no està disponible. Configureu la xarxa al menú de la barra superior per a informar del problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "La xarxa no està disponible. Configureu la xarxa per informar del problema."
 ],
 "Network plugin failed": [
  null,
  "El connector de xarxa ha fallat"
 ],
 "Next": [
  null,
  "Següent"
 ],
 "No devices": [
  null,
  "Sense dispositius"
 ],
 "No disks available": [
  null,
  "No hi ha discs disponibles"
 ],
 "No disks selected": [
  null,
  "No s'ha seleccionat cap disc"
 ],
 "No layouts selected yet": [
  null,
  "Encara no s'ha seleccionat cap disposició"
 ],
 "No results found": [
  null,
  "No s'han trobat resultats"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "No s'ha pogut obtenir cap mapa de teclat vàlid de VConsole per a la disposició(ns) de teclat seleccionada(es). Seleccioneu una disposició de teclat diferent."
 ],
 "Not enough available free space": [
  null,
  "No hi ha prou espai lliure disponible"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "No hi ha prou espai lliure als discs seleccionats."
 ],
 "Not enough space on selected disks.": [
  null,
  "No hi ha prou espai als discs seleccionats."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Avís: Aquest és un programari encara no publicat que està destinat només a propòsits de desenvolupament i proves. No utilitzeu aquest programari per a cap treball crític ni per a entorns de producció."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Obrir el formulari d'entrada d'errors de Bugzilla"
 ],
 "Operating system": [
  null,
  "Sistema operatiu"
 ],
 "Options": [
  null,
  "Opcions"
 ],
 "Other keyboards": [
  null,
  "Altres teclats"
 ],
 "Partitions (advanced)": [
  null,
  "Particions (avançat)"
 ],
 "Passphrase": [
  null,
  "Contrasenya"
 ],
 "Passphrase did not match any locked device": [
  null,
  "La contrasenya no coincideix amb cap dispositiu bloquejat"
 ],
 "Passphrases must match": [
  null,
  "Les contrasenyes han de coincidir"
 ],
 "Pending": [
  null,
  "Pendent"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Adjunteu el fitxer de registre $0 al problema."
 ],
 "Please select at least one disk to continue": [
  null,
  "Seleccioneu almenys un disc per continuar"
 ],
 "Pool": [
  null,
  "Agrupament"
 ],
 "Powered by Anaconda": [
  null,
  "Impulsat per Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-llançament"
 ],
 "Prefer to report manually? $0": [
  null,
  "Prefereixes informar manualment? $0"
 ],
 "Proceed with installation": [
  null,
  "Continueu amb la instal·lació"
 ],
 "Quit": [
  null,
  "Surt"
 ],
 "Quit installer?": [
  null,
  "Sortir de l'instal·lador?"
 ],
 "Reading information about the OS failed.": [
  null,
  "No s'ha pogut llegir la informació sobre el sistema operatiu."
 ],
 "Reading information about the computer failed.": [
  null,
  "Ha fallat la lectura de la informació sobre l'ordinador."
 ],
 "Reading installer configuration failed.": [
  null,
  "No s'ha pogut llegir la configuració de l'instal·lador."
 ],
 "Reading installer version information failed.": [
  null,
  "No s'ha pogut llegir la informació de la versió de l'instal·lador."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "El nom real de l'amfitrió només pot contenir caràcters, dígits, guions (no iniciar o acabar un caràcter) i punts"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "El nom d'amfitrió real ha de tenir 64 caràcters o menys"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reinicieu a Windows per canviar la mida de les particions encriptades amb BitLocker. Oferiu com a mínim $0 d'espai lliure disponible per a la instal·lació."
 ],
 "Reboot system?": [
  null,
  "Reiniciar el sistema?"
 ],
 "Reclaim additional space": [
  null,
  "Recupera espai addicional"
 ],
 "Reclaim space": [
  null,
  "Recuperar espai"
 ],
 "Reclaim space (required)": [
  null,
  "Reclama l'espai (obligatori)"
 ],
 "Recommended": [
  null,
  "Recomanat"
 ],
 "Recommended partitions:": [
  null,
  "Particions recomanades:"
 ],
 "Reformat": [
  null,
  "Torna a formatar"
 ],
 "Reinstall Fedora": [
  null,
  "Torneu a instal·lar Fedora"
 ],
 "Remove": [
  null,
  "Suprimeix"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Elimina totes les particions dels dispositius seleccionats, inclosos els sistemes operatius existents."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Traieu o canvieu la mida dels sistemes de fitxers existents per alliberar espai per a la instal·lació."
 ],
 "Remove server": [
  null,
  "Suprimeix el servidor"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "La supressió d'un sistema de fitxers suprimirà permanentment totes les dades que conté. Canviar la mida d'una partició pot alliberar espai no utilitzat, però no està exempt de riscos. Assegureu-vos de tenir còpies de seguretat de qualsevol cosa important abans de recuperar espai."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Reemplaça la instal·lació actual, però manté els fitxers de /home."
 ],
 "Report Issue": [
  null,
  "Informa d'un Problema"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Informar d'un problema o proporcionar comentaris obrint el formulari d'entrada d'error de Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Informa d'un problema"
 ],
 "Reporting issue...": [
  null,
  "Informant del problema..."
 ],
 "Required": [
  null,
  "Obligatori"
 ],
 "Requirements": [
  null,
  "Requisits"
 ],
 "Rescan devices": [
  null,
  "Re-escaneja els dispositius"
 ],
 "Rescanning of the disks failed.": [
  null,
  "No s'ha pogut tornar a escanejar els discs."
 ],
 "Resize": [
  null,
  "Redimensiona"
 ],
 "Resize partition": [
  null,
  "Redimensionar la partició"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "S'estan redimensionant les particions següents des de $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Restringeix l'accés a aquest informe"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Restringeix l'informe al grup $0. $1"
 ],
 "Return to installation": [
  null,
  "Tornar a la instal·lació"
 ],
 "Return to storage editor": [
  null,
  "Torna a l'editor d'emmagatzematge"
 ],
 "Review and install": [
  null,
  "Revisar i instal·lar"
 ],
 "Root account is enabled": [
  null,
  "El compte root està habilitat"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "El compte root està habilitat, però no s'ha configurat cap compte d'usuari"
 ],
 "Root password has been set.": [
  null,
  "La contrasenya de root ha estat establerta."
 ],
 "Save": [
  null,
  "Desa"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Escaneja el codi QR amb el teu telèfon o visita:"
 ],
 "Search for a language": [
  null,
  "Cerca un idioma"
 ],
 "Search for additional software": [
  null,
  "Cerca de programari addicional"
 ],
 "Search for an environment": [
  null,
  "Cerca un entorn"
 ],
 "Search keyboard layout": [
  null,
  "Cerca la disposició del teclat"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Protegiu les vostres dades mitjançant el xifratge basat en el disc. Només s'aplica a les particions noves"
 ],
 "Select": [
  null,
  "Selecciona"
 ],
 "Select a device": [
  null,
  "Seleccioneu un dispositiu"
 ],
 "Select city": [
  null,
  "Selecciona la ciutat"
 ],
 "Select destination": [
  null,
  "Seleccioneu la destinació"
 ],
 "Select region": [
  null,
  "Selecciona la regió"
 ],
 "Selected (top = current)": [
  null,
  "Seleccionat (superior = actual)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "El format '$0' del dispositiu seleccionat no es pot reformatejar."
 ],
 "Send us feedback on your installation": [
  null,
  "Envieu-nos comentaris sobre la vostra instal·lació"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server is not reachable": [
  null,
  "El servidor no és accessible"
 ],
 "Set custom hostname": [
  null,
  "Estableix un nom d'amfitrió personalitzat"
 ],
 "Share disk with other operating systems": [
  null,
  "Comparteix el disc amb altres sistemes operatius"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Comparteix el disc amb altres sistemes operatius: $0"
 ],
 "Show AM/PM": [
  null,
  "Mostra AM/PM"
 ],
 "Show API key": [
  null,
  "Mostra la clau de l'API"
 ],
 "Show confirmed password": [
  null,
  "Mostra la contrasenya confirmada"
 ],
 "Show passphrase": [
  null,
  "Mostra la paraula de pas"
 ],
 "Show password": [
  null,
  "Mostra la contrasenya"
 ],
 "Size": [
  null,
  "Mida"
 ],
 "Software installation": [
  null,
  "Instal·lació de programari"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instal·lació de programari: s'ha completat la configuració de l'emmagatzematge. El programari s'instal·la al dispositiu."
 ],
 "Software selection": [
  null,
  "Selecció de programari"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Encara cal completar alguns passos d'instal·lació abans de poder continuar."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Falten algunes particions necessàries: $0"
 ],
 "Space": [
  null,
  "Espai"
 ],
 "Stacktrace": [
  null,
  "Traça d'errors (Stacktrace)"
 ],
 "Storage": [
  null,
  "Emmagatzematge"
 ],
 "Storage configuration": [
  null,
  "Configuració d'emmagatzematge"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuració d'emmagatzematge: L'emmagatzematge s'està configurant actualment."
 ],
 "Storage editor": [
  null,
  "Editor d'emmagatzematge"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "L'emmagatzematge es basa en la configuració de 'Modifica l'emmagatzematge'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "La disposició de l’emmagatzematge està definida pel fitxer kickstart. Es pot revisar la disposició de particions planificada en el pas de resum."
 ],
 "Storage plugin failed": [
  null,
  "El connector d'emmagatzematge ha fallat"
 ],
 "Storage requirements not met": [
  null,
  "No s'han complert els requisits d'emmagatzematge"
 ],
 "Strong": [
  null,
  "Forta"
 ],
 "Successfully installed": [
  null,
  "S'ha instal·lat correctament"
 ],
 "Successfully unlocked $0.": [
  null,
  "S'ha desbloquejat $0 correctament."
 ],
 "Suggested keyboards": [
  null,
  "Teclats suggerits"
 ],
 "Suggested languages": [
  null,
  "Llengües suggerides"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Configuració del sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuració del sistema: Instal·lació del programari completada. Ara s'està configurant el sistema."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "La instal·lació d'Anaconda s'ha aturat inesperadament."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Es crearà el següent usuari:",
  "Es crearan els següents usuaris:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "La instal·lació necessita $0 d'espai de disc; tanmateix, la capacitat dels discs seleccionats és de només $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "L'instal·lador no pot continuar a causa d'un error crític."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "L'instal·lador no pot continuar a causa d'un error crític: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "La contrasenya que heu proporcionat conté caràcters que no són ASCII. Pot ser que no pugueu commutar entre disposicions de teclat quan la teclegeu."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "La disposició de teclat predeterminada seleccionada no admet caràcters ASCII. Trieu una disposició compatible amb ASCII com a predeterminada."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "L'editor d'emmagatzematge us permet canviar la mida, suprimir i crear particions. Pot configurar LVM i molt més. Està pensat com una utilitat avançada i no per ser utilitzat en una instal·lació típica."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Aquests fitxers de registre poden contenir informació sensible com adreces IP, noms d'usuari o altres detalls del sistema."
 ],
 "This hostname can't be submitted": [
  null,
  "Aquest nom d'amfitrió no es pot enviar"
 ],
 "This is unstable, pre-release software": [
  null,
  "Aquesta és una versió de programari inestable i prèvia al llançament"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Aquesta disposició s'utilitzarà per desblocar el sistema a l'arrencada"
 ],
 "This may take a moment": [
  null,
  "Això pot trigar una estona"
 ],
 "This will take a few moments": [
  null,
  "Això trigarà uns instants"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Timezone": [
  null,
  "Zona horària"
 ],
 "Title": [
  null,
  "Títol"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Per començar a utilitzar $0, reinicieu el sistema."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Per continuar, seleccioneu els dispositius on voleu instal·lar-lo."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Per a utilitzar aquesta opció, redimensioneu o suprimiu les particions existents per a alliberar almenys $0."
 ],
 "Type": [
  null,
  "Tipus"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "No s'ha pogut programar la supressió de $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "No s'ha pogut programar el canvi de mida de $0"
 ],
 "Undo last action": [
  null,
  "Desfés l'última acció"
 ],
 "Unlock": [
  null,
  "Desbloqueja"
 ],
 "Unlock encrypted devices": [
  null,
  "Desbloquejar dispositius xifrats"
 ],
 "Use configured storage": [
  null,
  "Utilitzeu l'emmagatzematge configurat"
 ],
 "Use entire disk": [
  null,
  "Utilitzeu el disc sencer"
 ],
 "Use free space": [
  null,
  "Usa l'espai lliure"
 ],
 "Use local account": [
  null,
  "Utilitza un compte local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Usa el dispositiu RAID per a les particions automàtiques"
 ],
 "User creation": [
  null,
  "Creació d'usuari"
 ],
 "User name": [
  null,
  "Nom d'usuari"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "El nom d'usuari només pot contenir: lletres d'a-z, dígits 0-9, guió $0, punt $1, guió baix $2"
 ],
 "User name must not be a reserved word": [
  null,
  "El nom d'usuari no ha de ser una paraula reservada"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Els noms d'usuari han de tenir menys de 33 caràcters"
 ],
 "Validating...": [
  null,
  "Validant..."
 ],
 "Weak": [
  null,
  "Feble"
 ],
 "Welcome": [
  null,
  "Benvinguts"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Benvingut a Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Benvinguts. Instal·lem $0 ara."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Quan enviïs aquest informe d'error, els següents fitxers de registre seran pujats automàticament: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "No es poden redimensionar les particions de Windows amb xifratge BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Podeu alliberar prou espai aquí i deixar que l'instal·lador gestioni la resta o configurar manualment les particions."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Pots generar la clau d'API per al teu compte de Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Heu d'habilitar el compte root o crear un compte d'usuari local per continuar."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Heu d'estar connectat a una xarxa per activar la data i l'hora automàtiques."
 ],
 "Your progress will not be saved.": [
  null,
  "El vostre progrés no es desarà."
 ],
 "completed step": [
  null,
  "pas completat"
 ],
 "current step": [
  null,
  "pas actual"
 ],
 "delete": [
  null,
  "suprimeix"
 ],
 "edit": [
  null,
  "edita"
 ],
 "encrypt": [
  null,
  "xifra"
 ],
 "encrypted": [
  null,
  "xifrat"
 ],
 "extended partition": [
  null,
  "Partició estesa"
 ],
 "format as $0": [
  null,
  "format com a $0"
 ],
 "here": [
  null,
  "aquí"
 ],
 "incomplete": [
  null,
  "incomplet"
 ],
 "mount": [
  null,
  "munta"
 ],
 "pending step": [
  null,
  "pas pendent"
 ],
 "report the issue manually": [
  null,
  "informar manualment del problema"
 ],
 "resized from $0": [
  null,
  "redimensionat des de $0"
 ],
 "shrink": [
  null,
  "encongeix"
 ],
 "shrink to $0": [
  null,
  "encongeix a $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "desfer"
 ]
});
