cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "ຄີທີ່ປ່ຽນແປງມັກຈະເກີດຈາກການຕິດຕັ້ງລະບົບປະຕິບັດການໃໝ່. ຢ່າງໃດກໍຕາມ, ການປ່ຽນແປງທີ່ບໍ່ຄາດຄິດອາດໝາຍເຖິງການພະຍາຍາມແຊກແຊງການເຊື່ອມຕໍ່ຂອງທ່ານຈາກບຸກຄົນທີສາມ."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "ເພື່ອໃຫ້ແນ່ໃຈວ່າການເຊື່ອມຕໍ່ຂອງທ່ານບໍ່ຖືກດັກຟັງໂດຍບຸກຄົນທີສາມ, ກະລຸນາກວດສອບລາຍນິ້ວມືຂອງຄີໂຮສຕ໌:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ."
 ],
 "Password": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "Log in": [
  null,
  "ເຂົ້າສູ່ລະບົບ"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Server": [
  null,
  "ເຊີເວີ"
 ],
 "Services": [
  null,
  "ບັນດາບໍລິການ"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Firewall": [
  null,
  "ໄຟວໍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Copy": [
  null,
  "ກັອບປີ້"
 ],
 "Copied": [
  null,
  "ກັອບປີ້ແລ້ວ"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Details": [
  null,
  "ລາຍລະອຽດ"
 ],
 "Public key": [
  null,
  "ຄີສາທາລະນະ (Public key)"
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Select": [
  null,
  "ເລືອກ"
 ],
 "Unexpected error": [
  null,
  "ເກີດຂໍ້ຜິດພາດທີ່ບໍ່ຄາດຄິດ"
 ],
 "No results found": [
  null,
  "ບໍ່ພົບຜົນລັບ"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "ເວີຊັນຂອງ Cockpit ທີ່ເຂົ້າກັນໄດ້ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນ $0."
 ],
 "Connect": [
  null,
  "ເຊື່ອມຕໍ່"
 ],
 "Add": [
  null,
  "ເພີ່ມ"
 ],
 "$0 key changed": [
  null,
  "ຄີ $0 ປ່ຽນແປງແລ້ວ"
 ],
 "Trust and add host": [
  null,
  "ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ເພື່ອການກວດສອບລາຍນິ້ວມື, ໃຫ້ຮັນຄຳສັ່ງຕໍ່ໄປນີ້ໃນ $0 ໃນຂະນະທີ່ຢູ່ໜ້າເຄື່ອງ ຫຼື ຜ່ານເຄືອຂ່າຍທີ່ໜ້າເຊື່ອຖື:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "ຖ້າລາຍນິ້ວມືກົງກັນ, ກົດ 'ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌'. ຖ້າບໍ່ດັ່ງນັ້ນ, ຫ້າມເຊື່ອມຕໍ່ ແລະ ຕິດຕໍ່ຜູ້ດູແລລະບົບຂອງເຈົ້າ."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "ລາຍນິ້ວມືທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ. ຖ້າທ່ານໃຫ້ຄົນອື່ນກວດສອບໃຫ້, ເຂົາເຈົ້າສາມາດສົ່ງຜົນການກວດສອບໃຫ້ທ່ານດ້ວຍວິທີໃດກໍໄດ້."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "ທ່ານກຳລັງເຊື່ອມຕໍ່ຫາ $0 ເປັນຄັ້ງທຳອິດ."
 ],
 "Verify fingerprint": [
  null,
  "ກວດສອບລາຍນິ້ວມື"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "ຣັນຄຳສັ່ງນີ້ຜ່ານເຄືອຂ່າຍທີ່ເຊື່ອຖືໄດ້ ຫຼື ຣັນຢູ່ເຄື່ອງປາຍທາງໂດຍກົງ:"
 ],
 "The fingerprint should match:": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ຄວນຈະກົງກັບ:"
 ],
 "The password can not be empty": [
  null,
  "ລະຫັດຜ່ານບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key password can not be empty": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key passwords do not match": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ກົງກັນ"
 ],
 "Log in to $0": [
  null,
  "ເຂົ້າສູ່ລະບົບ $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ໄດ້. ໂຮສຕ໌ບໍ່ຍອມຮັບການເຂົ້າລະບົບດ້ວຍລະຫັດຜ່ານ ຫຼື ຄີ SSH ໃດໆຂອງທ່ານ."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ແມ່ນຖືກປ້ອງກັນດ້ວຍລະຫັດຜ່ານ, ແລະ ໂຮສຕ໌ບໍ່ອະນຸຍາດໃຫ້ເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານ. ກະລຸນາລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ຖືກປ້ອງກັນໄວ້. ທ່ານສາມາດເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານຂອງທ່ານ ຫຼື ລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ສ້າງ SSH ຄີໃໝ່ ແລະ ອະນຸຍາດມັນ"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "SSH ຄີໃໝ່ຢູ່ $0 ຈະຖືກສ້າງຂຶ້ນສຳລັບ $1 ຢູ່ $2 ແລະ ມັນຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Key password": [
  null,
  "ລະຫັດຜ່ານຄີ"
 ],
 "Confirm key password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານຂອງຄີ"
 ],
 "Authorize SSH key": [
  null,
  "ອະນຸຍາດ SSH ຄີ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "ຄີ SSH $0 ຂອງ $1 ຢູ່ $2 ຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Authentication": [
  null,
  "ການຢືນຢັນຕົວຕົນ"
 ],
 "SSH key": [
  null,
  "ຄີ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "ຄີ SSH $0 ຈະສາມາດໃຊ້ໄດ້ຕະຫຼອດວາລະການໃຊ້ງານທີ່ເຫຼືອ ແລະ ຈະສາມາດໃຊ້ເຂົ້າສູ່ລະບົບໂຮສຕ໌ອື່ນໆໄດ້ຄືກັນ."
 ],
 "Disconnected": [
  null,
  "ຕັດການເຊື່ອມຕໍ່ແລ້ວ"
 ],
 "Permission denied": [
  null,
  "ການອະນຸຍາດຖືກປະຕິເສດ"
 ],
 "Clear input value": [
  null,
  "ລຶບຄ່າທີ່ປ້ອນເຂົ້າ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "ຮູບແບບວັນທີ ແລະ ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid time format": [
  null,
  "ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid date format": [
  null,
  "ຮູບແບບວັນທີບໍ່ຖືກຕ້ອງ"
 ],
 "Cannot schedule event in the past": [
  null,
  "ບໍ່ສາມາດຕັ້ງເວລາໃນອະດີດໄດ້"
 ],
 "No delay": [
  null,
  "ບໍ່ມີການຊັກຊ້າ"
 ],
 "1 minute": [
  null,
  "1 ນາທີ"
 ],
 "5 minutes": [
  null,
  "5 ນາທີ"
 ],
 "20 minutes": [
  null,
  "20 ນາທີ"
 ],
 "40 minutes": [
  null,
  "40 ນາທີ"
 ],
 "60 minutes": [
  null,
  "60 ນາທີ"
 ],
 "Specific time": [
  null,
  "ເວລາສະເພາະ"
 ],
 "Shut down": [
  null,
  "ປິດເຄື່ອງ"
 ],
 "Reboot": [
  null,
  "ບູດເຄື່ອງໃໝ່"
 ],
 "Message to logged in users": [
  null,
  "ຂໍ້ຄວາມເຖິງຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບຢູ່"
 ],
 "Delay": [
  null,
  "ການໜ່ວງເວລາ"
 ],
 "Pick date": [
  null,
  "ເລືອກວັນທີ"
 ],
 "Toggle date picker": [
  null,
  "ເປີດ-ປິດ ຕົວເລືອກວັນທີ"
 ],
 "Synchronized": [
  null,
  "ຊິງໂຄຣໄນຊ໌ແລ້ວ"
 ],
 "Synchronized with $0": [
  null,
  "ຊິງໂຄຣໄນຊ໌ກັບ $0 ແລ້ວ"
 ],
 "Synchronizing": [
  null,
  "ກຳລັງຊິງໂຄຣໄນຊ໌"
 ],
 "Trying to synchronize with $0": [
  null,
  "ກຳລັງພະຍາຍາມຊິງໂຄຣໄນຊ໌ກັບ $0"
 ],
 "Not synchronized": [
  null,
  "ບໍ່ໄດ້ຊິງໂຄຣໄນຊ໌"
 ],
 "Log messages": [
  null,
  "ຂໍ້ຄວາມລັອກ"
 ],
 "NTP server": [
  null,
  "ເຊີບເວີ NTP"
 ],
 "Manually": [
  null,
  "ດ້ວຍຕົນເອງ"
 ],
 "Automatically using NTP": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍ NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ເພີ່ມເຕີມ"
 ],
 "Automatically using specific NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ທີ່ລະບຸ"
 ],
 "Time zone": [
  null,
  "ເຂດເວລາ"
 ],
 "Set time": [
  null,
  "ຕັ້ງເວລາ"
 ],
 "Invalid timezone": [
  null,
  "ເຂດເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Need at least one NTP server": [
  null,
  "ຕ້ອງການເຊີບເວີ NTP ຢ່າງໜ້ອຍໜຶ່ງຕົວ"
 ],
 "Change system time": [
  null,
  "ປ່ຽນເວລາຂອງລະບົບ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Path to file": [
  null,
  "ເສັ້ນທາງໄປຫາໄຟລ໌"
 ],
 "No such file or directory": [
  null,
  "ບໍ່ມີໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີນີ້"
 ],
 "Create $0": [
  null,
  "ສ້າງ $0"
 ],
 "Ok": [
  null,
  "ຕົກລົງ"
 ],
 "Learn more": [
  null,
  "ຮຽນຮູ້ເພີ່ມເຕີມ"
 ],
 "You now have administrative access.": [
  null,
  "ດຽວນີ້ທ່ານມີສິດເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບແລ້ວ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ບໍ່ມີວິທີການເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ກະລຸນາຢືນຢັນຕົວຕົນເພື່ອເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ"
 ],
 "Switch to administrative access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "Authenticate": [
  null,
  "ຢືນຢັນຕົວຕົນ"
 ],
 "Administrative access": [
  null,
  "ສິດການບໍລິຫານ"
 ],
 "Problem becoming administrator": [
  null,
  "ມີບັນຫາໃນການກາຍເປັນຜູ້ດູແລລະບົບ"
 ],
 "Method": [
  null,
  "ວິທີການ"
 ],
 "Limit access": [
  null,
  "ຈຳກັດການເຂົ້າເຖິງ"
 ],
 "Switch to limited access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "ໂໝດການເຂົ້າເຖິງແບບຈຳກັດຈະຈຳກັດສິດຜູ້ດູແລລະບົບ. ບາງສ່ວນຂອງເວັບຄອນໂຊນຈະມີຟັງຊັນການເຮັດວຽກທີ່ຫຼຸດລົງ."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ບຣາວເຊີຂອງທ່ານຈະຈົດຈຳລະດັບການເຂົ້າເຖິງຂອງທ່ານໄວ້."
 ],
 "Limited access": [
  null,
  "ການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Turn on administrative access": [
  null,
  "ເປີດການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "$0 year": [
  null,
  "$0 ປີ"
 ],
 "$0 month": [
  null,
  "$0 ເດືອນ"
 ],
 "$0 week": [
  null,
  "$0 ອາທິດ"
 ],
 "$0 day": [
  null,
  "$0 ມື້"
 ],
 "$0 hour": [
  null,
  "$0 ຊົ່ວໂມງ"
 ],
 "$0 minute": [
  null,
  "$0 ນາທີ"
 ],
 "Go to now": [
  null,
  "ໄປທີ່ປັດຈຸບັນ"
 ],
 "1 hour": [
  null,
  "1 ຊົ່ວໂມງ"
 ],
 "6 hours": [
  null,
  "6 ຊົ່ວໂມງ"
 ],
 "1 day": [
  null,
  "1 ມື້"
 ],
 "1 week": [
  null,
  "1 ອາທິດ"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານ $0 ໃນ firewalld ໄດ້"
 ],
 "Visit firewall": [
  null,
  "ໄປທີ່ໄຟວໍ"
 ],
 "Zone": [
  null,
  "ໂຊນ"
 ],
 "Add $0": [
  null,
  "ເພີ່ມ $0"
 ],
 "less than a minute ago": [
  null,
  "ບໍ່ຮອດໜຶ່ງນາທີກ່ອນ"
 ],
 "in less than a minute": [
  null,
  "ພາຍໃນບໍ່ຮອດໜຶ່ງນາທີ"
 ],
 "Password is too weak": [
  null,
  "ລະຫັດຜ່ານອ່ອນເກີນໄປ"
 ],
 "Excellent password": [
  null,
  "ລະຫັດຜ່ານດີເລີດ"
 ],
 "Password is not acceptable": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Strong password": [
  null,
  "ລະຫັດຜ່ານທີ່ແຂງແຮງ"
 ],
 "Acceptable password": [
  null,
  "ລະຫັດຜ່ານທີ່ຍອມຮັບໄດ້"
 ],
 "Weak password": [
  null,
  "ລະຫັດຜ່ານທີ່ບໍ່ປອດໄພ"
 ],
 "Show password": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Hide password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "password quality": [
  null,
  "ຄຸນນະພາບລະຫັດຜ່ານ"
 ],
 "Show confirmation password": [
  null,
  "ສະແດງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Hide confirmation password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Additional packages:": [
  null,
  "ແພັກເກດເພີ່ມເຕີມ:"
 ],
 "Removals:": [
  null,
  "ການລຶບອອກ:"
 ],
 "Total size: $0": [
  null,
  "ຂະໜາດທັງໝົດ: $0"
 ],
 "Install software": [
  null,
  "ຕິດຕັ້ງຊອບແວ"
 ],
 "$0 will be installed.": [
  null,
  "$0 ຈະຖືກຕິດຕັ້ງ."
 ],
 "Install": [
  null,
  "ຕິດຕັ້ງ"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ກຳລັງລໍຖ້າໃຫ້ການຈັດການຊອບແວອື່ນໆເຮັດວຽກໃຫ້ສຳເລັດ"
 ],
 "Checking installed software": [
  null,
  "ກຳລັງກວດສອບຊອບແວທີ່ຕິດຕັ້ງແລ້ວ"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ບໍ່ມີໃຫ້ໃຊ້ຈາກຄັງຊອບແວໃດໆ."
 ],
 "Downloading $0": [
  null,
  "ກຳລັງດາວໂຫຼດ $0"
 ],
 "Removing $0": [
  null,
  "ກຳລັງລຶບ $0 ອອກ"
 ],
 "Installing $0": [
  null,
  "ກຳລັງຕິດຕັ້ງ $0"
 ],
 "Unknown host: $0": [
  null,
  "ບໍ່ຮູ້ຈັກໂຮສຕ໌: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ດ້ວຍການຢືນຢັນຄີ SSH ໄດ້. ກະລຸນາລະບຸລະຫັດຜ່ານ."
 ],
 "SSH key login": [
  null,
  "ການເຂົ້າສູ່ລະບົບດ້ວຍຄີ SSH"
 ],
 "[no data]": [
  null,
  "[ບໍ່ມີຂໍ້ມູນ]"
 ],
 "[binary data]": [
  null,
  "[ຂໍ້ມູນໄບນາຣີ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ຂັດຂ້ອງ"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ລາຍງານລະຫັດຄວາມຜິດພາດ $0"
 ],
 "show less": [
  null,
  "ສະແດງໜ້ອຍລົງ"
 ],
 "show more": [
  null,
  "ສະແດງເພີ່ມເຕີມ"
 ],
 "Row expansion": [
  null,
  "ການຂະຫຍາຍແຖວ"
 ],
 "Row select": [
  null,
  "ເລືອກແຖວ"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ວາງ (Paste)"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ເກີດຄວາມຜິດພາດໃນການວາງ"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "ບຣາວເຊີຂອງທ່ານບໍ່ອະນຸຍາດໃຫ້ວາງຂໍ້ມູນຈາກເມນູຄລິກຂວາ. ທ່ານສາມາດໃຊ້ Shift+Insert ແທນ."
 ],
 "Error during initialization": [
  null,
  "ເກີດຂໍ້ຜິດພາດລະຫວ່າງການເລີ່ມຕົ້ນ"
 ],
 "Failed": [
  null,
  "ຫຼົ້ມເຫຼວ"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "ພິມເພື່ອທອງ"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "ບໍ່ພົບຜົນລັບທີ່ກົງກັນ"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "ກັອບປີ້ໄວ້ໃນຄລິບບອດ"
 ],
 "Automation script": [
  null,
  "ສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ສ້າງໄຟລ໌ວຽກໃໝ່ດ້ວຍເນື້ອຫານີ້."
 ],
 "Ansible roles documentation": [
  null,
  "ເອກະສານ Ansible roles"
 ],
 "Shell script": [
  null,
  "ສະຄຣິບເຊວ"
 ],
 "No system modifications": [
  null,
  "ບໍ່ມີການແກ້ໄຂລະບົບ"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເບິ່ງການປ່ຽນແປງລະບົບ"
 ],
 "Loading system modifications...": [
  null,
  "ກຳລັງໂຫຼດການປ່ຽນແປງຂອງລະບົບ..."
 ],
 "View automation script": [
  null,
  "ເບິ່ງສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Occurrences": [
  null,
  "ຈຳນວນການເກີດຂຶ້ນ"
 ],
 "View all logs": [
  null,
  "ເບິ່ງບັນທຶກທັງໝົດ"
 ],
 "Other": [
  null,
  "ອື່ນໆ"
 ],
 "Unknown": [
  null,
  "ບໍ່ຮູ້ຈັກ"
 ],
 "Desktop": [
  null,
  "ເດດທອບ"
 ],
 "Low profile desktop": [
  null,
  "Low profile desktop"
 ],
 "Pizza box": [
  null,
  "ພິດຊ່າບັອກ (Pizza box)"
 ],
 "Mini tower": [
  null,
  "ມິນິທາວເວີ (Mini tower)"
 ],
 "Tower": [
  null,
  "ທາວເວີ (Tower)"
 ],
 "Portable": [
  null,
  "ພົກພາໄດ້"
 ],
 "Laptop": [
  null,
  "ແລັບທອບ"
 ],
 "Notebook": [
  null,
  "ໂນ້ດບຸກ"
 ],
 "Handheld": [
  null,
  "ອຸປະກອນພົກພາ"
 ],
 "Docking station": [
  null,
  "ດັອກກິງສະເຕຊັນ"
 ],
 "All-in-one": [
  null,
  "ທັງໝົດໃນອັນດຽວ"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "ຄອມພິວເຕີແບບປະຢັດພື້ນທີ່"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Main server chassis"
 ],
 "Expansion chassis": [
  null,
  "Expansion chassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus expansion chassis"
 ],
 "Peripheral chassis": [
  null,
  "ໂຄງເຄື່ອງອຸປະກອນຕໍ່ພ່ວງ"
 ],
 "RAID chassis": [
  null,
  "ໂຄງເຄື່ອງ RAID"
 ],
 "Rack mount chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຕິດຕັ້ງໃນແຣັກ"
 ],
 "Sealed-case PC": [
  null,
  "ພີຊີແບບກ່ອງປິດ (Sealed-case PC)"
 ],
 "Multi-system chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຫຼາຍລະບົບ"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade enclosure"
 ],
 "Tablet": [
  null,
  "ແທັບເລັດ"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "ຖອດອອກໄດ້"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ຄອມພິວເຕີຝັງຕົວ"
 ],
 "Mini PC": [
  null,
  "ມິນິພີຊີ (Mini PC)"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "ບໍ່ມີຢູ່"
 ],
 "Present": [
  null,
  "ມີຢູ່"
 ],
 "Old password not accepted": [
  null,
  "ລະຫັດຜ່ານເກົ່າບໍ່ຖືກຍອມຮັບ"
 ],
 "Failed to change password": [
  null,
  "ບໍ່ສາມາດປ່ຽນລະຫັດຜ່ານໄດ້"
 ],
 "New password was not accepted": [
  null,
  "ລະຫັດຜ່ານໃໝ່ບໍ່ຖືກຍອມຮັບ"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ການຖາມຜ່ານ ssh-keygen ໝົດເວລາ"
 ],
 "Not a valid private key": [
  null,
  "ບໍ່ແມ່ນໄພຣເວດຄີ (private key) ທີ່ຖືກຕ້ອງ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ການຖາມຜ່ານ ssh-add ໝົດເວລາ"
 ],
 "Invalid file permissions": [
  null,
  "ການອະນຸຍາດໄຟລ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Password not accepted": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Select an option": [
  null,
  "ເລືອກຕົວເລືອກ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 ຖືກຢຸດດ້ວຍສັນຍານ $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 ອອກດ້ວຍລະຫັດ $1"
 ],
 "$0 failed": [
  null,
  "$0 ຫຼົ້ມເຫຼວ"
 ],
 "Your session has been terminated.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານຖືກສິ້ນສຸດແລ້ວ."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານໝົດອາຍຸແລ້ວ. ກະລຸນາເຂົ້າສູ່ລະບົບໃໝ່."
 ],
 "Not permitted to perform this action.": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຮັດການນີ້."
 ],
 "Login failed": [
  null,
  "ເຂົ້າສູ່ລະບົບບໍ່ສຳເລັດ"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "ເຊີເວີປະຕິເສດການຢືນຢັນຕົວຕົນດ້ວຍທຸກວິທີທີ່ຮອງຮັບ."
 ],
 "Untrusted host": [
  null,
  "ໂຮສຕ໌ທີ່ບໍ່ໜ້າເຊື່ອຖື"
 ],
 "Host key is incorrect": [
  null,
  "ຄີຂອງໂຮສຕ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Internal error": [
  null,
  "ຂໍ້ຜິດພາດພາຍໃນ"
 ],
 "Connection has timed out.": [
  null,
  "ການເຊື່ອມຕໍ່ໝົດເວລາ."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນລະບົບ."
 ],
 "Cannot forward login credentials": [
  null,
  "ບໍ່ສາມາດສົ່ງຕໍ່ຂໍ້ມູນການເຂົ້າລະບົບໄດ້"
 ],
 "Server has closed the connection.": [
  null,
  "ເຊີເວີໄດ້ປິດການເຊື່ອມຕໍ່ແລ້ວ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ບໍ່ເຂົ້າກັນໄດ້ກັບຊອບແວໃນລະບົບ."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ບໍ່ສາມາດຕິດຕໍ່ກັບໂຮສຕ໌ທີ່ລະບຸໄດ້."
 ],
 "Too much data": [
  null,
  "ຂໍ້ມູນຫຼາຍເກີນໄປ"
 ],
 "Priority": [
  null,
  "ບຸລິມະສິດ"
 ],
 "Description": [
  null,
  "ຄຳອະທິບາຍ"
 ],
 "Save": [
  null,
  "ບັນທຶກ"
 ],
 "edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "None": [
  null,
  "ບໍ່ມີ"
 ],
 "Enabled": [
  null,
  "ເປີດໃຊ້ງານແລ້ວ"
 ],
 "Disabled": [
  null,
  "ປິດໃຊ້ງານແລ້ວ"
 ],
 "Generated": [
  null,
  "ຖືກສ້າງຂຶ້ນແລ້ວ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "ລຶບ"
 ],
 "Start service": [
  null,
  "ເລີ່ມບໍລິການ"
 ],
 "Status": [
  null,
  "ສະຖານະ"
 ],
 "Delete $0": [
  null,
  "ລຶບ $0"
 ],
 "Group": [
  null,
  "ກຸ່ມ"
 ],
 "Actions": [
  null,
  "ການດຳເນີນການຕ່າງໆ"
 ],
 "Options": [
  null,
  "ຕົວເລືອກ"
 ],
 "Not available": [
  null,
  "ບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "Ignore": [
  null,
  "ລະເວັ້ນ"
 ],
 "Permanent": [
  null,
  "ຖາວອນ"
 ],
 "Preserve": [
  null,
  "ຮັກສາໄວ້"
 ],
 "Random": [
  null,
  "ສຸ່ມ"
 ],
 "Stable": [
  null,
  "ຄົງທີ່"
 ],
 "Use $0": [
  null,
  "ໃຊ້ $0"
 ],
 "Failed to save settings": [
  null,
  "ບໍ່ສາມາດບັນທຶກການຕັ້ງຄ່າໄດ້"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການສ້າງ $0 ນີ້ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ກັບເຊີເວີຂາດຫາຍ ແລະ ຈະເຮັດໃຫ້ໜ້າຈໍບໍລິຫານໃຊ້ງານບໍ່ໄດ້."
 ],
 "Create it": [
  null,
  "ສ້າງມັນ"
 ],
 "Invalid prefix $0": [
  null,
  "ຄຳນຳໜ້າ (prefix) $0 ບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid metric $0": [
  null,
  "ຄ່າເມທຣິກ $0 ບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid address $0": [
  null,
  "ທີ່ຢູ່ $0 ບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "ຄຳນຳໜ້າ ຫຼື ເນັດມາກສ໌ $0 ບໍ່ຖືກຕ້ອງ"
 ],
 "Testing connection": [
  null,
  "ກຳລັງທົດສອບການເຊື່ອມຕໍ່"
 ],
 "Restoring connection": [
  null,
  "ກຳລັງກູ້ຄືນການເຊື່ອມຕໍ່"
 ],
 "Troubleshoot…": [
  null,
  "ແກ້ໄຂບັນຫາ…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager ບໍ່ໄດ້ເຮັດວຽກຢູ່"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ບໍ່ໄດ້ຖືກຕິດຕັ້ງ"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "ອຸປະກອນເຄືອຂ່າຍ ແລະ ກຣາຟ ຕ້ອງການ NetworkManager"
 ],
 "Enable service": [
  null,
  "ເປີດໃຊ້ບໍລິການ"
 ],
 "Network interface '$0' not found": [
  null,
  ""
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "ທ່ານບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ແກ້ໄຂໄຟວໍ."
 ],
 "Not authorized to disable the firewall": [
  null,
  "ບໍ່ມີສິດໃນການປິດໄຟວໍ"
 ],
 "Not authorized to enable the firewall": [
  null,
  "ບໍ່ມີສິດໃນການເປີດໄຟວໍ"
 ],
 "Disable the firewall": [
  null,
  "ປິດການໃຊ້ງານໄຟວໍ"
 ],
 "Enable the firewall": [
  null,
  "ເປີດໃຊ້ງານໄຟວໍ"
 ],
 "Edit service $0": [
  null,
  "ແກ້ໄຂບໍລິການ $0"
 ],
 "Remove service $0": [
  null,
  "ລຶບບໍລິການ $0 ອອກ"
 ],
 "Additional port": [
  null,
  "ພອດເພີ່ມເຕີມ"
 ],
 "Remove zone $0": [
  null,
  "ລຶບໂຊນ $0 ອອກ"
 ],
 "Add services to zone $0": [
  null,
  "ເພີ່ມບໍລິການໃຫ້ໂຊນ $0"
 ],
 "Add services": [
  null,
  "ເພີ່ມບໍລິການ"
 ],
 "Service": [
  null,
  "ບໍລິການ"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 ໂຊນ"
 ],
 "Interface": [
  null,
  "ອິນເຕີເຟສ"
 ],
 "Allowed addresses": [
  null,
  "ທີ່ຢູ່ທີ່ອະນຸຍາດ"
 ],
 "Entire subnet": [
  null,
  "ຊັບເນັດທັງໝົດ"
 ],
 "There are no active services in this zone": [
  null,
  "ບໍ່ມີບໍລິການທີ່ກຳລັງເຮັດວຽກຢູ່ໃນໂຊນນີ້"
 ],
 "Filter services": [
  null,
  "ກັ່ນຕອງບໍລິການ"
 ],
 "Failed to edit service": [
  null,
  "ບໍ່ສາມາດແກ້ໄຂບໍລິການໄດ້"
 ],
 "Failed to add port": [
  null,
  "ບໍ່ສາມາດເພີ່ມພອດໄດ້"
 ],
 "Failed to add service": [
  null,
  "ບໍ່ສາມາດເພີ່ມບໍລິການໄດ້"
 ],
 "Unknown service name": [
  null,
  "ບໍ່ຮູ້ຈັກຊື່ບໍລິການ"
 ],
 "Invalid port number": [
  null,
  "ໝາຍເລກພອດບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid range": [
  null,
  "ຊ່ວງບໍ່ຖືກຕ້ອງ"
 ],
 "Range must be strictly ordered": [
  null,
  "ຊ່ວງຕ້ອງຖືກຈັດລຽງຕາມລຳດັບຢ່າງເຄັ່ງຄັດ"
 ],
 "Edit service": [
  null,
  "ແກ້ໄຂບໍລິການ"
 ],
 "Edit custom service in $0 zone": [
  null,
  "ແກ້ໄຂບໍລິການທີ່ກຳນົດເອງໃນໂຊນ $0"
 ],
 "Add ports": [
  null,
  "ເພີ່ມພອດ (ports)"
 ],
 "Add ports to $0 zone": [
  null,
  "ເພີ່ມພອດໃຫ້ໂຊນ $0"
 ],
 "Add services to $0 zone": [
  null,
  "ເພີ່ມບໍລິການໃຫ້ໂຊນ $0"
 ],
 "Custom ports": [
  null,
  "ພອດທີ່ກຳນົດເອງ"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "ຕົວຢ່າງ: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "ຍອມຮັບພອດ, ຊ່ວງພອດ ແລະ ບໍລິການ ທີ່ຂັ້ນດ້ວຍຈຸດ"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "ຕົວຢ່າງ: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "ຖ້າປະວ່າງໄວ້, ID ຈະຖືກສ້າງຂຶ້ນໂດຍອີງຕາມບໍລິການພອດ ແລະ ໝາຍເລກພອດທີ່ກ່ຽວຂ້ອງ"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "ການເພີ່ມພອດເອງຈະເຮັດໃຫ້ firewalld ເລີ່ມໃໝ່. ເຊິ່ງຈະເຮັດໃຫ້ການຕັ້ງຄ່າທີ່ບໍ່ໄດ້ບັນທຶກໄວ້ຖາວອນຫາຍໄປ!"
 ],
 "Failed to add zone": [
  null,
  "ບໍ່ສາມາດເພີ່ມໂຊນໄດ້"
 ],
 "Add zone": [
  null,
  "ເພີ່ມໂຊນ"
 ],
 "Trust level": [
  null,
  "ລະດັບຄວາມເຊື່ອຖື"
 ],
 "Sorted from least to most trusted": [
  null,
  "ຈັດລຽງຈາກຄວາມໜ້າເຊື່ອຖືໜ້ອຍທີ່ສຸດຫາຫຼາຍທີ່ສຸດ"
 ],
 "Custom zones": [
  null,
  "ໂຊນທີ່ກຳນົດເອງ"
 ],
 "No description available": [
  null,
  "ບໍ່ມີຄຳອະທິບາຍ"
 ],
 "Included services": [
  null,
  "ບໍລິການທີ່ລວມຢູ່ນຳ"
 ],
 "The cockpit service is automatically included": [
  null,
  "ບໍລິການ cockpit ຖືກລວມເຂົ້າໂດຍອັດຕະໂນມັດ"
 ],
 "Interfaces": [
  null,
  "ບັນດາອິນເຕີເຟສ"
 ],
 "Range": [
  null,
  "ຊ່ວງ"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "ທີ່ຢູ່ IP ພ້ອມກັບ routing prefix. ແຍກຫຼາຍຄ່າດ້ວຍຈຸດ. ຕົວຢ່າງ: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "ຢືນຢັນການເອົາ $0 ອອກ"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "ໂຊນນີ້ມີບໍລິການ cockpit ຢູ່. ກະລຸນາກວດສອບໃຫ້ແນ່ໃຈວ່າໂຊນນີ້ບໍ່ໄດ້ນຳໃຊ້ກັບການເຊື່ອມຕໍ່ web console ປັດຈຸບັນຂອງທ່ານ."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ການລຶບໂຊນຈະເປັນການລຶບທຸກບໍລິການທີ່ຢູ່ໃນນັ້ນອອກ."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "ການລຶບບໍລິການ cockpit ອາດເຮັດໃຫ້ບໍ່ສາມາດເຂົ້າເຖິງ web console ໄດ້. ໃຫ້ແນ່ໃຈວ່າໂຊນນີ້ບໍ່ໄດ້ນຳໃຊ້ກັບການເຊື່ອມຕໍ່ web console ຂອງທ່ານໃນປັດຈຸບັນ."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "ລຶບບໍລິການ $0 ອອກຈາກໂຊນ (zone) $1"
 ],
 "Firewall is not available": [
  null,
  "ໄຟວໍບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "Please install the $0 package": [
  null,
  "ກະລຸນາຕິດຕັ້ງແພັກເກດ $0"
 ],
 "Add a new zone": [
  null,
  "ເພີ່ມໂຊນໃໝ່"
 ],
 "Add new zone": [
  null,
  "ເພີ່ມໂຊນໃໝ່"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "ຄຳຂໍຂາເຂົ້າຖືກບລັອກໂດຍຄ່າເລີ່ມຕົ້ນ. ຄຳຂໍຂາອອກຈະບໍ່ຖືກບລັອກ."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID ບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Password can not be empty": [
  null,
  "ລະຫັດຜ່ານບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Failed to connect": [
  null,
  "ເຊື່ອມຕໍ່ຫຼົ້ມເຫຼວ"
 ],
 "Check your password.": [
  null,
  "ກວດສອບລະຫັດຜ່ານຂອງທ່ານ."
 ],
 "Connect to hidden network": [
  null,
  "ເຊື່ອມຕໍ່ຫາເຄືອຂ່າຍທີ່ເຊື່ອງໄວ້"
 ],
 "Connect to $0": [
  null,
  "ເຊື່ອມຕໍ່ຫາ $0"
 ],
 "Network name": [
  null,
  "ຊື່ເຄືອຂ່າຍ"
 ],
 "Security": [
  null,
  "ຄວາມປອດໄພ"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການລຶບ $0 ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ກັບເຊີບເວີຂາດຫາຍ ແລະ ຈະເຮັດໃຫ້ໜ້າຈໍການຈັດການບໍ່ສາມາດໃຊ້ງານໄດ້."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການເປີດ $0 ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ຫາເຊີເວີຂາດຫາຍ ແລະ ຈະບໍ່ສາມາດໃຊ້ງານ UI ຂອງຜູ້ດູແລລະບົບໄດ້."
 ],
 "Switch on $0": [
  null,
  "ເປີດ $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການປິດ $0 ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ຫາເຊີເວີຂາດຫາຍ ແລະ ຈະບໍ່ສາມາດໃຊ້ງານ UI ຂອງຜູ້ດູແລລະບົບໄດ້."
 ],
 "Switch off $0": [
  null,
  "ປິດ $0"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Team": [
  null,
  "Team"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "ບຣິດ (Bridge)"
 ],
 "Unknown \"$0\"": [
  null,
  "ບໍ່ຮູ້ຈັກ \"$0\""
 ],
 "Carrier": [
  null,
  "ຕົວນຳສັນຍານ"
 ],
 "Yes": [
  null,
  "ແມ່ນ"
 ],
 "No": [
  null,
  "ບໍ່"
 ],
 "Inactive": [
  null,
  "ບໍ່ມີການເຄື່ອນໄຫວ"
 ],
 "Unknown configuration": [
  null,
  "ບໍ່ຮູ້ຈັກການຕັ້ງຄ່າ"
 ],
 "Additional address $val": [
  null,
  "ທີ່ຢູ່ເພີ່ມເຕີມ $val"
 ],
 "Address $val": [
  null,
  "ທີ່ຢູ່ $val"
 ],
 "Gateway $gateway": [
  null,
  "ເກດເວ $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS ເພີ່ມເຕີມ $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "ໂດເມນຄົ້ນຫາ DNS ເພີ່ມເຕີມ $val"
 ],
 "DNS search domains $val": [
  null,
  "ໂດເມນຄົ້ນຫາ DNS $val"
 ],
 "General": [
  null,
  "ທົ່ວໄປ"
 ],
 "Connect automatically": [
  null,
  "ເຊື່ອມຕໍ່ອັດຕະໂນມັດ"
 ],
 "Automatic": [
  null,
  "ອັດຕະໂນມັດ"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ການກວດສອບ ARP"
 ],
 "Broken configuration": [
  null,
  "ການຕັ້ງຄ່າເສຍຫາຍ"
 ],
 "Team port": [
  null,
  "Team port"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "ບຸລິມະສິດ $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "ການໜ່ວງເວລາສົ່ງຕໍ່ $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "ເວລາ Hello $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "ອາຍຸຂໍ້ຄວາມສູງສຸດ $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "ຄ່າເສັ້ນທາງ $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hairpin mode"
 ],
 "Bridge port": [
  null,
  "ພອດ Bridge"
 ],
 "Parent $parent": [
  null,
  "ຕົວຫຼັກ $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "ລະຫັດຜ່ານເຄືອຂ່າຍບໍ່ໄດ້ຖືກຈັດເກັບໄວ້. ກະລຸນາລຶບ (forget) ແລະ ເຊື່ອມຕໍ່ເຄືອຂ່າຍນີ້ຄືນໃໝ່."
 ],
 "Failed to connect to $0": [
  null,
  "ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບ $0 ໄດ້"
 ],
 "secured": [
  null,
  "ປອດໄພ"
 ],
 "open": [
  null,
  "ເປີດ"
 ],
 "Last connected: $0": [
  null,
  "ເຊື່ອມຕໍ່ຫຼ້າສຸດ: $0"
 ],
 "Signal strength": [
  null,
  "ຄວາມແຮງສັນຍານ"
 ],
 "Not permitted to disconnect network": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ຕັດການເຊື່ອມຕໍ່ເຄືອຂ່າຍ"
 ],
 "Disconnect": [
  null,
  "ຕັດການເຊື່ອມຕໍ່"
 ],
 "Not permitted to connect to network": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຊື່ອມຕໍ່ເຄືອຂ່າຍ"
 ],
 "Forget": [
  null,
  "ລຶບຂໍ້ມູນການຈື່"
 ],
 "$0 hidden network": [
  null,
  "ເຄືອຂ່າຍທີ່ເຊື່ອງໄວ້ $0 ເຄືອຂ່າຍ"
 ],
 "Filter": [
  null,
  "ໂຕກັ່ນຕອງ"
 ],
 "Refresh": [
  null,
  "ຣີເຟຣຊ (Refresh)"
 ],
 "Available networks": [
  null,
  "ເຄືອຂ່າຍທີ່ມີໃຫ້ໃຊ້"
 ],
 "Network": [
  null,
  "ເຄືອຂ່າຍ"
 ],
 "Mode": [
  null,
  "ໂໝດ"
 ],
 "Signal": [
  null,
  "ສັນຍານ"
 ],
 "Rate": [
  null,
  "ອັດຕາ"
 ],
 "Not permitted to configure network devices": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ຕັ້ງຄ່າອຸປະກອນເຄືອຂ່າຍ"
 ],
 "Enable or disable the device": [
  null,
  "ເປີດ ຫຼື ປິດໃຊ້ງານອຸປະກອນ"
 ],
 "This device cannot be managed here.": [
  null,
  "ອຸປະກອນນີ້ບໍ່ສາມາດຈັດການຢູ່ນີ້ໄດ້."
 ],
 "Connection will be lost": [
  null,
  "ການເຊື່ອມຕໍ່ຈະຂາດຫາຍ"
 ],
 "Keep connection": [
  null,
  "ຮັກສາການເຊື່ອມຕໍ່"
 ],
 "Invalid IP address: $0": [
  null,
  "ທີ່ຢູ່ IP ບໍ່ຖືກຕ້ອງ: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "ທີ່ຢູ່ປາຍທາງບໍ່ຖືກຕ້ອງ: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "ທີ່ຢູ່ເກດເວບໍ່ຖືກຕ້ອງ: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "ທີ່ຢູ່ DNS ບໍ່ຖືກຕ້ອງ: $0"
 ],
 "Preparing": [
  null,
  "ກຳລັງກຽມພ້ອມ"
 ],
 "Configuring": [
  null,
  "ກຳລັງຕັ້ງຄ່າ"
 ],
 "Authenticating": [
  null,
  "ກຳລັງຢືນຢັນຕົວຕົນ"
 ],
 "Configuring IP": [
  null,
  "ກຳລັງຕັ້ງຄ່າ IP"
 ],
 "Checking IP": [
  null,
  "ກຳລັງກວດສອບ IP"
 ],
 "Waiting": [
  null,
  "ກຳລັງລໍຖ້າ"
 ],
 "Active": [
  null,
  "ໃຊ້ງານຢູ່"
 ],
 "Deactivating": [
  null,
  "ກຳລັງປິດການໃຊ້ງານ"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "ເມຊ (Mesh)"
 ],
 "No carrier": [
  null,
  "ບໍ່ມີສັນຍານເຊື່ອມຕໍ່ (No carrier)"
 ],
 "Part of $0": [
  null,
  "ເປັນສ່ວນໜຶ່ງຂອງ $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການປ່ຽນການຕັ້ງຄ່າຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ກັບເຊີເວີຂາດຫາຍ ແລະ ຈະເຮັດໃຫ້ໜ້າຈໍບໍລິຫານໃຊ້ງານບໍ່ໄດ້."
 ],
 "Change the settings": [
  null,
  "ປ່ຽນການຕັ້ງຄ່າ"
 ],
 "Add bridge": [
  null,
  "ເພີ່ມ bridge"
 ],
 "Edit bridge settings": [
  null,
  "ແກ້ໄຂການຕັ້ງຄ່າ bridge"
 ],
 "Ports": [
  null,
  "ພອດ (Ports)"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "ລຳດັບຄວາມສຳຄັນຂອງ STP"
 ],
 "STP forward delay": [
  null,
  "STP forward delay"
 ],
 "STP hello time": [
  null,
  "STP hello time"
 ],
 "STP maximum message age": [
  null,
  "ອາຍຸຂໍ້ຄວາມສູງສຸດຂອງ STP"
 ],
 "Round robin": [
  null,
  "ແບບວົນຮອບ (Round robin)"
 ],
 "Active backup": [
  null,
  "ສຳຮອງຂໍ້ມູນແບບ Active"
 ],
 "Load balancing": [
  null,
  "ການແບ່ງເບົາພາລະ (Load balancing)"
 ],
 "Broadcast": [
  null,
  "ບຣອດແຄສ (Broadcast)"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "ແບບຕັ້ງຮັບ (Passive)"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "ເພີ່ມ team"
 ],
 "Edit team settings": [
  null,
  "ແກ້ໄຂການຕັ້ງຄ່າ team"
 ],
 "Runner": [
  null,
  "ຕົວຣັນ (Runner)"
 ],
 "Balancer": [
  null,
  "ຕົວປັບສົມດຸນ"
 ],
 "Primary": [
  null,
  "ຫຼັກ"
 ],
 "Link watch": [
  null,
  "Link watch"
 ],
 "Link up delay": [
  null,
  "ການໜ່ວງເວລາຕອນລິ້ງເຊື່ອມຕໍ່"
 ],
 "Link down delay": [
  null,
  "ການໜ່ວງເວລາຕອນລິ້ງຫຼຸດ"
 ],
 "Ping interval": [
  null,
  "ຊ່ວງເວລາການ Ping"
 ],
 "Ping target": [
  null,
  "ເປົ້າໝາຍການ Ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "ອັດຕະໂນມັດ (DHCP ເທົ່ານັ້ນ)"
 ],
 "Link local": [
  null,
  "Link local"
 ],
 "Manual": [
  null,
  "ກຳນົດເອງ"
 ],
 "Shared": [
  null,
  "ໃຊ້ຮ່ວມກັນ"
 ],
 "Prefix length or netmask": [
  null,
  "ຄວາມຍາວພຣີຟິກ ຫຼື ເນັດມາກ"
 ],
 "Prefix length": [
  null,
  "ຄວາມຍາວພຣີຟິກ (Prefix length)"
 ],
 "IPv4 settings": [
  null,
  "ການຕັ້ງຄ່າ IPv4"
 ],
 "IPv6 settings": [
  null,
  "ການຕັ້ງຄ່າ IPv6"
 ],
 "Addresses": [
  null,
  "ທີ່ຢູ່ຕ່າງໆ"
 ],
 "Select method": [
  null,
  "ເລືອກວິທີການ"
 ],
 "Add address": [
  null,
  "ເພີ່ມທີ່ຢູ່"
 ],
 "Address": [
  null,
  "ທີ່ຢູ່"
 ],
 "Remove item": [
  null,
  "ລຶບລາຍການອອກ"
 ],
 "Gateway": [
  null,
  "ເກດເວ (Gateway)"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "ເພີ່ມເຊີເວີ DNS"
 ],
 "DNS search domains": [
  null,
  "ໂດເມນຄົ້ນຫາ DNS"
 ],
 "Add search domain": [
  null,
  "ເພີ່ມໂດເມນຄົ້ນຫາ"
 ],
 "Search domain": [
  null,
  "ໂດເມນຄົ້ນຫາ"
 ],
 "Routes": [
  null,
  "ເສັ້ນທາງ (Routes)"
 ],
 "Add route": [
  null,
  "ເພີ່ມເສັ້ນທາງ (route)"
 ],
 "Metric": [
  null,
  "ເມທຣິກ (Metric)"
 ],
 "Enter a valid MAC address": [
  null,
  "ກະລຸນາປ້ອນທີ່ຢູ່ MAC ທີ່ຖືກຕ້ອງ"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "ເຄືອຂ່າຍ $0"
 ],
 "Add VPN": [
  null,
  "ເພີ່ມ VPN"
 ],
 "Add bond": [
  null,
  "ເພີ່ມ bond"
 ],
 "Add VLAN": [
  null,
  "ເພີ່ມ VLAN"
 ],
 "Edit rules and zones": [
  null,
  "ແກ້ໄຂກົດ ແລະ ໂຊນ"
 ],
 "$0 active zone": [
  null,
  "$0 ໂຊນທີ່ກຳລັງໃຊ້ງານ"
 ],
 "Managed interfaces": [
  null,
  "ອິນເຕີເຟສທີ່ຖືກຈັດການ"
 ],
 "IP address": [
  null,
  "ທີ່ຢູ່ IP"
 ],
 "Sending": [
  null,
  "ກຳລັງສົ່ງ"
 ],
 "Receiving": [
  null,
  "ກຳລັງຮັບ"
 ],
 "Unmanaged interfaces": [
  null,
  "ອິນເຕີເຟສທີ່ບໍ່ໄດ້ຮັບການຈັດການ"
 ],
 "Network logs": [
  null,
  "ບັນທຶກເຫດການເຄືອຂ່າຍ"
 ],
 "Addresses are not formatted correctly": [
  null,
  "ຮູບແບບທີ່ຢູ່ບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid IP address '$0'": [
  null,
  "ທີ່ຢູ່ IP ບໍ່ຖືກຕ້ອງ '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "ຍັງບໍ່ໄດ້ຕິດຕັ້ງແພັກເກັດ wireguard-tools"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "ພີຣ໌ #$0 ມີຈຸດປາຍທາງ (endpoint) ບໍ່ຖືກຕ້ອງ. ຕ້ອງກຳນົດເປັນ host:port, ຕົວຢ່າງ: 1.2.3.4:51820, [2001:db8::1]:51820 ຫຼື example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "ພີຣ໌ #$0 ມີພອດປາຍທາງບໍ່ຖືກຕ້ອງ. ພອດຕ້ອງເປັນຕົວເລກ."
 ],
 "Listen port must be a number": [
  null,
  "ພອດຕ້ອງເປັນຕົວເລກ"
 ],
 "Add WireGuard VPN": [
  null,
  "ເພີ່ມ WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "ແກ້ໄຂ WireGuard VPN"
 ],
 "Private key": [
  null,
  "ກະແຈສ່ວນຕົວ"
 ],
 "Paste existing key": [
  null,
  "ວາງຄີທີ່ມີຢູ່"
 ],
 "Regenerate": [
  null,
  "ສ້າງໃໝ່"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "ກະແຈສາທາລະນະຈະຖືກສ້າງຂຶ້ນເມື່ອປ້ອນກະແຈສ່ວນຕົວທີ່ຖືກຕ້ອງ"
 ],
 "Listen port": [
  null,
  "ພອດທີ່ລໍຖ້າຮັບການເຊື່ອມຕໍ່"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "ຈະຖືກຕັ້ງເປັນ \"ອັດຕະໂນມັດ\""
 ],
 "IP addresses": [
  null,
  "ທີ່ຢູ່ IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "ສາມາດກຳນົດໄດ້ຫຼາຍທີ່ຢູ່ໂດຍໃຊ້ຈຸດ (comma) ຫຼື ຍະຫວ່າງ ເປັນຕົວຂັ້ນ."
 ],
 "Peers": [
  null,
  "ພີຣ໌ (Peers)"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "ພີຣ໌ແມ່ນເຄື່ອງອື່ນໆທີ່ເຊື່ອມຕໍ່ກັບເຄື່ອງນີ້. ພັບບລິກຄີ (Public keys) ຈາກເຄື່ອງອື່ນຈະຖືກແບ່ງປັນໃຫ້ກັນແລະກັນ."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "ຈຸດປາຍທາງທີ່ເຮັດໜ້າທີ່ເປັນ \"ເຊີບເວີ\" ຕ້ອງກຳນົດເປັນ host:port, ຖ້າບໍ່ດັ່ງນັ້ນສາມາດປະວ່າງໄວ້ໄດ້."
 ],
 "Add peer": [
  null,
  "ເພີ່ມ peer"
 ],
 "Endpoint": [
  null,
  "ຈຸດປາຍທາງ"
 ],
 "Allowed IPs": [
  null,
  "IP ທີ່ອະນຸຍາດ"
 ],
 "No peers added.": [
  null,
  "ບໍ່ມີການເພີ່ມພີຣ໌ (peers)."
 ],
 "Edit VLAN settings": [
  null,
  "ແກ້ໄຂການຕັ້ງຄ່າ VLAN"
 ],
 "Parent": [
  null,
  "ຕົວຫຼັກ (Parent)"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "ກຳລັງສົ່ງຂໍ້ມູນ"
 ],
 "MTU must be a positive number": [
  null,
  "MTU ຕ້ອງເປັນຕົວເລກບວກ"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "ຕັ້ງເປັນ"
 ],
 "Team port settings": [
  null,
  "ການຕັ້ງຄ່າ Team port"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "LACP key": [
  null,
  "ຄີ LACP"
 ],
 "Bridge port settings": [
  null,
  "ການຕັ້ງຄ່າພອດ Bridge"
 ],
 "Path cost": [
  null,
  "ຄ່າເສັ້ນທາງ (Path cost)"
 ],
 "Hair pin mode": [
  null,
  "Hair pin mode"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "ການປັບສົມດຸນການສົ່ງຂໍ້ມູນແບບປັບຕົວ"
 ],
 "Adaptive load balancing": [
  null,
  "ການປັບສົມດຸນການໂຫຼດແບບປັບຕົວ"
 ],
 "MII (recommended)": [
  null,
  "MII (ແນະນຳ)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "ແກ້ໄຂການຕັ້ງຄ່າ bond"
 ],
 "Network bond": [
  null,
  "ການຮວມເຄືອຂ່າຍ (Network bond)"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "ການເຮັດ Network bond ແມ່ນການລວມເອົາຫຼາຍອິນເຕີເຟດເຄືອຂ່າຍເຂົ້າເປັນອິນເຕີເຟດດຽວ ເພື່ອໃຫ້ມີຄວາມໄວສູງຂຶ້ນ ຫຼື ເພື່ອສຳຮອງຂໍ້ມູນ."
 ],
 "Link monitoring": [
  null,
  "ການຕິດຕາມລິ້ງ"
 ],
 "Monitoring interval": [
  null,
  "ຊ່ວງເວລາການເຝົ້າລະວັງ"
 ],
 "Monitoring targets": [
  null,
  "ເປົ້າໝາຍການເຝົ້າລະວັງ"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການລຶບ $0 ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ກັບເຊີບເວີຂາດຫາຍ, ແລະ ຈະເຮັດໃຫ້ UI ສຳລັບການດູແລລະບົບໃຊ້ງານບໍ່ໄດ້."
 ],
 "Remove $0": [
  null,
  "ລຶບ $0 ອອກ"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ການເພີ່ມ $0 ຈະເຮັດໃຫ້ການເຊື່ອມຕໍ່ກັບເຊີເວີຂາດຫາຍ ແລະ ຈະເຮັດໃຫ້ໜ້າຈໍບໍລິຫານໃຊ້ງານບໍ່ໄດ້."
 ],
 "Add member": [
  null,
  "ເພີ່ມສະມາຊິກ"
 ],
 "Interface members": [
  null,
  "ສະມາຊິກອິນເຕີເຟສ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console ສຳລັບ Linux ເຊີເວີ"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ແມ່ນລະບົບຈັດການເຊີເວີທີ່ຊ່ວຍໃຫ້ການບໍລິຫານເຊີເວີ Linux ຂອງທ່ານຜ່ານເວັບບຣາວເຊີເປັນເລື່ອງງ່າຍ. ທ່ານສາມາດສະຫຼັບການເຮັດວຽກລະຫວ່າງເທີມິນໍ ແລະ ເຄື່ອງມືເວັບໄດ້ຢ່າງສະດວກ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ແມ່ນເໝາະສົມສຳລັບຜູ້ດູແລລະບົບໃໝ່, ຊ່ວຍໃຫ້ດຳເນີນວຽກງ່າຍໆ ເຊັ່ນ ການຈັດການບ່ອນເກັບຂໍ້ມູນ, ກວດສອບລັອກ ແລະ ການຈັດການບໍລິການຕ່າງໆ."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "ເມື່ອຕິດຕັ້ງ Cockpit ແລ້ວ, ໃຫ້ເປີດໃຊ້ງານດ້ວຍຄຳສັ່ງ \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ການຕັ້ງຄ່າ NetworkManager ແລະ Firewalld ຂອງ Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການເຄືອຂ່າຍ ເຊັ່ນ bonds, bridges, teams, VLANs ແລະ ໄຟວໍ (firewalls) ໂດຍໃຊ້ NetworkManager ແລະ Firewalld."
 ],
 "Manage storage": [
  null,
  "ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນພາຍໃນເຄື່ອງ ເຊັ່ນ ລະບົບໄຟລ໌, LVM2 volume groups, ແລະ ການຕິດຕັ້ງ NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "ເກັບກຳ ແລະ ລວມແພັກເກດຂໍ້ມູນການວິເຄາະ ແລະ ການຊ່ວຍເຫຼືອ"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ສ້າງໄຟລ໌ເກັບຂໍ້ມູນການຕັ້ງຄ່າ ແລະ ຂໍ້ມູນການວິເຄາະຈາກລະບົບທີ່ກຳລັງເຮັດວຽກຢູ່. ຂໍ້ມູນເຫຼົ່ານີ້ອາດຖືກເກັບໄວ້ໃນເຄື່ອງ ຫຼື ສ່ວນກາງເພື່ອຈຸດປະສົງໃນການບັນທຶກ ຫຼື ຕິດຕາມ, ຫຼື ສົ່ງໃຫ້ຝ່າຍຊ່ວຍເຫຼືອທາງເຕັກນິກ, ນັກພັດທະນາ ຫຼື ຜູ້ດູແລລະບົບເພື່ອຊ່ວຍໃນການແກ້ໄຂບັນຫາ ແລະ ດີບັກ (debug)."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "ການຕັ້ງຄ່າ ແລະ ການແກ້ໄຂບັນຫາ Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່ານະໂຍບາຍ SELinux ແລະ ສາມາດຊ່ວຍໃນການເຂົ້າໃຈ ແລະ ແກ້ໄຂການລະເມີດນະໂຍບາຍໄດ້."
 ],
 "Collect kernel crash dumps": [
  null,
  "ເກັບກຳຂໍ້ມູນ kernel crash dumps"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່າລະບົບເພື່ອບັນທຶກ kernel crash dumps. ມັນຮອງຮັບເປົ້າໝາຍການເກັບແບບ \"local\" (ດິດ), \"ssh\", ແລະ \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ການບໍລິຫານດ້ວຍ Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "ຕ້ອງມີການຢືນຢັນຕົວຕົນເພື່ອດຳເນີນການວຽກທີ່ມີສິດພິເສດດ້ວຍ Cockpit Web Console"
 ]
});
