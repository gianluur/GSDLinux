cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "Set": [
  null,
  "დაყენება"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "Trust and add host": [
  null,
  "ჰოსტის ნდობა და დამატება"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"ჰოსტის ნდობა და დამატებას\", ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "მიღებული ანაბეჭდის გაზიარება, ელფოსტის ჩათვლით, უსაფრთხოა. თუ თქვენ სხვას სთხოვთ, თქვენი სახელით გადაამოწმოს, მათ, შედეგების გამოგზავნა ნებისმიერი მეთოდით შეუძლიათ."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "Verify fingerprint": [
  null,
  "ანაბეჭდის გადამოწმება"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "გაუშვით ეს ბრძანება სანდო ქსელით ან ფიზიკურად, დაშორებულ მანქანაზე:"
 ],
 "The fingerprint should match:": [
  null,
  "ანაბეჭდების უნდა ემთხვეოდეს:"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "Permission denied": [
  null,
  "წვდომა აკრძალულია"
 ],
 "Clear input value": [
  null,
  "შეყვანილი მნიშვნელობის გასუფთავება"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "Create $0": [
  null,
  "$0-ის შექმნა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ადმინისტრატორის წვდომის მიღების მეთოდები (sudo -A, pkexec) ხელმისაწვდომი არაა."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Unknown host: $0": [
  null,
  "უცნობი ჰოსტი: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი."
 ],
 "SSH key login": [
  null,
  "SSH გასაღებით შესვლა"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit-ის შეცდომის კოდი $0"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Error during initialization": [
  null,
  "შეცდომა ინიციალიზაციის მიმდინარეობისას"
 ],
 "Failed": [
  null,
  "ჩავარდა"
 ],
 "Home": [
  null,
  "საწყისი"
 ],
 "Downloads": [
  null,
  "გადმოწერები"
 ],
 "Not a directory": [
  null,
  "საქაღალდე არაა"
 ],
 "All files": [
  null,
  "ყველა ფაილი"
 ],
 "Recent": [
  null,
  "უახლესი"
 ],
 "No recent directories": [
  null,
  "უახლესი საქაღალდეების გარეშე"
 ],
 "No recent files": [
  null,
  "უახლესი ფაილების გარეშე"
 ],
 "Type to filter": [
  null,
  "გასაფილტრად აკრიფეთ"
 ],
 "File chooser actions": [
  null,
  "ფაილის ამრჩევის ქმედებები"
 ],
 "Open in file browser": [
  null,
  "გახსნა ფაილების ბრაუზერში"
 ],
 "Hide hidden files": [
  null,
  "დამალული ფაილების დამალვა"
 ],
 "Show hidden files": [
  null,
  "დამალული ფაილების ჩვენება"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Clear filters": [
  null,
  "ფილტრების გასუფთავება"
 ],
 "Directory is empty": [
  null,
  "საქაღალდე ცარიელია"
 ],
 "Directory has no sub-directories": [
  null,
  "საქაღალდეს ქვესაქაღალდეები არ აქვს"
 ],
 "This directory contains only hidden files": [
  null,
  "ეს საქაღალდე, მხოლოდ, დამალულ ფაილებს შეიცავს"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "Folder": [
  null,
  "საქაღალდე"
 ],
 "File": [
  null,
  "ფაილი"
 ],
 "Copy to clipboard": [
  null,
  "ბუფერში კოპირება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Select an option": [
  null,
  "აირჩიეთ პარამეტრი"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "View logs": [
  null,
  "ჟურნალის ნახვა"
 ],
 "Dismiss": [
  null,
  "მოცილება"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Actions": [
  null,
  "ქმედებები"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Rename": [
  null,
  "სახელის გადარქმევა"
 ],
 "Started": [
  null,
  "დაწყებულია"
 ],
 "Delete group": [
  null,
  "ჯგუფის წაშლა"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Lock": [
  null,
  "დაკეტვა"
 ],
 "Use $0": [
  null,
  "$0-ის გამოყენება"
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Disconnect": [
  null,
  "გათიშვა"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "$0 disk is missing": [
  null,
  "$0 დისკი აკლია",
  "$0 ცალი დისკი აკლია"
 ],
 "Location": [
  null,
  "მდებარეობა"
 ],
 "Compression": [
  null,
  "შეკუმშვა"
 ],
 "Storage logs": [
  null,
  "საცავის ჟურნალი"
 ],
 "Name cannot be empty.": [
  null,
  "სახელი არ შეიძლება იყოს ცარიელი."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "სახელი არ შეიძლება 127 სიმბოლოზე გრძელი იყოს."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს სიმბოლოს '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს ცარიელ სიმბოლოებს."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "სახელი არ შეიძლება $0 სიმბოლოზე მეტი იყოს"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "სახელი არ შეიძლება $0 ბაიტზე გრძელი იყოს"
 ],
 "$name (from $host)": [
  null,
  "$name ($host-დან)"
 ],
 "Pool for thin logical volumes": [
  null,
  "თხელი ლოგიკური საცავების პული"
 ],
 "Thin logical volume": [
  null,
  "თხელი ლოგიკური ტომი"
 ],
 "Logical volume (snapshot)": [
  null,
  "ლოგიკური ტომი (სწრაფი ასლი)"
 ],
 "Logical volume": [
  null,
  "ლოგიკური ტომი"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID მოწყობილობა $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ტომის ჯგუფი $0"
 ],
 "VDO device $0": [
  null,
  "VDO მოწყობილობა: $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "ლოგიკური დაშიფრული საცავი $0"
 ],
 "Encrypted partition of $0": [
  null,
  "$0-ის დაშიფრული სექცია"
 ],
 "Logical volume of $0": [
  null,
  "$0-ის ლოგიკური სივრცე"
 ],
 "Partition of $0": [
  null,
  "$0-ის დანაყოფი"
 ],
 "Encrypted $0": [
  null,
  "$0 დაშიფრულია"
 ],
 "unpartitioned space on $0": [
  null,
  "$0-ზე დარჩენილი დაუხლეჩავი სივრცე"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "remove from btrfs volume": [
  null,
  "წაშლა btrfs ტომიდან"
 ],
 "stop": [
  null,
  "გაჩერება"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID-დან წაშლა"
 ],
 "remove from LVM2": [
  null,
  "LVM2-დან წაშლა"
 ],
 "btrfs device": [
  null,
  "btrfs მოწყობილობება"
 ],
 "btrfs volume": [
  null,
  "btrfs ტომი"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "სახელი არ შეიძლება 255 სიმბოლოზე გრძელი იყოს."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს სიმბოლოს '/'."
 ],
 "Create and mount": [
  null,
  "შექმნა და მიმაგრება"
 ],
 "Create only": [
  null,
  "მხოლოდ შექმნა"
 ],
 "Create subvolume": [
  null,
  "ქვეტომის შექმნა"
 ],
 "Mount Point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "delete": [
  null,
  "წაშლა"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "წავშალო სამუდამოდ ქვეტომი $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "წაშლა გაანადგურებს მონაცემებს ამ ქვეტომზე და ყველა მის შვილზე."
 ],
 "Edit mount point": [
  null,
  "მიმაგრების წერტილის ჩასწორება"
 ],
 "Unmount": [
  null,
  "მოხსნა"
 ],
 "Mount": [
  null,
  "მიმაგრება"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "საჭიროა, სულ ცოტა, ერთი ქვეტომი იყოს მიმაგრებული"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "ბოლოს მიმაგრებულ ქვეტომს ვერ წაშლით"
 ],
 "btrfs subvolume": [
  null,
  "Btrfs ქვეტომი"
 ],
 "Snapshot origin": [
  null,
  "სწრაფი ასლის წყარო"
 ],
 "Mount point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "No subvolumes": [
  null,
  "ქვეტომების გარეშე"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs ქვეტომები"
 ],
 "Snapshots": [
  null,
  "სწრაფი ასლები"
 ],
 "No snapshots found": [
  null,
  "სწრაფი ასლები აღმოჩენილი არაა"
 ],
 "snapshot": [
  null,
  "სწრაფი ასლი"
 ],
 "$0 is in use": [
  null,
  "$0 გამოიყენება"
 ],
 "Permanently delete $0?": [
  null,
  "წავშალო სამუდამოდ $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "წაშლა btrfs-ის ტომზე ყველა მონაცემს წაშლის."
 ],
 "Delete filesystem": [
  null,
  "ფაილური სისტემის წაშლა"
 ],
 "Change label": [
  null,
  "ჭდის შეცვლა"
 ],
 "Filesystem is mounted read-only": [
  null,
  "ფაილური სისტემა მიმაგრებულია, როგორც, მხოლოდ-წაკითხვადი"
 ],
 "Label": [
  null,
  "ჭდე"
 ],
 "Capacity": [
  null,
  "მოცულობა"
 ],
 "btrfs devices": [
  null,
  "btrfs მოწყობილობები"
 ],
 "No devices found": [
  null,
  "მოწყობილობები აღმოჩენილი არაა"
 ],
 "btrfs filesystem": [
  null,
  "ფაილური სისტემა btrfs"
 ],
 "Successful": [
  null,
  "წარმატებულია"
 ],
 "Aborted": [
  null,
  "შეწყვვეტილია"
 ],
 "In progress": [
  null,
  "მიმდინარეობს"
 ],
 "Interrupted": [
  null,
  "შეწყვეტილია"
 ],
 "Did not complete": [
  null,
  "არ დასრულებულა"
 ],
 "Failed (Unknown)": [
  null,
  "ჩავარდა (უცნობი)"
 ],
 "Failed (Electrical)": [
  null,
  "ჩავარდა (ელექტრო)"
 ],
 "Failed (Servo)": [
  null,
  "ჩავარდა (სერვო)"
 ],
 "Failed (Read)": [
  null,
  "ჩავარდა (წაკითხვა)"
 ],
 "Failed (Damaged)": [
  null,
  "ჩავარდა (დაზიანებულია)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "შეწყვეტილია კონტროლერის დონის ჩამოყრით"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "შეწყვეტილია სახელის სივრცის ინვენტორიდან სახელების სივრცის წაშლის გამო"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "შეწყვეტილია VM-ის დაფორმატების ბრძანების დამუშავების გამო"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "თვითშემოწმების ოპერაციისას აღმოჩენილია ფატალური შეცდომა"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "დასრულდა სეგმენტით, რომელიც ცავარდა და სეგმენტი, რომელიც ჩავარდა, უცნობია"
 ],
 "Completed with one or more failed segments": [
  null,
  "დასრულდა ერთი ან მეტი ჩავარდნილი სეგმენტით"
 ],
 "Aborted for unknown reason": [
  null,
  "შეწყდა უცნობი მიზეზით"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "შეწყვეტილია სანიტარიზაციის ოპერაციის გამო"
 ],
 "Spare capacity is below the threshold": [
  null,
  "თავისუფალი ადგილი დაყენებულზე დაბლაა"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "ტემპერატურა დასაშვებ შუალედს გარეთაა"
 ],
 "Degraded": [
  null,
  "დეგრადირებული"
 ],
 "All media is in read-only mode": [
  null,
  "ყველა მედია მხოლოდ-წაკითხვად რეჟიმშია"
 ],
 "Volatile memory backup failed": [
  null,
  "აქროლადი მეხსიერების მარქაფი ჩავარდა"
 ],
 "Persistent memory has become read-only": [
  null,
  "მუდმივი მეხსიერება მხოლოდ-წაკითხვადი გახდა"
 ],
 "Run short test": [
  null,
  "მოკლე შემოწმების გაშვება"
 ],
 "Run extended test": [
  null,
  "გაფართოებული შემოწმების გაშვება"
 ],
 "Abort test": [
  null,
  "შემოწმების შეწყვეტა"
 ],
 "Disk is failing": [
  null,
  "დისკი კვდება"
 ],
 "Disk is OK": [
  null,
  "დისკი კარგად გამოიყურება"
 ],
 "Assessment": [
  null,
  "შეფასება"
 ],
 "Power on hours": [
  null,
  "ჩართულობის დრო"
 ],
 "$0 hours": [
  null,
  "$0 საათი"
 ],
 "Self-test status": [
  null,
  "თვითშემოწმების სტატუსი"
 ],
 "Number of bad sectors": [
  null,
  "ცუდი სექტორების რაოდენობა"
 ],
 "Attributes failing": [
  null,
  "ჩავარდნილი ატრიბუტები"
 ],
 "Media drive": [
  null,
  "მედია დისკი"
 ],
 "Solid State Drive": [
  null,
  "მყარსხეულიანი დისკი"
 ],
 "Hard Disk Drive": [
  null,
  "მყარი დისკი"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI დისკი"
 ],
 "Drive": [
  null,
  "დისკი"
 ],
 "Device health (SMART)": [
  null,
  "მოწყობილობის ჯანმრთელობა (SMART)"
 ],
 "Firmware version": [
  null,
  "მიკროკოდის ვერსია"
 ],
 "Serial number": [
  null,
  "სერიული ნომერი"
 ],
 "World wide name": [
  null,
  "WWN სახელი"
 ],
 "No media inserted": [
  null,
  "დისკი არ დევს"
 ],
 "Device file": [
  null,
  "მოწყობილობის ფაილი"
 ],
 "Multipathed devices": [
  null,
  "მრავალბილიკა მოწყობილობები"
 ],
 "Free space": [
  null,
  "თავისუფალი სივრცე"
 ],
 "Create partition": [
  null,
  "განაყოფის შექმნა"
 ],
 "Extended partition": [
  null,
  "გაფართოებული განაყოფი"
 ],
 "$0 partitions": [
  null,
  "$0 დანაყოფი"
 ],
 "Partitions": [
  null,
  "დანაყოფები"
 ],
 "No partitions found": [
  null,
  "დანაყოფები ვერ ვიპოვე"
 ],
 "Unexpected partitions": [
  null,
  "მოულოდნელი დანაყოფები"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "ამ ბლოკურ მოწყობილობაზე დანაყოფები მხარდაჭერილი არაა. თუ ის გამოიყენება, როგორც დისკი ვირტუალური მანქანისთვის, დანაყოფები მართული უნდა იყოს ვირტუალურ მანქანაში არსებული ოპერაციული სისტემის მიერ."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "დანაყოფის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "No free space after this partition": [
  null,
  "ამ დანაყოფის შემდეგ თავისუფალი ადგილი არაა"
 ],
 "EFI system partition": [
  null,
  "EFI-ის სისტემური დანაყოფი"
 ],
 "BIOS boot partition": [
  null,
  "BIOS ჩატვირთვის დანაყოფი"
 ],
 "Partition": [
  null,
  "განაყოფი"
 ],
 "Shrink": [
  null,
  "შეწნეხვა"
 ],
 "Grow": [
  null,
  "გაზრდა"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP ჩატვირთვის დანაყოფი"
 ],
 "Linux swap space": [
  null,
  "Linux-ის სვოპის სივრცე"
 ],
 "Linux filesystem data": [
  null,
  "Linux-ის ფაილური სისტემის მონაცემები"
 ],
 "Logical Volume Manager partition": [
  null,
  "ლოგიკური ტომების მმართველის დანაყოფი"
 ],
 "Custom": [
  null,
  "ხელით"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "ტიპი, მხოლოდ, ზუსტად ორ თექვსმეტობით სიმბოლოს (0-9, A-F) უნდა შეიცავდეს."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "ტიპი შეიძლება, მხოლოდ, შეიცავდეს სიმბოლოებს 0-9, A-F და \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "ტიპი უნდა იყოს ფორმით NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "$0-ის დანაყოფის ტიპის დაყენება"
 ],
 "Custom type": [
  null,
  "მომხმარებლის ტიპი"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "დანაყოფის ტიპების შეცვლამ, შეიძლება, სისტემის ჩატვირთვას ხელი შეუშალოს."
 ],
 "This partition is not completely used by its content.": [
  null,
  "ეს დანაყოფი მისი შემცველობის მიერ სრულად არ გამოიყენება."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "დანაყოფის ზომაა $0. შემცველობის ზომა კი - $1."
 ],
 "Shrink partition": [
  null,
  "დანაყოფის შემცირება"
 ],
 "Grow content": [
  null,
  "შემცველობის გაზრდა"
 ],
 "initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "Initialize disk $0": [
  null,
  "დისკის ინიციალიზაცია $0"
 ],
 "Partitioning": [
  null,
  "დაყოფა"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "თავსებადია ყველა სისტემასა და მოწყობილობასთან (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "თავსებადია თანამედროვე სისტემებთან და >2TB დისკებთან (GPT)"
 ],
 "No partitioning": [
  null,
  "დანაყოფების გარეშე"
 ],
 "Overwrite": [
  null,
  "გადაწერა"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "არსებულ მონაცემებზე ნულების გადაწერა (ნელი)"
 ],
 "Initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "ინიციალიზაცია დისკზე მდებარე მონაცემებს მთლიანად წაშლის."
 ],
 "Device is read-only": [
  null,
  "მოწყობილობა მხოლოდ კითხვადია"
 ],
 "Create partition table": [
  null,
  "დაყოფის ცხრილის შექმნა"
 ],
 "Size must be a number": [
  null,
  "ზომა რიცხვი უნდა იყოს"
 ],
 "Size cannot be zero": [
  null,
  "ზომა არ შეიძლება ნულის ტოლი იყოს"
 ],
 "Size cannot be negative": [
  null,
  "ზომა არ შეიძლება უარყოფითი იყოს"
 ],
 "Size is too large": [
  null,
  "ზომა ძალიან დიდია"
 ],
 "Size must be at least $0": [
  null,
  "ზომის მინიმალური მნიშვნელობაა $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 საცავების ჯგუფის წევრი ფიზიკური საცავი"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID მოწყობილობის წევრი"
 ],
 "backing device for VDO device": [
  null,
  "VDO მოწყობილობის მხარდამჭერი მოწყობილობა"
 ],
 "member of Stratis pool": [
  null,
  "Stratis-ის პულის წევრი"
 ],
 "Filesystem outside the target": [
  null,
  "ფაილური სისტემა სამიზნის გარეთ"
 ],
 "device of btrfs volume": [
  null,
  "btrfs ტომის მოწყობილობა"
 ],
 "This device is currently in use.": [
  null,
  "მოწყობილობა უკვე გამოიყენება."
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Use": [
  null,
  "გამოყენება"
 ],
 "Services using the location": [
  null,
  "მდებარეობის გამომყენებელი სერვისები"
 ],
 "Processes using the location": [
  null,
  "მდებარეობის გამოყენებელი პროცესები"
 ],
 "Currently in use": [
  null,
  "ამჟამად გამოიყენება"
 ],
 "(Not part of target)": [
  null,
  "(სამიზნის ნაწილი არაა)"
 ],
 "These changes will be made:": [
  null,
  "მოხდება ეს ცვლილებები:"
 ],
 "Action": [
  null,
  "ქმედება"
 ],
 "Important data might be deleted:": [
  null,
  "შეიძლება, საჭირო მონაცემები წაგეშალოთ:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები და სერვისები ძალით იქნებიან გაჩერებული."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები ძალით იქნება გაჩერებული."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "დაკავშირებული სერვისები ძალით იქნება გაჩერებული."
 ],
 "Checking filesystem usage": [
  null,
  "ფაილური სისტემის გამოყენების შემოწმება"
 ],
 "$0 used, $1 total": [
  null,
  "$0 გამოყენებული, ჯამში $1"
 ],
 "Device contains unrecognized data": [
  null,
  "მოწყობილობა უცნობ მონაცემებს შეიცავს"
 ],
 "Locked encrypted device might contain data": [
  null,
  "ჩაკეტილი დაშიფრული მოწყობილობა, შეიძლება, მონაცემებს შეიცავდეს"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "ვადასტურებ, მნებავს, ეს მონაცემები სამუდამოდ წაიშალოს"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "მიმაგრების წერტილი $0 დაკავებულია ჩამოთვლილი პროცესების მიერ:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "მიმაგრების წერტილი $0 გამოიყენება ჩამოთვლილი სერვისების მიერ:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები და სერვისები ძალით იქნება გაჩერებული."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები ძალით გაჩერდება."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი სერვისები ძალით გაჩერდება."
 ],
 "Sorry": [
  null,
  "უკაცრავად"
 ],
 "Usage of $0": [
  null,
  "$0-ის გამოყენების წესები"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO პული"
 ],
 "Data used": [
  null,
  "გამოყენებული მონაცემები"
 ],
 "Metadata used": [
  null,
  "გამოყენებული მეტამონაცემები"
 ],
 "Use compression": [
  null,
  "შეკუმშვის გამოყენება"
 ],
 "Deduplication": [
  null,
  "დედუპლიკაცია"
 ],
 "Use deduplication": [
  null,
  "დედუპლიკაციის გამოყენება"
 ],
 "Rename volume group": [
  null,
  "ტომების ჯგუფისათვის სახელის გადარქმევა"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "ეს ტომების ჯგუფი ძირითად ფაილურ სისტემას შეიცავს. მისი სახელის გადარქმევას, შეიძლება, დამატებითი ცვლილებები დასჭირდეს ჩამტვირთავის კონფიგურაციაში ან ბირთვის ბრძანების სტრიქონში."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "საცავების ჯგუფის წაშლისას ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "Create snapshot": [
  null,
  "სწრაფი ასლის შექმნა"
 ],
 "Add disks": [
  null,
  "დისკების დამატება"
 ],
 "Disks": [
  null,
  "დისკები"
 ],
 "No disks are available.": [
  null,
  "დისკები ხელმიუწვდომელია."
 ],
 "At least one disk is needed.": [
  null,
  "საჭიროა ერთი დისკი მაინც."
 ],
 "Volume group is missing physical volumes": [
  null,
  "ტომების ჯგუფს ფიზიკური ტომები აკლია"
 ],
 "No free space": [
  null,
  "თავისუფალი ადგილის გარეშე"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ტომების ჯგუფი"
 ],
 "Add physical volume": [
  null,
  "ფიზიკური ტომის დამატება"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 ლოგიკური ტომები"
 ],
 "Create new logical volume": [
  null,
  "ახალი ლოგიკური ტომის შექმნა"
 ],
 "No logical volumes": [
  null,
  "ლოგიკური ტომების გარეშე"
 ],
 "Remove missing physical volumes?": [
  null,
  "წავშალო ნაკლული ფიზიკური ტომები?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "ამ ტომების ჯგუფის ფიზიკური ტომები აკლია."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "ტომების ჯგუფს, რომელსაც ფიზიკური ტომები აკლია, სახელს ვერ გადაარქმევთ."
 ],
 "Physical volumes": [
  null,
  "ფიზიკური ტომები"
 ],
 "No physical volumes found": [
  null,
  "ფიზიკური ტომები ვერ ვიპოვე"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 ფიზიკური ტომები"
 ],
 "Rename logical volume": [
  null,
  "ლოგიკური ტომისთვის სახელის გადარქმევა"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "წავშალო სამუდამოდ ლოგიკური ტომი $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "ლოგიკური საცავის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Unable to repair logical volume $0": [
  null,
  "ლოგიკური ტომის ($0) შეკეთება შეუძლებელია"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "შეკეთებისთვის საკმარისი ადგილი არაა. საჭიროა მინიმუმ $0 ადგილი ფიზიკურ ტომებზე, რომლებიც ლოგიკურ ტომებს არ უკავიათ."
 ],
 "An additional $0 must be selected": [
  null,
  "საჭიროა დამატებით $0-ის მონიშვნა"
 ],
 "Repair logical volume $0": [
  null,
  "ლოგიკური ტომის $0 შეკეთება"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "აირჩიეთ ფიზიკური ტომები, რომელიც ლოგიკური ტომის შესაკეთებლად იქნება გამოყენებული. საჭიროა მინიმუმ $0."
 ],
 "Physical Volumes": [
  null,
  "ფიზიკური ტომები"
 ],
 "Repair": [
  null,
  "შეკეთება"
 ],
 "deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "მოხდეს ლოგიკური ტომის, $0/$1 დეაქტივაცია?"
 ],
 "Deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "Not enough space to grow": [
  null,
  "გასადიდებლად არასაკმარისი სივრცეა"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 ლოგიკური ტომი"
 ],
 "Striped (RAID 0)": [
  null,
  "ზოლებით (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "სარკისებური (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "ზოლებით და სარკისებურად (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "გამოყოფილი ლუწობა (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "განაწილებული ლუწობა (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "ორმაგად განაწილებული ლუწობა (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "ლოგიკური საცავი მთლიანად არ გამოიყენება."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "საცავის ზომაა $0. შემცველობის კი $1."
 ],
 "Shrink volume": [
  null,
  "ტომის შემცირება"
 ],
 "Layout": [
  null,
  "განლაგება"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა და ვეღარ გამოიყენებთ. საჭიროა, წაშალოთ ის და თავიდან შექმნათ."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "ამ ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა, მაგრამ მონაცემები ჯერ არა. შეაკეთეთ ის საწყისი საიმედოობის დასაბრუნებლად."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "ამ ლოგიკურმა ტომმა რამდენიმე ფიზიკური ტომი დაკარგა, მაგრამ მონაცემები ჯერ არა. წესით, მისი შეკეთება უნდა შეძლოთ."
 ],
 "Stripes": [
  null,
  "ზოლები"
 ],
 "$0 synchronized": [
  null,
  "$0 სინქრონიზებულია"
 ],
 "Create volume group": [
  null,
  "ტომების ჯგუფის შექმნა"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 ფიზიკური ტომი"
 ],
 "Last cannot be removed": [
  null,
  "ბოლოს ვერ წაშლით"
 ],
 "Not enough free space": [
  null,
  "თავისუფალი ადგილი საკმარისი არაა"
 ],
 "Volume group": [
  null,
  "ტომების ჯგუფი"
 ],
 "Create thin volume": [
  null,
  "თხელი ტომის შექმნა"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "თხლად გაწერილი LVM2 ლოგიკური ტომები"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "ახალი თხლად გამოყოფილი ლოგიკური ტომის შექმნა"
 ],
 "Not enough space": [
  null,
  "ადგილი საკმარისი არაა"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "პული თხლად გამოყოფილი LVM2 ლოგიკური ტომებისთვის"
 ],
 "Inactive logical volume": [
  null,
  "არააქტიური ლოგიკური ტომი"
 ],
 "Activate": [
  null,
  "აქტივაცია"
 ],
 "Unsupported logical volume": [
  null,
  "მხარდაუჭერელი ლოგიკური ტომი"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "შიდა შეცდომა - ეს ლოგიკური ტომი მონიშნულია, როგორც აქტიური და უნდა ჰქონდეს ასოცირებული ბლოკური მოწყობილობა. მაგრამ ასეთი ბლოკური მოწყობილობა აღმოჩენილი არაა."
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0-ის დაყენება წაშლის $1-ს."
 ],
 "Installing packages": [
  null,
  "პაკეტების დაყენება"
 ],
 "Block device for filesystems": [
  null,
  "ბლოკური მოწყობილობები ფაილური სისტემებისთვის"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "თხლად გაწერილი საცავების პული"
 ],
 "Linear": [
  null,
  "წრფივი"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ფაილური სისტემის საცავი (შეკუმშვა/დედუპლიკაცია)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "მონაცემები მონიშნულ ტომებზე დამატებითი საიმედოობის თუ წარმადობის გაზრდის გარეშე იქნება დამახსოვრებული."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ცვალებადი სახით, რათა წარმადობა გაიზარდოს. საჭიროა, მინიმუმ, 2 ტომი."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება ორი ან მეტი ასლის სახით მონიშნულ ფიზიკურ ტომებზე, რათა საიმედოობა გაზარდოს. საჭიროა, მინიმუმ, 2 ტომის მონიშვნა."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "მონაცემები 2 ასლად იქნება შენახული და კიდევ, ცვალებადი მიდგომით, მონიშნულ ფიზიკურ ტომებზე, რათა გაუმჯობესდეს ორივე, სანდოობა და წარმადობა. საჭიროა, მინიმუმ, 4 ტომის მონიშვნა."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "მონაცემები შეინახება მონიშნულ ფიზიკურ ტომებზე ისე, რომ შეგიძლიათ, ერთ-ერთი მათგანი მონაცემების დაკარგვის გარეშე დაკარგოთ. საჭიროა მინიმუმ 3 ტომი."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ისე, რომ ერთ-ერთი მათგანის დაკარგვა მონაცემების დაკარგვის გარეშე შეგიძლიათ. მონაცემები შენახული იქნება მონაცვლეობითი მიმდევრობით, წარმადობის გასაზრდელად. საჭიროა სულ ცოტა სამი ტომის მონიშვნა."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "მონაცემები შენახული იქნება მონიშნულ ფიზიკურ ტომებზე ისე, რომ, ერთდროულად, ორი მათგანი შეგეძლებათ დაკარგოთ, მონაცემების კარგვის გარეშე. მონაცემები შენახულია მონაცვლეობითი მიმდევრობით, რათა წარმადობა გაზარდოს. საჭიროა მინიმუმ ხუთი ტომის არჩევა."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "ყველა $0 მონიშნული ფიზიკური ტომია საჭირო არჩეული განლაგებისთვის."
 ],
 "Create logical volume": [
  null,
  "ლოგიკური ტომის შექმნა"
 ],
 "Purpose": [
  null,
  "დანიშნულება"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO მოწყობილობების შესაქმნელად დაყენდება პაკეტი $0."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10-ს ფიზიკური ტომების ლუწი რიცხვი სჭირდება"
 ],
 "Logical size": [
  null,
  "ლოგიკური ზომა"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ადგილის შენახვა ინდივიდუალური ბლოკების LZ4-ის საშუალებით შეკუმშვით"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ადგილის შენახვა მონაცემების ერთნაირი ბლოკების მხოლოდ ერთხელ შენახვის საშუალებით"
 ],
 "Creating VDO device": [
  null,
  "VDO მოწყობილობის შექმნა"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "NFS მიმაგრება უკვე გამოიყენება და მხოლოდ მისი პარამეტრების შეცვლა შეგიძლიათ."
 ],
 "NFS mount": [
  null,
  "NFS მიმაგრება"
 ],
 "New NFS mount": [
  null,
  "ახალი NFS მიმაგრება"
 ],
 "Server address": [
  null,
  "სერვერის მისამართი"
 ],
 "Server cannot be empty.": [
  null,
  "სერვერი არ შეიძლება ცარიელი იყოს."
 ],
 "Path on server": [
  null,
  "ბილიკი სერვერზე"
 ],
 "Path on server cannot be empty.": [
  null,
  "სერვერზე ბილიკის ველი არ შეიძლება ცარიელი იყოს."
 ],
 "Path on server must start with \"/\".": [
  null,
  "ბილიკი სერვერზე უნდა იწყებოდეს სიმბოლოთი \"/\"."
 ],
 "Local mount point": [
  null,
  "მიმაგრების ლოკალური წერტილი"
 ],
 "Mount point cannot be empty.": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს."
 ],
 "Mount point must start with \"/\".": [
  null,
  "მიმაგრების წერტილი უნდა იწყებოდეს \"/\"-ით."
 ],
 "Mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Mount at boot": [
  null,
  "ჩატვირთვისას მიმაგრება"
 ],
 "Mount read only": [
  null,
  "მიმაგრებულია, მხოლოდ წასაკითხად"
 ],
 "Custom mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Unable to unmount filesystem": [
  null,
  "ფაილური სისტემის მოძრობის შეცდომა"
 ],
 "Stop and unmount": [
  null,
  "გაჩერება და მოძრობა"
 ],
 "Unable to remove mount": [
  null,
  "მიმაგრების მოხსნის შეცდომა"
 ],
 "Stop and remove": [
  null,
  "გაჩერება და წაშლა"
 ],
 "(not mounted)": [
  null,
  "(მიმაგრებული არაა)"
 ],
 "Start multipath": [
  null,
  "multipath-ის გაშვება"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "სისმტეაში არის მოწყობილობები მრავალი ბილიკით, მაგრამ multipath სერვისი გაშვებული არაა."
 ],
 "Show all $0 rows": [
  null,
  "ყელა $0 მწკრივის ჩვენება"
 ],
 "Category": [
  null,
  "კატეგორია"
 ],
 "more info": [
  null,
  "მეტი ინფორმაცია"
 ],
 "Encryption": [
  null,
  "დაშიფვრა"
 ],
 "encrypted": [
  null,
  "დაშიფრულია"
 ],
 "Last modified: $0": [
  null,
  "ბოლოს შეიცვალა: $0"
 ],
 "Stored passphrase": [
  null,
  "დამახსოვრებული საკვანძო სიტყვა"
 ],
 "Encryption options": [
  null,
  "დაშიფვრის მორგება"
 ],
 "Encryption type": [
  null,
  "დაშიფვრის ტიპი"
 ],
 "Cleartext device": [
  null,
  "მოწყობილობის შექმნა"
 ],
 "yes": [
  null,
  "დიახ"
 ],
 "Disk passphrase": [
  null,
  "დისკის საკვანძო სიტყვა"
 ],
 "Passphrase cannot be empty": [
  null,
  "საკვანძო ფრაზა არ შეიძლება ცარიელი იყოს"
 ],
 "Unlocking disk": [
  null,
  "დისკის განბლოკვა"
 ],
 "Checking for $0 package": [
  null,
  "$0 პაკეტის შემოწმება"
 ],
 "The $0 package must be installed.": [
  null,
  "საჭიროა დაყენებული იყოს პაკეტი $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 პაკეტი ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "$0-ის დაყენების შეცდომა: PackageKit ან dnf5daemon-server დაყენებული არაა"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "მოულოდნელი PackageManager-ის შეცდომა $0-ის დაყენებისას: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Initrd-ში NBDE-ის მხარდაჭერის შემოწმება"
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd-ის თავიდან გენერაცია აუცილებელია."
 ],
 "Regenerating initrd": [
  null,
  "Initrd-ის თავიდან გენერაცია"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "ბირთვის ბრძანების სტრიქონში rd.neednet=1 -ის დამატება"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "\"$0\"-ის დამატება ფაილური სისტემის პარამეტრებში"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "\"$0\"-ის დამატება დაშიფვრის პარამეტრებში"
 ],
 "Enabling $0": [
  null,
  "$0-ის ჩართვა"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "ქსელზე მიბმული დისკის დაშიფვრის დამატება"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "სისტემას ამჟამად ჩატვირთვისას Tang-ის გასაღებების სერვერით root ფაილური სისტემის განბლოკვის მხარდაჭერა არ გააჩნია."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "სისტემას ამჟამად ჩატვირთვისას ფაილური სისტემის Tang-ის გასაღებების სერვერით განბლოკვის მხარდაჭერა არ გააჩნია."
 ],
 "These additional steps are necessary:": [
  null,
  "საჭიროა ეს დამატებითი ნაბიჯები:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "ახალი საკვანძო სიტყვის შესანახად საჭიროა დისკის განბლოკვა. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Fix NBDE support": [
  null,
  "NBDE-ის მხარდაჭერის გასწორება"
 ],
 "Adding key": [
  null,
  "გასაღების დამატება"
 ],
 "Key source": [
  null,
  "გასაღების წყარო"
 ],
 "Repeat passphrase": [
  null,
  "გაიმეორეთ საკვანძო სიტყვა"
 ],
 "Passphrase": [
  null,
  "საკვანძო სიტყვა"
 ],
 "Tang keyserver": [
  null,
  "გასაღებების სერვერი Tang"
 ],
 "New passphrase": [
  null,
  "ახალი საკვანძო ფრაზა"
 ],
 "Passphrases do not match": [
  null,
  "საკვანძო ფრაზები ერთმანეთს არ ემთხვევა"
 ],
 "Keyserver address": [
  null,
  "გასაღების სერვერის მისამართი"
 ],
 "Change passphrase": [
  null,
  "საკვანძო ფრაზის შეცვლა"
 ],
 "Old passphrase": [
  null,
  "ძველი საკვანძო ფრაზა"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang გასაღებების სერვერის ჩასწორება"
 ],
 "Verify key": [
  null,
  "გასაღების შემოწმება"
 ],
 "Trust key": [
  null,
  "ნდობის გასაღები"
 ],
 "Passphrase can not be empty": [
  null,
  "საკვანძო ფრაზა ცარიელი არ შეიძლება იყოს"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "საკვანძო ფრაზის მოცილებამ შეიძლება შეუძლებელი გახადოს $0-ის განბლოკვა."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "არასავალდებულო საკვნძო ფრაზის წაშლის დადასტურება"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "კვანძური ფრაზის წაშლას სხვა კვანძური ფრაზის ჩამატების გარეშე შეუძლია გამოიწვიოს გასაღებების მართვის დაბლოკვა, თუ სხვა საკვანძო ფრაზები დაგავწყდებათ."
 ],
 "Passphrase from any other key slot": [
  null,
  "საკვანძო ფრაზა ნებისმიერი სხვა გასაღების სლოტიდან"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "წავშალო საკვანძო ფრაზა გასაღების სლოტი $0-დან?"
 ],
 "Remove $0?": [
  null,
  "წავშალო $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "წაშლით, შეიძლება, დაკარგოთ $0-ის განბლოკვის საშუალება."
 ],
 "Remove Tang keyserver?": [
  null,
  "წავშალო Tang გასაღებების სერვერი?"
 ],
 "Remove key in slot $0?": [
  null,
  "წავშალო გასაღები სლოტში $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "ამჟამად შესულ მომხმარებელს არ აქვს უფლება გასაღებების შესახებ ინფორმაცია მოითხოვოს."
 ],
 "No keys added": [
  null,
  "გასაღებები არ დამატებულა"
 ],
 "Slot $0": [
  null,
  "სლოტი $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "გასაღების ჩასასწორებლად საჭიროა თავისუფალი სლოტი"
 ],
 "The last key slot can not be removed": [
  null,
  "ბოლო სლოტს ვერ წაშლით"
 ],
 "Keyserver": [
  null,
  "გასაღებების სერვერი"
 ],
 "Unknown type": [
  null,
  "უცნობი ტიპი"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "უცნობი ტიპის გასაღებების ჩასწორება შეუძლებელია"
 ],
 "Keys": [
  null,
  "გასაღებები"
 ],
 "$0 slot remains": [
  null,
  "დარჩენილია $0 სლოტი",
  "დარჩენილი სლოტების რაოდენობა $0"
 ],
 "No available slots": [
  null,
  "თავისუფალი სლოტი ხელმიუწვდომელია"
 ],
 "No free key slots": [
  null,
  "გასაღების თავისუფალი სლოტების გარეშე"
 ],
 "Locked data": [
  null,
  "დაბლოკილი მონაცემები"
 ],
 "lock": [
  null,
  "ჩაკეტვა"
 ],
 "Lock $0?": [
  null,
  "დავბლოკო $0?"
 ],
 "Address cannot be empty": [
  null,
  "მისამართი არ შეიძლება ცარიელი იყოს"
 ],
 "Address is not a valid URL": [
  null,
  "მისამართი არ წარმოადგენს სწორ URL-ს"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "გასაღების ჰეშის Tang სერვერთან შემოწმება."
 ],
 "How to check": [
  null,
  "როგორ შევამოწმო"
 ],
 "In a terminal, run: ": [
  null,
  "ტერმინალში გაუშვით: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "წარმატებით დაკოპირდა ბუფერში!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "შემწმება, ბრძანების სტრიქონიდან მოსული SHA-256 ან SHA-1 ჰეში ფანჯრისას თუ ემთხვევა."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs ქვეტომი $0 $1-დან"
 ],
 "Mount point cannot be empty": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს"
 ],
 "Mount point is already used for $0": [
  null,
  "მიმაგრების წერტილი უკვე გამოიყენება $0-თვის"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "ამ მიმაგრების წერტილის ქვეშ ფაილური სისტემები უკვე მიმაგრებულია."
 ],
 "Please unmount them first.": [
  null,
  "ჯერ ისინი მოხსენით."
 ],
 "read only": [
  null,
  "მხოლოდ კითხვისთვის"
 ],
 "never mount at boot": [
  null,
  "არასოდეს მიმაგრდება ჩატვირთვის დროს"
 ],
 "after network": [
  null,
  "ქსელის ჩართვის შემდეგ"
 ],
 "ignore failure": [
  null,
  "გამოტოვება შეცდომის შემთხვევაში"
 ],
 "stop boot on failure": [
  null,
  "შეცდომის შემთხვევაში ჩატვირთვის გაჩერება"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "ფაილურ სისტემას მინიჭებული მამაგრების წერტილი არ გააჩნია."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ფაილურ სისტემას მუდმივი მისამაგრებელი წერტილი არ გააჩნია."
 ],
 "The filesystem is not mounted.": [
  null,
  "ფაილური სისტემა მიმაგრებული არაა."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ფაილური სისტემა განიბლოკება და მიმაგრდება შემდეგი ჩატვირთვისას. ამას საკვანძო სიტყვის შეყვანა შეიძლება დასჭირდეს."
 ],
 "(no assigned mount point)": [
  null,
  "(მინიჭებული მიმაგრების წერტილის გარეშე)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ფაილური სისტემა ამჟამად მიმაგრებულია $0-ზე, მაგრამ შემდეგი ჩატვირთვისას მიმაგრებული იქნება $1-ზე."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "$0-ზე ავტომატურად მიმაგრება ჩატვირთვის დროს"
 ],
 "Mount on $0 now": [
  null,
  "$0-ზე მიმაგრება"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ფაილური სისტემა ახლა მიმაგრებული არაა, მაგრამ იქნება შემდეგი ჩატვირთვისას."
 ],
 "Do not mount automatically on boot": [
  null,
  "ჩატვირთვისას არ მიმაგრება"
 ],
 "Mount now": [
  null,
  "ახლა მიმაგრება"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ამჟამად ფაილური სისტემა მიმაგრებულია, მაგრამ შემდეგი ჩატვირთვისას აღარ იქნება."
 ],
 "Mount also automatically on boot": [
  null,
  "ავტომატური მიმაგრება ჩატვირთვის დროს"
 ],
 "Unmount now": [
  null,
  "მიმაგრების მოხსნა"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ფაილური სისტემა უკვე მიმაგრებულია $0-ზე, მაგრამ შემდეგი ჩატვირთვისას არ იქნება მიმაგრებული."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ფაილური სისტემა მორგებულია ჩატვირთვისას ავტომატურად მისამაგრებლად. მაგრამ დაშიფვრის მისი კონტეინერი ამ დროს განბლოკილი არ იქნება."
 ],
 "Unlock automatically on boot": [
  null,
  "ავტომატური განბლოკვა ჩატვირთვისას"
 ],
 "Inconsistent filesystem mount": [
  null,
  "ფაილური სისტემის არასწორი მიმაგრება"
 ],
 "$0 filesystem": [
  null,
  "ფაილური სისტემა $0"
 ],
 "Filesystem name": [
  null,
  "ფაილური სისტემის სახელი"
 ],
 "Filesystem is locked": [
  null,
  "ფაილური სისტემა ჩაკეტილია"
 ],
 "Mounts before services start": [
  null,
  "მიმაგრება სერვისების გაშვებამდე"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "სათანადოა კრიტიკული მიმაგრების წერტილებისთვის, როგორიცაა /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "ჩატვირთვა ავარიულია, თუ ფაილური სისტემა მიმაგრებული არ იქნება, რის შედეგადაც დაშორებული წვდომა არ გექნებათ"
 ],
 "Mounts in parallel with services": [
  null,
  "სერვისების გაშვებასთან ერთად მიმაგრება"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "ჩატვირთვა გაგრძელდება, თუ ფაილური სისტემა მიმაგრებული არაა"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "მიმაგრება სერვისების გაშვებასთან ერთად მას შემდეგ, რაც ქსელი ჩაირთვება"
 ],
 "Does not mount during boot": [
  null,
  "ჩატვირთვისას არ მიმაგრება"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "გამოსადეგია მიმაგრების წერტილებისთვის, რომლებიც სავალდებული არაა და ჩარევას საჭიროებს (მაგ: საკვანძო სიტყვის შეყვანას)"
 ],
 "At boot": [
  null,
  "ჩატვირთვისას"
 ],
 "Mount before services start": [
  null,
  "მიმაგრება სერვისების გაშვებამდე"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "მიმაგრება დალოდების გარეშე. გამოტოვება შეცდომის შემთხვევაში"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "მიმაგრება ქსელის ჩართვის შემდეგ. გამოტოვება შეცდომის შემთხვევაში"
 ],
 "Do not mount": [
  null,
  "არ მიამაგრო"
 ],
 "This device can not be used for the installation target.": [
  null,
  "ამ მოწყობილობას დაყენების სამიზნედ ვერ გამოიყენებთ."
 ],
 "Mount filesystem": [
  null,
  "ფაილური სისტემის მიმაგრება"
 ],
 "Unmount filesystem $0": [
  null,
  "ფაილური სისტემის მოძრობა: $0"
 ],
 "Mount configuration": [
  null,
  "მიმაგრების კონფიგურაცია"
 ],
 "Swap": [
  null,
  "სვაპი"
 ],
 "Used": [
  null,
  "გამოყენებულია"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Stratis-ის დაშიფრული პულის განბლოკვა"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "შეიყვანეთ საკვანძო ფრაზა ამ ბლოკური მოწყობილობების პულისტვის:"
 ],
 "Stratis pool": [
  null,
  "Startis-ის პული"
 ],
 "stopped": [
  null,
  "გაჩერებულია"
 ],
 "Block devices": [
  null,
  "ბლოკური მოწყობილობები"
 ],
 "No block devices found": [
  null,
  "ბლოკური მოწყობილობები აღმოჩენილი არაა"
 ],
 "Stratis block devices": [
  null,
  "Stratis-ის ბლოკური მოწყობილობები"
 ],
 "Stratis block device": [
  null,
  "Stratis-ის ბლოკური მოწყობილობა"
 ],
 "data": [
  null,
  "მონაცემები"
 ],
 "cache": [
  null,
  "კეში"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "შეიყვანეთ არსებული პულის საკვანძო ფრაზა."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "თუ გასაღებების სერვერი $0 ხელმისაწვდომი არაა, შეგიძლიათ, არსებული საკვანძო ფრაზა შეიყვანოთ."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "თუ გასაღებების სერვერები ხელმისაწვდომი არაა, შეგიძლიათ, არსებული საკვანძო ფრაზა შეიყვანოთ."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "თუ არაინტერაქტიული განბლოკვის მეთოდები არ მუშაობს, შეგიძლიათ, არსებული საკვანძო ფრაზა შეიყვანოთ."
 ],
 "Pool passphrase": [
  null,
  "პულის საკვანძო ფრაზა"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "გასაღებების სერვერი $0 ხელმისაწვდომი უნდა იყოს."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "ხელმისაწვდომი უნდა იყოს, სულ ცოტა, ერთი გასაღებების სერვერი."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "უნდა მუშაობდეს სულ ცოტა ერთი არაინტერაქტიული განბლოკვის მეთოდი."
 ],
 "Create filesystem": [
  null,
  "ფაილური სისტემის შექმნა"
 ],
 "Stratis filesystem": [
  null,
  "Stratis-ის ფაილური სისტემა"
 ],
 "Set initial size": [
  null,
  "საწყისი ზომის დაყენება"
 ],
 "Limit size": [
  null,
  "ლიმიტის ზომა"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis-ის პულის წაშლა მასზე ჩაწერილი მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Rename Stratis pool": [
  null,
  "Stratis-ის პულისთვის სახელის გადარქმევა"
 ],
 "Add block devices": [
  null,
  "ბლოკური მოწყობილობების დამატება"
 ],
 "Tier": [
  null,
  "კლასი"
 ],
 "Data": [
  null,
  "მონაცემები"
 ],
 "Cache": [
  null,
  "ქეში"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "ბლოკური მოწყობილობების დამატებას პულის განბლოკვა სჭირდება."
 ],
 "Encrypted Stratis pool": [
  null,
  "სტრატისის დაშიფრული პული"
 ],
 "Delete pool": [
  null,
  "პულის წაშლა"
 ],
 "Encryption tokens": [
  null,
  "დაშიფვრის კოდები"
 ],
 "Stratis filesystems": [
  null,
  "Stratis-ს ფაილური სისტემები"
 ],
 "Create new filesystem": [
  null,
  "ახალი ფაილური სისტემის შექმნა"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "ეს პული მის ბლოკურ მოწყობილობებზე არსებულ ადგილს ბოლომდე არ იყენებს."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "ამ პულში ზოგიერთი ბლოკური მოწყობილობა ზომაში პულის შექმნის შემდეგ გაიზარდა. პულის გაზრდა დამატებული ადგილის გამოსაყენებლად უსაფრთხოა."
 ],
 "Grow the pool to take all space": [
  null,
  "პულის გადიდება მაქს. შესაძლო ზომამდე"
 ],
 "This pool is in a degraded state.": [
  null,
  "ეს პულ ავარიულ მდგომარეობაშია."
 ],
 "No filesystems": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis-ის ფაილური სისტემების პული"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "ეს საკვანძო ფრაზა ამ პულის განბლოკვისთვის ერთად-ერთი საშუალებაა და მისი წაშლა შეუძლებელია."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "ეს გასაღებების სერვერი ამ პულის განბლოკვის ერთად-ერთი საშუალებაა და მისი წაშლა შეუძლებელია."
 ],
 "Add passphrase": [
  null,
  "საკვანძო ფრაზის დამატება"
 ],
 "Add keyserver": [
  null,
  "გასაღებების სერვერის დამატება"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "ბოლო კოდს ვერ წაშლით"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "საკვანძო ფრაზებისთვის და გასაღებების სერვერისთვის ადგილი აღარაა."
 ],
 "Confirm": [
  null,
  "დასტური"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "საკვანძო ფრაზის დამატებას პულის განბლოკვა სჭირდება."
 ],
 "Remove passphrase?": [
  null,
  "წავშალო საკვანძო სიტყვა?"
 ],
 "Add Tang keyserver": [
  null,
  "Tang გასაღებების სერვერის დამატება"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "ახალი გასაღებების სერვერის დამატებას პულის განბლოკვა სჭირდება."
 ],
 "Remove Clevis token?": [
  null,
  "წავშალო Clevis-ის კოდი?"
 ],
 "Metadata format": [
  null,
  "მეტამონაცემების ფორმატი"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "მეტამონაცემების ფორმატის V1 მქონე პულები ერთ საკვანძო ფრაზაზე და ერთ გასაღებების სერვერზეა შეზღუდული."
 ],
 "Overprovisioning": [
  null,
  "სამუშაოდ მომზადების გადამეტტვირთვა"
 ],
 "Allow overprovisioning": [
  null,
  "სამუშაოდ მომზადების გადამეტტვირთვის დაშვება"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "ვირტუალური ფაილური სისტემის ზომები პულზე დიდია. სამუშაოდ მომზადების გადამეტტვირთვას ვერ გათიშავთ."
 ],
 "Allocated": [
  null,
  "გამოყოფილი"
 ],
 "Name can not be empty.": [
  null,
  "სახელი არ შეიძლება ცარიელი იყოს."
 ],
 "A pool with this name exists already.": [
  null,
  "პული ამ სახელით უკვე არსებობს."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "ფაილური სისტემა ამ სახელით მითითებულ პულში უკვე არსებობს."
 ],
 "Create Stratis pool": [
  null,
  "Stratis-ის პულის შექმნა"
 ],
 "No block devices are available.": [
  null,
  "ბლოკური მოწყობილობები ხელმიუწვდომელია."
 ],
 "At least one block device is needed.": [
  null,
  "საჭიროა ერთი ბლოკური ტიპის მოწყობილობა მაინც."
 ],
 "Encrypt data with a passphrase": [
  null,
  "დაშიფვრა საკვანძო ფრაზით"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "მონაცემების დაშიფვრა Tang-ის გასაღებების სერვერით"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ფაილური სისტემა $0-ის მყისიერი ასლის გადაღება"
 ],
 "Create snapshot and mount": [
  null,
  "სწრაფი ასლის შექმნა და მიმაგრება"
 ],
 "Create snapshot only": [
  null,
  "მხოლოდ სწრაფი ასლის შექმნა"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ფაილური სისტემის წაშლა მასზე არსებული მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Snapshot": [
  null,
  "სწრაფი ასლი"
 ],
 "Rename filesystem": [
  null,
  "ფაილური სისტემის სახელის გადარქმევა"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "დააყენეთ ლიმიტი ვირტუალური ფაილური სისტემის ზომაზე"
 ],
 "Limit virtual filesystem size": [
  null,
  "ფაილური სისტემის ზომის ლიმიტი"
 ],
 "Virtual size limit": [
  null,
  "ვირტუალური ზომის ზღვარი"
 ],
 "Virtual size": [
  null,
  "ვირტუალური ზომა"
 ],
 "Create RAID device": [
  null,
  "RAID მოწყობილობის შექმნა"
 ],
 "RAID level": [
  null,
  "RAID-ის დონე"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (სარკე)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (გამოყოფილი ლუწობა)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (განაწილებული ლუწობა)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ორმაგად განაწილებული ლუწობა)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (სარკეების ზოლები)"
 ],
 "Chunk size": [
  null,
  "ბლოკის ზომა"
 ],
 "4 KiB": [
  null,
  "4 კიბ"
 ],
 "8 KiB": [
  null,
  "8 კიბ"
 ],
 "16 KiB": [
  null,
  "16 კიბ"
 ],
 "32 KiB": [
  null,
  "32 კიბ"
 ],
 "64 KiB": [
  null,
  "64 კიბ"
 ],
 "128 KiB": [
  null,
  "128 კიბ"
 ],
 "512 KiB": [
  null,
  "512 კიბ"
 ],
 "1 MiB": [
  null,
  "1 მიბ"
 ],
 "2 MiB": [
  null,
  "2 მიბ"
 ],
 "At least $0 disk is needed.": [
  null,
  "საჭიროა $0 დისკი მაინც.",
  "საჭიროა $0 ცალი დისკი მაინც."
 ],
 "MDRAID disk": [
  null,
  "MDRAID დისკი"
 ],
 "In sync": [
  null,
  "სინქრონიზებულია"
 ],
 "Spare": [
  null,
  "მარქაფი"
 ],
 "Recovering": [
  null,
  "აღდგენა"
 ],
 "Write-mostly": [
  null,
  "ძირითადად-ჩაწერა"
 ],
 "Blocked": [
  null,
  "დაბლოკილია"
 ],
 "Unknown ($0)": [
  null,
  "უცნობი ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID მოწყობილობა გაშვებული უნდა იყოს"
 ],
 "MDRAID device is recovering": [
  null,
  "მიმდინარეობს MDRAID მოწყობილობის აღდგენა"
 ],
 "Need a spare disk": [
  null,
  "საჭიროა სათადარიგო დისკი"
 ],
 "Last disk can not be removed": [
  null,
  "ბოლო დისკს ვერ წაშლით"
 ],
 "MDRAID device": [
  null,
  "MDRAID მოწყობილობა"
 ],
 "Confirm stopping of $0": [
  null,
  "დაადასტურეთ $0-ის გაჩერება"
 ],
 "Stop device": [
  null,
  "მოწყობილობის გაჩერება"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "MDRAID მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID მოწყობილობა გაშვებული უნდა იყოს"
 ],
 "Add disk": [
  null,
  "დისკის დამატება"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 დისკი"
 ],
 "$0 chunk size": [
  null,
  "ნაგლეჯის ზომა $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID მოწყობილობა ავარიულ მდგომარეობაშია"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "ამ MDRAID მოწყობილობას wirte-intent ბიტური რუკა არ გააჩნია. ასეთ ბიტურ რუკას სინქრონიზაციის დრო საგრძნობლად შეუძლია, შეამციროს."
 ],
 "Add a bitmap": [
  null,
  "ბიტური რუკის დამატება"
 ],
 "No disks found": [
  null,
  "დისკები ვერ ვიპოვე"
 ],
 "MDRAID disks": [
  null,
  "MDRAID დისკები"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "VDO მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე ყველა მონაცემი."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "VDO მოწყობილობის შექმნა გაუქმებულია. მოწყობილობის გამოყენება შეუძლებელია."
 ],
 "Remove device": [
  null,
  "მოწყობილობის წაშლა"
 ],
 "Grow to take all space": [
  null,
  "გადიდება მაქს. შესაძლო ზომამდე"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "VDO მოწყობილობა თავის ყველა ზურგის მოწყობილობას არ იყენებს."
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1-დან გამოყენებულია მხოლოდ $0."
 ],
 "Grow logical size of $0": [
  null,
  "$0-ის ლოგიკური ზომის გადიდება"
 ],
 "Physical": [
  null,
  "ფიზიკური"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 მონაცემები + $1 დამატებით გამოყენებული $2 ($3)"
 ],
 "Logical": [
  null,
  "ლოგიკური"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "გამოყენებულია $0 $1-დან (შენახულია $2)"
 ],
 "Index memory": [
  null,
  "ინდექსების მეხსიერება"
 ],
 "SMART self-test of $target": [
  null,
  "$target-ის SMART თვითშემოწმების გაშვება"
 ],
 "Ejecting $target": [
  null,
  "$target-ის გამოგდება"
 ],
 "Unlocking $target": [
  null,
  "$target-ის განბლოკვა"
 ],
 "Locking $target": [
  null,
  "$target-ის ჩაკეტვა"
 ],
 "Modifying $target": [
  null,
  "$target-ის ჩასწორება"
 ],
 "Resizing $target": [
  null,
  "$target-ის ზომის შესვლა"
 ],
 "Starting swapspace $target": [
  null,
  "სვაპის ($target) გაშვება"
 ],
 "Stopping swapspace $target": [
  null,
  "სვაპის ($target) გაჩერება"
 ],
 "Mounting $target": [
  null,
  "$target-ის მიმაგრება"
 ],
 "Unmounting $target": [
  null,
  "$target-ის მიმაგრების მოხსნა"
 ],
 "Checking $target": [
  null,
  "$target-ის შემოწმება"
 ],
 "Repairing $target": [
  null,
  "$target-ის შეკეთება"
 ],
 "Erasing $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Creating filesystem on $target": [
  null,
  "$target-ზე ფაილური სისტემის შექმნა"
 ],
 "Setting up loop device $target": [
  null,
  "$target-ზე მარყუჟული მოწყობილობის შექმნა"
 ],
 "Deleting $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Creating partition $target": [
  null,
  "დანაყოფის შექმნა $target"
 ],
 "Cleaning up for $target": [
  null,
  "$target-ის გასუფთავება"
 ],
 "Securely erasing $target": [
  null,
  "$target-ის გარანტირებული წაშლა"
 ],
 "Very securely erasing $target": [
  null,
  "$target-ის ძალიან უსაფრთხოდ წაშლა"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის გაჩერება"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის გაშვება"
 ],
 "Marking $target as faulty": [
  null,
  "$target-ის გაფუჭებულად მონიშვნა"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target-ის MDRAID მოწყობილობიდან მოცილება"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის შექმნა"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID მოწყობილობის, $target-ის შემოწმება"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის შემოწმება და შეკეთება"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის აღდგენა"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID მოწყობილობა $target-ის სინქრონიზაცია"
 ],
 "Activating $target": [
  null,
  "$target-ის აქტივაცია"
 ],
 "Deactivating $target": [
  null,
  "$target-ის დეაქტივაცია"
 ],
 "Creating snapshot of $target": [
  null,
  "$target-ის სწრაფი ასლის შექმნა"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $target-ის შექმნა"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $target-ის წაშლა"
 ],
 "Adding physical volume to $target": [
  null,
  "$target-ზე ფიზიკური მოცულობების დამატება"
 ],
 "Removing physical volume from $target": [
  null,
  "$target-დან ფიზიკური საცავის მოცილება"
 ],
 "Emptying $target": [
  null,
  "$target-ის დაცარიელება"
 ],
 "Creating logical volume $target": [
  null,
  "ლოგიკური საცავს $target-ის შექმნა"
 ],
 "Renaming $target": [
  null,
  "$target-ის სახელის გადარქმევა"
 ],
 "Operation '$operation' on $target": [
  null,
  "ოპერაცია '$operation' $target-ზე"
 ],
 "unknown target": [
  null,
  "უცნობი სამიზნე ობიექტი"
 ],
 "Jobs": [
  null,
  "ამოცანები"
 ],
 "Reading": [
  null,
  "ვკითხულობ"
 ],
 "Writing": [
  null,
  "ჩაწერა"
 ],
 "Install Stratis support": [
  null,
  "Stratis-ის მხარდაჭერის დაყენება"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis-ის პულის შესაქმნელად საჭიროა დაყენებული იყოს პაკეტი $0."
 ],
 "Install NFS support": [
  null,
  "NFS-ის მხარდაჭერის დაყენება"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID მოწყობილობის შექმნა"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 საცავის ჯგუფის შექმნა"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI ინიციატორის სახელის შეცვლა"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI პორტალის დამატება"
 ],
 "Local storage": [
  null,
  "ლოკალური საცავი"
 ],
 "Networked storage": [
  null,
  "ქსელური საცავი"
 ],
 "Create storage device": [
  null,
  "საცავის მოწყობილობების შექმნა"
 ],
 "No storage found": [
  null,
  "საცავი ვერ ვიპოვე"
 ],
 "Server address cannot be empty.": [
  null,
  "სერვერის მისამართი ცარიელი არ შეიძლება იყოს."
 ],
 "Next": [
  null,
  "შემდეგი"
 ],
 "Invalid username or password": [
  null,
  "არასწორი მომხმარებელი ან პაროლი"
 ],
 "Unknown host name": [
  null,
  "ჰოსტის უცნობი სახელი"
 ],
 "Unable to reach server": [
  null,
  "სერვერამდე მიღწევის შეცდომა"
 ],
 "Available targets on $0": [
  null,
  "ხელმისაწვდომი სამიზნე $0-ზე"
 ],
 "Authentication required": [
  null,
  "საჭიროა ავთენტიკაცია"
 ],
 "iSCSI portal": [
  null,
  "iSCSI პორტალი"
 ],
 "iSCSI drives": [
  null,
  "iSCSI დისკები"
 ],
 "No drives found": [
  null,
  "ამძრავები ვერ ვიპოვე"
 ],
 "Target": [
  null,
  "სამიზნე"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ის მხარდამჭერი მოწყობილობები მეტად ვეღარ დაპატარავდება"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis ბლოკური მოწყობილობები მეტად ვეღარ დაპატარავდება"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "აქ უცნობი მონაცემების დაპატარავება შეუძლებელია."
 ],
 "Unlock before resizing": [
  null,
  "განბლოკვა ზომის შეცვლამდე"
 ],
 "$0 can not be resized here": [
  null,
  "$0-ის ზომას აქ ვერ შეცვლით"
 ],
 "$0 can not be resized": [
  null,
  "$0 ზომას ვერ შეცვლით"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 მეტად ვეღარ დაპატარავდება"
 ],
 "$0 can not be made larger": [
  null,
  "$0 მეტად ვეღარ გაიზრდება"
 ],
 "Physical volumes can not be resized here": [
  null,
  "ფიზიკურ ტომებს აქ ადგილს ვერ შეუცვლით"
 ],
 "Swap can not be resized here": [
  null,
  "სვოპის ზომას აქ ვერ შეცვლით"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "აქ უცნობი მონაცემების დაპატარავება შეუძლებელია"
 ],
 "Activate before resizing": [
  null,
  "აქტივაცია ზომის შეცვლამდე"
 ],
 "Grow logical volume": [
  null,
  "ლოგიკური ტომის გაზრდა"
 ],
 "Grow partition": [
  null,
  "დანაყოფის გაზრდა"
 ],
 "grow": [
  null,
  "გაზრდა"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "საჭიროა ზუსტად $0 ფიზიკური ტომის მონიშვნა"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "დაშიფრული ფაილური სისტემის ზომის შეცვლას ჯერ დისკის განბლოკვა სჭირდება. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "საჭიროა ზუსტად $0 ფიზიკური ტომის მონიშვნა, თითო ზოლი თითო ლოგიკური ტომისთვის."
 ],
 "Shrink logical volume": [
  null,
  "ლოგიკური ტომის შემცირება"
 ],
 "shrink": [
  null,
  "შემცირება"
 ],
 "Unformatted data": [
  null,
  "დაუფორმატებელი მონაცემები"
 ],
 "Block device": [
  null,
  "ბლოკური მოწყობილობა"
 ],
 "Device number": [
  null,
  "მოწყობილობის ნომერი"
 ],
 "Create partition on $0": [
  null,
  "$0-ზე სექციის შექმნა"
 ],
 "Format $0": [
  null,
  "$0-ის დაფორმატება"
 ],
 "No filesystem": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "(recommended)": [
  null,
  "(რეკომენდებულია)"
 ],
 "No encryption": [
  null,
  "დაშიფვრის გარეშე"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "არსებული დაშიფვრის ($0) გამოყენება"
 ],
 "Reuse existing encryption": [
  null,
  "არსებული დაშიფვრის გამოყენება"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "Format and mount": [
  null,
  "დაფორმატება და მიმაგრება"
 ],
 "Format only": [
  null,
  "მხოლოდ დაფორმატება"
 ],
 "Format": [
  null,
  "ფორმატი"
 ],
 "Create and start": [
  null,
  "შექმნა და გაშვება"
 ],
 "Format and start": [
  null,
  "დაფორმატება და გაშვება"
 ],
 "Store passphrase": [
  null,
  "საკვანძო სიტყვის დამახსოვრება"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "დაფორმატებამდე საჭიროა დისკის განბლოკვა. შეიყვანეთ საკვანძო ფრაზა."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "ფორმატირება ბლოკურ მოწყობილობაზე მდებარე ყველა მონაცემს წაშლის."
 ],
 "Unrecognized data": [
  null,
  "შეუცნობელი მონაცემები"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ამ სისტემაზე საცავის მართვა შეუძლებელია."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ. დამპის მხარდაჭერილი სამიზნეებია: \"local\" (დისკი), \"ssh\" და \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "format-bytes\u0004bytes": [
  null,
  "ბაიტი"
 ]
});
