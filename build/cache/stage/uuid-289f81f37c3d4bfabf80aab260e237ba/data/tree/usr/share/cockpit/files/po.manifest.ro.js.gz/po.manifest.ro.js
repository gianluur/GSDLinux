cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Navigator de fișiere"
 ],
 "files": [
  null,
  "fișiere"
 ],
 "explorer": [
  null,
  "explorare"
 ],
 "filesystem": [
  null,
  "sistem de fișiere"
 ]
});
