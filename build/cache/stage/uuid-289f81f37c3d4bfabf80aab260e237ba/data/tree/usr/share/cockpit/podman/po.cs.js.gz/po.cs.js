cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Smazat $0?"
 ],
 "Force delete": [
  null,
  "Vynutit smazání"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Must be a valid IP address": [
  null,
  "Je třeba, aby byla platná IP adresa"
 ],
 "1 to 65535": [
  null,
  "1 až 65535"
 ],
 "Container port must not be empty": [
  null,
  "Je třeba vyplnit port kontejneru"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address help": [
  null,
  "Nápověda k IP adrese"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Pokud je IP adresa hostitele nastavena na 0.0.0.0 nebo vůbec nenastavena, port bude navázán na všechny IP adresy hostitele."
 ],
 "Host port": [
  null,
  "Port hostitele"
 ],
 "Host port help": [
  null,
  "Nápověda k portu hostitele"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Pokud port hostitele není nastavený, port kontejneru bude náhodně přiřazen na port hostitele."
 ],
 "Container port": [
  null,
  "Port kontejneru"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Odebrat položku"
 ],
 "Image name is required": [
  null,
  "Je třeba zadat název obrazu"
 ],
 "Image name is not unique": [
  null,
  "Název obrazu už je použit"
 ],
 "Failed to commit container $0": [
  null,
  "Nepodařilo se odeslat kontejner $0"
 ],
 "New image name": [
  null,
  "Název nového obrazu"
 ],
 "Tag": [
  null,
  "Štítek"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Příklad, vaše jméno <vasejmeno@example.com>"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "Options": [
  null,
  "Volby"
 ],
 "Pause container when creating image": [
  null,
  "Při vytváření obrazu pozastavit kontejner"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Formát Docker se hodí pro sdílení obrazu s enginem Docker nebo Moby"
 ],
 "Use legacy Docker format": [
  null,
  "Použít původní Docker formát"
 ],
 "Commit container": [
  null,
  "Odeslat kontejner"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Vytvořit nový obraz založený na stávajícím stavu kontejneru $0."
 ],
 "Commit": [
  null,
  "Odeslat"
 ],
 "Force commit": [
  null,
  "Vynutit odeslání"
 ],
 "Failed to force remove container $0": [
  null,
  "Nepodařilo se vynutit odebrání kontejneru $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Smazání spuštěného kontejneru smaže veškerá data v něm."
 ],
 "Failed to stop container $0": [
  null,
  "Nepodařilo se zastavit kontejner $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Nepodařilo se zastavit quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Nepodařilo se spustit quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Nepodařilo se spustit kontejner $0"
 ],
 "Failed to resume container $0": [
  null,
  "Nepodařilo se navázat v chodu kontejneru $0"
 ],
 "Failed to pause container $0": [
  null,
  "Nepodařilo se pozastavit kontejner $0"
 ],
 "Failed to restart container $0": [
  null,
  "Nepodařilo se restartovat kontejner $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Nepodařilo se restartovat quadlet $0"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Restart": [
  null,
  "Restart"
 ],
 "Force stop": [
  null,
  "Vynutit zastavení"
 ],
 "Force restart": [
  null,
  "Vynutit restart"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Resume": [
  null,
  "Navázat v chodu"
 ],
 "Checkpoint": [
  null,
  "Kontrolní bod"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Restore": [
  null,
  "Obnovit"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Healthy": [
  null,
  "V pořádku"
 ],
 "Unhealthy": [
  null,
  "Není v pořádku"
 ],
 "Checking health": [
  null,
  "Kontroluje se stav"
 ],
 "Prune unused containers": [
  null,
  "Prořezat nepoužívané kontejnery"
 ],
 "Terminal not available": [
  null,
  "Terminál není k dispozici"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Tento prohlíčeč nepodporuje WebGL2."
 ],
 "View $0 logs": [
  null,
  "Zobrazit záznamy událostí z $0"
 ],
 "not available": [
  null,
  "není k dispozici"
 ],
 "n/a": [
  null,
  "n/a"
 ],
 "$0% of $1 limit": [
  null,
  "$0% z limitu $1"
 ],
 "service": [
  null,
  "služba"
 ],
 "system": [
  null,
  "systém"
 ],
 "user:": [
  null,
  "uživatel:"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Integration": [
  null,
  "Napojení"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Console": [
  null,
  "Konzole"
 ],
 "Health check": [
  null,
  "Kontrola vitálnosti"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "Memory": [
  null,
  "Operační paměť"
 ],
 "Click to see published ports": [
  null,
  "Kliknutím zobrazíte publikované porty"
 ],
 "ports": [
  null,
  "porty"
 ],
 "Click to see volumes": [
  null,
  "Kliknutím zobrazíte svazky"
 ],
 "volumes": [
  null,
  "svazky"
 ],
 "Container": [
  null,
  "Kontejner"
 ],
 "Owner": [
  null,
  "Vlastník"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "No containers": [
  null,
  "Žádné kontejnery"
 ],
 "No containers in this pod": [
  null,
  "V tomto podu nejsou žádné kontejnery"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "No containers that match the current filter": [
  null,
  "Stávajícímu filtru neodpovídají žádné kontejnery"
 ],
 "No running containers": [
  null,
  "Žádné spuštěné kontejnery"
 ],
 "Show": [
  null,
  "Zobrazit"
 ],
 "All": [
  null,
  "Vše"
 ],
 "Only running": [
  null,
  "Pouze spuštěné"
 ],
 "Create pod": [
  null,
  "Vytvořit pod"
 ],
 "Create container": [
  null,
  "Vytvořit kontejner"
 ],
 "Containers": [
  null,
  "Kontejnery"
 ],
 "Create container in pod": [
  null,
  "Vytvořit kontejner v podu"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Nepodařilo se obnovit kontejner $0"
 ],
 "Restore container $0": [
  null,
  "Obnovit kontejner $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Ponechat všechny dočasné soubory kontrolních bodů"
 ],
 "Restore with established TCP connections": [
  null,
  "Obnovit s navázanými TCP spojeními"
 ],
 "Ignore IP address if set statically": [
  null,
  "Pokud je nastavená staticky, IP adresu ignorovat"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Pokud je nastavená staticky, MAC adresu ignorovat"
 ],
 "Pod failed to be created": [
  null,
  "Pod se nepodařilo vytvořit"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Neplatné znaky. Název může obsahovat pouze písmena, číslice a vybranou interpunkci (_.-)."
 ],
 "Name": [
  null,
  "Název"
 ],
 "Pod name": [
  null,
  "Název pro pod"
 ],
 "System": [
  null,
  "Systém"
 ],
 "User:": [
  null,
  "Uživatel:"
 ],
 "No ports exposed": [
  null,
  "Nejsou vystavené žádné porty"
 ],
 "Port mapping": [
  null,
  "Mapování portů"
 ],
 "Add port mapping": [
  null,
  "Přidat mapování portů"
 ],
 "No volumes specified": [
  null,
  "Nejsou určeny žádné svazky"
 ],
 "Volumes": [
  null,
  "Svazky"
 ],
 "Add volume": [
  null,
  "Přidat svazek"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Type to filter…": [
  null,
  "Filtrujte psaním…"
 ],
 "Container path must not be empty": [
  null,
  "Je třeba vyplnit popis umístění kontejneru"
 ],
 "Host path": [
  null,
  "Popis umístění hostitele"
 ],
 "Container path": [
  null,
  "Popis umístění kontejneru"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Writable": [
  null,
  "Zapisovatelné"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Žádný štítek"
 ],
 "Shared": [
  null,
  "Sdílené"
 ],
 "Private": [
  null,
  "Soukromé"
 ],
 "Read-write access": [
  null,
  "Přístup pro čtení i zápis"
 ],
 "Read-only access": [
  null,
  "Přístup pouze pro čtení"
 ],
 "Show less": [
  null,
  "Zobrazit méně"
 ],
 "Show more": [
  null,
  "Zobrazit více"
 ],
 "Loading details...": [
  null,
  "Načítání podrobností…"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Environment variables": [
  null,
  "Proměnné prostředí"
 ],
 "Failed to download image $0:$1": [
  null,
  "Nepodařilo se stáhnout obraz $0:$1"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "unused": [
  null,
  "nepoužito"
 ],
 "$0 container": [
  null,
  "$0 kontejner",
  "$0 kontejnery",
  "$0 kontejnerů"
 ],
 "History": [
  null,
  "Historie"
 ],
 "Image": [
  null,
  "Obraz"
 ],
 "Created": [
  null,
  "Vytvořeno"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Disk space": [
  null,
  "Prostor na disku"
 ],
 "Used by": [
  null,
  "Používáno"
 ],
 "No images": [
  null,
  "Žádné obrazy"
 ],
 "No images that match the current filter": [
  null,
  "Žádné obrazy které by odpovídaly stávajícímu filtru"
 ],
 "Hide intermediate images": [
  null,
  "Skrýt obrazy mezi tím"
 ],
 "Show intermediate images": [
  null,
  "Zobrazit obrazy mezi tím"
 ],
 "Images": [
  null,
  "Obrazy"
 ],
 "$0 image total, $1": [
  null,
  "$0 obraz celkem, $1",
  "$0 obrazy celkem, $1",
  "$0 obrazů celkem, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 nepoužitý obraz, $1",
  "$0 nepoužité obrazy, $1",
  "$0 nepoužitých obrazů, $1"
 ],
 "Hide images": [
  null,
  "Skrýt obrazy"
 ],
 "Show images": [
  null,
  "Zobrazit obrazy"
 ],
 "Pulling": [
  null,
  "Stahování"
 ],
 "Download new image": [
  null,
  "Stáhnout si nový obraz"
 ],
 "Pull all images": [
  null,
  "Natáhnout veškeré obrazy"
 ],
 "Prune unused images": [
  null,
  "Prořezat nepoužívané obrazy"
 ],
 "Pull": [
  null,
  "Natáhnout"
 ],
 "Up since:": [
  null,
  "V chodu od:"
 ],
 "Exited": [
  null,
  "Skončilo"
 ],
 "systemd service": [
  null,
  "systemd služba"
 ],
 "View $0": [
  null,
  "Zobrazit $0"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "MAC address": [
  null,
  "MAC adresa"
 ],
 "Latest checkpoint": [
  null,
  "Nejnovější kontrolní bod"
 ],
 "No containers are using this image": [
  null,
  "Tento obraz není používán žádným kontejnerem"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "Loading logs...": [
  null,
  "Načítání záznamů událostí…"
 ],
 "Delete unused system images:": [
  null,
  "Smazat nepoužívané systémové obrazy:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Smazat nepoužité obrazy uživatele $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Nepodařilo se prořezat nepoužívané obrazy"
 ],
 "Pruning images": [
  null,
  "Prořezávají se obrazy"
 ],
 "Prune": [
  null,
  "Prořezat"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kontejner $0 se nepodařilo opatřit kontrolním bodem"
 ],
 "Checkpoint container $0": [
  null,
  "Kontejner kontrolního bodu $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Po zapsání kontrolního bodu na disk ponechat spuštěné"
 ],
 "Support preserving established TCP connections": [
  null,
  "Podpora pro zachování navázaných TCP spojení"
 ],
 "Failed to search for new images": [
  null,
  "Nepodařilo se vyhledat nové obrazy"
 ],
 "Failed to search for images: $0": [
  null,
  "Nepodařilo se vyhledat obrazy: $0"
 ],
 "Failed to search for images.": [
  null,
  "Nepodařilo se vyhledat obrazy."
 ],
 "Search for an image": [
  null,
  "Hledat obraz"
 ],
 "Search for": [
  null,
  "Hledat"
 ],
 "Search by name or description": [
  null,
  "Hledat podle názvu nebo popisu"
 ],
 "in": [
  null,
  "v"
 ],
 "All registries": [
  null,
  "Všechny registry"
 ],
 "Searching...": [
  null,
  "Vyhledávání..."
 ],
 "No images found": [
  null,
  "Nenalezeny žádné obrazy"
 ],
 "Start typing to look for images.": [
  null,
  "Vyhledávání obrazů zahájíte psaním."
 ],
 "No results for $0": [
  null,
  "Žádné výsledky pro $0"
 ],
 "Retry another term.": [
  null,
  "Zkusit znovu jiný pojem."
 ],
 "Download": [
  null,
  "Stáhnout"
 ],
 "No action": [
  null,
  "Žádná akce"
 ],
 "Container failed to be started": [
  null,
  "Kontejner se nepodařilo spustit"
 ],
 "Failed to clean up container": [
  null,
  "Nepodařilo se vyčistit kontejner"
 ],
 "Container failed to be created": [
  null,
  "Kontejner se nepodařilo vytvořit"
 ],
 "downloading": [
  null,
  "stahuje se"
 ],
 "Failed to run container $0": [
  null,
  "Nepodařilo se spustit kontejner $0"
 ],
 "Failed to create container $0": [
  null,
  "Nepodařilo se vytvořit kontejner $0"
 ],
 "Failed to pull image $0": [
  null,
  "Nepodařilo se natáhnout obraz $0"
 ],
 "Local images": [
  null,
  "Lokální obrazy"
 ],
 "Name already in use": [
  null,
  "Název je už používán"
 ],
 "Search by registry": [
  null,
  "Hledat podle registru (repozitáře)"
 ],
 "Local": [
  null,
  "Lokální"
 ],
 "Container name": [
  null,
  "Název kontejneru"
 ],
 "Owner help": [
  null,
  "Nápověda k vlastníkovi"
 ],
 "Ideal for running services": [
  null,
  "Ideální pro provozování služeb"
 ],
 "Resource limits can be set": [
  null,
  "Je možné nastavit limity prostředků"
 ],
 "Checkpoint and restore support": [
  null,
  "Podpora kontrolních bodů a obnovování"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Je možné mapovat na porty nižší než 1024"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "Ideal for development": [
  null,
  "Ideální pro vývoj"
 ],
 "Restricted by user account permissions": [
  null,
  "Omezeno oprávněními uživatelského účtu"
 ],
 "Image selection help": [
  null,
  "Nápověda k výběru obrazu"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "hostitel[:port]/[uživatel]/kontejner[:štítek]"
 ],
 "Example: $0": [
  null,
  "Příklad: $0"
 ],
 "Searching: $0": [
  null,
  "Vyhledávání: $0"
 ],
 "Search string or container location": [
  null,
  "Hledat řetězec nebo umístění kontejneru"
 ],
 "Pull latest image": [
  null,
  "Stáhnout si nejnovější obraz"
 ],
 "Entrypoint": [
  null,
  "Vstupní bod"
 ],
 "With terminal": [
  null,
  "S terminálem"
 ],
 "Memory limit": [
  null,
  "Limit operační paměti"
 ],
 "Decrease memory": [
  null,
  "Zmenšit paměť"
 ],
 "Increase memory": [
  null,
  "Zvětšit paměť"
 ],
 "Memory unit": [
  null,
  "Jednotka operační paměti"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Podílů na procesoru"
 ],
 "CPU Shares help": [
  null,
  "Nápověda k podílům na procesoru"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Podíly na procesoru určují prioritu spuštěných kontejnerů. Výchozí priorita je 1024. Vyšší číslo vede k vyšší prioritě takového kontejneru. Nižší číslo ji snižuje."
 ],
 "Decrease CPU shares": [
  null,
  "Snížit podíl na procesoru"
 ],
 "Increase CPU shares": [
  null,
  "Zvýšit podíl na procesoru"
 ],
 "Restart policy": [
  null,
  "Pravidlo restartování"
 ],
 "Restart policy help": [
  null,
  "Nápověda k pravidlu restartování"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Pravidlo ohledně restartování kterým se řídit při ukončení kontejnerů. Pokud je v rámci uživatelského účtu používán např. ecryptfs, systemd-homed, NFS nebo 2FA, pak se může stávat, že automatické spouštění pomocí linger za určitých podmínek nemusí zafungovat."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Které pravidlo ohledně restartování následovat když se kontejnery ukončují."
 ],
 "No": [
  null,
  "Ne"
 ],
 "On failure": [
  null,
  "Při nezdaru"
 ],
 "Always": [
  null,
  "Vždy"
 ],
 "Maximum retries": [
  null,
  "Maximální počet opětovných pokusů"
 ],
 "Decrease maximum retries": [
  null,
  "Snížit limit počtu opětovných pokusů"
 ],
 "Increase maximum retries": [
  null,
  "Zvýšit počet opětovných pokusů"
 ],
 "No environment variables specified": [
  null,
  "Nezadány žádné proměnné prostředí"
 ],
 "Add variable": [
  null,
  "Přidat proměnnou prostředí"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Pokud chcete hromadně naimportovat, zadejte do libovolné kolonky jeden či více řádků s dvojicemi klíč=hodnota"
 ],
 "Interval": [
  null,
  "Interval"
 ],
 "Health check interval help": [
  null,
  "Nápověda k intervalu kontroly vitálnosti"
 ],
 "Interval how often health check is run.": [
  null,
  "Jak často spouštět kontrolu vitálnosti."
 ],
 "Decrease interval": [
  null,
  "Snížit interval"
 ],
 "Increase interval": [
  null,
  "Prodloužit interval"
 ],
 "seconds": [
  null,
  "sekund"
 ],
 "Timeout": [
  null,
  "Časový limit"
 ],
 "Health check timeout help": [
  null,
  "Nápověda k časovému limitu kontroly vitálnosti"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Nejdelší přijatelná doba pro dokončení kontroly vitálnosti, než bude interval považován za nezdařilý."
 ],
 "Decrease timeout": [
  null,
  "Snížit časový limit"
 ],
 "Increase timeout": [
  null,
  "Prodloužit časový limit"
 ],
 "Start period": [
  null,
  "Perioda startu"
 ],
 "Health check start period help": [
  null,
  "Nápověda k periodě startu kontroly vitálnosti"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Doba potřebná pro inicializaci zavádění kontejneru."
 ],
 "Decrease start period": [
  null,
  "Snížit periodu startu"
 ],
 "Increase start period": [
  null,
  "Zvýšit periodu startu"
 ],
 "Retries": [
  null,
  "Opětovných pokusů"
 ],
 "Health check retries help": [
  null,
  "Nápověda k opakovaným pokusům o kontrolu vitálnosti"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Umožněný počet opětovných pokusů než bude výsledek kontroly vitálnosti považován za negativní."
 ],
 "Decrease retries": [
  null,
  "Snížit počet opakovaných pokusů"
 ],
 "Increase retries": [
  null,
  "Zvýšit počet opakování pokusů"
 ],
 "When unhealthy": [
  null,
  "Pokud v nepořádku"
 ],
 "Health failure check action help": [
  null,
  "Nápověda k akci kontroly selhání"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Akce kterou podniknout jakmile kontejner přejde do stavu, kdy nebude v pořádku."
 ],
 "Create container in $0": [
  null,
  "Vytvořit kontejner v $0"
 ],
 "Create and run": [
  null,
  "Vytvořit a spustit"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "Links": [
  null,
  "Odkazy"
 ],
 "Documentation": [
  null,
  "Dokumentace"
 ],
 "Tags": [
  null,
  "Štítky"
 ],
 "Created by": [
  null,
  "Vytvořil"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Comments": [
  null,
  "Komentáře"
 ],
 "Unable to load image history": [
  null,
  "Nepodařilo se načíst historii obrazu"
 ],
 "Key must not be empty": [
  null,
  "Je třeba vyplnit klíč"
 ],
 "Key must not begin with a digit": [
  null,
  "Klíč nemůže začínat na číslici"
 ],
 "Key contains invalid characters": [
  null,
  "Klíč obsahuje neplatné znaky"
 ],
 "Key": [
  null,
  "Klíč"
 ],
 "Value": [
  null,
  "Hodnota"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "Podman service failed": [
  null,
  "Služba podman selhala"
 ],
 "Troubleshoot": [
  null,
  "Řešení problémů"
 ],
 "Failed to force remove image $0": [
  null,
  "Nepodařilo se vynutit odebrání obrazu $0"
 ],
 "intermediate image": [
  null,
  "Obraz mezi tím"
 ],
 "Failed to remove image $0": [
  null,
  "Nepodařilo se odebrat obraz $0"
 ],
 "intermediate": [
  null,
  "mezi tím"
 ],
 "Delete $0 image?": [
  null,
  "Smazat obraz $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Pro tento obraz existuje vícero štítků. Vyberte oštítkované obrazy, které smazat."
 ],
 "Delete image": [
  null,
  "Smazat obraz"
 ],
 "Delete tagged images": [
  null,
  "Smazat štítkem označené obrazy"
 ],
 "Container is not running": [
  null,
  "Kontejner není spuštěný"
 ],
 "Error occurred while connecting console": [
  null,
  "Nastala chyba při připojování ke konzoli"
 ],
 "Force delete pod $0?": [
  null,
  "Vynutit smazání podu $0?"
 ],
 "Delete pod $0?": [
  null,
  "Smazat pod $0?"
 ],
 "An error occurred": [
  null,
  "Došlo k chybě"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Prázdný pod $0 bude nevratně odebrán."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Smazání tohoto podu odebere následující kontejnery:"
 ],
 "Failed to start pod $0": [
  null,
  "Nepodařilo se spustit pod $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Nepodařilo se zastavit pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Nepodařilo se restartovat pod $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Nepodařilo se navázat v chodu podu $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Nepodařilo se pozastavit pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Nepodařilo se prořezat nepoužívané kontejnery"
 ],
 "Removes selected non-running containers": [
  null,
  "Odebere označené (a nespuštěné) kontejnery"
 ],
 "Pruning containers": [
  null,
  "Prořezávají se kontejnery"
 ],
 "Container name is required.": [
  null,
  "Je třeba zadat název kontejneru."
 ],
 "Failed to rename container $0": [
  null,
  "Nepodařilo se přejmenovat kontejner $0"
 ],
 "New container name": [
  null,
  "Nový název pro kontejner"
 ],
 "Rename container $0": [
  null,
  "Přejmenovat kontejner $0"
 ],
 "Paused": [
  null,
  "Pozastaveno"
 ],
 "Stopped": [
  null,
  "Zastaveno"
 ],
 "Removing": [
  null,
  "Odebírá se"
 ],
 "Configured": [
  null,
  "Nastaveno"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "$0 second": [
  null,
  "$0 sekunda",
  "$0 sekundy",
  "$0 sekund"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Failing streak": [
  null,
  "Selhávající streak"
 ],
 "Failed to run health check on container $0": [
  null,
  "Nepodařilo se zkontrolovat vitálnost kontejneru $0"
 ],
 "Run health check": [
  null,
  "Zkontrolovat vitálnost"
 ],
 "Last 5 runs": [
  null,
  "Minulých 5 spuštění"
 ],
 "Started at": [
  null,
  "Spuštěno v"
 ],
 "Passed health run": [
  null,
  "Prošlo kontrolou vitálnosti"
 ],
 "Failed health run": [
  null,
  "Nepodařilo se spustit kontrolu vitálnosti"
 ],
 "Failed to remove container $0": [
  null,
  "Nepodařilo se odebrat kontejner $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Smazání kontejneru smaže veškerá data v něm."
 ]
});
