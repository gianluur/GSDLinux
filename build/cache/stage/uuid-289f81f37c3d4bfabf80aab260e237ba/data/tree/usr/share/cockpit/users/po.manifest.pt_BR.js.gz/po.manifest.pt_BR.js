cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Accounts": [
  null,
  "Contas"
 ],
 "user": [
  null,
  "usuário"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "senha"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nome de usuário"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "acesso"
 ],
 "roles": [
  null,
  "papéis"
 ],
 "keys": [
  null,
  "chaves"
 ],
 "Managing user accounts": [
  null,
  "Gerenciando contas de usuário"
 ]
});
