cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "ファイルブラウザー"
 ],
 "files": [
  null,
  "ファイル"
 ],
 "explorer": [
  null,
  "エクスプローラー"
 ],
 "filesystem": [
  null,
  "ファイルシステム"
 ]
});
