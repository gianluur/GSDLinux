cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "lg",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0$1"
 ],
 "$0 ($1)": [
  null,
  "$0($1)"
 ],
 "$0 error": [
  null,
  "",
  ""
 ],
 "$0 installation": [
  null,
  "Okussaako kwa $0"
 ],
 "$0 installer": [
  null,
  "Installer ya $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 kitundu kya MBR extended partition ekilimu ebitundu ebilala ebya logical partitions. Okusangulawo ebitundu ebya logical partitions byona, kijja kusangulawo nebitundu ebya extended partition byona."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 ze zetaagisa, naye $1 zokka ze ziriwo."
 ],
 "$0 warning": [
  null,
  "okulabula $0",
  "okulabulwa $0"
 ],
 "$0 will be deleted": [
  null,
  "$0 egenda kusimulwa"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' filesystem tesobola kubeela ku block device eli encrypted"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' erina okuuba ku kyuma ekisengekeddwa ku '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "'$0' partition ku kyuma kya MDRAID $1 esangiddwa. Bootloader partitions ku byuma bya MDRAID, tebiwagirwa."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Akawunti yo mukozesa ali kumutindo nga elina admin access okukola enkyukakyuka mubugazi bwa system."
 ],
 "About": [
  null,
  "Ebifa kweno pulogulamu"
 ],
 "Account": [
  null,
  "Akawunti"
 ],
 "Actions": [
  null,
  "Ebikolwa"
 ],
 "Add another server...": [
  null,
  "Yongelako server endala..."
 ],
 "Add mount": [
  null,
  "Ssaako mount"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Ebyongerwako ebikwata ku nteekateeka gyolonze"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Ebyongerwako ebitakwatta ku nteekateeka yo yokka"
 ],
 "Additional languages": [
  null,
  "Ennimi endala"
 ],
 "Additional software for the selected environment": [
  null,
  "Pulogulaamu endala ez'enteekateeka eyalondedwa"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Buli nkyukakyuka gyokoze mu storage edita ekola mbagirawo."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Devices zonna ezikozesa passphrase eno zijja kuggulwawo"
 ],
 "Anaconda Web UI": [
  null,
  "Enteekateeka ya Anaconda eya Web UI"
 ],
 "Anaconda project page": [
  null,
  "Akafo ka Anaconda pulojekiti ku yintaneeti"
 ],
 "Apply mount point assignment and install": [
  null,
  "Kozesa mount point assignment era oteeke"
 ],
 "Applying changes...": [
  null,
  ""
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Teekako partitions ku mount points. Kiyamba mu nteekateeka zo ez'enjawulo."
 ],
 "Automatic log file upload": [
  null,
  "Fayilo ya log essiddwa ku mukuttu mu ngeri ya otomatiki"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Kozesa time servers okuteekateeka essaawa n'ennaku z'omwezi mu ngeri eli otomatiki"
 ],
 "Automatically set timezone": [
  null,
  "Londa ekitundu ky’ebiseera mu ngeli eli otomatiki"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Ebbanga eririwo: $0. Okuteekamu kwetaaga: $1."
 ],
 "Back": [
  null,
  "mabega"
 ],
 "Base environment": [
  null,
  "Omusingi gw'enteekateeka"
 ],
 "Brief description of the issue": [
  null,
  "Ennyonnyola y'ekizibu mu bufunze"
 ],
 "Bug report details": [
  null,
  "Ebisingako mu alipoota y'ekizibu"
 ],
 "Bugzilla API key": [
  null,
  "API key ya Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Bw'oyongera okukozesa pulogulaamu eno, kiba kitegeeza nti otegeera era okkiriza obulabe obuyinza okubaawo mu pulogulaamu ezitannaba kufulumizibwa mu butongole, nti ogenda gikozesa mu kugezesa n'ebigendererwa by’enkulaakulana byokka, era nti oli mwetegefu okuwa alipoota ku nsobi oba ebizibu byonna okusobola okulongoosa omulimu guno."
 ],
 "Cancel": [
  null,
  "Sazaamu"
 ],
 "Change": [
  null,
  "Kyusa"
 ],
 "Change destination": [
  null,
  "Kyusa ekifo awateekebwa"
 ],
 "Change hostname": [
  null,
  "Kyusa erinnya lya kompyuta"
 ],
 "Change partition layout": [
  null,
  "Kyusa layout ya patisoni"
 ],
 "Change system keyboard layout": [
  null,
  "Kyusa layout ya keyboard"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Enkyukakyuka ezikolebwa wano zikosa enkola ya kompyuta. Teli 'kudda mabega'."
 ],
 "Checking storage configuration": [
  null,
  "Tukebera enteekateeka ya storage"
 ],
 "Clear search": [
  null,
  "Ggyamu ebinonnyebwa"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Nyiga 'Next' nate okweyongerayo wadde nga waliwo okulabula kuno."
 ],
 "Close": [
  null,
  "Ggalawo"
 ],
 "Close storage editor": [
  null,
  "Ggalawo edita ya storage"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit storage teyawaddeyo passphrase ey’okusumulula encrypted device."
 ],
 "Completed": [
  null,
  "Kimalirizidwa"
 ],
 "Configuration is incomplete": [
  null,
  ""
 ],
 "Configure NTP servers": [
  null,
  "Tegeka server ya NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Tegeka NTP servers ez’enjawulo"
 ],
 "Configure network": [
  null,
  "Tegeka network"
 ],
 "Configure storage": [
  null,
  "Tegeka storage"
 ],
 "Configure storage again": [
  null,
  "Tegeka storage nate"
 ],
 "Confirm passphrase": [
  null,
  "Kakasa passphrase"
 ],
 "Continue": [
  null,
  "Weyongereyo"
 ],
 "Continue installation": [
  null,
  "Weyongereyo n’okuteekaamu"
 ],
 "Continue with installation": [
  null,
  "Genda mu maaso n’okuteekaamu"
 ],
 "Correct these issues before continuing.": [
  null,
  ""
 ],
 "Create Account": [
  null,
  "Tonda Akawunti"
 ],
 "Create account": [
  null,
  "Tonda akawunti"
 ],
 "Currently installed: $0": [
  null,
  "Ebiriwo kati: $0"
 ],
 "Custom": [
  null,
  "Ey’enjawulo"
 ],
 "Date": [
  null,
  "Olunaku"
 ],
 "Date and time": [
  null,
  "Olunaku n’essaawa"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "okusazaamu partions ezimu kiyinza okulemesa $0 okutandika: $1"
 ],
 "Description": [
  null,
  "Okunnyonnyola"
 ],
 "Destination": [
  null,
  "Gye bitwalibwa"
 ],
 "Destination is encrypted": [
  null,
  "Ekifo gye biraga kisibidwa"
 ],
 "Detailed description of the issue": [
  null,
  "Ennyonyola enzijuvu ku nsonga eno"
 ],
 "Detected valid storage layout:": [
  null,
  "Layout ya storage entuffu ezuuliddwa:"
 ],
 "Device": [
  null,
  ""
 ],
 "Duplicate device.": [
  null,
  "Device nkoppe."
 ],
 "Duplicate mount point.": [
  null,
  "Mount point nkoppe."
 ],
 "Enable root account": [
  null,
  "sobozesa akawunti ya root"
 ],
 "Encrypt my data": [
  null,
  "Encrypt data wange"
 ],
 "Encrypted": [
  null,
  ""
 ],
 "Encryption": [
  null,
  ""
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Yingiza ekisumuluzo kyo ekya Bugzilla API okukola lipoota y'obuzibu. Ojja kusobola okwetegereza n'okulongoosa ebikwata ku kizibu mu mutendera oguddako."
 ],
 "Environment": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Sangula data oteekeemu"
 ],
 "Error details": [
  null,
  "Ebikwata ku nsobi"
 ],
 "Exit to live desktop": [
  null,
  "Fuluma oddeyo ku live desktop"
 ],
 "Extended partition": [
  null,
  "Partition eyongezeddwako"
 ],
 "Failed to report issue": [
  null,
  "Tulemeddwa okuloopa ensonga"
 ],
 "Failed to save layouts": [
  null,
  "Tulemeddwa okukuuma layouts"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux yeetaaga waakiri $0 ez'ekifo ku disiki."
 ],
 "Finalization": [
  null,
  "Tuli mu kumaliriza"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Okumaliriza: Ensengeka ya system ewedde. Okumaliriza installation kiyinza okutwala akaseera katono."
 ],
 "Find layout": [
  null,
  "Funa layout"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Okusobola okufuna obukuumi obulungi, weewale okukozesa akawunti ya root butereevu. Wabula, kozesa local akawunti eli waggulu okuddukanya system."
 ],
 "Full name": [
  null,
  "Amannya mu bujjuvu"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Erinnya mu bujjuvu teriyinza kubaamu nnyiriri za kkoona"
 ],
 "Helper text": [
  null,
  "Ekiwandiiko ky’obuyambi"
 ],
 "Hide confirmed password": [
  null,
  "Kweka pasiwadi ekakasiddwa"
 ],
 "Hide passphrase": [
  null,
  "Kweka passphrase"
 ],
 "Hide password": [
  null,
  "Kweka pasiwadi"
 ],
 "Hostname": [
  null,
  ""
 ],
 "How would you like to install?": [
  null,
  "Wandyagadde okuteeka otya?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Ntegedde nti data omu ariwo ajja kusangulwa"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Ntegedde nti partition ezimu zijja kukyusibwa"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Bwe kiba nga njereere, hostname egenda kuba ya kaseera buseera era eteekebwawo network information."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Bw'oba otegeka partitions bino wammanga byetaagibwa:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  ""
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  ""
 ],
 "Initializing...": [
  null,
  ""
 ],
 "Install": [
  null,
  ""
 ],
 "Installation failed": [
  null,
  ""
 ],
 "Installation method": [
  null,
  ""
 ],
 "Installation of the system failed": [
  null,
  ""
 ],
 "Installation of the system failed: $0": [
  null,
  ""
 ],
 "Installation type": [
  null,
  ""
 ],
 "Installing": [
  null,
  ""
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  ""
 ],
 "Jump to first incomplete step": [
  null,
  ""
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  ""
 ],
 "Keyboard": [
  null,
  ""
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  ""
 ],
 "Launch storage editor": [
  null,
  ""
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  ""
 ],
 "Locked devices": [
  null,
  ""
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  ""
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  ""
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "May need more free space": [
  null,
  ""
 ],
 "Medium": [
  null,
  ""
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  ""
 ],
 "Mount point": [
  null,
  ""
 ],
 "Mount point assignment": [
  null,
  ""
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  ""
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  ""
 ],
 "NTS": [
  null,
  ""
 ],
 "Name": [
  null,
  ""
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  ""
 ],
 "Network Configuration": [
  null,
  ""
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  ""
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  ""
 ],
 "Network plugin failed": [
  null,
  ""
 ],
 "Next": [
  null,
  ""
 ],
 "No devices": [
  null,
  ""
 ],
 "No disks available": [
  null,
  ""
 ],
 "No disks selected": [
  null,
  ""
 ],
 "No keyboard layouts selected": [
  null,
  ""
 ],
 "No layouts selected yet": [
  null,
  ""
 ],
 "No results found": [
  null,
  ""
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  ""
 ],
 "Not enough space on selected disks.": [
  null,
  ""
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  ""
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  ""
 ],
 "Options": [
  null,
  ""
 ],
 "Other keyboards": [
  null,
  ""
 ],
 "Partitions (advanced)": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  ""
 ],
 "Passphrase did not match any locked device": [
  null,
  ""
 ],
 "Passphrases must match": [
  null,
  ""
 ],
 "Pending": [
  null,
  ""
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  ""
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  ""
 ],
 "Pool": [
  null,
  ""
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  ""
 ],
 "Pre-release": [
  null,
  ""
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  ""
 ],
 "Quit": [
  null,
  ""
 ],
 "Quit installer?": [
  null,
  ""
 ],
 "Reading information about the OS failed.": [
  null,
  ""
 ],
 "Reading information about the computer failed.": [
  null,
  ""
 ],
 "Reading installer configuration failed.": [
  null,
  ""
 ],
 "Reading installer version information failed.": [
  null,
  ""
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Real hostname must be 64 characters or less": [
  null,
  ""
 ],
 "Reboot": [
  null,
  ""
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Reboot system?": [
  null,
  ""
 ],
 "Reclaim additional space": [
  null,
  ""
 ],
 "Reclaim space": [
  null,
  ""
 ],
 "Reclaim space (required)": [
  null,
  ""
 ],
 "Recommended": [
  null,
  ""
 ],
 "Recommended partitions:": [
  null,
  ""
 ],
 "Reformat": [
  null,
  ""
 ],
 "Reinstall Fedora": [
  null,
  ""
 ],
 "Remove": [
  null,
  ""
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  ""
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  ""
 ],
 "Remove server": [
  null,
  ""
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  ""
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  ""
 ],
 "Reporting issue...": [
  null,
  ""
 ],
 "Required": [
  null,
  ""
 ],
 "Requirements": [
  null,
  ""
 ],
 "Rescan devices": [
  null,
  ""
 ],
 "Rescanning of the disks failed.": [
  null,
  ""
 ],
 "Resize": [
  null,
  ""
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  ""
 ],
 "Return to storage editor": [
  null,
  ""
 ],
 "Review and install": [
  null,
  ""
 ],
 "Root account has been configured": [
  null,
  ""
 ],
 "Root account is enabled": [
  null,
  ""
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  ""
 ],
 "Save": [
  null,
  ""
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  ""
 ],
 "Search for a language": [
  null,
  ""
 ],
 "Search for additional software": [
  null,
  ""
 ],
 "Search for an environment": [
  null,
  ""
 ],
 "Search keyboard layout": [
  null,
  ""
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  ""
 ],
 "Select": [
  null,
  ""
 ],
 "Select a device": [
  null,
  ""
 ],
 "Select city": [
  null,
  ""
 ],
 "Select destination": [
  null,
  ""
 ],
 "Select region": [
  null,
  ""
 ],
 "Selected (top = current)": [
  null,
  ""
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  ""
 ],
 "Send us feedback on your installation": [
  null,
  ""
 ],
 "Server": [
  null,
  ""
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  ""
 ],
 "Share disk with other operating systems": [
  null,
  ""
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Show AM/PM": [
  null,
  ""
 ],
 "Show API key": [
  null,
  ""
 ],
 "Show PIN": [
  null,
  ""
 ],
 "Show confirmed password": [
  null,
  ""
 ],
 "Show passphrase": [
  null,
  ""
 ],
 "Show password": [
  null,
  ""
 ],
 "Size": [
  null,
  ""
 ],
 "Software installation": [
  null,
  ""
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  ""
 ],
 "Software selection": [
  null,
  ""
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  ""
 ],
 "Space": [
  null,
  ""
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  ""
 ],
 "Storage configuration": [
  null,
  ""
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  ""
 ],
 "Storage editor": [
  null,
  ""
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  ""
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  ""
 ],
 "Storage requirements not met": [
  null,
  ""
 ],
 "Strong": [
  null,
  ""
 ],
 "Successfully installed": [
  null,
  ""
 ],
 "Successfully unlocked $0.": [
  null,
  ""
 ],
 "Suggested keyboards": [
  null,
  ""
 ],
 "Suggested languages": [
  null,
  ""
 ],
 "System": [
  null,
  ""
 ],
 "System configuration": [
  null,
  ""
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  ""
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "",
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  ""
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  ""
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This is unstable, pre-release software": [
  null,
  ""
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  ""
 ],
 "This will take a few moments": [
  null,
  ""
 ],
 "Time": [
  null,
  ""
 ],
 "Timezone": [
  null,
  ""
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  ""
 ],
 "To continue, select the devices to install to.": [
  null,
  ""
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  ""
 ],
 "Type": [
  null,
  ""
 ],
 "Unable to schedule deletion of $0": [
  null,
  ""
 ],
 "Unable to schedule resizing of $0": [
  null,
  ""
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  ""
 ],
 "Unlock encrypted devices": [
  null,
  ""
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "Use configured storage": [
  null,
  ""
 ],
 "Use entire disk": [
  null,
  ""
 ],
 "Use free space": [
  null,
  ""
 ],
 "Use local account": [
  null,
  ""
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  ""
 ],
 "User creation": [
  null,
  ""
 ],
 "User name": [
  null,
  ""
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  ""
 ],
 "User name must not be a reserved word": [
  null,
  ""
 ],
 "User names must be shorter than 33 characters": [
  null,
  ""
 ],
 "Validating...": [
  null,
  ""
 ],
 "Weak": [
  null,
  ""
 ],
 "Welcome": [
  null,
  ""
 ],
 "Welcome to Fedora Linux": [
  null,
  ""
 ],
 "Welcome. Let's install $0 now.": [
  null,
  ""
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  ""
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  ""
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  ""
 ],
 "completed step": [
  null,
  ""
 ],
 "current step": [
  null,
  ""
 ],
 "delete": [
  null,
  ""
 ],
 "edit": [
  null,
  ""
 ],
 "encrypt": [
  null,
  ""
 ],
 "encrypted": [
  null,
  ""
 ],
 "extended partition": [
  null,
  ""
 ],
 "format as $0": [
  null,
  ""
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "pending step": [
  null,
  ""
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink": [
  null,
  ""
 ],
 "shrink to $0": [
  null,
  ""
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  ""
 ]
});
