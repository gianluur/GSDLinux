cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "네트워킹"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Accounts": [
  null,
  "계정"
 ],
 "user": [
  null,
  "사용자"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "비밀번호"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "사용자 이름"
 ],
 "login": [
  null,
  "로그인"
 ],
 "access": [
  null,
  "접근"
 ],
 "roles": [
  null,
  "역할"
 ],
 "keys": [
  null,
  "키"
 ],
 "Managing user accounts": [
  null,
  "사용자 계정 관리"
 ]
});
