cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Poistetaanko $0?"
 ],
 "Force delete": [
  null,
  "Pakota poisto"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Must be a valid IP address": [
  null,
  "On oltava kelvollinen IP-osoite"
 ],
 "1 to 65535": [
  null,
  "1–65535"
 ],
 "Container port must not be empty": [
  null,
  "Kontin portti ei saa olla tyhjä"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "IP address help": [
  null,
  "Ohjeita IP-osoitteesta"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jos isäntäkoneen IP-osoitteeksi on asetettu 0.0.0.0 tai sitä ei ole määritetty lainkaan, portti sidotaan kaikkiin isäntäkoneen IP-osoitteisiin."
 ],
 "Host port": [
  null,
  "Koneen portti"
 ],
 "Host port help": [
  null,
  "Ohjeita koneen portista"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jos isäntäporttia ei ole asetettu, konttiportille määritetään satunnainen isäntäportti."
 ],
 "Container port": [
  null,
  "Kontin portti"
 ],
 "Protocol": [
  null,
  "Protokolla"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Image name is required": [
  null,
  "Levykuvan nimi vaaditaan"
 ],
 "Image name is not unique": [
  null,
  "Kevykuvan nimi ei ole ainutlaatuinen"
 ],
 "Failed to commit container $0": [
  null,
  "Kontin $0 kommitointi epäonnistui"
 ],
 "New image name": [
  null,
  "Uusi levykuvan nimi"
 ],
 "Tag": [
  null,
  "Tunniste"
 ],
 "Author": [
  null,
  "Tekijä"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Esimerkki: Nimesi <nimesi@esimerkki.fi>"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Pause container when creating image": [
  null,
  "Pysäytä kontti levykuvan luomisen ajaksi"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-muoto on hyödyllinen, kun levykuvaa jaetaan Dockerin tai Moby Enginen kanssa"
 ],
 "Use legacy Docker format": [
  null,
  "Käytä vanhaa Docker-muotoa"
 ],
 "Commit container": [
  null,
  "Kommitoi kontti"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Luo uusi levykuva $0-kontin nykyisen tilan perusteella."
 ],
 "Commit": [
  null,
  "Kommitoi"
 ],
 "Force commit": [
  null,
  "Pakota kommitti"
 ],
 "Failed to force remove container $0": [
  null,
  "Kontin $0 pakotettu poistaminen epäonnistui"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Käynnissä olevan kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Failed to stop container $0": [
  null,
  "Kontin $0 pysäyttäminen epäonnistui"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Quadletin $0 pysäyttäminen epäonnistui"
 ],
 "Failed to start quadlet $0": [
  null,
  "Quadletin $0 käynnistäminen epäonnistui"
 ],
 "Failed to start container $0": [
  null,
  "Kontin $0 käynnistäminen epäonnistui"
 ],
 "Failed to resume container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Failed to pause container $0": [
  null,
  "Kontin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to restart container $0": [
  null,
  "Kontin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Quadletin $0 uudelleenkäynnistys epäonnistui"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Restart": [
  null,
  "Käynnistä uudelleen"
 ],
 "Force stop": [
  null,
  "Pakota pysäytys"
 ],
 "Force restart": [
  null,
  "Pakota uudelleenkäynnistys"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Resume": [
  null,
  "Jatka"
 ],
 "Checkpoint": [
  null,
  "Tarkistuspiste"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Restore": [
  null,
  "Palauta"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Healthy": [
  null,
  "Ehjä"
 ],
 "Unhealthy": [
  null,
  "Rikki"
 ],
 "Checking health": [
  null,
  "Tarkistetaan tilaa"
 ],
 "Prune unused containers": [
  null,
  "Poista käyttämättömiä kontteja"
 ],
 "Terminal not available": [
  null,
  "Pääte ei käytettävissä"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Tämä selain ei tue WebGL2:ta."
 ],
 "View $0 logs": [
  null,
  "Näytä $0 lokia"
 ],
 "not available": [
  null,
  "ei käytettävissä"
 ],
 "n/a": [
  null,
  "ei sovellu"
 ],
 "$0% of $1 limit": [
  null,
  "$0 % $1 rajasta"
 ],
 "service": [
  null,
  "palvelu"
 ],
 "system": [
  null,
  "järjestelmä"
 ],
 "user:": [
  null,
  "käyttäjä:"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Integration": [
  null,
  "Integraatio"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "Console": [
  null,
  "Konsoli"
 ],
 "Health check": [
  null,
  "Eheystarkistus"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Click to see published ports": [
  null,
  "Napsauta nähdäksesi julkaistut portit"
 ],
 "ports": [
  null,
  "portit"
 ],
 "Click to see volumes": [
  null,
  "Napsauta nähdäksesi taltiot"
 ],
 "volumes": [
  null,
  "taltiot"
 ],
 "Container": [
  null,
  "Kontti"
 ],
 "Owner": [
  null,
  "Omistaja"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "No containers": [
  null,
  "Ei kontteja"
 ],
 "No containers in this pod": [
  null,
  "Tässä podissa ei ole kontteja"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "No containers that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia kontteja"
 ],
 "No running containers": [
  null,
  "Ei käynnissä olevia kontteja"
 ],
 "Show": [
  null,
  "Näytä"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "Only running": [
  null,
  "Vain käynnissä olevat"
 ],
 "Create pod": [
  null,
  "Luo podi"
 ],
 "Create container": [
  null,
  "Luo kontti"
 ],
 "Containers": [
  null,
  "Kontit"
 ],
 "Create container in pod": [
  null,
  "Luo kontti podiin"
 ],
 "pod": [
  null,
  "podi"
 ],
 "Failed to restore container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Restore container $0": [
  null,
  "Palauta kontti $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Säilytä kaikki väliaikaiset tarkistuspistetiedostot"
 ],
 "Restore with established TCP connections": [
  null,
  "Palauta käyttäen luotuja TCP-yhteyksiä"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ohita IP-osoite, jos se on asetettu staattisesti"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ohita MAC-osoite, jos se on asetettu staattisesti"
 ],
 "Pod failed to be created": [
  null,
  "Podin luonti epäonnistui"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Virheellisiä merkkejä. Nimi voi sisältää vain kirjaimia, numeroita ja tiettyjä välimerkkejä (_ . -)."
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Pod name": [
  null,
  "Podin nimi"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "User:": [
  null,
  "Käyttäjä:"
 ],
 "No ports exposed": [
  null,
  "Ei paljastettuja portteja"
 ],
 "Port mapping": [
  null,
  "Porttiassosiaatio"
 ],
 "Add port mapping": [
  null,
  "Lisää porttiassosiaatio"
 ],
 "No volumes specified": [
  null,
  "Taltiota ei ole määritelty"
 ],
 "Volumes": [
  null,
  "Taltiot"
 ],
 "Add volume": [
  null,
  "Lisää taltio"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Type to filter…": [
  null,
  "Kirjoita suodattaaksesi…"
 ],
 "Container path must not be empty": [
  null,
  "Kontin polku ei saa olla tyhjä"
 ],
 "Host path": [
  null,
  "Koneen polku"
 ],
 "Container path": [
  null,
  "Kontin polku"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Writable": [
  null,
  "Kirjoitettavissa"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Ei nimiötä"
 ],
 "Shared": [
  null,
  "Jaettu"
 ],
 "Private": [
  null,
  "Yksityinen"
 ],
 "Read-write access": [
  null,
  "Luku-kirjoitusoikeus"
 ],
 "Read-only access": [
  null,
  "Vain luku-käyttöoikeus"
 ],
 "Show less": [
  null,
  "Näytä vähemmän"
 ],
 "Show more": [
  null,
  "Näytä lisää"
 ],
 "Loading details...": [
  null,
  "Ladataan tietoja..."
 ],
 "Ports": [
  null,
  "Portit"
 ],
 "Environment variables": [
  null,
  "Ympäristömuuttujat"
 ],
 "Failed to download image $0:$1": [
  null,
  "Levykuvan lataaminen epäonnistui $0:$1"
 ],
 "Error message": [
  null,
  "Virheviesti"
 ],
 "unused": [
  null,
  "ei käytössä"
 ],
 "$0 container": [
  null,
  "$0 kontti",
  "$0 konttia"
 ],
 "History": [
  null,
  "Historia"
 ],
 "Image": [
  null,
  "Levykuva"
 ],
 "Created": [
  null,
  "Luotu"
 ],
 "ID": [
  null,
  "TUNNISTE"
 ],
 "Disk space": [
  null,
  "Levytila"
 ],
 "Used by": [
  null,
  "Käyttää"
 ],
 "No images": [
  null,
  "Ei levykuvia"
 ],
 "No images that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia levykuvia"
 ],
 "Hide intermediate images": [
  null,
  "Piilota välivaiheen levykuvat"
 ],
 "Show intermediate images": [
  null,
  "Näytä välivaiheen levykuvat"
 ],
 "Images": [
  null,
  "Levykuvat"
 ],
 "$0 image total, $1": [
  null,
  "$0 levykuva yhteensä, $1",
  "$0 levykuvaa yhteensä, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 käyttämätön levykuva, $1",
  "$0 käyttämätöntä levykuvaa, $1"
 ],
 "Hide images": [
  null,
  "Piilota levykuvat"
 ],
 "Show images": [
  null,
  "Näytä levykuvat"
 ],
 "Pulling": [
  null,
  "Haetaan"
 ],
 "Download new image": [
  null,
  "Lataa uusi levykuva"
 ],
 "Pull all images": [
  null,
  "Vedä kaikki kuvat"
 ],
 "Prune unused images": [
  null,
  "Karsi käyttämättömät levykuvat"
 ],
 "Pull": [
  null,
  "Vedä"
 ],
 "Up since:": [
  null,
  "Käynnissä lähtien:"
 ],
 "Exited": [
  null,
  "Päättyi"
 ],
 "systemd service": [
  null,
  "systemd palvelu"
 ],
 "View $0": [
  null,
  "Näytä $0"
 ],
 "Gateway": [
  null,
  "Yhdyskäytävä"
 ],
 "MAC address": [
  null,
  "MAC-osoite"
 ],
 "Latest checkpoint": [
  null,
  "Viimeisin tarkistuspiste"
 ],
 "No containers are using this image": [
  null,
  "Yksikään kontti ei käytä tätä levykuvaa"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "Loading logs...": [
  null,
  "Ladataan lokeja..."
 ],
 "Delete unused system images:": [
  null,
  "Poista käyttämättömät järjestelmälevykuvat:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Poista käyttäjän $0 käyttämättömät levykuvat:"
 ],
 "Failed to prune unused images": [
  null,
  "Käyttämättömien levykuvien karsiminen epäonnistui"
 ],
 "Pruning images": [
  null,
  "Karsitaan levykuvia"
 ],
 "Prune": [
  null,
  "Karsi"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kontin $0 tarkistuspisteen luominen epäonnistui"
 ],
 "Checkpoint container $0": [
  null,
  "Luo tarkistuspiste kontista $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Jätä käyntiin tarkistuspisteen levylle kirjoittamisen jälkeen"
 ],
 "Support preserving established TCP connections": [
  null,
  "Tue jo luotujen TCP -yhteyksien säilyttämistä"
 ],
 "Failed to search for new images": [
  null,
  "Uusien levykuvien etsintä epäonnistui"
 ],
 "Failed to search for images: $0": [
  null,
  "Levykuvien etsintä epäonnistui: $0"
 ],
 "Failed to search for images.": [
  null,
  "Levykuvien etsintä epäonnistui."
 ],
 "Search for an image": [
  null,
  "Etsi levykuvaa"
 ],
 "Search for": [
  null,
  "Etsittävä"
 ],
 "Search by name or description": [
  null,
  "Hae nimen tai kuvauksen perusteella"
 ],
 "in": [
  null,
  "sijainnissa"
 ],
 "All registries": [
  null,
  "Kaikki rekisterit"
 ],
 "Searching...": [
  null,
  "Etsitään..."
 ],
 "No images found": [
  null,
  "Levykuvia ei löytynyt"
 ],
 "Start typing to look for images.": [
  null,
  "Aloita kirjoittaminen etsiäksesi levykuvia."
 ],
 "No results for $0": [
  null,
  "Ei tuloksia hakusanalle $0"
 ],
 "Retry another term.": [
  null,
  "Yritä toisella termillä uudelleen."
 ],
 "Download": [
  null,
  "Lataa"
 ],
 "No action": [
  null,
  "Ei toimintoa"
 ],
 "Container failed to be started": [
  null,
  "Kontin käynnistys epäonnistui"
 ],
 "Failed to clean up container": [
  null,
  "Kontin poistaminen epäonnistui"
 ],
 "Container failed to be created": [
  null,
  "Kontin luonti epäonnistui"
 ],
 "downloading": [
  null,
  "ladataan"
 ],
 "Failed to run container $0": [
  null,
  "Kontin $0 suorittaminen epäonnistui"
 ],
 "Failed to create container $0": [
  null,
  "Kontin $0 luominen epäonnistui"
 ],
 "Failed to pull image $0": [
  null,
  "Levykuvan $0 hakeminen epäonnistui"
 ],
 "Local images": [
  null,
  "Paikallisia levykuvia"
 ],
 "Name already in use": [
  null,
  "Nimi on jo käytössä"
 ],
 "Search by registry": [
  null,
  "Haku rekisterin perusteella"
 ],
 "Local": [
  null,
  "Paikallinen"
 ],
 "Container name": [
  null,
  "Kontin nimi"
 ],
 "Owner help": [
  null,
  "Omistajan ohjeet"
 ],
 "Ideal for running services": [
  null,
  "Ihanteellinen palvelujen suorittamiseen"
 ],
 "Resource limits can be set": [
  null,
  "Resurssirajoja voidaan asettaa"
 ],
 "Checkpoint and restore support": [
  null,
  "Tarkistuspisteen ja palautuksen tuki"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portit alle 1024 voidaan kartoittaa"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "Ideal for development": [
  null,
  "Ihanteellinen kehittämiseen"
 ],
 "Restricted by user account permissions": [
  null,
  "Rajoitettu käyttäjätilin käyttöoikeuksilla"
 ],
 "Image selection help": [
  null,
  "Ohjeita levykuvan valintaan"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "isäntä[:portti]/[käyttäjä]/kontti[:tag]"
 ],
 "Example: $0": [
  null,
  "Esimerkki: $0"
 ],
 "Searching: $0": [
  null,
  "Etsitään: $0"
 ],
 "Search string or container location": [
  null,
  "Hae merkkijonon tai kontin sijaintia"
 ],
 "Pull latest image": [
  null,
  "Hae viimeisin levykuva"
 ],
 "Entrypoint": [
  null,
  "Sisääntulokohta"
 ],
 "With terminal": [
  null,
  "Päätteen kanssa"
 ],
 "Memory limit": [
  null,
  "Muistiraja"
 ],
 "Decrease memory": [
  null,
  "Vähennä muistia"
 ],
 "Increase memory": [
  null,
  "Lisää muistia"
 ],
 "Memory unit": [
  null,
  "Muistiyksikkö"
 ],
 "KB": [
  null,
  "Kt"
 ],
 "MB": [
  null,
  "Mt"
 ],
 "GB": [
  null,
  "Gt"
 ],
 "CPU shares": [
  null,
  "Suoritinosuus"
 ],
 "CPU Shares help": [
  null,
  "Ohjeita CPU-osuuksista"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-osuudet määrittävät käynnissä olevien konttien prioriteetin. Oletusprioriteetti on 1024. Suurempi numero priorisoi tätä konttia. Pienempi numero laskee prioriteettia."
 ],
 "Decrease CPU shares": [
  null,
  "Vähennä suoritinosuuksia"
 ],
 "Increase CPU shares": [
  null,
  "Lisää suoritinosuuksia"
 ],
 "Restart policy": [
  null,
  "Uudelleenkäynnistyksen käytäntö"
 ],
 "Restart policy help": [
  null,
  "Ohjeita uudelleenkäynnistyksen käytännöstä"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Käytettävä uudelleenkäynnistyskäytäntö, kun kontit poistuvat. Viivyttämisen käyttäminen konttien automaattiseen käynnistykseen ei välttämättä toimi joissain olosuhteissa, kuten kun käyttäjätilillä on käytössä ecryptfs, systemd-homed, NFS tai 2FA."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Noudata uudelleenkäynnistyskäytäntöä, kun kontit poistuvat."
 ],
 "No": [
  null,
  "Ei"
 ],
 "On failure": [
  null,
  "Epäonnistumisesta"
 ],
 "Always": [
  null,
  "Aina"
 ],
 "Maximum retries": [
  null,
  "Uudelleenyritysten enimmäismäärä"
 ],
 "Decrease maximum retries": [
  null,
  "Pienennä uudelleenyritysten enimmäismäärää"
 ],
 "Increase maximum retries": [
  null,
  "Lisää uudelleenyritysten enimmäismäärää"
 ],
 "No environment variables specified": [
  null,
  "Ympäristömuuttujia ei ole määritetty"
 ],
 "Add variable": [
  null,
  "Lisää muuttuja"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Liitä yksi tai useampi rivi avain=arvo-pareja mihin tahansa kenttään joukkotuontia varten"
 ],
 "Interval": [
  null,
  "Aikaväli"
 ],
 "Health check interval help": [
  null,
  "Tietoa eheystarkistuksen aikavälistä"
 ],
 "Interval how often health check is run.": [
  null,
  "Eheystarkistusten aikaväli."
 ],
 "Decrease interval": [
  null,
  "Pienennä väliä"
 ],
 "Increase interval": [
  null,
  "Suurenna väliä"
 ],
 "seconds": [
  null,
  "sekuntia"
 ],
 "Timeout": [
  null,
  "Aikakatkaisu"
 ],
 "Health check timeout help": [
  null,
  "Tietoa eheystarkistuksen aikakatkaisusta"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Enimmäisaika, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "Decrease timeout": [
  null,
  "Pienennä aikakatkaisua"
 ],
 "Increase timeout": [
  null,
  "Nosta aikakatkaisua"
 ],
 "Start period": [
  null,
  "Aloitusjakso"
 ],
 "Health check start period help": [
  null,
  "Tietoa eheystarkistuksen aloitusjaksosta"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Alustusaika, joka tarvitaan kontin käynnistymiseen."
 ],
 "Decrease start period": [
  null,
  "Pienennä aloitusaikaa"
 ],
 "Increase start period": [
  null,
  "Pidennä aloitusjaksoa"
 ],
 "Retries": [
  null,
  "Uudelleenyritykset"
 ],
 "Health check retries help": [
  null,
  "Tietoa eheystarkistuksen uudelleenyrityksistä"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Yritysten enimmäismäärä, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "Decrease retries": [
  null,
  "Vähennä uudelleenyrityksiä"
 ],
 "Increase retries": [
  null,
  "Lisää uudelleenyrityksiä"
 ],
 "When unhealthy": [
  null,
  "Kun rikki"
 ],
 "Health failure check action help": [
  null,
  "Tietoa terveystarkistuksen virhetilan toimenpiteistä"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Toimenpiteet, kun kontti siirtyy epäterveelliseen tilaan."
 ],
 "Create container in $0": [
  null,
  "Luo kontti kohteeseen $0"
 ],
 "Create and run": [
  null,
  "Luo ja suorita"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Version": [
  null,
  "Versio"
 ],
 "Links": [
  null,
  "Linkit"
 ],
 "Documentation": [
  null,
  "Dokumentaatio"
 ],
 "Tags": [
  null,
  "Tunnisteet"
 ],
 "Created by": [
  null,
  "Tekijä"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Comments": [
  null,
  "Kommentit"
 ],
 "Unable to load image history": [
  null,
  "Levykuvan historian lataaminen epäonnistui"
 ],
 "Key must not be empty": [
  null,
  "Avain ei saa olla tyhjä"
 ],
 "Key must not begin with a digit": [
  null,
  "Avain ei saa alkaa numerolla"
 ],
 "Key contains invalid characters": [
  null,
  "Avain sisältää virheellisiä merkkejä"
 ],
 "Key": [
  null,
  "Avain"
 ],
 "Value": [
  null,
  "Arvo"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "Podman service failed": [
  null,
  "Podman-palvelu epäonnistui"
 ],
 "Troubleshoot": [
  null,
  "Vianetsintä"
 ],
 "Failed to force remove image $0": [
  null,
  "Levykuvan $0 pakotettu poistaminen epäonnistui"
 ],
 "intermediate image": [
  null,
  "välitasoinen levykuva"
 ],
 "Failed to remove image $0": [
  null,
  "Levykuvan $0 poistaminen epäonnistui"
 ],
 "intermediate": [
  null,
  "välitaso"
 ],
 "Delete $0 image?": [
  null,
  "Poistetaanko $0 kuva?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Tälle levykuvalle on useita tunnisteita. Valitse tunnisteelliset levykuvat jotka poistetaan."
 ],
 "Delete image": [
  null,
  "Poista levykuva"
 ],
 "Delete tagged images": [
  null,
  "Poista merkityt kuvat"
 ],
 "Container is not running": [
  null,
  "Kontti ei ole käynnissä"
 ],
 "Error occurred while connecting console": [
  null,
  "Virhe konsolia liitettäessä"
 ],
 "Force delete pod $0?": [
  null,
  "Pakota podin $0 poisto?"
 ],
 "Delete pod $0?": [
  null,
  "Poista podi $0?"
 ],
 "An error occurred": [
  null,
  "Tapahtui virhe"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Tyhjä podi $0 poistetaan pysyvästi."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Tämän podin poisto poistaa seuraavat kontit:"
 ],
 "Failed to start pod $0": [
  null,
  "Podin $0 käynnistäminen epäonnistui"
 ],
 "Failed to stop pod $0": [
  null,
  "Podin $0 pysäyttäminen epäonnistui"
 ],
 "Failed to restart pod $0": [
  null,
  "Podin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to resume pod $0": [
  null,
  "Podin $0 käytön jatkaminen epäonnistui"
 ],
 "Failed to pause pod $0": [
  null,
  "Podin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to prune unused containers": [
  null,
  "Käyttämättömien konttien poisto epäonnistui"
 ],
 "Removes selected non-running containers": [
  null,
  "Poistaa valitut ei käynnissä olevat kontit"
 ],
 "Pruning containers": [
  null,
  "Siivotaan kontteja"
 ],
 "Container name is required.": [
  null,
  "Kontin nimi vaaditaan."
 ],
 "Failed to rename container $0": [
  null,
  "Kontin $0 uudelleennimeäminen epäonnistui"
 ],
 "New container name": [
  null,
  "Kontin uusi nimi"
 ],
 "Rename container $0": [
  null,
  "Nimeä kontti $0 uudelleen"
 ],
 "Paused": [
  null,
  "Keskeytetty"
 ],
 "Stopped": [
  null,
  "Pysäytetty"
 ],
 "Removing": [
  null,
  "Poistetaan"
 ],
 "Configured": [
  null,
  "Asetukset asetettu"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "$0 second": [
  null,
  "$0 sekunti",
  "$0 sekuntia"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Failing streak": [
  null,
  "Epäonnistunut sarja"
 ],
 "Failed to run health check on container $0": [
  null,
  "Kontin $0 eheystarkastus epäonnistui"
 ],
 "Run health check": [
  null,
  "Aja eheystarkistus"
 ],
 "Last 5 runs": [
  null,
  "Viimeiset 5 ajoa"
 ],
 "Started at": [
  null,
  "Käynnistetty klo"
 ],
 "Passed health run": [
  null,
  "Onnistunut eheysajo"
 ],
 "Failed health run": [
  null,
  "Epäonnistunut eheysajo"
 ],
 "Failed to remove container $0": [
  null,
  "Kontin $0 poistaminen epäonnistui"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ]
});
