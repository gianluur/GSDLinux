cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "heslo"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "uživatelské jméno"
 ],
 "login": [
  null,
  "přihlášení"
 ],
 "access": [
  null,
  "přístup"
 ],
 "roles": [
  null,
  "role"
 ],
 "keys": [
  null,
  "klíče"
 ],
 "Managing user accounts": [
  null,
  "Správa uživatelských účtů"
 ]
});
