cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Tiedostoselain"
 ],
 "files": [
  null,
  "tiedostot"
 ],
 "explorer": [
  null,
  "selain"
 ],
 "filesystem": [
  null,
  "tiedostojärjestelmä"
 ]
});
