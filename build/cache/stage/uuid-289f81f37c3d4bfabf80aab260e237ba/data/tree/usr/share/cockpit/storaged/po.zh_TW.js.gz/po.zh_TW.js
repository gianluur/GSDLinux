cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "重新安裝作業系統通常會導致金鑰變更。然而，未預期的變更可能是第三方嘗試竊聽連線的跡象。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要確保您的連線未被惡意的第三方截取，請驗證主機金鑰指紋："
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Server": [
  null,
  "伺服器"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Type": [
  null,
  "類型"
 ],
 "Copy": [
  null,
  "複製"
 ],
 "Copied": [
  null,
  "已複製"
 ],
 "Unlock": [
  null,
  "解除鎖定"
 ],
 "Add key": [
  null,
  "新增金鑰"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Edit": [
  null,
  "編輯"
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Select": [
  null,
  "選擇"
 ],
 "No results found": [
  null,
  "沒有找到結果"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安裝"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "未在 $0 上安裝相容的 Cockpit 版本。"
 ],
 "Set": [
  null,
  "設定"
 ],
 "Add": [
  null,
  "加入"
 ],
 "Port": [
  null,
  "連接埠"
 ],
 "$0 key changed": [
  null,
  "金鑰 $0 已被更改"
 ],
 "Trust and add host": [
  null,
  "信任並新增主機"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要驗證指紋，請實際坐在機器前或透過可信任的網路於 $0 上執行以下指令："
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指紋相符，點選「信任並新增主機」。否則，不要連線並聯絡您的管理人員。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。如果您需要其他人士為您進行驗證，那些人士可使用任何方法傳送結果。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次連線到 $0 。"
 ],
 "Verify fingerprint": [
  null,
  "驗證指紋"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "由受信任的網路或親自到場於遠端機器上執行此指令："
 ],
 "The fingerprint should match:": [
  null,
  "指紋應該相符："
 ],
 "The password can not be empty": [
  null,
  "密碼不可為空值"
 ],
 "The key password can not be empty": [
  null,
  "金鑰密碼不可為空值"
 ],
 "The key passwords do not match": [
  null,
  "金鑰密碼不相符"
 ],
 "Log in to $0": [
  null,
  "登入至 $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "無法登入 $0 。該主機不接受密碼登入、或您的任何 SSH 金鑰。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 所用的金鑰受到密碼保護，且該主機並不允許使用密碼登入。請於 $1 提供該金鑰的密碼。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 金鑰受到保護。您可以用您的登入密碼、或提供前述金鑰的密碼於 $1 以便登入。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "建立新的 SSH 金鑰並對其授權"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "將為了在 $2 上的 $1 建立一個於 $0 的新 SSH 金鑰，且其將會被加到 $5 上 $4 的 $3 檔案中。"
 ],
 "Key password": [
  null,
  "金鑰密碼"
 ],
 "Confirm key password": [
  null,
  "確認金鑰密碼"
 ],
 "Authorize SSH key": [
  null,
  "授權 SSH 金鑰"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 金鑰 $0 將會被新增至 $5 上 $4 的 $3 檔案中。"
 ],
 "Authentication": [
  null,
  "核對"
 ],
 "SSH key": [
  null,
  "SSH 金鑰"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 金鑰 $0 將會於剩餘的工作階段可供使用，也將會可用於登入其他主機。"
 ],
 "Permission denied": [
  null,
  "使用權限被拒"
 ],
 "Clear input value": [
  null,
  "清除輸入的值"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無效的日期與時間格式"
 ],
 "Invalid time format": [
  null,
  "時間格式無效"
 ],
 "Invalid date format": [
  null,
  "日期格式無效"
 ],
 "Cannot schedule event in the past": [
  null,
  "無法安排過去的活動"
 ],
 "No delay": [
  null,
  "沒有延遲"
 ],
 "1 minute": [
  null,
  "1 分鐘"
 ],
 "5 minutes": [
  null,
  "5 分鐘"
 ],
 "20 minutes": [
  null,
  "20 分鐘"
 ],
 "40 minutes": [
  null,
  "40 分鐘"
 ],
 "60 minutes": [
  null,
  "60 分鐘"
 ],
 "Specific time": [
  null,
  "特定的時間"
 ],
 "Shut down": [
  null,
  "關機"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Message to logged in users": [
  null,
  "給已登入使用者的訊息"
 ],
 "Delay": [
  null,
  "延遲"
 ],
 "Pick date": [
  null,
  "選擇日期"
 ],
 "Toggle date picker": [
  null,
  "打開/關閉日期挑選器"
 ],
 "Synchronized": [
  null,
  "同步"
 ],
 "Synchronized with $0": [
  null,
  "已與 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步中"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在嘗試與 $0 同步"
 ],
 "Not synchronized": [
  null,
  "不同步"
 ],
 "Log messages": [
  null,
  "記錄訊息"
 ],
 "NTP server": [
  null,
  "NTP 伺服器"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Automatically using NTP": [
  null,
  "自動使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自動使用額外的 NTP 伺服器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自動使用指定的 NTP 伺服器"
 ],
 "Time zone": [
  null,
  "時區"
 ],
 "Set time": [
  null,
  "設定時間"
 ],
 "Invalid timezone": [
  null,
  "無效的時區"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一台 NTP 伺服器"
 ],
 "Change system time": [
  null,
  "變更系統時間"
 ],
 "Change": [
  null,
  "變更"
 ],
 "Path to file": [
  null,
  "檔案路徑"
 ],
 "No such file or directory": [
  null,
  "無此檔案或目錄"
 ],
 "Create $0": [
  null,
  "建立 $0"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "You now have administrative access.": [
  null,
  "您現在已有管理員存取權限。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "請進行驗證以獲得管理員存取權限"
 ],
 "Switch to administrative access": [
  null,
  "切換至管理員存取模式"
 ],
 "Authenticate": [
  null,
  "認證"
 ],
 "Administrative access": [
  null,
  "管理員存取模式"
 ],
 "Problem becoming administrator": [
  null,
  "切換為管理員時發生問題"
 ],
 "Method": [
  null,
  "方法"
 ],
 "Limit access": [
  null,
  "限制存取"
 ],
 "Switch to limited access": [
  null,
  "切換至受限存取模式"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "受限制的存取模式會限制管理員權限。網頁控制台的部份功能將會縮減。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的瀏覽器將在不同工作階段間記住您的存取權限等級。"
 ],
 "Limited access": [
  null,
  "受限制的存取"
 ],
 "Turn on administrative access": [
  null,
  "打開管理員存取權限"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 hour": [
  null,
  "$0 小時"
 ],
 "$0 minute": [
  null,
  "$0 分鐘"
 ],
 "Go to now": [
  null,
  "移至現在"
 ],
 "1 hour": [
  null,
  "1 小時"
 ],
 "6 hours": [
  null,
  "6 小時"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 week": [
  null,
  "1週"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "啟用 firewalld 中的 $0 失敗"
 ],
 "Visit firewall": [
  null,
  "前往防火牆"
 ],
 "Zone": [
  null,
  "區域"
 ],
 "Add $0": [
  null,
  "新增 $0"
 ],
 "less than a minute ago": [
  null,
  "不到一分鐘前"
 ],
 "in less than a minute": [
  null,
  "於一分鐘內"
 ],
 "Password is too weak": [
  null,
  "密碼太弱了"
 ],
 "Excellent password": [
  null,
  "優秀的密碼"
 ],
 "Password is not acceptable": [
  null,
  "密碼是不可接受的"
 ],
 "Strong password": [
  null,
  "強密碼"
 ],
 "Acceptable password": [
  null,
  "可接受的密碼強度"
 ],
 "Weak password": [
  null,
  "弱密碼"
 ],
 "Show password": [
  null,
  "顯示密碼"
 ],
 "Hide password": [
  null,
  "隱藏密碼"
 ],
 "password quality": [
  null,
  "密碼品質"
 ],
 "Show confirmation password": [
  null,
  "顯示確認密碼"
 ],
 "Hide confirmation password": [
  null,
  "隱藏確認密碼"
 ],
 "Additional packages:": [
  null,
  "額外軟體包："
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Total size: $0": [
  null,
  "總大小： $0"
 ],
 "Install software": [
  null,
  "安裝軟體"
 ],
 "$0 will be installed.": [
  null,
  "$0 將會被安裝。"
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他軟體管理動作完成"
 ],
 "Checking installed software": [
  null,
  "正在檢查已安裝的軟體"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 在任何軟體庫中都未提供。"
 ],
 "Downloading $0": [
  null,
  "下載 $0"
 ],
 "Removing $0": [
  null,
  "正在移除 $0"
 ],
 "Installing $0": [
  null,
  "正在安裝 $0"
 ],
 "Unknown host: $0": [
  null,
  "未知的主機： $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "無法使用 SSH 金鑰驗證登入 $0。請提供密碼。"
 ],
 "SSH key login": [
  null,
  "SSH 金鑰登入"
 ],
 "[no data]": [
  null,
  "[沒有資料]"
 ],
 "[binary data]": [
  null,
  "[二進位資料]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 當掉了"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit 回報了錯誤碼 $0"
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "Row expansion": [
  null,
  "展開橫列"
 ],
 "Row select": [
  null,
  "選擇列"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "貼上"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "貼上時發生錯誤"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的瀏覽器不允許從網頁選單貼上。您可以使用 Shift+Insert 。"
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "鍵入以篩選"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "檔案系統"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "沒有找到相符的結果"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "檔案"
 ],
 "Copy to clipboard": [
  null,
  "複製到剪貼簿"
 ],
 "Automation script": [
  null,
  "自動化腳本"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "以此內容建立新的工作檔案。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文件"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "沒有系統異動"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登入的使用者沒有檢視系統變更所需的權限"
 ],
 "Loading system modifications...": [
  null,
  "讀取系統變更中…"
 ],
 "View automation script": [
  null,
  "檢視自動化 script"
 ],
 "Occurrences": [
  null,
  "發生次數"
 ],
 "View all logs": [
  null,
  "檢視所有日誌紀錄檔"
 ],
 "Other": [
  null,
  "其它"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Desktop": [
  null,
  "桌機"
 ],
 "Low profile desktop": [
  null,
  "尺寸較小的桌上型電腦"
 ],
 "Pizza box": [
  null,
  "披薩盒"
 ],
 "Mini tower": [
  null,
  "迷你塔"
 ],
 "Tower": [
  null,
  "塔"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Laptop": [
  null,
  "筆記型電腦"
 ],
 "Notebook": [
  null,
  "筆記型"
 ],
 "Handheld": [
  null,
  "手持裝置"
 ],
 "Docking station": [
  null,
  "擴充基座"
 ],
 "All-in-one": [
  null,
  "一體成型電腦"
 ],
 "Sub-Notebook": [
  null,
  "小筆電"
 ],
 "Space-saving computer": [
  null,
  "節省空間的計算機"
 ],
 "Lunch box": [
  null,
  "午餐盒"
 ],
 "Main server chassis": [
  null,
  "主伺服器機殼"
 ],
 "Expansion chassis": [
  null,
  "擴充機殼"
 ],
 "Sub-Chassis": [
  null,
  "子機殼"
 ],
 "Bus expansion chassis": [
  null,
  "匯流排擴充機殼"
 ],
 "Peripheral chassis": [
  null,
  "週邊設備機殼"
 ],
 "RAID chassis": [
  null,
  "RAID 機殼"
 ],
 "Rack mount chassis": [
  null,
  "機架式機殼"
 ],
 "Sealed-case PC": [
  null,
  "密封式PC"
 ],
 "Multi-system chassis": [
  null,
  "多系統機殼"
 ],
 "Compact PCI": [
  null,
  "緊密型 PCI"
 ],
 "Advanced TCA": [
  null,
  "進階 TCA"
 ],
 "Blade": [
  null,
  "刀鋒"
 ],
 "Blade enclosure": [
  null,
  "刀鋒外殼"
 ],
 "Tablet": [
  null,
  "平板電腦"
 ],
 "Convertible": [
  null,
  "二合一電腦"
 ],
 "Detachable": [
  null,
  "可拆開"
 ],
 "IoT gateway": [
  null,
  "物聯網閘道"
 ],
 "Embedded PC": [
  null,
  "嵌入式PC"
 ],
 "Mini PC": [
  null,
  "迷你電腦"
 ],
 "Stick PC": [
  null,
  "堅持使用PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "單 Rank"
 ],
 "Dual rank": [
  null,
  "雙 Rank"
 ],
 "Absent": [
  null,
  "不存在"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Old password not accepted": [
  null,
  "舊密碼不被接受"
 ],
 "Failed to change password": [
  null,
  "無法更改密碼"
 ],
 "New password was not accepted": [
  null,
  "不接受新密碼"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "以 ssh-keygen 提示輸入已逾時"
 ],
 "Not a valid private key": [
  null,
  "不是有效的私鑰"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "以 ssh-add 提示輸入已逾時"
 ],
 "Invalid file permissions": [
  null,
  "檔案權限無效"
 ],
 "Password not accepted": [
  null,
  "密碼不被接受"
 ],
 "Select an option": [
  null,
  "選擇選項"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 被 $1 訊號終止執行"
 ],
 "$0 exited with code $1": [
  null,
  "$0 結束執行並回傳 $1"
 ],
 "$0 failed": [
  null,
  "$0 失敗"
 ],
 "Your session has been terminated.": [
  null,
  "您的工作階段已被終止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "您的工作階段已過期。請再次登入。"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允許執行此操作。"
 ],
 "Login failed": [
  null,
  "登入失敗"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "伺服器拒絕使用任何受支援的方式進行驗證。"
 ],
 "Untrusted host": [
  null,
  "不受信任的主機"
 ],
 "Host key is incorrect": [
  null,
  "主機金鑰不正確"
 ],
 "Internal error": [
  null,
  "內部錯誤"
 ],
 "Connection has timed out.": [
  null,
  "連線已逾時。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安裝在系統上。"
 ],
 "Cannot forward login credentials": [
  null,
  "無法轉發登入憑證"
 ],
 "Server has closed the connection.": [
  null,
  "伺服器已關閉連線。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 與該系統上的軟體不相容。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 無法聯絡指定的主機。"
 ],
 "Too much data": [
  null,
  "資料過多"
 ],
 "Description": [
  null,
  "說明"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "View logs": [
  null,
  "檢視紀錄檔"
 ],
 "Dismiss": [
  null,
  "清除"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "Model": [
  null,
  "型號"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "none": [
  null,
  "無"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "Running": [
  null,
  "執行中"
 ],
 "Not running": [
  null,
  "非執行中"
 ],
 "Loading...": [
  null,
  "正在載入..."
 ],
 "User": [
  null,
  "使用者"
 ],
 "Vendor": [
  null,
  "供應商"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "大小"
 ],
 "State": [
  null,
  "狀態"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Start": [
  null,
  "開始"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Confirm deletion of $0": [
  null,
  "確認刪除 $0"
 ],
 "Username": [
  null,
  "使用者名稱"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Rename": [
  null,
  "重新命名"
 ],
 "Started": [
  null,
  "啟動於"
 ],
 "Delete group": [
  null,
  "刪除群組"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Lock": [
  null,
  "鎖定"
 ],
 "Use $0": [
  null,
  "使用 $0"
 ],
 "Service": [
  null,
  "服務管理"
 ],
 "Disconnect": [
  null,
  "斷線"
 ],
 "Address": [
  null,
  "位址"
 ],
 "$0 disk is missing": [
  null,
  "$0 個磁碟遺失中"
 ],
 "Location": [
  null,
  "位置"
 ],
 "Compression": [
  null,
  "壓縮"
 ],
 "Storage logs": [
  null,
  "儲存日誌"
 ],
 "Name cannot be empty.": [
  null,
  "名稱不能為空。"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名稱不能超過 127 個字元。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名稱不能包含字元 '$0“。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名稱不能包含空格。"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名稱不能超過 $0 個字元"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名稱不能超過 $0 位元組"
 ],
 "$name (from $host)": [
  null,
  "$name （從 $host）"
 ],
 "Pool for thin logical volumes": [
  null,
  "精簡邏輯磁碟區"
 ],
 "Thin logical volume": [
  null,
  "精簡邏輯磁碟區"
 ],
 "Logical volume (snapshot)": [
  null,
  "邏輯磁碟區（快照）"
 ],
 "Logical volume": [
  null,
  "邏輯磁碟區"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID 裝置 $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 磁碟區群組 $0"
 ],
 "VDO device $0": [
  null,
  "VDO 裝置 $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 的已加密邏輯磁碟區"
 ],
 "Encrypted partition of $0": [
  null,
  "已加密分割區 $0"
 ],
 "Logical volume of $0": [
  null,
  "邏輯磁碟區 $0"
 ],
 "Partition of $0": [
  null,
  "$0 的分割區"
 ],
 "Encrypted $0": [
  null,
  "加密 $0"
 ],
 "unpartitioned space on $0": [
  null,
  "於 $0 上未分割的空間"
 ],
 "unmount": [
  null,
  "卸載"
 ],
 "mount": [
  null,
  "掛載"
 ],
 "remove from btrfs volume": [
  null,
  "從 btrfs 磁碟區中移除"
 ],
 "stop": [
  null,
  "停止"
 ],
 "remove from MDRAID": [
  null,
  "從 MDRAID 移除"
 ],
 "remove from LVM2": [
  null,
  "從 LVM2 移除"
 ],
 "btrfs device": [
  null,
  "btrfs 裝置"
 ],
 "btrfs volume": [
  null,
  "btrfs 磁碟區"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "名稱不可超過 255 個字元。"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "名稱不能包含 '/' 字元。"
 ],
 "Create and mount": [
  null,
  "建立並掛載"
 ],
 "Create only": [
  null,
  "僅建立"
 ],
 "Create subvolume": [
  null,
  "建立子磁碟區"
 ],
 "Mount Point": [
  null,
  "掛載點"
 ],
 "delete": [
  null,
  "刪除"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "要永久刪除子磁碟區 $0 嗎？"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "進行刪除將刪除此子磁碟區與其子磁碟區所含的所有資料。"
 ],
 "Edit mount point": [
  null,
  "編輯掛載點"
 ],
 "Unmount": [
  null,
  "卸載"
 ],
 "Mount": [
  null,
  "掛載"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "至少一個子磁碟區須被掛載"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "無法刪除最後一個已掛載的子磁碟區"
 ],
 "btrfs subvolume": [
  null,
  "btrfs 子磁碟區"
 ],
 "Snapshot origin": [
  null,
  "快照來源"
 ],
 "Mount point": [
  null,
  "掛載"
 ],
 "No subvolumes": [
  null,
  "無子磁碟區"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs 子磁碟區"
 ],
 "Snapshots": [
  null,
  "快照"
 ],
 "No snapshots found": [
  null,
  "未找到快照"
 ],
 "snapshot": [
  null,
  "快照"
 ],
 "$0 is in use": [
  null,
  "$0 正被使用"
 ],
 "Permanently delete $0?": [
  null,
  "永久刪除 $0 嗎？"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "刪除會刪除 btrfs 磁碟區上的所有資料。"
 ],
 "Delete filesystem": [
  null,
  "刪除檔案系統"
 ],
 "Change label": [
  null,
  "變更標籤"
 ],
 "Filesystem is mounted read-only": [
  null,
  "檔案系統以唯讀方式掛載"
 ],
 "Label": [
  null,
  "標籤"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "btrfs devices": [
  null,
  "btrfs 裝置"
 ],
 "No devices found": [
  null,
  "未找到裝置"
 ],
 "btrfs filesystem": [
  null,
  "btrfs 檔案系統"
 ],
 "Successful": [
  null,
  "成功"
 ],
 "Aborted": [
  null,
  "已中止"
 ],
 "In progress": [
  null,
  "進行中"
 ],
 "Interrupted": [
  null,
  "中斷"
 ],
 "Did not complete": [
  null,
  "未完成"
 ],
 "Failed (Unknown)": [
  null,
  "失敗(不明)"
 ],
 "Failed (Electrical)": [
  null,
  "失敗（與電有關的問題）"
 ],
 "Failed (Servo)": [
  null,
  "失敗(Servo)"
 ],
 "Failed (Read)": [
  null,
  "失敗(讀取)"
 ],
 "Failed (Damaged)": [
  null,
  "失敗（己損壞）"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "因控制器層級重設而中止"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "由於從命名空間清單中移除命名空間而中止"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "因處理格式化 NVM 指令而中止"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "自檢作業期間發生致命錯誤"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "已完成，但有一個段落失敗，且失敗的段落未知"
 ],
 "Completed with one or more failed segments": [
  null,
  "已完成，但有一個或多個段落失敗"
 ],
 "Aborted for unknown reason": [
  null,
  "因不明原因中止"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "因清理操作而中止"
 ],
 "Spare capacity is below the threshold": [
  null,
  "備用容量低於臨界值"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "溫度超出建議的臨界值"
 ],
 "Degraded": [
  null,
  "已降級"
 ],
 "All media is in read-only mode": [
  null,
  "所有媒體都處於唯讀模式"
 ],
 "Volatile memory backup failed": [
  null,
  "揮發性記憶體備份失敗"
 ],
 "Persistent memory has become read-only": [
  null,
  "持久記憶體已變成唯讀"
 ],
 "Run short test": [
  null,
  "執行簡短測試"
 ],
 "Run extended test": [
  null,
  "執行延伸測試"
 ],
 "Abort test": [
  null,
  "中止測試"
 ],
 "Disk is failing": [
  null,
  "磁碟即將故障"
 ],
 "Disk is OK": [
  null,
  "磁碟沒問題"
 ],
 "Assessment": [
  null,
  "狀況評估"
 ],
 "Power on hours": [
  null,
  "開機時間"
 ],
 "$0 hours": [
  null,
  "$0 小時"
 ],
 "Self-test status": [
  null,
  "自檢狀態"
 ],
 "Number of bad sectors": [
  null,
  "損壞的磁區數量"
 ],
 "Attributes failing": [
  null,
  "屬性失敗"
 ],
 "Media drive": [
  null,
  "媒體驅動裝置"
 ],
 "Solid State Drive": [
  null,
  "固態硬碟"
 ],
 "Hard Disk Drive": [
  null,
  "傳統硬碟"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI 硬碟機"
 ],
 "Drive": [
  null,
  "駕駛"
 ],
 "Device health (SMART)": [
  null,
  "裝置健康度 (SMART)"
 ],
 "Firmware version": [
  null,
  "韌體版本"
 ],
 "Serial number": [
  null,
  "序號"
 ],
 "World wide name": [
  null,
  "全域名稱"
 ],
 "No media inserted": [
  null,
  "沒有插入媒體"
 ],
 "Device file": [
  null,
  "裝置檔案"
 ],
 "Multipathed devices": [
  null,
  "多重路徑裝置"
 ],
 "Free space": [
  null,
  "可用空間"
 ],
 "Create partition": [
  null,
  "建立分割區"
 ],
 "Extended partition": [
  null,
  "延伸分割區"
 ],
 "$0 partitions": [
  null,
  "$0 分割區"
 ],
 "Partitions": [
  null,
  "分割區"
 ],
 "No partitions found": [
  null,
  "未找到分割區"
 ],
 "Unexpected partitions": [
  null,
  "非預期的分割區"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "此區塊裝置不支援分割區。如果這是作為一部虛擬機器的磁碟，須經由虛擬機器內的作業系統管理分割區。"
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "刪除分割區將刪除其中的所有資料。"
 ],
 "No free space after this partition": [
  null,
  "此分割區之後已無可用空間"
 ],
 "EFI system partition": [
  null,
  "EFI 系統分割區"
 ],
 "BIOS boot partition": [
  null,
  "BIOS 開機分割區"
 ],
 "Partition": [
  null,
  "分割區"
 ],
 "Shrink": [
  null,
  "縮小"
 ],
 "Grow": [
  null,
  "延展"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP 開機分割區"
 ],
 "Linux swap space": [
  null,
  "Linux 置換空間"
 ],
 "Linux filesystem data": [
  null,
  "Linux 檔案系統資料"
 ],
 "Logical Volume Manager partition": [
  null,
  "邏輯磁碟區管理器 (LVM) 分割區"
 ],
 "Custom": [
  null,
  "自訂"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "類型須為一字不差的兩個十六進位字元 (0 到 9、A 到 F)。"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "類型僅能包含字元 0 到 9、A 到 F，以及 \"-\" 。"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "類型須為 NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN 的格式。"
 ],
 "Set partition type of $0": [
  null,
  "設定 $0 的分割區類型"
 ],
 "Custom type": [
  null,
  "自訂類型"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "變更分割區類型可能會導致系統無法開機。"
 ],
 "This partition is not completely used by its content.": [
  null,
  "此分割區的內容物未完整利用該分割區。"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "分割區大小為 $0。內容大小為 $1。"
 ],
 "Shrink partition": [
  null,
  "縮小分割區"
 ],
 "Grow content": [
  null,
  "擴展內容物"
 ],
 "initialize": [
  null,
  "初始化"
 ],
 "Initialize disk $0": [
  null,
  "初始化磁碟 $0"
 ],
 "Partitioning": [
  null,
  "分割表"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "相容於所有系統和裝置（MBR）"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "相容現代系統和 > 2TB 硬碟 (GPT)"
 ],
 "No partitioning": [
  null,
  "無分割表"
 ],
 "Overwrite": [
  null,
  "覆寫"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "用零覆寫現有的資料 （較慢）"
 ],
 "Initialize": [
  null,
  "初始化"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初始化會刪除磁碟上的所有資料。"
 ],
 "Device is read-only": [
  null,
  "裝置是唯讀的"
 ],
 "Create partition table": [
  null,
  "建立分割表"
 ],
 "Size must be a number": [
  null,
  "大小必須是數字"
 ],
 "Size cannot be zero": [
  null,
  "大小不能為零"
 ],
 "Size cannot be negative": [
  null,
  "大小不能是負面的"
 ],
 "Size is too large": [
  null,
  "尺寸太大"
 ],
 "Size must be at least $0": [
  null,
  "尺寸必須至少為 $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 磁碟區群組的實體磁碟區"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID 裝置的成員"
 ],
 "backing device for VDO device": [
  null,
  "VDO 裝置的後備裝置"
 ],
 "member of Stratis pool": [
  null,
  "Stratis 集池的成員"
 ],
 "Filesystem outside the target": [
  null,
  "目標以外的檔案系統"
 ],
 "device of btrfs volume": [
  null,
  "btrfs 磁碟區的裝置"
 ],
 "This device is currently in use.": [
  null,
  "這個裝置目前使用中。"
 ],
 "Device": [
  null,
  "裝置"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Services using the location": [
  null,
  "使用此位置的服務"
 ],
 "Processes using the location": [
  null,
  "正在使用該位置的處理程序"
 ],
 "Currently in use": [
  null,
  "現正使用中"
 ],
 "(Not part of target)": [
  null,
  "（非目標的一部分）"
 ],
 "These changes will be made:": [
  null,
  "將會進行這些變更："
 ],
 "Action": [
  null,
  "動作"
 ],
 "Important data might be deleted:": [
  null,
  "重要的資料可能會被刪除："
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "相關的處理程序與服務將被強制終止。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "相關的處理程序將被強制中止。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "相關的服務將被強制終止。"
 ],
 "Checking filesystem usage": [
  null,
  "正在檢查檔案系統使用量"
 ],
 "$0 used, $1 total": [
  null,
  "已使用 $0 ，共 $1"
 ],
 "Device contains unrecognized data": [
  null,
  "裝置包含無法辨識的資料"
 ],
 "Locked encrypted device might contain data": [
  null,
  "已鎖定的加密裝置可能含有資料"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "我確認我想要永遠遺失此資料"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "這些處理程序仍在使用掛載點 $0 ："
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "指令"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "這些服務仍在使用掛載點 $0 ："
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "所列的處理程序與服務將被強制停止。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "所列的處理程序將會被強制停止。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "所列的服務將會被強制停止。"
 ],
 "Sorry": [
  null,
  "抱歉"
 ],
 "Usage of $0": [
  null,
  "$0 的使用率"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO 集池"
 ],
 "Data used": [
  null,
  "資料已使用"
 ],
 "Metadata used": [
  null,
  "已使用的後設資料"
 ],
 "Use compression": [
  null,
  "使用壓縮"
 ],
 "Deduplication": [
  null,
  "重複資料刪除"
 ],
 "Use deduplication": [
  null,
  "使用 deduplication"
 ],
 "Rename volume group": [
  null,
  "重命名卷組"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "此磁碟區群組內含根檔案系統。若將其重新命名，可能須進一步變更開機啟動程式的設定或核心指令行。"
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "進行刪除將會刪除磁碟區群組上的所有資料。"
 ],
 "Create snapshot": [
  null,
  "建立快照"
 ],
 "Add disks": [
  null,
  "新增磁碟"
 ],
 "Disks": [
  null,
  "磁碟"
 ],
 "No disks are available.": [
  null,
  "沒有磁碟可用。"
 ],
 "At least one disk is needed.": [
  null,
  "至少需要一個磁碟。"
 ],
 "Volume group is missing physical volumes": [
  null,
  "磁碟區群組缺少實體磁碟區"
 ],
 "No free space": [
  null,
  "沒有自由空間"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 磁碟區群組"
 ],
 "Add physical volume": [
  null,
  "新增實體磁碟區"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 邏輯磁碟區"
 ],
 "Create new logical volume": [
  null,
  "建立新邏輯磁碟區"
 ],
 "No logical volumes": [
  null,
  "沒有邏輯磁碟區"
 ],
 "Remove missing physical volumes?": [
  null,
  "要移除找不到的實體磁碟區嗎？"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "此磁碟區群組遺失部份的實體磁碟區。"
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "一個遺失實體磁碟區的磁碟區群組無法被重新命名。"
 ],
 "Physical volumes": [
  null,
  "物理卷"
 ],
 "No physical volumes found": [
  null,
  "未找到實體磁碟區"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 實體磁碟區"
 ],
 "Rename logical volume": [
  null,
  "重新命名邏輯磁碟區"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "要永久刪除邏輯磁碟區 $0/$1 嗎？"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "刪除邏輯磁碟區將刪除其中的所有資料。"
 ],
 "Unable to repair logical volume $0": [
  null,
  "無法修復邏輯磁碟區 $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "能被用於修復的可用空間不足。未用於此邏輯磁碟區的實體磁碟區至少需要 $0 的可用空間。"
 ],
 "An additional $0 must be selected": [
  null,
  "必須額外選擇 $0"
 ],
 "Repair logical volume $0": [
  null,
  "修復邏輯磁碟區 $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "選擇要用來修復邏輯磁碟區的實體磁碟區。至少需要 $0 個。"
 ],
 "Physical Volumes": [
  null,
  "實體磁碟區"
 ],
 "Repair": [
  null,
  "修復"
 ],
 "deactivate": [
  null,
  "停用"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "停止邏輯磁碟區 $0/$1 嗎？"
 ],
 "Deactivate": [
  null,
  "取消啟動"
 ],
 "Not enough space to grow": [
  null,
  "已無可用以擴展的空間"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 邏輯磁碟區"
 ],
 "Striped (RAID 0)": [
  null,
  "分散存放 (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "鏡射存放 (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "分散再鏡射存放 (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "專屬奇偶存放 (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "分散式奇偶存放 (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "雙重分散式奇偶存放 (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "此邏輯磁碟區的內容物未完整利用該磁碟區。"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "磁碟區大小是 $0 。內容物大小是 $1 。"
 ],
 "Shrink volume": [
  null,
  "縮小磁碟區"
 ],
 "Layout": [
  null,
  "配置"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "這個邏輯磁碟區遺失了部份的實體磁碟區、且無法再被使用。您必須刪除它，並建立一個新的以取代它。"
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "這個邏輯磁碟區遺失了部份的實體磁碟區，但尚未失去任何資料。您應該修復它以回到原本的冗餘狀態。"
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "這個邏輯磁碟區遺失了部份的實體磁碟區，但尚未失去任何資料。您可能可以修復它。"
 ],
 "Stripes": [
  null,
  "分散存放"
 ],
 "$0 synchronized": [
  null,
  "$0 已同步"
 ],
 "Create volume group": [
  null,
  "建立磁碟區群組"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 實體磁碟區"
 ],
 "Last cannot be removed": [
  null,
  "最後一個無法被移除"
 ],
 "Not enough free space": [
  null,
  "可用空間不足"
 ],
 "Volume group": [
  null,
  "儲區群組"
 ],
 "Create thin volume": [
  null,
  "建立精簡卷"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "精簡佈建的 LVM2 邏輯磁碟區"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "建立新的精簡佈建邏輯磁碟區"
 ],
 "Not enough space": [
  null,
  "空間不足"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "用於精簡佈建 LVM2 邏輯磁碟區的集池"
 ],
 "Inactive logical volume": [
  null,
  "非作用中的邏輯磁碟區"
 ],
 "Activate": [
  null,
  "使用"
 ],
 "Unsupported logical volume": [
  null,
  "未支援的邏輯磁碟區"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "內部錯誤 - 這個邏輯磁碟區被標記為啟用且應該擁有一個相聯的區塊裝置。然而，沒有找到前述的區塊裝置。"
 ],
 "Installing $0 would remove $1.": [
  null,
  "安裝 $0 將會移除 $1 。"
 ],
 "Installing packages": [
  null,
  "安裝軟體包"
 ],
 "Block device for filesystems": [
  null,
  "用於檔案系統的區塊裝置"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "用於精簡佈建磁碟區的集池"
 ],
 "Linear": [
  null,
  "線性"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO 檔案系統磁碟區 （壓縮/去重複）"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "資料將儲存在所選擇的物理磁碟區上，但沒有任何冗餘複本或效能改善。"
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "資料將分散存在選擇的物理磁碟區上以提高效能。至少須選擇兩個磁碟區。"
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "資料將會以兩個或更多複本的形式存在選擇的物理磁碟區，以改善可靠性。須選擇至少兩個磁碟區。"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "資料將儲存為兩個複本、且以分散形式存於選擇的物理磁碟區上，同時改善可靠度與效能。至少需要選擇四個磁碟區。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "資料將儲存在選擇的物理磁碟區上，因此遺失一個磁碟區也不會影響資料。至少須選擇三個磁碟區。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "資料將儲存在選擇的物理磁碟區上，因此遺失一個磁碟區也不會影響資料。同時資料也會以分散形式儲存以改善效能。至少須選擇三個磁碟區。"
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "資料將儲存在選擇的物理磁碟區上，在最多兩個磁碟區同時遺失時也不會影響資料。資料同時也以分散形式儲存以改善效能。至少須選擇五個磁碟區。"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "所選的配置需要全部 $0 個已選擇的實體磁碟區。"
 ],
 "Create logical volume": [
  null,
  "建立邏輯磁碟區"
 ],
 "Purpose": [
  null,
  "用途"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "須安裝 $0 軟體包以建立 VDO 裝置。"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 需要偶數個實體磁碟區"
 ],
 "Logical size": [
  null,
  "邏輯大小"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "以 LZ4 壓縮個別區塊來節省空間"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "以只儲存相同的資料一次節省空間"
 ],
 "Creating VDO device": [
  null,
  "正在建立 VDO 裝置"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "此 NFS 掛載正在使用中，只能更改其選項。"
 ],
 "NFS mount": [
  null,
  "NFS 掛載"
 ],
 "New NFS mount": [
  null,
  "新的 NFS 掛載"
 ],
 "Server address": [
  null,
  "伺服器位址"
 ],
 "Server cannot be empty.": [
  null,
  "伺服器不能為空。"
 ],
 "Path on server": [
  null,
  "伺服器上的路徑"
 ],
 "Path on server cannot be empty.": [
  null,
  "伺服器上的路徑不能為空。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "伺服器上的路徑必須以 \"/\" 開頭。"
 ],
 "Local mount point": [
  null,
  "本機掛載點"
 ],
 "Mount point cannot be empty.": [
  null,
  "掛載點不能為空。"
 ],
 "Mount point must start with \"/\".": [
  null,
  "掛載點必須以“/”開頭。"
 ],
 "Mount options": [
  null,
  "掛載選項"
 ],
 "Mount at boot": [
  null,
  "開機時掛載"
 ],
 "Mount read only": [
  null,
  "掛載為唯讀"
 ],
 "Custom mount options": [
  null,
  "自訂掛載選項"
 ],
 "Unable to unmount filesystem": [
  null,
  "無法卸載檔案系統"
 ],
 "Stop and unmount": [
  null,
  "停止和卸載"
 ],
 "Unable to remove mount": [
  null,
  "無法刪除掛載"
 ],
 "Stop and remove": [
  null,
  "停止並刪除"
 ],
 "(not mounted)": [
  null,
  "（未掛載）"
 ],
 "Start multipath": [
  null,
  "啟動多路徑"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "系統上有具備多重路徑的裝置，但多重路徑 (multipath) 服務並未運作。"
 ],
 "Show all $0 rows": [
  null,
  "顯示共 $0 列"
 ],
 "Category": [
  null,
  "種類"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "Last modified: $0": [
  null,
  "最後變更於： $0"
 ],
 "Stored passphrase": [
  null,
  "已儲存的通行片語"
 ],
 "Encryption options": [
  null,
  "加密選項"
 ],
 "Encryption type": [
  null,
  "加密類型"
 ],
 "Cleartext device": [
  null,
  "明文裝置"
 ],
 "yes": [
  null,
  "是"
 ],
 "Disk passphrase": [
  null,
  "磁碟通行片語"
 ],
 "Passphrase cannot be empty": [
  null,
  "通行片語不可為空值"
 ],
 "Unlocking disk": [
  null,
  "正在解鎖磁碟"
 ],
 "Checking for $0 package": [
  null,
  "正在檢查 $0 軟體包"
 ],
 "The $0 package must be installed.": [
  null,
  "必須安裝 $0 軟體包。"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 軟體包在任何軟體庫中都未提供。"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "正在確認 initrd 中的 NBDE 支援"
 ],
 "The initrd must be regenerated.": [
  null,
  "必須重新產生 initrd 。"
 ],
 "Regenerating initrd": [
  null,
  "重新產生 initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "增加 rd.neednet=1 至核心的指令行"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "將 \"$0\" 新增至檔案系統選項"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "將 \"$0\" 新增至加密選項"
 ],
 "Enabling $0": [
  null,
  "正在啟用 $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "新增網路綁定硬碟加密"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "此系統目前不支援以 Tang keyserver 解鎖根檔案系統。"
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "此系統目前不支援在開機時使用 Tang keyserver 解鎖檔案系統。"
 ],
 "These additional steps are necessary:": [
  null,
  "這些額外步驟為必要的："
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "儲存新密碼需要先解鎖磁碟。請提供一個現有的通行片語。"
 ],
 "Fix NBDE support": [
  null,
  "修復 NBDE 支援"
 ],
 "Adding key": [
  null,
  "新增金鑰"
 ],
 "Key source": [
  null,
  "金鑰來源"
 ],
 "Repeat passphrase": [
  null,
  "重複通行片語"
 ],
 "Passphrase": [
  null,
  "通行片語"
 ],
 "Tang keyserver": [
  null,
  "唐鑰匙伺服器"
 ],
 "New passphrase": [
  null,
  "新的通行片語"
 ],
 "Passphrases do not match": [
  null,
  "通行片語不相符"
 ],
 "Keyserver address": [
  null,
  "金鑰伺服器位址"
 ],
 "Change passphrase": [
  null,
  "變更通行片語"
 ],
 "Old passphrase": [
  null,
  "舊的通行片語"
 ],
 "Edit Tang keyserver": [
  null,
  "編輯 Tang keyserver"
 ],
 "Verify key": [
  null,
  "驗證金鑰"
 ],
 "Trust key": [
  null,
  "信任金鑰"
 ],
 "Passphrase can not be empty": [
  null,
  "通行片語不可留白"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "刪除通行片語可能會導致無法解鎖 $0。"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "使用替代的通行片語確認移除"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "移除通行片語卻不先確認其餘通行片語的話，當忘記或遺失其他通行片語時，可能導致無法解鎖或管理金鑰。"
 ],
 "Passphrase from any other key slot": [
  null,
  "來自其他金鑰槽的通行片語"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "刪除金鑰槽 $0 中的通行片語？"
 ],
 "Remove $0?": [
  null,
  "移除 $0？"
 ],
 "Remove Tang keyserver?": [
  null,
  "移除 Tang keyserver？"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "目前登入的使用者不被允許檢視金鑰相關的資訊。"
 ],
 "No keys added": [
  null,
  "沒有新增金鑰"
 ],
 "Slot $0": [
  null,
  "插槽 $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "編輯金鑰需要一個未使用的插槽"
 ],
 "The last key slot can not be removed": [
  null,
  "無法移除最後一個金鑰槽"
 ],
 "Keyserver": [
  null,
  "金鑰伺服器"
 ],
 "Unknown type": [
  null,
  "未知類型"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "此處無法編輯未知類型的鍵槽"
 ],
 "Keys": [
  null,
  "按鍵"
 ],
 "$0 slot remains": [
  null,
  "尚餘 $0 個槽"
 ],
 "No available slots": [
  null,
  "沒有可用的插槽"
 ],
 "No free key slots": [
  null,
  "沒有免費的鑰匙槽"
 ],
 "Locked data": [
  null,
  "已鎖住的資料"
 ],
 "lock": [
  null,
  "鎖定"
 ],
 "Lock $0?": [
  null,
  "鎖定 $0?"
 ],
 "Address cannot be empty": [
  null,
  "位址不能空白"
 ],
 "Address is not a valid URL": [
  null,
  "位址不是有效的URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "使用 Tang 伺服器檢查金鑰雜湊。"
 ],
 "How to check": [
  null,
  "如何檢查"
 ],
 "In a terminal, run: ": [
  null,
  "在終端機中執行： "
 ],
 "Successfully copied to clipboard!": [
  null,
  "已成功複製到剪貼簿！"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "檢查指令中的 SHA-256 或 SHA-1 雜湊須與此對話框中的相符。"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "$1 的 btrfs 子磁碟區 $0"
 ],
 "Mount point cannot be empty": [
  null,
  "掛載點不可為空值"
 ],
 "Mount point is already used for $0": [
  null,
  "掛載點已經被用於 $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "檔案系統已被掛載於此掛載點下。"
 ],
 "Please unmount them first.": [
  null,
  "請先卸載它們。"
 ],
 "read only": [
  null,
  "唯讀"
 ],
 "never mount at boot": [
  null,
  "永不在開機時掛載"
 ],
 "after network": [
  null,
  "於網路可使用後"
 ],
 "ignore failure": [
  null,
  "忽略失敗"
 ],
 "stop boot on failure": [
  null,
  "失敗時停止開機"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "該檔案系統沒有被指派掛載點。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "該檔案系統沒有永久的掛載點。"
 ],
 "The filesystem is not mounted.": [
  null,
  "該檔案系統未被掛載。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "檔案系統將於下次開機時被解鎖並掛載。屆時可能需要輸入一個通行片語。"
 ],
 "(no assigned mount point)": [
  null,
  "（沒有已指派的掛載點）"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "此檔案系統目前被掛載於 $0，但下次開機時將被掛載於 $1 。"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "開機時自動於 $0 掛載"
 ],
 "Mount on $0 now": [
  null,
  "立刻掛載於 $0"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "此檔案系統目前未被掛載，但下次開機後將被掛載。"
 ],
 "Do not mount automatically on boot": [
  null,
  "不要在開機時自動掛載"
 ],
 "Mount now": [
  null,
  "立刻掛載"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "此檔案系統目前已被掛載，但下次開機後將不會被掛載。"
 ],
 "Mount also automatically on boot": [
  null,
  "在開機時也自動掛載"
 ],
 "Unmount now": [
  null,
  "立即卸載"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "該檔案系統目前掛載於 $0 ，但下次開機後將不會被掛載。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "該檔案系統被設定為在開機時自動掛載，但其內受加密的容器不會在此時被解鎖。"
 ],
 "Unlock automatically on boot": [
  null,
  "於開機時自動解鎖"
 ],
 "Inconsistent filesystem mount": [
  null,
  "不一致的檔案系統掛載"
 ],
 "$0 filesystem": [
  null,
  "$0 檔案系統"
 ],
 "Filesystem name": [
  null,
  "檔案系統名稱"
 ],
 "Filesystem is locked": [
  null,
  "檔案系統被鎖住"
 ],
 "Mounts before services start": [
  null,
  "服務啟動前掛載"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "適合用於關鍵的掛載點，例如 /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "若檔案系統未能掛載導致開機失敗，將無法遠端存取系統"
 ],
 "Mounts in parallel with services": [
  null,
  "與服務同步掛載"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "即使檔案系統未能掛載，開機仍會成功"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "與服務平行掛載，但於網路可使用後"
 ],
 "Does not mount during boot": [
  null,
  "在開機時不掛載"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "對需要互動（如輸入通行片語）或非必要性的掛載來說很有用"
 ],
 "At boot": [
  null,
  "於開機時"
 ],
 "Mount before services start": [
  null,
  "服務啟動前掛載"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "掛載但不等待完成，忽略失敗"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "於網路可使用後掛載，忽略失敗"
 ],
 "Do not mount": [
  null,
  "不要掛載"
 ],
 "This device can not be used for the installation target.": [
  null,
  "這個裝置不可被當作安裝目標。"
 ],
 "Mount filesystem": [
  null,
  "掛載檔案系統"
 ],
 "Unmount filesystem $0": [
  null,
  "卸載檔案系統 $0"
 ],
 "Mount configuration": [
  null,
  "掛載設定"
 ],
 "Swap": [
  null,
  "置換"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "解鎖已加密的 Stratis 集池"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "提供這些區塊裝置上的集池集通行片語："
 ],
 "Stratis pool": [
  null,
  "Stratis 集池"
 ],
 "stopped": [
  null,
  "已停止"
 ],
 "Block devices": [
  null,
  "區塊裝置"
 ],
 "No block devices found": [
  null,
  "沒有找到區塊裝置"
 ],
 "Stratis block devices": [
  null,
  "Stratis 區塊裝置"
 ],
 "Stratis block device": [
  null,
  "Stratis 區塊裝置"
 ],
 "data": [
  null,
  "資料"
 ],
 "cache": [
  null,
  "快取"
 ],
 "Pool passphrase": [
  null,
  "集池的通行片語"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  ""
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  ""
 ],
 "Create filesystem": [
  null,
  "建立檔案系統"
 ],
 "Stratis filesystem": [
  null,
  "Stratis 檔案系統"
 ],
 "Set initial size": [
  null,
  "設定初始大小"
 ],
 "Limit size": [
  null,
  "限制大小"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "刪除 Stratis 集池將刪除其包含的的所有資料。"
 ],
 "Rename Stratis pool": [
  null,
  "重新命名 Stratis 集池"
 ],
 "Add block devices": [
  null,
  "新增區塊裝置"
 ],
 "Tier": [
  null,
  "層"
 ],
 "Data": [
  null,
  "資料"
 ],
 "Cache": [
  null,
  "快取"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  ""
 ],
 "Encrypted Stratis pool": [
  null,
  "已加密的 Stratis 集池"
 ],
 "Delete pool": [
  null,
  "刪除集區"
 ],
 "Stratis filesystems": [
  null,
  "Stratis 檔案系統"
 ],
 "Create new filesystem": [
  null,
  "建立新的檔案系統"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "這個集池並未使用其所在的區塊裝置上所有空間。"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "這個集池中的某些區塊裝置空間在集區建立之後已被擴充。這個集池可安全的擴展以使用新的可用空間。"
 ],
 "Grow the pool to take all space": [
  null,
  "擴展集池並使用所有空間"
 ],
 "This pool is in a degraded state.": [
  null,
  "這個集池處於降級狀態。"
 ],
 "No filesystems": [
  null,
  "沒有檔案系統"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis 檔案系統集池"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "此通行片語是唯一可解鎖該集池的方法，故無法被移除。"
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "該 keyserver 是唯一解鎖集池的方式，故不可被移除。"
 ],
 "Add passphrase": [
  null,
  "新增通行片語"
 ],
 "Add keyserver": [
  null,
  "新增金鑰伺服器"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  ""
 ],
 "Confirm": [
  null,
  "確認"
 ],
 "Remove passphrase?": [
  null,
  "移除通行片語？"
 ],
 "Add Tang keyserver": [
  null,
  "新增 Tang 金鑰伺服器"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  ""
 ],
 "Overprovisioning": [
  null,
  "超額佈建"
 ],
 "Allow overprovisioning": [
  null,
  "允許超額佈建"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "虛擬檔案系統大小比集池還大。無法關閉超額佈建。"
 ],
 "Allocated": [
  null,
  "已分配"
 ],
 "Name can not be empty.": [
  null,
  "名稱不能為空。"
 ],
 "A pool with this name exists already.": [
  null,
  "一個相同名稱的集池已經存在。"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "一個相同名稱的檔案系統已經存在於這個集池中。"
 ],
 "Create Stratis pool": [
  null,
  "建立 Stratis 集區"
 ],
 "No block devices are available.": [
  null,
  "沒有可用的區塊裝置。"
 ],
 "At least one block device is needed.": [
  null,
  "至少需要一個區塊裝置。"
 ],
 "Encrypt data with a passphrase": [
  null,
  "使用通行片語加密資料"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "使用 Tang 金鑰伺服器加密資料"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "建立檔案系統 $0 的快照"
 ],
 "Create snapshot and mount": [
  null,
  "建立快照並掛載"
 ],
 "Create snapshot only": [
  null,
  "僅建立快照"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "刪除檔案系統將刪除其中的所有資料。"
 ],
 "Snapshot": [
  null,
  "快照"
 ],
 "Rename filesystem": [
  null,
  "重新命名檔案系統"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "對虛擬檔案系統大小設限"
 ],
 "Limit virtual filesystem size": [
  null,
  "限制虛擬檔案系統大小"
 ],
 "Virtual size limit": [
  null,
  "虛擬大小限制"
 ],
 "Virtual size": [
  null,
  "虛擬大小"
 ],
 "Create RAID device": [
  null,
  "建立 RAID 裝置"
 ],
 "RAID level": [
  null,
  "RAID 等級"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0（分散存放）"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1（鏡像存放）"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4（專用奇偶存放）"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5（分散式奇偶存放）"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6（雙分散式奇偶存放）"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10（分散再鏡射存放）"
 ],
 "Chunk size": [
  null,
  "塊大小"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "至少需要 $0 個磁碟。"
 ],
 "MDRAID disk": [
  null,
  "MDRAID 磁碟"
 ],
 "In sync": [
  null,
  "同步中"
 ],
 "Spare": [
  null,
  "備用"
 ],
 "Recovering": [
  null,
  "正在復原"
 ],
 "Write-mostly": [
  null,
  "寫入為主"
 ],
 "Blocked": [
  null,
  "阻止"
 ],
 "Unknown ($0)": [
  null,
  "未知（$0）"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID 裝置必須正在運作"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID 裝置正在復原"
 ],
 "Need a spare disk": [
  null,
  "需要一個備用磁碟"
 ],
 "Last disk can not be removed": [
  null,
  "最後一個磁碟無法被移除"
 ],
 "MDRAID device": [
  null,
  "MDRAID 裝置"
 ],
 "Confirm stopping of $0": [
  null,
  "確認要停止 $0"
 ],
 "Stop device": [
  null,
  "停止裝置"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "進行刪除將刪除 MDRAID 裝置上的所有資料。"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID 裝置須為執行中"
 ],
 "Add disk": [
  null,
  "新增磁碟"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID（$0）"
 ],
 "$0 disks": [
  null,
  "$0 個磁碟"
 ],
 "$0 chunk size": [
  null,
  "$0 區塊大小"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID 裝置處於降級狀態"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "此 MDRAID 裝置沒有 write-intent bitmap。這樣的 bitmap 可以大幅減少同步所需時間。"
 ],
 "Add a bitmap": [
  null,
  "新增 bitmap"
 ],
 "No disks found": [
  null,
  "未找到磁碟"
 ],
 "MDRAID disks": [
  null,
  "MDRAID 磁碟"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "進行刪除將會刪除 VDO 裝置上的所有資料。"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "此 VDO 裝置未完成建立，故無法使用該裝置。"
 ],
 "Remove device": [
  null,
  "移除裝置"
 ],
 "Grow to take all space": [
  null,
  "成長以佔據所有空間"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "此 VDO 裝置未使用其所有後備裝置。"
 ],
 "Only $0 of $1 are used.": [
  null,
  "只要 $0 的 $1 使用。"
 ],
 "Grow logical size of $0": [
  null,
  "增加邏輯大小 $0"
 ],
 "Physical": [
  null,
  "實體"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "已使用資料 $0 + 額外負擔 $1 之於 $2 （$3）"
 ],
 "Logical": [
  null,
  "邏輯"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "已使用 $1 中的 $0 （節省了 $2）"
 ],
 "Index memory": [
  null,
  "索引記憶"
 ],
 "SMART self-test of $target": [
  null,
  "$target 的 SMART 自我測試"
 ],
 "Ejecting $target": [
  null,
  "彈出 $target"
 ],
 "Unlocking $target": [
  null,
  "解鎖 $target"
 ],
 "Locking $target": [
  null,
  "鎖定 $target"
 ],
 "Modifying $target": [
  null,
  "修改 $target"
 ],
 "Resizing $target": [
  null,
  "調整 $target"
 ],
 "Starting swapspace $target": [
  null,
  "啟動swapspace $target"
 ],
 "Stopping swapspace $target": [
  null,
  "正在停止置換空間 $target"
 ],
 "Mounting $target": [
  null,
  "正在掛載 $target"
 ],
 "Unmounting $target": [
  null,
  "卸載 $target"
 ],
 "Checking $target": [
  null,
  "檢查 $target"
 ],
 "Repairing $target": [
  null,
  "修復 $target"
 ],
 "Erasing $target": [
  null,
  "刪除 $target"
 ],
 "Creating filesystem on $target": [
  null,
  "建立檔案系統於 $target"
 ],
 "Setting up loop device $target": [
  null,
  "正在設定 loop 裝置 $target"
 ],
 "Deleting $target": [
  null,
  "刪除 $target"
 ],
 "Creating partition $target": [
  null,
  "建立分割區 $target"
 ],
 "Cleaning up for $target": [
  null,
  "清理 $target"
 ],
 "Securely erasing $target": [
  null,
  "正在安全抹除 $target"
 ],
 "Very securely erasing $target": [
  null,
  "正在非常安全地抹除 $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "正在停止 MDRAID 裝置 $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "正在啟動 MDRAID 裝置 $target"
 ],
 "Marking $target as faulty": [
  null,
  "將 $target 標記為故障"
 ],
 "Removing $target from MDRAID device": [
  null,
  "從 MDRAID 裝置中移除 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "正在建立 MDRAID 裝置 $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "正在檢查 MDRAID 裝置 $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "正在檢查並修復 MDRAID 裝置 $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "正在復原 MDRAID 裝置 $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "正在同步 MDRAID 裝置 $target"
 ],
 "Activating $target": [
  null,
  "啟動 $target"
 ],
 "Deactivating $target": [
  null,
  "停用 $target"
 ],
 "Creating snapshot of $target": [
  null,
  "建立快照 $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "建立 LVM2 磁碟區群組 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "正在刪除 LVM2 磁碟區群組 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "新增物理捲到 $target"
 ],
 "Removing physical volume from $target": [
  null,
  "從中刪除物理卷 $target"
 ],
 "Emptying $target": [
  null,
  "清空 $target"
 ],
 "Creating logical volume $target": [
  null,
  "建立邏輯磁碟區 $target"
 ],
 "Renaming $target": [
  null,
  "重命名 $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "運營'$operation' 上 $target"
 ],
 "unknown target": [
  null,
  "未知目標"
 ],
 "Jobs": [
  null,
  "工作"
 ],
 "Reading": [
  null,
  "正在讀取"
 ],
 "Writing": [
  null,
  "正在寫入"
 ],
 "Install Stratis support": [
  null,
  "安裝 Stratis 支援"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "須安裝 $0 軟體包以建立 Stratis 集池。"
 ],
 "Install NFS support": [
  null,
  "安裝 NFS 支援"
 ],
 "Create MDRAID device": [
  null,
  "建立 MDRAID 裝置"
 ],
 "Create LVM2 volume group": [
  null,
  "建立 LVM2 磁碟區群組"
 ],
 "Change iSCSI initiator name": [
  null,
  "更改iSCSI啟動器名稱"
 ],
 "Add iSCSI portal": [
  null,
  "新增 iSCSI 入口 (portal)"
 ],
 "Local storage": [
  null,
  "本機儲存空間"
 ],
 "Networked storage": [
  null,
  "網路儲存空間"
 ],
 "Create storage device": [
  null,
  "建立儲存裝置"
 ],
 "No storage found": [
  null,
  "未找到儲存空間"
 ],
 "Server address cannot be empty.": [
  null,
  "伺服器位址不可為空值。"
 ],
 "Next": [
  null,
  "下一步"
 ],
 "Invalid username or password": [
  null,
  "無效的帳號或密碼"
 ],
 "Unknown host name": [
  null,
  "未知的主機名"
 ],
 "Unable to reach server": [
  null,
  "無法訪問伺服器"
 ],
 "Available targets on $0": [
  null,
  "可用目標 $0"
 ],
 "Authentication required": [
  null,
  "需經過認證"
 ],
 "iSCSI portal": [
  null,
  "iSCSI 入口 (portal)"
 ],
 "iSCSI drives": [
  null,
  "iSCSI 硬碟機"
 ],
 "No drives found": [
  null,
  "未找到硬碟機"
 ],
 "Target": [
  null,
  "目標"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO 後備裝置無法再被縮小"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis 區塊裝置無法縮得更小"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "無法在此縮小無法辨識的資料。"
 ],
 "Unlock before resizing": [
  null,
  "在調整大小前解鎖"
 ],
 "$0 can not be resized here": [
  null,
  "無法在此調整 $0 的空間"
 ],
 "$0 can not be resized": [
  null,
  "無法調整 $0 的空間"
 ],
 "$0 can not be made smaller": [
  null,
  "無法再縮小 $0 的空間"
 ],
 "$0 can not be made larger": [
  null,
  "無法再擴展 $0 的空間"
 ],
 "Physical volumes can not be resized here": [
  null,
  "無法於此處調整實體磁碟區的大小"
 ],
 "Swap can not be resized here": [
  null,
  "無法在此處調整置換空間的大小"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "無法在此處縮小無法辨識的資料"
 ],
 "Activate before resizing": [
  null,
  "調整大小前啟用"
 ],
 "Grow logical volume": [
  null,
  "擴展邏輯磁碟區"
 ],
 "Grow partition": [
  null,
  "擴展分割區"
 ],
 "grow": [
  null,
  "擴展"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "必須僅選擇 $0 個物理磁碟區"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "欲調整已加密的檔案系統空間，必須先解鎖磁碟。請提供一個現有的通行片語。"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "必須僅選擇 $0 個物理磁碟區，每個邏輯磁碟區的 stripe 都需要一個。"
 ],
 "Shrink logical volume": [
  null,
  "縮小邏輯磁碟區"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "Unformatted data": [
  null,
  "未格式化的資料"
 ],
 "Block device": [
  null,
  "區塊裝置"
 ],
 "Device number": [
  null,
  "裝置編號"
 ],
 "Create partition on $0": [
  null,
  "在 $0 上建立分割區"
 ],
 "Format $0": [
  null,
  "格式化 $0"
 ],
 "No filesystem": [
  null,
  "沒有檔案系統"
 ],
 "(recommended)": [
  null,
  "（推薦）"
 ],
 "No encryption": [
  null,
  "無加密"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "再利用現有的加密 ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "利用既存的加密"
 ],
 "format": [
  null,
  "格式化"
 ],
 "Format and mount": [
  null,
  "格式化並掛載"
 ],
 "Format only": [
  null,
  "僅格式化"
 ],
 "Format": [
  null,
  "格式化"
 ],
 "Create and start": [
  null,
  "建立並啟動"
 ],
 "Format and start": [
  null,
  "格式化並啟動"
 ],
 "Store passphrase": [
  null,
  "儲存通行片語"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "需要先解鎖磁碟才能格式化。請提供一個現有的通行片語。"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "格式化將會刪除儲存裝置上的所有資料。"
 ],
 "Unrecognized data": [
  null,
  "無法辨識的資料"
 ],
 "Storage can not be managed on this system.": [
  null,
  "無法管理此系統的儲存空間。"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux伺服器的Web控制台"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一個伺服器管理器，它可以讓您透過網頁瀏覽器輕鬆管理 Linux 伺服器。同時運用終端機與網頁工具是沒有問題的。由 Cockpit 啟動的服務可在終端機中被停止。同樣地，若終端機中發生錯誤時，也可以在 Cockpit 的紀錄檔日誌介面中看到。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常適合新的系統管理員，使他們能夠輕鬆執行簡單的任務，如：儲存空間管理、檢查日誌紀錄及啟動與停止服務。您可以同時監控和管理多個伺服器。只需輕鬆的新增它們，您的機器們將會關心彼此的狀況。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "安裝Cockpit後，使用“systemctl enable --now cockpit.socket”啟用它。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit 的 NetworkManager 與 Firewalld 設定"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 與 Firewalld 管理網路功能，如 bond、橋接、teams、VLAN 和防火牆。NetworkManager 與 Ubuntu 預設的 systemd-networkd 及 Debian 的 ifupdown scripts 皆不相容。"
 ],
 "Manage storage": [
  null,
  "管理儲存空間"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本機儲存空間，如檔案系統、LVM2 磁碟區群組與掛載 NFS。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集並封裝診斷與支援資料"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具會從運作中的系統產生一個具有診斷資訊與設定的封存檔案。這個封存檔案可被存在本機、或為了紀錄與追蹤用途集中存放，也可能被傳送至技術支援代表、開發者或系統管理員以協助排除技術障礙與對程式除錯。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 設定與疑難排解"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具設定 SELinux 政策且能協助瞭解與處理政策違規事件。"
 ],
 "Collect kernel crash dumps": [
  null,
  "蒐集核心當機傾印"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具設定系統以儲存核心當機傾印。它支援 \"本機\" (磁碟)、\"ssh\"，與 \"nfs\" 作為傾印儲存目的地。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 網頁控制台進行管理"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "需要驗證才可以透過 Cockpit 網頁控制台執行高權限的工作"
 ],
 "format-bytes\u0004bytes": [
  null,
  "位元組"
 ]
});
