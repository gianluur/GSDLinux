cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Файлы Cockpit"
 ],
 "Home": [
  null,
  "Домашний каталог"
 ],
 "Unable to create bookmark directory": [
  null,
  "Не удаётся создать каталог закладок"
 ],
 "Unable to save bookmark file": [
  null,
  "Не удаётся сохранить файл закладок"
 ],
 "Remove from bookmarks": [
  null,
  "Удалить из закладок"
 ],
 "Add to bookmarks": [
  null,
  "Добавить в закладки"
 ],
 "Bookmarks": [
  null,
  "Закладки"
 ],
 "Bookmarked": [
  null,
  "В закладках"
 ],
 "Not bookmarked": [
  null,
  "Не в закладках"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Edit path": [
  null,
  "Редактировать путь"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "A-Z": [
  null,
  "А-Я"
 ],
 "Z-A": [
  null,
  "Я-А"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Largest size": [
  null,
  "Сначала большие"
 ],
 "Smallest size": [
  null,
  "Сначала маленькие"
 ],
 "Modified": [
  null,
  "Изменён"
 ],
 "First modified": [
  null,
  "Сначала изменённые"
 ],
 "Last modified": [
  null,
  "Дата изменения"
 ],
 "Owner": [
  null,
  "Владелец"
 ],
 "Owner ascending": [
  null,
  "По владельцу (возр.)"
 ],
 "Owner descending": [
  null,
  "По владельцу (убыв.)"
 ],
 "Permissions": [
  null,
  "Разрешения"
 ],
 "Most permissive": [
  null,
  "Сначала свободные"
 ],
 "Least permissive": [
  null,
  "Сначала строгие"
 ],
 "Show keyboard shortcuts": [
  null,
  "Показать горячие клавиши"
 ],
 "Filter directory": [
  null,
  "Фильтр каталога"
 ],
 "Display as a list": [
  null,
  "Отображать списком"
 ],
 "Display as a grid": [
  null,
  "Отображать сеткой"
 ],
 "Sort": [
  null,
  "Сортировка"
 ],
 "Hide hidden items": [
  null,
  "Скрыть скрытые элементы"
 ],
 "Show hidden items": [
  null,
  "Показать скрытые элементы"
 ],
 "$0 files": [
  null,
  "$0 файлов"
 ],
 "Uploaded as $0, $1": [
  null,
  "Загружено как $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Заменить файл $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Файл с таким же именем уже существует в «$0». Замена перезапишет его содержимое."
 ],
 "New file": [
  null,
  "Новый файл"
 ],
 "Original file on server": [
  null,
  "Исходный файл на сервере"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Применить это действие ко всем конфликтующим файлам"
 ],
 "Replace": [
  null,
  "Заменить"
 ],
 "Keep original": [
  null,
  "Оставить исходный"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Failed": [
  null,
  "Ошибка"
 ],
 "Upload error": [
  null,
  "Ошибка загрузки"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Не удаётся переместить загруженный файл в конечный каталог"
 ],
 "Cancelled": [
  null,
  "Отменено"
 ],
 "Cancelled upload of $0": [
  null,
  "Загрузка $0 отменена"
 ],
 "File uploaded": [
  null,
  "Файл загружен"
 ],
 "Files uploaded": [
  null,
  "Файлы загружены"
 ],
 "Change permissions": [
  null,
  "Изменить разрешения"
 ],
 "Uploads": [
  null,
  "Загрузки"
 ],
 "Cancel upload of $0": [
  null,
  "Отменить загрузку $0"
 ],
 "Upload $0% completed": [
  null,
  "Загрузка завершена на $0%"
 ],
 "Upload": [
  null,
  "Загрузить"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Execute-only": [
  null,
  "Только выполнение"
 ],
 "Write-only": [
  null,
  "Только запись"
 ],
 "Write and execute": [
  null,
  "Запись и выполнение"
 ],
 "Read-only": [
  null,
  "Только чтение"
 ],
 "Read and execute": [
  null,
  "Чтение и выполнение"
 ],
 "Read and write": [
  null,
  "Чтение и запись"
 ],
 "Read, write, and execute": [
  null,
  "Чтение, запись и выполнение"
 ],
 "Block device": [
  null,
  "Блочное устройство"
 ],
 "Character device": [
  null,
  "Символьное устройство"
 ],
 "Directory": [
  null,
  "Каталог"
 ],
 "Named pipe": [
  null,
  "Именованный канал"
 ],
 "Symbolic link": [
  null,
  "Символическая ссылка"
 ],
 "Regular file": [
  null,
  "Обычный файл"
 ],
 "Socket": [
  null,
  "Сокет"
 ],
 "Name cannot be empty": [
  null,
  "Имя не может быть пустым"
 ],
 "Name too long": [
  null,
  "Имя слишком длинное"
 ],
 "Name cannot include a /": [
  null,
  "Имя не может содержать /"
 ],
 "Filename is the same as original name": [
  null,
  "Имя файла совпадает с исходным"
 ],
 "Directory with the same name exists": [
  null,
  "Каталог с таким именем уже существует"
 ],
 "File exists": [
  null,
  "Файл существует"
 ],
 "Pasting failed": [
  null,
  "Вставка не удалась"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "«$0» существует, вставка не перезапишет его."
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Create directory": [
  null,
  "Создать каталог"
 ],
 "Create file": [
  null,
  "Создать файл"
 ],
 "Edit permissions": [
  null,
  "Изменить разрешения"
 ],
 "Open in terminal": [
  null,
  "Открыть в терминале"
 ],
 "Open text file": [
  null,
  "Открыть текстовый файл"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Download": [
  null,
  "Скачать"
 ],
 "Create link": [
  null,
  "Создать ссылку"
 ],
 "Drop files to upload": [
  null,
  "Перетащите файлы для загрузки"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Не удаётся переместить файлы, уже выполняется другая загрузка"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Go up a directory": [
  null,
  "На уровень выше"
 ],
 "Go back": [
  null,
  "Назад"
 ],
 "Go forward": [
  null,
  "Вперёд"
 ],
 "Activate selected item, enter directory": [
  null,
  "Активировать выбранный элемент, войти в каталог"
 ],
 "Rename selected file or directory": [
  null,
  "Переименовать выбранный файл или каталог"
 ],
 "Create new directory": [
  null,
  "Создать каталог"
 ],
 "Copy selected file or directory": [
  null,
  "Копировать выбранный файл или каталог"
 ],
 "Paste file or directory": [
  null,
  "Вставить файл или каталог"
 ],
 "Select all": [
  null,
  "Выбрать всё"
 ],
 "Save current file": [
  null,
  "Сохранить текущий файл"
 ],
 "Close editor": [
  null,
  "Закрыть редактор"
 ],
 "Keyboard shortcuts": [
  null,
  "Горячие клавиши"
 ],
 "Navigation": [
  null,
  "Навигация"
 ],
 "Editing": [
  null,
  "Редактирование"
 ],
 "Editor": [
  null,
  "Редактор"
 ],
 "Force delete $0 items": [
  null,
  "Принудительно удалить $0 элементов"
 ],
 "Delete $0 items?": [
  null,
  "Удалить $0 элементов?"
 ],
 "Force delete file $0?": [
  null,
  "Принудительно удалить файл $0?"
 ],
 "Delete file $0?": [
  null,
  "Удалить файл $0?"
 ],
 "Force delete link $0?": [
  null,
  "Принудительно удалить ссылку $0?"
 ],
 "Delete link $0?": [
  null,
  "Удалить ссылку $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Принудительно удалить каталог $0?"
 ],
 "Delete directory $0?": [
  null,
  "Удалить каталог $0?"
 ],
 "Force delete $0": [
  null,
  "Принудительно удалить $0"
 ],
 "Delete $0?": [
  null,
  "Удалить $0?"
 ],
 "No access": [
  null,
  "Нет доступа"
 ],
 "Missing type": [
  null,
  "Отсутствует тип"
 ],
 "Collapse": [
  null,
  "Свернуть"
 ],
 "Show all files": [
  null,
  "Показать все файлы"
 ],
 "$0 permissions": [
  null,
  "Разрешения $0"
 ],
 "Permissions for $0 files": [
  null,
  "Разрешения для $0 файлов"
 ],
 "Ownership": [
  null,
  "Владение"
 ],
 "Group": [
  null,
  "Группа"
 ],
 "Access": [
  null,
  "Доступ"
 ],
 "Owner access": [
  null,
  "Доступ владельца"
 ],
 "Group access": [
  null,
  "Доступ группы"
 ],
 "Others access": [
  null,
  "Доступ остальных"
 ],
 "Security context": [
  null,
  "Контекст безопасности"
 ],
 "Set executable as program": [
  null,
  "Установить как исполняемую программу"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change permissions for enclosed files": [
  null,
  "Изменить разрешения для вложенных файлов"
 ],
 "(original owner)": [
  null,
  "(исходный владелец)"
 ],
 "keep original owners": [
  null,
  "сохранить исходных владельцев"
 ],
 "Paste as owner": [
  null,
  "Вставить как владелец"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Вставляемые файлы имеют другого владельца. По умолчанию владелец будет изменён в соответствии с целевым каталогом."
 ],
 "New owner": [
  null,
  "Новый владелец"
 ],
 "Overwrite": [
  null,
  "Перезаписать"
 ],
 "New filename": [
  null,
  "Новое имя файла"
 ],
 "New name": [
  null,
  "Новое имя"
 ],
 "Rename $0?": [
  null,
  "Переименовать $0?"
 ],
 "link to $0": [
  null,
  "ссылка на $0"
 ],
 "Create link to $0": [
  null,
  "Создать ссылку на $0"
 ],
 "Target": [
  null,
  "Цель"
 ],
 "Symlink name": [
  null,
  "Имя ссылки"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Absolute vs. Relative": [
  null,
  "Абсолютная и относительная"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Абсолютные ссылки идеальны для ссылок на файлы или каталоги, которые не будут перемещаться, например системные файлы."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Относительные ссылки полезны, когда ссылка и цель могут перемещаться одновременно, например при переименовании или перемещении родительского каталога."
 ],
 "Absolute": [
  null,
  "Абсолютная"
 ],
 "Relative": [
  null,
  "Относительная"
 ],
 "The file has been removed on disk": [
  null,
  "Файл был удалён с диска"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Существующий файл неожиданно изменился"
 ],
 "Edit $0": [
  null,
  "Редактировать $0"
 ],
 "View $0": [
  null,
  "Просмотр $0"
 ],
 "The file has changed on disk": [
  null,
  "Файл на диске изменился"
 ],
 "Reload": [
  null,
  "Перезагрузить"
 ],
 "Ignore": [
  null,
  "Игнорировать"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Save changes?": [
  null,
  "Сохранить изменения?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Файл был удалён после открытия, сохранение воссоздаст его."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Файл изменился на диске с момента открытия"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "У $0 есть несохранённые изменения, которые будут безвозвратно потеряны при отмене."
 ],
 "Discard": [
  null,
  "Отменить"
 ],
 "File name": [
  null,
  "Имя файла"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Cannot create file in current directory": [
  null,
  "Не удаётся создать файл в текущем каталоге"
 ],
 "Permission denied": [
  null,
  "Отказано в доступе"
 ],
 "Directory name cannot be empty": [
  null,
  "Имя каталога не может быть пустым"
 ],
 "Directory name too long": [
  null,
  "Имя каталога слишком длинное"
 ],
 "Directory name cannot include a /": [
  null,
  "Имя каталога не может содержать /"
 ],
 "Directory name": [
  null,
  "Имя каталога"
 ],
 "Directory owner": [
  null,
  "Владелец каталога"
 ],
 "No matching results": [
  null,
  "Нет подходящих результатов"
 ],
 "Clear filter": [
  null,
  "Сбросить фильтр"
 ],
 "Directory is empty": [
  null,
  "Каталог пуст"
 ],
 "$0 item is hidden": [
  null,
  "Скрыт $0 элемент",
  "Скрыто $0 элемента",
  "Скрыто $0 элементов"
 ],
 "Folder": [
  null,
  "Папка"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Others": [
  null,
  "Остальные"
 ],
 "$0 files selected": [
  null,
  "Выбрано $0 файлов"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Каталог содержит $0 каталогов, $1 файлов"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Каталог содержит $0 каталогов, $1 файлов, $2 скрытых"
 ],
 "User": [
  null,
  "Пользователь"
 ]
});
