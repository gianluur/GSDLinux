cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "ຄີທີ່ປ່ຽນແປງມັກຈະເກີດຈາກການຕິດຕັ້ງລະບົບປະຕິບັດການໃໝ່. ຢ່າງໃດກໍຕາມ, ການປ່ຽນແປງທີ່ບໍ່ຄາດຄິດອາດໝາຍເຖິງການພະຍາຍາມແຊກແຊງການເຊື່ອມຕໍ່ຂອງທ່ານຈາກບຸກຄົນທີສາມ."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "ເພື່ອໃຫ້ແນ່ໃຈວ່າການເຊື່ອມຕໍ່ຂອງທ່ານບໍ່ຖືກດັກຟັງໂດຍບຸກຄົນທີສາມ, ກະລຸນາກວດສອບລາຍນິ້ວມືຂອງຄີໂຮສຕ໌:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ."
 ],
 "Password": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "Log in": [
  null,
  "ເຂົ້າສູ່ລະບົບ"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Server": [
  null,
  "ເຊີເວີ"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Type": [
  null,
  "ປະເພດ"
 ],
 "Copy": [
  null,
  "ກັອບປີ້"
 ],
 "Copied": [
  null,
  "ກັອບປີ້ແລ້ວ"
 ],
 "Unlock": [
  null,
  "ປົດລັອກ"
 ],
 "Add key": [
  null,
  "ເພີ່ມຄີ"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Remove": [
  null,
  "ລຶບອອກ"
 ],
 "Select": [
  null,
  "ເລືອກ"
 ],
 "No results found": [
  null,
  "ບໍ່ພົບຜົນລັບ"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "ເວີຊັນຂອງ Cockpit ທີ່ເຂົ້າກັນໄດ້ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນ $0."
 ],
 "Set": [
  null,
  "ຕັ້ງຄ່າ"
 ],
 "Add": [
  null,
  "ເພີ່ມ"
 ],
 "Port": [
  null,
  "ພອດ (Port)"
 ],
 "$0 key changed": [
  null,
  "ຄີ $0 ປ່ຽນແປງແລ້ວ"
 ],
 "Trust and add host": [
  null,
  "ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ເພື່ອການກວດສອບລາຍນິ້ວມື, ໃຫ້ຮັນຄຳສັ່ງຕໍ່ໄປນີ້ໃນ $0 ໃນຂະນະທີ່ຢູ່ໜ້າເຄື່ອງ ຫຼື ຜ່ານເຄືອຂ່າຍທີ່ໜ້າເຊື່ອຖື:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "ຖ້າລາຍນິ້ວມືກົງກັນ, ກົດ 'ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌'. ຖ້າບໍ່ດັ່ງນັ້ນ, ຫ້າມເຊື່ອມຕໍ່ ແລະ ຕິດຕໍ່ຜູ້ດູແລລະບົບຂອງເຈົ້າ."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "ລາຍນິ້ວມືທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ. ຖ້າທ່ານໃຫ້ຄົນອື່ນກວດສອບໃຫ້, ເຂົາເຈົ້າສາມາດສົ່ງຜົນການກວດສອບໃຫ້ທ່ານດ້ວຍວິທີໃດກໍໄດ້."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "ທ່ານກຳລັງເຊື່ອມຕໍ່ຫາ $0 ເປັນຄັ້ງທຳອິດ."
 ],
 "Verify fingerprint": [
  null,
  "ກວດສອບລາຍນິ້ວມື"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "ຣັນຄຳສັ່ງນີ້ຜ່ານເຄືອຂ່າຍທີ່ເຊື່ອຖືໄດ້ ຫຼື ຣັນຢູ່ເຄື່ອງປາຍທາງໂດຍກົງ:"
 ],
 "The fingerprint should match:": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ຄວນຈະກົງກັບ:"
 ],
 "The password can not be empty": [
  null,
  "ລະຫັດຜ່ານບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key password can not be empty": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key passwords do not match": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ກົງກັນ"
 ],
 "Log in to $0": [
  null,
  "ເຂົ້າສູ່ລະບົບ $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ໄດ້. ໂຮສຕ໌ບໍ່ຍອມຮັບການເຂົ້າລະບົບດ້ວຍລະຫັດຜ່ານ ຫຼື ຄີ SSH ໃດໆຂອງທ່ານ."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ແມ່ນຖືກປ້ອງກັນດ້ວຍລະຫັດຜ່ານ, ແລະ ໂຮສຕ໌ບໍ່ອະນຸຍາດໃຫ້ເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານ. ກະລຸນາລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ຖືກປ້ອງກັນໄວ້. ທ່ານສາມາດເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານຂອງທ່ານ ຫຼື ລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ສ້າງ SSH ຄີໃໝ່ ແລະ ອະນຸຍາດມັນ"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "SSH ຄີໃໝ່ຢູ່ $0 ຈະຖືກສ້າງຂຶ້ນສຳລັບ $1 ຢູ່ $2 ແລະ ມັນຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Key password": [
  null,
  "ລະຫັດຜ່ານຄີ"
 ],
 "Confirm key password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານຂອງຄີ"
 ],
 "Authorize SSH key": [
  null,
  "ອະນຸຍາດ SSH ຄີ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "ຄີ SSH $0 ຂອງ $1 ຢູ່ $2 ຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Authentication": [
  null,
  "ການຢືນຢັນຕົວຕົນ"
 ],
 "SSH key": [
  null,
  "ຄີ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "ຄີ SSH $0 ຈະສາມາດໃຊ້ໄດ້ຕະຫຼອດວາລະການໃຊ້ງານທີ່ເຫຼືອ ແລະ ຈະສາມາດໃຊ້ເຂົ້າສູ່ລະບົບໂຮສຕ໌ອື່ນໆໄດ້ຄືກັນ."
 ],
 "Permission denied": [
  null,
  "ການອະນຸຍາດຖືກປະຕິເສດ"
 ],
 "Clear input value": [
  null,
  "ລຶບຄ່າທີ່ປ້ອນເຂົ້າ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "ຮູບແບບວັນທີ ແລະ ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid time format": [
  null,
  "ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid date format": [
  null,
  "ຮູບແບບວັນທີບໍ່ຖືກຕ້ອງ"
 ],
 "Cannot schedule event in the past": [
  null,
  "ບໍ່ສາມາດຕັ້ງເວລາໃນອະດີດໄດ້"
 ],
 "No delay": [
  null,
  "ບໍ່ມີການຊັກຊ້າ"
 ],
 "1 minute": [
  null,
  "1 ນາທີ"
 ],
 "5 minutes": [
  null,
  "5 ນາທີ"
 ],
 "20 minutes": [
  null,
  "20 ນາທີ"
 ],
 "40 minutes": [
  null,
  "40 ນາທີ"
 ],
 "60 minutes": [
  null,
  "60 ນາທີ"
 ],
 "Specific time": [
  null,
  "ເວລາສະເພາະ"
 ],
 "Shut down": [
  null,
  "ປິດເຄື່ອງ"
 ],
 "Reboot": [
  null,
  "ບູດເຄື່ອງໃໝ່"
 ],
 "Message to logged in users": [
  null,
  "ຂໍ້ຄວາມເຖິງຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບຢູ່"
 ],
 "Delay": [
  null,
  "ການໜ່ວງເວລາ"
 ],
 "Pick date": [
  null,
  "ເລືອກວັນທີ"
 ],
 "Toggle date picker": [
  null,
  "ເປີດ-ປິດ ຕົວເລືອກວັນທີ"
 ],
 "Synchronized": [
  null,
  "ຊິງໂຄຣໄນຊ໌ແລ້ວ"
 ],
 "Synchronized with $0": [
  null,
  "ຊິງໂຄຣໄນຊ໌ກັບ $0 ແລ້ວ"
 ],
 "Synchronizing": [
  null,
  "ກຳລັງຊິງໂຄຣໄນຊ໌"
 ],
 "Trying to synchronize with $0": [
  null,
  "ກຳລັງພະຍາຍາມຊິງໂຄຣໄນຊ໌ກັບ $0"
 ],
 "Not synchronized": [
  null,
  "ບໍ່ໄດ້ຊິງໂຄຣໄນຊ໌"
 ],
 "Log messages": [
  null,
  "ຂໍ້ຄວາມລັອກ"
 ],
 "NTP server": [
  null,
  "ເຊີບເວີ NTP"
 ],
 "Manually": [
  null,
  "ດ້ວຍຕົນເອງ"
 ],
 "Automatically using NTP": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍ NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ເພີ່ມເຕີມ"
 ],
 "Automatically using specific NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ທີ່ລະບຸ"
 ],
 "Time zone": [
  null,
  "ເຂດເວລາ"
 ],
 "Set time": [
  null,
  "ຕັ້ງເວລາ"
 ],
 "Invalid timezone": [
  null,
  "ເຂດເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Need at least one NTP server": [
  null,
  "ຕ້ອງການເຊີບເວີ NTP ຢ່າງໜ້ອຍໜຶ່ງຕົວ"
 ],
 "Change system time": [
  null,
  "ປ່ຽນເວລາຂອງລະບົບ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Path to file": [
  null,
  "ເສັ້ນທາງໄປຫາໄຟລ໌"
 ],
 "No such file or directory": [
  null,
  "ບໍ່ມີໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີນີ້"
 ],
 "Create $0": [
  null,
  "ສ້າງ $0"
 ],
 "Ok": [
  null,
  "ຕົກລົງ"
 ],
 "Learn more": [
  null,
  "ຮຽນຮູ້ເພີ່ມເຕີມ"
 ],
 "You now have administrative access.": [
  null,
  "ດຽວນີ້ທ່ານມີສິດເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບແລ້ວ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ບໍ່ມີວິທີການເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ກະລຸນາຢືນຢັນຕົວຕົນເພື່ອເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ"
 ],
 "Switch to administrative access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "Authenticate": [
  null,
  "ຢືນຢັນຕົວຕົນ"
 ],
 "Administrative access": [
  null,
  "ສິດການບໍລິຫານ"
 ],
 "Problem becoming administrator": [
  null,
  "ມີບັນຫາໃນການກາຍເປັນຜູ້ດູແລລະບົບ"
 ],
 "Method": [
  null,
  "ວິທີການ"
 ],
 "Limit access": [
  null,
  "ຈຳກັດການເຂົ້າເຖິງ"
 ],
 "Switch to limited access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "ໂໝດການເຂົ້າເຖິງແບບຈຳກັດຈະຈຳກັດສິດຜູ້ດູແລລະບົບ. ບາງສ່ວນຂອງເວັບຄອນໂຊນຈະມີຟັງຊັນການເຮັດວຽກທີ່ຫຼຸດລົງ."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ບຣາວເຊີຂອງທ່ານຈະຈົດຈຳລະດັບການເຂົ້າເຖິງຂອງທ່ານໄວ້."
 ],
 "Limited access": [
  null,
  "ການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Turn on administrative access": [
  null,
  "ເປີດການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "$0 year": [
  null,
  "$0 ປີ"
 ],
 "$0 month": [
  null,
  "$0 ເດືອນ"
 ],
 "$0 week": [
  null,
  "$0 ອາທິດ"
 ],
 "$0 day": [
  null,
  "$0 ມື້"
 ],
 "$0 hour": [
  null,
  "$0 ຊົ່ວໂມງ"
 ],
 "$0 minute": [
  null,
  "$0 ນາທີ"
 ],
 "Go to now": [
  null,
  "ໄປທີ່ປັດຈຸບັນ"
 ],
 "1 hour": [
  null,
  "1 ຊົ່ວໂມງ"
 ],
 "6 hours": [
  null,
  "6 ຊົ່ວໂມງ"
 ],
 "1 day": [
  null,
  "1 ມື້"
 ],
 "1 week": [
  null,
  "1 ອາທິດ"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານ $0 ໃນ firewalld ໄດ້"
 ],
 "Visit firewall": [
  null,
  "ໄປທີ່ໄຟວໍ"
 ],
 "Zone": [
  null,
  "ໂຊນ"
 ],
 "Add $0": [
  null,
  "ເພີ່ມ $0"
 ],
 "less than a minute ago": [
  null,
  "ບໍ່ຮອດໜຶ່ງນາທີກ່ອນ"
 ],
 "in less than a minute": [
  null,
  "ພາຍໃນບໍ່ຮອດໜຶ່ງນາທີ"
 ],
 "Password is too weak": [
  null,
  "ລະຫັດຜ່ານອ່ອນເກີນໄປ"
 ],
 "Excellent password": [
  null,
  "ລະຫັດຜ່ານດີເລີດ"
 ],
 "Password is not acceptable": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Strong password": [
  null,
  "ລະຫັດຜ່ານທີ່ແຂງແຮງ"
 ],
 "Acceptable password": [
  null,
  "ລະຫັດຜ່ານທີ່ຍອມຮັບໄດ້"
 ],
 "Weak password": [
  null,
  "ລະຫັດຜ່ານທີ່ບໍ່ປອດໄພ"
 ],
 "Show password": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Hide password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "password quality": [
  null,
  "ຄຸນນະພາບລະຫັດຜ່ານ"
 ],
 "Show confirmation password": [
  null,
  "ສະແດງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Hide confirmation password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Additional packages:": [
  null,
  "ແພັກເກດເພີ່ມເຕີມ:"
 ],
 "Removals:": [
  null,
  "ການລຶບອອກ:"
 ],
 "Total size: $0": [
  null,
  "ຂະໜາດທັງໝົດ: $0"
 ],
 "Install software": [
  null,
  "ຕິດຕັ້ງຊອບແວ"
 ],
 "$0 will be installed.": [
  null,
  "$0 ຈະຖືກຕິດຕັ້ງ."
 ],
 "Install": [
  null,
  "ຕິດຕັ້ງ"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ກຳລັງລໍຖ້າໃຫ້ການຈັດການຊອບແວອື່ນໆເຮັດວຽກໃຫ້ສຳເລັດ"
 ],
 "Checking installed software": [
  null,
  "ກຳລັງກວດສອບຊອບແວທີ່ຕິດຕັ້ງແລ້ວ"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ບໍ່ມີໃຫ້ໃຊ້ຈາກຄັງຊອບແວໃດໆ."
 ],
 "Downloading $0": [
  null,
  "ກຳລັງດາວໂຫຼດ $0"
 ],
 "Removing $0": [
  null,
  "ກຳລັງລຶບ $0 ອອກ"
 ],
 "Installing $0": [
  null,
  "ກຳລັງຕິດຕັ້ງ $0"
 ],
 "Unknown host: $0": [
  null,
  "ບໍ່ຮູ້ຈັກໂຮສຕ໌: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ດ້ວຍການຢືນຢັນຄີ SSH ໄດ້. ກະລຸນາລະບຸລະຫັດຜ່ານ."
 ],
 "SSH key login": [
  null,
  "ການເຂົ້າສູ່ລະບົບດ້ວຍຄີ SSH"
 ],
 "[no data]": [
  null,
  "[ບໍ່ມີຂໍ້ມູນ]"
 ],
 "[binary data]": [
  null,
  "[ຂໍ້ມູນໄບນາຣີ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ຂັດຂ້ອງ"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ລາຍງານລະຫັດຄວາມຜິດພາດ $0"
 ],
 "show less": [
  null,
  "ສະແດງໜ້ອຍລົງ"
 ],
 "show more": [
  null,
  "ສະແດງເພີ່ມເຕີມ"
 ],
 "Row expansion": [
  null,
  "ການຂະຫຍາຍແຖວ"
 ],
 "Row select": [
  null,
  "ເລືອກແຖວ"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ວາງ (Paste)"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ເກີດຄວາມຜິດພາດໃນການວາງ"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "ບຣາວເຊີຂອງທ່ານບໍ່ອະນຸຍາດໃຫ້ວາງຂໍ້ມູນຈາກເມນູຄລິກຂວາ. ທ່ານສາມາດໃຊ້ Shift+Insert ແທນ."
 ],
 "Error during initialization": [
  null,
  "ເກີດຂໍ້ຜິດພາດລະຫວ່າງການເລີ່ມຕົ້ນ"
 ],
 "Failed": [
  null,
  "ຫຼົ້ມເຫຼວ"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "ພິມເພື່ອທອງ"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "ບໍ່ພົບຜົນລັບທີ່ກົງກັນ"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "ກັອບປີ້ໄວ້ໃນຄລິບບອດ"
 ],
 "Automation script": [
  null,
  "ສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ສ້າງໄຟລ໌ວຽກໃໝ່ດ້ວຍເນື້ອຫານີ້."
 ],
 "Ansible roles documentation": [
  null,
  "ເອກະສານ Ansible roles"
 ],
 "Shell script": [
  null,
  "ສະຄຣິບເຊວ"
 ],
 "No system modifications": [
  null,
  "ບໍ່ມີການແກ້ໄຂລະບົບ"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເບິ່ງການປ່ຽນແປງລະບົບ"
 ],
 "Loading system modifications...": [
  null,
  "ກຳລັງໂຫຼດການປ່ຽນແປງຂອງລະບົບ..."
 ],
 "View automation script": [
  null,
  "ເບິ່ງສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Occurrences": [
  null,
  "ຈຳນວນການເກີດຂຶ້ນ"
 ],
 "View all logs": [
  null,
  "ເບິ່ງບັນທຶກທັງໝົດ"
 ],
 "Other": [
  null,
  "ອື່ນໆ"
 ],
 "Unknown": [
  null,
  "ບໍ່ຮູ້ຈັກ"
 ],
 "Desktop": [
  null,
  "ເດດທອບ"
 ],
 "Low profile desktop": [
  null,
  "Low profile desktop"
 ],
 "Pizza box": [
  null,
  "ພິດຊ່າບັອກ (Pizza box)"
 ],
 "Mini tower": [
  null,
  "ມິນິທາວເວີ (Mini tower)"
 ],
 "Tower": [
  null,
  "ທາວເວີ (Tower)"
 ],
 "Portable": [
  null,
  "ພົກພາໄດ້"
 ],
 "Laptop": [
  null,
  "ແລັບທອບ"
 ],
 "Notebook": [
  null,
  "ໂນ້ດບຸກ"
 ],
 "Handheld": [
  null,
  "ອຸປະກອນພົກພາ"
 ],
 "Docking station": [
  null,
  "ດັອກກິງສະເຕຊັນ"
 ],
 "All-in-one": [
  null,
  "ທັງໝົດໃນອັນດຽວ"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "ຄອມພິວເຕີແບບປະຢັດພື້ນທີ່"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Main server chassis"
 ],
 "Expansion chassis": [
  null,
  "Expansion chassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus expansion chassis"
 ],
 "Peripheral chassis": [
  null,
  "ໂຄງເຄື່ອງອຸປະກອນຕໍ່ພ່ວງ"
 ],
 "RAID chassis": [
  null,
  "ໂຄງເຄື່ອງ RAID"
 ],
 "Rack mount chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຕິດຕັ້ງໃນແຣັກ"
 ],
 "Sealed-case PC": [
  null,
  "ພີຊີແບບກ່ອງປິດ (Sealed-case PC)"
 ],
 "Multi-system chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຫຼາຍລະບົບ"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade enclosure"
 ],
 "Tablet": [
  null,
  "ແທັບເລັດ"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "ຖອດອອກໄດ້"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ຄອມພິວເຕີຝັງຕົວ"
 ],
 "Mini PC": [
  null,
  "ມິນິພີຊີ (Mini PC)"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "ບໍ່ມີຢູ່"
 ],
 "Present": [
  null,
  "ມີຢູ່"
 ],
 "Old password not accepted": [
  null,
  "ລະຫັດຜ່ານເກົ່າບໍ່ຖືກຍອມຮັບ"
 ],
 "Failed to change password": [
  null,
  "ບໍ່ສາມາດປ່ຽນລະຫັດຜ່ານໄດ້"
 ],
 "New password was not accepted": [
  null,
  "ລະຫັດຜ່ານໃໝ່ບໍ່ຖືກຍອມຮັບ"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ການຖາມຜ່ານ ssh-keygen ໝົດເວລາ"
 ],
 "Not a valid private key": [
  null,
  "ບໍ່ແມ່ນໄພຣເວດຄີ (private key) ທີ່ຖືກຕ້ອງ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ການຖາມຜ່ານ ssh-add ໝົດເວລາ"
 ],
 "Invalid file permissions": [
  null,
  "ການອະນຸຍາດໄຟລ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Password not accepted": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Select an option": [
  null,
  "ເລືອກຕົວເລືອກ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 ຖືກຢຸດດ້ວຍສັນຍານ $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 ອອກດ້ວຍລະຫັດ $1"
 ],
 "$0 failed": [
  null,
  "$0 ຫຼົ້ມເຫຼວ"
 ],
 "Your session has been terminated.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານຖືກສິ້ນສຸດແລ້ວ."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານໝົດອາຍຸແລ້ວ. ກະລຸນາເຂົ້າສູ່ລະບົບໃໝ່."
 ],
 "Not permitted to perform this action.": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຮັດການນີ້."
 ],
 "Login failed": [
  null,
  "ເຂົ້າສູ່ລະບົບບໍ່ສຳເລັດ"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "ເຊີເວີປະຕິເສດການຢືນຢັນຕົວຕົນດ້ວຍທຸກວິທີທີ່ຮອງຮັບ."
 ],
 "Untrusted host": [
  null,
  "ໂຮສຕ໌ທີ່ບໍ່ໜ້າເຊື່ອຖື"
 ],
 "Host key is incorrect": [
  null,
  "ຄີຂອງໂຮສຕ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Internal error": [
  null,
  "ຂໍ້ຜິດພາດພາຍໃນ"
 ],
 "Connection has timed out.": [
  null,
  "ການເຊື່ອມຕໍ່ໝົດເວລາ."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນລະບົບ."
 ],
 "Cannot forward login credentials": [
  null,
  "ບໍ່ສາມາດສົ່ງຕໍ່ຂໍ້ມູນການເຂົ້າລະບົບໄດ້"
 ],
 "Server has closed the connection.": [
  null,
  "ເຊີເວີໄດ້ປິດການເຊື່ອມຕໍ່ແລ້ວ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ບໍ່ເຂົ້າກັນໄດ້ກັບຊອບແວໃນລະບົບ."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ບໍ່ສາມາດຕິດຕໍ່ກັບໂຮສຕ໌ທີ່ລະບຸໄດ້."
 ],
 "Too much data": [
  null,
  "ຂໍ້ມູນຫຼາຍເກີນໄປ"
 ],
 "Description": [
  null,
  "ຄຳອະທິບາຍ"
 ],
 "Save": [
  null,
  "ບັນທຶກ"
 ],
 "View logs": [
  null,
  "ເບິ່ງບັນທຶກ"
 ],
 "Dismiss": [
  null,
  "ຍົກເລີກ"
 ],
 "edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Model": [
  null,
  "ລຸ້ນ (Model)"
 ],
 "Usage": [
  null,
  "ການນຳໃຊ້"
 ],
 "none": [
  null,
  "ບໍ່ມີ"
 ],
 "Not found": [
  null,
  "ບໍ່ພົບ"
 ],
 "Error": [
  null,
  "ຂໍ້ຜິດພາດ"
 ],
 "Running": [
  null,
  "ກຳລັງເຮັດວຽກ"
 ],
 "Not running": [
  null,
  "ບໍ່ໄດ້ເຮັດວຽກ"
 ],
 "Loading...": [
  null,
  "ກຳລັງໂຫຼດ..."
 ],
 "User": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "Vendor": [
  null,
  "ຜູ້ຜະລິດ (Vendor)"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "ຂະໜາດ"
 ],
 "State": [
  null,
  "ສະຖານະ"
 ],
 "Stop": [
  null,
  "ຢຸດ"
 ],
 "Start": [
  null,
  "ເລີ່ມ"
 ],
 "Delete": [
  null,
  "ລຶບ"
 ],
 "Confirm deletion of $0": [
  null,
  "ຢືນຢັນການລຶບ $0"
 ],
 "Username": [
  null,
  "ຊື່ຜູ້ໃຊ້"
 ],
 "Actions": [
  null,
  "ການດຳເນີນການຕ່າງໆ"
 ],
 "Create": [
  null,
  "ສ້າງ"
 ],
 "Rename": [
  null,
  "ປ່ຽນຊື່"
 ],
 "Started": [
  null,
  "ເລີ່ມແລ້ວ"
 ],
 "Delete group": [
  null,
  "ລຶບກຸ່ມ"
 ],
 "Options": [
  null,
  "ຕົວເລືອກ"
 ],
 "Lock": [
  null,
  "ລັອກ"
 ],
 "Use $0": [
  null,
  "ໃຊ້ $0"
 ],
 "Service": [
  null,
  "ບໍລິການ"
 ],
 "Disconnect": [
  null,
  "ຕັດການເຊື່ອມຕໍ່"
 ],
 "Address": [
  null,
  "ທີ່ຢູ່"
 ],
 "$0 disk is missing": [
  null,
  "ດິສກ໌ $0 ໜ່ວຍຫາຍໄປ"
 ],
 "Location": [
  null,
  "ສະຖານທີ່"
 ],
 "Compression": [
  null,
  "ການບີບອັດ"
 ],
 "Storage logs": [
  null,
  "ບັນທຶກເຫດການຂອງບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Name cannot be empty.": [
  null,
  "ຊື່ບໍ່ສາມາດຫວ່າງໄດ້."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "ຊື່ບໍ່ສາມາດຍາວກວ່າ 127 ຕົວອັກສອນ."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "ຊື່ບໍ່ສາມາດມີຕົວອັກສອນ '$0' ໄດ້."
 ],
 "Name cannot contain whitespace.": [
  null,
  "ຊື່ບໍ່ສາມາດມີຍະຫວ່າງໄດ້."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "ຊື່ບໍ່ສາມາດຍາວກວ່າ $0 ຕົວອັກສອນ"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "ຊື່ບໍ່ສາມາດຍາວກວ່າ $0 ໄບຕ໌"
 ],
 "$name (from $host)": [
  null,
  "$name (ຈາກ $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "ພູລ (Pool) ສຳລັບໂລຈິຄໍວໍລຸມແບບບາງ"
 ],
 "Thin logical volume": [
  null,
  "Thin logical volume"
 ],
 "Logical volume (snapshot)": [
  null,
  "ວໍລຸມໂລຈິກ (snapshot)"
 ],
 "Logical volume": [
  null,
  "ວໍລຸມໂລຈິກ"
 ],
 "MDRAID device $0": [
  null,
  "ອຸປະກອນ MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "ກຸ່ມວໍລຸມ LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "ອຸປະກອນ VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "ວໍລຸມໂລຈິກທີ່ເຂົ້າລະຫັດແລ້ວຂອງ $0"
 ],
 "Encrypted partition of $0": [
  null,
  "ພາກສ່ວນດິສກ໌ທີ່ເຂົ້າລະຫັດແລ້ວຂອງ $0"
 ],
 "Logical volume of $0": [
  null,
  "ວໍລຸມໂລຈິກຂອງ $0"
 ],
 "Partition of $0": [
  null,
  "ພາທິຊັນຂອງ $0"
 ],
 "Encrypted $0": [
  null,
  "$0 ທີ່ເຂົ້າລະຫັດແລ້ວ"
 ],
 "unpartitioned space on $0": [
  null,
  "ພື້ນທີ່ທີ່ບໍ່ໄດ້ແບ່ງພາທິຊັນໃນ $0"
 ],
 "unmount": [
  null,
  "ຍົກເລີກການຕິດຕັ້ງ (unmount)"
 ],
 "mount": [
  null,
  "ເມົາທ໌ (mount)"
 ],
 "remove from btrfs volume": [
  null,
  "ລຶບອອກຈາກ btrfs volume"
 ],
 "stop": [
  null,
  "ຢຸດ"
 ],
 "remove from MDRAID": [
  null,
  "ລຶບອອກຈາກ MDRAID"
 ],
 "remove from LVM2": [
  null,
  "ລຶບອອກຈາກ LVM2"
 ],
 "btrfs device": [
  null,
  "ອຸປະກອນ btrfs"
 ],
 "btrfs volume": [
  null,
  "btrfs volume"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "ຊື່ບໍ່ສາມາດຍາວກວ່າ 255 ຕົວອັກສອນ."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "ຊື່ບໍ່ສາມາດມີຕົວອັກສອນ '/' ໄດ້."
 ],
 "Create and mount": [
  null,
  "ສ້າງ ແລະ ເມົາທ໌"
 ],
 "Create only": [
  null,
  "ສ້າງຢ່າງດຽວ"
 ],
 "Create subvolume": [
  null,
  "ສ້າງ subvolume"
 ],
 "Mount Point": [
  null,
  "ຈຸດເມົາທ໌ (Mount Point)"
 ],
 "delete": [
  null,
  "ລຶບ"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "ລຶບຊັບວໍລຸມ $0 ຖາວອນບໍ່?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "ການລຶບຈະລຶບຂໍ້ມູນທັງໝົດໃນຊັບວໍລຸມນີ້ ແລະ ຊັບວໍລຸມຍ່ອຍທັງໝົດຂອງມັນ."
 ],
 "Edit mount point": [
  null,
  "ແກ້ໄຂຈຸດເມົາທ໌"
 ],
 "Unmount": [
  null,
  "ຍົກເລີກການຕິດຕັ້ງ (Unmount)"
 ],
 "Mount": [
  null,
  "ເມົາທ໌ (Mount)"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "ຕ້ອງມີ subvolume ຢ່າງໜ້ອຍໜຶ່ງອັນທີ່ຖືກເມົາທ໌"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "ບໍ່ສາມາດລຶບ subvolume ສຸດທ້າຍທີ່ຕິດຕັ້ງຢູ່ອອກໄດ້"
 ],
 "btrfs subvolume": [
  null,
  "btrfs subvolume"
 ],
 "Snapshot origin": [
  null,
  "ຕົ້ນສະບັບຂອງສະແນັບຊັອດ"
 ],
 "Mount point": [
  null,
  "ຈຸດເມົາທ໌"
 ],
 "No subvolumes": [
  null,
  "ບໍ່ມີຊັບວໍລຸມ (subvolumes)"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs subvolumes"
 ],
 "Snapshots": [
  null,
  "ສະແນັບຊັອດ"
 ],
 "No snapshots found": [
  null,
  "ບໍ່ພົບແພັບຊັອດ (snapshots)"
 ],
 "snapshot": [
  null,
  "ສະແນັບຊັອດ"
 ],
 "$0 is in use": [
  null,
  "$0 ກຳລັງຖືກໃຊ້ງານຢູ່"
 ],
 "Permanently delete $0?": [
  null,
  "ລຶບ $0 ຖາວອນບໍ່?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "ການລຶບຈະລຶບຂໍ້ມູນທັງໝົດໃນວໍລຸມ btrfs."
 ],
 "Delete filesystem": [
  null,
  "ລຶບລະບົບໄຟລ໌"
 ],
 "Change label": [
  null,
  "ປ່ຽນປ້າຍຊື່ (label)"
 ],
 "Filesystem is mounted read-only": [
  null,
  "ລະບົບໄຟລ໌ຖືກເມົາທ໌ແບບອ່ານໄດ້ຢ່າງດຽວ"
 ],
 "Label": [
  null,
  "ປ້າຍຊື່"
 ],
 "Capacity": [
  null,
  "ຄວາມຈຸ"
 ],
 "btrfs devices": [
  null,
  "ອຸປະກອນ btrfs"
 ],
 "No devices found": [
  null,
  "ບໍ່ພົບອຸປະກອນ"
 ],
 "btrfs filesystem": [
  null,
  "ລະບົບໄຟລ໌ btrfs"
 ],
 "Successful": [
  null,
  "ສຳເລັດ"
 ],
 "Aborted": [
  null,
  "ຍົກເລີກແລ້ວ"
 ],
 "In progress": [
  null,
  "ກຳລັງດຳເນີນການ"
 ],
 "Interrupted": [
  null,
  "ຖືກຂັດຈັງຫວະ"
 ],
 "Did not complete": [
  null,
  "ບໍ່ສຳເລັດ"
 ],
 "Failed (Unknown)": [
  null,
  "ຫຼົ້ມເຫຼວ (ບໍ່ຮູ້ສາເຫດ)"
 ],
 "Failed (Electrical)": [
  null,
  "ຫຼົ້ມເຫຼວ (ລະບົບໄຟຟ້າ)"
 ],
 "Failed (Servo)": [
  null,
  "ຫຼົ້ມເຫຼວ (ເຊີໂວ)"
 ],
 "Failed (Read)": [
  null,
  "ຫຼົ້ມເຫຼວ (ການອ່ານ)"
 ],
 "Failed (Damaged)": [
  null,
  "ຫຼົ້ມເຫຼວ (ເສຍຫາຍ)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "ຖືກຍົກເລີກໂດຍການຣີເຊັດລະດັບຄອນໂທຣເລີ"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "ຖືກຍົກເລີກເນື່ອງຈາກການລຶບ namespace ອອກຈາກລາຍການ"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "ຖືກຍົກເລີກເນື່ອງຈາກການປະມວນຜົນຄຳສັ່ງ Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "ເກີດຂໍ້ຜິດພາດຮ້າຍແຮງໃນລະຫວ່າງການທົດສອບດ້ວຍຕົນເອງ"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "ສຳເລັດແຕ່ມີບາງສ່ວນທີ່ຫຼົ້ມເຫຼວ ແລະ ບໍ່ຮູ້ວ່າແມ່ນສ່ວນໃດ"
 ],
 "Completed with one or more failed segments": [
  null,
  "ສຳເລັດແຕ່ມີໜຶ່ງສ່ວນ ຫຼື ຫຼາຍກວ່ານັ້ນຫຼົ້ມເຫຼວ"
 ],
 "Aborted for unknown reason": [
  null,
  "ຖືກຍົກເລີກຍ້ອນສາເຫດທີ່ບໍ່ຮູ້ຈັກ"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "ຖືກຍົກເລີກເນື່ອງຈາກການເຮັດ Sanitize"
 ],
 "Spare capacity is below the threshold": [
  null,
  "ຄວາມຈຳສຳຮອງຕ່ຳກວ່າເກນທີ່ກຳນົດ"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "ອຸນຫະພູມຢູ່ນອກເກນທີ່ແນະນຳ"
 ],
 "Degraded": [
  null,
  "ເສື່ອມສະພາບ"
 ],
 "All media is in read-only mode": [
  null,
  "ສື່ບັນທຶກທັງໝົດຢູ່ໃນໂໝດອ່ານຢ່າງດຽວ"
 ],
 "Volatile memory backup failed": [
  null,
  "ການສຳຮອງຂໍ້ມູນໜ່ວຍຄວາມຈຳ Volatile ບໍ່ສຳເລັດ"
 ],
 "Persistent memory has become read-only": [
  null,
  "ໜ່ວຍຄວາມຈຳຖາວອນກາຍເປັນແບບອ່ານຢ່າງດຽວ"
 ],
 "Run short test": [
  null,
  "ຣັນການທົດສອບແບບສັ້ນ (short test)"
 ],
 "Run extended test": [
  null,
  "ຣັນການທົດສອບແບບຂະຫຍາຍ (extended test)"
 ],
 "Abort test": [
  null,
  "ຍົກເລີກການທົດສອບ"
 ],
 "Disk is failing": [
  null,
  "ດິສກ໌ກຳລັງຈະເສຍ"
 ],
 "Disk is OK": [
  null,
  "ດິສກ໌ປົກກະຕິ"
 ],
 "Assessment": [
  null,
  "ການປະເມີນ"
 ],
 "Power on hours": [
  null,
  "ຊົ່ວໂມງທີ່ເປີດໃຊ້ງານ"
 ],
 "$0 hours": [
  null,
  "$0 ຊົ່ວໂມງ"
 ],
 "Self-test status": [
  null,
  "ສະຖານະການທົດສອບຕົວເອງ"
 ],
 "Number of bad sectors": [
  null,
  "ຈຳນວນແບດເຊັກເຕີ (bad sectors)"
 ],
 "Attributes failing": [
  null,
  "ຄຸນລັກສະນະທີ່ກຳລັງລົ້ມເຫຼວ"
 ],
 "Media drive": [
  null,
  "ໄດຣຟ໌ມີເດຍ"
 ],
 "Solid State Drive": [
  null,
  "ໂຊລິດສະເຕດໄດຣຟ໌ (SSD)"
 ],
 "Hard Disk Drive": [
  null,
  "ຮາດດິສກ໌"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI Drive"
 ],
 "Drive": [
  null,
  "ໄດຣຟ໌"
 ],
 "Device health (SMART)": [
  null,
  "ສຸຂະພາບອຸປະກອນ (SMART)"
 ],
 "Firmware version": [
  null,
  "ເວີຊັນເຟີມແວ"
 ],
 "Serial number": [
  null,
  "ເລກລຳດັບ (Serial number)"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "ບໍ່ໄດ້ໃສ່ມີເດຍ"
 ],
 "Device file": [
  null,
  "ໄຟລ໌ອຸປະກອນ"
 ],
 "Multipathed devices": [
  null,
  "ອຸປະກອນແບບຫຼາຍເສັ້ນທາງ (Multipathed)"
 ],
 "Free space": [
  null,
  "ພື້ນທີ່ວ່າງ"
 ],
 "Create partition": [
  null,
  "ສ້າງພາທິຊັນ"
 ],
 "Extended partition": [
  null,
  "ພາກສ່ວນດິສກ໌ແບບຂະຫຍາຍ"
 ],
 "$0 partitions": [
  null,
  "$0 ພາທິຊັນ"
 ],
 "Partitions": [
  null,
  "ພາທິຊັນ"
 ],
 "No partitions found": [
  null,
  "ບໍ່ພົບພາທິຊັນ"
 ],
 "Unexpected partitions": [
  null,
  "ພາທິຊັນທີ່ບໍ່ຄາດຄິດ"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "ບໍ່ຮອງຮັບພາທິຊັນໃນອຸປະກອນບລັອກນີ້. ຖ້າມັນຖືກໃຊ້ເປັນດິສກ໌ສຳລັບເວີຊົວແມັດຊີນ (virtual machine), ພາທິຊັນຕ້ອງໄດ້ຮັບການຈັດການໂດຍລະບົບປະຕິບັດການພາຍໃນເວີຊົວແມັດຊີນນັ້ນ."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "ການລຶບພາກສ່ວນດິສກ໌ຈະລຶບຂໍ້ມູນທັງໝົດທີ່ຢູ່ໃນນັ້ນ."
 ],
 "No free space after this partition": [
  null,
  "ບໍ່ມີພື້ນທີ່ຫວ່າງຫຼັງຈາກພາທິຊັນນີ້"
 ],
 "EFI system partition": [
  null,
  "ພາກສ່ວນລະບົບ EFI"
 ],
 "BIOS boot partition": [
  null,
  "ພາທິຊັນ BIOS boot"
 ],
 "Partition": [
  null,
  "ພາທິຊັນ"
 ],
 "Shrink": [
  null,
  "ຫຍໍ້ຂະໜາດ"
 ],
 "Grow": [
  null,
  "ຂະຫຍາຍ"
 ],
 "PowerPC PReP boot partition": [
  null,
  "ພາທິຊັນບູດ PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "ພື້ນທີ່ swap ຂອງ Linux"
 ],
 "Linux filesystem data": [
  null,
  "ຂໍ້ມູນລະບົບໄຟລ໌ Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "ພາກສ່ວນດິສກ໌ຂອງ Logical Volume Manager"
 ],
 "Custom": [
  null,
  "ກຳນົດເອງ"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "ປະເພດຕ້ອງມີຕົວອັກສອນເລກຖານສິບຫົກສອງຕົວ (0 ຫາ 9, A ຫາ F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "ປະເພດສາມາດມີໄດ້ສະເພາະຕົວອັກສອນ 0 ຫາ 9, A ຫາ F, ແລະ \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "ປະເພດຕ້ອງຢູ່ໃນຮູບແບບ NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "ຕັ້ງປະເພດພາທິຊັນຂອງ $0"
 ],
 "Custom type": [
  null,
  "ປະເພດທີ່ກຳນົດເອງ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "ການປ່ຽນປະເພດພາທິຊັນອາດຈະເຮັດໃຫ້ລະບົບບໍ່ສາມາດບູດໄດ້."
 ],
 "This partition is not completely used by its content.": [
  null,
  "ພາທິຊັນນີ້ຍັງບໍ່ໄດ້ຖືກໃຊ້ງານເຕັມພື້ນທີ່ໂດຍເນື້ອໃນຂອງມັນ."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "ຂະໜາດພາທິຊັນແມ່ນ $0. ຂະໜາດເນື້ອໃນແມ່ນ $1."
 ],
 "Shrink partition": [
  null,
  "ຫຍໍ້ຂະໜາດພາທິຊັນ"
 ],
 "Grow content": [
  null,
  "ຂະຫຍາຍເນື້ອໃນ"
 ],
 "initialize": [
  null,
  "ກຳນົດຄ່າເລີ່ມຕົ້ນ (Initialize)"
 ],
 "Initialize disk $0": [
  null,
  "ເລີ່ມຕົ້ນລະບົບດິສກ໌ $0"
 ],
 "Partitioning": [
  null,
  "ການແບ່ງພາທິຊັນ"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "ເຂົ້າກັນໄດ້ກັບທຸກລະບົບ ແລະ ອຸປະກອນ (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "ເຂົ້າກັນໄດ້ກັບລະບົບສະໄໝໃໝ່ ແລະ ຮາດດິສກ໌ > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "ບໍ່ມີການແບ່ງພາທິຊັນ"
 ],
 "Overwrite": [
  null,
  "ຂຽນທັບ"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "ຂຽນທັບຂໍ້ມູນທີ່ມີຢູ່ດ້ວຍເລກສູນ (ຊ້າກວ່າ)"
 ],
 "Initialize": [
  null,
  "ເລີ່ມຕົ້ນລະບົບ"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "ການເລີ່ມຕົ້ນລະບົບຈະລຶບຂໍ້ມູນທັງໝົດໃນດິສກ໌."
 ],
 "Device is read-only": [
  null,
  "ອຸປະກອນສາມາດອ່ານໄດ້ຢ່າງດຽວ"
 ],
 "Create partition table": [
  null,
  "ສ້າງຕາຕະລາງພາທິຊັນ"
 ],
 "Size must be a number": [
  null,
  "ຂະໜາດຕ້ອງເປັນຕົວເລກ"
 ],
 "Size cannot be zero": [
  null,
  "ຂະໜາດບໍ່ສາມາດເປັນສູນໄດ້"
 ],
 "Size cannot be negative": [
  null,
  "ຂະໜາດບໍ່ສາມາດເປັນຄ່າລົບໄດ້"
 ],
 "Size is too large": [
  null,
  "ຂະໜາດໃຫຍ່ເກີນໄປ"
 ],
 "Size must be at least $0": [
  null,
  "ຂະໜາດຕ້ອງມີຢ່າງໜ້ອຍ $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "physical volume ຂອງ LVM2 volume group"
 ],
 "member of MDRAID device": [
  null,
  "ສະມາຊິກຂອງອຸປະກອນ MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "ອຸປະກອນຮອງຮັບສຳລັບອຸປະກອນ VDO"
 ],
 "member of Stratis pool": [
  null,
  "ສະມາຊິກຂອງ Stratis pool"
 ],
 "Filesystem outside the target": [
  null,
  "ລະບົບໄຟລ໌ຢູ່ນອກເປົ້າໝາຍ"
 ],
 "device of btrfs volume": [
  null,
  "ອຸປະກອນຂອງ btrfs volume"
 ],
 "This device is currently in use.": [
  null,
  "ອຸປະກອນນີ້ກຳລັງຖືກໃຊ້ງານຢູ່."
 ],
 "Device": [
  null,
  "ອຸປະກອນ"
 ],
 "Use": [
  null,
  "ໃຊ້"
 ],
 "Services using the location": [
  null,
  "ບໍລິການທີ່ກຳລັງໃຊ້ທີ່ຕັ້ງນີ້"
 ],
 "Processes using the location": [
  null,
  "ຂະບວນການທີ່ກຳລັງໃຊ້ສະຖານທີ່ນີ້"
 ],
 "Currently in use": [
  null,
  "ກຳລັງຖືກໃຊ້ງານໃນຕອນນີ້"
 ],
 "(Not part of target)": [
  null,
  "(ບໍ່ແມ່ນສ່ວນໜຶ່ງຂອງເປົ້າໝາຍ)"
 ],
 "These changes will be made:": [
  null,
  "ການປ່ຽນແປງເຫຼົ່ານີ້ຈະຖືກດຳເນີນການ:"
 ],
 "Action": [
  null,
  "ການດຳເນີນການ"
 ],
 "Important data might be deleted:": [
  null,
  "ຂໍ້ມູນສຳຄັນອາດຈະຖືກລຶບ:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "ໂປຣເຊສ ແລະ ການບໍລິການທີ່ກ່ຽວຂ້ອງຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "ໂປຣເຊສທີ່ກ່ຽວຂ້ອງຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "ການບໍລິການທີ່ກ່ຽວຂ້ອງຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "Checking filesystem usage": [
  null,
  "ກຳລັງກວດສອບການໃຊ້ງານລະບົບໄຟລ໌"
 ],
 "$0 used, $1 total": [
  null,
  "ໃຊ້ໄປ $0, ທັງໝົດ $1"
 ],
 "Device contains unrecognized data": [
  null,
  "ອຸປະກອນມີຂໍ້ມູນທີ່ບໍ່ຮູ້ຈັກ"
 ],
 "Locked encrypted device might contain data": [
  null,
  "ອຸປະກອນທີ່ຖືກເຂົ້າລະຫັດ ແລະ ລັອກໄວ້ອາດມີຂໍ້ມູນຢູ່"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "ຂ້ອຍຢືນຢັນວ່າຕ້ອງການລຶບຂໍ້ມູນນີ້ແບບຖາວອນ"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "ຈຸດຕິດຕັ້ງ $0 ກຳລັງຖືກໃຊ້ໂດຍໂປຣເຊສເຫຼົ່ານີ້:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "ຄຳສັ່ງ"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "ຈຸດຕິດຕັ້ງ $0 ກຳລັງຖືກໃຊ້ໂດຍບໍລິການເຫຼົ່ານີ້:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "ໂປຣເຊສ ແລະ ບໍລິການທີ່ລະບຸໄວ້ຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "ໂປຣເຊສທີ່ລະບຸໄວ້ຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "ບໍລິການທີ່ລະບຸໄວ້ຈະຖືກບັງຄັບໃຫ້ຢຸດ."
 ],
 "Sorry": [
  null,
  "ຂໍອະໄພ"
 ],
 "Usage of $0": [
  null,
  "ການນຳໃຊ້ຂອງ $0"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO pool"
 ],
 "Data used": [
  null,
  "ຂໍ້ມູນທີ່ໃຊ້ແລ້ວ"
 ],
 "Metadata used": [
  null,
  "ເມຕາດາຕາທີ່ໃຊ້ແລ້ວ"
 ],
 "Use compression": [
  null,
  "ໃຊ້ການບີບອັດ (Compression)"
 ],
 "Deduplication": [
  null,
  "ການລຶບຂໍ້ມູນຊໍ້າຊ້ອນ"
 ],
 "Use deduplication": [
  null,
  "ໃຊ້ການຫຼຸດຄວາມຊ້ຳຊ້ອນ (Deduplication)"
 ],
 "Rename volume group": [
  null,
  "ປ່ຽນຊື່ກຸ່ມວໍລຸມ"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Volume group ນີ້ມີລະບົບໄຟລ໌ຮາກ (root) ຢູ່. ການປ່ຽນຊື່ມັນອາດຈະຕ້ອງໄດ້ປ່ຽນແປງການຕັ້ງຄ່າ bootloader ຫຼື ຄຳສັ່ງເຄີເນິລເພີ່ມເຕີມ."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "ການລຶບຈະລຶບຂໍ້ມູນທັງໝົດໃນກຸ່ມວໍລຸມ."
 ],
 "Create snapshot": [
  null,
  "ສ້າງ snapshot"
 ],
 "Add disks": [
  null,
  "ເພີ່ມດິສກ໌ຕ່າງໆ"
 ],
 "Disks": [
  null,
  "ດິສກ໌"
 ],
 "No disks are available.": [
  null,
  "ບໍ່ມີດິສກ໌ທີ່ພ້ອມໃຊ້ງານ."
 ],
 "At least one disk is needed.": [
  null,
  "ຕ້ອງການດິສກ໌ຢ່າງໜ້ອຍໜຶ່ງໜ່ວຍ."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Volume group ຂາດ physical volumes"
 ],
 "No free space": [
  null,
  "ບໍ່ມີພື້ນທີ່ຫວ່າງ"
 ],
 "LVM2 volume group": [
  null,
  "ກຸ່ມວໍລຸມ LVM2"
 ],
 "Add physical volume": [
  null,
  "ເພີ່ມ physical volume"
 ],
 "LVM2 logical volumes": [
  null,
  "ວໍລຸມໂລຈິກ LVM2 ທັງໝົດ"
 ],
 "Create new logical volume": [
  null,
  "ສ້າງ logical volume ໃໝ່"
 ],
 "No logical volumes": [
  null,
  "ບໍ່ມີໂລຈິຄໍວໍລຸມ (logical volumes)"
 ],
 "Remove missing physical volumes?": [
  null,
  "ລຶບຟີຊິກໍວໍລຸມທີ່ຫາຍໄປບໍ່?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Volume group ນີ້ຂາດ physical volumes ບາງອັນ."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "ກຸ່ມວໍລຸມ (Volume group) ທີ່ຂາດ physical volumes ບໍ່ສາມາດປ່ຽນຊື່ໄດ້."
 ],
 "Physical volumes": [
  null,
  "ຟີຊິກໍວໍລຸມ"
 ],
 "No physical volumes found": [
  null,
  "ບໍ່ພົບຟີຊິກໍວໍລຸມ (physical volumes)"
 ],
 "LVM2 physical volumes": [
  null,
  "ວໍລຸມຟີຊິກ LVM2 ທັງໝົດ"
 ],
 "Rename logical volume": [
  null,
  "ປ່ຽນຊື່ໂລຈິຄໍວໍລຸມ"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "ລຶບໂລຈິຄໍວໍລຸມ $0/$1 ຖາວອນບໍ່?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "ການລຶບວໍລຸມໂລຈິກຈະລຶບຂໍ້ມູນທັງໝົດທີ່ຢູ່ໃນນັ້ນ."
 ],
 "Unable to repair logical volume $0": [
  null,
  "ບໍ່ສາມາດສ້ອມແປງ logical volume $0 ໄດ້"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "ມີພື້ນທີ່ຫວ່າງບໍ່ພຽງພໍສຳລັບການສ້ອມແປງ. ຕ້ອງການຢ່າງໜ້ອຍ $0 ໃນ physical volumes ທີ່ຍັງບໍ່ໄດ້ຖືກໃຊ້ສຳລັບ logical volume ນີ້."
 ],
 "An additional $0 must be selected": [
  null,
  "ຕ້ອງເລືອກເພີ່ມອີກ $0"
 ],
 "Repair logical volume $0": [
  null,
  "ສ້ອມແປງໂລຈິຄໍວໍລຸມ $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "ເລືອກຟີຊິກໍວໍລຸມທີ່ຄວນໃຊ້ເພື່ອສ້ອມແປງໂລຈິຄໍວໍລຸມ. ຕ້ອງການຢ່າງໜ້ອຍ $0."
 ],
 "Physical Volumes": [
  null,
  "ຟີຊິກໍວໍລຸມ (Physical Volumes)"
 ],
 "Repair": [
  null,
  "ສ້ອມແປງ"
 ],
 "deactivate": [
  null,
  "ປິດການໃຊ້ງານ"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "ປິດການໃຊ້ງານວໍລຸມໂລຈິກ $0/$1 ບໍ່?"
 ],
 "Deactivate": [
  null,
  "ປິດການໃຊ້ງານ"
 ],
 "Not enough space to grow": [
  null,
  "ພື້ນທີ່ບໍ່ພໍສຳລັບການຂະຫຍາຍ"
 ],
 "LVM2 logical volume": [
  null,
  "ວໍລຸມໂລຈິກ LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Striped (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "ແວ່ນແຍງ (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Striped ແລະ mirrored (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "ແພຣິດຕີ້ສະເພາະ (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "ແພຣິດຕີ້ແບບກະຈາຍ (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "ແພຣິດຕີ້ແບບກະຈາຍສອງຊັ້ນ (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Logical volume ນີ້ຍັງບໍ່ໄດ້ຖືກໃຊ້ງານເຕັມພື້ນທີ່ໂດຍເນື້ອໃນຂອງມັນ."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "ຂະໜາດ Volume ແມ່ນ $0. ຂະໜາດເນື້ອໃນແມ່ນ $1."
 ],
 "Shrink volume": [
  null,
  "ຫຍໍ້ຂະໜາດວໍລຸ່ມ"
 ],
 "Layout": [
  null,
  "ຮູບແບບການຈັດວາງ"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Logical volume ນີ້ໄດ້ສູນເສຍ physical volumes ບາງອັນ ແລະ ບໍ່ສາມາດໃຊ້ງານໄດ້ອີກຕໍ່ໄປ. ທ່ານຈຳເປັນຕ້ອງລຶບມັນອອກ ແລະ ສ້າງອັນໃໝ່ແທນ."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Logical volume ນີ້ໄດ້ສູນເສຍ physical volumes ບາງອັນ ແຕ່ຍັງບໍ່ສູນເສຍຂໍ້ມູນເທື່ອ. ທ່ານຄວນສ້ອມແປງມັນເພື່ອໃຫ້ກັບຄືນສູ່ສະພາບເດີມ."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Logical volume ນີ້ໄດ້ສູນເສຍ physical volumes ບາງອັນ ແຕ່ອາດຈະຍັງບໍ່ສູນເສຍຂໍ້ມູນເທື່ອ. ທ່ານອາດຈະສາມາດສ້ອມແປງມັນໄດ້."
 ],
 "Stripes": [
  null,
  "Stripes"
 ],
 "$0 synchronized": [
  null,
  "$0 ຊິງໂຄຣໄນແລ້ວ"
 ],
 "Create volume group": [
  null,
  "ສ້າງ volume group"
 ],
 "LVM2 physical volume": [
  null,
  "ວໍລຸມຟີຊິກ LVM2"
 ],
 "Last cannot be removed": [
  null,
  "ບໍ່ສາມາດນຳອັນສຸດທ້າຍອອກໄດ້"
 ],
 "Not enough free space": [
  null,
  "ພື້ນທີ່ຫວ່າງບໍ່ພໍ"
 ],
 "Volume group": [
  null,
  "Volume group"
 ],
 "Create thin volume": [
  null,
  "ສ້າງ thin volume"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "LVM2 logical volumes ແບບ Thinly provisioned"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "ສ້າງ logical volume ແບບ thinly provisioned ໃໝ່"
 ],
 "Not enough space": [
  null,
  "ພື້ນທີ່ບໍ່ພໍ"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "ພູລສຳລັບ LVM2 ໂລຈິຄໍວໍລຸມແບບບາງ"
 ],
 "Inactive logical volume": [
  null,
  "ວໍລຸມໂລຈິກທີ່ບໍ່ໄດ້ໃຊ້ງານ"
 ],
 "Activate": [
  null,
  "ເປີດໃຊ້ງານ"
 ],
 "Unsupported logical volume": [
  null,
  "Logical volume ທີ່ບໍ່ຮອງຮັບ"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ຂໍ້ຜິດພາດພາຍໃນ - ວໍລຸມໂລຈິກນີ້ຖືກມາກສ໌ວ່າເປີດໃຊ້ງານຢູ່ ແລະ ຄວນມີອຸປະກອນບລັອກທີ່ກ່ຽວຂ້ອງ. ແນວໃດກໍຕາມ, ບໍ່ພົບອຸປະກອນບລັອກດັ່ງກ່າວ."
 ],
 "Installing $0 would remove $1.": [
  null,
  "ການຕິດຕັ້ງ $0 ຈະນຳເອົາ $1 ອອກ."
 ],
 "Installing packages": [
  null,
  "ກຳລັງຕິດຕັ້ງແພັກເກດ"
 ],
 "Block device for filesystems": [
  null,
  "ອຸປະກອນບລັອກສຳລັບລະບົບໄຟລ໌"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "ພູລສຳລັບວໍລຸມແບບບາງ"
 ],
 "Linear": [
  null,
  "Linear"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO filesystem volume (ການບີບອັດ/ການຫຼຸດຄວາມຊ້ຳຊ້ອນ)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ໃນວໍລຸມຟີຊິກທີ່ເລືອກ ໂດຍບໍ່ມີການເສີມຄວາມຊໍ້າຊ້ອນ ຫຼື ການປັບປຸງປະສິດທິພາບໃດໆ."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ໃນວໍລຸມຟີຊິກທີ່ເລືອກແບບສະຫຼັບກັນເພື່ອເພີ່ມປະສິດທິພາບ. ຕ້ອງເລືອກຢ່າງໜ້ອຍສອງວໍລຸມ."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ເປັນສອງຊຸດ ຫຼື ຫຼາຍກວ່ານັ້ນໃນວໍລຸມຟີຊິກທີ່ເລືອກ ເພື່ອເພີ່ມຄວາມໜ້າເຊື່ອຖື. ຕ້ອງເລືອກຢ່າງໜ້ອຍສອງວໍລຸມ."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ເປັນສອງຊຸດ ແລະ ຈັດຮຽງແບບສະຫຼັບກັນໃນວໍລຸມຟີຊິກທີ່ເລືອກ ເພື່ອເພີ່ມທັງຄວາມໜ້າເຊື່ອຖື ແລະ ປະສິດທິພາບ. ຕ້ອງເລືອກຢ່າງໜ້ອຍສີ່ວໍລຸມ."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ໃນວໍລຸມຟີຊິກທີ່ເລືອກ ເພື່ອໃຫ້ສາມາດສູນເສຍໜຶ່ງໃນນັ້ນໄດ້ໂດຍບໍ່ກະທົບຕໍ່ຂໍ້ມູນ. ຕ້ອງເລືອກຢ່າງໜ້ອຍສາມວໍລຸມ."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ໃນວໍລຸມຟີຊິກທີ່ເລືອກ ເພື່ອໃຫ້ສາມາດສູນເສຍໜຶ່ງໃນນັ້ນໄດ້ໂດຍບໍ່ກະທົບຕໍ່ຂໍ້ມູນ. ຂໍ້ມູນຍັງຖືກເກັບແບບສະຫຼັບກັນເພື່ອເພີ່ມປະສິດທິພາບ. ຕ້ອງເລືອກຢ່າງໜ້ອຍສາມວໍລຸມ."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "ຂໍ້ມູນຈະຖືກເກັບໄວ້ໃນວໍລຸມຟີຊິກທີ່ເລືອກ ເພື່ອໃຫ້ສາມາດສູນເສຍໄດ້ສູງສຸດສອງໜ່ວຍພ້ອມກັນໂດຍບໍ່ກະທົບຕໍ່ຂໍ້ມູນ. ຂໍ້ມູນຍັງຖືກເກັບແບບສະຫຼັບກັນເພື່ອເພີ່ມປະສິດທິພາບ. ຕ້ອງເລືອກຢ່າງໜ້ອຍຫ້າວໍລຸມ."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "ຕ້ອງໃຊ້ $0 physical volumes ທີ່ເລືອກທັງໝົດສຳລັບຮູບແບບທີ່ເລືອກ."
 ],
 "Create logical volume": [
  null,
  "ສ້າງ logical volume"
 ],
 "Purpose": [
  null,
  "ຈຸດປະສົງ"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "ແພັກເກັດ $0 ຈະຖືກຕິດຕັ້ງເພື່ອສ້າງອຸປະກອນ VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 ຕ້ອງການຈຳນວນຟິຊິກຄໍວໍລຸມເປັນເລກຄູ່"
 ],
 "Logical size": [
  null,
  "ຂະໜາດໂລຈິກ"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ປະຢັດພື້ນທີ່ໂດຍການບີບອັດແຕ່ລະບລັອກດ້ວຍ LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ປະຢັດພື້ນທີ່ໂດຍການຈັດເກັບບລັອກຂໍ້ມູນທີ່ຄືກັນພຽງຄັ້ງດຽວ"
 ],
 "Creating VDO device": [
  null,
  "ກຳລັງສ້າງອຸປະກອນ VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "ການຕິດຕັ້ງ NFS ນີ້ກຳລັງຖືກໃຊ້ງານຢູ່ ແລະ ສາມາດປ່ຽນແປງໄດ້ສະເພາະຕົວເລືອກຂອງມັນເທົ່ານັ້ນ."
 ],
 "NFS mount": [
  null,
  "ການເມົາທ໌ NFS"
 ],
 "New NFS mount": [
  null,
  "ການເມົາທ໌ NFS ໃໝ່"
 ],
 "Server address": [
  null,
  "ທີ່ຢູ່ເຊີເວີ"
 ],
 "Server cannot be empty.": [
  null,
  "ເຊີເວີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້."
 ],
 "Path on server": [
  null,
  "ເສັ້ນທາງໃນເຊີບເວີ"
 ],
 "Path on server cannot be empty.": [
  null,
  "ເສັ້ນທາງໃນເຊີບເວີບໍ່ສາມາດຫວ່າງໄດ້."
 ],
 "Path on server must start with \"/\".": [
  null,
  "ເສັ້ນທາງໃນເຊີບເວີຕ້ອງເລີ່ມຕົ້ນດ້ວຍ \"/\"."
 ],
 "Local mount point": [
  null,
  "ຈຸດເມົາທ໌ພາຍໃນເຄື່ອງ"
 ],
 "Mount point cannot be empty.": [
  null,
  "ຈຸດເມົາທ໌ບໍ່ສາມາດຫວ່າງໄດ້."
 ],
 "Mount point must start with \"/\".": [
  null,
  "ຈຸດເມົາທ໌ຕ້ອງເລີ່ມຕົ້ນດ້ວຍ \"/\"."
 ],
 "Mount options": [
  null,
  "ຕົວເລືອກການເມົາທ໌"
 ],
 "Mount at boot": [
  null,
  "ເມົາທ໌ຕອນບູດເຄື່ອງ"
 ],
 "Mount read only": [
  null,
  "ເມົາທ໌ແບບອ່ານຢ່າງດຽວ"
 ],
 "Custom mount options": [
  null,
  "ຕົວເລືອກການເມົາທ໌ທີ່ກຳນົດເອງ"
 ],
 "Unable to unmount filesystem": [
  null,
  "ບໍ່ສາມາດຍົກເລີກການຕິດຕັ້ງລະບົບໄຟລ໌ໄດ້"
 ],
 "Stop and unmount": [
  null,
  "ຢຸດ ແລະ ຍົກເລີກການຕິດຕັ້ງ (Unmount)"
 ],
 "Unable to remove mount": [
  null,
  "ບໍ່ສາມາດລຶບການຕິດຕັ້ງ (Mount) ອອກໄດ້"
 ],
 "Stop and remove": [
  null,
  "ຢຸດ ແລະ ລຶບອອກ"
 ],
 "(not mounted)": [
  null,
  "(ບໍ່ໄດ້ເມົາທ໌)"
 ],
 "Start multipath": [
  null,
  "ເລີ່ມ multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "ມີອຸປະກອນທີ່ມີຫຼາຍເສັ້ນທາງ (multiple paths) ໃນລະບົບ, ແຕ່ບໍລິການ multipath ບໍ່ໄດ້ເຮັດວຽກຢູ່."
 ],
 "Show all $0 rows": [
  null,
  "ສະແດງທັງໝົດ $0 ແຖວ"
 ],
 "Category": [
  null,
  "ໝວດໝູ່"
 ],
 "more info": [
  null,
  "ຂໍ້ມູນເພີ່ມເຕີມ"
 ],
 "Encryption": [
  null,
  "ການເຂົ້າລະຫັດ"
 ],
 "encrypted": [
  null,
  "ເຂົ້າລະຫັດແລ້ວ"
 ],
 "Last modified: $0": [
  null,
  "ແກ້ໄຂຫຼ້າສຸດ: $0"
 ],
 "Stored passphrase": [
  null,
  "ລະຫັດຜ່ານທີ່ຖືກເກັບໄວ້"
 ],
 "Encryption options": [
  null,
  "ຕົວເລືອກການເຂົ້າລະຫັດ"
 ],
 "Encryption type": [
  null,
  "ປະເພດການເຂົ້າລະຫັດ"
 ],
 "Cleartext device": [
  null,
  "ອຸປະກອນ Cleartext"
 ],
 "yes": [
  null,
  "ແມ່ນ"
 ],
 "Disk passphrase": [
  null,
  "ວະລີຜ່ານດິສກ໌"
 ],
 "Passphrase cannot be empty": [
  null,
  "ວະລີຜ່ານບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Unlocking disk": [
  null,
  "ກຳລັງປົດລັອກດິດ"
 ],
 "Checking for $0 package": [
  null,
  "ກຳລັງກວດສອບຫາແພັກເກດ $0"
 ],
 "The $0 package must be installed.": [
  null,
  "ຕ້ອງຕິດຕັ້ງແພັກເກັດ $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "ແພັກເກັດ $0 ບໍ່ມີໃຫ້ໃຊ້ຈາກ repository ໃດໆ."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "ເກີດຂໍ້ຜິດພາດໃນການຕິດຕັ້ງ $0: ບໍ່ໄດ້ຕິດຕັ້ງ PackageKit ຫຼື dnf5daemon-server"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "ເກີດຂໍ້ຜິດພາດທີ່ບໍ່ຄາດຄິດຂອງ PackageManager ໃນລະຫວ່າງການຕິດຕັ້ງ $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "ກຳລັງກວດສອບການຮອງຮັບ NBDE ໃນ initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "ຕ້ອງສ້າງ initrd ໃໝ່."
 ],
 "Regenerating initrd": [
  null,
  "ກຳລັງສ້າງ initrd ໃໝ່"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "ກຳລັງເພີ່ມ rd.neednet=1 ເຂົ້າໃນ kernel command line"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "ກຳລັງເພີ່ມ \"$0\" ເຂົ້າໃນຕົວເລືອກລະບົບໄຟລ໌"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "ກຳລັງເພີ່ມ \"$0\" ເຂົ້າໃນຕົວເລືອກການເຂົ້າລະຫັດ"
 ],
 "Enabling $0": [
  null,
  "ກຳລັງເປີດໃຊ້ງານ $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "ເພີ່ມການເຂົ້າລະຫັດດິສກ໌ແບບຜູກກັບເຄືອຂ່າຍ"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "ລະບົບຍັງບໍ່ຮອງຮັບການປົດລັອກລະບົບໄຟລ໌ຮາກ (root) ດ້ວຍເຊີເວີຄີ Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "ລະບົບຍັງບໍ່ຮອງຮັບການປົດລັອກລະບົບໄຟລ໌ດ້ວຍເຊີເວີຄີ Tang ໃນຂະນະບູດເຄື່ອງ."
 ],
 "These additional steps are necessary:": [
  null,
  "ຂັ້ນຕອນເພີ່ມເຕີມເຫຼົ່ານີ້ແມ່ນຈຳເປັນ:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "ການບັນທຶກວະລີຜ່ານໃໝ່ຕ້ອງການການປົດລັອກດິສກ໌. ກະລຸນາລະບຸວະລີຜ່ານຂອງດິສກ໌ປັດຈຸບັນ."
 ],
 "Fix NBDE support": [
  null,
  "ແກ້ໄຂການຮອງຮັບ NBDE"
 ],
 "Adding key": [
  null,
  "ກຳລັງເພີ່ມຄີ"
 ],
 "Key source": [
  null,
  "ແຫຼ່ງທີ່ມາຂອງຄີ"
 ],
 "Repeat passphrase": [
  null,
  "ປ້ອນວະລີຜ່ານຊ້ຳ"
 ],
 "Passphrase": [
  null,
  "ວະລີຜ່ານ"
 ],
 "Tang keyserver": [
  null,
  "ເຊີເວີຄີ (Keyserver) Tang"
 ],
 "New passphrase": [
  null,
  "ວະລີຜ່ານ (passphrase) ໃໝ່"
 ],
 "Passphrases do not match": [
  null,
  "ວະລີຜ່ານບໍ່ກົງກັນ"
 ],
 "Keyserver address": [
  null,
  "ທີ່ຢູ່ Keyserver"
 ],
 "Change passphrase": [
  null,
  "ປ່ຽນວະລີລັບ"
 ],
 "Old passphrase": [
  null,
  "ວະລີຜ່ານເກົ່າ"
 ],
 "Edit Tang keyserver": [
  null,
  "ແກ້ໄຂ Tang keyserver"
 ],
 "Verify key": [
  null,
  "ກວດສອບຄີ"
 ],
 "Trust key": [
  null,
  "ເຊື່ອຖືຄີ"
 ],
 "Passphrase can not be empty": [
  null,
  "ວະລີຜ່ານບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "ການລຶບວະລີຜ່ານອາດເຮັດໃຫ້ບໍ່ສາມາດປົດລັອກ $0 ໄດ້."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "ຢືນຢັນການເອົາອອກດ້ວຍວະລີລັບສຳຮອງ"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "ການລຶບວະລີຜ່ານໂດຍບໍ່ມີການຢືນຢັນວະລີຜ່ານອື່ນ ອາດເຮັດໃຫ້ບໍ່ສາມາດປົດລັອກ ຫຼື ຈັດການຄີໄດ້, ຖ້າຫາກວະລີຜ່ານອື່ນໆຖືກລືມ ຫຼື ຫາຍສາບສູນ."
 ],
 "Passphrase from any other key slot": [
  null,
  "ວະລີຜ່ານຈາກຊ່ອງຄີອື່ນໆ"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "ລຶບວະລີຜ່ານໃນຊ່ອງຄີ $0 ບໍ່?"
 ],
 "Remove $0?": [
  null,
  "ລຶບ $0 ອອກບໍ່?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "ການລຶບອາດເຮັດໃຫ້ບໍ່ສາມາດປົດລັອກ $0 ໄດ້."
 ],
 "Remove Tang keyserver?": [
  null,
  "ລຶບເຊີບເວີຄີ Tang ບໍ່?"
 ],
 "Remove key in slot $0?": [
  null,
  "ລຶບຄີໃນຊ່ອງ $0 ບໍ່?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "ຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບຢູ່ປັດຈຸບັນບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເບິ່ງຂໍ້ມູນກ່ຽວກັບຄີ."
 ],
 "No keys added": [
  null,
  "ບໍ່ມີການເພີ່ມຄີ"
 ],
 "Slot $0": [
  null,
  "ຊ່ອງ $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "ການແກ້ໄຂຄີຕ້ອງມີສະລັອດວ່າງ"
 ],
 "The last key slot can not be removed": [
  null,
  "ບໍ່ສາມາດລຶບຊ່ອງຄີ (Key slot) ສຸດທ້າຍອອກໄດ້"
 ],
 "Keyserver": [
  null,
  "Keyserver"
 ],
 "Unknown type": [
  null,
  "ບໍ່ຮູ້ຈັກປະເພດ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "ສະລັອດຄີທີ່ບໍ່ຮູ້ຈັກປະເພດບໍ່ສາມາດແກ້ໄຂໄດ້ຢູ່ທີ່ນີ້"
 ],
 "Keys": [
  null,
  "ບັນດາຄີ"
 ],
 "$0 slot remains": [
  null,
  "ເຫຼືອ $0 ຊ່ອງ"
 ],
 "No available slots": [
  null,
  "ບໍ່ມີຊ່ອງ (slot) ທີ່ຫວ່າງ"
 ],
 "No free key slots": [
  null,
  "ບໍ່ມີຊ່ອງຄີ (key slot) ທີ່ຫວ່າງ"
 ],
 "Locked data": [
  null,
  "ຂໍ້ມູນທີ່ຖືກລັອກ"
 ],
 "lock": [
  null,
  "ລັອກ"
 ],
 "Lock $0?": [
  null,
  "ລັອກ $0 ບໍ່?"
 ],
 "Address cannot be empty": [
  null,
  "ທີ່ຢູ່ບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Address is not a valid URL": [
  null,
  "ທີ່ຢູ່ບໍ່ແມ່ນ URL ທີ່ຖືກຕ້ອງ"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "ກວດສອບຄ່າ hash ຂອງຄີກັບ Tang server."
 ],
 "How to check": [
  null,
  "ວິທີກວດສອບ"
 ],
 "In a terminal, run: ": [
  null,
  "ໃນເທີມີນໍ, ໃຫ້ຣັນ: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "ຄັດລອກໄປທີ່ຄລິບບອດສຳເລັດແລ້ວ!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "ກວດສອບວ່າຄ່າ hash SHA-256 ຫຼື SHA-1 ຈາກຄຳສັ່ງກົງກັບໃນໜ້ານີ້."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs subvolume $0 ຂອງ $1"
 ],
 "Mount point cannot be empty": [
  null,
  "ຈຸດເມົາທ໌ບໍ່ສາມາດຫວ່າງໄດ້"
 ],
 "Mount point is already used for $0": [
  null,
  "ຈຸດເມົາທ໌ຖືກໃຊ້ສຳລັບ $0 ແລ້ວ"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "ມີລະບົບໄຟລ໌ຖືກເມົາທ໌ຢູ່ພາຍໃຕ້ຈຸດເມົາທ໌ນີ້ແລ້ວ."
 ],
 "Please unmount them first.": [
  null,
  "ກະລຸນາອັນເມົາທ໌ (unmount) ພວກມັນກ່ອນ."
 ],
 "read only": [
  null,
  "ອ່ານຢ່າງດຽວ"
 ],
 "never mount at boot": [
  null,
  "ບໍ່ຕ້ອງເມົາທ໌ຕອນບູດ"
 ],
 "after network": [
  null,
  "ຫຼັງຈາກເຄືອຂ່າຍ"
 ],
 "ignore failure": [
  null,
  "ລະເລີຍຂໍ້ຜິດພາດ"
 ],
 "stop boot on failure": [
  null,
  "ຢຸດການບູດເມື່ອລົ້ມເຫຼວ"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "ລະບົບໄຟລ໌ບໍ່ມີຈຸດຕິດຕັ້ງ (Mount point) ທີ່ກຳນົດໄວ້."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ລະບົບໄຟລ໌ບໍ່ມີຈຸດຕິດຕັ້ງຖາວອນ."
 ],
 "The filesystem is not mounted.": [
  null,
  "ລະບົບໄຟລ໌ບໍ່ໄດ້ຖືກຕິດຕັ້ງ."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ລະບົບໄຟລ໌ຈະຖືກປົດລັອກ ແລະ ຕິດຕັ້ງໃນການບູດເຄື່ອງຄັ້ງຕໍ່ໄປ. ນີ້ອາດຈະຕ້ອງໄດ້ປ້ອນລະຫັດຜ່ານ."
 ],
 "(no assigned mount point)": [
  null,
  "(ບໍ່ມີການກຳນົດຈຸດເມົາທ໌)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ລະບົບໄຟລ໌ຖືກຕິດຕັ້ງຢູ່ $0 ໃນປັດຈຸບັນ ແຕ່ຈະຖືກຕິດຕັ້ງຢູ່ $1 ໃນການບູດເຄື່ອງຄັ້ງຕໍ່ໄປ."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "ເມົາທ໌ອັດຕະໂນມັດທີ່ $0 ຕອນບູດເຄື່ອງ"
 ],
 "Mount on $0 now": [
  null,
  "ເມົາທ໌ທີ່ $0 ດຽວນີ້"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ລະບົບໄຟລ໌ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນປັດຈຸບັນ ແຕ່ຈະຖືກຕິດຕັ້ງໃນການບູດເຄື່ອງຄັ້ງຕໍ່ໄປ."
 ],
 "Do not mount automatically on boot": [
  null,
  "ບໍ່ຕ້ອງເມົາທ໌ອັດຕະໂນມັດຕອນບູດ"
 ],
 "Mount now": [
  null,
  "ເມົາທ໌ດຽວນີ້"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ລະບົບໄຟລ໌ຖືກຕິດຕັ້ງຢູ່ໃນປັດຈຸບັນ ແຕ່ຈະບໍ່ຖືກຕິດຕັ້ງຫຼັງຈາກການບູດເຄື່ອງຄັ້ງຕໍ່ໄປ."
 ],
 "Mount also automatically on boot": [
  null,
  "ໃຫ້ເມົາທ໌ອັດຕະໂນມັດຕອນບູດເຄື່ອງນຳ"
 ],
 "Unmount now": [
  null,
  "ຍົກເລີກການຕິດຕັ້ງດຽວນີ້"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ລະບົບໄຟລ໌ຖືກຕິດຕັ້ງຢູ່ $0 ໃນປັດຈຸບັນ ແຕ່ຈະບໍ່ຖືກຕິດຕັ້ງຫຼັງຈາກການບູດເຄື່ອງຄັ້ງຕໍ່ໄປ."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ລະບົບໄຟລ໌ຖືກກຳນົດໃຫ້ຕິດຕັ້ງໂດຍອັດຕະໂນມັດເມື່ອບູດເຄື່ອງ ແຕ່ບ່ອນເກັບຂໍ້ມູນທີ່ເຂົ້າລະຫັດໄວ້ຈະບໍ່ຖືກປົດລັອກໃນເວລານັ້ນ."
 ],
 "Unlock automatically on boot": [
  null,
  "ປົດລັອກໂດຍອັດຕະໂນມັດເມື່ອບູດເຄື່ອງ"
 ],
 "Inconsistent filesystem mount": [
  null,
  "ການເມົາທ໌ລະບົບໄຟລ໌ບໍ່ສອດຄ່ອງກັນ"
 ],
 "$0 filesystem": [
  null,
  "ລະບົບໄຟລ໌ $0"
 ],
 "Filesystem name": [
  null,
  "ຊື່ລະບົບໄຟລ໌"
 ],
 "Filesystem is locked": [
  null,
  "ລະບົບໄຟລ໌ຖືກລັອກຢູ່"
 ],
 "Mounts before services start": [
  null,
  "ເມົາທ໌ກ່ອນການບໍລິການເລີ່ມຕົ້ນ"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "ເໝາະສຳລັບການເມົາທ໌ທີ່ສຳຄັນ ເຊັ່ນ /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "ການບູດຈະຫຼົ້ມເຫຼວຖ້າລະບົບໄຟລ໌ບໍ່ຖືກເມົາທ໌, ເຊິ່ງຈະຂັດຂວາງການເຂົ້າເຖິງຈາກທາງໄກ"
 ],
 "Mounts in parallel with services": [
  null,
  "ເມົາທ໌ໄປພ້ອມໆກັບການບໍລິການ"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "ການບູດຍັງສຳເລັດເຖິງວ່າລະບົບໄຟລ໌ຈະບໍ່ຖືກເມົາທ໌"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "ເມົາທ໌ໄປພ້ອມໆກັບການບໍລິການ, ແຕ່ຫຼັງຈາກເຄືອຂ່າຍພ້ອມໃຊ້ງານ"
 ],
 "Does not mount during boot": [
  null,
  "ບໍ່ເມົາທ໌ລະຫວ່າງການບູດ"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "ມີປະໂຫຍດສຳລັບການຕິດຕັ້ງທີ່ເປັນທາງເລືອກ ຫຼື ຕ້ອງການການໂຕ້ຕອບ (ເຊັ່ນ ລະຫັດຜ່ານ)"
 ],
 "At boot": [
  null,
  "ເມື່ອເລີ່ມລະບົບ"
 ],
 "Mount before services start": [
  null,
  "ເມົາທ໌ກ່ອນການບໍລິການເລີ່ມຕົ້ນ"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "ເມົາທ໌ໂດຍບໍ່ຕ້ອງລໍຖ້າ, ຂ້າມຄວາມຜິດພາດ"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "ເມົາທ໌ຫຼັງຈາກເຄືອຂ່າຍພ້ອມໃຊ້ງານ, ຂ້າມຄວາມຜິດພາດ"
 ],
 "Do not mount": [
  null,
  "ບໍ່ຕ້ອງເມົາທ໌"
 ],
 "This device can not be used for the installation target.": [
  null,
  "ອຸປະກອນນີ້ບໍ່ສາມາດໃຊ້ເປັນເປົ້າໝາຍໃນການຕິດຕັ້ງໄດ້."
 ],
 "Mount filesystem": [
  null,
  "ເມົາທ໌ລະບົບໄຟລ໌"
 ],
 "Unmount filesystem $0": [
  null,
  "ຍົກເລີກການຕິດຕັ້ງລະບົບໄຟລ໌ $0"
 ],
 "Mount configuration": [
  null,
  "ການຕັ້ງຄ່າການເມົາທ໌"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "ໃຊ້ແລ້ວ"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "ປົດລັອກ Stratis pool ທີ່ຖືກເຂົ້າລະຫັດ"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "ລະບຸວະລີຜ່ານ (passphrase) ສໍາລັບພູລ (pool) ໃນອຸປະກອນບລັອກເຫຼົ່ານີ້:"
 ],
 "Stratis pool": [
  null,
  "Stratis pool"
 ],
 "stopped": [
  null,
  "ຢຸດແລ້ວ"
 ],
 "Block devices": [
  null,
  "ອຸປະກອນບລັອກຕ່າງໆ"
 ],
 "No block devices found": [
  null,
  "ບໍ່ພົບອຸປະກອນບລັອກ"
 ],
 "Stratis block devices": [
  null,
  "ອຸປະກອນບລັອກ Stratis"
 ],
 "Stratis block device": [
  null,
  "ອຸປະກອນບລັອກ Stratis"
 ],
 "data": [
  null,
  "ຂໍ້ມູນ"
 ],
 "cache": [
  null,
  "ແຄັຊ (cache)"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "ກະລຸນາລະບຸວະລີຜ່ານຂອງພູລ (pool) ທີ່ມີຢູ່."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "ຖ້າບໍ່ສາມາດຕິດຕໍ່ keyserver ທີ່ $0 ໄດ້, ເຈົ້າສາມາດໃຊ້ວະລີຜ່ານທີ່ມີຢູ່ແລ້ວໄດ້."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "ຖ້າບໍ່ສາມາດຕິດຕໍ່ keyserver ໃດໄດ້ເລີຍ, ເຈົ້າສາມາດໃຊ້ວະລີຜ່ານທີ່ມີຢູ່ແລ້ວໄດ້."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "ຖ້າວິທີການປົດລັອກແບບບໍ່ໂຕ້ຕອບບໍ່ສາມາດໃຊ້ງານໄດ້, ເຈົ້າສາມາດໃຊ້ວະລີຜ່ານທີ່ມີຢູ່ແລ້ວໄດ້."
 ],
 "Pool passphrase": [
  null,
  "ວະລີຜ່ານຂອງພູລ"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "ຕ້ອງສາມາດເຊື່ອມຕໍ່ຫາເຊີເວີຄີຢູ່ $0 ໄດ້."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "ຕ້ອງມີ keyserver ຢ່າງໜ້ອຍໜຶ່ງອັນທີ່ສາມາດຕິດຕໍ່ໄດ້."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "ຕ້ອງມີວິທີການປົດລັອກແບບບໍ່ໂຕ້ຕອບຢ່າງໜ້ອຍໜຶ່ງວິທີທີ່ໃຊ້ງານໄດ້."
 ],
 "Create filesystem": [
  null,
  "ສ້າງລະບົບໄຟລ໌"
 ],
 "Stratis filesystem": [
  null,
  "ລະບົບໄຟລ໌ Stratis"
 ],
 "Set initial size": [
  null,
  "ຕັ້ງຂະໜາດເລີ່ມຕົ້ນ"
 ],
 "Limit size": [
  null,
  "ຈຳກັດຂະໜາດ"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "ການລຶບ Stratis pool ຈະລຶບຂໍ້ມູນທັງໝົດທີ່ຢູ່ໃນນັ້ນ."
 ],
 "Rename Stratis pool": [
  null,
  "ປ່ຽນຊື່ Stratis pool"
 ],
 "Add block devices": [
  null,
  "ເພີ່ມອຸປະກອນບລັອກ (block devices)"
 ],
 "Tier": [
  null,
  "ລະດັບ (Tier)"
 ],
 "Data": [
  null,
  "ຂໍ້ມູນ"
 ],
 "Cache": [
  null,
  "ແຄສ (Cache)"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "ການເພີ່ມອຸປະກອນບລັອກຕ້ອງໄດ້ປົດລັອກ pool ກ່ອນ."
 ],
 "Encrypted Stratis pool": [
  null,
  "Stratis pool ທີ່ເຂົ້າລະຫັດແລ້ວ"
 ],
 "Delete pool": [
  null,
  "ລຶບພູລ"
 ],
 "Encryption tokens": [
  null,
  "ໂທເຄັນການເຂົ້າລະຫັດ"
 ],
 "Stratis filesystems": [
  null,
  "ລະບົບໄຟລ໌ Stratis"
 ],
 "Create new filesystem": [
  null,
  "ສ້າງລະບົບໄຟລ໌ໃໝ່"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Pool ນີ້ບໍ່ໄດ້ໃຊ້ພື້ນທີ່ທັງໝົດໃນອຸປະກອນບລັອກຂອງມັນ."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "ອຸປະກອນບລັອກບາງອັນໃນ pool ນີ້ມີຂະໜາດໃຫຍ່ຂຶ້ນຫຼັງຈາກທີ່ pool ຖືກສ້າງ. ສາມາດຂະຫຍາຍ pool ເພື່ອໃຊ້ພື້ນທີ່ຫວ່າງໃໝ່ນີ້ໄດ້ຢ່າງປອດໄພ."
 ],
 "Grow the pool to take all space": [
  null,
  "ຂະຫຍາຍພູລໃຫ້ເຕັມພື້ນທີ່ທັງໝົດ"
 ],
 "This pool is in a degraded state.": [
  null,
  "Pool ນີ້ຢູ່ໃນສະຖານະທີ່ປະສິດທິພາບຫຼຸດລົງ (Degraded)."
 ],
 "No filesystems": [
  null,
  "ບໍ່ມີລະບົບໄຟລ໌"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool ລະບົບໄຟລ໌ Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "ລະຫັດຜ່ານ (Passphrase) ນີ້ເປັນວິທີດຽວທີ່ຈະປົດລັອກ pool ໄດ້ ແລະ ບໍ່ສາມາດລຶບອອກໄດ້."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "ເຊີເວີຄີນີ້ເປັນວິທີດຽວທີ່ຈະປົດລັອກ pool ໄດ້ ແລະ ບໍ່ສາມາດລຶບອອກໄດ້."
 ],
 "Add passphrase": [
  null,
  "ເພີ່ມວະລີລັບ"
 ],
 "Add keyserver": [
  null,
  "ເພີ່ມ keyserver"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "ບໍ່ສາມາດນຳໂທເຄັນອັນສຸດທ້າຍອອກໄດ້"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "ບໍ່ມີພື້ນທີ່ເຫຼືອສຳລັບວະລີຜ່ານ ຫຼື ເຊີບເວີຄີ."
 ],
 "Confirm": [
  null,
  "ຢືນຢັນ"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "ການເພີ່ມວະລີລັບຕ້ອງໄດ້ປົດລັອກ pool ກ່ອນ."
 ],
 "Remove passphrase?": [
  null,
  "ລຶບວະລີຜ່ານບໍ່?"
 ],
 "Add Tang keyserver": [
  null,
  "ເພີ່ມ Tang keyserver"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "ການເພີ່ມ keyserver ຕ້ອງໄດ້ປົດລັອກ pool ກ່ອນ."
 ],
 "Remove Clevis token?": [
  null,
  "ລຶບເທັກເຄັນ Clevis ບໍ່?"
 ],
 "Metadata format": [
  null,
  "ຮູບແບບເມຕາດາຕາ"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "ພູລທີ່ມີຮູບແບບເມຕາດາຕາ V1 ແມ່ນຖືກຈຳກັດໃຫ້ມີວະລີຜ່ານໄດ້ພຽງໜຶ່ງດຽວ ແລະ ເຊີບເວີຄີໄດ້ພຽງໜຶ່ງດຽວເທົ່ານັ້ນ."
 ],
 "Overprovisioning": [
  null,
  "ການກຳນົດພື້ນທີ່ເກີນ (Overprovisioning)"
 ],
 "Allow overprovisioning": [
  null,
  "ອະນຸຍາດໃຫ້ຈອງເກີນຂະໜາດ (overprovisioning)"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "ຂະໜາດລະບົບໄຟລ໌ສະເມືອນໃຫຍ່ກວ່າ pool. ບໍ່ສາມາດປິດການໃຊ້ງານ Overprovisioning ໄດ້."
 ],
 "Allocated": [
  null,
  "ຖືກຈັດສັນແລ້ວ"
 ],
 "Name can not be empty.": [
  null,
  "ຊື່ບໍ່ສາມາດຫວ່າງໄດ້."
 ],
 "A pool with this name exists already.": [
  null,
  "pool ທີ່ມີຊື່ນີ້ມີຢູ່ແລ້ວ."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "ລະບົບໄຟລ໌ທີ່ມີຊື່ນີ້ມີຢູ່ແລ້ວໃນ pool ນີ້."
 ],
 "Create Stratis pool": [
  null,
  "ສ້າງ Stratis pool"
 ],
 "No block devices are available.": [
  null,
  "ບໍ່ມີອຸປະກອນບລັອກ (block device) ທີ່ພ້ອມໃຊ້ງານ."
 ],
 "At least one block device is needed.": [
  null,
  "ຕ້ອງການອຸປະກອນບລັອກຢ່າງໜ້ອຍໜຶ່ງອັນ."
 ],
 "Encrypt data with a passphrase": [
  null,
  "ເຂົ້າລະຫັດຂໍ້ມູນດ້ວຍວະລີຜ່ານ"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "ເຂົ້າລະຫັດຂໍ້ມູນດ້ວຍ Tang keyserver"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ສ້າງ snapshot ຂອງລະບົບໄຟລ໌ $0"
 ],
 "Create snapshot and mount": [
  null,
  "ສ້າງ snapshot ແລະ ເມົາທ໌"
 ],
 "Create snapshot only": [
  null,
  "ສ້າງ snapshot ຢ່າງດຽວ"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ການລຶບລະບົບໄຟລ໌ຈະລຶບຂໍ້ມູນທັງໝົດທີ່ຢູ່ໃນນັ້ນ."
 ],
 "Snapshot": [
  null,
  "ສະແນັບຊັອດ (Snapshot)"
 ],
 "Rename filesystem": [
  null,
  "ປ່ຽນຊື່ລະບົບໄຟລ໌"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "ຕັ້ງຂີດຈຳກັດຂະໜາດຂອງລະບົບໄຟລ໌ສະເມືອນ"
 ],
 "Limit virtual filesystem size": [
  null,
  "ຈຳກັດຂະໜາດລະບົບໄຟລ໌ສະເໝືອນ"
 ],
 "Virtual size limit": [
  null,
  "ຂີດຈຳກັດຂະໜາດສະເມືອນ"
 ],
 "Virtual size": [
  null,
  "ຂະໜາດສະເມືອນ"
 ],
 "Create RAID device": [
  null,
  "ສ້າງອຸປະກອນ RAID"
 ],
 "RAID level": [
  null,
  "ລະດັບ RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (ແບບແຖບ)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (ແບບແວ່ນ)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (ແບບແຍກພາຣິຕີ)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (ແບບກະຈາຍພາຣິຕີ)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ແບບກະຈາຍພາຣິຕີສອງຊັ້ນ)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (ແບບແຖບຂອງແວ່ນ)"
 ],
 "Chunk size": [
  null,
  "ຂະໜາດ Chunk"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "ຕ້ອງການດິສກ໌ຢ່າງໜ້ອຍ $0 ໜ່ວຍ."
 ],
 "MDRAID disk": [
  null,
  "ດິສກ໌ MDRAID"
 ],
 "In sync": [
  null,
  "ກຳລັງຊິງຄ໌"
 ],
 "Spare": [
  null,
  "ສຳຮອງ (Spare)"
 ],
 "Recovering": [
  null,
  "ກຳລັງກູ້ຄືນ"
 ],
 "Write-mostly": [
  null,
  "Write-mostly"
 ],
 "Blocked": [
  null,
  "ຖືກບລັອກ"
 ],
 "Unknown ($0)": [
  null,
  "ບໍ່ຮູ້ຈັກ ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "ອຸປະກອນ MDRAID ຕ້ອງກຳລັງເຮັດວຽກຢູ່"
 ],
 "MDRAID device is recovering": [
  null,
  "ອຸປະກອນ MDRAID ກຳລັງກູ້ຄືນ"
 ],
 "Need a spare disk": [
  null,
  "ຕ້ອງການດິສກ໌ສຳຮອງ"
 ],
 "Last disk can not be removed": [
  null,
  "ບໍ່ສາມາດນຳດິສກ໌ອັນສຸດທ້າຍອອກໄດ້"
 ],
 "MDRAID device": [
  null,
  "ອຸປະກອນ MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "ຢືນຢັນການຢຸດ $0"
 ],
 "Stop device": [
  null,
  "ຢຸດອຸປະກອນ"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "ການລຶບຈະລຶບຂໍ້ມູນທັງໝົດໃນອຸປະກອນ MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "ອຸປະກອນ MDRAID ຕ້ອງກຳລັງເຮັດວຽກຢູ່"
 ],
 "Add disk": [
  null,
  "ເພີ່ມດິສກ໌"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "ດິສກ໌ $0 ໜ່ວຍ"
 ],
 "$0 chunk size": [
  null,
  "ຂະໜາດ chunk $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "ອຸປະກອນ MDRAID ຢູ່ໃນສະຖານະທີ່ປະສິດທິພາບຫຼຸດລົງ (Degraded)"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "ອຸປະກອນ MDRAID ນີ້ບໍ່ມີ write-intent bitmap. bitmap ດັ່ງກ່າວສາມາດຫຼຸດເວລາໃນການຊິງໂຄຣໄນຊ໌ລົງໄດ້ຢ່າງຫຼວງຫຼາຍ."
 ],
 "Add a bitmap": [
  null,
  "ເພີ່ມບິດແມັບ (bitmap)"
 ],
 "No disks found": [
  null,
  "ບໍ່ພົບດິສກ໌"
 ],
 "MDRAID disks": [
  null,
  "ດິສກ໌ MDRAID ທັງໝົດ"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "ການລຶບຈະລຶບຂໍ້ມູນທັງໝົດໃນອຸປະກອນ VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "ການສ້າງອຸປະກອນ VDO ນີ້ບໍ່ສຳເລັດ ແລະ ບໍ່ສາມາດໃຊ້ອຸປະກອນໄດ້."
 ],
 "Remove device": [
  null,
  "ລຶບອຸປະກອນອອກ"
 ],
 "Grow to take all space": [
  null,
  "ຂະຫຍາຍໃຫ້ເຕັມພື້ນທີ່ທັງໝົດ"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "ອຸປະກອນ VDO ນີ້ບໍ່ໄດ້ໃຊ້ພື້ນທີ່ທັງໝົດຂອງອຸປະກອນຮອງຮັບ (backing device)."
 ],
 "Only $0 of $1 are used.": [
  null,
  "ໃຊ້ພຽງແຕ່ $0 ຈາກ $1."
 ],
 "Grow logical size of $0": [
  null,
  "ຂະຫຍາຍຂະໜາດໂລຈິກຂອງ $0"
 ],
 "Physical": [
  null,
  "ທາງກາຍະພາບ (Physical)"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 ຂໍ້ມູນ + $1 overhead ໃຊ້ໄປ $2 ($3)"
 ],
 "Logical": [
  null,
  "ໂລຈິກ (Logical)"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "ໃຊ້ໄປ $0 ຈາກ $1 (ປະຢັດໄດ້ $2)"
 ],
 "Index memory": [
  null,
  "ໜ່ວຍຄວາມຈຳດັດຊະນີ"
 ],
 "SMART self-test of $target": [
  null,
  "ການທົດສອບຕົວເອງ SMART ຂອງ $target"
 ],
 "Ejecting $target": [
  null,
  "ກຳລັງຖອດ $target ອອກ"
 ],
 "Unlocking $target": [
  null,
  "ກຳລັງປົດລັອກ $target"
 ],
 "Locking $target": [
  null,
  "ກຳລັງລັອກ $target"
 ],
 "Modifying $target": [
  null,
  "ກຳລັງແກ້ໄຂ $target"
 ],
 "Resizing $target": [
  null,
  "ກຳລັງປ່ຽນຂະໜາດ $target"
 ],
 "Starting swapspace $target": [
  null,
  "ກຳລັງເລີ່ມ swapspace $target"
 ],
 "Stopping swapspace $target": [
  null,
  "ກຳລັງຢຸດ swapspace $target"
 ],
 "Mounting $target": [
  null,
  "ກຳລັງເມົາທ໌ $target"
 ],
 "Unmounting $target": [
  null,
  "ກຳລັງຍົກເລີກການຕິດຕັ້ງ $target"
 ],
 "Checking $target": [
  null,
  "ກຳລັງກວດສອບ $target"
 ],
 "Repairing $target": [
  null,
  "ກຳລັງສ້ອມແປງ $target"
 ],
 "Erasing $target": [
  null,
  "ກຳລັງລຶບຂໍ້ມູນໃນ $target"
 ],
 "Creating filesystem on $target": [
  null,
  "ກຳລັງສ້າງລະບົບໄຟລ໌ໃນ $target"
 ],
 "Setting up loop device $target": [
  null,
  "ກຳລັງຕິດຕັ້ງອຸປະກອນ loop $target"
 ],
 "Deleting $target": [
  null,
  "ກຳລັງລຶບ $target"
 ],
 "Creating partition $target": [
  null,
  "ກຳລັງສ້າງພາທິຊັນ $target"
 ],
 "Cleaning up for $target": [
  null,
  "ກຳລັງອະນາໄມສຳລັບ $target"
 ],
 "Securely erasing $target": [
  null,
  "ກຳລັງລຶບ $target ຢ່າງປອດໄພ"
 ],
 "Very securely erasing $target": [
  null,
  "ກຳລັງລຶບ $target ແບບປອດໄພທີ່ສຸດ"
 ],
 "Stopping MDRAID device $target": [
  null,
  "ກຳລັງຢຸດອຸປະກອນ MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "ກຳລັງເລີ່ມອຸປະກອນ MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "ກຳລັງມາກສ໌ $target ວ່າບົກພ່ອງ"
 ],
 "Removing $target from MDRAID device": [
  null,
  "ກຳລັງລຶບ $target ອອກຈາກອຸປະກອນ MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "ກຳລັງສ້າງອຸປະກອນ MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "ກຳລັງກວດສອບອຸປະກອນ MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "ກຳລັງກວດສອບ ແລະ ຊ່ອມແຊມອຸປະກອນ MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "ກຳລັງກູ້ຄືນອຸປະກອນ MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "ກຳລັງຊິງໂຄຣໄນຊ໌ອຸປະກອນ MDRAID $target"
 ],
 "Activating $target": [
  null,
  "ກຳລັງເປີດໃຊ້ $target"
 ],
 "Deactivating $target": [
  null,
  "ກຳລັງປິດການໃຊ້ງານ $target"
 ],
 "Creating snapshot of $target": [
  null,
  "ກຳລັງສ້າງ snapshot ຂອງ $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "ກຳລັງສ້າງ LVM2 volume group $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "ກຳລັງລຶບກຸ່ມວໍລຸມ LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "ກຳລັງເພີ່ມ physical volume ເຂົ້າໃນ $target"
 ],
 "Removing physical volume from $target": [
  null,
  "ກຳລັງລຶບຟີຊິກໍວໍລຸມອອກຈາກ $target"
 ],
 "Emptying $target": [
  null,
  "ກຳລັງເຮັດໃຫ້ $target ວ່າງ"
 ],
 "Creating logical volume $target": [
  null,
  "ກຳລັງສ້າງ logical volume $target"
 ],
 "Renaming $target": [
  null,
  "ກຳລັງປ່ຽນຊື່ $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "ການເຮັດວຽກ '$operation' ເທິງ $target"
 ],
 "unknown target": [
  null,
  "ບໍ່ຮູ້ຈັກເປົ້າໝາຍ"
 ],
 "Jobs": [
  null,
  "ງານ"
 ],
 "Reading": [
  null,
  "ກຳລັງອ່ານ"
 ],
 "Writing": [
  null,
  "ກຳລັງຂຽນ"
 ],
 "Install Stratis support": [
  null,
  "ຕິດຕັ້ງການຮອງຮັບ Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "ຕ້ອງຕິດຕັ້ງແພັກເກັດ $0 ກ່ອນເພື່ອສ້າງ Stratis pools."
 ],
 "Install NFS support": [
  null,
  "ຕິດຕັ້ງການຮອງຮັບ NFS"
 ],
 "Create MDRAID device": [
  null,
  "ສ້າງອຸປະກອນ MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "ສ້າງ LVM2 volume group"
 ],
 "Change iSCSI initiator name": [
  null,
  "ປ່ຽນຊື່ iSCSI initiator"
 ],
 "Add iSCSI portal": [
  null,
  "ເພີ່ມ iSCSI portal"
 ],
 "Local storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນພາຍໃນເຄື່ອງ"
 ],
 "Networked storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນຜ່ານເຄືອຂ່າຍ"
 ],
 "Create storage device": [
  null,
  "ສ້າງອຸປະກອນເກັບຂໍ້ມູນ"
 ],
 "No storage found": [
  null,
  "ບໍ່ພົບບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Server address cannot be empty.": [
  null,
  "ທີ່ຢູ່ເຊີເວີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້."
 ],
 "Next": [
  null,
  "ຕໍ່ໄປ"
 ],
 "Invalid username or password": [
  null,
  "ຊື່ຜູ້ໃຊ້ ຫຼື ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ"
 ],
 "Unknown host name": [
  null,
  "ບໍ່ຮູ້ຈັກຊື່ໂຮສຕ໌"
 ],
 "Unable to reach server": [
  null,
  "ບໍ່ສາມາດຕິດຕໍ່ຫາເຊີເວີໄດ້"
 ],
 "Available targets on $0": [
  null,
  "ເປົ້າໝາຍທີ່ມີໃຫ້ໃຊ້ໃນ $0"
 ],
 "Authentication required": [
  null,
  "ຕ້ອງມີການຢືນຢັນຕົວຕົນ"
 ],
 "iSCSI portal": [
  null,
  "iSCSI portal"
 ],
 "iSCSI drives": [
  null,
  "iSCSI drives"
 ],
 "No drives found": [
  null,
  "ບໍ່ພົບໄດຣຟ໌"
 ],
 "Target": [
  null,
  "ເປົ້າໝາຍ"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "ອຸປະກອນຮອງຮັບ VDO ບໍ່ສາມາດເຮັດໃຫ້ຂະໜາດນ້ອຍລົງໄດ້"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "ອຸປະກອນບລັອກ Stratis ບໍ່ສາມາດເຮັດໃຫ້ຂະໜາດນ້ອຍລົງໄດ້"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "ຂໍ້ມູນທີ່ບໍ່ຮູ້ຈັກບໍ່ສາມາດເຮັດໃຫ້ຂະໜາດນ້ອຍລົງໄດ້ຢູ່ບ່ອນນີ້."
 ],
 "Unlock before resizing": [
  null,
  "ປົດລັອກກ່ອນປ່ຽນຂະໜາດ"
 ],
 "$0 can not be resized here": [
  null,
  "$0 ບໍ່ສາມາດປັບຂະໜາດໄດ້ຢູ່ບ່ອນນີ້"
 ],
 "$0 can not be resized": [
  null,
  "$0 ບໍ່ສາມາດປັບຂະໜາດໄດ້"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 ບໍ່ສາມາດເຮັດໃຫ້ນ້ອຍລົງໄດ້"
 ],
 "$0 can not be made larger": [
  null,
  "$0 ບໍ່ສາມາດເຮັດໃຫ້ໃຫຍ່ຂຶ້ນໄດ້"
 ],
 "Physical volumes can not be resized here": [
  null,
  "ຟີຊິກໍວໍລຸມບໍ່ສາມາດປ່ຽນຂະໜາດຢູ່ທີ່ນີ້ໄດ້"
 ],
 "Swap can not be resized here": [
  null,
  "ບໍ່ສາມາດປ່ຽນຂະໜາດ Swap ຢູ່ບ່ອນນີ້ໄດ້"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "ຂໍ້ມູນທີ່ບໍ່ຮູ້ຈັກບໍ່ສາມາດເຮັດໃຫ້ຂະໜາດນ້ອຍລົງໄດ້ຢູ່ບ່ອນນີ້"
 ],
 "Activate before resizing": [
  null,
  "ເປີດໃຊ້ງານກ່ອນປັບຂະໜາດ"
 ],
 "Grow logical volume": [
  null,
  "ຂະຫຍາຍວໍລຸມໂລຈິກ"
 ],
 "Grow partition": [
  null,
  "ຂະຫຍາຍພາກສ່ວນດິສກ໌"
 ],
 "grow": [
  null,
  "ຂະຫຍາຍ"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "ຕ້ອງເລືອກວໍລຸມຟີຊິກໃຫ້ຄົບ $0 ວໍລຸມ"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "ການປ່ຽນຂະໜາດລະບົບໄຟລ໌ທີ່ເຂົ້າລະຫັດໄວ້ ຕ້ອງການການປົດລັອກດິສກ໌. ກະລຸນາລະບຸວະລີຜ່ານຂອງດິສກ໌ປັດຈຸບັນ."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "ຕ້ອງເລືອກວໍລຸມຟີຊິກໃຫ້ຄົບ $0 ວໍລຸມ, ໂດຍເລືອກໜຶ່ງວໍລຸມຕໍ່ແຕ່ລະ stripe ຂອງວໍລຸມໂລຈິກ."
 ],
 "Shrink logical volume": [
  null,
  "ຫຍໍ້ຂະໜາດ logical volume"
 ],
 "shrink": [
  null,
  "ຫຍໍ້"
 ],
 "Unformatted data": [
  null,
  "ຂໍ້ມູນທີ່ຍັງບໍ່ໄດ້ຟໍແມັດ"
 ],
 "Block device": [
  null,
  "ອຸປະກອນບລັອກ"
 ],
 "Device number": [
  null,
  "ໝາຍເລກອຸປະກອນ"
 ],
 "Create partition on $0": [
  null,
  "ສ້າງພາທິຊັນໃນ $0"
 ],
 "Format $0": [
  null,
  "ຟໍແມັດ $0"
 ],
 "No filesystem": [
  null,
  "ບໍ່ມີລະບົບໄຟລ໌"
 ],
 "(recommended)": [
  null,
  "(ແນະນຳ)"
 ],
 "No encryption": [
  null,
  "ບໍ່ມີການເຂົ້າລະຫັດ"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "ນຳໃຊ້ການເຂົ້າລະຫັດທີ່ມີຢູ່ຄືນໃໝ່ ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "ນຳໃຊ້ການເຂົ້າລະຫັດທີ່ມີຢູ່ຄືນໃໝ່"
 ],
 "format": [
  null,
  "ຟໍແມັດ"
 ],
 "Format and mount": [
  null,
  "ຟໍແມັດ ແລະ ເມົາທ໌"
 ],
 "Format only": [
  null,
  "ຟໍແມັດຢ່າງດຽວ"
 ],
 "Format": [
  null,
  "ຟໍແມັດ"
 ],
 "Create and start": [
  null,
  "ສ້າງ ແລະ ເລີ່ມຕົ້ນ"
 ],
 "Format and start": [
  null,
  "ຟໍແມັດ ແລະ ເລີ່ມຕົ້ນ"
 ],
 "Store passphrase": [
  null,
  "ເກັບຮັກສາລະຫັດຜ່ານ (Passphrase)"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "ດິດຈຳເປັນຕ້ອງໄດ້ຮັບການປົດລັອກກ່ອນການຟໍແມັດ. ກະລຸນາລະບຸລະຫັດຜ່ານທີ່ມີຢູ່."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "ການຟໍແມັດຈະລຶບຂໍ້ມູນທັງໝົດໃນອຸປະກອນຈັດເກັບຂໍ້ມູນ."
 ],
 "Unrecognized data": [
  null,
  "ຂໍ້ມູນທີ່ບໍ່ຮູ້ຈັກ"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ບໍ່ສາມາດຈັດການບ່ອນຈັດເກັບຂໍ້ມູນໃນລະບົບນີ້ໄດ້."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console ສຳລັບ Linux ເຊີເວີ"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ແມ່ນລະບົບຈັດການເຊີເວີທີ່ຊ່ວຍໃຫ້ການບໍລິຫານເຊີເວີ Linux ຂອງທ່ານຜ່ານເວັບບຣາວເຊີເປັນເລື່ອງງ່າຍ. ທ່ານສາມາດສະຫຼັບການເຮັດວຽກລະຫວ່າງເທີມິນໍ ແລະ ເຄື່ອງມືເວັບໄດ້ຢ່າງສະດວກ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ແມ່ນເໝາະສົມສຳລັບຜູ້ດູແລລະບົບໃໝ່, ຊ່ວຍໃຫ້ດຳເນີນວຽກງ່າຍໆ ເຊັ່ນ ການຈັດການບ່ອນເກັບຂໍ້ມູນ, ກວດສອບລັອກ ແລະ ການຈັດການບໍລິການຕ່າງໆ."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "ເມື່ອຕິດຕັ້ງ Cockpit ແລ້ວ, ໃຫ້ເປີດໃຊ້ງານດ້ວຍຄຳສັ່ງ \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ການຕັ້ງຄ່າ NetworkManager ແລະ Firewalld ຂອງ Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການເຄືອຂ່າຍ ເຊັ່ນ bonds, bridges, teams, VLANs ແລະ ໄຟວໍ (firewalls) ໂດຍໃຊ້ NetworkManager ແລະ Firewalld."
 ],
 "Manage storage": [
  null,
  "ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນພາຍໃນເຄື່ອງ ເຊັ່ນ ລະບົບໄຟລ໌, LVM2 volume groups, ແລະ ການຕິດຕັ້ງ NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "ເກັບກຳ ແລະ ລວມແພັກເກດຂໍ້ມູນການວິເຄາະ ແລະ ການຊ່ວຍເຫຼືອ"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ສ້າງໄຟລ໌ເກັບຂໍ້ມູນການຕັ້ງຄ່າ ແລະ ຂໍ້ມູນການວິເຄາະຈາກລະບົບທີ່ກຳລັງເຮັດວຽກຢູ່. ຂໍ້ມູນເຫຼົ່ານີ້ອາດຖືກເກັບໄວ້ໃນເຄື່ອງ ຫຼື ສ່ວນກາງເພື່ອຈຸດປະສົງໃນການບັນທຶກ ຫຼື ຕິດຕາມ, ຫຼື ສົ່ງໃຫ້ຝ່າຍຊ່ວຍເຫຼືອທາງເຕັກນິກ, ນັກພັດທະນາ ຫຼື ຜູ້ດູແລລະບົບເພື່ອຊ່ວຍໃນການແກ້ໄຂບັນຫາ ແລະ ດີບັກ (debug)."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "ການຕັ້ງຄ່າ ແລະ ການແກ້ໄຂບັນຫາ Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່ານະໂຍບາຍ SELinux ແລະ ສາມາດຊ່ວຍໃນການເຂົ້າໃຈ ແລະ ແກ້ໄຂການລະເມີດນະໂຍບາຍໄດ້."
 ],
 "Collect kernel crash dumps": [
  null,
  "ເກັບກຳຂໍ້ມູນ kernel crash dumps"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່າລະບົບເພື່ອບັນທຶກ kernel crash dumps. ມັນຮອງຮັບເປົ້າໝາຍການເກັບແບບ \"local\" (ດິດ), \"ssh\", ແລະ \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ການບໍລິຫານດ້ວຍ Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "ຕ້ອງມີການຢືນຢັນຕົວຕົນເພື່ອດຳເນີນການວຽກທີ່ມີສິດພິເສດດ້ວຍ Cockpit Web Console"
 ],
 "format-bytes\u0004bytes": [
  null,
  "ໄບຕ໌ (bytes)"
 ]
});
