cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "el",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
