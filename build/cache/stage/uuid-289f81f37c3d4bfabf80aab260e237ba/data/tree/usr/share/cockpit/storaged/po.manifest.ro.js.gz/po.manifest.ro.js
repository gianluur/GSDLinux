cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "unmount": [
  null,
  "demontare"
 ],
 "mount": [
  null,
  "montare"
 ],
 "format": [
  null,
  "format"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "sistem de fișiere"
 ],
 "partition": [
  null,
  "partiția"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volum"
 ],
 "disk": [
  null,
  "disc"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "unitate"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "criptare"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Gestionarea partițiilor"
 ],
 "Managing NFS mounts": [
  null,
  "Gestionarea montărilor NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestionarea RAID-urilor"
 ],
 "Managing LVMs": [
  null,
  "Gestionarea LVM-urilor"
 ],
 "Managing physical drives": [
  null,
  "Gestionarea unităților fizice"
 ],
 "Managing VDOs": [
  null,
  "Gestionarea VDO-urilor"
 ],
 "Using LUKS encryption": [
  null,
  "Se utilizează criptarea LUKS"
 ],
 "Using Tang server": [
  null,
  "Se utilizează serverul Tang"
 ]
});
