cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "$0 silinsin mi?"
 ],
 "Force delete": [
  null,
  "Silmeye zorla"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Must be a valid IP address": [
  null,
  "Geçerli bir IP adresi olmak zorundadır"
 ],
 "1 to 65535": [
  null,
  "1'den 65535'e"
 ],
 "Container port must not be empty": [
  null,
  "Kapsayıcı bağlantı noktası boş olmamak zorundadır"
 ],
 "IP address": [
  null,
  "IP adresi"
 ],
 "IP address help": [
  null,
  "IP adresi yardım"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Eğer anamakine IP'si 0.0.0.0 olarak ayarlanırsa veya hiç ayarlanmazsa, bağlantı noktası anamakinedeki tüm IP'lere bağlanır."
 ],
 "Host port": [
  null,
  "Anamakine bağlantı noktası"
 ],
 "Host port help": [
  null,
  "Anamakine b.noktası yardım"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Eğer anamakine bağlantı noktası ayarlanmazsa, kapsayıcı bağlantı noktası anamakinede rastgele bir bağlantı noktasına atanacaktır."
 ],
 "Container port": [
  null,
  "Kapsayıcı bağlantı noktası"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Öğeyi kaldır"
 ],
 "Image name is required": [
  null,
  "Kalıp adı gerekli"
 ],
 "Image name is not unique": [
  null,
  "Kalıp adı benzersiz değil"
 ],
 "Failed to commit container $0": [
  null,
  "$0 kapsayıcısını işleme başarısız oldu"
 ],
 "New image name": [
  null,
  "Yeni kalıp adı"
 ],
 "Tag": [
  null,
  "Etiket"
 ],
 "Author": [
  null,
  "Hazırlayan"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Örnek, Adınız <adiniz@ornek.com>"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Pause container when creating image": [
  null,
  "Kalıp oluştururken kapsayıcıyı duraklatın"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker biçimi, kalıbı Docker veya Moby Engine ile paylaşırken kullanışlıdır"
 ],
 "Use legacy Docker format": [
  null,
  "Eski Docker biçimini kullan"
 ],
 "Commit container": [
  null,
  "Kapsayıcı işle"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "$0 kapsayıcısının şu anki durumuna göre yeni bir kalıp oluşturun."
 ],
 "Commit": [
  null,
  "İşle"
 ],
 "Force commit": [
  null,
  "İşlemeye zorla"
 ],
 "Failed to force remove container $0": [
  null,
  "$0 kapsayıcısını zorla kaldırma başarısız oldu"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Çalışan bir kapsayıcıyı silmek içindeki tüm verileri silecek."
 ],
 "Failed to stop container $0": [
  null,
  "$0 kapsayıcısını durdurma başarısız oldu"
 ],
 "Failed to stop quadlet $0": [
  null,
  "$0 quadlet'i durdurma başarısız oldu"
 ],
 "Failed to start quadlet $0": [
  null,
  "$0 quadlet'i başlatma başarısız oldu"
 ],
 "Failed to start container $0": [
  null,
  "$0 kapsayıcısını başlatma başarısız oldu"
 ],
 "Failed to resume container $0": [
  null,
  "$0 kapsayıcısını sürdürme başarısız oldu"
 ],
 "Failed to pause container $0": [
  null,
  "$0 kapsayıcısını duraklatma başarısız oldu"
 ],
 "Failed to restart container $0": [
  null,
  "$0 kapsayıcısını yeniden başlatma başarısız oldu"
 ],
 "Failed to restart quadlet $0": [
  null,
  "$0 quadlet'i yeniden başlatma başarısız oldu"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Restart": [
  null,
  "Yeniden başlat"
 ],
 "Force stop": [
  null,
  "Durdurmaya zorla"
 ],
 "Force restart": [
  null,
  "Yeniden başlatmaya zorla"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Resume": [
  null,
  "Devam"
 ],
 "Checkpoint": [
  null,
  "Denetim noktası"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Restore": [
  null,
  "Geri yükle"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Healthy": [
  null,
  "Sağlıklı"
 ],
 "Unhealthy": [
  null,
  "Sağlıksız"
 ],
 "Checking health": [
  null,
  "Sağlık denetleniyor"
 ],
 "Prune unused containers": [
  null,
  "Kullanılmayan kapsayıcıları ayıkla"
 ],
 "Terminal not available": [
  null,
  "Terminal kullanılabilir değil"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Bu tarayıcı WebGL2'yi desteklemiyor."
 ],
 "View $0 logs": [
  null,
  "$0 günlüklerini görüntüle"
 ],
 "not available": [
  null,
  "kullanılabilir değil"
 ],
 "n/a": [
  null,
  "yok"
 ],
 "$0% of $1 limit": [
  null,
  "%$0 / $1 sınır"
 ],
 "service": [
  null,
  "hizmet"
 ],
 "system": [
  null,
  "sistem"
 ],
 "user:": [
  null,
  "kullanıcı:"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Integration": [
  null,
  "Bütünleştirme"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Health check": [
  null,
  "Sağlık denetimi"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "Click to see published ports": [
  null,
  "Yayınlanan bağlantı noktalarını görmek için tıklayın"
 ],
 "ports": [
  null,
  "bağlantı noktaları"
 ],
 "Click to see volumes": [
  null,
  "Birimleri görmek için tıklayın"
 ],
 "volumes": [
  null,
  "birimler"
 ],
 "Container": [
  null,
  "Kapsayıcı"
 ],
 "Owner": [
  null,
  "Sahibi"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Actions": [
  null,
  "Eylemler"
 ],
 "No containers": [
  null,
  "Kapsayıcılar yok"
 ],
 "No containers in this pod": [
  null,
  "Bu bölmede kapsayıcılar yok"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "No containers that match the current filter": [
  null,
  "Şu anki süzgeçle eşleşen kapsayıcılar yok"
 ],
 "No running containers": [
  null,
  "Çalışan kapsayıcılar yok"
 ],
 "Show": [
  null,
  "Göster"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "Only running": [
  null,
  "Sadece çalışanlar"
 ],
 "Create pod": [
  null,
  "Bölme oluştur"
 ],
 "Create container": [
  null,
  "Kapsayıcı oluştur"
 ],
 "Containers": [
  null,
  "Kapsayıcılar"
 ],
 "Create container in pod": [
  null,
  "Bölme içinde kapsayıcı oluştur"
 ],
 "pod": [
  null,
  "bölme"
 ],
 "Failed to restore container $0": [
  null,
  "$0 kapsayıcısını geri yükleme başarısız oldu"
 ],
 "Restore container $0": [
  null,
  "$0 kapsayıcısını geri yükle"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Tüm geçici denetim noktası dosyalarını sakla"
 ],
 "Restore with established TCP connections": [
  null,
  "Kurulu TCP bağlantıları ile geri yükle"
 ],
 "Ignore IP address if set statically": [
  null,
  "Sabit olarak ayarlanmışsa IP adresini yoksay"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Sabit olarak ayarlanmışsa MAC adresini yoksay"
 ],
 "Pod failed to be created": [
  null,
  "Bölmenin oluşturulması başarısız oldu"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Geçersiz karakterler. Ad sadece harf, sayı ve belirli noktalama işaretlerini (_ . -) içerebilir."
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Pod name": [
  null,
  "Bölme adı"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "User:": [
  null,
  "Kullanıcı:"
 ],
 "No ports exposed": [
  null,
  "Açığa çıkan bağlantı noktaları yok"
 ],
 "Port mapping": [
  null,
  "Bağlantı noktası eşleme"
 ],
 "Add port mapping": [
  null,
  "Bağlantı noktası eşlemesi ekle"
 ],
 "No volumes specified": [
  null,
  "Belirtilen birimler yok"
 ],
 "Volumes": [
  null,
  "Birimler"
 ],
 "Add volume": [
  null,
  "Birim ekle"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Type to filter…": [
  null,
  "Süzmek için yazın…"
 ],
 "Container path must not be empty": [
  null,
  "Kapsayıcı yolu boş olmamak zorundadır"
 ],
 "Host path": [
  null,
  "Anamakine yolu"
 ],
 "Container path": [
  null,
  "Kapsayıcı yolu"
 ],
 "Mode": [
  null,
  "Mod"
 ],
 "Writable": [
  null,
  "Yazılabilir"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Etiket yok"
 ],
 "Shared": [
  null,
  "Paylaşılan"
 ],
 "Private": [
  null,
  "Özel"
 ],
 "Read-write access": [
  null,
  "Okuma-yazma erişimi"
 ],
 "Read-only access": [
  null,
  "Salt-okunur erişim"
 ],
 "Show less": [
  null,
  "Daha az göster"
 ],
 "Show more": [
  null,
  "Daha fazlasını göster"
 ],
 "Loading details...": [
  null,
  "Ayrıntılar yükleniyor..."
 ],
 "Ports": [
  null,
  "Bağlantı noktaları"
 ],
 "Environment variables": [
  null,
  "Ortam değişkenleri"
 ],
 "Failed to download image $0:$1": [
  null,
  "$0:$1 kalıbını indirme başarısız oldu"
 ],
 "Error message": [
  null,
  "Hata iletisi"
 ],
 "unused": [
  null,
  "kullanılmayan"
 ],
 "$0 container": [
  null,
  "$0 kapsayıcı",
  "$0 kapsayıcı"
 ],
 "History": [
  null,
  "Geçmiş"
 ],
 "Image": [
  null,
  "Kalıp"
 ],
 "Created": [
  null,
  "Oluşturuldu"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Disk space": [
  null,
  "Disk alanı"
 ],
 "Used by": [
  null,
  "Kullanan"
 ],
 "No images": [
  null,
  "Kalıplar yok"
 ],
 "No images that match the current filter": [
  null,
  "Şu anki süzgeçle eşleşen kalıplar yok"
 ],
 "Hide intermediate images": [
  null,
  "Ara kalıpları gizle"
 ],
 "Show intermediate images": [
  null,
  "Ara kalıpları göster"
 ],
 "Images": [
  null,
  "Kalıplar"
 ],
 "$0 image total, $1": [
  null,
  "Toplam $0 kalıp, $1",
  "Toplam $0 kalıp, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 kullanılmayan kalıp, $1",
  "$0 kullanılmayan kalıp, $1"
 ],
 "Hide images": [
  null,
  "Kalıpları gizle"
 ],
 "Show images": [
  null,
  "Kalıpları göster"
 ],
 "Pulling": [
  null,
  "Çekiliyor"
 ],
 "Download new image": [
  null,
  "Yeni kalıbı indir"
 ],
 "Pull all images": [
  null,
  "Tüm kalıpları çek"
 ],
 "Prune unused images": [
  null,
  "Kullanılmayan kalıpları ayıkla"
 ],
 "Pull": [
  null,
  "Çek"
 ],
 "Up since:": [
  null,
  "Çalıştığı süre:"
 ],
 "Exited": [
  null,
  "Çıkıldı"
 ],
 "systemd service": [
  null,
  "systemd hizmeti"
 ],
 "View $0": [
  null,
  "$0 görüntüle"
 ],
 "Gateway": [
  null,
  "Ağ geçidi"
 ],
 "MAC address": [
  null,
  "MAC adresi"
 ],
 "Latest checkpoint": [
  null,
  "Son denetim noktası"
 ],
 "No containers are using this image": [
  null,
  "Bu kalıbı hiçbir kapsayıcı kullanmıyor"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "Loading logs...": [
  null,
  "Günlükler yükleniyor..."
 ],
 "Delete unused system images:": [
  null,
  "Kullanılmayan sistem kalıplarını sil:"
 ],
 "Delete unused images of user $0:": [
  null,
  "$0 kullanıcısının kullanılmayan şu kalıplarını sil:"
 ],
 "Failed to prune unused images": [
  null,
  "Kullanılmayan kalıpları ayıklama başarısız oldu"
 ],
 "Pruning images": [
  null,
  "Kalıplar ayıklanıyor"
 ],
 "Prune": [
  null,
  "Ayıkla"
 ],
 "Failed to checkpoint container $0": [
  null,
  "$0 kapsayıcısını denetleme noktası başarısız oldu"
 ],
 "Checkpoint container $0": [
  null,
  "$0 kapsayıcısı denetim noktası"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Denetim noktasını diske yazdıktan sonra çalışır durumda bırak"
 ],
 "Support preserving established TCP connections": [
  null,
  "Kurulu TCP bağlantılarını korumayı destekle"
 ],
 "Failed to search for new images": [
  null,
  "Yeni kalıpları arama başarısız oldu"
 ],
 "Failed to search for images: $0": [
  null,
  "Kalıpları arama başarısız oldu: $0"
 ],
 "Failed to search for images.": [
  null,
  "Kalıpları arama başarısız oldu."
 ],
 "Search for an image": [
  null,
  "Kalıp ara"
 ],
 "Search for": [
  null,
  "Ara"
 ],
 "Search by name or description": [
  null,
  "Ada veya açıklamaya göre ara"
 ],
 "in": [
  null,
  "şurada"
 ],
 "All registries": [
  null,
  "Tüm kayıtlar"
 ],
 "Searching...": [
  null,
  "Aranıyor..."
 ],
 "No images found": [
  null,
  "Bulunan kalıplar yok"
 ],
 "Start typing to look for images.": [
  null,
  "Kalıpları aramak için yazmaya başlayın."
 ],
 "No results for $0": [
  null,
  "$0 için sonuçlar yok"
 ],
 "Retry another term.": [
  null,
  "Başka bir terimi yeniden deneyin."
 ],
 "Download": [
  null,
  "İndir"
 ],
 "No action": [
  null,
  "Eylem yok"
 ],
 "Container failed to be started": [
  null,
  "Kapsayıcının başlatılması başarısız oldu"
 ],
 "Failed to clean up container": [
  null,
  "Kapsayıcıyı temizleme başarısız oldu"
 ],
 "Container failed to be created": [
  null,
  "Kapsayıcının oluşturulması başarısız oldu"
 ],
 "downloading": [
  null,
  "indiriliyor"
 ],
 "Failed to run container $0": [
  null,
  "$0 kapsayıcısını çalıştırma başarısız oldu"
 ],
 "Failed to create container $0": [
  null,
  "$0 kapsayıcısını oluşturma başarısız oldu"
 ],
 "Failed to pull image $0": [
  null,
  "$0 kalıbını çekme başarısız oldu"
 ],
 "Local images": [
  null,
  "Yerel kalıplar"
 ],
 "Name already in use": [
  null,
  "Ad zaten kullanımda"
 ],
 "Search by registry": [
  null,
  "Kayıt defterine göre ara"
 ],
 "Local": [
  null,
  "Yerel"
 ],
 "Container name": [
  null,
  "Kapsayıcı adı"
 ],
 "Owner help": [
  null,
  "Sahibi yardımı"
 ],
 "Ideal for running services": [
  null,
  "Çalışan hizmetler için ideal"
 ],
 "Resource limits can be set": [
  null,
  "Kaynak sınırları ayarlanabilir"
 ],
 "Checkpoint and restore support": [
  null,
  "Denetim noktası ve geri yükleme desteği"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "1024 altındaki bağlantı noktaları eşlenebilir"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Ideal for development": [
  null,
  "Geliştirme için ideal"
 ],
 "Restricted by user account permissions": [
  null,
  "Kullanıcı hesabı izinleri tarafından kısıtlanmış"
 ],
 "Image selection help": [
  null,
  "Kalıp seçim yardımı"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "anamakine[:b.noktası]/[kullanıcı]/kapsayıcı[:etiket]"
 ],
 "Example: $0": [
  null,
  "Örnek: $0"
 ],
 "Searching: $0": [
  null,
  "Aranan: $0"
 ],
 "Search string or container location": [
  null,
  "Arama dizgisi veya kapsayıcı konumu"
 ],
 "Pull latest image": [
  null,
  "Son kalıbı çek"
 ],
 "Entrypoint": [
  null,
  "Giriş noktası"
 ],
 "With terminal": [
  null,
  "Terminal ile"
 ],
 "Memory limit": [
  null,
  "Bellek sınırı"
 ],
 "Decrease memory": [
  null,
  "Belleği azalt"
 ],
 "Increase memory": [
  null,
  "Belleği artır"
 ],
 "Memory unit": [
  null,
  "Bellek birimi"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU paylaşımları"
 ],
 "CPU Shares help": [
  null,
  "CPU Paylaşımları yardımı"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU paylaşımları, kapsayıcıları çalıştırmanın önceliğini belirler. Varsayılan öncelik 1024'dür. Daha yüksek bir sayı bu kapsayıcıya öncelik verir. Daha düşük bir sayı önceliği azaltır."
 ],
 "Decrease CPU shares": [
  null,
  "CPU paylaşımlarını azalt"
 ],
 "Increase CPU shares": [
  null,
  "CPU paylaşımlarını artır"
 ],
 "Restart policy": [
  null,
  "Yeniden başlatma ilkesi"
 ],
 "Restart policy help": [
  null,
  "Yeniden başlatma ilkesi yardımı"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Kapsayıcılar çıktığında izlenecek ilkeyi yeniden başlatın. Otomatik başlatma kapsayıcıları için geciktirme kullanılması, bir kullanıcı hesabında ecryptfs, systemd-homed, NFS veya 2FA kullanıldığında olduğu gibi bazı durumlarda çalışmayabilir."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Kapsayıcılardan çıkıldığında izlenecek ilkeyi yeniden başlatın."
 ],
 "No": [
  null,
  "Hayır"
 ],
 "On failure": [
  null,
  "Başarısızlıkla"
 ],
 "Always": [
  null,
  "Her zaman"
 ],
 "Maximum retries": [
  null,
  "En fazla yeniden deneme"
 ],
 "Decrease maximum retries": [
  null,
  "En fazla yeniden denemeyi azalt"
 ],
 "Increase maximum retries": [
  null,
  "En fazla yeniden denemeyi artır"
 ],
 "No environment variables specified": [
  null,
  "Belirtilen ortam değişkenleri yok"
 ],
 "Add variable": [
  null,
  "Değişken ekle"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Toplu içe aktarma için herhangi bir alana bir veya daha fazla anahtar=değer çifti satırı yapıştırın"
 ],
 "Interval": [
  null,
  "Aralık"
 ],
 "Health check interval help": [
  null,
  "Sağlık denetimi aralığı yardımı"
 ],
 "Interval how often health check is run.": [
  null,
  "Sağlık denetiminin ne sıklıkta çalıştırıldığı aralığı."
 ],
 "Decrease interval": [
  null,
  "Aralığı azalt"
 ],
 "Increase interval": [
  null,
  "Aralığı artır"
 ],
 "seconds": [
  null,
  "saniye"
 ],
 "Timeout": [
  null,
  "Zaman aşımı"
 ],
 "Health check timeout help": [
  null,
  "Sağlık denetimi zaman aşımı yardımı"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Bir aralığın başarısız olduğu kabul edilmeden önce sağlık denetimini tamamlanması için izin verilen en fazla süre."
 ],
 "Decrease timeout": [
  null,
  "Zaman aşımını azalt"
 ],
 "Increase timeout": [
  null,
  "Zaman aşımını artır"
 ],
 "Start period": [
  null,
  "Başlangıç süresi"
 ],
 "Health check start period help": [
  null,
  "Sağlık denetimi başlangıç dönemi yardımı"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Bir kapsayıcının önyükleme yapması için gereken başlatma süresi."
 ],
 "Decrease start period": [
  null,
  "Başlangıç süresini azalt"
 ],
 "Increase start period": [
  null,
  "Başlangıç süresini artır"
 ],
 "Retries": [
  null,
  "Yeniden denemeler"
 ],
 "Health check retries help": [
  null,
  "Sağlık denetimi yeniden denemeleri yardımı"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Bir sağlık denetiminden önce izin verilen yeniden deneme sayısı sağlıksız olarak kabul edilir."
 ],
 "Decrease retries": [
  null,
  "Yeniden denemeleri azalt"
 ],
 "Increase retries": [
  null,
  "Yeniden denemeleri artır"
 ],
 "When unhealthy": [
  null,
  "Sağlıksız olduğunda"
 ],
 "Health failure check action help": [
  null,
  "Sağlık denetimi hatası eylem yardımı"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Kapsayıcı sağlıksız bir duruma geçtikten sonra gerçekleştirilecek eylem."
 ],
 "Create container in $0": [
  null,
  "$0 içinde kapsayıcı oluştur"
 ],
 "Create and run": [
  null,
  "Oluştur ve çalıştır"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Version": [
  null,
  "Sürüm"
 ],
 "Links": [
  null,
  "Bağlantılar"
 ],
 "Documentation": [
  null,
  "Belgeler"
 ],
 "Tags": [
  null,
  "Etiketler"
 ],
 "Created by": [
  null,
  "Oluşturan"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Comments": [
  null,
  "Açıklamalar"
 ],
 "Unable to load image history": [
  null,
  "Kalıp geçmişini yükleme başarısız oldu"
 ],
 "Key must not be empty": [
  null,
  "Anahtar boş olmamak zorundadır"
 ],
 "Key must not begin with a digit": [
  null,
  "Anahtar bir rakamla başlamamalıdır"
 ],
 "Key contains invalid characters": [
  null,
  "Anahtar geçersiz karakterler içeriyor"
 ],
 "Key": [
  null,
  "Anahtar"
 ],
 "Value": [
  null,
  "Değer"
 ],
 "user": [
  null,
  "kullanıcı"
 ],
 "Podman service failed": [
  null,
  "Podman hizmeti başarısız oldu"
 ],
 "Troubleshoot": [
  null,
  "Sorun Giderme"
 ],
 "Failed to force remove image $0": [
  null,
  "$0 kalıbını zorla kaldırma başarısız oldu"
 ],
 "intermediate image": [
  null,
  "orta seviye kalıp"
 ],
 "Failed to remove image $0": [
  null,
  "$0 kalıbını kaldırma başarısız oldu"
 ],
 "intermediate": [
  null,
  "orta seviye"
 ],
 "Delete $0 image?": [
  null,
  "$0 kalıbı silinsin mi?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Bu kalıp için birden fazla etiket var. Silinecek etiketlenmiş kalıpları seçin."
 ],
 "Delete image": [
  null,
  "Kalıbı sil"
 ],
 "Delete tagged images": [
  null,
  "Etiketli kalıpları sil"
 ],
 "Container is not running": [
  null,
  "Kapsayıcı çalışmıyor"
 ],
 "Error occurred while connecting console": [
  null,
  "Konsola bağlanırken hata meydana geldi"
 ],
 "Force delete pod $0?": [
  null,
  "$0 bölmesi silmeye zorlansın mı?"
 ],
 "Delete pod $0?": [
  null,
  "$0 bölmesi silinsin mi?"
 ],
 "An error occurred": [
  null,
  "Bir hata meydana geldi"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Boş bölme $0 kalıcı olarak kaldırılacaktır."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Bu bölmeyi silmek aşağıdaki kapsayıcıları kaldıracak:"
 ],
 "Failed to start pod $0": [
  null,
  "$0 bölmesini başlatma başarısız oldu"
 ],
 "Failed to stop pod $0": [
  null,
  "$0 bölmesini durdurma başarısız oldu"
 ],
 "Failed to restart pod $0": [
  null,
  "$0 bölmesini yeniden başlatma başarısız oldu"
 ],
 "Failed to resume pod $0": [
  null,
  "$0 bölmesini sürdürme başarısız oldu"
 ],
 "Failed to pause pod $0": [
  null,
  "$0 bölmesini duraklatma başarısız oldu"
 ],
 "Failed to prune unused containers": [
  null,
  "Kullanılmayan kapsayıcıları ayıklama başarısız oldu"
 ],
 "Removes selected non-running containers": [
  null,
  "Seçilen çalışmayan kapsayıcıları kaldırır"
 ],
 "Pruning containers": [
  null,
  "Kapsayıcılar ayıklanıyor"
 ],
 "Container name is required.": [
  null,
  "Kapsayıcı adı gerekli."
 ],
 "Failed to rename container $0": [
  null,
  "$0 kapsayıcısını yeniden adlandırma başarısız oldu"
 ],
 "New container name": [
  null,
  "Yeni kapsayıcı adı"
 ],
 "Rename container $0": [
  null,
  "$0 kapsayıcısını yeniden adlandır"
 ],
 "Paused": [
  null,
  "Duraklatıldı"
 ],
 "Stopped": [
  null,
  "Durduruldu"
 ],
 "Removing": [
  null,
  "Kaldırılıyor"
 ],
 "Configured": [
  null,
  "Yapılandırıldı"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "$0 second": [
  null,
  "$0 saniye",
  "$0 saniye"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Failing streak": [
  null,
  "Başarısız olan seri"
 ],
 "Failed to run health check on container $0": [
  null,
  "$0 kapsayıcısında sağlık denetimi çalıştırma başarısız oldu"
 ],
 "Run health check": [
  null,
  "Sağlık denetimini çalıştır"
 ],
 "Last 5 runs": [
  null,
  "Son 5 çalıştırma"
 ],
 "Started at": [
  null,
  "Başlama zamanı"
 ],
 "Passed health run": [
  null,
  "Sağlık çalıştırması geçti"
 ],
 "Failed health run": [
  null,
  "Sağlık işlemini çalıştırma başarısız oldu"
 ],
 "Failed to remove container $0": [
  null,
  "$0 kapsayıcısını kaldırma başarısız oldu"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Bir kapsayıcıyı silmek içindeki tüm verileri silecek."
 ]
});
