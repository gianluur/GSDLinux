cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "et",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Failibrauser"
 ],
 "files": [
  null,
  "failid"
 ],
 "explorer": [
  null,
  "sirvija"
 ],
 "filesystem": [
  null,
  "failisüsteem"
 ]
});
