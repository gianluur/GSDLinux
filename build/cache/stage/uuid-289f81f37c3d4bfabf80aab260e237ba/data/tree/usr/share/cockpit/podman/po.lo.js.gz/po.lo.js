cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "ລຶບ $0 ບໍ່?"
 ],
 "Force delete": [
  null,
  "ບັງຄັບລຶບ"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Must be a valid IP address": [
  null,
  "ຕ້ອງເປັນທີ່ຢູ່ IP ທີ່ຖືກຕ້ອງ"
 ],
 "1 to 65535": [
  null,
  "1 ຫາ 65535"
 ],
 "Container port must not be empty": [
  null,
  "ພອດຂອງຄອນເທນເນີຕ້ອງບໍ່ຫວ່າງເປົ່າ"
 ],
 "IP address": [
  null,
  "ທີ່ຢູ່ IP"
 ],
 "IP address help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງທີ່ຢູ່ IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "ຖ້າຕັ້ງ IP ຂອງໂຮສເປັນ 0.0.0.0 ຫຼື ບໍ່ໄດ້ຕັ້ງເລີຍ, ພອດຈະຖືກເຊື່ອມກັບທຸກໆ IP ທີ່ມີຢູ່ໃນເຄື່ອງໂຮສ."
 ],
 "Host port": [
  null,
  "ພອດຂອງໂຮສ"
 ],
 "Host port help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງພອດຂອງໂຮສ"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "ຖ້າບໍ່ໄດ້ຕັ້ງພອດຂອງໂຮສ, ພອດຂອງຄອນເທນເນີຈະຖືກສຸ່ມໝາຍເລກພອດໃຫ້ໃນເຄື່ອງໂຮສ."
 ],
 "Container port": [
  null,
  "ພອດຂອງຄອນເທນເນີ"
 ],
 "Protocol": [
  null,
  "ໂປຣໂຕຄອນ (Protocol)"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "ລຶບລາຍການອອກ"
 ],
 "Image name is required": [
  null,
  "ຕ້ອງໃສ່ຊື່ອິເມຈ"
 ],
 "Image name is not unique": [
  null,
  "ຊື່ອິເມຈຊ້ຳກັບທີ່ມີຢູ່ແລ້ວ"
 ],
 "Failed to commit container $0": [
  null,
  "ບໍ່ສາມາດຄອມມິດຄອນເທນເນີ $0"
 ],
 "New image name": [
  null,
  "ຊື່ອິເມຈໃໝ່"
 ],
 "Tag": [
  null,
  "ແທັກ (Tag)"
 ],
 "Author": [
  null,
  "ຜູ້ສ້າງ"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "ຕົວຢ່າງ, ຊື່ຂອງທ່ານ <yourname@example.com>"
 ],
 "Command": [
  null,
  "ຄຳສັ່ງ"
 ],
 "Options": [
  null,
  "ຕົວເລືອກ"
 ],
 "Pause container when creating image": [
  null,
  "ພັກຄອນເທນເນີຊົ່ວຄາວໃນຂະນະທີ່ກຳລັງສ້າງອິເມຈ"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "ຮູບແບບ Docker ແມ່ນມີປະໂຫຍດເມື່ອແບ່ງປັນອິເມຈໃຫ້ກັບ Docker ຫຼື Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "ໃຊ້ຮູບແບບ Docker ແບບເກົ່າ"
 ],
 "Commit container": [
  null,
  "ຄອມມິດຄອນເທນເນີ"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "ສ້າງອິເມຈໃໝ່ໂດຍອີງຕາມສະຖານະປັດຈຸບັນຂອງຄອນເທນເນີ $0."
 ],
 "Commit": [
  null,
  "ຄອມມິດ (Commit)"
 ],
 "Force commit": [
  null,
  "ບັງຄັບຄອມມິດ"
 ],
 "Failed to force remove container $0": [
  null,
  "ບໍ່ສາມາດບັງຄັບລຶບຄອນເທນເນີ $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "ການລຶບຄອນເທນເນີທີ່ກຳລັງເຮັດວຽກຈະເຮັດໃຫ້ຂໍ້ມູນທັງໝົດໃນນັ້ນຖືກລຶບອອກ."
 ],
 "Failed to stop container $0": [
  null,
  "ບໍ່ສາມາດຢຸດຄອນເທນເນີ $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "ບໍ່ສາມາດຢຸດ quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມ quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມຄອນເທນເນີ $0"
 ],
 "Failed to resume container $0": [
  null,
  "ບໍ່ສາມາດໃຫ້ຄອນເທນເນີ $0 ເຮັດວຽກຕໍ່"
 ],
 "Failed to pause container $0": [
  null,
  "ບໍ່ສາມາດພັກຄອນເທນເນີ $0 ຊົ່ວຄາວ"
 ],
 "Failed to restart container $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມຕົ້ນຄອນເທນເນີ $0 ໃໝ່"
 ],
 "Failed to restart quadlet $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມຕົ້ນ quadlet $0 ໃໝ່"
 ],
 "Rename": [
  null,
  "ປ່ຽນຊື່"
 ],
 "Stop": [
  null,
  "ຢຸດ"
 ],
 "Restart": [
  null,
  "ເລີ່ມຕົ້ນໃໝ່ (Restart)"
 ],
 "Force stop": [
  null,
  "ບັງຄັບຢຸດ"
 ],
 "Force restart": [
  null,
  "ບັງຄັບເລີ່ມຕົ້ນໃໝ່"
 ],
 "Pause": [
  null,
  "ພັກຊົ່ວຄາວ"
 ],
 "Resume": [
  null,
  "ເຮັດວຽກຕໍ່"
 ],
 "Checkpoint": [
  null,
  "ເຊັກພອຍ (Checkpoint)"
 ],
 "Start": [
  null,
  "ເລີ່ມ"
 ],
 "Restore": [
  null,
  "ຄືນຄ່າ"
 ],
 "Delete": [
  null,
  "ລຶບ"
 ],
 "Healthy": [
  null,
  "ປົກກະຕິ (Healthy)"
 ],
 "Unhealthy": [
  null,
  "ບໍ່ສົມບູນ (Unhealthy)"
 ],
 "Checking health": [
  null,
  "ກຳລັງກວດສອບສຸຂະພາບລະບົບ"
 ],
 "Prune unused containers": [
  null,
  "ລ້າງຄອນເທນເນີທີ່ບໍ່ໄດ້ໃຊ້"
 ],
 "Terminal not available": [
  null,
  "ເທີມີນໍບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "This browser does not support WebGL2.": [
  null,
  "ບຣາວເຊີນີ້ບໍ່ຮອງຮັບ WebGL2."
 ],
 "View $0 logs": [
  null,
  "ເບິ່ງບັນທຶກລັອກ $0"
 ],
 "not available": [
  null,
  "ບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "n/a": [
  null,
  "ບໍ່ມີຂໍ້ມູນ"
 ],
 "$0% of $1 limit": [
  null,
  "$0% ຈາກຂີດຈຳກັດ $1"
 ],
 "service": [
  null,
  "ບໍລິການ"
 ],
 "system": [
  null,
  "ລະບົບ"
 ],
 "user:": [
  null,
  "ຜູ້ໃຊ້:"
 ],
 "Details": [
  null,
  "ລາຍລະອຽດ"
 ],
 "Integration": [
  null,
  "ການເຊື່ອມຕໍ່ລະບົບ (Integration)"
 ],
 "Logs": [
  null,
  "ບັນທຶກລັອກ"
 ],
 "Console": [
  null,
  "ຄອນໂຊລ"
 ],
 "Health check": [
  null,
  "ກວດສອບສຸຂະພາບລະບົບ"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "ໜ່ວຍຄວາມຈຳ"
 ],
 "Click to see published ports": [
  null,
  "ຄລິກເພື່ອເບິ່ງພອດທີ່ເປີດໃຊ້"
 ],
 "ports": [
  null,
  "ພອດ"
 ],
 "Click to see volumes": [
  null,
  "ຄລິກເພື່ອເບິ່ງໂວລຸມ"
 ],
 "volumes": [
  null,
  "ໂວລຸມ"
 ],
 "Container": [
  null,
  "ຄອນເທນເນີ (Container)"
 ],
 "Owner": [
  null,
  "ເຈົ້າຂອງ"
 ],
 "State": [
  null,
  "ສະຖານະ"
 ],
 "Actions": [
  null,
  "ການດຳເນີນການຕ່າງໆ"
 ],
 "No containers": [
  null,
  "ບໍ່ມີຄອນເທນເນີ"
 ],
 "No containers in this pod": [
  null,
  "ບໍ່ມີຄອນເທນເນີໃນພອດ (Pod) ນີ້"
 ],
 "Loading...": [
  null,
  "ກຳລັງໂຫຼດ..."
 ],
 "No containers that match the current filter": [
  null,
  "ບໍ່ມີຄອນເທນເນີທີ່ກົງກັບຕົວຕອງປັດຈຸບັນ"
 ],
 "No running containers": [
  null,
  "ບໍ່ມີຄອນເທນເນີທີ່ກຳລັງເຮັດວຽກ"
 ],
 "Show": [
  null,
  "ສະແດງ"
 ],
 "All": [
  null,
  "ທັງໝົດ"
 ],
 "Only running": [
  null,
  "ສະເພາະທີ່ກຳລັງເຮັດວຽກ"
 ],
 "Create pod": [
  null,
  "ສ້າງພອດ (Pod)"
 ],
 "Create container": [
  null,
  "ສ້າງຄອນເທນເນີ"
 ],
 "Containers": [
  null,
  "ຄອນເທນເນີທັງໝົດ"
 ],
 "Create container in pod": [
  null,
  "ສ້າງຄອນເທນເນີໃນພອດ (Pod)"
 ],
 "pod": [
  null,
  "ພອດ (pod)"
 ],
 "Failed to restore container $0": [
  null,
  "ບໍ່ສາມາດຄືນຄ່າຄອນເທນເນີ $0"
 ],
 "Restore container $0": [
  null,
  "ຄືນຄ່າຄອນເທນເນີ $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "ເກັບໄຟລ໌ເຊັກພອຍຊົ່ວຄາວທັງໝົດໄວ້"
 ],
 "Restore with established TCP connections": [
  null,
  "ຄືນຄ່າພ້ອມກັບການເຊື່ອມຕໍ່ TCP ທີ່ສ້າງໄວ້ແລ້ວ"
 ],
 "Ignore IP address if set statically": [
  null,
  "ລະເວັ້ນທີ່ຢູ່ IP ຫາກມີການຕັ້ງຄ່າແບບຄົງທີ່ (Static)"
 ],
 "Ignore MAC address if set statically": [
  null,
  "ລະເວັ້ນທີ່ຢູ່ MAC ຫາກມີການຕັ້ງຄ່າແບບຄົງທີ່ (Static)"
 ],
 "Pod failed to be created": [
  null,
  "ສ້າງພອດ (Pod) ບໍ່ສຳເລັດ"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "ຕົວອັກສອນບໍ່ຖືກຕ້ອງ. ຊື່ສາມາດມີໄດ້ສະເພາະຕົວໜັງສື, ຕົວເລກ, ແລະ ເຄື່ອງໝາຍວັກຕອນບາງຢ່າງ (_ . -)."
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Pod name": [
  null,
  "ຊື່ພອດ (Pod)"
 ],
 "System": [
  null,
  "ລະບົບ"
 ],
 "User:": [
  null,
  "ຜູ້ໃຊ້:"
 ],
 "No ports exposed": [
  null,
  "ບໍ່ມີພອດທີ່ເປີດອອກພາຍນອກ"
 ],
 "Port mapping": [
  null,
  "ການຈັບຄູ່ພອດ"
 ],
 "Add port mapping": [
  null,
  "ເພີ່ມການຈັບຄູ່ພອດ"
 ],
 "No volumes specified": [
  null,
  "ບໍ່ໄດ້ກຳນົດໂວລຸມ"
 ],
 "Volumes": [
  null,
  "ໂວລຸມ (Volumes)"
 ],
 "Add volume": [
  null,
  "ເພີ່ມໂວລຸມ (Volume)"
 ],
 "Create": [
  null,
  "ສ້າງ"
 ],
 "Type to filter…": [
  null,
  "ພິມເພື່ອຕອງຂໍ້ມູນ…"
 ],
 "Container path must not be empty": [
  null,
  "ເສັ້ນທາງໃນຄອນເທນເນີຕ້ອງບໍ່ຫວ່າງເປົ່າ"
 ],
 "Host path": [
  null,
  "ເສັ້ນທາງ (Path) ຂອງເຄື່ອງໂຮສ"
 ],
 "Container path": [
  null,
  "ເສັ້ນທາງ (Path) ໃນຄອນເທນເນີ"
 ],
 "Mode": [
  null,
  "ໂໝດ"
 ],
 "Writable": [
  null,
  "ສາມາດຂຽນໄດ້"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "ບໍ່ມີປ້າຍກຳກັບ (Label)"
 ],
 "Shared": [
  null,
  "ໃຊ້ຮ່ວມກັນ"
 ],
 "Private": [
  null,
  "ສ່ວນຕົວ (Private)"
 ],
 "Read-write access": [
  null,
  "ສິດອ່ານ ແລະ ຂຽນ"
 ],
 "Read-only access": [
  null,
  "ສິດອ່ານຢ່າງດຽວ"
 ],
 "Show less": [
  null,
  "ສະແດງໜ້ອຍລົງ"
 ],
 "Show more": [
  null,
  "ສະແດງເພີ່ມເຕີມ"
 ],
 "Loading details...": [
  null,
  "ກຳລັງໂຫຼດລາຍລະອຽດ..."
 ],
 "Ports": [
  null,
  "ພອດ (Ports)"
 ],
 "Environment variables": [
  null,
  "ຕົວປ່ຽນສະພາບແວດລ້ອມ (Environment variables)"
 ],
 "Failed to download image $0:$1": [
  null,
  "ບໍ່ສາມາດດາວໂຫຼດອິເມຈ $0:$1"
 ],
 "Error message": [
  null,
  "ຂໍ້ຄວາມຜິດພາດ"
 ],
 "unused": [
  null,
  "ບໍ່ໄດ້ໃຊ້"
 ],
 "$0 container": [
  null,
  "$0 ຄອນເທນເນີ"
 ],
 "History": [
  null,
  "ປະຫວັດ"
 ],
 "Image": [
  null,
  "ອິເມຈ (Image)"
 ],
 "Created": [
  null,
  "ສ້າງແລ້ວ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "ເນື້ອທີ່ດິສກ໌"
 ],
 "Used by": [
  null,
  "ໃຊ້ໂດຍ"
 ],
 "No images": [
  null,
  "ບໍ່ມີອິເມຈ"
 ],
 "No images that match the current filter": [
  null,
  "ບໍ່ມີອິເມຈທີ່ກົງກັບຕົວຕອງປັດຈຸບັນ"
 ],
 "Hide intermediate images": [
  null,
  "ເຊື່ອງອິເມຈລະຫວ່າງກາງ (Intermediate)"
 ],
 "Show intermediate images": [
  null,
  "ສະແດງອິເມຈລະຫວ່າງກາງ (Intermediate)"
 ],
 "Images": [
  null,
  "ອິເມຈທັງໝົດ"
 ],
 "$0 image total, $1": [
  null,
  "ອິເມຈທັງໝົດ $0, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 ອິເມຈທີ່ບໍ່ໄດ້ໃຊ້, $1"
 ],
 "Hide images": [
  null,
  "ເຊື່ອງອິເມຈ"
 ],
 "Show images": [
  null,
  "ສະແດງອິເມຈ"
 ],
 "Pulling": [
  null,
  "ກຳລັງດຶງ (Pulling)"
 ],
 "Download new image": [
  null,
  "ດາວໂຫຼດອິເມຈໃໝ່"
 ],
 "Pull all images": [
  null,
  "ດຶງອິເມຈທັງໝົດ"
 ],
 "Prune unused images": [
  null,
  "ລ້າງອິເມຈທີ່ບໍ່ໄດ້ໃຊ້"
 ],
 "Pull": [
  null,
  "ດຶງ (Pull)"
 ],
 "Up since:": [
  null,
  "ເປີດໃຊ້ງານຕັ້ງແຕ່:"
 ],
 "Exited": [
  null,
  "ອອກແລ້ວ"
 ],
 "systemd service": [
  null,
  "ບໍລິການ systemd"
 ],
 "View $0": [
  null,
  "ເບິ່ງ $0"
 ],
 "Gateway": [
  null,
  "ເກດເວ (Gateway)"
 ],
 "MAC address": [
  null,
  "ທີ່ຢູ່ MAC"
 ],
 "Latest checkpoint": [
  null,
  "ເຊັກພອຍຫຼ້າສຸດ"
 ],
 "No containers are using this image": [
  null,
  "ບໍ່ມີຄອນເທນເນີໃດກຳລັງໃຊ້ອິເມຈນີ້"
 ],
 "Running": [
  null,
  "ກຳລັງເຮັດວຽກ"
 ],
 "Loading logs...": [
  null,
  "ກຳລັງໂຫຼດບັນທຶກລັອກ..."
 ],
 "Delete unused system images:": [
  null,
  "ລຶບອິເມຈຂອງລະບົບທີ່ບໍ່ໄດ້ໃຊ້:"
 ],
 "Delete unused images of user $0:": [
  null,
  "ລຶບອິເມຈທີ່ບໍ່ໄດ້ໃຊ້ຂອງຜູ້ໃຊ້ $0:"
 ],
 "Failed to prune unused images": [
  null,
  "ບໍ່ສາມາດລ້າງອິເມຈທີ່ບໍ່ໄດ້ໃຊ້"
 ],
 "Pruning images": [
  null,
  "ກຳລັງລ້າງອິເມຈ"
 ],
 "Prune": [
  null,
  "ລ້າງຂໍ້ມູນ (Prune)"
 ],
 "Failed to checkpoint container $0": [
  null,
  "ບໍ່ສາມາດສ້າງເຊັກພອຍໃຫ້ຄອນເທນເນີ $0"
 ],
 "Checkpoint container $0": [
  null,
  "ສ້າງເຊັກພອຍໃຫ້ຄອນເທນເນີ $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "ໃຫ້ເຮັດວຽກຕໍ່ໄປຫຼັງຈາກບັນທຶກເຊັກພອຍລົງດິສກ໌ແລ້ວ"
 ],
 "Support preserving established TCP connections": [
  null,
  "ຮອງຮັບການຮັກສາການເຊື່ອມຕໍ່ TCP ທີ່ສ້າງໄວ້ແລ້ວ"
 ],
 "Failed to search for new images": [
  null,
  "ຄົ້ນຫາອິເມຈໃໝ່ບໍ່ສຳເລັດ"
 ],
 "Failed to search for images: $0": [
  null,
  "ຄົ້ນຫາອິເມຈບໍ່ສຳເລັດ: $0"
 ],
 "Failed to search for images.": [
  null,
  "ຄົ້ນຫາອິເມຈບໍ່ສຳເລັດ."
 ],
 "Search for an image": [
  null,
  "ຄົ້ນຫາອິເມຈ"
 ],
 "Search for": [
  null,
  "ຄົ້ນຫາ"
 ],
 "Search by name or description": [
  null,
  "ຄົ້ນຫາຕາມຊື່ ຫຼື ຄຳອະທິບາຍ"
 ],
 "in": [
  null,
  "ໃນ"
 ],
 "All registries": [
  null,
  "ເລຈິດສະຕຣີທັງໝົດ"
 ],
 "Searching...": [
  null,
  "ກຳລັງຄົ້ນຫາ..."
 ],
 "No images found": [
  null,
  "ບໍ່ພົບອິເມຈ"
 ],
 "Start typing to look for images.": [
  null,
  "ພິມເພື່ອຄົ້ນຫາອິເມຈ."
 ],
 "No results for $0": [
  null,
  "ບໍ່ມີຜົນການຄົ້ນຫາສຳລັບ $0"
 ],
 "Retry another term.": [
  null,
  "ລອງໃຊ້ຄຳຄົ້ນຫາອື່ນ."
 ],
 "Download": [
  null,
  "ດາວໂຫຼດ"
 ],
 "No action": [
  null,
  "ບໍ່ມີການດຳເນີນການ"
 ],
 "Container failed to be started": [
  null,
  "ເລີ່ມເຮັດວຽກຄອນເທນເນີບໍ່ສຳເລັດ"
 ],
 "Failed to clean up container": [
  null,
  "ບໍ່ສາມາດລ້າງຂໍ້ມູນຄອນເທນເນີ"
 ],
 "Container failed to be created": [
  null,
  "ສ້າງຄອນເທນເນີບໍ່ສຳເລັດ"
 ],
 "downloading": [
  null,
  "ກຳລັງດາວໂຫຼດ"
 ],
 "Failed to run container $0": [
  null,
  "ບໍ່ສາມາດສັ່ງໃຫ້ຄອນເທນເນີ $0 ເຮັດວຽກ"
 ],
 "Failed to create container $0": [
  null,
  "ບໍ່ສາມາດສ້າງຄອນເທນເນີ $0"
 ],
 "Failed to pull image $0": [
  null,
  "ບໍ່ສາມາດດຶງ (Pull) ອິເມຈ $0"
 ],
 "Local images": [
  null,
  "ອິເມຈພາຍໃນເຄື່ອງ"
 ],
 "Name already in use": [
  null,
  "ຊື່ນີ້ຖືກໃຊ້ໄປແລ້ວ"
 ],
 "Search by registry": [
  null,
  "ຄົ້ນຫາຕາມເລຈິດສະຕຣີ"
 ],
 "Local": [
  null,
  "ພາຍໃນເຄື່ອງ (Local)"
 ],
 "Container name": [
  null,
  "ຊື່ຄອນເທນເນີ"
 ],
 "Owner help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງເຈົ້າຂອງ"
 ],
 "Ideal for running services": [
  null,
  "ເໝາະສຳລັບການເປີດບໍລິການ (Services)"
 ],
 "Resource limits can be set": [
  null,
  "ສາມາດຕັ້ງຂີດຈຳກັດຊັບພະຍາກອນໄດ້"
 ],
 "Checkpoint and restore support": [
  null,
  "ຮອງຮັບການເຮັດເຊັກພອຍ ແລະ ຄືນຄ່າ"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "ພອດທີ່ຕ່ຳກວ່າ 1024 ສາມາດຈັບຄູ່ໄດ້"
 ],
 "User": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "Ideal for development": [
  null,
  "ເໝາະສຳລັບການພັດທະນາ"
 ],
 "Restricted by user account permissions": [
  null,
  "ຖືກຈຳກັດໂດຍສິດການໃຊ້ງານຂອງບັນຊີຜູ້ໃຊ້"
 ],
 "Image selection help": [
  null,
  "ຊ່ວຍເຫຼືອໃນການເລືອກອິເມຈ"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "Example: $0": [
  null,
  "ຕົວຢ່າງ: $0"
 ],
 "Searching: $0": [
  null,
  "ກຳລັງຄົ້ນຫາ: $0"
 ],
 "Search string or container location": [
  null,
  "ຄົ້ນຫາຂໍ້ຄວາມ ຫຼື ທີ່ຢູ່ຂອງຄອນເທນເນີ"
 ],
 "Pull latest image": [
  null,
  "ດຶງອິເມຈຫຼ້າສຸດ"
 ],
 "Entrypoint": [
  null,
  "ຈຸດເລີ່ມຕົ້ນ (Entrypoint)"
 ],
 "With terminal": [
  null,
  "ພ້ອມເທີມີນໍ"
 ],
 "Memory limit": [
  null,
  "ຂີດຈຳກັດໜ່ວຍຄວາມຈຳ"
 ],
 "Decrease memory": [
  null,
  "ຫຼຸດໜ່ວຍຄວາມຈຳ"
 ],
 "Increase memory": [
  null,
  "ເພີ່ມໜ່ວຍຄວາມຈຳ"
 ],
 "Memory unit": [
  null,
  "ຫົວໜ່ວຍຄວາມຈຳ"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "ສ່ວນແບ່ງ CPU"
 ],
 "CPU Shares help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງສ່ວນແບ່ງ CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "ສ່ວນແບ່ງ CPU ກຳນົດລຳດັບຄວາມສຳຄັນຂອງຄອນເທນເນີທີ່ກຳລັງເຮັດວຽກ. ຄ່າເລີ່ມຕົ້ນແມ່ນ 1024. ຕົວເລກທີ່ສູງກວ່າຈະໃຫ້ຄວາມສຳຄັນແກ່ຄອນເທນເນີນີ້ກ່ອນ. ຕົວເລກທີ່ຕ່ຳກວ່າຈະຫຼຸດລຳດັບຄວາມສຳຄັນລົງ."
 ],
 "Decrease CPU shares": [
  null,
  "ຫຼຸດສ່ວນແບ່ງ CPU"
 ],
 "Increase CPU shares": [
  null,
  "ເພີ່ມສ່ວນແບ່ງ CPU"
 ],
 "Restart policy": [
  null,
  "ນະໂຍບາຍການເລີ່ມຕົ້ນໃໝ່"
 ],
 "Restart policy help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງນະໂຍບາຍການເລີ່ມຕົ້ນໃໝ່"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "ນະໂຍບາຍການເລີ່ມຕົ້ນໃໝ່ທີ່ຈະໃຊ້ເມື່ອຄອນເທນເນີຢຸດເຮັດວຽກ. ການໃຊ້ linger ສຳລັບການເລີ່ມຄອນເທນເນີອັດຕະໂນມັດອາດຈະບໍ່ເຮັດວຽກໃນບາງກໍລະນີ, ເຊັ່ນເມື່ອມີການໃຊ້ ecryptfs, systemd-homed, NFS, ຫຼື 2FA ໃນບັນຊີຜູ້ໃຊ້."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "ນະໂຍບາຍການເລີ່ມຕົ້ນໃໝ່ທີ່ຈະໃຊ້ເມື່ອຄອນເທນເນີຢຸດເຮັດວຽກ."
 ],
 "No": [
  null,
  "ບໍ່"
 ],
 "On failure": [
  null,
  "ເມື່ອເກີດຄວາມຜິດພາດ"
 ],
 "Always": [
  null,
  "ຕະຫຼອດເວລາ"
 ],
 "Maximum retries": [
  null,
  "ຈຳນວນການລອງໃໝ່ສູງສຸດ"
 ],
 "Decrease maximum retries": [
  null,
  "ຫຼຸດຈຳນວນຄັ້ງສູງສຸດໃນການລອງໃໝ່"
 ],
 "Increase maximum retries": [
  null,
  "ເພີ່ມຈຳນວນຄັ້ງສູງສຸດໃນການລອງໃໝ່"
 ],
 "No environment variables specified": [
  null,
  "ບໍ່ໄດ້ກຳນົດຕົວປ່ຽນສະພາບແວດລ້ອມ"
 ],
 "Add variable": [
  null,
  "ເພີ່ມຕົວປ່ຽນ"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "ວາງຄູ່ key=value ຫຼາຍໆແຖວໃສ່ໃນຫ້ອງໃດກໍໄດ້ເພື່ອເພີ່ມຂໍ້ມູນພ້ອມກັນຫຼາຍລາຍການ"
 ],
 "Interval": [
  null,
  "ໄລຍະຫ່າງ"
 ],
 "Health check interval help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງໄລຍະຫ່າງການກວດສອບສຸຂະພາບ"
 ],
 "Interval how often health check is run.": [
  null,
  "ໄລຍະຫ່າງວ່າຈະໃຫ້ກວດສອບສຸຂະພາບລະບົບເລື້ອຍປານໃດ."
 ],
 "Decrease interval": [
  null,
  "ຫຼຸດໄລຍະຫ່າງ"
 ],
 "Increase interval": [
  null,
  "ເພີ່ມໄລຍະຫ່າງ"
 ],
 "seconds": [
  null,
  "ວິນາທີ"
 ],
 "Timeout": [
  null,
  "ໝົດກຳນົດເວລາ"
 ],
 "Health check timeout help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງເວລາໝົດກຳນົດການກວດສອບສຸຂະພາບ"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "ເວລາສູງສຸດທີ່ອະນຸຍາດໃຫ້ກວດສອບສຸຂະພາບ ກ່ອນທີ່ຈະຖືວ່າການກວດສອບຄັ້ງນັ້ນລົ້ມເຫຼວ."
 ],
 "Decrease timeout": [
  null,
  "ຫຼຸດເວລາໝົດກຳນົດ (Timeout)"
 ],
 "Increase timeout": [
  null,
  "ເພີ່ມເວລາໝົດກຳນົດ"
 ],
 "Start period": [
  null,
  "ໄລຍະເວລາເລີ່ມຕົ້ນ"
 ],
 "Health check start period help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງໄລຍະເວລາເລີ່ມຕົ້ນການກວດສອບສຸຂະພາບ"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "ໄລຍະເວລາເລີ່ມຕົ້ນທີ່ຄອນເທນເນີຕ້ອງການເພື່ອບູດລະບົບ (Bootstrap)."
 ],
 "Decrease start period": [
  null,
  "ຫຼຸດໄລຍະເວລາເລີ່ມຕົ້ນ"
 ],
 "Increase start period": [
  null,
  "ເພີ່ມໄລຍະເວລາເລີ່ມຕົ້ນ"
 ],
 "Retries": [
  null,
  "ການລອງໃໝ່"
 ],
 "Health check retries help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງການລອງໃໝ່ໃນການກວດສອບສຸຂະພາບ"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "ຈຳນວນຄັ້ງທີ່ອະນຸຍາດໃຫ້ລອງໃໝ່ ກ່ອນທີ່ຈະຖືວ່າສຸຂະພາບຂອງຄອນເທນເນີບໍ່ສົມບູນ (Unhealthy)."
 ],
 "Decrease retries": [
  null,
  "ຫຼຸດການລອງໃໝ່"
 ],
 "Increase retries": [
  null,
  "ເພີ່ມການລອງໃໝ່"
 ],
 "When unhealthy": [
  null,
  "ເມື່ອບໍ່ສົມບູນ (Unhealthy)"
 ],
 "Health failure check action help": [
  null,
  "ຊ່ວຍເຫຼືອເລື່ອງການດຳເນີນການເມື່ອກວດສອບສຸຂະພາບລົ້ມເຫຼວ"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "ການດຳເນີນການທີ່ຈະເຮັດເມື່ອຄອນເທນເນີປ່ຽນໄປສູ່ສະຖານະທີ່ບໍ່ສົມບູນ (Unhealthy)."
 ],
 "Create container in $0": [
  null,
  "ສ້າງຄອນເທນເນີໃນ $0"
 ],
 "Create and run": [
  null,
  "ສ້າງ ແລະ ເລີ່ມເຮັດວຽກ"
 ],
 "Description": [
  null,
  "ຄຳອະທິບາຍ"
 ],
 "Version": [
  null,
  "ເວີຊັນ"
 ],
 "Links": [
  null,
  "ລີ້ງຄ໌"
 ],
 "Documentation": [
  null,
  "ເອກະສານແນະນຳ"
 ],
 "Tags": [
  null,
  "ແທັກທັງໝົດ"
 ],
 "Created by": [
  null,
  "ສ້າງໂດຍ"
 ],
 "Size": [
  null,
  "ຂະໜາດ"
 ],
 "Comments": [
  null,
  "ຄຳຄິດເຫັນ"
 ],
 "Unable to load image history": [
  null,
  "ບໍ່ສາມາດໂຫຼດປະຫວັດຂອງອິເມຈ"
 ],
 "Key must not be empty": [
  null,
  "ຄີ (Key) ຕ້ອງບໍ່ຫວ່າງເປົ່າ"
 ],
 "Key must not begin with a digit": [
  null,
  "ຄີ (Key) ຕ້ອງບໍ່ຂຶ້ນຕົ້ນດ້ວຍຕົວເລກ"
 ],
 "Key contains invalid characters": [
  null,
  "ຄີ (Key) ມີຕົວອັກສອນທີ່ບໍ່ຖືກຕ້ອງ"
 ],
 "Key": [
  null,
  "ຄີ (Key)"
 ],
 "Value": [
  null,
  "ຄ່າ (Value)"
 ],
 "user": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "Podman service failed": [
  null,
  "ການບໍລິການ Podman ລົ້ມເຫຼວ"
 ],
 "Troubleshoot": [
  null,
  "ແກ້ໄຂບັນຫາ"
 ],
 "Failed to force remove image $0": [
  null,
  "ບໍ່ສາມາດບັງຄັບລຶບອິເມຈ $0"
 ],
 "intermediate image": [
  null,
  "ອິເມຈລະຫວ່າງກາງ"
 ],
 "Failed to remove image $0": [
  null,
  "ບໍ່ສາມາດລຶບອິເມຈ $0"
 ],
 "intermediate": [
  null,
  "ລະຫວ່າງກາງ"
 ],
 "Delete $0 image?": [
  null,
  "ລຶບອິເມຈ $0 ບໍ່?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "ມີຫຼາຍແທັກ (Tag) ສຳລັບອິເມຈນີ້. ກະລຸນາເລືອກອິເມຈທີ່ມີແທັກທີ່ຕ້ອງການລຶບ."
 ],
 "Delete image": [
  null,
  "ລຶບອິເມຈ"
 ],
 "Delete tagged images": [
  null,
  "ລຶບອິເມຈທີ່ມີແທັກ (Tag)"
 ],
 "Container is not running": [
  null,
  "ຄອນເທນເນີບໍ່ໄດ້ກຳລັງເຮັດວຽກ"
 ],
 "Error occurred while connecting console": [
  null,
  "ເກີດຂໍ້ຜິດພາດຂຶ້ນໃນຂະນະທີ່ເຊື່ອມຕໍ່ກັບຄອນໂຊລ"
 ],
 "Force delete pod $0?": [
  null,
  "ບັງຄັບລຶບພອດ $0 ບໍ່?"
 ],
 "Delete pod $0?": [
  null,
  "ລຶບພອດ $0 ບໍ່?"
 ],
 "An error occurred": [
  null,
  "ເກີດຂໍ້ຜິດພາດຂຶ້ນ"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "ພອດ $0 ທີ່ວ່າງເປົ່າຈະຖືກລຶບອອກຢ່າງຖາວອນ."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "ການລຶບພອດນີ້ຈະເຮັດໃຫ້ຄອນເທນເນີຕໍ່ໄປນີ້ຖືກລຶບອອກນຳ:"
 ],
 "Failed to start pod $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມພອດ $0"
 ],
 "Failed to stop pod $0": [
  null,
  "ບໍ່ສາມາດຢຸດພອດ $0"
 ],
 "Failed to restart pod $0": [
  null,
  "ບໍ່ສາມາດເລີ່ມຕົ້ນພອດ $0 ໃໝ່"
 ],
 "Failed to resume pod $0": [
  null,
  "ບໍ່ສາມາດໃຫ້ພອດ $0 ເຮັດວຽກຕໍ່"
 ],
 "Failed to pause pod $0": [
  null,
  "ບໍ່ສາມາດພັກພອດ $0 ຊົ່ວຄາວ"
 ],
 "Failed to prune unused containers": [
  null,
  "ບໍ່ສາມາດລ້າງຄອນເທນເນີທີ່ບໍ່ໄດ້ໃຊ້"
 ],
 "Removes selected non-running containers": [
  null,
  "ລຶບຄອນເທນເນີທີ່ເລືອກໄວ້ເຊິ່ງບໍ່ໄດ້ກຳລັງເຮັດວຽກຢູ່"
 ],
 "Pruning containers": [
  null,
  "ກຳລັງລ້າງຄອນເທນເນີ"
 ],
 "Container name is required.": [
  null,
  "ຕ້ອງໃສ່ຊື່ຄອນເທນເນີ."
 ],
 "Failed to rename container $0": [
  null,
  "ບໍ່ສາມາດປ່ຽນຊື່ຄອນເທນເນີ $0"
 ],
 "New container name": [
  null,
  "ຊື່ຄອນເທນເນີໃໝ່"
 ],
 "Rename container $0": [
  null,
  "ປ່ຽນຊື່ຄອນເທນເນີ $0"
 ],
 "Paused": [
  null,
  "ພັກຊົ່ວຄາວຢູ່"
 ],
 "Stopped": [
  null,
  "ຢຸດແລ້ວ"
 ],
 "Removing": [
  null,
  "ກຳລັງລຶບອອກ"
 ],
 "Configured": [
  null,
  "ຕັ້ງຄ່າແລ້ວ"
 ],
 "Error": [
  null,
  "ຂໍ້ຜິດພາດ"
 ],
 "$0 second": [
  null,
  "$0 ວິນາທີ"
 ],
 "Status": [
  null,
  "ສະຖານະ"
 ],
 "Failing streak": [
  null,
  "ການເຮັດວຽກລົ້ມເຫຼວຢ່າງຕໍ່ເນື່ອງ"
 ],
 "Failed to run health check on container $0": [
  null,
  "ບໍ່ສາມາດກວດສອບສຸຂະພາບໃນຄອນເທນເນີ $0"
 ],
 "Run health check": [
  null,
  "ສັ່ງກວດສອບສຸຂະພາບລະບົບ"
 ],
 "Last 5 runs": [
  null,
  "ການເຮັດວຽກ 5 ຄັ້ງຫຼ້າສຸດ"
 ],
 "Started at": [
  null,
  "ເລີ່ມຕົ້ນເມື່ອ"
 ],
 "Passed health run": [
  null,
  "ຜ່ານການກວດສອບສຸຂະພາບລະບົບ"
 ],
 "Failed health run": [
  null,
  "ການກວດສອບສຸຂະພາບລະບົບລົ້ມເຫຼວ"
 ],
 "Failed to remove container $0": [
  null,
  "ບໍ່ສາມາດລຶບຄອນເທນເນີ $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "ການລຶບຄອນເທນເນີຈະເຮັດໃຫ້ຂໍ້ມູນທັງໝົດໃນນັ້ນຖືກລຶບອອກ."
 ]
});
