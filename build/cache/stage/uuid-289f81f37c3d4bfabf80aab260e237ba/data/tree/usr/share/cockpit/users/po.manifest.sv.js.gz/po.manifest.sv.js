cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Accounts": [
  null,
  "Konton"
 ],
 "user": [
  null,
  "användare"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "lösenord"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "användarnamn"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "åtkomst"
 ],
 "roles": [
  null,
  "roller"
 ],
 "keys": [
  null,
  "nycklar"
 ],
 "Managing user accounts": [
  null,
  "Hantera användarkonton"
 ]
});
