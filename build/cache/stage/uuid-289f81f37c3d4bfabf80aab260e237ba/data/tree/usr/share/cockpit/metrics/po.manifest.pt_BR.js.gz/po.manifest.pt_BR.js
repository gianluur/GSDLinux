cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "user": [
  null,
  "usuário"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
