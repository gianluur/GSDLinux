cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Services"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "Logs": [
  null,
  "Logboeken"
 ],
 "time": [
  null,
  "tijd"
 ],
 "date": [
  null,
  "datum"
 ],
 "restart": [
  null,
  "herstarten"
 ],
 "shut": [
  null,
  "afsluiten"
 ],
 "domain": [
  null,
  "domein"
 ],
 "machine": [
  null,
  "machine"
 ],
 "operating system": [
  null,
  "besturingssysteem"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "asset-tag"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "vermogen"
 ],
 "version": [
  null,
  "versie"
 ],
 "host": [
  null,
  "host"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "matiging"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "geheugen"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dim"
 ],
 "serial": [
  null,
  "serieel"
 ],
 "graphs": [
  null,
  "grafieken"
 ],
 "metrics": [
  null,
  "metriek"
 ],
 "history": [
  null,
  "geschiedenis"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "schijven"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "performance"
 ],
 "Configuring system settings": [
  null,
  "Systeeminstellingen configureren"
 ],
 "service": [
  null,
  "service"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "doel"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "timer"
 ],
 "path": [
  null,
  "pad"
 ],
 "unit": [
  null,
  "unit"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "opstart"
 ],
 "mask": [
  null,
  "masker"
 ],
 "unmask": [
  null,
  "ontmaskeren"
 ],
 "enable": [
  null,
  "inschakelen"
 ],
 "disable": [
  null,
  "uitschakelen"
 ],
 "Managing services": [
  null,
  "Services beheren"
 ],
 "journal": [
  null,
  "logboek"
 ],
 "warning": [
  null,
  "waarschuwing"
 ],
 "error": [
  null,
  "fout"
 ],
 "debug": [
  null,
  "debug"
 ],
 "crash": [
  null,
  "crash"
 ],
 "coredump": [
  null,
  "core dump"
 ],
 "Reviewing logs": [
  null,
  "Logboeken bekijken"
 ],
 "console": [
  null,
  "console"
 ],
 "command": [
  null,
  "opdracht"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
