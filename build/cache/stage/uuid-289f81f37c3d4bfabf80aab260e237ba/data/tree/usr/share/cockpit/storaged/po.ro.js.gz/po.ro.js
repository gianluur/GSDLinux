cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Schimbarea cheilor este adesea rezultatul reinstalării sistemului de operare. Cu toate acestea, o schimbare neașteptată poate indica o încercare a unei terțe părți de a vă intercepta conexiunea."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pentru a vă asigura că conexiunea dumneavoastră nu este interceptată de o terță parte rău intenționată, vă rugăm să verificați amprenta cheii gazdei:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Conectează-te"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Type": [
  null,
  "Tip"
 ],
 "Copy": [
  null,
  "Copiază"
 ],
 "Copied": [
  null,
  "Copiat"
 ],
 "Unlock": [
  null,
  "Deblochează"
 ],
 "Add key": [
  null,
  "Adaugă cheie"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Edit": [
  null,
  "Editare"
 ],
 "Remove": [
  null,
  "Elimină"
 ],
 "Select": [
  null,
  "Selectează"
 ],
 "No results found": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nu este instalat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Pe $0 nu este instalată o versiune compatibilă a Cockpit."
 ],
 "Set": [
  null,
  "Stabilește"
 ],
 "Add": [
  null,
  "Adaugă"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "Cheia $0 a fost schimbată"
 ],
 "Trust and add host": [
  null,
  "Am încredere, adaugă gazda"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pentru a verifica o amprentă digitală, executați următoarea comandă pe $0, fie fizic, de la mașină, fie printr-o rețea de încredere:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Dacă amprenta digitală se potrivește, faceți clic pe „Am încredere, adaugă gazda”. În caz contrar, nu vă conectați și contactați administratorul."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică. Dacă îi ceri altcuiva să efectueze verificarea în locul tău, acea persoană îți poate trimite rezultatele prin orice metodă."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vă conectați la $0 pentru prima dată."
 ],
 "Verify fingerprint": [
  null,
  "Verifică amprenta digitală"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Executați această comandă într-o rețea de încredere sau direct pe mașina la distanță:"
 ],
 "The fingerprint should match:": [
  null,
  "Amprenta digitală trebuie să se potrivească:"
 ],
 "The password can not be empty": [
  null,
  "Parola nu poate fi goală"
 ],
 "The key password can not be empty": [
  null,
  "Parola cheii nu poate fi goală"
 ],
 "The key passwords do not match": [
  null,
  "Parolele cheii nu se potrivesc"
 ],
 "Log in to $0": [
  null,
  "Conectează-te la $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nu se poate efectua autentificarea la $0. Gazda nu acceptă autentificarea cu parolă și niciuna dintre cheile dvs. SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată de o parolă, iar serverul nu permite autentificarea cu o parolă. Vă rugăm să introduceți parola cheii la $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată. Vă puteți autentifica fie folosind parola de acces, fie introducând parola cheii la $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Creează o nouă cheie SSH și-o autorizează"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se va crea o nouă cheie SSH la $0 pentru $1 pe $2, iar aceasta va fi adăugată la fișierul $3 al lui $4 pe $5."
 ],
 "Key password": [
  null,
  "Parola cheii"
 ],
 "Confirm key password": [
  null,
  "Confirmă parola cheii"
 ],
 "Authorize SSH key": [
  null,
  "Autorizează cheia SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Cheia SSH $0 din $1 de pe $2 va fi adăugată la fișierul $3 din $4 de pe $5."
 ],
 "Authentication": [
  null,
  "Autentificare"
 ],
 "SSH key": [
  null,
  "Cheie SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Cheia SSH $0 va fi disponibilă pe durata restului sesiunii și va putea fi utilizată și pentru conectarea la alte gazde."
 ],
 "Permission denied": [
  null,
  "Permisiune refuzată"
 ],
 "Clear input value": [
  null,
  "Șterge valoarea introdusă"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de dată incorect și format de oră incorect"
 ],
 "Invalid time format": [
  null,
  "Format de oră nevalid"
 ],
 "Invalid date format": [
  null,
  "Format de dată incorect"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nu se poate planifica un eveniment în trecut"
 ],
 "No delay": [
  null,
  "Fără întârziere"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minute"
 ],
 "20 minutes": [
  null,
  "20 de minute"
 ],
 "40 minutes": [
  null,
  "40 de minute"
 ],
 "60 minutes": [
  null,
  "60 de minute"
 ],
 "Specific time": [
  null,
  "Momentul specificat"
 ],
 "Shut down": [
  null,
  "Oprire"
 ],
 "Reboot": [
  null,
  "Repornire"
 ],
 "Message to logged in users": [
  null,
  "Mesaj pentru utilizatorii autentificați"
 ],
 "Delay": [
  null,
  "Întârziere"
 ],
 "Pick date": [
  null,
  "Alegeți data"
 ],
 "Toggle date picker": [
  null,
  "Activează/dezactivează selectorul de dată"
 ],
 "Synchronized": [
  null,
  "Sincronizat"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizat cu $0"
 ],
 "Synchronizing": [
  null,
  "Se sincronizează"
 ],
 "Trying to synchronize with $0": [
  null,
  "Se încearcă sincronizarea cu $0"
 ],
 "Not synchronized": [
  null,
  "Nu este sincronizat"
 ],
 "Log messages": [
  null,
  "Mesaje de jurnal"
 ],
 "NTP server": [
  null,
  "server NTP"
 ],
 "Manually": [
  null,
  "În mod manual"
 ],
 "Automatically using NTP": [
  null,
  "Utilizând NTP în mod automat"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizând în mod automat servere NTP suplimentare"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizând în mod automat servere NTP specifice"
 ],
 "Time zone": [
  null,
  "Fusul orar"
 ],
 "Set time": [
  null,
  "Ajustează ora"
 ],
 "Invalid timezone": [
  null,
  "Fus orar nevalid"
 ],
 "Need at least one NTP server": [
  null,
  "Este necesar cel puțin un server NTP"
 ],
 "Change system time": [
  null,
  "Schimbă ora sistemului"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Path to file": [
  null,
  "Ruta către fișier"
 ],
 "No such file or directory": [
  null,
  "Nu există un astfel de fișier sau director"
 ],
 "Create $0": [
  null,
  "Creează $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Află mai multe"
 ],
 "You now have administrative access.": [
  null,
  "Acum aveți acces de administrator."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nu sunt disponibile metode pentru a obține acces administrativ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentificați-vă pentru a obține acces administrativ"
 ],
 "Switch to administrative access": [
  null,
  "Treceți la acces administrativ"
 ],
 "Authenticate": [
  null,
  "Autentifica"
 ],
 "Administrative access": [
  null,
  "Acces administrativ"
 ],
 "Problem becoming administrator": [
  null,
  "Probleme în devenirea administrator"
 ],
 "Method": [
  null,
  "Metodă"
 ],
 "Limit access": [
  null,
  "Limitează accesul"
 ],
 "Switch to limited access": [
  null,
  "Treceți la acces limitat"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Modul de acces limitat restricționează privilegiile administrative. Anumite secțiuni ale consolei web vor avea funcționalități reduse."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Navigatorul dvs. va reține nivelul dvs. de acces între sesiuni."
 ],
 "Limited access": [
  null,
  "Acces limitat"
 ],
 "Turn on administrative access": [
  null,
  "Activează accesul de administrator"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ani",
  "$0 de ani"
 ],
 "$0 month": [
  null,
  "$0 lună",
  "$0 luni",
  "$0 de luni"
 ],
 "$0 week": [
  null,
  "$0 săptămână",
  "$0 săptămâni",
  "$0 de săptămâni"
 ],
 "$0 day": [
  null,
  "$0 zi",
  "$0 zile",
  "$0 de zile"
 ],
 "$0 hour": [
  null,
  "$0 oră",
  "$0 ore",
  "$0 de ore"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minute",
  "$0 de minute"
 ],
 "Go to now": [
  null,
  "Mergi la acum"
 ],
 "1 hour": [
  null,
  "1 oră"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 zi"
 ],
 "1 week": [
  null,
  "1 săptămână"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nu s-a putut activa $0 în firewalld"
 ],
 "Visit firewall": [
  null,
  "Accedeți la paravanul de protecție"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adaugă $0"
 ],
 "less than a minute ago": [
  null,
  "acum mai puțin de un minut"
 ],
 "in less than a minute": [
  null,
  "în mai puțin de un minut"
 ],
 "Password is too weak": [
  null,
  "Parola este prea slabă (este ușor de ghicit)"
 ],
 "Excellent password": [
  null,
  "Parolă excelentă"
 ],
 "Password is not acceptable": [
  null,
  "Parola nu este acceptabilă"
 ],
 "Strong password": [
  null,
  "Parolă puternică"
 ],
 "Acceptable password": [
  null,
  "Parolă acceptabilă"
 ],
 "Weak password": [
  null,
  "Parolă slabă (ușor de ghicit)"
 ],
 "Show password": [
  null,
  "Afișează parola"
 ],
 "Hide password": [
  null,
  "Ascunde parola"
 ],
 "password quality": [
  null,
  "calitatea parolei"
 ],
 "Show confirmation password": [
  null,
  "Afișează parola de confirmare"
 ],
 "Hide confirmation password": [
  null,
  "Ascunde parola de confirmare"
 ],
 "Additional packages:": [
  null,
  "Pachete suplimentare:"
 ],
 "Removals:": [
  null,
  "Eliminare:"
 ],
 "Total size: $0": [
  null,
  "Dimensiunea totală: $0"
 ],
 "Install software": [
  null,
  "Instalează software-ul"
 ],
 "$0 will be installed.": [
  null,
  "$0 va fi instalat."
 ],
 "Install": [
  null,
  "Instalează"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Se așteaptă finalizarea altor operații de gestionare a software-ului"
 ],
 "Checking installed software": [
  null,
  "Se verifică software-ul instalat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nu este disponibil din niciun depozit."
 ],
 "Downloading $0": [
  null,
  "Se descarcă $0"
 ],
 "Removing $0": [
  null,
  "Se elimină $0"
 ],
 "Installing $0": [
  null,
  "Se instalează $0"
 ],
 "Unknown host: $0": [
  null,
  "Gazdă necunoscută: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nu se poate efectua autentificarea la $0 folosind autentificarea cu cheie SSH. Vă rugăm să introduceți parola."
 ],
 "SSH key login": [
  null,
  "Autentificare cu cheie SSH"
 ],
 "[no data]": [
  null,
  "[nu există date]"
 ],
 "[binary data]": [
  null,
  "[date binare]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit s-a prăbușit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a raportat codul de eroare $0"
 ],
 "show less": [
  null,
  "afișează mai puțin"
 ],
 "show more": [
  null,
  "afișează mai mult"
 ],
 "Row expansion": [
  null,
  "Extinderea rândului"
 ],
 "Row select": [
  null,
  "Selectare rând"
 ],
 "Ctrl+Insert": [
  null,
  "«Ctrl+Insert»"
 ],
 "Paste": [
  null,
  "Lipește"
 ],
 "Shift+Insert": [
  null,
  "«Shift+Insert»"
 ],
 "Paste error": [
  null,
  "Eroare la lipire"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Navigatorul dvs. nu permite lipirea din meniul contextual. Puteți folosi combinația de taste «Shift+Insert»."
 ],
 "Error during initialization": [
  null,
  "Eroare în timpul inițializării"
 ],
 "Failed": [
  null,
  "Nu a funcționat"
 ],
 "Home": [
  null,
  "Acasă"
 ],
 "Downloads": [
  null,
  "Descărcări"
 ],
 "Not a directory": [
  null,
  "Nu este un director"
 ],
 "All files": [
  null,
  "Toate fișierele"
 ],
 "Recent": [
  null,
  "Recente"
 ],
 "No recent directories": [
  null,
  "Nu există directoare recente"
 ],
 "No recent files": [
  null,
  "Nu există fișiere recente"
 ],
 "Type to filter": [
  null,
  "Tastați pentru a filtra"
 ],
 "File chooser actions": [
  null,
  "Acțiuni ale selectorului de fișiere"
 ],
 "Open in file browser": [
  null,
  "Deschide în exploratorul de fișiere"
 ],
 "Hide hidden files": [
  null,
  "Ascunde elementele ascunse"
 ],
 "Show hidden files": [
  null,
  "Afișează fișierele ascunse"
 ],
 "Filesystem": [
  null,
  "Sistem de fișiere"
 ],
 "Clear filters": [
  null,
  "Șterge filtrele"
 ],
 "Directory is empty": [
  null,
  "Directorul este gol"
 ],
 "Directory has no sub-directories": [
  null,
  "Directorul nu conține subdirectoare"
 ],
 "This directory contains only hidden files": [
  null,
  "Acest director conține doar fișiere ascunse"
 ],
 "No matching results": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Folder": [
  null,
  "Dosar"
 ],
 "File": [
  null,
  "Fișier"
 ],
 "Copy to clipboard": [
  null,
  "Copiază în clipboard"
 ],
 "Automation script": [
  null,
  "Script de automatizare"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Creează un fișier de sarcini nou cu acest conținut."
 ],
 "Ansible roles documentation": [
  null,
  "Documentația privind rolurile Ansible"
 ],
 "Shell script": [
  null,
  "script Shell"
 ],
 "No system modifications": [
  null,
  "Nicio modificare a sistemului"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Utilizatorul conectat nu are permisiunea de a vizualiza modificările aduse sistemului"
 ],
 "Loading system modifications...": [
  null,
  "Se încarcă modificările aduse sistemului..."
 ],
 "View automation script": [
  null,
  "Vizualizează scriptul de automatizare"
 ],
 "Occurrences": [
  null,
  "Apariții"
 ],
 "View all logs": [
  null,
  "Vizualizează toate jurnalele"
 ],
 "Other": [
  null,
  "Alta"
 ],
 "Unknown": [
  null,
  "Necunoscută"
 ],
 "Desktop": [
  null,
  "Calculator de birou"
 ],
 "Low profile desktop": [
  null,
  "Calculator de birou cu profil redus"
 ],
 "Pizza box": [
  null,
  "„Pizza box”"
 ],
 "Mini tower": [
  null,
  "Mini turn"
 ],
 "Tower": [
  null,
  "Turn"
 ],
 "Portable": [
  null,
  "Portabil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispozitiv de buzunar"
 ],
 "Docking station": [
  null,
  "Stație de andocare"
 ],
 "All-in-one": [
  null,
  "Toate într-unul"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Calculator compact"
 ],
 "Lunch box": [
  null,
  "„Lunch box”"
 ],
 "Main server chassis": [
  null,
  "Șasiul serverului principal"
 ],
 "Expansion chassis": [
  null,
  "Șasiu de expansiune"
 ],
 "Sub-Chassis": [
  null,
  "Sub-șasiu"
 ],
 "Bus expansion chassis": [
  null,
  "Șasiu de expansiune de magistrală"
 ],
 "Peripheral chassis": [
  null,
  "Șasiu periferic"
 ],
 "RAID chassis": [
  null,
  "Șasiu RAID"
 ],
 "Rack mount chassis": [
  null,
  "Șasiu de montare în rack"
 ],
 "Sealed-case PC": [
  null,
  "PC cu carcasă sigilată"
 ],
 "Multi-system chassis": [
  null,
  "Șasiu multi-sistem"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avansat"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Servitor blade (lamă)"
 ],
 "Tablet": [
  null,
  "Tabletă"
 ],
 "Convertible": [
  null,
  "Convertibil"
 ],
 "Detachable": [
  null,
  "Detașabil (amovibil)"
 ],
 "IoT gateway": [
  null,
  "Poartă de acces IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrat"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 Gio"
 ],
 "Single rank": [
  null,
  "Rang unic"
 ],
 "Dual rank": [
  null,
  "Rang dual"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Prezent"
 ],
 "Old password not accepted": [
  null,
  "Vechea parolă nu este acceptată"
 ],
 "Failed to change password": [
  null,
  "Schimbarea parolei a eșuat"
 ],
 "New password was not accepted": [
  null,
  "Noua parolă nu a fost acceptată"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "A expirat timpul de așteptare pentru generarea cheii prin ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Nu este o cheie privată validă"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A expirat timpul de așteptare pentru adăugarea prin ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisiuni de fișier nevalide"
 ],
 "Password not accepted": [
  null,
  "Parola nu este acceptată"
 ],
 "Select an option": [
  null,
  "Selectați o opțiune"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 a fost omorât cu semnalul $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 a ieșit cu codul $1"
 ],
 "$0 failed": [
  null,
  "$0 a eșuat"
 ],
 "Your session has been terminated.": [
  null,
  "Sesiunea dumneavoastră a fost încheiată."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesiunea dumneavoastră a expirat. Vă rugăm să vă autentificați din nou."
 ],
 "Not permitted to perform this action.": [
  null,
  "Nu este permisă efectuarea acestei acțiuni."
 ],
 "Login failed": [
  null,
  "Autentificare eșuată"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serverul a refuzat autentificarea prin orice metodă acceptată."
 ],
 "Untrusted host": [
  null,
  "Gazdă nesigură (nu este de încredere)"
 ],
 "Host key is incorrect": [
  null,
  "Cheia gazdei este incorectă"
 ],
 "Internal error": [
  null,
  "Eroare internă"
 ],
 "Connection has timed out.": [
  null,
  "Timpul de conectare a expirat."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nu este instalat în sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Nu se pot transmite datele de autentificare"
 ],
 "Server has closed the connection.": [
  null,
  "Serverul a închis conexiunea."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nu este compatibil cu software-ul din sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nu a putut stabili legătura cu gazda specificată."
 ],
 "Too much data": [
  null,
  "Prea multe date"
 ],
 "Description": [
  null,
  "Descriere"
 ],
 "Save": [
  null,
  "Salvează"
 ],
 "View logs": [
  null,
  "Vizualizează jurnalele"
 ],
 "Dismiss": [
  null,
  "Revocare"
 ],
 "edit": [
  null,
  "editează"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Utilizare"
 ],
 "none": [
  null,
  "niciunul"
 ],
 "Not found": [
  null,
  "Nu s-a găsit"
 ],
 "Error": [
  null,
  "Eroare"
 ],
 "Running": [
  null,
  "În execuție"
 ],
 "Not running": [
  null,
  "Nu rulează"
 ],
 "Loading...": [
  null,
  "Se încarcă…"
 ],
 "User": [
  null,
  "Utilizator"
 ],
 "Vendor": [
  null,
  "Fabricant"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Dimensiune"
 ],
 "State": [
  null,
  "Stare"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Start": [
  null,
  "Pornire"
 ],
 "Delete": [
  null,
  "Șterge"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmă ștergerea lui $0"
 ],
 "Username": [
  null,
  "Numele utilizatorului"
 ],
 "Actions": [
  null,
  "Acțiuni"
 ],
 "Create": [
  null,
  "Creează"
 ],
 "Rename": [
  null,
  "Redenumește"
 ],
 "Started": [
  null,
  "Pornit"
 ],
 "Delete group": [
  null,
  "Șterge grupul"
 ],
 "Options": [
  null,
  "Opțiuni"
 ],
 "Lock": [
  null,
  "Blocare"
 ],
 "Use $0": [
  null,
  "Utilizează $0"
 ],
 "Service": [
  null,
  "Serviciu"
 ],
 "Disconnect": [
  null,
  "Deconectare"
 ],
 "Address": [
  null,
  "Adresă"
 ],
 "$0 disk is missing": [
  null,
  "$0 disc lipsește",
  "$0 discuri lipsesc",
  "$0 de discuri lipsesc"
 ],
 "Location": [
  null,
  "Locație"
 ],
 "Compression": [
  null,
  "Comprimare"
 ],
 "Storage logs": [
  null,
  "Jurnale de stocare"
 ],
 "Name cannot be empty.": [
  null,
  "Numele nu poate să fie gol."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Numele nu poate avea mai mult de 127 de caractere."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Numele nu poate conține caracterul „$0”."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Numele nu poate conține spații albe."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Numele nu poate avea mai mult de $0 caractere"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Numele nu poate avea mai mult de $0 octeți"
 ],
 "$name (from $host)": [
  null,
  "$name (din $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Grup pentru volume logice cu alocare dinamică (thin)"
 ],
 "Thin logical volume": [
  null,
  "Volum logic cu alocare dinamică"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volum logic (instantanee)"
 ],
 "Logical volume": [
  null,
  "Volum logic"
 ],
 "MDRAID device $0": [
  null,
  "Dispozitiv MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupul de volume LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Dispozitivul VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volum logic criptat de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partiție criptată de $0"
 ],
 "Logical volume of $0": [
  null,
  "Volum logic de $0"
 ],
 "Partition of $0": [
  null,
  "Partiție de $0"
 ],
 "Encrypted $0": [
  null,
  "Criptat $0"
 ],
 "unpartitioned space on $0": [
  null,
  "spațiu nepartiționat pe $0"
 ],
 "unmount": [
  null,
  "demontare"
 ],
 "mount": [
  null,
  "montare"
 ],
 "remove from btrfs volume": [
  null,
  "eliminare din volumul btrfs"
 ],
 "stop": [
  null,
  "oprire"
 ],
 "remove from MDRAID": [
  null,
  "eliminare din MDRAID"
 ],
 "remove from LVM2": [
  null,
  "eliminare din LVM2"
 ],
 "btrfs device": [
  null,
  "dispozitiv btrfs"
 ],
 "btrfs volume": [
  null,
  "volum btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Numele nu poate avea mai mult de 255 de caractere."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Numele nu poate conține caracterul „/”."
 ],
 "Create and mount": [
  null,
  "Creează și montează"
 ],
 "Create only": [
  null,
  "Creează doar"
 ],
 "Create subvolume": [
  null,
  "Creează un sub-volum"
 ],
 "Mount Point": [
  null,
  "Punct de montare"
 ],
 "delete": [
  null,
  "șterge"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Doriți să ștergeți definitiv sub-volumul $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Ștergerea va elimina toate datele de pe acest sub-volum și de pe toate sub-volumele-copil ale acestuia."
 ],
 "Edit mount point": [
  null,
  "Editează punctul de montare"
 ],
 "Unmount": [
  null,
  "Demontare"
 ],
 "Mount": [
  null,
  "Montează"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Cel puțin un sub-volum trebuie să fie montat"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Ultimul subvolum montat nu poate fi șters"
 ],
 "btrfs subvolume": [
  null,
  "sub-volum btrfs"
 ],
 "Snapshot origin": [
  null,
  "Originea instantaneei"
 ],
 "Mount point": [
  null,
  "Punct de montare"
 ],
 "No subvolumes": [
  null,
  "Nu există sub-volume"
 ],
 "btrfs subvolumes": [
  null,
  "sub-volume btrfs"
 ],
 "Snapshots": [
  null,
  "Imagini instantanee"
 ],
 "No snapshots found": [
  null,
  "Nu s-au găsit instantanee"
 ],
 "snapshot": [
  null,
  "imagine instantanee"
 ],
 "$0 is in use": [
  null,
  "$0 este în uz"
 ],
 "Permanently delete $0?": [
  null,
  "Doriți să ștergeți definitiv $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Ștergerea va elimina toate datele de pe un volum btrfs."
 ],
 "Delete filesystem": [
  null,
  "Șterge sistemul de fișiere"
 ],
 "Change label": [
  null,
  "Modifică eticheta"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Sistemul de fișiere este montat numai-pentru-citire"
 ],
 "Label": [
  null,
  "Etichetă"
 ],
 "Capacity": [
  null,
  "Capacitate"
 ],
 "btrfs devices": [
  null,
  "dispozitive btrfs"
 ],
 "No devices found": [
  null,
  "Nu s-au găsit dispozitive"
 ],
 "btrfs filesystem": [
  null,
  "sistem de fișiere btrfs"
 ],
 "Successful": [
  null,
  "Operație efectuată cu succes"
 ],
 "Aborted": [
  null,
  "Întrerupt"
 ],
 "In progress": [
  null,
  "În curs de desfășurare"
 ],
 "Interrupted": [
  null,
  "Întrerupt"
 ],
 "Did not complete": [
  null,
  "Nu a fost completat"
 ],
 "Failed (Unknown)": [
  null,
  "Nu a funcționat (problemă necunoscută)"
 ],
 "Failed (Electrical)": [
  null,
  "Nu a funcționat (probleme electrice)"
 ],
 "Failed (Servo)": [
  null,
  "Nu a funcționat (probleme la servomotor)"
 ],
 "Failed (Read)": [
  null,
  "Nu a funcționat (probleme la citire)"
 ],
 "Failed (Damaged)": [
  null,
  "Nu a funcționat (deteriorat)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Întrerupt de o reinițiere la nivel de controlor"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Întrerupt din cauza eliminării unui spațiu de nume din inventarul spațiilor de nume"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Întrerupt din cauza procesării unei comenzi de formatare NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "A apărut o eroare fatală în timpul operației de autotestare"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Completat cu un segment care a eșuat și nu se cunoaște care este segmentul care a eșuat"
 ],
 "Completed with one or more failed segments": [
  null,
  "Completat cu unul sau mai multe segmente eșuate"
 ],
 "Aborted for unknown reason": [
  null,
  "Întrerupt din motive necunoscute"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Întrerupt din cauza unei operații de igienizare"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Capacitatea de rezervă este sub pragul stabilit"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatura depășește limitele recomandate"
 ],
 "Degraded": [
  null,
  "Degradat"
 ],
 "All media is in read-only mode": [
  null,
  "Toate suporturile media sunt în modul numai-citire"
 ],
 "Volatile memory backup failed": [
  null,
  "Copierea de rezervă a memoriei volatile a eșuat"
 ],
 "Persistent memory has become read-only": [
  null,
  "Memoria persistentă a devenit de numai-pentru-citire"
 ],
 "Run short test": [
  null,
  "Rulează testul scurt"
 ],
 "Run extended test": [
  null,
  "Rulează testul extins"
 ],
 "Abort test": [
  null,
  "Întrerupe testul"
 ],
 "Disk is failing": [
  null,
  "Discul prezintă probleme"
 ],
 "Disk is OK": [
  null,
  "Discul este în regulă"
 ],
 "Assessment": [
  null,
  "Evaluare"
 ],
 "Power on hours": [
  null,
  "Ore de funcționare"
 ],
 "$0 hours": [
  null,
  "$0 ore"
 ],
 "Self-test status": [
  null,
  "Starea autotestării"
 ],
 "Number of bad sectors": [
  null,
  "Numărul de sectoare defectuoase"
 ],
 "Attributes failing": [
  null,
  "Atributele nu sunt valabile"
 ],
 "Media drive": [
  null,
  "Unitate suport media"
 ],
 "Solid State Drive": [
  null,
  "Unitate de stare solidă (SSD)"
 ],
 "Hard Disk Drive": [
  null,
  "Unitate de disc dur"
 ],
 "iSCSI Drive": [
  null,
  "Unitate iSCSI"
 ],
 "Drive": [
  null,
  "Unitate"
 ],
 "Device health (SMART)": [
  null,
  "Starea de sănătate a dispozitivului (SMART)"
 ],
 "Firmware version": [
  null,
  "Versiunea firmware"
 ],
 "Serial number": [
  null,
  "Număr de serie"
 ],
 "World wide name": [
  null,
  "World wide name (WWN)"
 ],
 "No media inserted": [
  null,
  "Nu a fost introdus niciun suport media"
 ],
 "Device file": [
  null,
  "Fișier de dispozitiv"
 ],
 "Multipathed devices": [
  null,
  "Dispozitive cu rute multiple"
 ],
 "Free space": [
  null,
  "Spațiu liber"
 ],
 "Create partition": [
  null,
  "Creează o partiție"
 ],
 "Extended partition": [
  null,
  "Partiție extinsă"
 ],
 "$0 partitions": [
  null,
  "$0 partiții"
 ],
 "Partitions": [
  null,
  "Partiții"
 ],
 "No partitions found": [
  null,
  "Nu s-au găsit partiții"
 ],
 "Unexpected partitions": [
  null,
  "Partiții neașteptate"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Partițiile nu sunt acceptate pe acest dispozitiv de blocuri. Dacă este utilizat ca disc pentru o mașină virtuală, partițiile trebuie gestionate de sistemul de operare din interiorul mașinii virtuale."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Ștergerea unei partiții va șterge toate datele din aceasta."
 ],
 "No free space after this partition": [
  null,
  "Nu există spațiu liber după această partiție"
 ],
 "EFI system partition": [
  null,
  "Partiția de sistem EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partiția de pornire a BIOS"
 ],
 "Partition": [
  null,
  "Partiția"
 ],
 "Shrink": [
  null,
  "Reduce"
 ],
 "Grow": [
  null,
  "Augmenta"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partiția de pornire PReP a PowerPC"
 ],
 "Linux swap space": [
  null,
  "Spațiu de interschimb (swap) Linux"
 ],
 "Linux filesystem data": [
  null,
  "Date ale sistemului de fișiere Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partiția managerului de volume logice"
 ],
 "Custom": [
  null,
  "Personalizată"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tipul trebuie să conțină exact două caractere hexazecimale (0–9, A–F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tipul poate conține doar caracterele de la 0 la 9, de la A la F și „-”."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tipul trebuie să aibă forma NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Stabilește tipul partiției la $0"
 ],
 "Custom type": [
  null,
  "Tip personalizat"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Schimbarea tipurilor de partiții poate împiedica pornirea sistemului."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Această partiție nu este utilizată în totalitate de conținutul său."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Dimensiunea partiției este de $0. Dimensiunea conținutului este de $1."
 ],
 "Shrink partition": [
  null,
  "Reduce partiția"
 ],
 "Grow content": [
  null,
  "Augmenta conținutul"
 ],
 "initialize": [
  null,
  "inițializare"
 ],
 "Initialize disk $0": [
  null,
  "Inițializează discul $0"
 ],
 "Partitioning": [
  null,
  "Partiționare"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibil cu toate sistemele și dispozitivele (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatibil cu sistemele moderne și cu discurile dure > 2 To (GPT)"
 ],
 "No partitioning": [
  null,
  "Fără partiționare"
 ],
 "Overwrite": [
  null,
  "Suprascrie"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Suprascrie datele existente cu zerouri (mai lent)"
 ],
 "Initialize": [
  null,
  "Inițializare"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inițializarea șterge toate datele de pe un disc."
 ],
 "Device is read-only": [
  null,
  "Dispozitivul este numai-pentru-citire"
 ],
 "Create partition table": [
  null,
  "Creează tabelul de partiții"
 ],
 "Size must be a number": [
  null,
  "Dimensiunea trebuie să fie un număr"
 ],
 "Size cannot be zero": [
  null,
  "Dimensiunea nu poate fi zero"
 ],
 "Size cannot be negative": [
  null,
  "Dimensiunea nu poate fi negativă"
 ],
 "Size is too large": [
  null,
  "Dimensiunea este prea mare"
 ],
 "Size must be at least $0": [
  null,
  "Dimensiunea trebuie să fie de cel puțin $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volum fizic al grupului de volume LVM2"
 ],
 "member of MDRAID device": [
  null,
  "membru al dispozitivului MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "dispozitiv de susținere pentru dispozitivul VDO"
 ],
 "member of Stratis pool": [
  null,
  "membru al grupului Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Sistem de fișiere în afara țintei"
 ],
 "device of btrfs volume": [
  null,
  "dispozitiv de volum btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Acest dispozitiv este în prezent în uz."
 ],
 "Device": [
  null,
  "Dispozitiv"
 ],
 "Use": [
  null,
  "Utilizare"
 ],
 "Services using the location": [
  null,
  "Servicii care utilizează locația"
 ],
 "Processes using the location": [
  null,
  "Procese care utilizează locația"
 ],
 "Currently in use": [
  null,
  "În prezent în uz"
 ],
 "(Not part of target)": [
  null,
  "(Nu face parte din țintă)"
 ],
 "These changes will be made:": [
  null,
  "Se vor efectua următoarele modificări:"
 ],
 "Action": [
  null,
  "Acțiune"
 ],
 "Important data might be deleted:": [
  null,
  "Date importante ar putea fi șterse:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Procesele și serviciile asociate vor fi oprite forțat."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Procesele asociate vor fi oprite forțat."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Serviciile asociate vor fi oprite în mod forțat."
 ],
 "Checking filesystem usage": [
  null,
  "Se verifică utilizarea sistemului de fișiere"
 ],
 "$0 used, $1 total": [
  null,
  "$0 utilizați, $1 în total"
 ],
 "Device contains unrecognized data": [
  null,
  "Dispozitivul conține date necunoscute"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Dispozitivul criptat și blocat ar putea conține date"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confirm că doresc să șterg definitiv aceste date"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Punctul de montare $0 este utilizat de următoarele procese:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Comandă"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Punctul de montare $0 este utilizat de următoarele servicii:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Procesele și serviciile listate vor fi oprite forțat."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Procesele listate vor fi oprite forțat."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Serviciile listate vor fi oprite în mod forțat."
 ],
 "Sorry": [
  null,
  "Scuze"
 ],
 "Usage of $0": [
  null,
  "Utilizarea lui $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Grupul VDO LVM2"
 ],
 "Data used": [
  null,
  "Date utilizate"
 ],
 "Metadata used": [
  null,
  "Metadatele utilizate"
 ],
 "Use compression": [
  null,
  "Utilizează comprimarea"
 ],
 "Deduplication": [
  null,
  "Deduplicare"
 ],
 "Use deduplication": [
  null,
  "Utilizează deduplicarea"
 ],
 "Rename volume group": [
  null,
  "Redenumește grupul de volume"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Acest grup de volume conține sistemul de fișiere rădăcină. Schimbarea numelui acestuia ar putea necesita modificări suplimentare ale configurației încărcătorului de pornire sau ale liniei de comandă a nucleului."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Ștergerea va elimina toate datele de pe un grup de volume."
 ],
 "Create snapshot": [
  null,
  "Creează o imagine instantanee"
 ],
 "Add disks": [
  null,
  "Adaugă discuri"
 ],
 "Disks": [
  null,
  "Discuri"
 ],
 "No disks are available.": [
  null,
  "Nu există discuri disponibile."
 ],
 "At least one disk is needed.": [
  null,
  "Este nevoie de cel puțin un disc."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Grupului de volume îi lipsesc volume fizice"
 ],
 "No free space": [
  null,
  "Nu există spațiu liber"
 ],
 "LVM2 volume group": [
  null,
  "Grup de volume LVM2"
 ],
 "Add physical volume": [
  null,
  "Adaugă un volum fizic"
 ],
 "LVM2 logical volumes": [
  null,
  "Volume logice LVM2"
 ],
 "Create new logical volume": [
  null,
  "Creează un volum logic nou"
 ],
 "No logical volumes": [
  null,
  "Nu există volume logice"
 ],
 "Remove missing physical volumes?": [
  null,
  "Eliminați volumele fizice lipsă?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Acestui grup de volume îi lipsesc unele volume fizice."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Un grup de volume din care lipsesc volume fizice nu poate fi redenumit."
 ],
 "Physical volumes": [
  null,
  "Volume fizice"
 ],
 "No physical volumes found": [
  null,
  "Nu s-au găsit volume fizice"
 ],
 "LVM2 physical volumes": [
  null,
  "Volume fizice LVM2"
 ],
 "Rename logical volume": [
  null,
  "Redenumește volumul logic"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Doriți să ștergeți volumul logic $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Ștergerea unui volum logic va șterge toate datele din acesta."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Nu s-a putut repara volumul logic $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Nu există suficient spațiu disponibil care să poată fi utilizat pentru o reparație. Este nevoie de cel puțin $0 pe volumele fizice care nu sunt deja utilizate pentru acest volum logic."
 ],
 "An additional $0 must be selected": [
  null,
  "Trebuie selectat un $0 suplimentar"
 ],
 "Repair logical volume $0": [
  null,
  "Repară volumul logic $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Selectați volumele fizice care trebuie utilizate pentru repararea volumului logic. Sunt necesare cel puțin $0."
 ],
 "Physical Volumes": [
  null,
  "Volume fizice"
 ],
 "Repair": [
  null,
  "Reparare"
 ],
 "deactivate": [
  null,
  "dezactivare"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Doriți să dezactivați volumul logic $0/$1?"
 ],
 "Deactivate": [
  null,
  "Dezactivează"
 ],
 "Not enough space to grow": [
  null,
  "Nu există suficient spațiu pentru augmentare"
 ],
 "LVM2 logical volume": [
  null,
  "Volum logic LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "În benzi (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Oglindit (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "În benzi și oglindit (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Paritate dedicată (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Paritate distribuită (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Paritate distribuită dublă (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Acest volum logic nu este complet utilizat de conținutul său."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Dimensiunea volumului este de $0. Dimensiunea conținutului este de $1."
 ],
 "Shrink volume": [
  null,
  "Reduce volumul"
 ],
 "Layout": [
  null,
  "Aspect"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Acest volum logic a pierdut o parte din volumele sale fizice și nu mai poate fi utilizat. Trebuie să îl ștergeți și să creați unul nou în locul lui."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Acest volum logic a pierdut o parte din volumele sale fizice, dar nu a pierdut încă nicio dată. Ar trebui să îl reparați pentru a-i restaura redundanța inițială."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Acest volum logic a pierdut o parte din volumele sale fizice, dar este posibil să nu fi pierdut încă niciun fel de date. Este posibil să îl puteți repara."
 ],
 "Stripes": [
  null,
  "Benzi"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizat"
 ],
 "Create volume group": [
  null,
  "Creează un grup de volume"
 ],
 "LVM2 physical volume": [
  null,
  "Volum fizic LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Ultimul nu poate fi eliminat"
 ],
 "Not enough free space": [
  null,
  "Nu există suficient spațiu liber"
 ],
 "Volume group": [
  null,
  "Grup de volume"
 ],
 "Create thin volume": [
  null,
  "Creează un volum dinamic"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volume logice LVM2 cu alocare dinamică"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Creează un volum logic alocat dinamic nou"
 ],
 "Not enough space": [
  null,
  "Nu există suficient spațiu"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Grup pentru volume logice LVM2 cu alocare dinamică"
 ],
 "Inactive logical volume": [
  null,
  "Volum logic inactiv"
 ],
 "Activate": [
  null,
  "Activare"
 ],
 "Unsupported logical volume": [
  null,
  "Volum logic neacceptat"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "EROARE INTERNĂ - Acest volum logic este marcat ca activ și ar trebui să aibă un dispozitiv de blocuri asociat. Cu toate acestea, nu s-a găsit niciun astfel de dispozitiv de blocuri."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Instalarea lui $0 ar elimina $1."
 ],
 "Installing packages": [
  null,
  "Se instalează pachetele"
 ],
 "Block device for filesystems": [
  null,
  "Dispozitiv de blocuri pentru sisteme de fișiere"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Grup pentru volume cu alocare dinamică"
 ],
 "Linear": [
  null,
  "Liniar"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volumul sistemului de fișiere VDO (comprimare/deduplicare)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Datele vor fi stocate pe volumele fizice selectate, fără nicio redundanță suplimentară sau îmbunătățiri ale performanței."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Datele vor fi stocate pe volumele fizice selectate în mod alternativ, pentru a îmbunătăți performanța. Trebuie selectate cel puțin două volume."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Datele vor fi stocate în două sau mai multe copii pe volumele fizice selectate, pentru a spori fiabilitatea. Trebuie selectate cel puțin două volume."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Datele vor fi stocate în două copii și, de asemenea, în mod alternativ pe volumele fizice selectate, pentru a îmbunătăți atât fiabilitatea, cât și performanța. Trebuie selectate cel puțin patru volume."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Datele vor fi stocate pe volumele fizice selectate, astfel încât pierderea unuia dintre ele să nu afecteze datele. Trebuie selectate cel puțin trei volume."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Datele vor fi stocate pe volumele fizice selectate, astfel încât pierderea unuia dintre ele să nu afecteze datele. De asemenea, datele sunt stocate alternativ pentru a îmbunătăți performanța. Trebuie selectate cel puțin trei volume."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Datele vor fi stocate pe volumele fizice selectate, astfel încât să se poată pierde până la două dintre ele în același timp fără a afecta datele. De asemenea, datele sunt stocate în mod alternativ pentru a îmbunătăți performanța. Trebuie selectate cel puțin cinci volume."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Toate cele $0 volume fizice selectate sunt necesare pentru configurația aleasă."
 ],
 "Create logical volume": [
  null,
  "Creează un volum logic"
 ],
 "Purpose": [
  null,
  "Scopul"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Pachetul $0 trebuie instalat pentru a crea dispozitive VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 necesită un număr par de volume fizice"
 ],
 "Logical size": [
  null,
  "Dimensiunea logică"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Economisiți spațiu prin comprimarea blocurilor individuale cu LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Economisiți spațiu stocând blocurile de date identice o singură dată"
 ],
 "Creating VDO device": [
  null,
  "Se creează dispozitivul VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Această montare NFS este în uz și doar opțiunile sale pot fi modificate."
 ],
 "NFS mount": [
  null,
  "Montare NFS"
 ],
 "New NFS mount": [
  null,
  "Muntare NFS nouă"
 ],
 "Server address": [
  null,
  "Adresa serverului"
 ],
 "Server cannot be empty.": [
  null,
  "Câmpul serverului nu poate fi gol."
 ],
 "Path on server": [
  null,
  "Ruta pe server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Ruta pe server nu poate fi goală."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Ruta pe server trebuie să înceapă cu „/”."
 ],
 "Local mount point": [
  null,
  "Punct de montare local"
 ],
 "Mount point cannot be empty.": [
  null,
  "Punctul de montare nu poate fi gol."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Punctul de montare trebuie să înceapă cu „/”."
 ],
 "Mount options": [
  null,
  "Opțiuni de montare"
 ],
 "Mount at boot": [
  null,
  "Montează la pornire"
 ],
 "Mount read only": [
  null,
  "Montare numai pentru citire"
 ],
 "Custom mount options": [
  null,
  "Opțiuni de montare personalizate"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nu se poate demonta sistemul de fișiere"
 ],
 "Stop and unmount": [
  null,
  "Oprește și demontează"
 ],
 "Unable to remove mount": [
  null,
  "Nu se poate elimina montarea"
 ],
 "Stop and remove": [
  null,
  "Oprește și elimină"
 ],
 "(not mounted)": [
  null,
  "(nemontat)"
 ],
 "Start multipath": [
  null,
  "Pornește «multipath»"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "În sistem există dispozitive cu rute multiple, dar serviciul «multipath» nu rulează."
 ],
 "Show all $0 rows": [
  null,
  "Afișează toate cele $0 de rânduri"
 ],
 "Category": [
  null,
  "Categorie"
 ],
 "more info": [
  null,
  "mai multe informații"
 ],
 "Encryption": [
  null,
  "Criptare"
 ],
 "encrypted": [
  null,
  "criptat"
 ],
 "Last modified: $0": [
  null,
  "Ultima modificare: $0"
 ],
 "Stored passphrase": [
  null,
  "Fraza de acces stocată"
 ],
 "Encryption options": [
  null,
  "Opțiuni de criptare"
 ],
 "Encryption type": [
  null,
  "Tipul criptării"
 ],
 "Cleartext device": [
  null,
  "Dispozitiv cu text în clar"
 ],
 "yes": [
  null,
  "da"
 ],
 "Disk passphrase": [
  null,
  "Frază de acces pentru disc"
 ],
 "Passphrase cannot be empty": [
  null,
  "Fraza de acces nu poate fi goală"
 ],
 "Unlocking disk": [
  null,
  "Se deblochează discul"
 ],
 "Checking for $0 package": [
  null,
  "Se verifică existența pachetului $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Pachetul $0 trebuie să fie instalat."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Pachetul $0 nu este disponibil din niciun depozit."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Eroare la instalarea $0: PackageKit sau dnf5daemon-server nu este instalat"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Eroare neașteptată a PackageManager în timpul instalării $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Se verifică prezența suportului pentru NBDE în initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd-ul trebuie regenerat."
 ],
 "Regenerating initrd": [
  null,
  "Se regenerează initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Se adaugă parametrul „rd.neednet=1” la linia de comandă a nucleului"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Se adaugă „$0” la opțiunile sistemului de fișiere"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Se adaugă „$0” la opțiunile de criptare"
 ],
 "Enabling $0": [
  null,
  "Se activează $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Adăugare criptare disc legat la rețea"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "În prezent, sistemul nu acceptă deblocarea sistemului de fișiere rădăcină cu ajutorul unui server de chei Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "În prezent, sistemul nu acceptă deblocarea unui sistem de fișiere cu ajutorul unui server de chei Tang în timpul pornirii."
 ],
 "These additional steps are necessary:": [
  null,
  "Sunt necesare următoarele etape suplimentare:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salvarea unei parole noi necesită deblocarea discului. Vă rugăm să introduceți parola curentă a discului."
 ],
 "Fix NBDE support": [
  null,
  "Remedierea suportului pentru NBDE"
 ],
 "Adding key": [
  null,
  "Se adaugă cheia"
 ],
 "Key source": [
  null,
  "Sursa cheii"
 ],
 "Repeat passphrase": [
  null,
  "Repetă fraza de acces"
 ],
 "Passphrase": [
  null,
  "Fraza de acces"
 ],
 "Tang keyserver": [
  null,
  "Serverul de chei Tang"
 ],
 "New passphrase": [
  null,
  "Frază de acces nouă"
 ],
 "Passphrases do not match": [
  null,
  "Frazele de acces nu se potrivesc"
 ],
 "Keyserver address": [
  null,
  "Adresa serverului de chei"
 ],
 "Change passphrase": [
  null,
  "Schimbă fraza de acces"
 ],
 "Old passphrase": [
  null,
  "Fraza de acces veche"
 ],
 "Edit Tang keyserver": [
  null,
  "Editează serverul de chei Tang"
 ],
 "Verify key": [
  null,
  "Verifică cheia"
 ],
 "Trust key": [
  null,
  "Cheie de încredere"
 ],
 "Passphrase can not be empty": [
  null,
  "Fraza de acces nu poate fi goală"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Eliminarea frazei de acces poate împiedica deblocarea $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirmă ștergerea cu o parolă alternativă"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Eliminarea unei fraze de acces fără confirmarea unei alte fraze de acces poate împiedica deblocarea sau gestionarea cheilor, în cazul în care celelalte fraze de acces sunt uitate sau pierdute."
 ],
 "Passphrase from any other key slot": [
  null,
  "Fraza de acces din orice alt slot pentru chei"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Doriți să eliminați fraza de acces din slotul de chei $0?"
 ],
 "Remove $0?": [
  null,
  "Eliminați $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Eliminarea poate împiedica deblocarea $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Eliminați serverul de chei Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Eliminați cheia din slotul $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Utilizatorul conectat în prezent nu are permisiunea de a vizualiza informații despre chei."
 ],
 "No keys added": [
  null,
  "Nu s-au adăugat chei"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editarea unei chei necesită un slot liber"
 ],
 "The last key slot can not be removed": [
  null,
  "Ultimul slot pentru chei nu poate fi eliminat"
 ],
 "Keyserver": [
  null,
  "Server de chei"
 ],
 "Unknown type": [
  null,
  "Tip necunoscut"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sloturile de chei cu tipuri necunoscute nu pot fi editate aici"
 ],
 "Keys": [
  null,
  "Chei"
 ],
 "$0 slot remains": [
  null,
  "$0 slot rămas",
  "$0 sloturi rămase",
  "$0 de sloturi rămase"
 ],
 "No available slots": [
  null,
  "Nu există sloturi disponibile"
 ],
 "No free key slots": [
  null,
  "Nu există sloturi libere pentru chei"
 ],
 "Locked data": [
  null,
  "Date blocate"
 ],
 "lock": [
  null,
  "blocare"
 ],
 "Lock $0?": [
  null,
  "Blocaâi $0?"
 ],
 "Address cannot be empty": [
  null,
  "Adresa nu poate fi goală"
 ],
 "Address is not a valid URL": [
  null,
  "Adresa nu este o adresă URL validă"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Verificați hash-ul cheii cu serverul Tang."
 ],
 "How to check": [
  null,
  "Cum se verifică"
 ],
 "In a terminal, run: ": [
  null,
  "Într-un terminal, executați: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "S-a copiat cu succes în clipboard!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Verificați dacă hash-ul SHA-256 sau SHA-1 generat de comandă corespunde cu cel din această fereastră de dialog."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "sub-volumul btrfs $0 din $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Punctul de montare nu poate fi gol"
 ],
 "Mount point is already used for $0": [
  null,
  "Punctul de montare este deja utilizat pentru $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Sistemele de fișiere sunt deja montate sub acest punct de montare."
 ],
 "Please unmount them first.": [
  null,
  "Demontați-le mai întâi."
 ],
 "read only": [
  null,
  "numai-citire"
 ],
 "never mount at boot": [
  null,
  "nu se montează niciodată la pornire"
 ],
 "after network": [
  null,
  "după rețea"
 ],
 "ignore failure": [
  null,
  "ignoră eșecul"
 ],
 "stop boot on failure": [
  null,
  "oprește pornirea în caz de eroare"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Sistemul de fișiere nu are un punct de montare atribuit."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Sistemul de fișiere nu are un punct de montare permanent."
 ],
 "The filesystem is not mounted.": [
  null,
  "Sistemul de fișiere nu este montat."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Sistemul de fișiere va fi deblocat și montat la următoarea pornire a sistemului. Este posibil să fie necesară introducerea unei fraze de acces."
 ],
 "(no assigned mount point)": [
  null,
  "(niciun punct de montare atribuit)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Sistemul de fișiere este montat în prezent pe $0, dar va fi montat pe $1 la următoarea pornire a sistemului."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montează automat pe $0 la pornire"
 ],
 "Mount on $0 now": [
  null,
  "Montează pe $0 acum"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Sistemul de fișiere nu este montat în prezent, dar va fi montat la următoarea pornire a sistemului."
 ],
 "Do not mount automatically on boot": [
  null,
  "Nu se montează automat la pornire"
 ],
 "Mount now": [
  null,
  "Montează acum"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Sistemul de fișiere este montat în prezent, dar nu va mai fi montat după pornirea următoare."
 ],
 "Mount also automatically on boot": [
  null,
  "Montează de asemenea automat la pornire"
 ],
 "Unmount now": [
  null,
  "Demontează acum"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Sistemul de fișiere este montat în prezent pe $0, dar nu va mai fi montat după următoarea pornire."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Sistemul de fișiere este configurat să fie montat automat la pornire, dar containerul său de criptare nu va fi deblocat în acel moment."
 ],
 "Unlock automatically on boot": [
  null,
  "Deblochează automat la pornire"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montarea incorectă a sistemului de fișiere"
 ],
 "$0 filesystem": [
  null,
  "Sistem de fișiere $0"
 ],
 "Filesystem name": [
  null,
  "Numele sistemului de fișiere"
 ],
 "Filesystem is locked": [
  null,
  "Sistemul de fișiere este blocat"
 ],
 "Mounts before services start": [
  null,
  "Montează înainte de inițierea serviciilor"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Potrivit pentru montări critice, precum „/var”"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Pornirea eșuează dacă sistemul de fișiere nu se montează, împiedicând accesul de la distanță"
 ],
 "Mounts in parallel with services": [
  null,
  "Montează în paralel cu inițierea serviciilor"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Pornirea are succes chiar și atunci când sistemul de fișiere nu este montat"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Montează în paralel cu inițierea serviciilor, dar după ce rețeaua este disponibilă"
 ],
 "Does not mount during boot": [
  null,
  "Nu se montează la pornire"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Util pentru montări care sunt opționale sau necesită interacțiune (cum ar fi parolele)"
 ],
 "At boot": [
  null,
  "La pornire"
 ],
 "Mount before services start": [
  null,
  "Montează înainte de inițierea serviciilor"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montează fără așteptare, se ignoră eșecul"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montează după ce rețeaua devine disponibilă; ignoră eșecul"
 ],
 "Do not mount": [
  null,
  "Nu monta"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Acest dispozitiv nu poate fi utilizat pentru ținta de instalare."
 ],
 "Mount filesystem": [
  null,
  "Montează sistemul de fișiere"
 ],
 "Unmount filesystem $0": [
  null,
  "Demontează sistemul de fișiere $0"
 ],
 "Mount configuration": [
  null,
  "Configurarea montării"
 ],
 "Swap": [
  null,
  "Spațiu de interschimb"
 ],
 "Used": [
  null,
  "Utilizat"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Deblochează grupul Stratis criptat"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Introduceți fraza de acces pentru grupul de stocare de pe aceste dispozitive de blocuri:"
 ],
 "Stratis pool": [
  null,
  "Grupul Stratis"
 ],
 "stopped": [
  null,
  "oprit"
 ],
 "Block devices": [
  null,
  "Dispozitive de blocuri"
 ],
 "No block devices found": [
  null,
  "Nu s-au găsit dispozitive de blocuri"
 ],
 "Stratis block devices": [
  null,
  "Dispozitive de blocuri Stratis"
 ],
 "Stratis block device": [
  null,
  "Dispozitiv de blocuri Stratis"
 ],
 "data": [
  null,
  "date"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Introduceți o frază de acces existentă pentru grupul de stocare."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Dacă serverul de chei de la $0 nu este accesibil, puteți furniza o frază de acces existentă."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Dacă niciunul dintre serverele de chei nu este accesibil, puteți furniza o frază de acces existentă."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Dacă niciuna dintre metodele de deblocare neinteractive nu funcționează, puteți furniza o parolă existentă."
 ],
 "Pool passphrase": [
  null,
  "Fraza de acces a grupului de stocare"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Serverul de chei de la adresa $0 trebuie să fie accesibil."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Cel puțin un server de chei trebuie să fie accesibil."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Cel puțin una dintre metodele de deblocare neinteractive trebuie să funcționeze."
 ],
 "Create filesystem": [
  null,
  "Creează un sistem de fișiere"
 ],
 "Stratis filesystem": [
  null,
  "Sistem de fișiere Stratis"
 ],
 "Set initial size": [
  null,
  "Stabilește dimensiunea inițială"
 ],
 "Limit size": [
  null,
  "Limitează dimensiunea"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Ștergerea unui grup de stocare Stratis va șterge toate datele pe care le conține."
 ],
 "Rename Stratis pool": [
  null,
  "Redenumește grupul de stocare Stratis"
 ],
 "Add block devices": [
  null,
  "Adaugă dispozitive de blocuri"
 ],
 "Tier": [
  null,
  "Nivel"
 ],
 "Data": [
  null,
  "Date"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Adăugarea dispozitivelor de blocuri necesită deblocarea grupului."
 ],
 "Encrypted Stratis pool": [
  null,
  "Grup de stocare Stratis criptat"
 ],
 "Delete pool": [
  null,
  "Șterge grupul de stocare"
 ],
 "Encryption tokens": [
  null,
  "Jetoane de criptare"
 ],
 "Stratis filesystems": [
  null,
  "Sisteme de fișiere Stratis"
 ],
 "Create new filesystem": [
  null,
  "Creează un sistem de fișiere nou"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Acest grup nu utilizează tot spațiul disponibil pe dispozitivele sale de blocuri."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Unele dispozitive de blocuri din acest grup au crescut în dimensiune după crearea grupului. Grupul poate fi extins în siguranță pentru a utiliza spațiul nou disponibil."
 ],
 "Grow the pool to take all space": [
  null,
  "Augmenta grupul pentru a ocupa tot spațiul"
 ],
 "This pool is in a degraded state.": [
  null,
  "Acest grup este într-o stare de degradare."
 ],
 "No filesystems": [
  null,
  "Niciun sistem de fișiere"
 ],
 "Stratis filesystems pool": [
  null,
  "Grupul de sisteme de fișiere Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Această frază de acces este singura modalitate de a debloca grupul și nu poate fi eliminată."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Acest server de chei este singura modalitate de a debloca grupul și nu poate fi eliminat."
 ],
 "Add passphrase": [
  null,
  "Adaugă o frază de acces"
 ],
 "Add keyserver": [
  null,
  "Adaugă server de chei"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis „$0”"
 ],
 "Last token can not be removed": [
  null,
  "Ultimul jeton nu poate fi eliminat"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Nu mai este spațiu pentru fraze de acces sau servere de chei."
 ],
 "Confirm": [
  null,
  "Confirmă"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Adăugarea unei fraze de acces necesită deblocarea grupului."
 ],
 "Remove passphrase?": [
  null,
  "Doriți să eliminați fraza de acces?"
 ],
 "Add Tang keyserver": [
  null,
  "Adaugă serverul de chei Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Adăugarea unui server de chei necesită deblocarea grupului."
 ],
 "Remove Clevis token?": [
  null,
  "Eliminați jetoanul Clevis?"
 ],
 "Metadata format": [
  null,
  "Formatul metadatelor"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Grupurile de stocare cu formatul de metadate V1 sunt limitate la cel mult o frază de acces și cel mult un server de chei."
 ],
 "Overprovisioning": [
  null,
  "Supraalocarea"
 ],
 "Allow overprovisioning": [
  null,
  "Permite supraalocarea"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Dimensiunile sistemului de fișiere virtual sunt mai mari decât cele ale grupului. Supraalocarea nu poate fi dezactivată."
 ],
 "Allocated": [
  null,
  "Alocat"
 ],
 "Name can not be empty.": [
  null,
  "Numele nu poate să fie gol."
 ],
 "A pool with this name exists already.": [
  null,
  "Există deja un grup cu acest nume."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un sistem de fișiere cu acest nume există deja în acest grup."
 ],
 "Create Stratis pool": [
  null,
  "Creează un grup Stratis"
 ],
 "No block devices are available.": [
  null,
  "Nu există dispozitive de blocuri disponibile."
 ],
 "At least one block device is needed.": [
  null,
  "Este necesar cel puțin un dispozitiv de blocuri."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Criptați datele cu o frază de acces"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Criptați datele cu un server de chei Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Creează o imagine instantanee a sistemului de fișiere $0"
 ],
 "Create snapshot and mount": [
  null,
  "Creează o imagine instantanee și-o montează"
 ],
 "Create snapshot only": [
  null,
  "Creează imaginea instantanee doar"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Ștergerea unui sistem de fișiere va șterge toate datele din acesta."
 ],
 "Snapshot": [
  null,
  "Imagine instantanee"
 ],
 "Rename filesystem": [
  null,
  "Redenumește sistemul de fișiere"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Stabilește limita dimensiunii sistemului de fișiere virtual"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limitează dimensiunea sistemului de fișiere virtual"
 ],
 "Virtual size limit": [
  null,
  "Limita dimensiunii virtuale"
 ],
 "Virtual size": [
  null,
  "Dimensiunea virtuală"
 ],
 "Create RAID device": [
  null,
  "Creează un dispozitiv RAID"
 ],
 "RAID level": [
  null,
  "Nivel RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (bandă)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (oglindă)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (partiție dedicată)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (partiție distribuită)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (partiție distribuită dublă)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (bandă de oglinzi)"
 ],
 "Chunk size": [
  null,
  "Dimensiunea bucății"
 ],
 "4 KiB": [
  null,
  "4 Kio"
 ],
 "8 KiB": [
  null,
  "8 Kio"
 ],
 "16 KiB": [
  null,
  "16 Kio"
 ],
 "32 KiB": [
  null,
  "32 Kio"
 ],
 "64 KiB": [
  null,
  "64 Kio"
 ],
 "128 KiB": [
  null,
  "128 Kio"
 ],
 "512 KiB": [
  null,
  "512 Kio"
 ],
 "1 MiB": [
  null,
  "1 Mio"
 ],
 "2 MiB": [
  null,
  "2 Mio"
 ],
 "At least $0 disk is needed.": [
  null,
  "Este nevoie de cel puțin $0 disc.",
  "Sunt necesare cel puțin $0 discuri.",
  "Sunt necesare cel puțin $0 de discuri."
 ],
 "MDRAID disk": [
  null,
  "Disc MDRAID"
 ],
 "In sync": [
  null,
  "În sincronizare"
 ],
 "Spare": [
  null,
  "De rezervă"
 ],
 "Recovering": [
  null,
  "Se recuperează"
 ],
 "Write-mostly": [
  null,
  "În principal scriere"
 ],
 "Blocked": [
  null,
  "Blocat"
 ],
 "Unknown ($0)": [
  null,
  "Necunoscut ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Dispozitivul MDRAID trebuie să fie în funcțiune"
 ],
 "MDRAID device is recovering": [
  null,
  "Dispozitivul MDRAID se recuperează"
 ],
 "Need a spare disk": [
  null,
  "Este nevoie de un disc de rezervă"
 ],
 "Last disk can not be removed": [
  null,
  "Ultimul disc nu poate fi eliminat"
 ],
 "MDRAID device": [
  null,
  "Dispozitiv MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmă oprirea lui $0"
 ],
 "Stop device": [
  null,
  "Oprește dispozitivul"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Ștergerea va elimina toate datele de pe un dispozitiv MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Dispozitivul MDRAID trebuie să fie în funcțiune"
 ],
 "Add disk": [
  null,
  "Adaugă un disc"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 discuri"
 ],
 "$0 chunk size": [
  null,
  "dimensiunea bucății $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Dispozitivul MDRAID este într-o stare degradată"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Acest dispozitiv MDRAID nu dispune de o hartă de biți pentru operații de scriere. O astfel de hartă de biți poate reduce semnificativ timpul de sincronizare."
 ],
 "Add a bitmap": [
  null,
  "Adaugă o hartă de biți"
 ],
 "No disks found": [
  null,
  "Nu s-au găsit discuri"
 ],
 "MDRAID disks": [
  null,
  "Discuri MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Ștergerea va elimina toate datele de pe un dispozitiv VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Crearea acestui dispozitiv VDO nu a fost finalizată, iar dispozitivul nu poate fi utilizat."
 ],
 "Remove device": [
  null,
  "Elimină dispozitivul"
 ],
 "Grow to take all space": [
  null,
  "Augmenta pentru a ocupa tot spațiul"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Acest dispozitiv VDO nu utilizează întreaga capacitate a dispozitivului subiacent de stocare."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Se utilizează doar $0 din $1."
 ],
 "Grow logical size of $0": [
  null,
  "Augmenta dimensiunea logică a $0"
 ],
 "Physical": [
  null,
  "Fizic"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 date + $1 supraîncărcare utilizată din $2 ($3)"
 ],
 "Logical": [
  null,
  "Logic"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 utilizați din $1 ($2 salvat)"
 ],
 "Index memory": [
  null,
  "Memorie index"
 ],
 "SMART self-test of $target": [
  null,
  "Auto-testul SMART al $target"
 ],
 "Ejecting $target": [
  null,
  "Se ejectează $target"
 ],
 "Unlocking $target": [
  null,
  "Se deblochează $target"
 ],
 "Locking $target": [
  null,
  "Se blochează $target"
 ],
 "Modifying $target": [
  null,
  "Se modifică $target"
 ],
 "Resizing $target": [
  null,
  "Se redimensionează $target"
 ],
 "Starting swapspace $target": [
  null,
  "Se inițializează spațiul se interschimb $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Se oprește spațiul se interschimb $target"
 ],
 "Mounting $target": [
  null,
  "Se montează $target"
 ],
 "Unmounting $target": [
  null,
  "Se demontează $target"
 ],
 "Checking $target": [
  null,
  "Se verifică $target"
 ],
 "Repairing $target": [
  null,
  "Se repară $target"
 ],
 "Erasing $target": [
  null,
  "Se șterge $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Se creează sistemul de fișiere pe $target"
 ],
 "Setting up loop device $target": [
  null,
  "Configurarea dispozitivului de buclă $target"
 ],
 "Deleting $target": [
  null,
  "Se șterge $target"
 ],
 "Creating partition $target": [
  null,
  "Se creează partiția $target"
 ],
 "Cleaning up for $target": [
  null,
  "Se curăță pentru $target"
 ],
 "Securely erasing $target": [
  null,
  "Ștergerea în siguranță a $target"
 ],
 "Very securely erasing $target": [
  null,
  "Se șterge tot ceea ce este relaționat cu $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Se oprește dispozitivul MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Se inițializează dispozitivul MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Se marchează $target ca fiind defect"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Eliminarea $target din dispozitivul MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Se creează dispozitivul MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Se verifică dispozitivul MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Se verifică și se repară dispozitivul MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Se recuperează dispozitivul MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Se sincronizează dispozitivul MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Se activează $target"
 ],
 "Deactivating $target": [
  null,
  "Se dezactivează $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Se creează imaginea instantanee pe $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Se creează grupul de volume LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Se șterge grupul de volume LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Se adaugă volumul fizic la $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Se elimină volumul fizic din $target"
 ],
 "Emptying $target": [
  null,
  "Se golește $target"
 ],
 "Creating logical volume $target": [
  null,
  "Se creează volumul logic $target"
 ],
 "Renaming $target": [
  null,
  "Se redenumește $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operația „$operation” asupra $target"
 ],
 "unknown target": [
  null,
  "țintă necunoscută"
 ],
 "Jobs": [
  null,
  "Lucrări"
 ],
 "Reading": [
  null,
  "Se citește"
 ],
 "Writing": [
  null,
  "Se scrie"
 ],
 "Install Stratis support": [
  null,
  "Instalează suportul pentru Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Pachetul $0 trebuie instalat pentru a crea grupuri Stratis."
 ],
 "Install NFS support": [
  null,
  "Instalează suportul pentru NFS"
 ],
 "Create MDRAID device": [
  null,
  "Creează un dispozitiv MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Creează un grup de volume LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Schimbă numele inițiatorului iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Adaugă portal iSCSI"
 ],
 "Local storage": [
  null,
  "Stocare locală"
 ],
 "Networked storage": [
  null,
  "Stocare în rețea"
 ],
 "Create storage device": [
  null,
  "Creează un dispozitiv de stocare"
 ],
 "No storage found": [
  null,
  "Nu s-a găsit niciun spațiu de stocare"
 ],
 "Server address cannot be empty.": [
  null,
  "Adresa serverului nu poate fi goală."
 ],
 "Next": [
  null,
  "Înainte"
 ],
 "Invalid username or password": [
  null,
  "Nume de utilizator sau parolă nevalidă"
 ],
 "Unknown host name": [
  null,
  "Nume de gazdă necunoscut"
 ],
 "Unable to reach server": [
  null,
  "Nu se poate accesa serverul"
 ],
 "Available targets on $0": [
  null,
  "Ținte disponibile pe $0"
 ],
 "Authentication required": [
  null,
  "Autentificarea este necesară"
 ],
 "iSCSI portal": [
  null,
  "Portal iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Unități iSCSI"
 ],
 "No drives found": [
  null,
  "Nu s-au găsit unități de stocare"
 ],
 "Target": [
  null,
  "Ținta"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Dispozitivele de rezervă VDO nu pot fi redimensionate"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Dispozitivele de blocuri Stratis nu pot fi făcute mai mici"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Datele nerecunoscute nu pot fi micșorate aici."
 ],
 "Unlock before resizing": [
  null,
  "Deblochează înainte de redimensionare"
 ],
 "$0 can not be resized here": [
  null,
  "$0 nu poate fi redimensionat aici"
 ],
 "$0 can not be resized": [
  null,
  "$0 nu poate fi redimensionat"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 nu poate fi micșorat"
 ],
 "$0 can not be made larger": [
  null,
  "$0 nu poate fi mărit"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Volumele fizice nu pot fi redimensionate aici"
 ],
 "Swap can not be resized here": [
  null,
  "Spațiul de interschimb(swap) nu poate fi redimensionat aici"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Datele nerecunoscute nu pot fi micșorate aici"
 ],
 "Activate before resizing": [
  null,
  "Activează înainte de redimensionare"
 ],
 "Grow logical volume": [
  null,
  "Augmenta volumul logic"
 ],
 "Grow partition": [
  null,
  "Augmenta partiția"
 ],
 "grow": [
  null,
  "augmenta"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exact $0 volume fizice trebuie să fie selectate"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Redimensionarea unui sistem de fișiere criptat necesită deblocarea discului. Vă rugăm să introduceți fraza de acces actuală a discului."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exact $0 volume fizice trebuie să fie selectate, câte unul pentru fiecare bandă a volumului logic."
 ],
 "Shrink logical volume": [
  null,
  "Reduce volumul logic"
 ],
 "shrink": [
  null,
  "reduce"
 ],
 "Unformatted data": [
  null,
  "Date neformatate"
 ],
 "Block device": [
  null,
  "Dispozitiv de blocuri"
 ],
 "Device number": [
  null,
  "Numărul dispozitivului"
 ],
 "Create partition on $0": [
  null,
  "Creează o partiție pe $0"
 ],
 "Format $0": [
  null,
  "Formatare $0"
 ],
 "No filesystem": [
  null,
  "Niciun sistem de fișiere"
 ],
 "(recommended)": [
  null,
  "(recomandat)"
 ],
 "No encryption": [
  null,
  "Fără criptare"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Reutilizează criptarea existentă ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Reutilizează criptarea existentă"
 ],
 "format": [
  null,
  "format"
 ],
 "Format and mount": [
  null,
  "Formatare și montare"
 ],
 "Format only": [
  null,
  "Doar formatare"
 ],
 "Format": [
  null,
  "Formatare"
 ],
 "Create and start": [
  null,
  "Creează și inițiază"
 ],
 "Format and start": [
  null,
  "Formatează și pornește"
 ],
 "Store passphrase": [
  null,
  "Stochează fraza de acces"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Discul trebuie deblocat înainte de formatare. Vă rugăm să introduceți fraza de acces existentă."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatarea elimină toate datele de pe un dispozitiv de stocare."
 ],
 "Unrecognized data": [
  null,
  "Date nerecunoscute"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Stocarea nu poate fi gestionată pe acest sistem."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web pentru servere Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit este un gestionator de servere care facilitează administrarea serverelor Linux prin intermediul unui navigator web. Trecerea de la terminal la instrumentul web și invers nu reprezintă nicio problemă. Un serviciu pornit prin Cockpit poate fi oprit prin terminal. La fel, dacă apare o eroare în terminal, aceasta poate fi vizualizată în interfața de jurnal a Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit este ideal pentru administratorii de sistem începători, permițându-le să efectueze cu ușurință sarcini simple, precum administrarea spațiului de stocare, verificarea jurnalelor și pornirea sau oprirea serviciilor. Puteți monitoriza și administra mai multe servere în același timp. Trebuie doar să le adăugați cu un singur clic, iar sistemul se va ocupa de restul."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "După ce Cockpit este instalat, activați-l cu comanda «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurarea Cockpit a NetworkManager și Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Acest instrument gestionează rețelele, cum ar fi legăturile, punțile, grupurile, rețelele VLAN și paravanele de protecție, folosind NetworkManager și Firewalld. NetworkManager nu este compatibil cu scripturile implicite systemd-networkd din Ubuntu și ifupdown din Debian."
 ],
 "Manage storage": [
  null,
  "Gestionează spațiul de stocare"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Acest instrument gestionează spațiul de stocare local, cum ar fi sistemele de fișiere, grupurile de volume LVM2 și montările NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Colectarea și organizarea datelor de diagnosticare și asistență"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Acest instrument generează un fișier de arhivă care conține informații de configurare și diagnosticare din sistemul în funcțiune. Fișierul de arhivă poate fi stocat local sau centralizat în scopuri de înregistrare sau monitorizare sau poate fi trimis reprezentanților serviciului de asistență tehnică, dezvoltatorilor sau administratorilor de sistem pentru a facilita identificarea problemelor tehnice și depanarea."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurarea și soluționarea problemelor în Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Acest instrument configurează politica SELinux și poate fi de ajutor în înțelegerea și rezolvarea încălcărilor politicii."
 ],
 "Collect kernel crash dumps": [
  null,
  "Colectarea fișierelor cu conținutul memoriei în momentul apariției unei erori fatale ale sistemului de către nucleu"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Acest instrument configurează sistemul pentru a genera fișiere cu conținutul memoriei din momentul apariției unei erori fatale de către nucleui. Acesta acceptă destinațiile de salvare „local” (pe disc), „ssh” și „nfs”."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrare cu ajutorul consolei web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Este necesară autentificarea pentru a efectua operații cu drepturi speciale în consola web Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "octeți"
 ]
});
