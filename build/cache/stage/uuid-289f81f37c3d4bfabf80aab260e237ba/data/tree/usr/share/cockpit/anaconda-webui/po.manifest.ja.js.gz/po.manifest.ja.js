cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
