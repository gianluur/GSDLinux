cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 erreur",
  "$0 erreurs"
 ],
 "$0 installation": [
  null,
  "Installation du système $0"
 ],
 "$0 installer": [
  null,
  "Programme d'installation du système $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 est une partition étendue MBR qui contient des partitions logiques. Supprimer toutes les partitions logiques aura pour effet de supprimer automatiquement la partition étendue."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 est requis, mais seul $1 est disponible."
 ],
 "$0 warning": [
  null,
  "$0 avertissement",
  "$0 avertissements"
 ],
 "$0 will be deleted": [
  null,
  "$0 sera supprimé"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Le système de fichiers '$0' ne peut pas être sur un périphérique block chiffré"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' doit être assigné à '$1'"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' doit être sur un périphérique au format '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' doit être sur une partition système EFI. La partition sélectionnée utilise un système de fichiers FAT, mais n'est pas marquée comme ESP. Définissez le type de partition sur Partition système EFI et activez le flag esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Partition '$0' trouvée sur le périphérique MDRAID $1. Les partitions de bootloader ne sont pas prises en charge lorsqu'elles se trouvent sur un périphérique MDRAID."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Un compte utilisateur standard avec un accès administrateur permettant d'effectuer des modifications au niveau du système."
 ],
 "Abort installation": [
  null,
  "Interrompre l'installation"
 ],
 "About": [
  null,
  "À propos"
 ],
 "Account": [
  null,
  "Compte"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "Add another server...": [
  null,
  "Ajouter un autre serveur..."
 ],
 "Add mount": [
  null,
  "Ajouter un point de montage"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Extensions pour votre environnement"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Extensions non spécifiques à votre environnement"
 ],
 "Additional languages": [
  null,
  "Langues supplémentaires"
 ],
 "Additional software for the selected environment": [
  null,
  "Logiciels supplémentaires pour l'environnement sélectionné"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Toutes les modifications effectuées dans l'éditeur de stockage prendront effet immédiatement."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Tous les périphériques utilisant cette phrase secrète seront déverrouillés"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Page du projet Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Appliquer l'assignation des points de montage et installer"
 ],
 "Applying changes...": [
  null,
  "Application des modifications..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Assigner les partitions aux points de montage. Utile lorsqu'un schéma de stockage personnalisé a été préconfiguré."
 ],
 "Automatic log file upload": [
  null,
  "Upload automatique du fichier journal"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Définir automatiquement la date et l'heure en utilisant des serveurs de temps"
 ],
 "Automatically set timezone": [
  null,
  "Définir automatiquement le fuseau horaire"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Espace libre disponible : $0. Espace nécessaire pour l'installation : $1."
 ],
 "Back": [
  null,
  "Retour"
 ],
 "Base environment": [
  null,
  "Environnement de base"
 ],
 "Brief description of the issue": [
  null,
  "Courte description du problème"
 ],
 "Bug report details": [
  null,
  "Détails du rapport de bug"
 ],
 "Bugzilla API key": [
  null,
  "Clé d'API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "En continuant d'utiliser ce logiciel, vous comprenez et vous acceptez les risques liés à l'utilisation de logiciels en préversion. Vous l'utiliserez uniquement à des fins de test et de développement, et vous vous engagez à signaler tout bug ou problème rencontré afin d'améliorer ce logiciel."
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change destination": [
  null,
  "Changer de destination"
 ],
 "Change hostname": [
  null,
  "Modifier le nom d'hôte"
 ],
 "Change partition layout": [
  null,
  "Modifier la disposition des partitions"
 ],
 "Change system keyboard layout": [
  null,
  "Changer de disposition de clavier système"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Les modifications apportées ici auront un effet immédiat sur le système. Aucun retour en arrière n'est possible."
 ],
 "Checking installation configuration...": [
  null,
  "Vérification de la configuration d'installation..."
 ],
 "Checking storage configuration": [
  null,
  "Vérification de la configuration du stockage"
 ],
 "Clear search": [
  null,
  "Effacer la recherche"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Cliquez à nouveau sur « Suivant » pour continuer malgré ces avertissements."
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Close storage editor": [
  null,
  "Fermer l'éditeur de stockage"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit Storage n'a pas fourni la phrase secrète permettant de déverrouiller le périphérique chiffré."
 ],
 "Completed": [
  null,
  "Terminé"
 ],
 "Configuration is incomplete": [
  null,
  "La configuration est incomplète"
 ],
 "Configure NTP servers": [
  null,
  "Configurer les serveurs NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurer des serveurs NTP personnalisés"
 ],
 "Configure network": [
  null,
  "Configurer le réseau"
 ],
 "Configure storage": [
  null,
  "Configurer le stockage"
 ],
 "Configure storage again": [
  null,
  "Configurer le stockage à nouveau"
 ],
 "Confirm passphrase": [
  null,
  "Confirmez la phrase secrète"
 ],
 "Continue": [
  null,
  "Continuer"
 ],
 "Continue installation": [
  null,
  "Continuer l'installation"
 ],
 "Continue installation?": [
  null,
  "Continuer l'installation ?"
 ],
 "Continue with installation": [
  null,
  "Continuez l'installation"
 ],
 "Correct these issues before continuing.": [
  null,
  "Corrigez ces problèmes avant de continuer."
 ],
 "Create Account": [
  null,
  "Créer un compte"
 ],
 "Create account": [
  null,
  "Créer un compte"
 ],
 "Currently installed: $0": [
  null,
  "Actuellement installé : $0"
 ],
 "Custom": [
  null,
  "Personnalisé"
 ],
 "Date": [
  null,
  "Date"
 ],
 "Date and time": [
  null,
  "Date et heure"
 ],
 "Delete partition": [
  null,
  "Supprimer la partition"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "La suppression de certaines partitions peut empêcher le démarrage de $0 : $1"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Destination": [
  null,
  "Destination"
 ],
 "Destination is encrypted": [
  null,
  "La destination est chiffrée"
 ],
 "Detailed description of the issue": [
  null,
  "Description détaillée du problème"
 ],
 "Detected valid storage layout:": [
  null,
  "Schéma de stockage valide détecté :"
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Duplicate device.": [
  null,
  "Périphérique en double."
 ],
 "Duplicate mount point.": [
  null,
  "Point de montage en double."
 ],
 "Enable root account": [
  null,
  "Activer le compte root"
 ],
 "Encrypt my data": [
  null,
  "Chiffrer mes données"
 ],
 "Encrypted": [
  null,
  "Chiffré"
 ],
 "Encryption": [
  null,
  "Chiffrement"
 ],
 "Enter PIN": [
  null,
  "Saisir le code PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Saisissez le code PIN pour accéder à l'installation"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Entrez votre clé d'API Bugzilla pour créer un rapport de bug. Vous pourrez examiner et modifier les détails du bug à la prochaine étape."
 ],
 "Environment": [
  null,
  "Environnement"
 ],
 "Erase data and install": [
  null,
  "Effacer les données et installer"
 ],
 "Error details": [
  null,
  "Détails de l'erreur"
 ],
 "Exit to live desktop": [
  null,
  "Quitter vers le bureau live"
 ],
 "Extended partition": [
  null,
  "Partition étendue"
 ],
 "Failed to report issue": [
  null,
  "Impossible de signaler le problème"
 ],
 "Failed to save layouts": [
  null,
  "Échec de l'enregistrement des dispositions"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux requiert au moins $0 d'espace disque."
 ],
 "Finalization": [
  null,
  "Finalisation"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalisation : La configuration du système est terminée. La finalisation de l'installation peut prendre quelques instants."
 ],
 "Find layout": [
  null,
  "Rechercher une disposition"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Pour une meilleure sécurité, évitez d'utiliser le compte root directement. À la place, utilisez le compte local ci-dessus pour gérer le système."
 ],
 "Full name": [
  null,
  "Nom complet"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Le nom complet ne peut pas contenir le caractère deux-points"
 ],
 "Helper text": [
  null,
  "Texte d'assistance"
 ],
 "Hide API key": [
  null,
  "Masquer la clé d'API"
 ],
 "Hide PIN": [
  null,
  "Masquer le code PIN"
 ],
 "Hide confirmed password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide passphrase": [
  null,
  "Masquer la phrase secrète"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "Hostname": [
  null,
  "Nom d'hôte"
 ],
 "How would you like to install?": [
  null,
  "Comment souhaitez-vous effectuer l'installation ?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Je comprends que toutes les données existantes seront effacées",
  "Je comprends que toutes les données existantes des disques sélectionnés seront effacées"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Je comprends que des données existantes seront effacées"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Je comprends que des partitions seront modifiées"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Si le champ est vide, le nom d'hôte sera transitoire et défini par les informations du réseau."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Si aucune des options ci-dessus ne convient, utilisez l'éditeur de stockage pour créer un partitionnement personnalisé avant de continuer."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Si vous décidez d'effectuer la configuration manuellement, les partitions suivantes sont requises :"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Si vous n'acceptez pas l'upload automatique du fichier journal, vous pouvez à la place $0. Le signalement manuel de bugs vous permet d'examiner et choisir vous-même les fichiers journaux à joindre."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Si vous ne comprenez ou n'acceptez pas ces risques, merci de quitter ce programme."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Si votre problème correspond à l'un des bugs ci-dessus, vous pouvez l'ouvrir et y ajouter vos informations plutôt que de créer un nouveau signalement."
 ],
 "In progress": [
  null,
  "En cours"
 ],
 "Initializing...": [
  null,
  "Initialisation..."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Installation completed": [
  null,
  "Installation terminée"
 ],
 "Installation failed": [
  null,
  "Installation échouée"
 ],
 "Installation method": [
  null,
  "Méthode d'installation"
 ],
 "Installation of the system failed": [
  null,
  "L'installation du système a échoué"
 ],
 "Installation of the system failed: $0": [
  null,
  "Échec de l'installation du système : $0"
 ],
 "Installation type": [
  null,
  "Type d'installation"
 ],
 "Installing": [
  null,
  "Installation en cours"
 ],
 "Insufficient disk space": [
  null,
  "Espace disque insuffisant"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Code PIN invalide, veuillez réessayer."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Configuration RAID invalide détectée. Si votre matrice RAID est créée directement sur les disques, une table de partitions doit être créée sur la matrice. Si votre matrice RAID est créée sur les partitions, elle doit contenir un système de fichiers ou format (ex. LVM PV) unique. Toute partition existant déjà sur cette matrice sera ignorée."
 ],
 "Invalid hostname": [
  null,
  "Nom d'hôte invalide"
 ],
 "Jump to first incomplete step": [
  null,
  "Sauter à la première étape incomplète"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Conserver la configuration actuelle des disques et utiliser l'espace disponible (pour créer un dual-boot avec un autre OS)."
 ],
 "Keyboard": [
  null,
  "Clavier"
 ],
 "Keyboard layout during boot": [
  null,
  "Disposition de clavier pendant le démarrage"
 ],
 "Language": [
  null,
  "Langue"
 ],
 "Launch storage editor": [
  null,
  "Lancer l'éditeur de stockage"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "En savoir plus sur l'accès restreint dans la configuration"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Laissez les deux champs de phrase secrète vides pour utiliser un mot de passe vide."
 ],
 "Location": [
  null,
  "Emplacement"
 ],
 "Locked devices": [
  null,
  "Périphériques verrouillés"
 ],
 "Log in": [
  null,
  "Se connecter"
 ],
 "Make current": [
  null,
  "Définir comme actuelle"
 ],
 "Manual disk configuration": [
  null,
  "Configuration manuelle des disques"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuration manuelle des disques : Définition des points de montage"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Peut contenir des lettres, des nombres et des tirets."
 ],
 "May need more free space": [
  null,
  "Peut nécessiter plus d'espace libre"
 ],
 "Medium": [
  null,
  "Moyen"
 ],
 "Minimum of $0 required": [
  null,
  "Au moins $0 requis"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Problème de correspondance dans la sélection des périphériques parent et enfant à reformater."
 ],
 "Mount point": [
  null,
  "Point de montage"
 ],
 "Mount point assignment": [
  null,
  "Assigner les points de montage"
 ],
 "Move down": [
  null,
  "Déplacer vers le bas"
 ],
 "Move up": [
  null,
  "Déplacer vers le haut"
 ],
 "Must be at least $0 characters": [
  null,
  "Doit être d'au moins $0 caractères"
 ],
 "My issue is different, continue": [
  null,
  "Mon problème est différent, continuer"
 ],
 "NTP Servers": [
  null,
  "Serveurs NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Needs at least $0": [
  null,
  "Nécessite au moins $0"
 ],
 "Network": [
  null,
  "Réseau"
 ],
 "Network Configuration": [
  null,
  "Configuration réseau"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Réseau non disponible. Configurez le réseau dans le menu de la barre supérieure pour signaler le problème."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Réseau non disponible. Configurez le réseau pour signaler le problème."
 ],
 "Network plugin failed": [
  null,
  "Défaillance du plugin réseau"
 ],
 "Next": [
  null,
  "Suivant"
 ],
 "No devices": [
  null,
  "Aucun périphérique"
 ],
 "No disks available": [
  null,
  "Aucun disque disponible"
 ],
 "No disks selected": [
  null,
  "Aucun disque sélectionné"
 ],
 "No keyboard layouts selected": [
  null,
  "Aucune disposition de clavier sélectionnée"
 ],
 "No layouts selected yet": [
  null,
  "Aucune disposition sélectionnée"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Aucune keymap VConsole valide ne peut être obtenue pour les dispositions de clavier sélectionnées. Veuillez modifier votre sélection de dispositions de clavier."
 ],
 "Not enough available free space": [
  null,
  "Espace libre disponible insuffisant"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Espace libre insuffisant sur les disques sélectionnés."
 ],
 "Not enough space on selected disks.": [
  null,
  "Espace insuffisant sur les disques sélectionnés."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Avertissement : Ce logiciel est en préversion. Son utilisation est prévue uniquement à des fins de développement et de test. N'UTILISEZ PAS ce logiciel pour répondre à un besoin critique ou dans un environnement de production."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Ouvrir le formulaire Bugzilla de signalement de bug"
 ],
 "Operating system": [
  null,
  "Système d'exploitation"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other keyboards": [
  null,
  "Autres claviers"
 ],
 "Partitions (advanced)": [
  null,
  "Partitions (avancé)"
 ],
 "Passphrase": [
  null,
  "Phrase secrète"
 ],
 "Passphrase did not match any locked device": [
  null,
  "La phrase secrète saisie ne correspond à aucun périphérique verrouillé"
 ],
 "Passphrases must match": [
  null,
  "Les phrases secrètes doivent correspondre"
 ],
 "Pending": [
  null,
  "En attente"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Veuillez joindre le fichier journal $0 au signalement."
 ],
 "Please enter a PIN": [
  null,
  "Veuillez saisir un code PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Sélectionnez au moins un disque pour continuer"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Doublon potentiel trouvé"
 ],
 "Powered by Anaconda": [
  null,
  "Fonctionne grâce à Anaconda"
 ],
 "Pre-release": [
  null,
  "Préversion"
 ],
 "Prefer to report manually? $0": [
  null,
  "Vous préférez effectuer un signalement manuel ? $0"
 ],
 "Proceed with installation": [
  null,
  "Poursuivre l'installation"
 ],
 "Quit": [
  null,
  "Quitter"
 ],
 "Quit installer?": [
  null,
  "Quitter le programme d'installation ?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Échec de la lecture des informations à propos du système d'exploitation."
 ],
 "Reading information about the computer failed.": [
  null,
  "Échec de la lecture des informations à propos de l'ordinateur."
 ],
 "Reading installer configuration failed.": [
  null,
  "Échec de la lecture de la configuration du programme d'installation."
 ],
 "Reading installer version information failed.": [
  null,
  "Échec de la lecture des informations de version du programme d'installation."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Le nom d'hôte réel peut contenir uniquement des caractères, des chiffres, des tirets (hormis au début et à la fin) et des points"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Le nom d'hôte réel ne doit pas dépasser 64 caractères"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Redémarrez dans Windows pour redimensionner les partitions chiffrées avec BitLocker. Pensez à dédier au moins $0 d'espace libre à l'installation."
 ],
 "Reboot system?": [
  null,
  "Redémarrer le système ?"
 ],
 "Reclaim additional space": [
  null,
  "Récupérer plus d'espace"
 ],
 "Reclaim space": [
  null,
  "Récupérer de l'espace"
 ],
 "Reclaim space (required)": [
  null,
  "Récupérer de l'espace (requis)"
 ],
 "Recommended": [
  null,
  "Recommandé"
 ],
 "Recommended partitions:": [
  null,
  "Partitions recommandées :"
 ],
 "Reformat": [
  null,
  "Reformater"
 ],
 "Reinstall Fedora": [
  null,
  "Réinstaller Fedora"
 ],
 "Remove": [
  null,
  "Supprimer"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Supprimer toutes les partitions des périphériques sélectionnés, y compris les systèmes d'exploitation existants."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Supprimez ou redimensionnez les systèmes de fichiers existants pour libérer de l'espace pour l'installation."
 ],
 "Remove server": [
  null,
  "Retirer le serveur"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Retirer un système de fichiers supprimera définitivement l'ensemble des données qu'il contient. Redimensionner une partition peut permettre de libérer de l'espace inutilisé, mais n'est pas sans risque. Assurez-vous d'avoir sauvegardé tout ce qu'il y a d'important sur ce disque avant de récupérer de l'espace."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Remplacer l'installation actuelle tout en conservant les fichiers dans /home."
 ],
 "Report Issue": [
  null,
  "Signaler un problème"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Signalez un problème ou envoyez vos commentaires en ouvrant le formulaire Bugzilla de saisie de bug, accessible $0."
 ],
 "Report issue": [
  null,
  "Signaler un problème"
 ],
 "Reporting issue...": [
  null,
  "Signalement du problème..."
 ],
 "Required": [
  null,
  "Requis"
 ],
 "Requirements": [
  null,
  "Prérequis"
 ],
 "Rescan devices": [
  null,
  "Scanner à nouveau les périphériques"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Échec du scan des disques."
 ],
 "Resize": [
  null,
  "Redimensionner"
 ],
 "Resize partition": [
  null,
  "Redimensionner la partition"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Redimensionnement des partitions suivantes (taille originale : $0) : $1"
 ],
 "Restrict access to the report": [
  null,
  "Restreindre l'accès au rapport"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Restreint l'accès au rapport au groupe $0. $1"
 ],
 "Return to installation": [
  null,
  "Retour vers l'installation"
 ],
 "Return to storage editor": [
  null,
  "Revenir dans l'éditeur de stockage"
 ],
 "Review and install": [
  null,
  "Examiner et installer"
 ],
 "Root account has been configured": [
  null,
  "Le compte root a été configuré"
 ],
 "Root account is enabled": [
  null,
  "Le compte root est activé"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Le compte root est activé, mais aucun compte utilisateur n'a été configuré"
 ],
 "Root password has been set.": [
  null,
  "Le mot de passe administrateur a été défini."
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scannez le code QR avec votre téléphone ou visitez :"
 ],
 "Search for a language": [
  null,
  "Rechercher une langue"
 ],
 "Search for additional software": [
  null,
  "Rechercher des logiciels supplémentaires"
 ],
 "Search for an environment": [
  null,
  "Rechercher un environnement"
 ],
 "Search keyboard layout": [
  null,
  "Rechercher une disposition de clavier"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Sécurisez vos données à l'aide du chiffrement au niveau du disque. S'applique uniquement aux nouvelles partitions."
 ],
 "Select": [
  null,
  "Sélectionner"
 ],
 "Select a device": [
  null,
  "Sélectionner un périphérique"
 ],
 "Select city": [
  null,
  "Sélectionner une ville"
 ],
 "Select destination": [
  null,
  "Sélectionnez la destination"
 ],
 "Select region": [
  null,
  "Sélectionner une région"
 ],
 "Selected (top = current)": [
  null,
  "Sélectionnées (en haut = actuelle)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Le format du périphérique sélectionné '$0' ne peut pas être reformaté."
 ],
 "Send us feedback on your installation": [
  null,
  "Donnez-nous votre avis sur votre expérience d'installation"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Server is not reachable": [
  null,
  "Impossible d'atteindre le serveur"
 ],
 "Set custom hostname": [
  null,
  "Définir un nom d'hôte personnalisé"
 ],
 "Share disk with other operating systems": [
  null,
  "Partager le disque avec d'autres systèmes d'exploitation"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Partager le disque avec les systèmes d'exploitation : $0"
 ],
 "Show AM/PM": [
  null,
  "Afficher AM/PM"
 ],
 "Show API key": [
  null,
  "Afficher la clé d'API"
 ],
 "Show PIN": [
  null,
  "Afficher le code PIN"
 ],
 "Show confirmed password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show passphrase": [
  null,
  "Afficher la phrase secrète"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Software installation": [
  null,
  "Installation des logiciels"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Installation des logiciels : Configuration du stockage terminée. Les logiciels sont maintenant en cours d'installation sur votre appareil."
 ],
 "Software selection": [
  null,
  "Sélection des logiciels"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Certaines étapes d'installation doivent encore être complétées avant de pouvoir continuer."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Certaines partitions requises sont manquantes : $0"
 ],
 "Space": [
  null,
  "Espace"
 ],
 "Stacktrace": [
  null,
  "Trace d'appels"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Storage configuration": [
  null,
  "Configuration du stockage"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuration du stockage : Le stockage est en cours de configuration."
 ],
 "Storage editor": [
  null,
  "Éditeur de stockage"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Le stockage est basé sur la configuration provenant du menu 'Modifier le stockage'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Le schéma de stockage est défini par le fichier Kickstart. Le schéma de partitionnement planifié peut être examiné à l'étape de résumé."
 ],
 "Storage plugin failed": [
  null,
  "Défaillance du plugin stockage"
 ],
 "Storage requirements not met": [
  null,
  "Prérequis de stockage non respectés"
 ],
 "Strong": [
  null,
  "Fort"
 ],
 "Successfully installed": [
  null,
  "Installation réussie"
 ],
 "Successfully unlocked $0.": [
  null,
  "Déverrouillage de $0 réussi."
 ],
 "Suggested keyboards": [
  null,
  "Claviers suggérés"
 ],
 "Suggested languages": [
  null,
  "Langues suggérées"
 ],
 "System": [
  null,
  "Système"
 ],
 "System configuration": [
  null,
  "Configuration du système"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuration du système : Installation des logiciels terminée. Le système est maintenant en cours de configuration."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "L'installation Anaconda s'est arrêtée de manière inattendue."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Les bugs ouverts suivants peuvent être liés à votre problème. Examinez-les avant de créer un nouveau signalement."
 ],
 "The following user will be created:": [
  null,
  "L'utilisateur suivant sera créé :",
  "Les utilisateurs suivants seront créés :"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "L'installation nécessite $0 d'espace disque, mais la capacité des disques sélectionnés n'est que de $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Le programme d'installation ne peut pas continuer en raison d'une erreur critique."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Le programme d'installation ne peut pas continuer en raison d'une erreur critique : $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "La phrase secrète que vous avez fournie contient des caractères non ASCII. Vous pourriez ne pas être en mesure de changer de disposition de clavier au moment de le taper."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "La disposition de clavier par défaut sélectionnée ne prend pas en charge les caractères ASCII. Veuillez définir par défaut une disposition compatible ASCII."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "L'éditeur de stockage vous permet de redimensionner, supprimer et créer des partitions. Il peut configurer LVM et bien plus encore. Il est censé être utilisé en tant qu'utilitaire avancé, et n'est pas destiné aux installations standards."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Ces fichiers journaux sont susceptibles de contenir des informations sensibles, telles que des adresses IP, des noms d'utilisateur·rices ou d'autres informations sur le système."
 ],
 "This hostname can't be submitted": [
  null,
  "Ce nom d'hôte ne peut pas être envoyé"
 ],
 "This is unstable, pre-release software": [
  null,
  "Il s'agit d'un logiciel instable, en préversion"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Cette disposition sera utilisée pour déverrouiller votre système lors du démarrage"
 ],
 "This may take a moment": [
  null,
  "Cela peut prendre un court instant"
 ],
 "This will take a few moments": [
  null,
  "Cela prendra quelques instants"
 ],
 "Time": [
  null,
  "Heure"
 ],
 "Timezone": [
  null,
  "Fuseau horaire"
 ],
 "Title": [
  null,
  "Titre"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Redémarrez votre système pour commencer à utiliser $0."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Pour continuer, sélectionnez les périphériques sur lesquels effectuer l'installation."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Pour utiliser cette option, redimensionnez ou supprimez les partitions existantes afin de libérer au moins $0."
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Impossible de planifier la suppression de $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Impossible de planifier le redimensionnement de $0"
 ],
 "Undo last action": [
  null,
  "Annuler la dernière action"
 ],
 "Unlock": [
  null,
  "Déverrouiller"
 ],
 "Unlock encrypted devices": [
  null,
  "Déverrouiller les périphériques chiffrés"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Déverrouillez les partitions chiffrées pour conserver les données existantes et afficher des méthodes d'installation supplémentaires."
 ],
 "Use configured storage": [
  null,
  "Utiliser le stockage configuré"
 ],
 "Use entire disk": [
  null,
  "Utiliser le disque tout entier"
 ],
 "Use free space": [
  null,
  "Utiliser l'espace libre"
 ],
 "Use local account": [
  null,
  "Utiliser un compte local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Utiliser le périphérique RAID pour le partitionnement automatique"
 ],
 "User creation": [
  null,
  "Création de l’utilisateur"
 ],
 "User name": [
  null,
  "Nom d'utilisateur"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Le nom d'utilisateur ne peut contenir que : des lettres de a à z, des chiffres de 0 à 9, des tirets $0, des points $1, des tirets bas $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Le nom d'utilisateur ne doit pas être un mot réservé"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Les noms d'utilisateurs ne doivent pas dépasser 32 caractères"
 ],
 "Validating...": [
  null,
  "Validation..."
 ],
 "Weak": [
  null,
  "Faible"
 ],
 "Welcome": [
  null,
  "Bienvenue"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Bienvenue sur Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Bienvenue, installons $0 ensemble."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "En envoyant ce rapport de bug, les fichiers journaux suivants seront uploadés automatiquement : $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Les partitions Windows avec chiffrement BitLocker ne peuvent pas être redimensionnées"
 ],
 "You can close this browser window now.": [
  null,
  "Vous pouvez maintenant fermer cette fenêtre de navigateur."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Vous pouvez choisir de libérer suffisamment d'espace ici et laisser le programme d'installation gérer le reste, ou bien de configurer manuellement les partitions."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Vous pouvez générer une clé d'API pour votre compte Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Pour continuer, vous devez activer le compte root ou créer un compte utilisateur local."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Vous devez être connecté·e à un réseau pour activer la date et l'heure automatiques."
 ],
 "Your progress will not be saved.": [
  null,
  "Votre progression ne sera pas sauvegardée."
 ],
 "completed step": [
  null,
  "étape terminée"
 ],
 "current step": [
  null,
  "étape actuelle"
 ],
 "delete": [
  null,
  "supprimer"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "encrypt": [
  null,
  "chiffrer"
 ],
 "encrypted": [
  null,
  "chiffré"
 ],
 "extended partition": [
  null,
  "partition étendue"
 ],
 "format as $0": [
  null,
  "formater en $0"
 ],
 "here": [
  null,
  "ici"
 ],
 "incomplete": [
  null,
  "incomplète"
 ],
 "mount": [
  null,
  "monter"
 ],
 "pending step": [
  null,
  "étape en attente"
 ],
 "report the issue manually": [
  null,
  "signaler le problème manuellement"
 ],
 "resized from $0": [
  null,
  "redimensionné (taille précédente : $0)"
 ],
 "shrink": [
  null,
  "réduire"
 ],
 "shrink to $0": [
  null,
  "réduire à $0"
 ],
 "transient, will use DHCP": [
  null,
  "transitoire, DHCP sera utilisé"
 ],
 "undo": [
  null,
  "annuler"
 ]
});
