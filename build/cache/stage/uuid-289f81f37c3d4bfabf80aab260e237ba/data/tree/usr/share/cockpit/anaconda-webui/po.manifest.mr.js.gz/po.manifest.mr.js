cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "mr",
  "language-direction": "ltr"
 }
});
