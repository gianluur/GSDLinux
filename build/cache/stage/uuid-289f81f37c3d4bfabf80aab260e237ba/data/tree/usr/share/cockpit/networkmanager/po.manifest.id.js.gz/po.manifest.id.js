cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Layanan"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "network": [
  null,
  "jaringan"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "antarmuka"
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "bond"
 ],
 "team": [
  null,
  "tim"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zona"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Mengelola bond jaringan"
 ],
 "Managing networking teams": [
  null,
  "Mengelola tim jaringan"
 ],
 "Managing networking bridges": [
  null,
  "Mengelola jembatan jaringan"
 ],
 "Managing VLANs": [
  null,
  "Mengelola VLAN"
 ],
 "Managing firewall": [
  null,
  "Mengelola firewall"
 ]
});
