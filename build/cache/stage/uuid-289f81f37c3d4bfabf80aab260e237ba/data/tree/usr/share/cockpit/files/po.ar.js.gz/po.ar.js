cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Cockpit Files": [
  null,
  "ملفات Cockpit"
 ],
 "Home": [
  null,
  "المنزل"
 ],
 "Unable to create bookmark directory": [
  null,
  "غير قادر على إنشاء علامة مرجعية لدليل"
 ],
 "Unable to save bookmark file": [
  null,
  "غير قادر على حفظ ملف العلامة المرجعية"
 ],
 "Remove from bookmarks": [
  null,
  "الإزالة من العلامات المرجعية"
 ],
 "Add to bookmarks": [
  null,
  "إضافة إلى العلامات المرجعية"
 ],
 "Bookmarks": [
  null,
  "العلامات المرجعية"
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Edit path": [
  null,
  "عدل المسار"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Largest size": [
  null,
  "أكبر حجم"
 ],
 "Smallest size": [
  null,
  "أصغر حجم"
 ],
 "Modified": [
  null,
  "مُعدَّل"
 ],
 "First modified": [
  null,
  "التعديل الأول"
 ],
 "Last modified": [
  null,
  "آخر تعديل"
 ],
 "Owner": [
  null,
  "المالك"
 ],
 "Owner ascending": [
  null,
  "مالك (تصاعدي)"
 ],
 "Owner descending": [
  null,
  "مالك (تنازلي)"
 ],
 "Permissions": [
  null,
  "الصلاحيات"
 ],
 "Most permissive": [
  null,
  "الأكثر تَساهُلًا"
 ],
 "Least permissive": [
  null,
  "أقل تساهلاً"
 ],
 "Show keyboard shortcuts": [
  null,
  "أظهر اختصارات لوحة المفاتيح"
 ],
 "Filter directory": [
  null,
  "دليل التصفية"
 ],
 "Display as a list": [
  null,
  "إظهار كقائمة"
 ],
 "Display as a grid": [
  null,
  "إظهار كشبكة"
 ],
 "Sort": [
  null,
  "ترتيب"
 ],
 "Hide hidden items": [
  null,
  "اخفِ العناصر المخفية"
 ],
 "Show hidden items": [
  null,
  "أظهر العناصر المخفية"
 ],
 "$0 files": [
  null,
  "$0 ملفات"
 ],
 "Uploaded as $0, $1": [
  null,
  "محمّل كـ $0، $1"
 ],
 "Replace file $0?": [
  null,
  "استبدال الملف $0؟"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "يوجد ملف بنفس الاسم بالفعل في \"$0\". سيؤدي استبداله إلى الكتابة فوق محتواه."
 ],
 "New file": [
  null,
  "ملف جديد"
 ],
 "Original file on server": [
  null,
  "الملف الأصلي على الخادم"
 ],
 "Apply this action to all conflicting files": [
  null,
  "قم بتطبيق هذا الإجراء على جميع الملفات المتعارضة"
 ],
 "Replace": [
  null,
  "استبدل"
 ],
 "Keep original": [
  null,
  "حافظ على الأصل"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Upload error": [
  null,
  "خطأ في الرفع"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "غير قادر على نقل الملف المرفوع إلى وجهته النهائية"
 ],
 "Cancelled": [
  null,
  "تم إلغاؤه"
 ],
 "Cancelled upload of $0": [
  null,
  "تم إلغاء تحميل $0"
 ],
 "File uploaded": [
  null,
  "تم تحميل الملف"
 ],
 "Files uploaded": [
  null,
  "الملفات التي تم تحميلها"
 ],
 "Change permissions": [
  null,
  "تغيير الصلاحيات"
 ],
 "Uploads": [
  null,
  "عمليات التحميل"
 ],
 "Cancel upload of $0": [
  null,
  "إلغاء تحميل $0"
 ],
 "Upload $0% completed": [
  null,
  "اكتمل الرفع بنسبة $0%"
 ],
 "Upload": [
  null,
  "ارفع"
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "Execute-only": [
  null,
  "التنفيذ فقط"
 ],
 "Write-only": [
  null,
  "الكتابة-فقط"
 ],
 "Write and execute": [
  null,
  "الكتابة والتنفيذ"
 ],
 "Read-only": [
  null,
  "القراءة-فقط"
 ],
 "Read and execute": [
  null,
  "قراءة ثمَّ تنفيذ"
 ],
 "Read and write": [
  null,
  "قراءة وكتابة"
 ],
 "Read, write, and execute": [
  null,
  "قراءة، كتابة، وتنفيذ"
 ],
 "Block device": [
  null,
  "حجب الجحاز"
 ],
 "Character device": [
  null,
  "جهاز محوري"
 ],
 "Directory": [
  null,
  "دليل"
 ],
 "Named pipe": [
  null,
  "الأنبوب المسمى"
 ],
 "Symbolic link": [
  null,
  "رابط رمزي"
 ],
 "Regular file": [
  null,
  "ملف عادي"
 ],
 "Socket": [
  null,
  "مقبس الشبكة"
 ],
 "Name cannot be empty": [
  null,
  "لا يمكن أن يكون الاسم فارغاً"
 ],
 "Name too long": [
  null,
  "الاسم كبير جداً"
 ],
 "Name cannot include a /": [
  null,
  "لا يمكن أن يتضمن الاسم /"
 ],
 "Filename is the same as original name": [
  null,
  "اسم الملف هو نفس الاسم الأصلي"
 ],
 "Directory with the same name exists": [
  null,
  "الدليل موجود بنفس الاسم"
 ],
 "File exists": [
  null,
  "الملف موجود"
 ],
 "Pasting failed": [
  null,
  "فشل اللصق"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "الملف \"$0\" موجود ، ولن يؤدي اللصق لاستبداله."
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Create directory": [
  null,
  "إنشاء دليل"
 ],
 "Create file": [
  null,
  "إنشاء ملف"
 ],
 "Edit permissions": [
  null,
  "عدِّل الصلاحيات"
 ],
 "Open in terminal": [
  null,
  "فتح في الطرفية"
 ],
 "Open text file": [
  null,
  "افتح الملف النصي"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Rename": [
  null,
  "أعد التسمية"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Download": [
  null,
  "نزِّل"
 ],
 "Create link": [
  null,
  "إنشاء رابط"
 ],
 "Drop files to upload": [
  null,
  "أسقط الملفات للتحميل"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "لا يمكن إسقاط الملفات، هناك تحميل آخر قيد المعالجة بالفعل"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Go up a directory": [
  null,
  "الانتقال للأعلى"
 ],
 "Go back": [
  null,
  "الرجوع للوراء"
 ],
 "Go forward": [
  null,
  "التقدّم للأمام"
 ],
 "Activate selected item, enter directory": [
  null,
  "تنشيط العنصر المحدد، ادخل الدليل"
 ],
 "Rename selected file or directory": [
  null,
  "أعد تسممية الملف أو الدليل المحدد"
 ],
 "Create new directory": [
  null,
  "إنشاء دليل جديد"
 ],
 "Copy selected file or directory": [
  null,
  "لنسخ المجلد أو الدليل المحدد"
 ],
 "Paste file or directory": [
  null,
  "لصق الملف أو الدليل"
 ],
 "Select all": [
  null,
  "حدد الكل"
 ],
 "Save current file": [
  null,
  ""
 ],
 "Close editor": [
  null,
  ""
 ],
 "Keyboard shortcuts": [
  null,
  "اختصارات لوحة المفاتيح"
 ],
 "Navigation": [
  null,
  "التنقل"
 ],
 "Editing": [
  null,
  "تعديل"
 ],
 "Force delete $0 items": [
  null,
  "حذف $0 عنصراً بشكل إجباري"
 ],
 "Delete $0 items?": [
  null,
  "حذف $0 عنصراً؟"
 ],
 "Force delete file $0?": [
  null,
  "حذف الملف $0 بشكل إجباري؟"
 ],
 "Delete file $0?": [
  null,
  "حذف الملف $0؟"
 ],
 "Force delete link $0?": [
  null,
  "حذف الرابط $0 بشكل إجباري؟"
 ],
 "Delete link $0?": [
  null,
  "حذف الرابط $0؟"
 ],
 "Force delete directory $0?": [
  null,
  "حذف الدليل $0 بشكل إجباري؟"
 ],
 "Delete directory $0?": [
  null,
  "حذف الدليل $0؟"
 ],
 "Force delete $0": [
  null,
  "حذف $0 بشكل إجباري"
 ],
 "Delete $0?": [
  null,
  "حذف $0؟"
 ],
 "No access": [
  null,
  "لا وصول"
 ],
 "Missing type": [
  null,
  "نوع مفقود"
 ],
 "Collapse": [
  null,
  "انهيار"
 ],
 "Show all files": [
  null,
  "أظهر جميع الملفات"
 ],
 "$0 permissions": [
  null,
  "$0 صلاحيات"
 ],
 "Permissions for $0 files": [
  null,
  "الصلاحيات لـ $0 ملفاً"
 ],
 "Ownership": [
  null,
  "الملكية"
 ],
 "Group": [
  null,
  "مجموعة"
 ],
 "Access": [
  null,
  "وصول"
 ],
 "Owner access": [
  null,
  "وصول المالك"
 ],
 "Group access": [
  null,
  "دخول المجموعة"
 ],
 "Others access": [
  null,
  "وصول آخرين"
 ],
 "Security context": [
  null,
  "السياق الأمني"
 ],
 "Set executable as program": [
  null,
  "اجعله قابلاً للتنفيذ كبرنامج"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Change permissions for enclosed files": [
  null,
  "تغيير صلاحيات الملفات المرفقة"
 ],
 "(original owner)": [
  null,
  "(المالك الأصلي)"
 ],
 "keep original owners": [
  null,
  "الحفاظ على المُلَّاك الأصليين"
 ],
 "Paste as owner": [
  null,
  "لصق كمالك"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "الملفات التي يتم لصقها لها مالك مختلف. بشكل افتراضي، سيتم تغيير الملكية لتتناسب مع الدليل الوجهة."
 ],
 "New owner": [
  null,
  "مالك جديد"
 ],
 "Overwrite": [
  null,
  "الكتابة فوق"
 ],
 "New filename": [
  null,
  "اسم ملف جديد"
 ],
 "New name": [
  null,
  "اسم جديد"
 ],
 "Rename $0?": [
  null,
  "إعادة تسمية $0؟"
 ],
 "link to $0": [
  null,
  "ربط بـ $0"
 ],
 "Create link to $0": [
  null,
  "إنشاء رابط إلى $0"
 ],
 "Target": [
  null,
  "الهدف"
 ],
 "Symlink name": [
  null,
  "اسم الرابط الرمزي"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Absolute vs. Relative": [
  null,
  "المطلق مقابل النسبي"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "تعتبر الروابط الرمزية المطلقة نموذجية عند الإشارة إلى الملفات أو الدلائل التي لن تتحرك، مثل ملفات النظام."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "الروابط الرمزية النسبية مفيدة عندما يكون كلٌ من الرابط والهدف معرضين للحركة في نفس الوقت، كما هو الحال عند إعادة تسمية أو نقل الدليل الأب."
 ],
 "Absolute": [
  null,
  "مطلق"
 ],
 "Relative": [
  null,
  "نسبي"
 ],
 "The file has been removed on disk": [
  null,
  "الملف تمت إزالته من القرص"
 ],
 "The existing file changed unexpectedly": [
  null,
  "الملف الموجود تغيَّر بشكل غير متوقع"
 ],
 "Edit $0": [
  null,
  "عدِّل $0"
 ],
 "View $0": [
  null,
  "عرض $0"
 ],
 "The file has changed on disk": [
  null,
  "تم تغيير الملف على القرص"
 ],
 "Reload": [
  null,
  "إعادة تحميل"
 ],
 "Ignore": [
  null,
  "تجاهل"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Save changes?": [
  null,
  ""
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  ""
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  ""
 ],
 "Discard": [
  null,
  ""
 ],
 "File name": [
  null,
  "اسم الملف"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Cannot create file in current directory": [
  null,
  "يتعذر إنشاء ملف في الدليل الحالي"
 ],
 "Permission denied": [
  null,
  "الإذن مرفوض"
 ],
 "Directory name cannot be empty": [
  null,
  "اسم الدليل لا يمكن أن يكون فارغاً"
 ],
 "Directory name too long": [
  null,
  "اسم الدليل كبير جداَ"
 ],
 "Directory name cannot include a /": [
  null,
  "اسم الدليل لا يمكن أن يتضمن /"
 ],
 "Directory name": [
  null,
  "اسم الدليل"
 ],
 "Directory owner": [
  null,
  "مدير الدليل"
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "Clear filter": [
  null,
  "إزالة عامل التصفية"
 ],
 "Directory is empty": [
  null,
  "الدليل فارغ"
 ],
 "$0 item is hidden": [
  null,
  "لا عنصر مخفي",
  "عنصر واحد مخفي",
  "عنصران مخفيان",
  "$0 عناصر مخفية",
  "$0 عنصراً مخفياً",
  "$0 عنصراً مخفياً"
 ],
 "Folder": [
  null,
  ""
 ],
 "Others": [
  null,
  "الآخرون"
 ],
 "$0 files selected": [
  null,
  "$0 ملفاً محدداً"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "الدليل يحوي على $0 دلائل، $1 ملفات"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "المجلد يحتوي على $0 مجلدات، $1 ملفات $2 مخفية"
 ],
 "User": [
  null,
  "المستخدم"
 ]
});
