cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Службы"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "time": [
  null,
  "время"
 ],
 "date": [
  null,
  "дата"
 ],
 "restart": [
  null,
  "перезапустить"
 ],
 "shut": [
  null,
  "закрывать"
 ],
 "domain": [
  null,
  "домен"
 ],
 "machine": [
  null,
  "компьютер"
 ],
 "operating system": [
  null,
  "операционная система"
 ],
 "os": [
  null,
  "ОС"
 ],
 "asset tag": [
  null,
  "тег актива"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "питание"
 ],
 "version": [
  null,
  "версия"
 ],
 "host": [
  null,
  "узел"
 ],
 "hardware": [
  null,
  "оборудование"
 ],
 "mitigation": [
  null,
  "защита"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "память"
 ],
 "cpu": [
  null,
  "процессор"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ОЗУ"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "последовательный"
 ],
 "graphs": [
  null,
  "графики"
 ],
 "metrics": [
  null,
  "метрики"
 ],
 "history": [
  null,
  "история"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "диски"
 ],
 "network": [
  null,
  "сеть"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "производительность"
 ],
 "Configuring system settings": [
  null,
  "Настройка параметров системы"
 ],
 "service": [
  null,
  "служба"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "цель"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "таймер"
 ],
 "path": [
  null,
  "путь"
 ],
 "unit": [
  null,
  "блок"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "загрузка"
 ],
 "mask": [
  null,
  "маска"
 ],
 "unmask": [
  null,
  "снять маску"
 ],
 "enable": [
  null,
  "включить"
 ],
 "disable": [
  null,
  "отключить"
 ],
 "Managing services": [
  null,
  "Управление службами"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "warning": [
  null,
  "предупреждение"
 ],
 "error": [
  null,
  "ошибка"
 ],
 "debug": [
  null,
  "отладка"
 ],
 "crash": [
  null,
  "сбой"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "Reviewing logs": [
  null,
  "Просмотр журналов"
 ],
 "console": [
  null,
  "консоль"
 ],
 "command": [
  null,
  "команда"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "оболочка"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
