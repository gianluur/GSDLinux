cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "User name": [
  null,
  "Nazwa użytkownika"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Comment": [
  null,
  "Komentarz"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Fingerprint": [
  null,
  "Odcisk"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Change password": [
  null,
  "Zmień hasło"
 ],
 "Password changed successfully": [
  null,
  "Pomyślnie zmieniono hasło"
 ],
 "New password": [
  null,
  "Nowe hasło"
 ],
 "Confirm password": [
  null,
  "Potwierdź hasło"
 ],
 "Password tip": [
  null,
  "Wskazówka na temat hasła"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Wskazówka: ustawienie hasła klucza na takie samo, jak hasło logowania automatycznie uwierzytelni w innych systemach."
 ],
 "Unlock key $0": [
  null,
  "Odblokuj klucz $0"
 ],
 "Unlock": [
  null,
  "Odblokuj"
 ],
 "Add key": [
  null,
  "Dodaj klucz"
 ],
 "SSH keys": [
  null,
  "Klucze SSH"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Użycie poniższych kluczy do uwierzytelniania w innych systemach"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Toggle": [
  null,
  "Przełącz"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Public key": [
  null,
  "Klucz publiczny"
 ],
 "Use key": [
  null,
  "Użyj klucza"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Hosts": [
  null,
  "Komputery"
 ],
 "Connection error": [
  null,
  "Błąd połączenia"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Add new host": [
  null,
  "Dodaj nowy komputer"
 ],
 "Host": [
  null,
  "Gospodarz"
 ],
 "Stop editing hosts": [
  null,
  "Zatrzymaj modyfikowanie komputerów"
 ],
 "Edit hosts": [
  null,
  "Modyfikuj komputery"
 ],
 "active": [
  null,
  "aktywne"
 ],
 "Active pages": [
  null,
  "Aktywne strony"
 ],
 "Page name": [
  null,
  "Nazwa strony"
 ],
 "There are currently no active pages": [
  null,
  "Obecnie nie ma aktywnych stron"
 ],
 "Close selected pages": [
  null,
  "Zamknij zaznaczone strony"
 ],
 "$0 documentation": [
  null,
  "dokumentacja $0"
 ],
 "About Web Console": [
  null,
  "O programie"
 ],
 "Style": [
  null,
  "Styl"
 ],
 "Default": [
  null,
  "Domyślne"
 ],
 "Light": [
  null,
  "Jasny"
 ],
 "Dark": [
  null,
  "Ciemny"
 ],
 "Display language": [
  null,
  "Język"
 ],
 "Log out": [
  null,
  "Wyloguj"
 ],
 "Ooops!": [
  null,
  "Ups!"
 ],
 "Help": [
  null,
  "Pomoc"
 ],
 "Session": [
  null,
  "Sesja"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Na warunkach licencji GNU LGPL w wersji 2.1"
 ],
 "Web Console": [
  null,
  "Konsola internetowa"
 ],
 "Web console logo": [
  null,
  "Logo konsoli internetowej"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit to interaktywny interfejs do administrowania serwerami Linux."
 ],
 "Project website": [
  null,
  "Strona projektu"
 ],
 "Loading packages...": [
  null,
  "Wczytywanie pakietów…"
 ],
 "Choose the language to be used in the application": [
  null,
  "Proszę wybrać język używany w aplikacji"
 ],
 "Filter menu items": [
  null,
  "Filtruj elementy menu"
 ],
 "No languages match": [
  null,
  "Brak pasujących języków"
 ],
 "Select": [
  null,
  "Wybierz"
 ],
 "Unexpected error": [
  null,
  "Nieoczekiwany błąd"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Wystąpił nieoczekiwany wewnętrzny błąd w programie Cockpit."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "w większości przeglądarek"
 ],
 "System": [
  null,
  "System"
 ],
 "Search": [
  null,
  "Szukaj"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "Clear search": [
  null,
  "Wyczyść wyszukiwanie"
 ],
 "Contains:": [
  null,
  "Zawiera:"
 ],
 "Apps": [
  null,
  "Aplikacje"
 ],
 "Tools": [
  null,
  "Narzędzia"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Nie można skontaktować się z podanym komputerem $0. Proszę się upewnić, że ma on uruchomioną usługę ssh na porcie $1 lub podać inny port w adresie."
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  ""
 ],
 "Connect": [
  null,
  "Połącz"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Adres IP lub nazwa komputera nie może zawierać spacji."
 ],
 "This machine has already been added.": [
  null,
  "Ten komputer został już dodany."
 ],
 "Failed to add machine: $0": [
  null,
  "Dodanie komputera się nie powiodło: $0"
 ],
 "Edit host": [
  null,
  "Modyfikuj komputer"
 ],
 "Set": [
  null,
  "Ustaw"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Może być nazwą komputera, adresem IP, nazwą aliasu lub adresem URI typu ssh://"
 ],
 "When empty, connect with the current user": [
  null,
  "Pozostawienie pustej spowoduje połączenie z obecnym użytkownikiem"
 ],
 "Color": [
  null,
  "Kolor"
 ],
 "Failed to edit machine: $0": [
  null,
  "Modyfikacja komputera się nie powiodła: $0"
 ],
 "Could not contact $0": [
  null,
  "Nie można skontaktować się z $0"
 ],
 "Update": [
  null,
  "Zaktualizuj"
 ],
 "Unable to contact $0.": [
  null,
  "Nie można skontaktować się z $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "Czy sshd jest uruchomione na innym porcie?"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "New host: $0": [
  null,
  "Nowy komputer: $0"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Szkodliwe strony na zdalnym komputerze mogą mieć wpływ na pozostałe połączone komputery"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "The new key password can not be empty": [
  null,
  "Nowe hasło klucza nie może być puste"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Nie można zalogować się w $0 za pomocą uwierzytelniania kluczem SSH. Proszę podać hasło. Można później skonfigurować klucze SSH do automatycznego logowania."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Można zmienić hasło klucza do automatycznego logowania."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Aby umożliwić w przyszłości logowanie na komputerze $0 jako użytkownik $1 bez hasła, należy użyć hasła logowania użytkownika $2 na komputerze $3 jako hasło klucza lub pozostawić hasło klucza puste."
 ],
 "Change the password of $0": [
  null,
  "Zmień hasło klucza $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Zmieniając hasło klucza SSH $0 na hasło logowania użytkownika $1 na komputerze $2, klucz automatycznie stanie się dostępny i w przyszłości będzie można logować się na komputerze $3 bez hasła."
 ],
 "New key password": [
  null,
  "Nowe hasło klucza"
 ],
 "Confirm new key password": [
  null,
  "Potwierdź nowe hasło klucza"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Umożliwi to logowanie bez hasła w przyszłości."
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "Automatic login": [
  null,
  "Automatyczne logowanie"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Wylogowano z powodu nieaktywności."
 ],
 "Connection failed": [
  null,
  "Połączenie się nie powiodło"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Wystąpił nieoczekiwany błąd podczas łączenia z maszyną."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Być może w dzienniku znajdują się komunikaty związane z niepowodzeniem:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Użytkownicy przeglądarki Safari muszą zaimportować certyfikat samopodpisującego CA i oznaczyć go jako zaufany:"
 ],
 "Reconnect": [
  null,
  "Połącz ponownie"
 ],
 "Disconnected": [
  null,
  "Rozłączono"
 ],
 "The machine is rebooting": [
  null,
  "Komputer jest ponownie uruchamiany"
 ],
 "Connecting to the machine": [
  null,
  "Łączenie z komputerem"
 ],
 "Not connected to host": [
  null,
  "Nie połączono z komputerem"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nie można połączyć się z nieznanym komputerem"
 ],
 "Session is about to expire": [
  null,
  "Sesja zaraz wygaśnie"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Wylogowanie nastąpi za $0 s."
 ],
 "Continue session": [
  null,
  "Kontynuuj sesję"
 ],
 "Skip to content": [
  null,
  "Przejdź do treści"
 ],
 "Skip main navigation": [
  null,
  "Pomiń główną nawigację"
 ],
 "Permission denied": [
  null,
  "Odmowa dostępu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "You now have administrative access.": [
  null,
  "Uzyskano dostęp administracyjny."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Proszę się uwierzytelnić, aby uzyskać dostęp administracyjny"
 ],
 "Switch to administrative access": [
  null,
  "Przełącz na dostęp administracyjny"
 ],
 "Authenticate": [
  null,
  "Uwierzytelnij"
 ],
 "Administrative access": [
  null,
  "Dostęp administracyjny"
 ],
 "Problem becoming administrator": [
  null,
  "Problem podczas zostawania administratorem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Ogranicz dostęp"
 ],
 "Switch to limited access": [
  null,
  "Przełącz na ograniczony dostęp"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Tryb ograniczonego dostępu ogranicza uprawnienia administracyjne. Część konsoli internetowej będzie miała zmniejszoną funkcjonalność."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Używana przeglądarka będzie pamiętała poziom dostępu użytkownika między sesjami."
 ],
 "Limited access": [
  null,
  "Ograniczony dostęp"
 ],
 "Turn on administrative access": [
  null,
  "Włącz dostęp administracyjny"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "PackageKit reported error code $0": [
  null,
  "Usługa PackageKit zgłosiła kod błędu $0"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrowanie"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "System plików"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Brak wyników"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Plik"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ]
});
