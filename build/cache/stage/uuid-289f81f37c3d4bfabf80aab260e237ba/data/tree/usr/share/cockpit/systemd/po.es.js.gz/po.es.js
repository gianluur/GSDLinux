cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Journal": [
  null,
  "Bitácora"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Información del hardware"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "active": [
  null,
  "activo"
 ],
 "Default": [
  null,
  "Predeterminado"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Dark": [
  null,
  "Oscuro"
 ],
 "Help": [
  null,
  "Ayuda"
 ],
 "Select": [
  null,
  "Seleccionar"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No fue capaz de iniciar sesión en $0. El hospedaje no acepta inicio de sesión por contraseña ni ninguna de sus claves SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH nueva y autorícela"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Authorize SSH key": [
  null,
  "Autorice la clave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "Permission denied": [
  null,
  "Permiso denegado"
 ],
 "Clear input value": [
  null,
  "Vaciar valor de entrada"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "Create $0": [
  null,
  "Crear $0"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "You now have administrative access.": [
  null,
  "Ahora tienes acceso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "No hay métodos disponibles para obtener acceso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentíquese para obtener acceso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Cambiar a acceso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acceso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema al cambiar a administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acceso"
 ],
 "Switch to limited access": [
  null,
  "Pasar a acceso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "El modo de acceso limitado restringe los privilegios administrativos. Algunas partes de la consola web tendrán funcionalidad reducida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Su navegador recordará su nivel de acceso entre sesiones."
 ],
 "Limited access": [
  null,
  "Acceso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar el acceso administrativo"
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "less than a minute ago": [
  null,
  "es menos que hace un minuto"
 ],
 "in less than a minute": [
  null,
  "es menos de un minuto"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Removing $0": [
  null,
  "Retirando $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Hospedaje desconocido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña."
 ],
 "SSH key login": [
  null,
  "Clave SSH de acceso"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportó un error con código $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "Row expansion": [
  null,
  "Fila de expansión"
 ],
 "Row select": [
  null,
  "Seleccionar fila"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Error durante la inicialización"
 ],
 "Failed": [
  null,
  "Falló"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Teclee para filtrar"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Sistema de archivos"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Archivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo inválido"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Select an option": [
  null,
  "Seleccione una opción"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 incorrecto"
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "$0 is not a directory": [
  null,
  "$0 no es un directorio"
 ],
 "$0 does not exist": [
  null,
  "$0 no existe"
 ],
 "Font size": [
  null,
  "Tamaño de la fuente"
 ],
 "Decrease by one": [
  null,
  "Disminuir en uno"
 ],
 "Increase by one": [
  null,
  "Incrementar en uno"
 ],
 "Appearance": [
  null,
  "Apariencia"
 ],
 "Black": [
  null,
  "Negro"
 ],
 "White": [
  null,
  "Blanco"
 ],
 "Reset": [
  null,
  "Reiniciar"
 ],
 "Unable to open directory": [
  null,
  "No es capaz de abrir directorio"
 ],
 "Running process prevents directory change": [
  null,
  "Ejecutar proceso previene cambio de directorio"
 ],
 "Change directory": [
  null,
  "Cambiar directorio"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Cambiar el directorio forzará detener el proceso actualmente ejecutándose. El proceso además puede ser detenido manualmente en el terminal antes de continuar."
 ],
 "Terminal not available": [
  null,
  "Terminal no está disponible"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Este navegador no soporta WebGL2."
 ],
 "unknown": [
  null,
  "desconocido"
 ],
 "Shutdown": [
  null,
  "Apagar"
 ],
 "running $0": [
  null,
  "ejecutando $0"
 ],
 "Current boot": [
  null,
  "Arranque actual"
 ],
 "Previous boot": [
  null,
  "Arranque previo"
 ],
 "Last 24 hours": [
  null,
  "Últimas 24 horas"
 ],
 "Last 7 days": [
  null,
  "Últimos 7 días"
 ],
 "Only emergency": [
  null,
  "Solo en caso de emergencia"
 ],
 "Alert and above": [
  null,
  "Alerta y superior"
 ],
 "Critical and above": [
  null,
  "Crítico y superior"
 ],
 "Error and above": [
  null,
  "Error y superior"
 ],
 "Warning and above": [
  null,
  "Aviso y superior"
 ],
 "Notice and above": [
  null,
  "Notice y superior"
 ],
 "Info and above": [
  null,
  "Informativo y superior"
 ],
 "Debug and above": [
  null,
  "Debug y superior"
 ],
 "Toggle filters": [
  null,
  "Alternar filtros"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Priority": [
  null,
  "Prioridad"
 ],
 "Identifier": [
  null,
  "Identificador"
 ],
 "Filters": [
  null,
  "Filtros"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Resume": [
  null,
  "Reanudar"
 ],
 "All": [
  null,
  "Todo"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Las especificaciones de fecha deberían estar en formato YYYY-MM-DD hh:mm:ss. De igual manera, las cadenas 'yesterday', 'today', 'tomorrow' también se entienden. 'now' se refiere al tiempo actual. Finalmente, se pueden especificar tiempos relativos con prefijo '-','+'"
 ],
 "Since": [
  null,
  "Desde"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Comenzar a mostrar entradas desde la fecha especificada a la más reciente, incluyéndola."
 ],
 "Until": [
  null,
  "Hasta"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Comenzar a mostrar entradas desde la fecha especificada a la más antigua, incluyéndola."
 ],
 "Boot": [
  null,
  "Arranque"
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostrar mensajes de un arranque específico."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Esto añadirá una entrada para '_BOOT_ID=' en la búsqueda. Si no se especifica se mostrarán los registros del arranque actual. Si se omite el ID del arranque, un valor positivo se usará para buscar arranques desde el comienzo del registro, y un valor menor o igual que cero buscará los arranques desde el final del registro. Por ello, 1 significa el primer arranque encontrado en el registro por orden cronológico, 2 el segundo y así; mientras que -0 es el último arranque, -1 el anterior y así."
 ],
 "Unit": [
  null,
  "Unidad"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostrar mensajes para la unidad de systemd especificada."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Esto añadirá coincidencia para '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' y 'UNIT=' para encontrar todos los mensajes posibles de dicha unidad. Se pueden contener más unidades separadas por coma."
 ],
 "Free-form search": [
  null,
  "Búsqueda libre"
 ],
 "Show messages containing given string.": [
  null,
  "Muestra mensajes que contengan una cadena dada."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Se puede filtrar cualquier cadena de texto en los mensajes de los registros. La cadena también puede tener forma de expresión regular. También admite el filtrado por campos de registro de mensajes. Estos son valores separados por espacios, en forma CAMPO=VALOR, donde el valor puede ser una lista de valores posibles separados por comas."
 ],
 "journalctl manpage": [
  null,
  "Página de manual de journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiado al portapapeles con éxito"
 ],
 "Create timer": [
  null,
  "Crear un temporizador"
 ],
 "Edit timer": [
  null,
  "Editar el temporizador"
 ],
 "Timer creation failed": [
  null,
  "Fallo en la creación del temporizador"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Fallo al obtener las condiciones iniciales del temporizador"
 ],
 "Failed to get the timer command": [
  null,
  "Fallo al obtener el comando del temporizador"
 ],
 "This field cannot be empty": [
  null,
  "Este campo no puede estar vacío"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Solo se permiten caracteres alfanuméricos y : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Shell command": [
  null,
  "comando shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Este comando será ejecutado por /bin/sh."
 ],
 "Trigger": [
  null,
  "Disparador"
 ],
 "At specific time": [
  null,
  "A una hora específica"
 ],
 "After system boot": [
  null,
  "Después de que el sistema arranque"
 ],
 "Seconds": [
  null,
  "Segundos"
 ],
 "Minutes": [
  null,
  "Minutos"
 ],
 "Hours": [
  null,
  "Horas"
 ],
 "Weeks": [
  null,
  "Semanas"
 ],
 "Delay must be a number": [
  null,
  "El retardo debe ser númerico"
 ],
 "Repeat": [
  null,
  "Repetir"
 ],
 "Don't repeat": [
  null,
  "No repetir"
 ],
 "Minutely": [
  null,
  "Cada minuto"
 ],
 "Hourly": [
  null,
  "Cada hora"
 ],
 "Daily": [
  null,
  "A diario"
 ],
 "Weekly": [
  null,
  "Semanalmente"
 ],
 "Monthly": [
  null,
  "Mensualmente"
 ],
 "Yearly": [
  null,
  "Anualmente"
 ],
 "Run at": [
  null,
  "Ejecutar a las"
 ],
 "At second": [
  null,
  "Al segundo"
 ],
 "At minute": [
  null,
  "Al minuto"
 ],
 "Run on": [
  null,
  "Ejecutar cada"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "El minuto debe ser un número comprendido entre 0 y 59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "El segundo debe ser un número comprendido entre 0 y 59"
 ],
 "Repeat weekly": [
  null,
  "Repetir cada semana"
 ],
 "Mondays": [
  null,
  "Los lunes"
 ],
 "Tuesdays": [
  null,
  "Los martes"
 ],
 "Wednesdays": [
  null,
  "Los miércoles"
 ],
 "Thursdays": [
  null,
  "Los jueves"
 ],
 "Fridays": [
  null,
  "Los viernes"
 ],
 "Saturdays": [
  null,
  "Los sábados"
 ],
 "Sundays": [
  null,
  "Los domingos"
 ],
 "Repeat monthly": [
  null,
  "Repetir mensualmente"
 ],
 "1st": [
  null,
  "1"
 ],
 "2nd": [
  null,
  "2"
 ],
 "3rd": [
  null,
  "3"
 ],
 "4th": [
  null,
  "4"
 ],
 "5th": [
  null,
  "5"
 ],
 "6th": [
  null,
  "6"
 ],
 "7th": [
  null,
  "7"
 ],
 "8th": [
  null,
  "8"
 ],
 "9th": [
  null,
  "9"
 ],
 "10th": [
  null,
  "10"
 ],
 "11th": [
  null,
  "11"
 ],
 "12th": [
  null,
  "12"
 ],
 "13th": [
  null,
  "13"
 ],
 "14th": [
  null,
  "14"
 ],
 "15th": [
  null,
  "15"
 ],
 "16th": [
  null,
  "16"
 ],
 "17th": [
  null,
  "17"
 ],
 "18th": [
  null,
  "18"
 ],
 "19th": [
  null,
  "19"
 ],
 "20th": [
  null,
  "20"
 ],
 "21th": [
  null,
  "21"
 ],
 "22th": [
  null,
  "22"
 ],
 "23th": [
  null,
  "23"
 ],
 "24th": [
  null,
  "24"
 ],
 "25th": [
  null,
  "25"
 ],
 "26th": [
  null,
  "26"
 ],
 "27th": [
  null,
  "27"
 ],
 "28th": [
  null,
  "28"
 ],
 "29th": [
  null,
  "29"
 ],
 "30th": [
  null,
  "30"
 ],
 "31st": [
  null,
  "31"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Unclean shutdown": [
  null,
  "Apagado sucio"
 ],
 "View logs": [
  null,
  "Ver todos los registros"
 ],
 "Dismiss": [
  null,
  "Despedir"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Apagado programado a las $0"
 ],
 "Cancel poweroff": [
  null,
  "Cancelar apagado"
 ],
 "Scheduled reboot at $0": [
  null,
  "Reinicio programado el $0"
 ],
 "Cancel reboot": [
  null,
  "Cancelar reinicio"
 ],
 "edit": [
  null,
  "editar"
 ],
 "Set hostname": [
  null,
  "Establecer un nombre de anfitrión"
 ],
 "Configuration": [
  null,
  "Configuración"
 ],
 "Hostname": [
  null,
  "Nombre del anfitrión"
 ],
 "System time": [
  null,
  "Hora del sistema"
 ],
 "Domain": [
  null,
  "Dominio"
 ],
 "Performance profile": [
  null,
  "Perfil de rendimiento"
 ],
 "Secure shell keys": [
  null,
  "Claves de Secure Shell"
 ],
 "Show fingerprints": [
  null,
  "Mostrar las huellas dactilares"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "no se pudo mostrar las claves ssh del anfitrión: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Fallo al cargar las claves SSH"
 ],
 "Error message": [
  null,
  "Mensaje de error"
 ],
 "Loading keys...": [
  null,
  "Cargando claves…"
 ],
 "No host keys found.": [
  null,
  "No se encontró ninguna clave de anfitrión."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Huellas de clave SSH de la máquina"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "El nombre real del anfitrión debe tener 64 caracteres o menos"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "El nombre real del anfitrión solo puede contener caracteres en minúscula, dígitos, guiones y puntos (con subdominios poblados)"
 ],
 "Change host name": [
  null,
  "Cambiar el nombre del anfitrión"
 ],
 "Pretty host name": [
  null,
  "Nombre bonito del anfitrión"
 ],
 "Real host name": [
  null,
  "Nombre real del anfitrión"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "El usuario $0 no tiene permisos para modificar las políticas de criptografía"
 ],
 "Cryptographic policy": [
  null,
  "Políticas de criptografía"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Recomendado, ajustes seguros para los modelos de ataque actuales."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT con posibilidad de verificación de firmas SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Mayor interoperabilidad a costa de una mayor superficie de ataque."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY con interoperabilidad con Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Sólo se usan determinados algoritmos aprobados y permitidos cuando se arranca en modo FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS con restricciones Common Criteria."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protege de ataques anticipados en el futuro a corto plazo a costa de una menor interoperabilidad."
 ],
 "Custom cryptographic policy": [
  null,
  "Política de criptografía personalizada"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Las políticas de criptografía son un componente del sistema que configura los principales subsistemas criptográficos, cubriendo los protocolos TLS, IPSec, SSH, DNSSec y Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Cambiar políticas de criptografía"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplicando la nueva normativa… Esto puede tardar unos minutos."
 ],
 "Reapply and reboot": [
  null,
  "Aplicar y reiniciar"
 ],
 "Apply and reboot": [
  null,
  "Aplicar y reiniciar"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS no está activado adecuadamente"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Las políticas de criptografía seleccionadas son inconsistentes"
 ],
 "Review cryptographic policy": [
  null,
  "Revisar las políticas de criptografía"
 ],
 "System information": [
  null,
  "Información del sistema"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Asset tag": [
  null,
  "Etiqueta de propiedad"
 ],
 "Machine ID": [
  null,
  "Id. de máquina"
 ],
 "Up since": [
  null,
  "Activo desde"
 ],
 "View hardware details": [
  null,
  "Ver los detalles del hardware"
 ],
 "Last successful login:": [
  null,
  "Último inicio de sesión correcto:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 intento de inicio de sesión incorrecto",
  "$0 intentos de inicio de sesión fallidos"
 ],
 "View login history": [
  null,
  "Ver el historial de inicios de sesión"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Para unirse a un dominio debe instalar realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "No se puede unir a un dominio porque el realmd no está disponible en este sistema"
 ],
 "Joining this domain is not supported": [
  null,
  "No puede unirse a este dominio porque no está soportado"
 ],
 "Login format": [
  null,
  "Formato de acceso"
 ],
 "Server software": [
  null,
  "Software de servidor"
 ],
 "Client software": [
  null,
  "Cliente de software"
 ],
 "Leave domain": [
  null,
  "Abandonar el dominio"
 ],
 "Leave $0": [
  null,
  "Abandonar $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Después de sacarlo del dominio, solo los usuarios con credenciales locales pueden ver los registros de esta máquina. Esto puede que afecte a otros servicios como la configuración de resolución de DNS y el listado de las CA de confianza."
 ],
 "Validating address": [
  null,
  "Validando dirección"
 ],
 "Contacted domain": [
  null,
  "Contactado con el dominio"
 ],
 "Domain could not be contacted": [
  null,
  "El dominio no pudo ser contactado"
 ],
 "Domain is not supported": [
  null,
  "El dominio no está soportado"
 ],
 "Domain address": [
  null,
  "Dirección de dominio"
 ],
 "Domain administrator name": [
  null,
  "Nombre del administrador del dominio"
 ],
 "Domain administrator password": [
  null,
  "Contraseña del administrador del dominio"
 ],
 "Joining": [
  null,
  "Uniéndose"
 ],
 "Join": [
  null,
  "Unirse"
 ],
 "This may take a while": [
  null,
  "Esto llevará un tiempo"
 ],
 "Not permitted to configure realms": [
  null,
  "Sin permisos para configurar realms"
 ],
 "Join domain": [
  null,
  "Unirse a dominio"
 ],
 "Install realmd support": [
  null,
  "Instale soporte para realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disco está fallando",
  "$0 discos están fallando"
 ],
 "Connected to Insights": [
  null,
  "Conectado a Insights"
 ],
 "Not connected to Insights": [
  null,
  "No se ha conectado a Insights"
 ],
 "Health": [
  null,
  "Salud"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 núcleos de CPU"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "View metrics and history": [
  null,
  "Ver métricas e histórico"
 ],
 "Tuned is not available": [
  null,
  "Tuned no está disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned no se está ejecutando"
 ],
 "Tuned is off": [
  null,
  "Tuned está apagado"
 ],
 "This system is using the recommended profile": [
  null,
  "El sistema utiliza el perfil recomendado"
 ],
 "This system is using a custom profile": [
  null,
  "El sistema utiliza un perfil personalizado"
 ],
 "none": [
  null,
  "ninguno"
 ],
 "Communication with tuned has failed": [
  null,
  "Ha fallado la comunicación con el servicio tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Falló la habilitación de tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Falló la desactivación del servicio tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Fallo al desactivar el perfil de tuned"
 ],
 "Failed to switch profile": [
  null,
  "Falló el cambio de perfil"
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "Disable tuned": [
  null,
  "Deshabilitar tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned ha fallado al iniciar"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned es un servicio que monitoriza su sistema y optimiza el rendimiendo ante ciertas cargas de trabajo. El núcleo de Tuned son los perfiles, que ecualizan su sistema para distintos tipos de necesidades."
 ],
 "Change performance profile": [
  null,
  "Cambiar el perfil de rendimiento"
 ],
 "Change profile": [
  null,
  "Cambiar el perfil"
 ],
 "Edit /etc/motd": [
  null,
  "Editar /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Fallo al guardar los cambios en /etc/motd"
 ],
 "Save changes": [
  null,
  "Guardar cambios"
 ],
 "Edit motd": [
  null,
  "Editar motd"
 ],
 "Stub": [
  null,
  "Resguardo"
 ],
 "Not found": [
  null,
  "No se ha encontrado"
 ],
 "Bad setting": [
  null,
  "Configuración incorrecta"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Merged": [
  null,
  "Fusionado"
 ],
 "Running": [
  null,
  "Ejecutando"
 ],
 "Reloading": [
  null,
  "Recargando"
 ],
 "Not running": [
  null,
  "No está ejecutándose"
 ],
 "Failed to start": [
  null,
  "Falló al iniciar"
 ],
 "Maintenance": [
  null,
  "Modo de mantenimiento"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Disabled": [
  null,
  "Deshabilitado"
 ],
 "Linked": [
  null,
  "Vinculado"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Enmascarado"
 ],
 "Static": [
  null,
  "Estático"
 ],
 "Invalid": [
  null,
  "No válido"
 ],
 "Indirect": [
  null,
  "Indirecto"
 ],
 "Generated": [
  null,
  "Generado"
 ],
 "Transient": [
  null,
  "Transitorio"
 ],
 "Bad": [
  null,
  "Malo"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Falló la suscripción a las señales de systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Falló la conexión con dbus: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Fallo al listar unidades: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 servicio ha fallado",
  "$0 servicios han fallado"
 ],
 "Loading of units failed": [
  null,
  "Fallo al cargar las unidades"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Listing units": [
  null,
  "Listando unidades"
 ],
 "Filter by name or description": [
  null,
  "Filtrar por nombre o descripción"
 ],
 "Active state": [
  null,
  "Estado de actividad"
 ],
 "File state": [
  null,
  "Estado del archivo de unidad"
 ],
 "$0 filters applied": [
  null,
  "$0 filtros aplicados"
 ],
 "User": [
  null,
  "Usuario"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "El usuario $0 tiene permisos para cambiar las mitigaciones de seguridad de la cpu"
 ],
 "Mitigations": [
  null,
  "Mitigaciones"
 ],
 "Version": [
  null,
  "Versión"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Versión de la BIOS"
 ],
 "BIOS date": [
  null,
  "Fecha de la BIOS"
 ],
 "CPU security": [
  null,
  "Seguridad de CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Deshabilitar el multi-hilo simultáneo"
 ],
 "Read more...": [
  null,
  "Leer más..."
 ],
 "Save and reboot": [
  null,
  "Guardar y reiniciar"
 ],
 "CPU security toggles": [
  null,
  "Configuración de seguridad de la CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Las soluciones alternativas basadas en software ayudan a evitar problemas de seguridad de la CPU. Estas mitigaciones tienen el efecto secundario de reducir el rendimiento. Cambie estas configuraciones bajo su propio riesgo."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Clase"
 ],
 "Vendor": [
  null,
  "Proveedor"
 ],
 "Slot": [
  null,
  "Compartimento"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Tecnología de la memoria"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Rank": [
  null,
  "Posición"
 ],
 "Speed": [
  null,
  "Velocidad"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Necesita acceso administrativo para ver información sobre la memoria."
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "Failed to fetch logs": [
  null,
  "Fallo al obtener los registros"
 ],
 "Clear all filters": [
  null,
  "Vacía todos los filtros"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "No se pudo encontrar ningún registro mediante la combinación de filtros actuales."
 ],
 "No logs found": [
  null,
  "No se encontraron registros"
 ],
 "Load earlier entries": [
  null,
  "Cargar entradas anteriores"
 ],
 "You may try to load older entries.": [
  null,
  "Intente cargar entradas antiguas."
 ],
 "Allow running (unmask)": [
  null,
  "Permitir su ejecución (desenmascarar)"
 ],
 "Reload": [
  null,
  "Recargar"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Stop": [
  null,
  "Detener"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vaciar 'Falló al iniciar'"
 ],
 "Mask service": [
  null,
  "Enmascarar un servicio"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Enmascarando un servicio para prevenir que todas las unidades dependan de su ejecución. Esto puede tener un impacto mayor de los previsto. Por favor confirme que quiere enmascarar esta unidad."
 ],
 "Disallow running (mask)": [
  null,
  "No permitirle ejecutarse (enmascarar)"
 ],
 "Unpin unit": [
  null,
  "Desfijar unidad"
 ],
 "Pin unit": [
  null,
  "Fijar unidad"
 ],
 "Additional actions": [
  null,
  "Acciones adicionales"
 ],
 "Note": [
  null,
  "Nota"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Esta unidad no está diseñada para que se habilite de forma explícita."
 ],
 "Forbidden from running": [
  null,
  "Prohibido ejecutarlo"
 ],
 "Start service": [
  null,
  "Iniciar servicio"
 ],
 "Active since ": [
  null,
  "Activo desde "
 ],
 "Required by ": [
  null,
  "Requerido por "
 ],
 "Read-only": [
  null,
  "Solo lectura"
 ],
 "Requires administration access to edit": [
  null,
  "Es necesario tener permisos de acceso administrativi para editar"
 ],
 "Automatically starts": [
  null,
  "Se ejecuta automáticamente"
 ],
 "Updating status...": [
  null,
  "Actualizando el estado..."
 ],
 "Stop and disable": [
  null,
  "Parar y desactivar"
 ],
 "Start and enable": [
  null,
  "Empezar y activar"
 ],
 "Failed to load unit": [
  null,
  "Fallo al cargar la unidad"
 ],
 "View all services": [
  null,
  "Mostrar todos los servicios"
 ],
 "Triggers": [
  null,
  "Disparadores"
 ],
 "Triggered by": [
  null,
  "Desencadenado por"
 ],
 "Requires": [
  null,
  "Requiere"
 ],
 "Requisite": [
  null,
  "Requisito"
 ],
 "Wants": [
  null,
  "Quiere"
 ],
 "Binds to": [
  null,
  "Asociado a"
 ],
 "Part of": [
  null,
  "Parte de"
 ],
 "Required by": [
  null,
  "Requerido por"
 ],
 "Requisite of": [
  null,
  "Requisito de"
 ],
 "Wanted by": [
  null,
  "Buscado por"
 ],
 "Bound by": [
  null,
  "Balanceado por"
 ],
 "Consists of": [
  null,
  "Consiste en"
 ],
 "Conflicts": [
  null,
  "Conflictos"
 ],
 "Conflicted by": [
  null,
  "En conflicto por"
 ],
 "Before": [
  null,
  "Antes"
 ],
 "After": [
  null,
  "Después"
 ],
 "On failure": [
  null,
  "En caso de fallo"
 ],
 "Propagates reload to": [
  null,
  "Propagar la recargar de"
 ],
 "Reload propagated from": [
  null,
  "Recargar la propagación desde"
 ],
 "Joins namespace of": [
  null,
  "Se une a un espacio de nombres de"
 ],
 "Condition $0=$1 was not met": [
  null,
  "La condición $0=$1 no se cumple"
 ],
 "Deletion will remove the following files:": [
  null,
  "El proceso eliminará los siguientes archivos:"
 ],
 "Pinned unit": [
  null,
  "Unidad fijada"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Path": [
  null,
  "Ruta"
 ],
 "Listen": [
  null,
  "Escuchando"
 ],
 "Container": [
  null,
  "Contenedor"
 ],
 "View Podman container": [
  null,
  "Vista de contenedor Podman"
 ],
 "Condition failed": [
  null,
  "Condición incorrecta"
 ],
 "Show more relationships": [
  null,
  "Mostrar más relaciones"
 ],
 "Show relationships": [
  null,
  "Mostrar relaciones"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirme el borrado de $0"
 ],
 "Timer deletion failed": [
  null,
  "Fallo en la eliminación del temporizador"
 ],
 "Targets": [
  null,
  "Objetivos"
 ],
 "Sockets": [
  null,
  "Zócalos"
 ],
 "Timers": [
  null,
  "Temporizadores"
 ],
 "Paths": [
  null,
  "Rutas"
 ],
 "Go to $0": [
  null,
  "Ir a $0"
 ],
 "Journal entry not found": [
  null,
  "Entrada de bitácora no encontrada"
 ],
 "Journal entry": [
  null,
  "Bitácora de apunte"
 ],
 "Entry at $0": [
  null,
  "Entrada en $0"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "Loading unit failed": [
  null,
  "Fallo al cargar la unidad"
 ],
 "Service logs": [
  null,
  "Bitácoras del servicio"
 ],
 "No log entries": [
  null,
  "No hay entradas de registro"
 ],
 "Systemd units": [
  null,
  "Unidades de systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "No se obtuvieron resultados según el criterio de búsqueda. Limpie todos los filtros para mostrar los resultados."
 ],
 "Does not automatically start": [
  null,
  "No se inicia automáticamente en el inicio"
 ],
 "Cannot be enabled": [
  null,
  "No se puede activar"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La consola Web está en modo de acceso limitado."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta herramienta configura el sistema para que escriba los volcados de colapso del kernel. Admite volcados de destino\"local\" (disco), \"ssh\" y \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "desde $0 en $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "desde $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "en $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Dominio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Unirse a un dominio"
 ]
});
