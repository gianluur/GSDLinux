cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Você está se conectando com $0 pela primeira vez."
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Execute este comando por meio de uma rede confiável ou fisicamente na máquina remota:"
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Não foi possível efetuar login em $0. O host não aceita login por senha nem por nenhuma de suas chaves SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida por senha, e o host não permite login com senha. Por favor, forneça a senha da chave no endereço $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida. Você pode acessar usando sua senha de login ou fornecendo a senha da chave no endereço $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "Key password": [
  null,
  "Senha da chave"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "A chave SSH $0 de $1 em $2 serão adicionadas ao arquivo $3 de $4 em $5."
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "A chave SSH $0 ficará disponível durante o restante da sessão e também poderá ser usada para fazer login em outros hosts."
 ],
 "Permission denied": [
  null,
  "Permissão negada"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Pick date": [
  null,
  "Selecionar data"
 ],
 "Toggle date picker": [
  null,
  "Alternar o seletor de data"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "You now have administrative access.": [
  null,
  "Agora você tem acesso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Não existem métodos disponíveis para obter acesso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentique-se para obter acesso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Trocar para acesso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema ao se tornar administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Switch to limited access": [
  null,
  "Trocar para acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "O modo de acesso limitado restringe os privilégios administrativos. Algumas partes do console web terão funcionalidade reduzida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Seu navegador irá memorizar seu nível de acesso entre as sessões."
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar acesso administrativo"
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitar firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Strong password": [
  null,
  "Senha forte"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Weak password": [
  null,
  "Senha fraca"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "Show confirmation password": [
  null,
  "Mostrar a senha de confirmação"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando a conclusão de outras operações de gerenciamento de software"
 ],
 "Checking installed software": [
  null,
  "Verificando software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Não foi possível efetuar login em $0 usando autenticação por chave SSH. Por favor, forneça a senha."
 ],
 "SSH key login": [
  null,
  "Login com chave SSH"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportou código de erro $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "Row expansion": [
  null,
  "Expansão de linha"
 ],
 "Row select": [
  null,
  "Seleção de linha"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Erro de colagem"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Seu navegador não permite colar texto pelo menu de contexto. Você pode usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Erro durante inicialização"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Home": [
  null,
  "Pasta pessoal"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Não é um diretório"
 ],
 "All files": [
  null,
  "Todos os arquivos"
 ],
 "Recent": [
  null,
  "Recentes"
 ],
 "No recent directories": [
  null,
  "Nenhum diretório recente"
 ],
 "No recent files": [
  null,
  "Nenhum arquivo recente"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "File chooser actions": [
  null,
  "Ações do seletor de arquivos"
 ],
 "Open in file browser": [
  null,
  "Abrir no navegador de arquivos"
 ],
 "Hide hidden files": [
  null,
  "Ocultar arquivos ocultos"
 ],
 "Show hidden files": [
  null,
  "Mostrar arquivos ocultos"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Clear filters": [
  null,
  "Limpar filtros"
 ],
 "Directory is empty": [
  null,
  "O diretório está vazio"
 ],
 "Directory has no sub-directories": [
  null,
  "O diretório não tem subdiretórios"
 ],
 "This directory contains only hidden files": [
  null,
  "Este diretório contém apenas arquivos ocultos"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "Folder": [
  null,
  "Pasta"
 ],
 "File": [
  null,
  "Arquivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "O usuário conectado não tem permissão para visualizar as modificações do sistema"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "View automation script": [
  null,
  "Ver script de automação"
 ],
 "Occurrences": [
  null,
  "Ocorrências"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Select an option": [
  null,
  "Selecione uma opção"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Not permitted to perform this action.": [
  null,
  "Não autorizado a executar esta ação."
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Host key is incorrect": [
  null,
  "Chave de host incorreta"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "View logs": [
  null,
  "Ver logs"
 ],
 "Dismiss": [
  null,
  "Descartar"
 ],
 "edit": [
  null,
  "editar"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "none": [
  null,
  "nenhum"
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "Not running": [
  null,
  "Não está em execução"
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmar a exclusão de $0"
 ],
 "Username": [
  null,
  "Nome de usuário"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Delete group": [
  null,
  "Excluir grupo"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Lock": [
  null,
  "Travar"
 ],
 "Use $0": [
  null,
  "Usar $0"
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "Location": [
  null,
  "Local"
 ],
 "Compression": [
  null,
  "Compressão"
 ],
 "Storage logs": [
  null,
  "Logs de armazenamento"
 ],
 "Name cannot be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "O nome não pode ser maior do que 127 caracteres."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "O nome não pode conter o caractere '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nome não pode conter espaço em branco."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "O nome não pode ser maior do que $0 caracteres"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "O nome não pode ser maior que $0 bytes"
 ],
 "$name (from $host)": [
  null,
  "$name (do $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool de armazenamento para Thin Logical Volumes"
 ],
 "Thin logical volume": [
  null,
  "Volume lógico Thin"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume Lógico (Snapshot)"
 ],
 "Logical volume": [
  null,
  "Volume Lógico"
 ],
 "MDRAID device $0": [
  null,
  "Dispositivo MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupo de volume LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume Lógico Criptografado de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partição Criptografada de $0"
 ],
 "Logical volume of $0": [
  null,
  "Volume Lógico de $0"
 ],
 "Partition of $0": [
  null,
  "Partição de $0"
 ],
 "Encrypted $0": [
  null,
  "Encriptado $0"
 ],
 "unpartitioned space on $0": [
  null,
  "espaço não particionado em $0"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "mount": [
  null,
  "montar"
 ],
 "remove from btrfs volume": [
  null,
  "remover do volume btrfs"
 ],
 "stop": [
  null,
  "parar"
 ],
 "remove from MDRAID": [
  null,
  "remover do MDRAID"
 ],
 "remove from LVM2": [
  null,
  "remover do LVM2"
 ],
 "btrfs device": [
  null,
  "Dispositivo btrfs"
 ],
 "btrfs volume": [
  null,
  "Volume btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "O nome não pode ser maior do que 255 caracteres."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "O nome não pode conter o caractere '/'."
 ],
 "Create and mount": [
  null,
  "Criar e montar"
 ],
 "Create only": [
  null,
  "Criar apenas"
 ],
 "Create subvolume": [
  null,
  "Criar subvolume"
 ],
 "Mount Point": [
  null,
  "Ponto de montagem"
 ],
 "delete": [
  null,
  "excluir"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Excluir o subvolume $0 permanentemente?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "A exclusão apaga todos os dados neste subvolume e em todos os seus filhos."
 ],
 "Edit mount point": [
  null,
  "Editar ponto de montagem"
 ],
 "Unmount": [
  null,
  "Desmontar"
 ],
 "Mount": [
  null,
  "Montar"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Pelo menos um subvolume precisa ser montado"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "O último subvolume montado não pode ser excluído"
 ],
 "btrfs subvolume": [
  null,
  "Subvolume btrfs"
 ],
 "Snapshot origin": [
  null,
  "Origem do snapshot"
 ],
 "Mount point": [
  null,
  "Ponto de Montagem"
 ],
 "No subvolumes": [
  null,
  "Nenhum subvolume"
 ],
 "btrfs subvolumes": [
  null,
  "Subvolumes btrfs"
 ],
 "Snapshots": [
  null,
  "Snapshots"
 ],
 "No snapshots found": [
  null,
  "Nenhum snapshot encontrado"
 ],
 "snapshot": [
  null,
  "snapshot"
 ],
 "$0 is in use": [
  null,
  "$0 está em uso"
 ],
 "Permanently delete $0?": [
  null,
  "Excluir $0 permanentemente?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "A exclusão apaga todos os dados em um volume btrfs."
 ],
 "Delete filesystem": [
  null,
  "Excluir sistema de arquivos"
 ],
 "Change label": [
  null,
  "Alterar rótulo"
 ],
 "Filesystem is mounted read-only": [
  null,
  "O sistema de arquivos está montado somente para leitura"
 ],
 "Label": [
  null,
  "Rótulo"
 ],
 "Capacity": [
  null,
  "Capacidade"
 ],
 "btrfs devices": [
  null,
  "Dispositivos btrfs"
 ],
 "No devices found": [
  null,
  "Nenhum dispositivos encontrado"
 ],
 "btrfs filesystem": [
  null,
  "Sistema de arquivos btrfs"
 ],
 "Successful": [
  null,
  "Realizado com sucesso"
 ],
 "Aborted": [
  null,
  "Interrompido"
 ],
 "In progress": [
  null,
  "Em andamento"
 ],
 "Interrupted": [
  null,
  "Interrompido"
 ],
 "Did not complete": [
  null,
  "Não concluiu"
 ],
 "Failed (Unknown)": [
  null,
  "Falha (desconhecida)"
 ],
 "Failed (Electrical)": [
  null,
  "Falha (elétrica)"
 ],
 "Failed (Servo)": [
  null,
  "Falha (servo)"
 ],
 "Failed (Read)": [
  null,
  "Falha (leitura)"
 ],
 "Failed (Damaged)": [
  null,
  "Falha (danificado)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Abortado por uma redefinição de nível do controlador"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Abortado devido à remoção de um namespace do inventário de namespace"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Abortado devido ao processamento de um comando Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Ocorreu um erro fatal durante a operação de autoteste"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Concluído com um segmento que falhou e o segmento que falhou não é conhecido"
 ],
 "Completed with one or more failed segments": [
  null,
  "Concluído com um ou mais segmentos com falha"
 ],
 "Aborted for unknown reason": [
  null,
  "Abortado por uma razão desconhecida"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Abortado devido a uma operação de higienização"
 ],
 "Spare capacity is below the threshold": [
  null,
  "A capacidade excedente está abaixo do limite"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatura fora do limiar recomendado"
 ],
 "Degraded": [
  null,
  "Degradado"
 ],
 "All media is in read-only mode": [
  null,
  "Todas as mídias estão em modo somente leitura"
 ],
 "Volatile memory backup failed": [
  null,
  "Backup de memória volátil falhou"
 ],
 "Persistent memory has become read-only": [
  null,
  "A memória persistente tornou-se somente leitura"
 ],
 "Run short test": [
  null,
  "Executar teste curto"
 ],
 "Run extended test": [
  null,
  "Executar teste estendido"
 ],
 "Abort test": [
  null,
  "Abortar teste"
 ],
 "Disk is failing": [
  null,
  "O disco está falhando"
 ],
 "Disk is OK": [
  null,
  "O Disco está OK"
 ],
 "Assessment": [
  null,
  "Avaliação"
 ],
 "Power on hours": [
  null,
  "Horas ligado"
 ],
 "$0 hours": [
  null,
  "$0 horas"
 ],
 "Self-test status": [
  null,
  "Estado do auto-teste"
 ],
 "Number of bad sectors": [
  null,
  "Número de setores ruins"
 ],
 "Attributes failing": [
  null,
  "Atributos falhando"
 ],
 "Media drive": [
  null,
  "Unidade de mídia"
 ],
 "Solid State Drive": [
  null,
  "Unidade de estado sólido"
 ],
 "Hard Disk Drive": [
  null,
  "Unidade de disco rígido"
 ],
 "iSCSI Drive": [
  null,
  "Drive iSCSI"
 ],
 "Drive": [
  null,
  "Unidade"
 ],
 "Device health (SMART)": [
  null,
  "Saúde do dispositivo (SMART)"
 ],
 "Firmware version": [
  null,
  "Versão do firmware"
 ],
 "Serial number": [
  null,
  "Número de série"
 ],
 "World wide name": [
  null,
  "Nome mundial"
 ],
 "No media inserted": [
  null,
  "Nenhuma mídia inserida"
 ],
 "Device file": [
  null,
  "Arquivo do dispositivo"
 ],
 "Multipathed devices": [
  null,
  "Dispositivos do vários caminhos (multipath)"
 ],
 "Free space": [
  null,
  "Espaço Livre"
 ],
 "Create partition": [
  null,
  "Criar Partição"
 ],
 "Extended partition": [
  null,
  "Partição estendida"
 ],
 "$0 partitions": [
  null,
  "Partições $0"
 ],
 "Partitions": [
  null,
  "Partições"
 ],
 "No partitions found": [
  null,
  "Nenhuma partição encontrada"
 ],
 "Unexpected partitions": [
  null,
  "Partições inesperadas"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Este dispositivo de bloco não suporta partições. Se for utilizado como disco para uma máquina virtual, as partições deverão ser gerenciadas pelo sistema operacional dentro da máquina virtual."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "A exclusão de uma partição excluirá todos os dados dela."
 ],
 "No free space after this partition": [
  null,
  "Não há espaço livre após esta partição"
 ],
 "EFI system partition": [
  null,
  "Partição de sistema EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partição de boot da BIOS"
 ],
 "Partition": [
  null,
  "Partição"
 ],
 "Shrink": [
  null,
  "Compactar"
 ],
 "Grow": [
  null,
  "Aumentar"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partição de inicialização PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "Espaço swap Linux"
 ],
 "Linux filesystem data": [
  null,
  "Dados do sistema de arquivos Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partição de Logical Volume Manager"
 ],
 "Custom": [
  null,
  "Personalizado"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "O tipo deve conter exatamente dois caracteres hexadecimais (0 a 9, A a F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "O tipo pode conter apenas os caracteres de 0 a 9, de A a F e \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "O tipo deve estar no formato NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Definir tipo de partição de $0"
 ],
 "Custom type": [
  null,
  "Tipo customizado"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Alterar os tipos de partição pode impedir a inicialização do sistema."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Esta partição não é completamente utilizada pelo seu conteúdo."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "O tamanho da partição é $0. O tamanho do conteúdo é $1."
 ],
 "Shrink partition": [
  null,
  "Diminuir partição"
 ],
 "Grow content": [
  null,
  "Aumentar o conteúdo"
 ],
 "initialize": [
  null,
  "inicializar"
 ],
 "Initialize disk $0": [
  null,
  "Inicializando disco $0"
 ],
 "Partitioning": [
  null,
  "Particionamento"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatível com todos os sistemas e dispositivos (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatível com sistema moderno e discos rígidos > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Sem particionamento"
 ],
 "Overwrite": [
  null,
  "Sobrescrever"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Sobrescrever dados existentes com zeros (mais lento)"
 ],
 "Initialize": [
  null,
  "Inicializar"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "A inicialização apagará todos os dados do disco."
 ],
 "Device is read-only": [
  null,
  "Dispositivo é somente leitura"
 ],
 "Create partition table": [
  null,
  "Criar tabela de partição"
 ],
 "Size must be a number": [
  null,
  "O tamanho deve ser um número"
 ],
 "Size cannot be zero": [
  null,
  "O tamanho não pode ser zero"
 ],
 "Size cannot be negative": [
  null,
  "O tamanho não pode ser negativo"
 ],
 "Size is too large": [
  null,
  "O tamanho é muito extenso"
 ],
 "Size must be at least $0": [
  null,
  "O tamanho deve ser pelo menos $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume físico do grupo de volumes LVM2"
 ],
 "member of MDRAID device": [
  null,
  "membro do Dispositivo MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "dispositivo backup para dispositivo VDO"
 ],
 "member of Stratis pool": [
  null,
  "membro do pool Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Sistema de arquivos fora do alvo"
 ],
 "device of btrfs volume": [
  null,
  "dispositivo do volume btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Este dispositivo está atualmente em uso."
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Use": [
  null,
  "Utilizar"
 ],
 "Services using the location": [
  null,
  "Serviços usando a localização"
 ],
 "Processes using the location": [
  null,
  "Processos usando a localização"
 ],
 "Currently in use": [
  null,
  "Atualmente em uso"
 ],
 "(Not part of target)": [
  null,
  "(Não faz parte do alvo)"
 ],
 "These changes will be made:": [
  null,
  "Essas mudanças serão realizadas:"
 ],
 "Action": [
  null,
  "Ação"
 ],
 "Important data might be deleted:": [
  null,
  "Dados importantes poderão ser excluídos:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Processos e serviços relacionados serão interrompidos à força."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Processos relacionados serão interrompidos à força."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Os serviços relacionados serão interrompidos à força."
 ],
 "Checking filesystem usage": [
  null,
  "Verificando o uso do sistema de arquivos"
 ],
 "$0 used, $1 total": [
  null,
  "$0 usado, $1 total"
 ],
 "Device contains unrecognized data": [
  null,
  "O dispositivo contém dados irreconhecíveis"
 ],
 "Locked encrypted device might contain data": [
  null,
  "O dispositivo criptografado bloqueado pode conter dados"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confirmo que desejo perder esses dados para sempre"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "O ponto de montagem $0 está em uso por estes processos:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "O ponto de montagem $0 está em uso por estes serviços:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Os processos e serviços listados serão interrompidos à força."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Os processos listados serão interrompidos à força."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Os serviços listados serão interrompidos à força."
 ],
 "Sorry": [
  null,
  "Desculpe"
 ],
 "Usage of $0": [
  null,
  "Uso de $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Pool LVM2 VDO"
 ],
 "Data used": [
  null,
  "Dados Usados"
 ],
 "Metadata used": [
  null,
  "Metadados usados"
 ],
 "Use compression": [
  null,
  "Usar compressão"
 ],
 "Deduplication": [
  null,
  "Deduplicação"
 ],
 "Use deduplication": [
  null,
  "Usar deduplicação"
 ],
 "Rename volume group": [
  null,
  "Renomear Grupo de Volume"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Este grupo de volumes contém o sistema de arquivos raiz. Renomeá-lo pode exigir alterações adicionais na configuração do carregador de inicialização ou na linha de comando do kernel."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "A exclusão apaga todos os dados em um grupo de volumes."
 ],
 "Create snapshot": [
  null,
  "Criar snapshot"
 ],
 "Add disks": [
  null,
  "Adicionar discos"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "No disks are available.": [
  null,
  "Sem discos disponíveis."
 ],
 "At least one disk is needed.": [
  null,
  "Pelo menos um disco é necessário."
 ],
 "Volume group is missing physical volumes": [
  null,
  "O grupo de volumes não possui volumes físicos"
 ],
 "No free space": [
  null,
  "Não há espaço livre"
 ],
 "LVM2 volume group": [
  null,
  "Grupo de Volumes LVM2"
 ],
 "Add physical volume": [
  null,
  "Adicionar volume físico"
 ],
 "LVM2 logical volumes": [
  null,
  "Volumes lógicos LVM2"
 ],
 "Create new logical volume": [
  null,
  "Criar novo volume lógico"
 ],
 "No logical volumes": [
  null,
  "Nenhum Volume Lógico"
 ],
 "Remove missing physical volumes?": [
  null,
  "Remover volumes físicos ausentes?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Este grupo de volumes está sem alguns volumes físicos."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Um grupo de volumes com volumes físicos ausentes não pode ser renomeado."
 ],
 "Physical volumes": [
  null,
  "Volumes Físicos"
 ],
 "No physical volumes found": [
  null,
  "Nenhum volume físico encontrado"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumes físicos LVM2"
 ],
 "Rename logical volume": [
  null,
  "Renomear Volume Lógico"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Deletar permanentemente o volume lógico $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "A exclusão de um volume lógico excluirá todos os dados dele."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Não foi possível corrigir o volume lógico $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Não há espaço suficiente disponível que possa ser usado para um reparo. Pelo menos $0 são necessários em volumes físicos que ainda não estão sendo usados para este volume lógico."
 ],
 "An additional $0 must be selected": [
  null,
  "Um $0 adicional deve ser selecionado"
 ],
 "Repair logical volume $0": [
  null,
  "Reparar volume lógico $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Selecionar os volumes físicos que devem ser usados para reparar o volume lógico. Pelo menos $0 são necessários."
 ],
 "Physical Volumes": [
  null,
  "Volumes Físicos"
 ],
 "Repair": [
  null,
  "Reparar"
 ],
 "deactivate": [
  null,
  "desativar"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Desativar o volume lógico $0/$1?"
 ],
 "Deactivate": [
  null,
  "Desativar"
 ],
 "Not enough space to grow": [
  null,
  "Não há espaço suficiente para aumentar de tamanho"
 ],
 "LVM2 logical volume": [
  null,
  "Volume Lógico LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Distribuído (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Espelhado (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Distribuído e espelhado (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Paridade dedicada (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Paridade distribuída (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Paridade duplamente distribuída (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Este volume lógico não é completamente utilizado pelo seu conteúdo."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Tamanho do volume é $0. Tamanho de conteúdo é $1."
 ],
 "Shrink volume": [
  null,
  "Diminuir volume"
 ],
 "Layout": [
  null,
  "Disposição"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos e não pode mais ser usado. Você precisa excluí-lo e criar um novo para tomar o seu lugar."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos, mas ainda não perdeu nenhum dado. Você deve repará-lo para restaurar sua redundância original."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos, mas pode não ter perdido nenhum dado ainda. Você pode ser capaz de repará-lo."
 ],
 "Stripes": [
  null,
  "Listrados"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizado"
 ],
 "Create volume group": [
  null,
  "Criar Grupo de Volumes"
 ],
 "LVM2 physical volume": [
  null,
  "Volume físico LVM2"
 ],
 "Last cannot be removed": [
  null,
  "O último não pode ser removido"
 ],
 "Not enough free space": [
  null,
  "Não há espaço livre suficiente"
 ],
 "Volume group": [
  null,
  "Grupo de volumes"
 ],
 "Create thin volume": [
  null,
  "Criar Thin Volume"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volumes lógicos LVM2 provisionados finamente"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Criar novo volume lógico com provisionamento fino"
 ],
 "Not enough space": [
  null,
  "Não há espaço suficiente"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool de armazenamento para volumes finamente provisionados"
 ],
 "Inactive logical volume": [
  null,
  "Volume lógico inativo"
 ],
 "Activate": [
  null,
  "Ativar"
 ],
 "Unsupported logical volume": [
  null,
  "Volume lógico não suportado"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERRO INTERNO - Este volume lógico está marcado como ativo e deve ter um dispositivo de bloco associado. No entanto, nenhum dispositivo de bloco desse tipo pôde ser encontrado."
 ],
 "Installing $0 would remove $1.": [
  null,
  "A instalação de $0 removeria $1."
 ],
 "Installing packages": [
  null,
  "Instalando pacotes"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo de bloqueio para sistemas de arquivos"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool de armazenamento para volumes finamente provisionados"
 ],
 "Linear": [
  null,
  "Linear"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume do sistema de arquivos VDO (compressão/deduplicação)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados sem qualquer redundância adicional ou melhorias de desempenho."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados de forma alternada para melhorar o desempenho. Pelo menos dois volumes precisam ser selecionados."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Os dados serão armazenados como duas ou mais cópias nos volumes físicos selecionados, para melhorar a confiabilidade. Pelo menos dois volumes precisam ser selecionados."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Os dados serão armazenados como duas cópias e também de forma alternada nos volumes físicos selecionados, para melhorar a confiabilidade e o desempenho. Pelo menos quatro volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que um deles possa ser perdido sem afetar os dados. Pelo menos três volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que um deles possa ser perdido sem afetar os dados. Os dados também são armazenados de forma alternada para melhorar o desempenho. Pelo menos três volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que até dois deles possam ser perdidos ao mesmo tempo sem afetar os dados. Os dados também são armazenados de forma alternada para melhorar o desempenho. Pelo menos cinco volumes precisam ser selecionados."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Todos os $0 volumes físicos selecionados são necessários para o layout escolhido."
 ],
 "Create logical volume": [
  null,
  "Criar volume lógico"
 ],
 "Purpose": [
  null,
  "Propósito"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "O pacote $0 será instalado para criar dispositivos VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 precisa de um número par de volumes físicos"
 ],
 "Logical size": [
  null,
  "Tamanho Lógico"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Economizar espaço comprimindo blocos individuais com LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Economizar espaço armazenando blocos de dados idênticos uma só vez"
 ],
 "Creating VDO device": [
  null,
  "Criando dispositivo VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Esta montagem NFS está em uso e somente suas opções podem ser alteradas."
 ],
 "NFS mount": [
  null,
  "Montagem NFS"
 ],
 "New NFS mount": [
  null,
  "Nova montagem de volume NFS"
 ],
 "Server address": [
  null,
  "Endereço do Servidor"
 ],
 "Server cannot be empty.": [
  null,
  "O servidor não pode estar vazio."
 ],
 "Path on server": [
  null,
  "Caminho no servidor"
 ],
 "Path on server cannot be empty.": [
  null,
  "Caminho no servidor não pode estar vazio."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Caminho no servidor deve começar com \"/\"."
 ],
 "Local mount point": [
  null,
  "Ponto de montagem local"
 ],
 "Mount point cannot be empty.": [
  null,
  "O ponto de montagem não pode estar vazio."
 ],
 "Mount point must start with \"/\".": [
  null,
  "O ponto de montagem deve começar com \"/\"."
 ],
 "Mount options": [
  null,
  "Opções de Montagem"
 ],
 "Mount at boot": [
  null,
  "Monte na Inicialização"
 ],
 "Mount read only": [
  null,
  "Monte só de leitura"
 ],
 "Custom mount options": [
  null,
  "Opções de montagem personalizadas"
 ],
 "Unable to unmount filesystem": [
  null,
  "Não é possível desmontar o sistema de arquivos"
 ],
 "Stop and unmount": [
  null,
  "Parar e desmontar"
 ],
 "Unable to remove mount": [
  null,
  "Não é possível remover a unidade montade"
 ],
 "Stop and remove": [
  null,
  "Pare e remova"
 ],
 "(not mounted)": [
  null,
  "(não montado)"
 ],
 "Start multipath": [
  null,
  "Iniciar Multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Há dispositivos com vários caminhos no sistema, mas o serviço de multicaminho não está em execução."
 ],
 "Show all $0 rows": [
  null,
  "Exibir todas as $0 linhas"
 ],
 "Category": [
  null,
  "Categoria"
 ],
 "more info": [
  null,
  "mais informações"
 ],
 "Encryption": [
  null,
  "Encriptação"
 ],
 "encrypted": [
  null,
  "criptografado"
 ],
 "Last modified: $0": [
  null,
  "Última modificação: $0"
 ],
 "Stored passphrase": [
  null,
  "Senha armazenada"
 ],
 "Encryption options": [
  null,
  "Opções de Criptografia"
 ],
 "Encryption type": [
  null,
  "Tipo de encriptação"
 ],
 "Cleartext device": [
  null,
  "Dispositivo de texto simples"
 ],
 "yes": [
  null,
  "sim"
 ],
 "Disk passphrase": [
  null,
  "Senha de disco"
 ],
 "Passphrase cannot be empty": [
  null,
  "A senha não pode ser vazia"
 ],
 "Unlocking disk": [
  null,
  "Desbloqueando o disco"
 ],
 "Checking for $0 package": [
  null,
  "Verificando a presença do pacote $0"
 ],
 "The $0 package must be installed.": [
  null,
  "O pacote $0 deve estar instalado."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "O pacote $0 não está disponível em nenhum repositório."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Erro ao instalar $0: PackageKit ou dnf5daemon-server não está instalado"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Erro inesperado do PackageManager durante a instalação de $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Checando o suporte NBDE no initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "O initrd deve ser regenerado."
 ],
 "Regenerating initrd": [
  null,
  "Regenerando initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Adicionando rd.neednet=1 à linha de comando do kernel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Adicionando \"$0\" às opções do sistema de arquivos"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Adicionando \"$0\" às opções de criptografia"
 ],
 "Enabling $0": [
  null,
  "Habilitando $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Adicionar criptografia de disco vinculado à rede"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Atualmente, o sistema não oferece suporte ao desbloqueio do sistema de arquivos raiz com um servidor de chaves Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Atualmente, o sistema não oferece suporte ao desbloqueio de um sistema de arquivos com um servidor de chaves Tang durante a inicialização."
 ],
 "These additional steps are necessary:": [
  null,
  "Estes passos adicionais são necessários:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salvar uma nova senha requer o desbloqueio do disco. Por favor, forneça uma senha de disco atual."
 ],
 "Fix NBDE support": [
  null,
  "Corrigir suporte NBDE"
 ],
 "Adding key": [
  null,
  "Adicionando chave"
 ],
 "Key source": [
  null,
  "Fonte chave"
 ],
 "Repeat passphrase": [
  null,
  "Repita a frase secreta"
 ],
 "Passphrase": [
  null,
  "Frase-senha"
 ],
 "Tang keyserver": [
  null,
  "Servidor de chaves Tang"
 ],
 "New passphrase": [
  null,
  "Nova frase secreta"
 ],
 "Passphrases do not match": [
  null,
  "As senhas não correspondem"
 ],
 "Keyserver address": [
  null,
  "Endereço do servidor de chaves"
 ],
 "Change passphrase": [
  null,
  "Alterar senha"
 ],
 "Old passphrase": [
  null,
  "Senha antiga"
 ],
 "Edit Tang keyserver": [
  null,
  "Editar o servidor de chaves Tang"
 ],
 "Verify key": [
  null,
  "Verificar chave"
 ],
 "Trust key": [
  null,
  "Chave de confiança"
 ],
 "Passphrase can not be empty": [
  null,
  "A senha não pode ser vazia"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "A remoção da senha pode impedir o desbloqueio de $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirme a remoção com a frase secreta alternativa"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Remover uma frase secreta sem a confirmação de outra frase pode impedir o desbloqueio ou o gerenciamento de chaves, caso outras frases secretas sejam esquecidas ou perdidas."
 ],
 "Passphrase from any other key slot": [
  null,
  "Senha de qualquer outro slot de chave"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Remover frase secreta no slot de chave $0?"
 ],
 "Remove $0?": [
  null,
  "Remover $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "A remoção pode impedir o desbloqueio de $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Remover o servidor de chaves Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Remover chave do slot $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "O usuário atualmente conectado não tem permissão para ver informações sobre chaves."
 ],
 "No keys added": [
  null,
  "Nenhuma chave adicionada"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editar uma chave requer um espaço livre"
 ],
 "The last key slot can not be removed": [
  null,
  "O último slot chave não pode ser removido"
 ],
 "Keyserver": [
  null,
  "Servidor de chaves"
 ],
 "Unknown type": [
  null,
  "Tipo desconhecido"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Slots chave com tipos desconhecidos não podem ser editados aqui"
 ],
 "Keys": [
  null,
  "Chaves"
 ],
 "$0 slot remains": [
  null,
  "$0 slot restante",
  "$0 slots restantes"
 ],
 "No available slots": [
  null,
  "Sem slots disponíveis"
 ],
 "No free key slots": [
  null,
  "Nenhum slot de chave livre"
 ],
 "Locked data": [
  null,
  "Dados bloqueados"
 ],
 "lock": [
  null,
  "trancar"
 ],
 "Lock $0?": [
  null,
  "Travar $0?"
 ],
 "Address cannot be empty": [
  null,
  "O endereço não pode estar vazio"
 ],
 "Address is not a valid URL": [
  null,
  "O endereço não é uma URL válida"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Verifique o hash da chave com o servidor Tang."
 ],
 "How to check": [
  null,
  "Como verificar"
 ],
 "In a terminal, run: ": [
  null,
  "Em um terminal, execute: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiado com sucesso para área de transferência!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Verifique se o hash SHA-256 ou SHA-1 do comando corresponde a essa caixa de diálogo."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Subvolume btrfs $0 de $1"
 ],
 "Mount point cannot be empty": [
  null,
  "O ponto de montagem não pode estar vazio"
 ],
 "Mount point is already used for $0": [
  null,
  "Ponto de montagem já está sendo usado para $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Os sistemas de arquivos já estão montados abaixo deste ponto de montagem."
 ],
 "Please unmount them first.": [
  null,
  "Desmonte-os primeiro."
 ],
 "read only": [
  null,
  "somente leitura"
 ],
 "never mount at boot": [
  null,
  "nunca montar na inicialização"
 ],
 "after network": [
  null,
  "após rede"
 ],
 "ignore failure": [
  null,
  "ignorar falhas"
 ],
 "stop boot on failure": [
  null,
  "parar a inicialização em caso de falha"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "O sistema de arquivos não tem ponto de montagem atribuído."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "O sistema de arquivos não tem ponto de montagem permanente."
 ],
 "The filesystem is not mounted.": [
  null,
  "O sistema de arquivos não está montado."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "O sistema de arquivos será desbloqueado e montado na próxima inicialização. Isso pode exigir a inserção de uma frase-senha."
 ],
 "(no assigned mount point)": [
  null,
  "(nenhum ponto de montagem atribuído)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado em $0, mas será montado em $1 na próxima inicialização."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Monte automaticamente no $0 na inicialização"
 ],
 "Mount on $0 now": [
  null,
  "Monte no $0 agora"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "O sistema de arquivos não está montado no momento, mas será montado na próxima inicialização."
 ],
 "Do not mount automatically on boot": [
  null,
  "Não monta automaticamente na inicialização"
 ],
 "Mount now": [
  null,
  "Monte agora"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado, mas não será montado após a próxima inicialização."
 ],
 "Mount also automatically on boot": [
  null,
  "Monte também automaticamente na inicialização"
 ],
 "Unmount now": [
  null,
  "Desmontar agora"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado em $0, mas não será montado na próxima inicialização."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "O sistema de arquivos está configurado para ser montado automaticamente na inicialização, mas seu contêiner de criptografia não será desbloqueado naquele momento."
 ],
 "Unlock automatically on boot": [
  null,
  "Desbloquear automaticamente na inicialização"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montagem inconsistente do sistema de arquivos"
 ],
 "$0 filesystem": [
  null,
  "Sistema de arquivos $0"
 ],
 "Filesystem name": [
  null,
  "Nome do sistema de arquivos"
 ],
 "Filesystem is locked": [
  null,
  "Sistema de arquivos está bloqueado"
 ],
 "Mounts before services start": [
  null,
  "Monta antes do início dos serviços"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Apropriado para montagens críticas, como /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "A inicialização falha se o sistema de arquivos não é montado, impedindo o acesso remoto"
 ],
 "Mounts in parallel with services": [
  null,
  "Monta em paralelo com os serviços"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "A inicialização ainda é bem-sucedida quando o sistema de arquivos não é montado"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monta em paralelo com os serviços, mas depois que a rede está disponível"
 ],
 "Does not mount during boot": [
  null,
  "Não monta durante a inicialização"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Útil para montagens que são opcionais ou precisam de interação (como senhas)"
 ],
 "At boot": [
  null,
  "Na inicialização"
 ],
 "Mount before services start": [
  null,
  "Monte antes do início dos serviços"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monte sem esperar, ignore a falha"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monte depois que a rede se tornar disponível, ignore a falha"
 ],
 "Do not mount": [
  null,
  "Não montar"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Este dispositivo não pode ser usado para o alvo de instalação."
 ],
 "Mount filesystem": [
  null,
  "Montar sistema de arquivos"
 ],
 "Unmount filesystem $0": [
  null,
  "Desmontar o sistema de arquivos $0"
 ],
 "Mount configuration": [
  null,
  "Configuração de montagem"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Desbloquear pool Stratis criptografado"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Forneça a senha para o pool nestes dispositivos de bloco:"
 ],
 "Stratis pool": [
  null,
  "Pool de Stratis"
 ],
 "stopped": [
  null,
  "parado"
 ],
 "Block devices": [
  null,
  "Dispositivos de bloco"
 ],
 "No block devices found": [
  null,
  "Nenhum dispositivo de bloco encontrado"
 ],
 "Stratis block devices": [
  null,
  "Dispositivos de bloco Stratis"
 ],
 "Stratis block device": [
  null,
  "Dispositivo de bloco Stratis"
 ],
 "data": [
  null,
  "dados"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Forneça uma senha do pool existente."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Se o servidor de chaves em $0 não for alcançável, você pode fornecer uma senha existente."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Se nenhum dos servidores de chave for alcançável, você pode fornecer uma senha existente."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Se nenhum dos métodos de desbloqueio não-interativo funcionar, você pode fornecer uma senha existente."
 ],
 "Pool passphrase": [
  null,
  "Senha do pool de armazenamento"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "O servidor de chaves em $0 deve estar acessível."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Pelo menos um servidor de chaves deve ser alcançável."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Pelo menos um dos métodos de desbloqueio não interativo deve funcionar."
 ],
 "Create filesystem": [
  null,
  "Criar sistema de arquivos"
 ],
 "Stratis filesystem": [
  null,
  "Sistema de arquivos Stratis"
 ],
 "Set initial size": [
  null,
  "Definir tamanho inicial"
 ],
 "Limit size": [
  null,
  "Limitar tamanho"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "A exclusão de um pool Stratis apagará todos os dados que ele contém."
 ],
 "Rename Stratis pool": [
  null,
  "Renomear pool Stratis"
 ],
 "Add block devices": [
  null,
  "Adicionar dispositivos de bloco"
 ],
 "Tier": [
  null,
  "Tier"
 ],
 "Data": [
  null,
  "Dados"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Adicionar dispositivos de bloco requer desbloqueio do pool."
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool de armazenamento Stratis criptografado"
 ],
 "Delete pool": [
  null,
  "Excluir pool"
 ],
 "Encryption tokens": [
  null,
  "Tokens de criptografia"
 ],
 "Stratis filesystems": [
  null,
  "Sistemas de arquivos Stratis"
 ],
 "Create new filesystem": [
  null,
  "Criar novo sistema de arquivos"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Este pool de armazenamento não utiliza todo o espaço em seus dispositivos de bloco."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Alguns dispositivos de bloco deste pool aumentaram em tamanho depois que o pool foi criado. O pool pode ser aumentado com segurança para usar o novo espaço disponível."
 ],
 "Grow the pool to take all space": [
  null,
  "Aumentar o pool de armazenamento para tomar todo o espaço"
 ],
 "This pool is in a degraded state.": [
  null,
  "Este pool de armazenamento está em estado degradado."
 ],
 "No filesystems": [
  null,
  "Nenhum sistema de arquivos"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool de sistemas de arquivos Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Esta senha é a única maneira de desbloquear o pool de armazenamento e não pode ser removida."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Este servidor de chaves é a única maneira de desbloquear o pool de armazenamento e não pode ser removido."
 ],
 "Add passphrase": [
  null,
  "Adicionar senha"
 ],
 "Add keyserver": [
  null,
  "Adicionar servidor de chaves"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "O último token não pode ser removido"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Não há mais espaço para senhas e servidores de senha."
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Adicionar uma senha requer o desbloqueio do pool."
 ],
 "Remove passphrase?": [
  null,
  "Remover senha?"
 ],
 "Add Tang keyserver": [
  null,
  "Adicionar servidor de chaves Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Adicionar servidor de chaves requer o desbloqueio do pool de armazenamento."
 ],
 "Remove Clevis token?": [
  null,
  "Remover token de Clevis?"
 ],
 "Metadata format": [
  null,
  "Formato de metadados"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Pools com formato de metadados V1 são restritos a no máximo uma senha e no máximo um servidor de chave."
 ],
 "Overprovisioning": [
  null,
  "Superprovisionamento"
 ],
 "Allow overprovisioning": [
  null,
  "Permitir superprovisionamento"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Os tamanhos do sistema de arquivos virtual são maiores que o pool. O superprovisionamento não pode ser desabilitado."
 ],
 "Allocated": [
  null,
  "Alocado"
 ],
 "Name can not be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "A pool with this name exists already.": [
  null,
  "Já existe um pool de armazenamento com esse nome."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Um sistema de arquivos com esse nome já existe nesse pool de armazenamento."
 ],
 "Create Stratis pool": [
  null,
  "Criar pool de Stratis"
 ],
 "No block devices are available.": [
  null,
  "Nenhum dispositivo de bloco está disponível."
 ],
 "At least one block device is needed.": [
  null,
  "Pelo menos um dispositivo de bloco é necessário."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Criptografar dados com uma senha"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Criptografar dados com um servidor de chaves Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Criar um instantâneo do sistema de arquivos $0"
 ],
 "Create snapshot and mount": [
  null,
  "Criar snapshot e montar"
 ],
 "Create snapshot only": [
  null,
  "Criar snapshot apenas"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "A exclusão de um sistema de arquivos excluirá todos os dados dele."
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Rename filesystem": [
  null,
  "Renomear sistema de arquivos"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Definir limite do tamanho do sistema de arquivos virtual"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limitar o tamanho do sistema de arquivos virtual"
 ],
 "Virtual size limit": [
  null,
  "Limite do tamanho virtual"
 ],
 "Virtual size": [
  null,
  "Tamanho virtual"
 ],
 "Create RAID device": [
  null,
  "Criar dispositivo RAID"
 ],
 "RAID level": [
  null,
  "Nível de RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Distribuição)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Espelhamento)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Paridade Dedicada)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Paridade Distribuída)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Paridade Duplamente Distribuída)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Distribuição de Espelhos)"
 ],
 "Chunk size": [
  null,
  "Tamanho do Bloco"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Pelo menos $0 disco é necessário.",
  "Pelo menos $0 discos são necessários."
 ],
 "MDRAID disk": [
  null,
  "Disco MDRAID"
 ],
 "In sync": [
  null,
  "Em Sincronização"
 ],
 "Spare": [
  null,
  "Reposição"
 ],
 "Recovering": [
  null,
  "Recuperação"
 ],
 "Write-mostly": [
  null,
  "Maioria-Escrita"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Unknown ($0)": [
  null,
  "Desconhecido ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "O dispositivo MDRAID deve estar em execução"
 ],
 "MDRAID device is recovering": [
  null,
  "O dispositivo MDRAID está se recuperando"
 ],
 "Need a spare disk": [
  null,
  "Precisa de um disco sobressalente"
 ],
 "Last disk can not be removed": [
  null,
  "O último disco não pode ser removido"
 ],
 "MDRAID device": [
  null,
  "Dispositivo MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmar a parada de $0"
 ],
 "Stop device": [
  null,
  "Parar dispositivo"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "A exclusão apaga todos os dados em um dispositivo MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "O dispositivo MDRAID deve estar em execução"
 ],
 "Add disk": [
  null,
  "Adicionar disco"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 discos"
 ],
 "$0 chunk size": [
  null,
  "Tamanho do bloco $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "O dispositivo MDRAID está em um estado degradado"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Este dispositivo MDRAID não tem bitmap de intenção de gravação. Tal bitmap pode reduzir significativamente os tempos de sincronização."
 ],
 "Add a bitmap": [
  null,
  "Adicionar um bitmap"
 ],
 "No disks found": [
  null,
  "Nenhum discos encontrados"
 ],
 "MDRAID disks": [
  null,
  "Discos MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "A exclusão apaga todos os dados em um dispositivo VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "A criação deste dispositivo VDO não foi concluída e o dispositivo não pode ser usado."
 ],
 "Remove device": [
  null,
  "Remover dispositivo"
 ],
 "Grow to take all space": [
  null,
  "Aumentar o tamanho para tomar todo o espaço"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Este dispositivo VDO não usa todo o seu dispositivo de apoio."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Somente $0 de $1 está em uso."
 ],
 "Grow logical size of $0": [
  null,
  "Aumentar o tamanho lógico de $0"
 ],
 "Physical": [
  null,
  "Fisica"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dados + $1 sobrecarga usada de $2 ($3)"
 ],
 "Logical": [
  null,
  "Lógico"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usados of $1 ($2 salvos)"
 ],
 "Index memory": [
  null,
  "Memória de índice"
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-teste de $target"
 ],
 "Ejecting $target": [
  null,
  "Ejetando $target"
 ],
 "Unlocking $target": [
  null,
  "Desbloqueando $target"
 ],
 "Locking $target": [
  null,
  "Bloqueando $target"
 ],
 "Modifying $target": [
  null,
  "Modificando $target"
 ],
 "Resizing $target": [
  null,
  "Redimensionando $target"
 ],
 "Starting swapspace $target": [
  null,
  "Iniciando swapspace $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Parando swapspace $target"
 ],
 "Mounting $target": [
  null,
  "Montando $target"
 ],
 "Unmounting $target": [
  null,
  "Desmontando $target"
 ],
 "Checking $target": [
  null,
  "Vericando $target"
 ],
 "Repairing $target": [
  null,
  "Reparando $target"
 ],
 "Erasing $target": [
  null,
  "Apagando $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Criando sistema de arquivos em $target"
 ],
 "Setting up loop device $target": [
  null,
  "Configurando o dispositivo de loop $target"
 ],
 "Deleting $target": [
  null,
  "Deletando $target"
 ],
 "Creating partition $target": [
  null,
  "Criando partição $target"
 ],
 "Cleaning up for $target": [
  null,
  "Limpando $target"
 ],
 "Securely erasing $target": [
  null,
  "Apagando com segurança $target"
 ],
 "Very securely erasing $target": [
  null,
  "Apagando com muita segurança $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Parando o Dispositivo MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Iniciando o Dispositivo MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Marcando $target como defeituoso"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Removendo $target de Dispositivo MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Criando dispositivo MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Checando Dispositivo MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Checando e corrigindo o dispositivo MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Recuperando dispositivo MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Sincronizando Dispositivo MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Ativando $target"
 ],
 "Deactivating $target": [
  null,
  "Desativando $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Criando snapshot de $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Criando o grupo de volumes LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Excluindo grupo de volume LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Adicionando volume físico a $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Removendo volume físico de $target"
 ],
 "Emptying $target": [
  null,
  "Esvaziando $target"
 ],
 "Creating logical volume $target": [
  null,
  "Criando volume lógico $target"
 ],
 "Renaming $target": [
  null,
  "Renomeando $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operação '$operation' em $target"
 ],
 "unknown target": [
  null,
  "alvo desconhecido"
 ],
 "Jobs": [
  null,
  "Trabalhos"
 ],
 "Reading": [
  null,
  "Lendo"
 ],
 "Writing": [
  null,
  "Escrevendo"
 ],
 "Install Stratis support": [
  null,
  "Instalar suporte ao Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "O pacote $0 deve ser instalado para criar pools Stratis."
 ],
 "Install NFS support": [
  null,
  "Instalar o suporte ao NFS"
 ],
 "Create MDRAID device": [
  null,
  "Criar dispositivo MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Criar grupo de volumes LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Alterar Nome do Iniciador iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Adicionar portal iSCSI"
 ],
 "Local storage": [
  null,
  "Armazenamento local"
 ],
 "Networked storage": [
  null,
  "Armazenamento em rede"
 ],
 "Create storage device": [
  null,
  "Criar dispositivo de armazenamento"
 ],
 "No storage found": [
  null,
  "Nenhum armazenamento encontrado"
 ],
 "Server address cannot be empty.": [
  null,
  "O endereço do servidor não pode estar vazio."
 ],
 "Next": [
  null,
  "Próximo"
 ],
 "Invalid username or password": [
  null,
  "Nome de usuário ou senha inválidos"
 ],
 "Unknown host name": [
  null,
  "Nome de host desconhecido"
 ],
 "Unable to reach server": [
  null,
  "Não é possível acessar o servidor"
 ],
 "Available targets on $0": [
  null,
  "Alvos disponíveis em $0"
 ],
 "Authentication required": [
  null,
  "Autenticação requerida"
 ],
 "iSCSI portal": [
  null,
  "Portal iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Drive iSCSI"
 ],
 "No drives found": [
  null,
  "Nenhum discos encontrados"
 ],
 "Target": [
  null,
  "Alvo"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Dispositivos de suporte VDO não podem ser menores"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Dispositivos de blocos Stratis não podem ser menores"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui."
 ],
 "Unlock before resizing": [
  null,
  "Desbloquear antes de redimensionar"
 ],
 "$0 can not be resized here": [
  null,
  "$0 não pode ser redimensionado aqui"
 ],
 "$0 can not be resized": [
  null,
  "$0 não pode ser redimensionado"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 não pode ser reduzido"
 ],
 "$0 can not be made larger": [
  null,
  "$0 não pode ser aumentado"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Volumes físicos não podem ser redimensionados aqui"
 ],
 "Swap can not be resized here": [
  null,
  "Swap não pode ser redimensionado aqui"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui"
 ],
 "Activate before resizing": [
  null,
  "Ativar antes de redimensionar"
 ],
 "Grow logical volume": [
  null,
  "Aumentar o Volume Lógico"
 ],
 "Grow partition": [
  null,
  "Aumentar a partição"
 ],
 "grow": [
  null,
  "incrementar"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exatamente $0 volumes físicos devem ser selecionados"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Redimensionar um sistema de arquivos criptografado requer desbloquear o disco. Forneça uma senha de disco atual."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exatamente $0 volumes físicos precisam ser selecionados, um para cada faixa do volume lógico."
 ],
 "Shrink logical volume": [
  null,
  "Diminuir volume lógico"
 ],
 "shrink": [
  null,
  "compactar"
 ],
 "Unformatted data": [
  null,
  "Dados não formatados"
 ],
 "Block device": [
  null,
  "Dispositivo de bloco"
 ],
 "Device number": [
  null,
  "Número do dispositivo"
 ],
 "Create partition on $0": [
  null,
  "Criar Partição em $0"
 ],
 "Format $0": [
  null,
  "Formatar $0"
 ],
 "No filesystem": [
  null,
  "Nenhum sistema de arquivos"
 ],
 "(recommended)": [
  null,
  "(recomendado)"
 ],
 "No encryption": [
  null,
  "Sem criptografia"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Recusar criptografia existente ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Reusar criptografia existente"
 ],
 "format": [
  null,
  "formatar"
 ],
 "Format and mount": [
  null,
  "Formatar e montar"
 ],
 "Format only": [
  null,
  "Apenas formatar"
 ],
 "Format": [
  null,
  "Formato"
 ],
 "Create and start": [
  null,
  "Criar e iniciar"
 ],
 "Format and start": [
  null,
  "Formatar e iniciar"
 ],
 "Store passphrase": [
  null,
  "Armazene a senha"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "O disco precisa ser desbloqueado antes da formatação. Por favor, forneça uma senha existente."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "A formatação apaga todos os dados em um dispositivo de armazenamento."
 ],
 "Unrecognized data": [
  null,
  "Dados não reconhecidos"
 ],
 "Storage can not be managed on this system.": [
  null,
  "O armazenamento não pode ser gerenciado neste sistema."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuração e resolução de problemas do Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
