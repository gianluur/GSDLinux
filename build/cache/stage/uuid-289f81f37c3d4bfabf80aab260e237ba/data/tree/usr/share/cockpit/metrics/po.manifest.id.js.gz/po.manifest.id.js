cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Overview": [
  null,
  "Ringkasan"
 ],
 "user": [
  null,
  "pengguna"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
