cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Служби"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "network": [
  null,
  "мережа"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "інтерфейс"
 ],
 "bridge": [
  null,
  "місток"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "прив’язка"
 ],
 "team": [
  null,
  "команда"
 ],
 "port": [
  null,
  "порт"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "брандмауер"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "зона"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Керування зв'язками у мережі"
 ],
 "Managing networking teams": [
  null,
  "Керування командами у мережі"
 ],
 "Managing networking bridges": [
  null,
  "Керування містками у мережі"
 ],
 "Managing VLANs": [
  null,
  "Керування VLAN"
 ],
 "Managing firewall": [
  null,
  "Керування брандмауером"
 ]
});
