cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "user": [
  null,
  "usuario"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
