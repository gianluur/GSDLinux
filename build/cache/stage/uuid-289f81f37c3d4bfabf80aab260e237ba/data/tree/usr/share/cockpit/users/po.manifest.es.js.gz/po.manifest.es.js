cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Accounts": [
  null,
  "Cuentas"
 ],
 "user": [
  null,
  "usuario"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "contraseña"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nombre de usuario"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "acceso"
 ],
 "roles": [
  null,
  "roles"
 ],
 "keys": [
  null,
  "teclas"
 ],
 "Managing user accounts": [
  null,
  "Gestión de cuentas de usuario"
 ]
});
