cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Contenedores de Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "contenedor"
 ],
 "image": [
  null,
  "imagen"
 ]
});
