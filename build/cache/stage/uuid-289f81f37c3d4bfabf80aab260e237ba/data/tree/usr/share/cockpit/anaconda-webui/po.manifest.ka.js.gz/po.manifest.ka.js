cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
