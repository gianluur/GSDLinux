cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Hapus ( $0 )?"
 ],
 "Force delete": [
  null,
  "Paksa hapus"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Must be a valid IP address": [
  null,
  "Harus berupa alamat IP yang valid"
 ],
 "1 to 65535": [
  null,
  "1 hingga 65535"
 ],
 "Container port must not be empty": [
  null,
  "Port kontainer tidak boleh kosong"
 ],
 "IP address": [
  null,
  "Alamat IP"
 ],
 "IP address help": [
  null,
  "Bantuan alamat IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jika IP host disetel ke 0.0.0.0 atau tidak disetel sama sekali, port akan diikat pada semua IP di host."
 ],
 "Host port": [
  null,
  "Port host"
 ],
 "Host port help": [
  null,
  "Bantuan port host"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jika port host tidak disetel, port kontainer akan ditetapkan secara acak ke sebuah port pada host."
 ],
 "Container port": [
  null,
  "Port kontainer"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Hapus item"
 ],
 "Image name is required": [
  null,
  "Nama image wajib diisi"
 ],
 "Image name is not unique": [
  null,
  "Nama image tidak unik"
 ],
 "Failed to commit container $0": [
  null,
  "Gagal melakukan commit pada kontainer ( $0 )"
 ],
 "New image name": [
  null,
  "Nama image baru"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Author": [
  null,
  "Penulis"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Contoh, Nama Anda <yourname@example.com>"
 ],
 "Command": [
  null,
  "Perintah"
 ],
 "Options": [
  null,
  "Opsi"
 ],
 "Pause container when creating image": [
  null,
  "Jeda kontainer saat membuat image"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Format Docker berguna saat membagikan image dengan Docker atau Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Gunakan format Docker lama"
 ],
 "Commit container": [
  null,
  "Commit kontainer"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Buat image baru berdasarkan status saat ini dari kontainer ( $0 )."
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Force commit": [
  null,
  "Paksa commit"
 ],
 "Failed to force remove container $0": [
  null,
  "Gagal memaksa menghapus kontainer ( $0 )"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Menghapus kontainer yang sedang berjalan akan menghapus semua data di dalamnya."
 ],
 "Failed to stop container $0": [
  null,
  "Gagal menghentikan kontainer ( $0 )"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Gagal menghentikan quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Gagal memulai quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Gagal memulai kontainer ( $0 )"
 ],
 "Failed to resume container $0": [
  null,
  "Gagal melanjutkan kontainer ( $0 )"
 ],
 "Failed to pause container $0": [
  null,
  "Gagal menjeda kontainer ( $0 )"
 ],
 "Failed to restart container $0": [
  null,
  "Gagal memulai ulang kontainer ( $0 )"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Gagal memulai ulang quadlet $0"
 ],
 "Rename": [
  null,
  "Ganti nama"
 ],
 "Stop": [
  null,
  "Hentikan"
 ],
 "Restart": [
  null,
  "Mulai ulang"
 ],
 "Force stop": [
  null,
  "Paksa hentikan"
 ],
 "Force restart": [
  null,
  "Paksa mulai ulang"
 ],
 "Pause": [
  null,
  "Jeda"
 ],
 "Resume": [
  null,
  "Lanjutkan"
 ],
 "Checkpoint": [
  null,
  "Checkpoint"
 ],
 "Start": [
  null,
  "Mulai"
 ],
 "Restore": [
  null,
  "Pulihkan"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Healthy": [
  null,
  "Sehat"
 ],
 "Unhealthy": [
  null,
  "Tidak sehat"
 ],
 "Checking health": [
  null,
  "Memeriksa kesehatan"
 ],
 "Prune unused containers": [
  null,
  "Pangkas kontainer yang tidak digunakan"
 ],
 "Terminal not available": [
  null,
  "Terminal tidak tersedia"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Browser ini tidak mendukung WebGL2."
 ],
 "View $0 logs": [
  null,
  "Lihat log ( $0 )"
 ],
 "not available": [
  null,
  "tidak tersedia"
 ],
 "n/a": [
  null,
  "n/a"
 ],
 "$0% of $1 limit": [
  null,
  "( $0 )% dari batas ( $1 )"
 ],
 "service": [
  null,
  "layanan"
 ],
 "system": [
  null,
  "sistem"
 ],
 "user:": [
  null,
  "pengguna:"
 ],
 "Details": [
  null,
  "Detail"
 ],
 "Integration": [
  null,
  "Integrasi"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Health check": [
  null,
  "Pemeriksaan kesehatan"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memori"
 ],
 "Click to see published ports": [
  null,
  "Klik untuk melihat port yang dipublikasikan"
 ],
 "ports": [
  null,
  "port"
 ],
 "Click to see volumes": [
  null,
  "Klik untuk melihat volume"
 ],
 "volumes": [
  null,
  "volume"
 ],
 "Container": [
  null,
  "Kontainer"
 ],
 "Owner": [
  null,
  "Pemilik"
 ],
 "State": [
  null,
  "Status"
 ],
 "Actions": [
  null,
  "Tindakan"
 ],
 "No containers": [
  null,
  "Tidak ada kontainer"
 ],
 "No containers in this pod": [
  null,
  "Tidak ada kontainer di pod ini"
 ],
 "Loading...": [
  null,
  "Memuat..."
 ],
 "No containers that match the current filter": [
  null,
  "Tidak ada kontainer yang cocok dengan filter saat ini"
 ],
 "No running containers": [
  null,
  "Tidak ada kontainer yang berjalan"
 ],
 "Show": [
  null,
  "Tampilkan"
 ],
 "All": [
  null,
  "Semua"
 ],
 "Only running": [
  null,
  "Hanya yang berjalan"
 ],
 "Create pod": [
  null,
  "Buat pod"
 ],
 "Create container": [
  null,
  "Buat kontainer"
 ],
 "Containers": [
  null,
  "Kontainer"
 ],
 "Create container in pod": [
  null,
  "Buat kontainer dalam pod"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Gagal memulihkan kontainer ( $0 )"
 ],
 "Restore container $0": [
  null,
  "Pulihkan kontainer ( $0 )"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Simpan semua file checkpoint sementara"
 ],
 "Restore with established TCP connections": [
  null,
  "Pulihkan dengan koneksi TCP yang sudah terjalin"
 ],
 "Ignore IP address if set statically": [
  null,
  "Abaikan alamat IP jika disetel secara statis"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Abaikan alamat MAC jika disetel secara statis"
 ],
 "Pod failed to be created": [
  null,
  "Pod gagal dibuat"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Karakter tidak valid. Nama hanya boleh berisi huruf, angka, dan tanda baca tertentu (_ . -)."
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Pod name": [
  null,
  "Nama pod"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "User:": [
  null,
  "Pengguna:"
 ],
 "No ports exposed": [
  null,
  "Tidak ada port yang diekspos"
 ],
 "Port mapping": [
  null,
  "Pemetaan port"
 ],
 "Add port mapping": [
  null,
  "Tambahkan pemetaan port"
 ],
 "No volumes specified": [
  null,
  "Tidak ada volume yang ditentukan"
 ],
 "Volumes": [
  null,
  "Volume"
 ],
 "Add volume": [
  null,
  "Tambahkan volume"
 ],
 "Create": [
  null,
  "Buat"
 ],
 "Type to filter…": [
  null,
  "Ketik untuk memfilter…"
 ],
 "Container path must not be empty": [
  null,
  "Jalur kontainer tidak boleh kosong"
 ],
 "Host path": [
  null,
  "Jalur host"
 ],
 "Container path": [
  null,
  "Jalur kontainer"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Writable": [
  null,
  "Dapat ditulis"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Tanpa label"
 ],
 "Shared": [
  null,
  "Dibagikan"
 ],
 "Private": [
  null,
  "Pribadi"
 ],
 "Read-write access": [
  null,
  "Akses baca-tulis"
 ],
 "Read-only access": [
  null,
  "Akses hanya-baca"
 ],
 "Show less": [
  null,
  "Tampilkan lebih sedikit"
 ],
 "Show more": [
  null,
  "Tampilkan lebih banyak"
 ],
 "Loading details...": [
  null,
  "Memuat detail..."
 ],
 "Ports": [
  null,
  "Port"
 ],
 "Environment variables": [
  null,
  "Variabel lingkungan"
 ],
 "Failed to download image $0:$1": [
  null,
  "Gagal mengunduh image ( $0 ):( $1 )"
 ],
 "Error message": [
  null,
  "Pesan kesalahan"
 ],
 "unused": [
  null,
  "tidak digunakan"
 ],
 "$0 container": [
  null,
  "( $0 ) kontainer"
 ],
 "History": [
  null,
  "Riwayat"
 ],
 "Image": [
  null,
  "Image"
 ],
 "Created": [
  null,
  "Dibuat"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Ruang disk"
 ],
 "Used by": [
  null,
  "Digunakan oleh"
 ],
 "No images": [
  null,
  "Tidak ada image"
 ],
 "No images that match the current filter": [
  null,
  "Tidak ada image yang cocok dengan filter saat ini"
 ],
 "Hide intermediate images": [
  null,
  "Sembunyikan image perantara"
 ],
 "Show intermediate images": [
  null,
  "Tampilkan image perantara"
 ],
 "Images": [
  null,
  "Image"
 ],
 "$0 image total, $1": [
  null,
  "Total ( $0 ) image, ( $1 )"
 ],
 "$0 unused image, $1": [
  null,
  "( $0 ) image tidak digunakan, ( $1 )"
 ],
 "Hide images": [
  null,
  "Sembunyikan image"
 ],
 "Show images": [
  null,
  "Tampilkan image"
 ],
 "Pulling": [
  null,
  "Sedang menarik"
 ],
 "Download new image": [
  null,
  "Unduh image baru"
 ],
 "Pull all images": [
  null,
  "Tarik semua image"
 ],
 "Prune unused images": [
  null,
  "Pangkas image yang tidak digunakan"
 ],
 "Pull": [
  null,
  "Tarik"
 ],
 "Up since:": [
  null,
  "Aktif sejak:"
 ],
 "Exited": [
  null,
  "Keluar"
 ],
 "systemd service": [
  null,
  "layanan systemd"
 ],
 "View $0": [
  null,
  "Lihat ( $0 )"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "MAC address": [
  null,
  "Alamat MAC"
 ],
 "Latest checkpoint": [
  null,
  "Checkpoint terbaru"
 ],
 "No containers are using this image": [
  null,
  "Tidak ada kontainer yang menggunakan image ini"
 ],
 "Running": [
  null,
  "Berjalan"
 ],
 "Loading logs...": [
  null,
  "Memuat log..."
 ],
 "Delete unused system images:": [
  null,
  "Hapus image sistem yang tidak digunakan:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Hapus image tidak digunakan milik pengguna ( $0 ):"
 ],
 "Failed to prune unused images": [
  null,
  "Gagal memangkas image yang tidak digunakan"
 ],
 "Pruning images": [
  null,
  "Memangkas image"
 ],
 "Prune": [
  null,
  "Pangkas"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Gagal melakukan checkpoint pada kontainer ( $0 )"
 ],
 "Checkpoint container $0": [
  null,
  "Checkpoint kontainer ( $0 )"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Biarkan tetap berjalan setelah menulis checkpoint ke disk"
 ],
 "Support preserving established TCP connections": [
  null,
  "Dukungan mempertahankan koneksi TCP yang sudah terjalin"
 ],
 "Failed to search for new images": [
  null,
  "Gagal mencari image baru"
 ],
 "Failed to search for images: $0": [
  null,
  "Gagal mencari image: ( $0 )"
 ],
 "Failed to search for images.": [
  null,
  "Gagal mencari image."
 ],
 "Search for an image": [
  null,
  "Cari sebuah image"
 ],
 "Search for": [
  null,
  "Cari"
 ],
 "Search by name or description": [
  null,
  "Cari berdasarkan nama atau deskripsi"
 ],
 "in": [
  null,
  "di"
 ],
 "All registries": [
  null,
  "Semua registry"
 ],
 "Searching...": [
  null,
  "Sedang mencari..."
 ],
 "No images found": [
  null,
  "Tidak ditemukan image"
 ],
 "Start typing to look for images.": [
  null,
  "Mulai mengetik untuk mencari image."
 ],
 "No results for $0": [
  null,
  "Tidak ada hasil untuk ( $0 )"
 ],
 "Retry another term.": [
  null,
  "Coba istilah lain."
 ],
 "Download": [
  null,
  "Unduh"
 ],
 "No action": [
  null,
  "Tidak ada tindakan"
 ],
 "Container failed to be started": [
  null,
  "Kontainer gagal dijalankan"
 ],
 "Failed to clean up container": [
  null,
  "Gagal membersihkan kontainer"
 ],
 "Container failed to be created": [
  null,
  "Kontainer gagal dibuat"
 ],
 "downloading": [
  null,
  "mengunduh"
 ],
 "Failed to run container $0": [
  null,
  "Gagal menjalankan kontainer ( $0 )"
 ],
 "Failed to create container $0": [
  null,
  "Gagal membuat kontainer ( $0 )"
 ],
 "Failed to pull image $0": [
  null,
  "Gagal menarik image ( $0 )"
 ],
 "Local images": [
  null,
  "Image lokal"
 ],
 "Name already in use": [
  null,
  "Nama sudah digunakan"
 ],
 "Search by registry": [
  null,
  "Cari berdasarkan registry"
 ],
 "Local": [
  null,
  "Lokal"
 ],
 "Container name": [
  null,
  "Nama kontainer"
 ],
 "Owner help": [
  null,
  "Bantuan pemilik"
 ],
 "Ideal for running services": [
  null,
  "Ideal untuk menjalankan layanan"
 ],
 "Resource limits can be set": [
  null,
  "Batas sumber daya dapat disetel"
 ],
 "Checkpoint and restore support": [
  null,
  "Dukungan checkpoint dan pemulihan"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Port di bawah 1024 dapat dipetakan"
 ],
 "User": [
  null,
  "Pengguna"
 ],
 "Ideal for development": [
  null,
  "Ideal untuk pengembangan"
 ],
 "Restricted by user account permissions": [
  null,
  "Dibatasi oleh izin akun pengguna"
 ],
 "Image selection help": [
  null,
  "Bantuan pemilihan image"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/kontainer[:tag]"
 ],
 "Example: $0": [
  null,
  "Contoh: ( $0 )"
 ],
 "Searching: $0": [
  null,
  "Sedang mencari: ( $0 )"
 ],
 "Search string or container location": [
  null,
  "String pencarian atau lokasi kontainer"
 ],
 "Pull latest image": [
  null,
  "Tarik image terbaru"
 ],
 "Entrypoint": [
  null,
  "Titik masuk"
 ],
 "With terminal": [
  null,
  "Dengan terminal"
 ],
 "Memory limit": [
  null,
  "Batas memori"
 ],
 "Decrease memory": [
  null,
  "Kurangi memori"
 ],
 "Increase memory": [
  null,
  "Tingkatkan memori"
 ],
 "Memory unit": [
  null,
  "Satuan memori"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Pembagian CPU"
 ],
 "CPU Shares help": [
  null,
  "Bantuan pembagian CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Pembagian CPU menentukan prioritas kontainer yang berjalan. Prioritas default adalah 1024. Angka yang lebih tinggi memprioritaskan kontainer ini. Angka yang lebih rendah menurunkan prioritas."
 ],
 "Decrease CPU shares": [
  null,
  "Kurangi pembagian CPU"
 ],
 "Increase CPU shares": [
  null,
  "Tingkatkan pembagian CPU"
 ],
 "Restart policy": [
  null,
  "Kebijakan mulai ulang"
 ],
 "Restart policy help": [
  null,
  "Bantuan kebijakan mulai ulang"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Kebijakan mulai ulang yang diikuti saat kontainer berhenti. Penggunaan linger untuk memulai otomatis kontainer mungkin tidak berfungsi dalam beberapa keadaan, seperti saat ecryptfs, systemd-homed, NFS, atau 2FA digunakan pada akun pengguna."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Kebijakan mulai ulang yang diikuti saat kontainer berhenti."
 ],
 "No": [
  null,
  "Tidak"
 ],
 "On failure": [
  null,
  "Saat gagal"
 ],
 "Always": [
  null,
  "Selalu"
 ],
 "Maximum retries": [
  null,
  "Percobaan ulang maksimum"
 ],
 "Decrease maximum retries": [
  null,
  "Kurangi percobaan ulang maksimum"
 ],
 "Increase maximum retries": [
  null,
  "Tingkatkan percobaan ulang maksimum"
 ],
 "No environment variables specified": [
  null,
  "Tidak ada variabel lingkungan yang ditentukan"
 ],
 "Add variable": [
  null,
  "Tambahkan variabel"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Tempel satu atau lebih baris pasangan kunci=nilai ke bidang mana pun untuk impor massal"
 ],
 "Interval": [
  null,
  "Interval"
 ],
 "Health check interval help": [
  null,
  "Bantuan interval pemeriksaan kesehatan"
 ],
 "Interval how often health check is run.": [
  null,
  "Interval seberapa sering pemeriksaan kesehatan dijalankan."
 ],
 "Decrease interval": [
  null,
  "Kurangi interval"
 ],
 "Increase interval": [
  null,
  "Tingkatkan interval"
 ],
 "seconds": [
  null,
  "detik"
 ],
 "Timeout": [
  null,
  "Batas waktu"
 ],
 "Health check timeout help": [
  null,
  "Bantuan batas waktu pemeriksaan kesehatan"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Waktu maksimum yang diizinkan untuk menyelesaikan pemeriksaan kesehatan sebelum suatu interval dianggap gagal."
 ],
 "Decrease timeout": [
  null,
  "Kurangi batas waktu"
 ],
 "Increase timeout": [
  null,
  "Tingkatkan batas waktu"
 ],
 "Start period": [
  null,
  "Periode mulai"
 ],
 "Health check start period help": [
  null,
  "Bantuan periode mulai pemeriksaan kesehatan"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Waktu inisialisasi yang diperlukan agar kontainer melakukan bootstrap."
 ],
 "Decrease start period": [
  null,
  "Kurangi periode mulai"
 ],
 "Increase start period": [
  null,
  "Tingkatkan periode mulai"
 ],
 "Retries": [
  null,
  "Percobaan ulang"
 ],
 "Health check retries help": [
  null,
  "Bantuan percobaan ulang pemeriksaan kesehatan"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Jumlah percobaan ulang yang diizinkan sebelum healthcheck dianggap tidak sehat."
 ],
 "Decrease retries": [
  null,
  "Kurangi percobaan ulang"
 ],
 "Increase retries": [
  null,
  "Tingkatkan percobaan ulang"
 ],
 "When unhealthy": [
  null,
  "Saat tidak sehat"
 ],
 "Health failure check action help": [
  null,
  "Bantuan tindakan saat pemeriksaan gagal karena kesehatan"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Tindakan yang diambil setelah kontainer beralih ke status tidak sehat."
 ],
 "Create container in $0": [
  null,
  "Buat kontainer di ( $0 )"
 ],
 "Create and run": [
  null,
  "Buat dan jalankan"
 ],
 "Description": [
  null,
  "Deskripsi"
 ],
 "Version": [
  null,
  "Versi"
 ],
 "Links": [
  null,
  "Tautan"
 ],
 "Documentation": [
  null,
  "Dokumentasi"
 ],
 "Tags": [
  null,
  "Tag"
 ],
 "Created by": [
  null,
  "Dibuat oleh"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "Comments": [
  null,
  "Komentar"
 ],
 "Unable to load image history": [
  null,
  "Tidak dapat memuat riwayat image"
 ],
 "Key must not be empty": [
  null,
  "Kunci tidak boleh kosong"
 ],
 "Key must not begin with a digit": [
  null,
  "Kunci tidak boleh diawali dengan digit"
 ],
 "Key contains invalid characters": [
  null,
  "Kunci mengandung karakter tidak valid"
 ],
 "Key": [
  null,
  "Kunci"
 ],
 "Value": [
  null,
  "Nilai"
 ],
 "user": [
  null,
  "pengguna"
 ],
 "Podman service failed": [
  null,
  "Layanan Podman gagal"
 ],
 "Troubleshoot": [
  null,
  "Pemecahan masalah"
 ],
 "Failed to force remove image $0": [
  null,
  "Gagal memaksa menghapus image ( $0 )"
 ],
 "intermediate image": [
  null,
  "image perantara"
 ],
 "Failed to remove image $0": [
  null,
  "Gagal menghapus image ( $0 )"
 ],
 "intermediate": [
  null,
  "perantara"
 ],
 "Delete $0 image?": [
  null,
  "Hapus image ( $0 )?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Ada beberapa tag untuk image ini. Pilih image bertag yang akan dihapus."
 ],
 "Delete image": [
  null,
  "Hapus image"
 ],
 "Delete tagged images": [
  null,
  "Hapus image bertag"
 ],
 "Container is not running": [
  null,
  "Kontainer tidak sedang berjalan"
 ],
 "Error occurred while connecting console": [
  null,
  "Terjadi kesalahan saat menyambungkan konsol"
 ],
 "Force delete pod $0?": [
  null,
  "Paksa hapus pod ( $0 )?"
 ],
 "Delete pod $0?": [
  null,
  "Hapus pod ( $0 )?"
 ],
 "An error occurred": [
  null,
  "Terjadi kesalahan"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Pod kosong ( $0 ) akan dihapus secara permanen."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Menghapus pod ini akan menghapus kontainer berikut:"
 ],
 "Failed to start pod $0": [
  null,
  "Gagal memulai pod ( $0 )"
 ],
 "Failed to stop pod $0": [
  null,
  "Gagal menghentikan pod ( $0 )"
 ],
 "Failed to restart pod $0": [
  null,
  "Gagal memulai ulang pod ( $0 )"
 ],
 "Failed to resume pod $0": [
  null,
  "Gagal melanjutkan pod ( $0 )"
 ],
 "Failed to pause pod $0": [
  null,
  "Gagal menjeda pod ( $0 )"
 ],
 "Failed to prune unused containers": [
  null,
  "Gagal memangkas kontainer yang tidak digunakan"
 ],
 "Removes selected non-running containers": [
  null,
  "Menghapus kontainer yang dipilih yang tidak sedang berjalan"
 ],
 "Pruning containers": [
  null,
  "Memangkas kontainer"
 ],
 "Container name is required.": [
  null,
  "Nama kontainer wajib diisi."
 ],
 "Failed to rename container $0": [
  null,
  "Gagal mengganti nama kontainer ( $0 )"
 ],
 "New container name": [
  null,
  "Nama kontainer baru"
 ],
 "Rename container $0": [
  null,
  "Ganti nama kontainer ( $0 )"
 ],
 "Paused": [
  null,
  "Dijeda"
 ],
 "Stopped": [
  null,
  "Dihentikan"
 ],
 "Removing": [
  null,
  "Sedang menghapus"
 ],
 "Configured": [
  null,
  "Dikonfigurasi"
 ],
 "Error": [
  null,
  "Kesalahan"
 ],
 "$0 second": [
  null,
  "( $0 ) detik"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Failing streak": [
  null,
  "Rangkaian kegagalan"
 ],
 "Failed to run health check on container $0": [
  null,
  "Gagal menjalankan pemeriksaan kesehatan pada kontainer ( $0 )"
 ],
 "Run health check": [
  null,
  "Jalankan pemeriksaan kesehatan"
 ],
 "Last 5 runs": [
  null,
  "5 eksekusi terakhir"
 ],
 "Started at": [
  null,
  "Dimulai pada"
 ],
 "Passed health run": [
  null,
  "Eksekusi pemeriksaan kesehatan berhasil"
 ],
 "Failed health run": [
  null,
  "Eksekusi pemeriksaan kesehatan gagal"
 ],
 "Failed to remove container $0": [
  null,
  "Gagal menghapus kontainer ( $0 )"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Menghapus kontainer akan menghapus semua data di dalamnya."
 ]
});
