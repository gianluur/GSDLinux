cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servizi"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "time": [
  null,
  "ora"
 ],
 "date": [
  null,
  "data"
 ],
 "restart": [
  null,
  "riavvia"
 ],
 "shut": [
  null,
  "shut"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "machine": [
  null,
  "macchina"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "Etichetta di inventario"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "alimentazione"
 ],
 "version": [
  null,
  "versione"
 ],
 "host": [
  null,
  "host"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "mitigazione"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "seriale"
 ],
 "graphs": [
  null,
  "grafici"
 ],
 "metrics": [
  null,
  "metriche"
 ],
 "history": [
  null,
  "cronologia"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "dischi"
 ],
 "network": [
  null,
  "rete"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "prestazioni"
 ],
 "Configuring system settings": [
  null,
  "Configurazione delle impostazioni di sistema"
 ],
 "service": [
  null,
  "servizio"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "destinazione"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "timer"
 ],
 "path": [
  null,
  "percorso"
 ],
 "unit": [
  null,
  "unità"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "avvio"
 ],
 "mask": [
  null,
  "maschera"
 ],
 "unmask": [
  null,
  "smaschera"
 ],
 "enable": [
  null,
  "abilita"
 ],
 "disable": [
  null,
  "disabilita"
 ],
 "Managing services": [
  null,
  "Gestione dei servizi"
 ],
 "journal": [
  null,
  "registro"
 ],
 "warning": [
  null,
  "avviso"
 ],
 "error": [
  null,
  "errore"
 ],
 "debug": [
  null,
  "debug"
 ],
 "crash": [
  null,
  "crash"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "Revisione dei log"
 ],
 "console": [
  null,
  "console"
 ],
 "command": [
  null,
  "comando"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
