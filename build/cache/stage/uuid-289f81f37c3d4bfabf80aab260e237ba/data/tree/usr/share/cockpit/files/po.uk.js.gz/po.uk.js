cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Файли Cockpit"
 ],
 "Home": [
  null,
  "Домівка"
 ],
 "Unable to create bookmark directory": [
  null,
  "Не вдалося створити закладку на каталог"
 ],
 "Unable to save bookmark file": [
  null,
  "Не вдалося зберегти файл закладки"
 ],
 "Remove from bookmarks": [
  null,
  "Вилучити із закладок"
 ],
 "Add to bookmarks": [
  null,
  "Додати до закладок"
 ],
 "Bookmarks": [
  null,
  "Закладки"
 ],
 "Bookmarked": [
  null,
  "Має закладку"
 ],
 "Not bookmarked": [
  null,
  "Не має закладки"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Edit path": [
  null,
  "Редагувати шлях"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "A-Z": [
  null,
  "А-Я"
 ],
 "Z-A": [
  null,
  "Я-А"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Largest size": [
  null,
  "Найбільший розмір"
 ],
 "Smallest size": [
  null,
  "Найменший розмір"
 ],
 "Modified": [
  null,
  "Змінено"
 ],
 "First modified": [
  null,
  "Перший змінений"
 ],
 "Last modified": [
  null,
  "Востаннє змінено"
 ],
 "Owner": [
  null,
  "Власник"
 ],
 "Owner ascending": [
  null,
  "Власник за зростанням"
 ],
 "Owner descending": [
  null,
  "Власник за спаданням"
 ],
 "Permissions": [
  null,
  "Права доступу"
 ],
 "Most permissive": [
  null,
  "Найширший доступ"
 ],
 "Least permissive": [
  null,
  "Найвужчий доступ"
 ],
 "Show keyboard shortcuts": [
  null,
  "Показати клавіатурні скорочення"
 ],
 "Filter directory": [
  null,
  "Фільтрувати каталог"
 ],
 "Display as a list": [
  null,
  "Показати як список"
 ],
 "Display as a grid": [
  null,
  "Показати як таблицю"
 ],
 "Sort": [
  null,
  "Упорядкувати"
 ],
 "Hide hidden items": [
  null,
  "Приховати приховані записи"
 ],
 "Show hidden items": [
  null,
  "Показати приховані записи"
 ],
 "$0 files": [
  null,
  "$0 файлів"
 ],
 "Uploaded as $0, $1": [
  null,
  "Вивантажено як $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Замінити файл $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "У «$0» вже існує файл з тією самою назвою. Заміна призведе до перезапису його вмісту."
 ],
 "New file": [
  null,
  "Новий файл"
 ],
 "Original file on server": [
  null,
  "Початковий файл на сервері"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Застосувати цю дію до усіх файлів з конфліктами"
 ],
 "Replace": [
  null,
  "Замінити"
 ],
 "Keep original": [
  null,
  "Зберегти початкове"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Failed": [
  null,
  "Не вдалося"
 ],
 "Upload error": [
  null,
  "Помилка під час вивантаження"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Не вдалося пересунути вивантажений файл до остаточного місця"
 ],
 "Cancelled": [
  null,
  "Скасовано"
 ],
 "Cancelled upload of $0": [
  null,
  "Скасовано вивантаження $0"
 ],
 "File uploaded": [
  null,
  "Файл вивантажено"
 ],
 "Files uploaded": [
  null,
  "Файли вивантажено"
 ],
 "Change permissions": [
  null,
  "Змінити права доступу"
 ],
 "Uploads": [
  null,
  "Вивантаження"
 ],
 "Cancel upload of $0": [
  null,
  "Скасувати вивантаження $0"
 ],
 "Upload $0% completed": [
  null,
  "Вивантаження завершено на $0%"
 ],
 "Upload": [
  null,
  "Вивантажити"
 ],
 "None": [
  null,
  "Немає"
 ],
 "Execute-only": [
  null,
  "Лише виконання"
 ],
 "Write-only": [
  null,
  "Тільки запис"
 ],
 "Write and execute": [
  null,
  "Записати і виконати"
 ],
 "Read-only": [
  null,
  "Лише читання"
 ],
 "Read and execute": [
  null,
  "Читання і виконання"
 ],
 "Read and write": [
  null,
  "Читання та запис"
 ],
 "Read, write, and execute": [
  null,
  "Читання, запис і виконання"
 ],
 "Block device": [
  null,
  "Блоковий пристрій"
 ],
 "Character device": [
  null,
  "Символьний пристрій"
 ],
 "Directory": [
  null,
  "Каталог"
 ],
 "Named pipe": [
  null,
  "Іменований канал"
 ],
 "Symbolic link": [
  null,
  "Символічне посилання"
 ],
 "Regular file": [
  null,
  "Звичайний файл"
 ],
 "Socket": [
  null,
  "Сокет"
 ],
 "Name cannot be empty": [
  null,
  "Назва не може бути порожньою"
 ],
 "Name too long": [
  null,
  "Назва є надто довгою"
 ],
 "Name cannot include a /": [
  null,
  "у назві не може бути /"
 ],
 "Filename is the same as original name": [
  null,
  "Назва файла збігається із початковою назвою"
 ],
 "Directory with the same name exists": [
  null,
  "Каталог із такою назвою вже існує"
 ],
 "File exists": [
  null,
  "Файл існує"
 ],
 "Pasting failed": [
  null,
  "Не вдалося вставити"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "«$0» існує, не переписуємо вставлянням."
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Create directory": [
  null,
  "Створити каталог"
 ],
 "Create file": [
  null,
  "Створити файл"
 ],
 "Edit permissions": [
  null,
  "Редагувати права доступу"
 ],
 "Open in terminal": [
  null,
  "Відкрити в терміналі"
 ],
 "Open text file": [
  null,
  "Відкрити текстовий файл"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Download": [
  null,
  "Отримати"
 ],
 "Create link": [
  null,
  "Створити посилання"
 ],
 "Drop files to upload": [
  null,
  "Скиньте файли для вивантаження"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Скидання файлів неможливе, виконуємо інше вивантаження"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Go up a directory": [
  null,
  "Вище за ієрархією каталогів"
 ],
 "Go back": [
  null,
  "Назад"
 ],
 "Go forward": [
  null,
  "Вперед"
 ],
 "Activate selected item, enter directory": [
  null,
  "Активувати позначений запис, увійти до каталогу"
 ],
 "Rename selected file or directory": [
  null,
  "Перейменувати позначений файл або каталог"
 ],
 "Create new directory": [
  null,
  "Створити новий каталог"
 ],
 "Copy selected file or directory": [
  null,
  "Копіювати позначений файл або каталог"
 ],
 "Paste file or directory": [
  null,
  "Вставити файл або каталог"
 ],
 "Select all": [
  null,
  "Вибрати все"
 ],
 "Save current file": [
  null,
  "Зберегти поточний файл"
 ],
 "Close editor": [
  null,
  "Закрити редактор"
 ],
 "Keyboard shortcuts": [
  null,
  "Клавіатурні скорочення"
 ],
 "Navigation": [
  null,
  "Навігація"
 ],
 "Editing": [
  null,
  "Редагування"
 ],
 "Editor": [
  null,
  "Редактор"
 ],
 "Force delete $0 items": [
  null,
  "Примусово вилучити $0 записів"
 ],
 "Delete $0 items?": [
  null,
  "Вилучити $0 записів?"
 ],
 "Force delete file $0?": [
  null,
  "Примусово вилучити файл $0?"
 ],
 "Delete file $0?": [
  null,
  "Вилучити файл $0?"
 ],
 "Force delete link $0?": [
  null,
  "Примусово вилучити посилання $0?"
 ],
 "Delete link $0?": [
  null,
  "Вилучити посилання $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Примусово вилучити каталог $0?"
 ],
 "Delete directory $0?": [
  null,
  "Вилучити каталог $0?"
 ],
 "Force delete $0": [
  null,
  "Примусове вилучення $0"
 ],
 "Delete $0?": [
  null,
  "Вилучити $0?"
 ],
 "No access": [
  null,
  "Немає доступу"
 ],
 "Missing type": [
  null,
  "Пропущено тип"
 ],
 "Collapse": [
  null,
  "Згорнути"
 ],
 "Show all files": [
  null,
  "Показати усі файли"
 ],
 "$0 permissions": [
  null,
  "Права доступу $0"
 ],
 "Permissions for $0 files": [
  null,
  "Права доступу для $0 файлів"
 ],
 "Ownership": [
  null,
  "Власність"
 ],
 "Group": [
  null,
  "Група"
 ],
 "Access": [
  null,
  "Доступ"
 ],
 "Owner access": [
  null,
  "Доступ власника"
 ],
 "Group access": [
  null,
  "Груповий доступ"
 ],
 "Others access": [
  null,
  "Доступ інших"
 ],
 "Security context": [
  null,
  "Контекст безпеки"
 ],
 "Set executable as program": [
  null,
  "Встановити виконуваність як програми"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change permissions for enclosed files": [
  null,
  "Змінити права для вкладених файлів"
 ],
 "(original owner)": [
  null,
  "(початковий власник)"
 ],
 "keep original owners": [
  null,
  "зберегти початкового власника"
 ],
 "Paste as owner": [
  null,
  "Вставити як власник"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Файли, які ви вставляєте мають іншого власника. Типово, права власності буде змінено так, щоб вони відповідали каталогу призначення."
 ],
 "New owner": [
  null,
  "Новий власник"
 ],
 "Overwrite": [
  null,
  "Перезаписати"
 ],
 "New filename": [
  null,
  "Нова назва файла"
 ],
 "New name": [
  null,
  "Нова назва"
 ],
 "Rename $0?": [
  null,
  "Перейменувати $0?"
 ],
 "link to $0": [
  null,
  "посилання на $0"
 ],
 "Create link to $0": [
  null,
  "Створити посилання на $0"
 ],
 "Target": [
  null,
  "Призначення"
 ],
 "Symlink name": [
  null,
  "Назва символічного посилання"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Absolute vs. Relative": [
  null,
  "Абсолютні і відносні"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Абсолютні символічні посилання ідеальні при посиланні на файли і каталоги, які не буде переміщено, зокрема файлів системи."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Відносні символічні посилання корисні при можливості переміщення символічного посилання і призначення, зокрема при перейменуванні або переміщенні батьківського каталогу."
 ],
 "Absolute": [
  null,
  "Абсолютні"
 ],
 "Relative": [
  null,
  "Відносний"
 ],
 "The file has been removed on disk": [
  null,
  "Файли було вилучено на диску"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Наявний файл неочікувано змінено"
 ],
 "Edit $0": [
  null,
  "Змінити $0"
 ],
 "View $0": [
  null,
  "Перегляд $0"
 ],
 "The file has changed on disk": [
  null,
  "Файл змінено на диску"
 ],
 "Reload": [
  null,
  "Перезавантажити"
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save changes?": [
  null,
  "Зберегти зміни?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Файл було вилучено після відкриття — його збереження призведе до повторного створення файла."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Файл змінено на диску між моментом його відкриття і поточним моментом"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "У $0 є незбережені зміни, які буде незворотно втрачено, якщо дані буде відкинуто."
 ],
 "Discard": [
  null,
  "Відкинути"
 ],
 "File name": [
  null,
  "Назва файла"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Cannot create file in current directory": [
  null,
  "Не вдалося створити файл у поточному каталозі"
 ],
 "Permission denied": [
  null,
  "Відмовлено у доступі"
 ],
 "Directory name cannot be empty": [
  null,
  "Назва каталогу має бути непорожньою"
 ],
 "Directory name too long": [
  null,
  "Назва каталогу занадто довга"
 ],
 "Directory name cannot include a /": [
  null,
  "У назві каталогу не може бути /"
 ],
 "Directory name": [
  null,
  "Назва каталогу"
 ],
 "Directory owner": [
  null,
  "Власник каталогу"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "Clear filter": [
  null,
  "Зняти фільтрування"
 ],
 "Directory is empty": [
  null,
  "Каталог є порожнім"
 ],
 "$0 item is hidden": [
  null,
  "$0 запис приховано",
  "$0 записи приховано",
  "$0 записів приховано"
 ],
 "Folder": [
  null,
  "Тека"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Others": [
  null,
  "Інші"
 ],
 "$0 files selected": [
  null,
  "Позначено $0 файлів"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "У каталозі міститься $0 каталогів, $1 файлів"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "У каталозі міститься $0 каталогів, $1 файлів, $2 прихованих записів"
 ],
 "User": [
  null,
  "Користувач"
 ]
});
