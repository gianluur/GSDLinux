cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ta",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
