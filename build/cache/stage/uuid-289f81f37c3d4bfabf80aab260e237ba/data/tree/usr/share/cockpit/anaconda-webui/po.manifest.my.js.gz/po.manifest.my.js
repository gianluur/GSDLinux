cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "my",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
