cockpit.locale({
 "": {
  "plural-forms": ((n) => n % 10 != 1 || n % 100 == 11),
  "language": "is",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
