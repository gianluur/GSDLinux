cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "სერვისები"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "ინტერფეისი"
 ],
 "bridge": [
  null,
  "ხიდი"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "გადაბმა"
 ],
 "team": [
  null,
  "გუნდი"
 ],
 "port": [
  null,
  "პორტი"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "ზონა"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "ქსელის ბარათების გაერთიანების მართვა"
 ],
 "Managing networking teams": [
  null,
  "ქსელური ბარათების გუნდების მართვა"
 ],
 "Managing networking bridges": [
  null,
  "ქსელური ხიდების მართვა"
 ],
 "Managing VLANs": [
  null,
  "VLAN-ის მართვა"
 ],
 "Managing firewall": [
  null,
  "ბრანდმაუერის მართვა"
 ]
});
