cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "unmount": [
  null,
  "ຍົກເລີກການຕິດຕັ້ງ (unmount)"
 ],
 "mount": [
  null,
  "ເມົາທ໌ (mount)"
 ],
 "format": [
  null,
  "ຟໍແມັດ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "partition": [
  null,
  "ພາທິຊັນ"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "ວໍລຸ່ມ"
 ],
 "disk": [
  null,
  "ດິດ"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "ໄດຣຟ໌"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "ການເຂົ້າລະຫັດ"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "ການຈັດການພາກສ່ວນດິສກ໌"
 ],
 "Managing NFS mounts": [
  null,
  "ການຈັດການການເມົາທ໌ NFS"
 ],
 "Managing RAIDs": [
  null,
  "ການຈັດການ RAID"
 ],
 "Managing LVMs": [
  null,
  "ການຈັດການ LVM"
 ],
 "Managing physical drives": [
  null,
  "ການຈັດການໄດຣຟ໌ຟີຊິກ"
 ],
 "Managing VDOs": [
  null,
  "ການຈັດການ VDO"
 ],
 "Using LUKS encryption": [
  null,
  "ກຳລັງໃຊ້ການເຂົ້າລະຫັດ LUKS"
 ],
 "Using Tang server": [
  null,
  "ກຳລັງໃຊ້ເຊີເວີ Tang"
 ]
});
