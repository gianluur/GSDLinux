cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
