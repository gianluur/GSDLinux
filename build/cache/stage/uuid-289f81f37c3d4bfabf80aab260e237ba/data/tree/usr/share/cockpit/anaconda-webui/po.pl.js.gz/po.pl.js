cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 błąd",
  "$0 błędy",
  "$0 błędów"
 ],
 "$0 installation": [
  null,
  "Instalacja systemu $0"
 ],
 "$0 installer": [
  null,
  "Instalator systemu $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 jest rozszerzoną partycją MBR, która zawiera partycje logiczne. Usunięcie wszystkich partycji logicznych spowoduje także automatyczne usunięcie partycji rozszerzonej."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Wymagane jest $0, ale dostępne jest tylko $1."
 ],
 "$0 warning": [
  null,
  "$0 ostrzeżenie",
  "$0 ostrzeżenia",
  "$0 ostrzeżeń"
 ],
 "$0 will be deleted": [
  null,
  "System $0 zostanie usunięty"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "System plików „$0” nie może być na zaszyfrowanym urządzeniu blokowym"
 ],
 "'$0' must be assigned to $1": [
  null,
  "Punkt montowania „$0” musi być na urządzeniu przypisanym jako „$1”"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "Punkt montowania „$0” musi być na urządzeniu sformatowanym jako „$1”"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' musi być na partycji systemowej EFI. Wybrana partycja używa systemu plików FAT, lecz nie jest zaznaczona jako ESP. Wybierz typ partycji jako System EFI i włącz flagę ESP."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Odnaleziono partycję „$0” na urządzeniu MDRAID $1. Partycje programu startowego na urządzeniach MDRAID nie są obsługiwane."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Standardowe konto użytkownika z dostępem administratora do wprowadzania zmian w systemie."
 ],
 "Abort installation": [
  null,
  "Anuluj instalację"
 ],
 "About": [
  null,
  "Informacje"
 ],
 "Account": [
  null,
  "Konto"
 ],
 "Actions": [
  null,
  "Działania"
 ],
 "Add another server...": [
  null,
  "Dodaj kolejny serwer…"
 ],
 "Add mount": [
  null,
  "Dodaj punkt montowania"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Dodatki do wybranego środowiska"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Dodatki niezwiązane ze środowiskiem użytkownika"
 ],
 "Additional languages": [
  null,
  "Dodatkowe języki"
 ],
 "Additional software for the selected environment": [
  null,
  "Dodatkowe oprogramowanie dla wybranego środowiska"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Wszystkie zmiany wprowadzone w edytorze urządzeń do przechowywania danych są stosowane natychmiast."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Wszystkie urządzenia używające tego hasła zostaną odblokowane"
 ],
 "Anaconda Web UI": [
  null,
  "Interfejs użytkownika Anaconda Web"
 ],
 "Anaconda project page": [
  null,
  "Strona projektu Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Zastosuj przydział punktów montowania i zainstaluj"
 ],
 "Applying changes...": [
  null,
  "Zastosowywanie zmian…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Przydziela partycje do punktów montowania. Przydatne dla wstępnie skonfigurowanych niestandardowych układów."
 ],
 "Automatic log file upload": [
  null,
  "Automatyczne wysyłanie pliku dziennika"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Automatyczne ustawianie daty i czasu za pomocą serwerów czasu"
 ],
 "Automatically set timezone": [
  null,
  "Automatyczne ustawianie strefy czasowej"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Dostępne wolne miejsce: $0. Instalacja wymaga: $1."
 ],
 "Back": [
  null,
  "Wstecz"
 ],
 "Base environment": [
  null,
  "Podstawowe środowisko"
 ],
 "Brief description of the issue": [
  null,
  "Krótki opis błędu (w języku angielskim)"
 ],
 "Bug report details": [
  null,
  "Informacje o zgłoszeniu błędu"
 ],
 "Bugzilla API key": [
  null,
  "Klucz API serwisu Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Kontynuując używanie tego oprogramowania użytkownik potwierdza, że rozumie i akceptuje ryzyko związane z oprogramowaniem testowym, ma zamiar używać go wyłącznie do testowania i rozwijania, a także chce zgłaszać błędy lub problemy w celu jego ulepszenia."
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Change destination": [
  null,
  "Zmień miejsce docelowe"
 ],
 "Change hostname": [
  null,
  "Zmień nazwę komputera"
 ],
 "Change partition layout": [
  null,
  "Zmień układ partycji"
 ],
 "Change system keyboard layout": [
  null,
  "Zmień układ klawiatury systemu"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Zmiany wprowadzone w tym miejscu będą miały natychmiastowy wpływ na komputer. Nie ma możliwości cofnięcia."
 ],
 "Checking installation configuration...": [
  null,
  "Sprawdzanie konfiguracji instalacji…"
 ],
 "Checking storage configuration": [
  null,
  "Sprawdzanie konfiguracji urządzeń do przechowywania danych"
 ],
 "Clear search": [
  null,
  "Wyczyść wyszukiwanie"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Kliknięcie „Dalej” drugi raz kontynuuje pomimo tych ostrzeżeń."
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Close storage editor": [
  null,
  "Zamknij edytora urządzeń do przechowywania danych"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit-Storage nie dostarczyło hasła do odblokowania zaszyfrowanego urządzenia."
 ],
 "Completed": [
  null,
  "Ukończono"
 ],
 "Configuration is incomplete": [
  null,
  "Konfiguracja jest niepełna"
 ],
 "Configure NTP servers": [
  null,
  "Skonfiguruj serwery NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Konfiguracja niestandardowych serwerów NTP"
 ],
 "Configure network": [
  null,
  "Skonfiguruj sieć"
 ],
 "Configure storage": [
  null,
  "Skonfiguruj urządzenia do przechowywania danych"
 ],
 "Configure storage again": [
  null,
  "Ponownie skonfiguruj urządzenia do przechowywania danych"
 ],
 "Confirm passphrase": [
  null,
  "Potwierdzenie hasła"
 ],
 "Continue": [
  null,
  "Kontynuuj"
 ],
 "Continue installation": [
  null,
  "Kontynuuj instalację"
 ],
 "Continue installation?": [
  null,
  "Kontynuować instalację?"
 ],
 "Continue with installation": [
  null,
  "Kontynuuj instalację"
 ],
 "Correct these issues before continuing.": [
  null,
  "Proszę naprawić te problemy przed kontynuowaniem."
 ],
 "Create Account": [
  null,
  "Utwórz Konto"
 ],
 "Create account": [
  null,
  "Utwórz konto"
 ],
 "Currently installed: $0": [
  null,
  "Obecnie zainstalowane: $0"
 ],
 "Custom": [
  null,
  "Niestandardowy"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data i czas"
 ],
 "Delete partition": [
  null,
  "Usuwa partycję"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Usunięcie pewnych partycji może uniemożliwić uruchomienie systemu $0: $1"
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Destination": [
  null,
  "Miejsce docelowe"
 ],
 "Destination is encrypted": [
  null,
  "Miejsce docelowe jest zaszyfrowane"
 ],
 "Detailed description of the issue": [
  null,
  "Szczegółowy opis błędu (w języku angielskim)"
 ],
 "Detected valid storage layout:": [
  null,
  "Wykryto prawidłowy układ urządzeń do przechowywania danych:"
 ],
 "Device": [
  null,
  "Urządzenie"
 ],
 "Duplicate device.": [
  null,
  "Podwójne urządzenie."
 ],
 "Duplicate mount point.": [
  null,
  "Podwójny punkt montowania."
 ],
 "Enable root account": [
  null,
  "Włączone konto roota"
 ],
 "Encrypt my data": [
  null,
  "Szyfrowanie danych"
 ],
 "Encrypted": [
  null,
  "Zaszyfrowane"
 ],
 "Encryption": [
  null,
  "Szyfrowanie"
 ],
 "Enter PIN": [
  null,
  "Wprowadź PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Wprowadź PIN żeby uzyskać dostęp do instalatora"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Proszę podać klucz API serwisu Bugzilla, aby utworzyć zgłoszenie błędu. W następnym kroku będzie można przejrzeć i zmodyfikować informacje o błędzie."
 ],
 "Environment": [
  null,
  "Środowisko"
 ],
 "Erase data and install": [
  null,
  "Usuń dane i zainstaluj"
 ],
 "Error details": [
  null,
  "Informacje o błędzie"
 ],
 "Exit to live desktop": [
  null,
  "Wyjdź do pulpitu"
 ],
 "Extended partition": [
  null,
  "Partycja rozszerzona"
 ],
 "Failed to report issue": [
  null,
  "Zgłoszenie błędu się nie powiodło"
 ],
 "Failed to save layouts": [
  null,
  "Zapisanie układów się nie powiodło"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux wymaga co najmniej $0 wolnego miejsca na dysku."
 ],
 "Finalization": [
  null,
  "Kończenie"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Kończenie: ukończono konfigurację systemu. Dokończenie instalacji może chwilę zająć."
 ],
 "Find layout": [
  null,
  "Wyszukiwanie układu"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Dla większego bezpieczeństwa należy unikać bezpośredniego używania konta roota. Zamiast tego do zarządzania systemem należy używać powyższego lokalnego konta."
 ],
 "Full name": [
  null,
  "Imię i nazwisko"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Imię i nazwisko nie mogą zawierać dwukropków"
 ],
 "Helper text": [
  null,
  "Tekst pomocniczy"
 ],
 "Hide API key": [
  null,
  "Ukryj klucz API"
 ],
 "Hide PIN": [
  null,
  "Ukryj PIN"
 ],
 "Hide confirmed password": [
  null,
  "Ukryj potwierdzone hasło"
 ],
 "Hide passphrase": [
  null,
  "Ukryj hasło"
 ],
 "Hide password": [
  null,
  "Ukryj hasło"
 ],
 "Hostname": [
  null,
  "Nazwa komputera"
 ],
 "How would you like to install?": [
  null,
  "W jaki sposób zainstalować?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Rozumiem, że wszystkie istniejące dane zostaną usunięte",
  "Rozumiem, że wszystkie istniejące dane zostaną usunięte z wybranych dysków",
  "Rozumiem, że wszystkie istniejące dane zostaną usunięte z wybranych dysków"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Rozumiem, że część istniejących danych zostanie usunięta"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Rozumiem, że część partycji zostanie zmodyfikowanych"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Jeśli puste, nazwa komputera będzie tymczasowa i zostanie ustawiona na podstawie informacji sieciowych."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Jeśli żadna z powyższych opcji nie ma zastosowania, przed kontynuacją utwórz niestandardowe partycjonowanie za pomocą edytora pamięci masowej."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "W przypadku konfigurowania partycji wymagane są następujące elementy:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Jeśli użytkownik nie wyrazi zgody na automatyczne wysyłanie pliku dziennika, to można zamiast tego $0. Ręczne zgłoszenie umożliwia przejrzenie i samodzielne dołączenie wybranych plików dziennika."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Jeśli użytkownik nie rozumie lub nie akceptuje ryzyka, to proszę zakończyć ten program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Jeśli Twój problem pasuje do jednego z powyższych błędów, otwórz go i dodaj swoje informacje, zamiast tworzyć duplikat."
 ],
 "In progress": [
  null,
  "W trakcie"
 ],
 "Initializing...": [
  null,
  "Inicjowanie…"
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Installation completed": [
  null,
  "Instalacja zakończona"
 ],
 "Installation failed": [
  null,
  "Instalacja się nie powiodła"
 ],
 "Installation method": [
  null,
  "Metoda instalacji"
 ],
 "Installation of the system failed": [
  null,
  "Instalacja systemu się nie powiodła"
 ],
 "Installation of the system failed: $0": [
  null,
  "Instalacja systemu się nie powiodła: $0"
 ],
 "Installation type": [
  null,
  "Typ instalacji"
 ],
 "Installing": [
  null,
  "Instalowanie"
 ],
 "Insufficient disk space": [
  null,
  "Za mało miejsca na dysku"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Nieprawidłowy PIN. Spróbuj ponownie."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Wykryto nieprawidłową konfigurację RAID. Jeśli macierz RAID jest tworzona bezpośrednio na dyskach, tablica partycji musi być utworzona na macierzy. Jeśli macierz RAID jest tworzona na partycjach, to musi zawierać tylko jeden system plików lub format (np. wolumin fizyczny LVM). Wszystkie istniejące partycje na tej macierzy będą ignorowane."
 ],
 "Invalid hostname": [
  null,
  "Nieprawidłowa nazwa komputera"
 ],
 "Jump to first incomplete step": [
  null,
  "Przejdź do pierwszego nieukończonego kroku"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Zachowuje obecny układ dysku i wykorzystuje dostępne miejsce, aby móc uruchamiać się jednocześnie z innym systemem operacyjnym."
 ],
 "Keyboard": [
  null,
  "Klawiatura"
 ],
 "Keyboard layout during boot": [
  null,
  "Układ klawiatury podczas uruchamiania"
 ],
 "Language": [
  null,
  "Język"
 ],
 "Launch storage editor": [
  null,
  "Uruchom edytor urządzeń do przechowywania danych"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Więcej informacji o ograniczonym dostępie znajduje się w konfiguracji"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Zostaw oba pola hasła puste żeby użyć pustego hasła."
 ],
 "Location": [
  null,
  "Położenie"
 ],
 "Locked devices": [
  null,
  "Zablokowane urządzenia"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Make current": [
  null,
  "Ustaw jako obecnie używany"
 ],
 "Manual disk configuration": [
  null,
  "Ręczna konfiguracja dysku"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Ręczna konfiguracja dysku: mapowanie punktów montowania"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Może zawierać litery, cyfry i myślniki."
 ],
 "May need more free space": [
  null,
  "Może potrzebować więcej wolnego miejsca"
 ],
 "Medium": [
  null,
  "Średnie"
 ],
 "Minimum of $0 required": [
  null,
  "Wymagane jest co najmniej $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Rozbieżność między wyborem ponownego formatowania urządzenia nadrzędnego i urządzenia potomnego."
 ],
 "Mount point": [
  null,
  "Punkt montowania"
 ],
 "Mount point assignment": [
  null,
  "Przydzielenie punktów montowania"
 ],
 "Move down": [
  null,
  "Przenieś w dół"
 ],
 "Move up": [
  null,
  "Przenieś w górę"
 ],
 "Must be at least $0 characters": [
  null,
  "Minimalna liczba znaków: $0"
 ],
 "My issue is different, continue": [
  null,
  "Mam inny problem, kontynuuj"
 ],
 "NTP Servers": [
  null,
  "Serwery NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Needs at least $0": [
  null,
  "Potrzebuje co najmniej $0"
 ],
 "Network": [
  null,
  "Sieć"
 ],
 "Network Configuration": [
  null,
  "Konfiguracja sieci"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Sieć jest niedostępna. Proszę skonfigurować sieć w menu na górnym pasku, aby zgłosić problem."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Sieć jest niedostępna. Proszę skonfigurować sieć, aby zgłosić problem."
 ],
 "Network plugin failed": [
  null,
  "Wtyczka sieci się nie powiodła"
 ],
 "Next": [
  null,
  "Dalej"
 ],
 "No devices": [
  null,
  "Brak urządzeń"
 ],
 "No disks available": [
  null,
  "Brak dostępnych dysków"
 ],
 "No disks selected": [
  null,
  "Nie wybrano dysków"
 ],
 "No keyboard layouts selected": [
  null,
  "Nie wybrano żadnego układu klawiatury"
 ],
 "No layouts selected yet": [
  null,
  "Nie wybrano jeszcze żadnego układu"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Nie można uzyskać prawidłowej mapy klawiszy VConsole dla wybranego układu klawiatury. Proszę wybrać inny układ."
 ],
 "Not enough available free space": [
  null,
  "Za mało dostępnego wolnego miejsca"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Za mało wolnego miejsca na wybranych dyskach."
 ],
 "Not enough space on selected disks.": [
  null,
  "Za mało miejsca na wybranych dyskach."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Uwaga: to jest wydanie testowe, przeznaczone wyłącznie do rozwijania i testowania. Nie należy używać tego oprogramowania w środowiskach produkcyjnych."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Otwórz formularz zgłaszania błędu w serwisie Bugzilla"
 ],
 "Operating system": [
  null,
  "System operacyjny"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Other keyboards": [
  null,
  "Inne klawiatury"
 ],
 "Partitions (advanced)": [
  null,
  "Partycje (zaawansowane)"
 ],
 "Passphrase": [
  null,
  "Hasło"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Hasło nie pasuje do żadnego zablokowanego urządzenia"
 ],
 "Passphrases must match": [
  null,
  "Hasła muszą się zgadzać"
 ],
 "Pending": [
  null,
  "Nieukończone"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Proszę załączyć plik dziennika $0 w zgłoszeniu."
 ],
 "Please enter a PIN": [
  null,
  "Proszę podać PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Proszę wybrać co najmniej jeden dysk, aby kontynuować"
 ],
 "Pool": [
  null,
  "Pula"
 ],
 "Potential duplicate bugs found": [
  null,
  "Znaleziono podobne zgłoszenia błędów"
 ],
 "Powered by Anaconda": [
  null,
  "Używa technologii Anaconda"
 ],
 "Pre-release": [
  null,
  "Wydanie testowe"
 ],
 "Prefer to report manually? $0": [
  null,
  "Zgłosić ręcznie? $0"
 ],
 "Proceed with installation": [
  null,
  "Kontynuuj instalację"
 ],
 "Quit": [
  null,
  "Zakończ"
 ],
 "Quit installer?": [
  null,
  "Zakończyć instalatora?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Odczytanie informacji o systemie operacyjnym się nie powiodło."
 ],
 "Reading information about the computer failed.": [
  null,
  "Odczytanie informacji o komputerze się nie powiodło."
 ],
 "Reading installer configuration failed.": [
  null,
  "Odczytanie konfiguracji instalatora się nie powiodło."
 ],
 "Reading installer version information failed.": [
  null,
  "Odczytanie informacji o wersji instalatora się nie powiodło."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Prawdziwa nazwa komputera może zawierać tylko litery, cyfry, myślniki (ale nie na początku ani końcu) i kropki"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Prawdziwa nazwa komputera nie może mieć więcej niż 64 znaki"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Należy uruchomić ponownie do systemu Windows, aby zmienić rozmiar partycji zaszyfrowanych funkcją BitLocker. Instalacja wymaga co najmniej $0 wolnego miejsca."
 ],
 "Reboot system?": [
  null,
  "Uruchomić komputer ponownie?"
 ],
 "Reclaim additional space": [
  null,
  "Odzyskanie dodatkowego miejsca"
 ],
 "Reclaim space": [
  null,
  "Odzyskaj miejsce"
 ],
 "Reclaim space (required)": [
  null,
  "Odzyskanie miejsca (wymagane)"
 ],
 "Recommended": [
  null,
  "Zalecany"
 ],
 "Recommended partitions:": [
  null,
  "Zalecane partycje:"
 ],
 "Reformat": [
  null,
  "Ponowne formatowanie"
 ],
 "Reinstall Fedora": [
  null,
  "Ponownie zainstaluj Fedorę"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Usuwa wszystkie partycje na wybranych urządzeniach, w tym istniejące systemy operacyjne."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Należy usunąć lub zmienić rozmiar istniejących systemów plików, aby zwolnić miejsce na instalację."
 ],
 "Remove server": [
  null,
  "Usuń serwer"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Usunięcie systemu plików spowoduje trwałe usunięcie wszystkich danych, jakie zawiera. Zmiana rozmiaru partycji może zwolnić nieużywane miejsce, ale nie jest bez ryzyka. Proszę się upewnić, że wykonano kopię zapasową ważnych danych przed odzyskiwaniem miejsca."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Zastępuje obecną instalację, ale zachowuje pliki w katalogu domowym."
 ],
 "Report Issue": [
  null,
  "Zgłoś błąd"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Proszę zgłosić błąd lub podzielić się opinią, otwierając formularz zgłaszania błędu w serwisie Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Zgłoś błąd"
 ],
 "Reporting issue...": [
  null,
  "Zgłaszanie błędu…"
 ],
 "Required": [
  null,
  "Wymagany"
 ],
 "Requirements": [
  null,
  "Wymagania"
 ],
 "Rescan devices": [
  null,
  "Ponownie skanuj urządzenia"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Ponowne skanowanie dysków się nie powiodło."
 ],
 "Resize": [
  null,
  "Zmień rozmiar"
 ],
 "Resize partition": [
  null,
  "Zmienia rozmiar partycji"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Zmienianie rozmiaru następujących partycji systemu $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Ograniczenie dostępu do zgłoszenia"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Ogranicza zgłoszenie do grupy $0. $1"
 ],
 "Return to installation": [
  null,
  "Wróć do instalacji"
 ],
 "Return to storage editor": [
  null,
  "Wróć do edytora urządzeń do przechowywania danych"
 ],
 "Review and install": [
  null,
  "Przegląd i instalacja"
 ],
 "Root account has been configured": [
  null,
  "Skonfigurowano konto roota"
 ],
 "Root account is enabled": [
  null,
  "Konto roota jest włączone"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Konto roota jest włączone, ale żadne konto użytkownika nie jest skonfigurowane"
 ],
 "Root password has been set.": [
  null,
  "Ustawiono hasło roota."
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Proszę zeskanować kod QR za pomocą telefonu lub otworzyć stronę:"
 ],
 "Search for a language": [
  null,
  "Wyszukiwanie języka"
 ],
 "Search for additional software": [
  null,
  "Wyszukiwanie dodatkowego oprogramowania"
 ],
 "Search for an environment": [
  null,
  "Wyszukiwanie środowiska"
 ],
 "Search keyboard layout": [
  null,
  "Wyszukiwanie układów klawiatury"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Zabezpiecza dane za pomocą szyfrowania na poziomie dysku. Ma zastosowanie tylko do nowych partycji"
 ],
 "Select": [
  null,
  "Wybierz"
 ],
 "Select a device": [
  null,
  "Wybierz urządzenie"
 ],
 "Select city": [
  null,
  "Wybierz miasto"
 ],
 "Select destination": [
  null,
  "Wybierz miejsce docelowe"
 ],
 "Select region": [
  null,
  "Wybierz region"
 ],
 "Selected (top = current)": [
  null,
  "Wybrane (na górze jest obecnie używany)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Nie można ponownie formatować formatu „$0” wybranego urządzenia."
 ],
 "Send us feedback on your installation": [
  null,
  "Prześlij nam swoją opinię na temat instalacji"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "Server is not reachable": [
  null,
  "Nie można połączyć się z serwerem"
 ],
 "Set custom hostname": [
  null,
  "Ustaw niestandardową nazwę komputera"
 ],
 "Share disk with other operating systems": [
  null,
  "Dziel dysk z innymi systemami operacyjnymi"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Dziel dysk z innymi systemami operacyjnymi: $0"
 ],
 "Show AM/PM": [
  null,
  "Wyświetlanie AM/PM"
 ],
 "Show API key": [
  null,
  "Wyświetl klucz API"
 ],
 "Show PIN": [
  null,
  "Wyświetl PIN"
 ],
 "Show confirmed password": [
  null,
  "Wyświetl potwierdzone hasło"
 ],
 "Show passphrase": [
  null,
  "Wyświetl hasło"
 ],
 "Show password": [
  null,
  "Wyświetl hasło"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "Software installation": [
  null,
  "Instalacja oprogramowania"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalacja oprogramowania: ukończono konfigurację urządzeń do przechowywania danych. Oprogramowanie jest teraz instalowane na urządzeniu."
 ],
 "Software selection": [
  null,
  "Wybór oprogramowania"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Część kroków instalacji nadal musi zostać ukończona, aby kontynuować."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Brakuje części wymaganych partycji: $0"
 ],
 "Space": [
  null,
  "Miejsce"
 ],
 "Stacktrace": [
  null,
  "Ślad stosu"
 ],
 "Storage": [
  null,
  "Urządzenia do przechowywania danych"
 ],
 "Storage configuration": [
  null,
  "Konfiguracja urządzeń do przechowywania danych"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Konfiguracja urządzeń do przechowywania danych: w trakcie."
 ],
 "Storage editor": [
  null,
  "Edytor urządzeń do przechowywania danych"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Urządzenia do przechowywania danych są na podstawie konfiguracji z „Modyfikuj urządzenia do przechowywania danych”."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Układ urządzeń do przechowywania danych jest określony przez plik kickstart. Zaplanowany układ partycjonowania może zostać przejrzany w kroku podsumowania."
 ],
 "Storage plugin failed": [
  null,
  "Wtyczka urządzeń do przechowywania danych się nie powiodła"
 ],
 "Storage requirements not met": [
  null,
  "Wymagania urządzeń do przechowywania danych nie zostały spełnione"
 ],
 "Strong": [
  null,
  "Silne"
 ],
 "Successfully installed": [
  null,
  "Zainstalowano pomyślnie"
 ],
 "Successfully unlocked $0.": [
  null,
  "Pomyślnie odblokowano urządzenie $0."
 ],
 "Suggested keyboards": [
  null,
  "Proponowane klawiatury"
 ],
 "Suggested languages": [
  null,
  "Proponowane języki"
 ],
 "System": [
  null,
  "System"
 ],
 "System configuration": [
  null,
  "Konfiguracja systemu"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Konfiguracja systemu: ukończono instalację oprogramowania. System jest teraz konfigurowany."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Instalacja Anaconda nieoczekiwanie zakończyła działanie."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Poniższe otwarte błędy mogą być związane z twoim problemem. Proszę sprawdź je przed utworzeniem nowego raportu."
 ],
 "The following user will be created:": [
  null,
  "Ten użytkownik zostanie utworzony:",
  "Następujący użytkownicy zostaną utworzeni:",
  "Następujący użytkownicy zostaną utworzeni:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Wymagane miejsce na dysku: $0, pojemność wybranych dysków: $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Instalator nie może kontynuować z powodu krytycznego błędu."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Instalator nie może kontynuować z powodu krytycznego błędu: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Podane hasło zawiera znaki spoza zestawu ASCII. Nie można przełączać między układami klawiatury podczas wpisywania hasła."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Wybrany domyślny układ klawiatury nie obsługuje znaków ASCII. Proszę wybrać układ zdolny do wprowadzania znaków ASCII jako domyślny."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Edytor urządzeń do przechowywania danych umożliwia zmianę rozmiaru, usuwanie i tworzenie partycji. Może skonfigurować LVM i wiele więcej. Jest przeznaczony do używania jako zaawansowane narzędzie i nie powinien być używany do typowej instalacji."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Te pliki dziennika mogą zawierać prywatne informacje, takie jak adresy IP, nazwy użytkowników lub inne informacje o systemie."
 ],
 "This hostname can't be submitted": [
  null,
  "Ta nazwa komputera nie może zostać przesłana"
 ],
 "This is unstable, pre-release software": [
  null,
  "To jest niestabilne, testowe oprogramowanie"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Ten układ będzie używany do odblokowywania komputera podczas uruchamiania"
 ],
 "This may take a moment": [
  null,
  "Może to chwilę zająć"
 ],
 "This will take a few moments": [
  null,
  "To zajmie chwilę"
 ],
 "Time": [
  null,
  "Czas"
 ],
 "Timezone": [
  null,
  "Strefa czasowa"
 ],
 "Title": [
  null,
  "Tytuł"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Uruchom komputer ponownie, aby zacząć korzystać z systemu $0."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Aby kontynuować, proszę wybrać urządzenia, na których zainstalować."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Należy zmienić rozmiar lub usunąć istniejące partycje i zwolnić co najmniej $0, aby móc użyć tej opcji."
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Nie można zaplanować usunięcia $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Nie można zaplanować zmiany rozmiaru $0"
 ],
 "Undo last action": [
  null,
  "Cofa ostatnie działanie"
 ],
 "Unlock": [
  null,
  "Odblokuj"
 ],
 "Unlock encrypted devices": [
  null,
  "Odblokowanie zaszyfrowanych urządzeń"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Odblokowanie zaszyfrowanych partycji pozwoli zachować dane i odkryć kolejne metody instalacji."
 ],
 "Use configured storage": [
  null,
  "Użyj skonfigurowanych urządzeń do przechowywania danych"
 ],
 "Use entire disk": [
  null,
  "Użyj całego dysku"
 ],
 "Use free space": [
  null,
  "Użycie wolnego miejsca"
 ],
 "Use local account": [
  null,
  "Użycie lokalnego konta"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Użycie urządzenia RAID do automatycznego partycjonowania"
 ],
 "User creation": [
  null,
  "Utworzenie użytkownika"
 ],
 "User name": [
  null,
  "Nazwa użytkownika"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Nazwa użytkownika może zawierać tylko: litery od a do z, cyfry od 0 do 9, myślnik ($0), kropkę ($1), podkreślenie ($2)"
 ],
 "User name must not be a reserved word": [
  null,
  "Nazwa użytkownika nie może być słowem zastrzeżonym"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Nazwy użytkowników nie mogą mieć więcej niż 33 znaki"
 ],
 "Validating...": [
  null,
  "Sprawdzanie poprawności…"
 ],
 "Weak": [
  null,
  "Słabe"
 ],
 "Welcome": [
  null,
  "Witaj"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Witaj w Fedorze Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Witaj w instalacji systemu $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Podczas wysyłania tego zgłoszenia błędu, następujące pliki dziennika zostaną automatycznie wysłane: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Nie można zmienić rozmiaru partycji systemu Windows z szyfrowaniem BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  "Możesz teraz zamknąć to okno przeglądarki."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Można zwolnić odpowiednią ilość miejsca i pozwolić instalatorowi zająć się resztą, albo ręcznie skonfigurować partycje."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Można utworzyć klucz API dla konta w serwisie Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Aby kontynuować, należy włączyć konto roota lub utworzyć konto lokalnego użytkownika."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Włączenie automatycznej daty i czasu wymaga połączenia z siecią."
 ],
 "Your progress will not be saved.": [
  null,
  "Postęp nie zostanie zapisany."
 ],
 "completed step": [
  null,
  "ukończony krok"
 ],
 "current step": [
  null,
  "obecny krok"
 ],
 "delete": [
  null,
  "usuń"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "encrypt": [
  null,
  "zaszyfruj"
 ],
 "encrypted": [
  null,
  "zaszyfrowane"
 ],
 "extended partition": [
  null,
  "partycja rozszerzona"
 ],
 "format as $0": [
  null,
  "sformatuj jako $0"
 ],
 "here": [
  null,
  "w tym miejscu"
 ],
 "incomplete": [
  null,
  "nieukończone"
 ],
 "mount": [
  null,
  "punkt montowania"
 ],
 "pending step": [
  null,
  "nieukończony krok"
 ],
 "report the issue manually": [
  null,
  "ręcznie zgłosić błąd"
 ],
 "resized from $0": [
  null,
  "zmieniono rozmiar z $0"
 ],
 "shrink": [
  null,
  "zmniejsz"
 ],
 "shrink to $0": [
  null,
  "zmniejsz do $0"
 ],
 "transient, will use DHCP": [
  null,
  "tymczasowy, użyje DHCP"
 ],
 "undo": [
  null,
  "cofnij"
 ]
});
