cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Explorateur de fichiers"
 ],
 "files": [
  null,
  "fichiers"
 ],
 "explorer": [
  null,
  "explorateur"
 ],
 "filesystem": [
  null,
  "système de fichiers"
 ]
});
