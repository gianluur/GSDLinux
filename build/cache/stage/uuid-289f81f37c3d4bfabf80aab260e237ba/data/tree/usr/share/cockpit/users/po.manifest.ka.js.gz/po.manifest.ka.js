cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Accounts": [
  null,
  "ანგარიშები"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "პაროლი"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "login": [
  null,
  "შესვლა"
 ],
 "access": [
  null,
  "წვდომა"
 ],
 "roles": [
  null,
  "როლები"
 ],
 "keys": [
  null,
  "გასაღებები"
 ],
 "Managing user accounts": [
  null,
  "მომხმარებლების ანგარიშების მართვა"
 ]
});
