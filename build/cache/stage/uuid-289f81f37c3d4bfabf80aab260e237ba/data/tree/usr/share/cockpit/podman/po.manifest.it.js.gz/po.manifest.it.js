cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Container Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "container"
 ],
 "image": [
  null,
  "immagine"
 ]
});
