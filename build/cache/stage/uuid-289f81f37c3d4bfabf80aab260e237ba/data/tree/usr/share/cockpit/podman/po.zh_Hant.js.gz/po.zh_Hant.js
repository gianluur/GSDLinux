cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_Hant",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "刪除 $0?"
 ],
 "Force delete": [
  null,
  "強制刪除"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Must be a valid IP address": [
  null,
  "必須是有效的 IP 位址"
 ],
 "1 to 65535": [
  null,
  "1 到 65535"
 ],
 "Container port must not be empty": [
  null,
  "容器通訊埠不得為空白"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "IP address help": [
  null,
  "IP 地址協助"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "如果主機 IP 設定為 0.0.0.0 或完全未設定，則通訊埠會綁定在主機上的所有 IP 上。"
 ],
 "Host port": [
  null,
  "主機通訊埠"
 ],
 "Host port help": [
  null,
  "主機通訊埠協助"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "如果未設定主機通訊埠，則容器連接埠會隨機分配給主機上的一個通訊埠。"
 ],
 "Container port": [
  null,
  "容器通訊埠"
 ],
 "Protocol": [
  null,
  "通訊協定"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "移除項目"
 ],
 "Image name is required": [
  null,
  "必須填寫映像檔名稱"
 ],
 "Image name is not unique": [
  null,
  "映像檔名稱不唯一"
 ],
 "Failed to commit container $0": [
  null,
  "提交容器失敗 $0"
 ],
 "New image name": [
  null,
  "新映像檔名稱"
 ],
 "Tag": [
  null,
  "標籤"
 ],
 "Author": [
  null,
  "作者"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "範例，您的姓名 <yourname@example.com>"
 ],
 "Command": [
  null,
  "指令"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Pause container when creating image": [
  null,
  "建立映像檔時暫停容器"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker 格式在與 Docker 或 Moby Engine 分享映像檔時非常有用"
 ],
 "Use legacy Docker format": [
  null,
  "使用傳統的 Docker 格式"
 ],
 "Commit container": [
  null,
  "承載容器"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "根據 $0 容器的目前狀態建立新映像檔。"
 ],
 "Commit": [
  null,
  "承載"
 ],
 "Force commit": [
  null,
  "強制提交"
 ],
 "Failed to force remove container $0": [
  null,
  "強制移除容器己失敗 $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "刪除執行中的容器會刪除其中的所有資料。"
 ],
 "Failed to stop container $0": [
  null,
  "停止容器失敗 $0"
 ],
 "Failed to start container $0": [
  null,
  "啟動容器 $0 失敗"
 ],
 "Failed to resume container $0": [
  null,
  "恢復容器失敗 $0"
 ],
 "Failed to pause container $0": [
  null,
  "暫停容器己失敗 $0"
 ],
 "Failed to restart container $0": [
  null,
  "重新啟動容器 $0 失敗"
 ],
 "Rename": [
  null,
  "重新命名"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Restart": [
  null,
  "重新啟動"
 ],
 "Force stop": [
  null,
  "強制停止"
 ],
 "Force restart": [
  null,
  "強制重新啟動"
 ],
 "Pause": [
  null,
  "暫停"
 ],
 "Resume": [
  null,
  "繼續"
 ],
 "Checkpoint": [
  null,
  "檢查點"
 ],
 "Start": [
  null,
  "啟動"
 ],
 "Restore": [
  null,
  "還原"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Healthy": [
  null,
  "健康"
 ],
 "Unhealthy": [
  null,
  "不健康"
 ],
 "Checking health": [
  null,
  "檢查健康狀態"
 ],
 "Prune unused containers": [
  null,
  "修復未使用容器"
 ],
 "This browser does not support WebGL2.": [
  null,
  ""
 ],
 "View $0 logs": [
  null,
  "檢視 $0 記錄檔"
 ],
 "not available": [
  null,
  "不提供"
 ],
 "n/a": [
  null,
  "n/a"
 ],
 "$0% of $1 limit": [
  null,
  "$1 限制的 $0"
 ],
 "service": [
  null,
  "服務"
 ],
 "system": [
  null,
  "系統"
 ],
 "user:": [
  null,
  "使用者:"
 ],
 "Details": [
  null,
  "詳情"
 ],
 "Integration": [
  null,
  "整合"
 ],
 "Logs": [
  null,
  "記錄檔"
 ],
 "Console": [
  null,
  "控制台"
 ],
 "Health check": [
  null,
  "健康狀態檢查"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Click to see published ports": [
  null,
  "按一下以查看已發布使用的通訊埠"
 ],
 "ports": [
  null,
  "通訊埠"
 ],
 "Click to see volumes": [
  null,
  "點擊查看分區(卷)"
 ],
 "volumes": [
  null,
  "分區(卷)"
 ],
 "Container": [
  null,
  "容器"
 ],
 "Owner": [
  null,
  "所有人"
 ],
 "State": [
  null,
  "狀態"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "No containers": [
  null,
  "無容器"
 ],
 "No containers in this pod": [
  null,
  "此 pod 中沒有容器"
 ],
 "Loading...": [
  null,
  "正在載入中..."
 ],
 "No containers that match the current filter": [
  null,
  "沒有符合目前篩選條件的容器"
 ],
 "No running containers": [
  null,
  "無執行中容器"
 ],
 "Show": [
  null,
  "顯示"
 ],
 "All": [
  null,
  "全部"
 ],
 "Only running": [
  null,
  "僅運行"
 ],
 "Create pod": [
  null,
  "建立 pod"
 ],
 "Create container": [
  null,
  "建立容器"
 ],
 "Containers": [
  null,
  "容器"
 ],
 "Create container in pod": [
  null,
  "在 pod 中建立容器"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "還原容器 $0 失敗"
 ],
 "Restore container $0": [
  null,
  "還原容器 $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "保留所有臨時檢查點檔案"
 ],
 "Restore with established TCP connections": [
  null,
  "使用已建立的 TCP 連線進行還原"
 ],
 "Ignore IP address if set statically": [
  null,
  "忽略靜態設定的 IP 位址"
 ],
 "Ignore MAC address if set statically": [
  null,
  "忽略靜態設定的 MAC 位址"
 ],
 "Pod failed to be created": [
  null,
  "Pod 建立己失敗"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "無效字符。 名稱只能包含字母、數字和某些標點符號 (_ . -)."
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Pod name": [
  null,
  "Pod 名稱"
 ],
 "System": [
  null,
  "系統"
 ],
 "User:": [
  null,
  "使用者:"
 ],
 "No ports exposed": [
  null,
  "無通訊埠外露"
 ],
 "Port mapping": [
  null,
  "通訊埠映射"
 ],
 "Add port mapping": [
  null,
  "新增通訊埠映射"
 ],
 "No volumes specified": [
  null,
  "未指定分區(卷)容量"
 ],
 "Volumes": [
  null,
  "分區(卷)"
 ],
 "Add volume": [
  null,
  "新增分卷"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Type to filter…": [
  null,
  "特定類型過濾…"
 ],
 "Container path must not be empty": [
  null,
  "容器路徑不得為空白"
 ],
 "Host path": [
  null,
  "主機路徑"
 ],
 "Container path": [
  null,
  "容器路徑"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Writable": [
  null,
  "可寫"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "無標記"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Private": [
  null,
  "私有"
 ],
 "Read-write access": [
  null,
  "讀寫存取"
 ],
 "Read-only access": [
  null,
  "唯讀存取"
 ],
 "Show less": [
  null,
  "顯示更少"
 ],
 "Show more": [
  null,
  "顯示更多"
 ],
 "Loading details...": [
  null,
  "正在載入詳細資料中..."
 ],
 "Ports": [
  null,
  "通訊埠"
 ],
 "Environment variables": [
  null,
  "環境變數"
 ],
 "Failed to download image $0:$1": [
  null,
  "下載映像檔己失敗 $0:$1"
 ],
 "Error message": [
  null,
  "錯誤訊息"
 ],
 "unused": [
  null,
  "未使用"
 ],
 "$0 container": [
  null,
  "$0 個容器"
 ],
 "History": [
  null,
  "歷史"
 ],
 "Image": [
  null,
  "映像檔"
 ],
 "Created": [
  null,
  "己建立"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "磁碟空間"
 ],
 "Used by": [
  null,
  "已使用"
 ],
 "No images": [
  null,
  "無映像檔"
 ],
 "No images that match the current filter": [
  null,
  "沒有符合目前篩選條件的映像檔"
 ],
 "Hide intermediate images": [
  null,
  "隱藏中介映像檔"
 ],
 "Show intermediate images": [
  null,
  "顯示中介映像檔"
 ],
 "Images": [
  null,
  "映像檔"
 ],
 "$0 image total, $1": [
  null,
  "$0 個映像檔總計 , $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 個未使用的映像檔 , $1"
 ],
 "Hide images": [
  null,
  "隱藏映像檔"
 ],
 "Show images": [
  null,
  "顯示映像檔"
 ],
 "Pulling": [
  null,
  "正在拉取"
 ],
 "Download new image": [
  null,
  "下載新的映像檔"
 ],
 "Pull all images": [
  null,
  "拉取全部映像檔"
 ],
 "Prune unused images": [
  null,
  "修復未使用映像檔"
 ],
 "Pull": [
  null,
  "拉取"
 ],
 "Up since:": [
  null,
  "自此上線："
 ],
 "Exited": [
  null,
  "已退出"
 ],
 "systemd service": [
  null,
  "systemd 服務"
 ],
 "View $0": [
  null,
  "檢視 $0"
 ],
 "Gateway": [
  null,
  "閘道器"
 ],
 "MAC address": [
  null,
  "MAC 地址"
 ],
 "Latest checkpoint": [
  null,
  "最新檢查點"
 ],
 "No containers are using this image": [
  null,
  "沒有容器使用此映像檔"
 ],
 "Running": [
  null,
  "執行中"
 ],
 "Loading logs...": [
  null,
  "正在載入記錄檔中..."
 ],
 "Delete unused system images:": [
  null,
  "刪除未使用的系統映像檔："
 ],
 "Delete unused images of user $0:": [
  null,
  "刪除使用者 $0 未使用的映像檔："
 ],
 "Failed to prune unused images": [
  null,
  "修復未使用的映像檔己失敗"
 ],
 "Pruning images": [
  null,
  "正在修復映像檔"
 ],
 "Prune": [
  null,
  "修復"
 ],
 "Failed to checkpoint container $0": [
  null,
  "檢查點的容器 $0 己失敗"
 ],
 "Checkpoint container $0": [
  null,
  "檢查點容器 $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "將檢查點寫入磁碟後繼續執行"
 ],
 "Support preserving established TCP connections": [
  null,
  "支援保留已建立的 TCP 連線"
 ],
 "Failed to search for new images": [
  null,
  "搜尋新的映像檔失敗"
 ],
 "Failed to search for images: $0": [
  null,
  "搜尋映像檔失敗： $0"
 ],
 "Failed to search for images.": [
  null,
  "搜尋映像檔失敗。"
 ],
 "Search for an image": [
  null,
  "搜尋映像檔"
 ],
 "Search for": [
  null,
  "搜尋"
 ],
 "Search by name or description": [
  null,
  "依名稱或描述搜尋"
 ],
 "in": [
  null,
  "在"
 ],
 "All registries": [
  null,
  "所有註冊"
 ],
 "Searching...": [
  null,
  "正在搜尋中..."
 ],
 "No images found": [
  null,
  "無找到映像檔"
 ],
 "Start typing to look for images.": [
  null,
  "開始輸入尋找映像檔。"
 ],
 "No results for $0": [
  null,
  "沒有 $0 的結果"
 ],
 "Retry another term.": [
  null,
  "重試另一個期限。"
 ],
 "Download": [
  null,
  "下載"
 ],
 "No action": [
  null,
  "無動作"
 ],
 "Container failed to be started": [
  null,
  "容器啟動失敗"
 ],
 "Failed to clean up container": [
  null,
  "未能清理容器"
 ],
 "Container failed to be created": [
  null,
  "容器建立失敗"
 ],
 "downloading": [
  null,
  "正在下載"
 ],
 "Failed to run container $0": [
  null,
  "執行容器 $0 失敗"
 ],
 "Failed to create container $0": [
  null,
  "建立容器 $0 己失敗"
 ],
 "Failed to pull image $0": [
  null,
  "擷取映像檔失敗 $0"
 ],
 "Local images": [
  null,
  "本地映像檔"
 ],
 "Name already in use": [
  null,
  "已使用的名稱"
 ],
 "Search by registry": [
  null,
  "依註冊表搜尋"
 ],
 "Local": [
  null,
  "本地"
 ],
 "Container name": [
  null,
  "容器名稱"
 ],
 "Owner help": [
  null,
  "所有人協助"
 ],
 "Ideal for running services": [
  null,
  "運行服務的理想選擇"
 ],
 "Resource limits can be set": [
  null,
  "可設定系統資源限制"
 ],
 "Checkpoint and restore support": [
  null,
  "檢查點與還原支援"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "可以映射 1024 以下的連接埠"
 ],
 "User": [
  null,
  "使用者"
 ],
 "Ideal for development": [
  null,
  "開發的理想選擇"
 ],
 "Restricted by user account permissions": [
  null,
  "受使用者帳戶權限限制"
 ],
 "Image selection help": [
  null,
  "映像檔選擇說明"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "主機[:通訊埠]/[使用者]/容器[:標籤]"
 ],
 "Example: $0": [
  null,
  "範例: $0"
 ],
 "Searching: $0": [
  null,
  "正在搜尋: $0"
 ],
 "Search string or container location": [
  null,
  "搜尋字串或容器位置"
 ],
 "Pull latest image": [
  null,
  "拉取最新映像檔"
 ],
 "Entrypoint": [
  null,
  "切入點"
 ],
 "With terminal": [
  null,
  "配備終端機"
 ],
 "Memory limit": [
  null,
  "記憶體上限"
 ],
 "Decrease memory": [
  null,
  "減少記憶"
 ],
 "Increase memory": [
  null,
  "增加記憶體"
 ],
 "Memory unit": [
  null,
  "記憶體單元"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU 共享"
 ],
 "CPU Shares help": [
  null,
  "CPU 共享協助"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 共享決定執行中容器的優先順序。 預設優先順序為 1024。 數字越大，此容器的優先順序越高。 數字越小，優先順序越低。"
 ],
 "Decrease CPU shares": [
  null,
  "減少 CPU 共享"
 ],
 "Increase CPU shares": [
  null,
  "增加 CPU 共享"
 ],
 "Restart policy": [
  null,
  "重新啟動政策"
 ],
 "Restart policy help": [
  null,
  "重新啟動政策說明"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "容器退出時要遵循的重新啟動原則。 使用 linger 自動啟動容器在某些情況下可能無法運作，例如當使用者帳戶使用 ecryptfs、systemd-homed、NFS 或 2FA 時。"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "容器退出時要遵循的重新啟動原則。"
 ],
 "No": [
  null,
  "無"
 ],
 "On failure": [
  null,
  "關於失敗"
 ],
 "Always": [
  null,
  "總是"
 ],
 "Maximum retries": [
  null,
  "最大重試次數"
 ],
 "Decrease maximum retries": [
  null,
  "減少最大重試次數"
 ],
 "Increase maximum retries": [
  null,
  "增加最大重試次數"
 ],
 "No environment variables specified": [
  null,
  "未指定環境變數"
 ],
 "Add variable": [
  null,
  "新增變數"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "將一或多行 key=value 對貼到任何欄位，以進行大量匯入"
 ],
 "Interval": [
  null,
  "間隔"
 ],
 "Health check interval help": [
  null,
  "健康狀態檢查間隔幫助"
 ],
 "Interval how often health check is run.": [
  null,
  "執行健康狀態檢查的間隔時間。"
 ],
 "Decrease interval": [
  null,
  "減少間隔"
 ],
 "Increase interval": [
  null,
  "增加間隔"
 ],
 "seconds": [
  null,
  "秒"
 ],
 "Timeout": [
  null,
  "超時"
 ],
 "Health check timeout help": [
  null,
  "健康狀態檢查超時說明"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "在間隔被視為失敗之前，完成健康狀態檢查所允許的最長時間。"
 ],
 "Decrease timeout": [
  null,
  "減少超時"
 ],
 "Increase timeout": [
  null,
  "增加超時"
 ],
 "Start period": [
  null,
  "啟動期間"
 ],
 "Health check start period help": [
  null,
  "健康狀態檢查開始期間的幫助"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "容器開機所需的初始化時間。"
 ],
 "Decrease start period": [
  null,
  "縮短開始時間"
 ],
 "Increase start period": [
  null,
  "增加開始期間"
 ],
 "Retries": [
  null,
  "重試"
 ],
 "Health check retries help": [
  null,
  "健康檢查重試說明"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "在健康狀態檢查被視為不健康之前允許的重試次數。"
 ],
 "Decrease retries": [
  null,
  "減少重複嘗試"
 ],
 "Increase retries": [
  null,
  "增加重試"
 ],
 "When unhealthy": [
  null,
  "不健康時"
 ],
 "Health failure check action help": [
  null,
  "健康失敗檢查行動幫助"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "容器轉換到不健康狀態時得要採取的動作。"
 ],
 "Create container in $0": [
  null,
  "以 $0 建立容器"
 ],
 "Create and run": [
  null,
  "建立並執行"
 ],
 "Description": [
  null,
  ""
 ],
 "Version": [
  null,
  ""
 ],
 "Links": [
  null,
  ""
 ],
 "Documentation": [
  null,
  ""
 ],
 "Tags": [
  null,
  "標籤"
 ],
 "Created by": [
  null,
  "己建立於"
 ],
 "Size": [
  null,
  "占用大小"
 ],
 "Comments": [
  null,
  "評論"
 ],
 "Unable to load image history": [
  null,
  "無法載入映像檔歷史記錄"
 ],
 "Key must not be empty": [
  null,
  "金鑰不可為空"
 ],
 "Key must not begin with a digit": [
  null,
  "金鑰不得以數字開頭"
 ],
 "Key contains invalid characters": [
  null,
  "金鑰包含無效的字元"
 ],
 "Key": [
  null,
  "密鑰"
 ],
 "Value": [
  null,
  "值"
 ],
 "user": [
  null,
  "使用者"
 ],
 "Podman service failed": [
  null,
  "Podman 服務啟動失敗"
 ],
 "Troubleshoot": [
  null,
  "疑難排解"
 ],
 "Failed to force remove image $0": [
  null,
  "強制移除映像檔己失敗 $0"
 ],
 "intermediate image": [
  null,
  "中介映像檔"
 ],
 "Failed to remove image $0": [
  null,
  "移除映像檔失敗 $0"
 ],
 "intermediate": [
  null,
  "中介"
 ],
 "Delete $0 image?": [
  null,
  "刪除 $0 映像檔?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "此映像檔存在多個標記。 選取要刪除的標記的映像檔。"
 ],
 "Delete image": [
  null,
  "刪除映像檔"
 ],
 "Delete tagged images": [
  null,
  "刪除已標記的映像檔"
 ],
 "Container is not running": [
  null,
  "容器未執行"
 ],
 "Error occurred while connecting console": [
  null,
  "連接控制台時發生錯誤"
 ],
 "Force delete pod $0?": [
  null,
  "強制刪除 pod $0?"
 ],
 "Delete pod $0?": [
  null,
  "刪除 pod $0?"
 ],
 "An error occurred": [
  null,
  "發生錯誤"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "空的 pod $0 將被永久移除。"
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "刪除此 pod 將移除下列容器："
 ],
 "Failed to start pod $0": [
  null,
  "啟動 Pod 失敗 $0"
 ],
 "Failed to stop pod $0": [
  null,
  "無法停止 pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "重新啟動 Pod $0 失敗"
 ],
 "Failed to resume pod $0": [
  null,
  "恢復 Pod 失敗 $0"
 ],
 "Failed to pause pod $0": [
  null,
  "暫停 Pod 己失敗 $0"
 ],
 "Failed to prune unused containers": [
  null,
  "未能修復未使用的容器"
 ],
 "Removes selected non-running containers": [
  null,
  "移除己選取的非執行中容器"
 ],
 "Pruning containers": [
  null,
  "正在修復容器"
 ],
 "Container name is required.": [
  null,
  "必須填寫容器名稱。"
 ],
 "Failed to rename container $0": [
  null,
  "重新命名容器 $0 失敗"
 ],
 "New container name": [
  null,
  "新容器名稱"
 ],
 "Rename container $0": [
  null,
  "重新命名容器 $0"
 ],
 "Paused": [
  null,
  "已暫停"
 ],
 "Stopped": [
  null,
  "己停止"
 ],
 "Removing": [
  null,
  "移除"
 ],
 "Configured": [
  null,
  "已設定"
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "$0 second": [
  null,
  "$0 秒"
 ],
 "Status": [
  null,
  "狀態"
 ],
 "Failing streak": [
  null,
  "連續失敗"
 ],
 "Failed to run health check on container $0": [
  null,
  "對容器 $0 執行健康檢查失敗"
 ],
 "Run health check": [
  null,
  "執行健康狀態檢查"
 ],
 "Last 5 runs": [
  null,
  "最近 5 次的運行過程"
 ],
 "Started at": [
  null,
  "己啟動於"
 ],
 "Passed health run": [
  null,
  "通過健康狀態測試"
 ],
 "Failed health run": [
  null,
  "健康測試己失敗"
 ],
 "Failed to remove container $0": [
  null,
  "移除容器失敗 $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "刪除容器會刪除其中的所有資料。"
 ]
});
