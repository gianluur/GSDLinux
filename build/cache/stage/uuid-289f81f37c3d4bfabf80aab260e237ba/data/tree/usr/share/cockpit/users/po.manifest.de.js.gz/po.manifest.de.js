cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Accounts": [
  null,
  "Konten"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "Passwort"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "Benutzername"
 ],
 "login": [
  null,
  "Login"
 ],
 "access": [
  null,
  "Zugriff"
 ],
 "roles": [
  null,
  "Rollen"
 ],
 "keys": [
  null,
  "Schlüssel"
 ],
 "Managing user accounts": [
  null,
  "Benutzerkonten verwalten"
 ]
});
