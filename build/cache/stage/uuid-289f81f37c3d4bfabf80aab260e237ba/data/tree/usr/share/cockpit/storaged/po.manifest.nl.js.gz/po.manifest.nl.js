cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "bestandssysteem"
 ],
 "partition": [
  null,
  "partitie"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volume"
 ],
 "disk": [
  null,
  "schijf"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "station"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "versleuteling"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Partities beheren"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-aankoppelingen beheren"
 ],
 "Managing RAIDs": [
  null,
  "RAID's beheren"
 ],
 "Managing LVMs": [
  null,
  "LVM's beheren"
 ],
 "Managing physical drives": [
  null,
  "Fysieke schijven beheren"
 ],
 "Managing VDOs": [
  null,
  "VDO's beheren"
 ],
 "Using LUKS encryption": [
  null,
  "Gebruikt LUKS-versleuteling"
 ],
 "Using Tang server": [
  null,
  "Gebruikt Tang-server"
 ]
});
