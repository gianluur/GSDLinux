cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Hizmetler"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "network": [
  null,
  "ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "arayüz"
 ],
 "bridge": [
  null,
  "köprü"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "birleştirme"
 ],
 "team": [
  null,
  "takım"
 ],
 "port": [
  null,
  "bağlantı noktası"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "güvenlik duvarı"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "bölge"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Ağ birleştirmelerini yönetme"
 ],
 "Managing networking teams": [
  null,
  "Ağ takımlarını yönetme"
 ],
 "Managing networking bridges": [
  null,
  "Ağ köprülerini yönetme"
 ],
 "Managing VLANs": [
  null,
  "VLAN'ları yönetme"
 ],
 "Managing firewall": [
  null,
  "Güvenlik duvarını yönetme"
 ]
});
