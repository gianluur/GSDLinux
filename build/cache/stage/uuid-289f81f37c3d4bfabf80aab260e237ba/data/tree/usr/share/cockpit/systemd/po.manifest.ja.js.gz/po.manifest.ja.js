cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "サービス"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "time": [
  null,
  "時間"
 ],
 "date": [
  null,
  "日付"
 ],
 "restart": [
  null,
  "再起動"
 ],
 "shut": [
  null,
  "シャット"
 ],
 "domain": [
  null,
  "ドメイン"
 ],
 "machine": [
  null,
  "マシン"
 ],
 "operating system": [
  null,
  "オペレーティングシステム"
 ],
 "os": [
  null,
  "OS"
 ],
 "asset tag": [
  null,
  "アセットタグ"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "電源"
 ],
 "version": [
  null,
  "バージョン"
 ],
 "host": [
  null,
  "ホスト"
 ],
 "hardware": [
  null,
  "ハードウェア"
 ],
 "mitigation": [
  null,
  "軽減"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "memory": [
  null,
  "メモリー"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "シリアル"
 ],
 "graphs": [
  null,
  "グラフ"
 ],
 "metrics": [
  null,
  "メトリックス"
 ],
 "history": [
  null,
  "履歴"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "ディスク"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "パフォーマンス"
 ],
 "Configuring system settings": [
  null,
  "システム設定の変更"
 ],
 "service": [
  null,
  "サービス"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ターゲット"
 ],
 "socket": [
  null,
  "ソケット"
 ],
 "timer": [
  null,
  "タイマー"
 ],
 "path": [
  null,
  "パス"
 ],
 "unit": [
  null,
  "単位"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "ブート"
 ],
 "mask": [
  null,
  "マスク"
 ],
 "unmask": [
  null,
  "マスク解除"
 ],
 "enable": [
  null,
  "有効にする"
 ],
 "disable": [
  null,
  "無効にする"
 ],
 "Managing services": [
  null,
  "サービス管理"
 ],
 "journal": [
  null,
  "ジャーナル"
 ],
 "warning": [
  null,
  "警告"
 ],
 "error": [
  null,
  "エラー"
 ],
 "debug": [
  null,
  "デバッグ"
 ],
 "crash": [
  null,
  "クラッシュ"
 ],
 "coredump": [
  null,
  "コアダンプ"
 ],
 "Reviewing logs": [
  null,
  "ログのレビュー"
 ],
 "console": [
  null,
  "コンソール"
 ],
 "command": [
  null,
  "コマンド"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "シェル"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
