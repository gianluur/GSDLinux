cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "File di Cockpit"
 ],
 "Home": [
  null,
  "Home"
 ],
 "Unable to create bookmark directory": [
  null,
  "Impossibile creare la cartella dei segnalibri"
 ],
 "Unable to save bookmark file": [
  null,
  "Impossibile salvare il file dei segnalibri"
 ],
 "Remove from bookmarks": [
  null,
  "Rimuovi dai segnalibri"
 ],
 "Add to bookmarks": [
  null,
  "Aggiungi ai segnalibri"
 ],
 "Bookmarks": [
  null,
  "Segnalibri"
 ],
 "Bookmarked": [
  null,
  "Segnalibro aggiunto"
 ],
 "Not bookmarked": [
  null,
  "Segnalibro non aggiunto"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Edit path": [
  null,
  "Modifica percorso"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Largest size": [
  null,
  "Dimensione maggiore"
 ],
 "Smallest size": [
  null,
  "Dimensione minima"
 ],
 "Modified": [
  null,
  "Modificati"
 ],
 "First modified": [
  null,
  "Prima modifica"
 ],
 "Last modified": [
  null,
  "Ultima modifica"
 ],
 "Owner": [
  null,
  "Proprietario"
 ],
 "Owner ascending": [
  null,
  "Proprietario crescente"
 ],
 "Owner descending": [
  null,
  "Proprietario decrescente"
 ],
 "Permissions": [
  null,
  "permessi"
 ],
 "Most permissive": [
  null,
  "Più permissivi"
 ],
 "Least permissive": [
  null,
  "Meno permissivo"
 ],
 "Show keyboard shortcuts": [
  null,
  "Mostra scorciatoie da tastiera"
 ],
 "Filter directory": [
  null,
  "Filtra cartella"
 ],
 "Display as a list": [
  null,
  "Visualizza come elenco"
 ],
 "Display as a grid": [
  null,
  "Visualizza come griglia"
 ],
 "Sort": [
  null,
  "ordina"
 ],
 "Hide hidden items": [
  null,
  "Nascondi elementi nascosti"
 ],
 "Show hidden items": [
  null,
  "Mostra elementi nascosti"
 ],
 "$0 files": [
  null,
  "$0 files"
 ],
 "Uploaded as $0, $1": [
  null,
  "Caricato come $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Sostituire il file $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Un file con lo stesso nome esiste già in \"$0\". Sostituendolo ne sovrascriverai il contenuto."
 ],
 "New file": [
  null,
  "Nuovo file"
 ],
 "Original file on server": [
  null,
  "File originale sul server"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Applica questa azione a tutti i file in conflitto"
 ],
 "Replace": [
  null,
  "Sostituisci"
 ],
 "Keep original": [
  null,
  "Mantieni originale"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Upload error": [
  null,
  "Errore di caricamento"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Impossibile spostare il file caricato nella destinazione finale"
 ],
 "Cancelled": [
  null,
  "Annullato"
 ],
 "Cancelled upload of $0": [
  null,
  "Caricamento di $0 annullato"
 ],
 "File uploaded": [
  null,
  "File caricato"
 ],
 "Files uploaded": [
  null,
  "File caricati"
 ],
 "Change permissions": [
  null,
  "Modifica permessi"
 ],
 "Uploads": [
  null,
  "Caricamento"
 ],
 "Cancel upload of $0": [
  null,
  "Annulla caricamento di $0"
 ],
 "Upload $0% completed": [
  null,
  "Caricamento $0 completato"
 ],
 "Upload": [
  null,
  "Caricare"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Execute-only": [
  null,
  "Sola esecuzione"
 ],
 "Write-only": [
  null,
  "Sola scrittura"
 ],
 "Write and execute": [
  null,
  "Scrittura ed esecuzione"
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Read and execute": [
  null,
  "Lettura ed esecuzione"
 ],
 "Read and write": [
  null,
  "Lettura e scrittura"
 ],
 "Read, write, and execute": [
  null,
  "Lettura, scrittura ed esecuzione"
 ],
 "Block device": [
  null,
  "blocca il dispositivo"
 ],
 "Character device": [
  null,
  "dispositivo a caratteri"
 ],
 "Directory": [
  null,
  "Cartella"
 ],
 "Named pipe": [
  null,
  "pipe nominata"
 ],
 "Symbolic link": [
  null,
  "Link Simbolico"
 ],
 "Regular file": [
  null,
  "file regolare"
 ],
 "Socket": [
  null,
  "Socket"
 ],
 "Name cannot be empty": [
  null,
  "Il nome non può essere vuoto"
 ],
 "Name too long": [
  null,
  "Nome troppo lungo"
 ],
 "Name cannot include a /": [
  null,
  "Il nome non può includere /"
 ],
 "Filename is the same as original name": [
  null,
  "Il nome del file è uguale al nome originale"
 ],
 "Directory with the same name exists": [
  null,
  "Esiste una cartella con lo stesso nome"
 ],
 "File exists": [
  null,
  "Il file esiste già"
 ],
 "Pasting failed": [
  null,
  "Operazione incolla fallita"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "“$0” esiste, non si sovrascrive con l'incolla."
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Create directory": [
  null,
  "Crea directory"
 ],
 "Create file": [
  null,
  "Crea file"
 ],
 "Edit permissions": [
  null,
  "Modifica permessi"
 ],
 "Open in terminal": [
  null,
  "Apri nel terminale"
 ],
 "Open text file": [
  null,
  "Apri file di testo"
 ],
 "Copy": [
  null,
  "copia"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Download": [
  null,
  "Scarica"
 ],
 "Create link": [
  null,
  "Crea link"
 ],
 "Drop files to upload": [
  null,
  "Trascina i file qui per caricarli"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Impossibile rilasciare i file, un altro caricamento è già in corso"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Go up a directory": [
  null,
  "Tornare alla cartella superiore"
 ],
 "Go back": [
  null,
  "Va indietro"
 ],
 "Go forward": [
  null,
  "Avanti"
 ],
 "Activate selected item, enter directory": [
  null,
  "Attiva l'elemento selezionato, entra nella cartella"
 ],
 "Rename selected file or directory": [
  null,
  "Rinomina file o cartella selezionata"
 ],
 "Create new directory": [
  null,
  "Crea una nuova cartella"
 ],
 "Copy selected file or directory": [
  null,
  "Copia i file o directory selezionati"
 ],
 "Paste file or directory": [
  null,
  "Incolla file o cartella"
 ],
 "Select all": [
  null,
  "Seleziona tutto"
 ],
 "Save current file": [
  null,
  "Salva il file attuale"
 ],
 "Close editor": [
  null,
  "Chiudi editor"
 ],
 "Keyboard shortcuts": [
  null,
  "Scorciatoie da tastiera"
 ],
 "Navigation": [
  null,
  "Navigazione"
 ],
 "Editing": [
  null,
  "Modifica"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Forza eliminazione di $0 elementi"
 ],
 "Delete $0 items?": [
  null,
  "Cancella $0 oggetti?"
 ],
 "Force delete file $0?": [
  null,
  "Forzare l'eliminazione del file $0?"
 ],
 "Delete file $0?": [
  null,
  "Cancella file $0?"
 ],
 "Force delete link $0?": [
  null,
  "Forzare l'eliminazione del collegamento $0?"
 ],
 "Delete link $0?": [
  null,
  "Cancella link $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Forzare l'eliminazione della cartella $0?"
 ],
 "Delete directory $0?": [
  null,
  "Eliminare la cartella $0?"
 ],
 "Force delete $0": [
  null,
  "Forza eliminazione di $0"
 ],
 "Delete $0?": [
  null,
  "Eliminare $0?"
 ],
 "No access": [
  null,
  "Nessun accesso"
 ],
 "Missing type": [
  null,
  "Tipo mancante"
 ],
 "Collapse": [
  null,
  "Comprimi"
 ],
 "Show all files": [
  null,
  "Mostra tutti i file"
 ],
 "$0 permissions": [
  null,
  "$0 permessioni"
 ],
 "Permissions for $0 files": [
  null,
  "Permessi per $0 file"
 ],
 "Ownership": [
  null,
  "Proprietà"
 ],
 "Group": [
  null,
  "Gruppo"
 ],
 "Access": [
  null,
  "Accesso"
 ],
 "Owner access": [
  null,
  "Accesso proprietario"
 ],
 "Group access": [
  null,
  "Accesso gruppo"
 ],
 "Others access": [
  null,
  "Accesso altri"
 ],
 "Security context": [
  null,
  "Contesto di sicurezza"
 ],
 "Set executable as program": [
  null,
  "Imposta come eseguibile (programma)"
 ],
 "Change": [
  null,
  "Modifica"
 ],
 "Change permissions for enclosed files": [
  null,
  "Modifica permessi per i file inclusi"
 ],
 "(original owner)": [
  null,
  "(propietario originario)"
 ],
 "keep original owners": [
  null,
  "mantenere i proprietari originali"
 ],
 "Paste as owner": [
  null,
  "Incolla come proprietario"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "I file incollati hanno un proprietario diverso. Per impostazione predefinita, la proprietà verrà modificata per corrispondere alla cartella di destinazione."
 ],
 "New owner": [
  null,
  "Nuovo proprietario"
 ],
 "Overwrite": [
  null,
  "Sovrascrivere"
 ],
 "New filename": [
  null,
  "Nuovo nome file"
 ],
 "New name": [
  null,
  "Nuovo nome"
 ],
 "Rename $0?": [
  null,
  "Rinomina $0?"
 ],
 "link to $0": [
  null,
  "Collega a $0"
 ],
 "Create link to $0": [
  null,
  "Crea link a $0"
 ],
 "Target": [
  null,
  "Target"
 ],
 "Symlink name": [
  null,
  "Nome collegamento simbolico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Absolute vs. Relative": [
  null,
  "Assoluto vs. Relativo"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "I collegamenti simbolici assoluti sono ideali quando ci si riferisce a file o cartelle che non verranno spostati, come i file di sistema."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "I collegamenti simbolici relativi sono utili quando sia un collegamento simbolico che la sua destinazione potrebbero spostarsi contemporaneamente, ad esempio rinominando o spostando una cartella principale."
 ],
 "Absolute": [
  null,
  "Assoluto"
 ],
 "Relative": [
  null,
  "Relativo"
 ],
 "The file has been removed on disk": [
  null,
  "Il file è stato rimosso dal disco"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Il file esistente è cambiato inaspettatamente"
 ],
 "Edit $0": [
  null,
  "Modifica $0"
 ],
 "View $0": [
  null,
  "Visualizza $0"
 ],
 "The file has changed on disk": [
  null,
  "Il file è cambiato sul disco"
 ],
 "Reload": [
  null,
  "Ricarica"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save changes?": [
  null,
  "Salvare le modifiche?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Il file è stato eliminato dopo essere stato aperto; il salvataggio lo ricreerà."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Il file sul disco è stato modificato nel periodo tra l'apertura e il momento attuale"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 ha delle modifiche non salvate che andranno perse definitivamente se scartate."
 ],
 "Discard": [
  null,
  "Scarta"
 ],
 "File name": [
  null,
  "Nome del file"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Cannot create file in current directory": [
  null,
  "Impossibile creare il file nella cartella corrente"
 ],
 "Permission denied": [
  null,
  "Permesso negato"
 ],
 "Directory name cannot be empty": [
  null,
  "Il nome della cartella non può essere vuoto"
 ],
 "Directory name too long": [
  null,
  "Nome della cartella troppo lungo"
 ],
 "Directory name cannot include a /": [
  null,
  "Il nome della cartella non può includere /"
 ],
 "Directory name": [
  null,
  "Nome cartella"
 ],
 "Directory owner": [
  null,
  "Proprietario cartella"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "Clear filter": [
  null,
  "Cancella filtro"
 ],
 "Directory is empty": [
  null,
  "La cartella è vuota"
 ],
 "$0 item is hidden": [
  null,
  "$0 l'elemento è nascosto",
  "$0 gli elementi sono nascosti"
 ],
 "Folder": [
  null,
  "Cartella"
 ],
 "File": [
  null,
  "File"
 ],
 "Others": [
  null,
  "Altri"
 ],
 "$0 files selected": [
  null,
  "$0 file selezionati"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "La cartella contiene $0 cartelle, $1 file"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "La cartella contiene $0 cartelle, $1 file, $2 nascosti"
 ],
 "User": [
  null,
  "Utente"
 ]
});
