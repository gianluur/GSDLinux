cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 помилка",
  "$0 помилки",
  "$0 помилок"
 ],
 "$0 installation": [
  null,
  "Встановлення $0"
 ],
 "$0 installer": [
  null,
  "Засіб встановлення $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 - це розширений розділ MBR, який містить логічні розділи. Вилучення усіх логічних розділів автоматично вилучить і розширений розділ."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "потрібно $0, але маємо лише $1."
 ],
 "$0 warning": [
  null,
  "$0 попередження",
  "$0 попередження",
  "$0 попереджень"
 ],
 "$0 will be deleted": [
  null,
  "$0 буде видалено"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Файлова система '$0' не може бути на зашифрованому блоковому пристрої"
 ],
 "'$0' must be assigned to $1": [
  null,
  "«$0» має бути пов'язано з $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "«$0» має перебувати на пристрої з форматуванням «$1»"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "«$0» має перебувати на системному розділі EFI. На вибраному розділі використано файлову систему FAT, але його не позначено як ESP. Встановіть тип розділу «EFI System» і позначте пункт esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Знайдено розділ «$0» на пристрої MDRAID $1. Підтримки розділів завантажувача на пристроях MDRAID не передбачено."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Стандартний обліковий запис користувача з правами адміністратора для внесення загальносистемних змін."
 ],
 "Abort installation": [
  null,
  "Перервати встановлення"
 ],
 "About": [
  null,
  "Відомості"
 ],
 "Account": [
  null,
  "Обліковий запис"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Add another server...": [
  null,
  "Додати інший сервер…"
 ],
 "Add mount": [
  null,
  "Додати монтування"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Додатки до вибраного вами середовища"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Додатки, які не є прив'язаними до вашого середовища"
 ],
 "Additional languages": [
  null,
  "Додаткові мови"
 ],
 "Additional software for the selected environment": [
  null,
  "Додаткове програмне забезпечення для вибраного середовища"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Всі зміни, внесені в редакторі сховища, вступають в силу негайно."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Усі пристрої із цим паролем буде розблоковано"
 ],
 "Anaconda Web UI": [
  null,
  "Веб-інтерфейс Анаконда"
 ],
 "Anaconda project page": [
  null,
  "Сторінка проєкту Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Застосувати прив'язку точки монтування і встановити"
 ],
 "Applying changes...": [
  null,
  "Застосовуємо зміни…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Прив'язування розділів до точок монтування. Корисно для попередньо сконфігурованих користувацьких макетів."
 ],
 "Automatic log file upload": [
  null,
  "Автоматичне вивантаження файла журналу"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Автоматично встановити дату і час за даними серверів часу"
 ],
 "Automatically set timezone": [
  null,
  "Автоматично встановити часовий пояс"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Доступний вільний простір: $0. Для встановлення необхідно: $1."
 ],
 "Back": [
  null,
  "Назад"
 ],
 "Base environment": [
  null,
  "Базове середовище"
 ],
 "Brief description of the issue": [
  null,
  "Короткий опис проблеми"
 ],
 "Bug report details": [
  null,
  "Подробиці звіту щодо помилки"
 ],
 "Bugzilla API key": [
  null,
  "Ключ до програмного інтерфейсу Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Користуючись надалі цим програмним забезпечення, ви підтверджуєте, що розумієте і приймаєте усі ризики, пов’язані з використанням тестового програмного забезпечення, що ви маєте намір скористатися ним лише з метою тестування або подальшої розробки і що ви маєте намір повідомляти про всі вади і проблеми з метою покращення його роботи."
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change destination": [
  null,
  "Змінити призначення"
 ],
 "Change hostname": [
  null,
  "Змінити назву вузла"
 ],
 "Change partition layout": [
  null,
  "Змінити компонування розділів"
 ],
 "Change system keyboard layout": [
  null,
  "Змінити загальносистемну розкладку клавіатури"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Зміни, внесені тут, негайно вплинуть на систему. Скасувати їх неможливо."
 ],
 "Checking installation configuration...": [
  null,
  "Перевіряємо налаштування для встановлення…"
 ],
 "Checking storage configuration": [
  null,
  "Перевіряємо налаштування носія"
 ],
 "Clear search": [
  null,
  "Спорожнити поле пошуку"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Натисніть «Далі» ще раз, щоб продовжити попри попередження."
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Close storage editor": [
  null,
  "Закрити редактор сховищ даних"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Сховище Cockpit не надало пароль для розблокування зашифрованого пристрою."
 ],
 "Completed": [
  null,
  "Завершено"
 ],
 "Configuration is incomplete": [
  null,
  "Налаштування є неповними"
 ],
 "Configure NTP servers": [
  null,
  "Налаштувати сервери NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Налаштувати нетипові сервери NTP"
 ],
 "Configure network": [
  null,
  "Налаштувати мережу"
 ],
 "Configure storage": [
  null,
  "Налаштувати сховище даних"
 ],
 "Configure storage again": [
  null,
  "Повторне налаштовування сховища даних"
 ],
 "Confirm passphrase": [
  null,
  "Підтвердіть пароль"
 ],
 "Continue": [
  null,
  "Продовжити"
 ],
 "Continue installation": [
  null,
  "Продовжити встановлення"
 ],
 "Continue installation?": [
  null,
  "Продовжити встановлення?"
 ],
 "Continue with installation": [
  null,
  "Продовжити встановлення"
 ],
 "Correct these issues before continuing.": [
  null,
  "Виправте ці проблеми, перш ніж продовжувати."
 ],
 "Create Account": [
  null,
  "Створити обліковий запис"
 ],
 "Create account": [
  null,
  "Створити обліковий запис"
 ],
 "Currently installed: $0": [
  null,
  "Зараз встановлено: $0"
 ],
 "Custom": [
  null,
  "Нетипове"
 ],
 "Date": [
  null,
  "Дата"
 ],
 "Date and time": [
  null,
  "Дата і час"
 ],
 "Delete partition": [
  null,
  "Вилучити розділ"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Вилучення певних розділів може завадити завантаженню $0: $1"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Destination": [
  null,
  "Призначення"
 ],
 "Destination is encrypted": [
  null,
  "Місце призначення зашифровано"
 ],
 "Detailed description of the issue": [
  null,
  "Докладний опис проблеми"
 ],
 "Detected valid storage layout:": [
  null,
  "Виявлене коректне компонування сховищ даних:"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Duplicate device.": [
  null,
  "Дублювання пристрою."
 ],
 "Duplicate mount point.": [
  null,
  "Дублювання точки монтування."
 ],
 "Enable root account": [
  null,
  "Увімкнути обліковий запис root"
 ],
 "Encrypt my data": [
  null,
  "Зашифрувати дані"
 ],
 "Encrypted": [
  null,
  "Зашифровано"
 ],
 "Encryption": [
  null,
  "Шифрування"
 ],
 "Enter PIN": [
  null,
  "Введіть PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Введіть PIN-код для отримання доступу до засобу встановлення"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Для створення звіту щодо вади введіть ваш ключ до програмного інтерфейсу Bugzilla.На наступному кроці ви зможете переглянути і змінити подробиці щодо звіту."
 ],
 "Environment": [
  null,
  "Середовище"
 ],
 "Erase data and install": [
  null,
  "Витерти дані і встановити"
 ],
 "Error details": [
  null,
  "Подробиці щодо помилки"
 ],
 "Exit to live desktop": [
  null,
  "Повернутися до портативної стільниці"
 ],
 "Extended partition": [
  null,
  "Розширений розділ"
 ],
 "Failed to report issue": [
  null,
  "Не вдалося повідомити про ваду"
 ],
 "Failed to save layouts": [
  null,
  "Не вдалося зберегти компонування"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Для Fedora linux потрібно принаймні $0 місця на диску."
 ],
 "Finalization": [
  null,
  "Завершення"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Завершення: налаштовування системи завершено. Потрібно ще трохи часу на завершення встановлення."
 ],
 "Find layout": [
  null,
  "Виявити компонування"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Щоб захистити систему, не користуйтеся обліковим записом root безпосередньо. Замість цього, користуйтеся для керування системою вказаним вище локальним обліковим записом."
 ],
 "Full name": [
  null,
  "Ім’я повністю"
 ],
 "Full name cannot contain colon characters": [
  null,
  "У повному імені не повинно міститися двокрапок"
 ],
 "Helper text": [
  null,
  "Допоміжний текст"
 ],
 "Hide API key": [
  null,
  "Приховати ключ до API"
 ],
 "Hide PIN": [
  null,
  "Приховати PIN"
 ],
 "Hide confirmed password": [
  null,
  "Приховати підтверджений пароль"
 ],
 "Hide passphrase": [
  null,
  "Приховати пароль"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Hostname": [
  null,
  "Назва вузла"
 ],
 "How would you like to install?": [
  null,
  "Яким способом ви хочете виконати встановлення?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Розумію, що з позначених дисків буде витерто усі наявні дані",
  "Розумію, що з позначених дисків буде витерто усі наявні дані",
  "Розумію, що з позначених дисків буде витерто усі наявні дані"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Розумію, що частину з наявних даних буде витерто"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Розумію, що до деяких розділів буде внесено зміни"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Якщо не заповнено, назва вузла буде тимчасовою, такою, яку буде визначено за даними мережі."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Якщо жоден із варіантів вище не є застосовним, скористайтеся редактором сховища даних для створення нетипового розділу, перш ніж продовжувати встановлення."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Якщо ви налаштовуєте розділи, обов'язковими є такі:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Якщо ви не погоджуєтеся із автоматичним вивантаженням файлів журналу, ви можете скористатися $0. Звітування вручну надасть вам змогу переглянути і вибірково долучити файли журналу власноруч."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Якщо ви не впевнені щодо наслідків своїх дій або не хочете ризикувати даними, будь ласка, завершіть роботу цієї програми."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Якщо ваша проблема подібна до однієї з наведених вище вад, ви можете відкрити сторінку вади і додати ваші відомості, замість створення звіту-дубліката."
 ],
 "In progress": [
  null,
  "Виконуємо"
 ],
 "Initializing...": [
  null,
  "Започаткування…"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Installation failed": [
  null,
  "Не вдалося встановити"
 ],
 "Installation method": [
  null,
  "Спосіб встановлення"
 ],
 "Installation of the system failed": [
  null,
  "Не вдалося встановити систему"
 ],
 "Installation of the system failed: $0": [
  null,
  "Не вдалося встановити систему: $0"
 ],
 "Installation type": [
  null,
  "Тип встановлення"
 ],
 "Installing": [
  null,
  "Встановлюємо"
 ],
 "Insufficient disk space": [
  null,
  "Недостатньо місця на диску"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Некоректний PIN. Будь ласка, повторіть спробу."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Виявлено некоректні налаштування RAID. Якщо ваш масив RAID створено безпосередньо на основі дисків, на масиві має бути створено таблицю розділів. Якщо вас масив RAID створено на основі розділів, у ньому має міститися єдина файлова система або формат (наприклад, PV LVM). Усі наявні розділи у цьому масиві буде проігноровано."
 ],
 "Invalid hostname": [
  null,
  "Некоректна назва вузла"
 ],
 "Jump to first incomplete step": [
  null,
  "Перейти до першого незавершеного кроку"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Зберегти поточне компонування дисків і використати доступне вільне місце для подвійного завантаження з іншою ОС."
 ],
 "Keyboard": [
  null,
  "Клавіатура"
 ],
 "Keyboard layout during boot": [
  null,
  "Розкладка клавіатури під час завантаження"
 ],
 "Language": [
  null,
  "Мова"
 ],
 "Launch storage editor": [
  null,
  "Запустити редактор сховищ даних"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Дізнатися більше про обмежений доступ у налаштуваннях"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Не заповнюйте обидва поля паролів, щоб скористатися порожнім паролем."
 ],
 "Location": [
  null,
  "Розташування"
 ],
 "Locked devices": [
  null,
  "Заблоковані пристрої"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Make current": [
  null,
  "Зробити поточним"
 ],
 "Manual disk configuration": [
  null,
  "Налаштування дисків вручну"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Налаштування дисків вручну: прив'язування точок монтування"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Може складатися з літер, цифр та дефісів."
 ],
 "May need more free space": [
  null,
  "Може потребувати більше вільного місця"
 ],
 "Medium": [
  null,
  "Носій"
 ],
 "Minimum of $0 required": [
  null,
  "Потрібно принаймні $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Невідповідність між вибраними параметрами повторного форматування батьківського та дочірнього пристроїв."
 ],
 "Mount point": [
  null,
  "Точка монтування"
 ],
 "Mount point assignment": [
  null,
  "Прив'язка до точки монтування"
 ],
 "Move down": [
  null,
  "Пересунути нижче"
 ],
 "Move up": [
  null,
  "Пересунути вище"
 ],
 "Must be at least $0 characters": [
  null,
  "Має складатися із принаймні $0 символів"
 ],
 "My issue is different, continue": [
  null,
  "У мене інша проблема, продовжити"
 ],
 "NTP Servers": [
  null,
  "Сервери NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Needs at least $0": [
  null,
  "Потребує принаймні $0"
 ],
 "Network": [
  null,
  "Мережа"
 ],
 "Network Configuration": [
  null,
  "Налаштування мережі"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Мережа недоступна. Налаштуйте мережу у меню верхньої панелі, щоб повідомити про проблему."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Мережа недоступна. Налаштуйте мережу, щоб повідомити про проблему."
 ],
 "Network plugin failed": [
  null,
  "Помилка додатка мережі"
 ],
 "Next": [
  null,
  "Далі"
 ],
 "No devices": [
  null,
  "Немає пристроїв"
 ],
 "No disks available": [
  null,
  "Немає доступних дисків"
 ],
 "No disks selected": [
  null,
  "Не позначено жодного диска"
 ],
 "No keyboard layouts selected": [
  null,
  "Не вибрано жодної розкладки"
 ],
 "No layouts selected yet": [
  null,
  "Ще не вибрано жодної розкладки"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Не вдалося отримати коректної прив'язки клавіш VConsole для вибраних розкладок клавіатури. Будь ласка, виберіть інші розкладки."
 ],
 "Not enough available free space": [
  null,
  "Недостатньо доступного вільного місця"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "На позначених дисках недостатньо вільного місця."
 ],
 "Not enough space on selected disks.": [
  null,
  "На позначених дисках недостатньо місця."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Зауваження: це тестове програмне забезпечення, яке призначено лише для розробників і тестувальників. НЕ використовуйте це програмне забезпечення для виконання критично важливих завдань або у промислових середовищах."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Відкрити форму введення звіту щодо вади у Bugzilla"
 ],
 "Operating system": [
  null,
  "Операційна система"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other keyboards": [
  null,
  "Інші клавіатури"
 ],
 "Partitions (advanced)": [
  null,
  "Розділи (додатково)"
 ],
 "Passphrase": [
  null,
  "Пароль"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Пароль не є відповідним до жодного заблокованого пристрою"
 ],
 "Passphrases must match": [
  null,
  "Паролі мають збігатися"
 ],
 "Pending": [
  null,
  "У черзі"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Будь ласка, додайте до повідомлення про ваду файл журналу $0."
 ],
 "Please enter a PIN": [
  null,
  "Будь ласка, введіть PIN-код"
 ],
 "Please select at least one disk to continue": [
  null,
  "Будь ласка, позначте принаймні один диск, щоб продовжити"
 ],
 "Pool": [
  null,
  "Набір"
 ],
 "Potential duplicate bugs found": [
  null,
  "Виявлено потенційні дублікати звіту щодо вади"
 ],
 "Powered by Anaconda": [
  null,
  "На основі Anaconda"
 ],
 "Pre-release": [
  null,
  "Тестовий випуск"
 ],
 "Prefer to report manually? $0": [
  null,
  "Хочете створити звіт вручну? $0"
 ],
 "Proceed with installation": [
  null,
  "Продовжити встановлення"
 ],
 "Quit": [
  null,
  "Вийти"
 ],
 "Quit installer?": [
  null,
  "Вийти зі встановлювача?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Не вдалося прочитати відомості щодо операційної системи."
 ],
 "Reading information about the computer failed.": [
  null,
  "Не вдалося прочитати відомості щодо комп'ютера."
 ],
 "Reading installer configuration failed.": [
  null,
  "Не вдалося прочитати налаштування встановлювача."
 ],
 "Reading installer version information failed.": [
  null,
  "Не вдалося прочитати дані щодо версії встановлювача."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Справжня назва вузла може складатися лише з літер, цифр дефісів (не на початку і не у кінці) та крапок"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Справжня назва вузла має складатися не більше, ніж з 64 символів"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Перезавантажтеся у Windows, щоб змінити розмір зашифрованих BitLocker розділів. Звільніть принаймні $0 для встановлення."
 ],
 "Reboot system?": [
  null,
  "Перезавантажити систему?"
 ],
 "Reclaim additional space": [
  null,
  "Звільнити додаткове місце"
 ],
 "Reclaim space": [
  null,
  "Звільнити місце"
 ],
 "Reclaim space (required)": [
  null,
  "Звільнити місце (обов'язково)"
 ],
 "Recommended": [
  null,
  "Рекомендовано"
 ],
 "Recommended partitions:": [
  null,
  "Рекомендовані розділи:"
 ],
 "Reformat": [
  null,
  "Повторно форматувати"
 ],
 "Reinstall Fedora": [
  null,
  "Перевстановити Fedora"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Вилучити усі розділи на позначених пристроях, включно із наявними операційними системами."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Вилучіть наявні файлові системи або змініть їхні розміри, щоб звільнити місце для встановлення."
 ],
 "Remove server": [
  null,
  "Вилучити сервер"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Вилучення файлової системи призведе до остаточного знищення усіх даних, що на ній містяться. Зміна розмірів розділу може вивільнити місце, але вона не є абсолютно безпечною. Переконайтеся, що створено резервні копії усіх важливих даних до вивільнення місця."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Замінити поточне встановлення, але зберегти файли у домашній теці."
 ],
 "Report Issue": [
  null,
  "Повідомити про ваду"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Повідомте про ваду або надайте відгук шляхом заповнення форми щодо вади у Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Повідомити про ваду"
 ],
 "Reporting issue...": [
  null,
  "Звітування щодо вади…"
 ],
 "Required": [
  null,
  "Обов'язковий"
 ],
 "Requirements": [
  null,
  "Вимоги"
 ],
 "Rescan devices": [
  null,
  "Виконати повторний пошук пристроїв"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Повторне сканування дисків зазнало невдачі."
 ],
 "Resize": [
  null,
  "Змінити розмір"
 ],
 "Resize partition": [
  null,
  "Змінити розмір розділу"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Змінюємо розмір таких розділів на $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Обмежити доступ до звіту"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Обмежити звіт до групи $0. $1"
 ],
 "Return to installation": [
  null,
  "Повернутися до встановлення"
 ],
 "Return to storage editor": [
  null,
  "Повернутися до редактора сховищ даних"
 ],
 "Review and install": [
  null,
  "Переглянути і встановити"
 ],
 "Root account has been configured": [
  null,
  "Налаштовано обліковий запис root"
 ],
 "Root account is enabled": [
  null,
  "Обліковий запис root увімкнено"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Увімкнено обліковий запис root, але не налаштовано жодного облікового запису користувача"
 ],
 "Root password has been set.": [
  null,
  "Встановлено пароль root."
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Виконайте сканування QR-коду за допомогою вашого телефону або відвідайте цю сторінку:"
 ],
 "Search for a language": [
  null,
  "Шукати мову"
 ],
 "Search for additional software": [
  null,
  "Шукати додаткове програмне забезпечення"
 ],
 "Search for an environment": [
  null,
  "Шукати середовище"
 ],
 "Search keyboard layout": [
  null,
  "Шукати розкладку клавіатури"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Захистіть ваші дані за допомогою шифрування дисків. Можна застосувати лише до нових розділів"
 ],
 "Select": [
  null,
  "Позначити"
 ],
 "Select a device": [
  null,
  "Виберіть пристрій"
 ],
 "Select city": [
  null,
  "Виберіть місто"
 ],
 "Select destination": [
  null,
  "Виберіть призначення"
 ],
 "Select region": [
  null,
  "Виберіть регіон"
 ],
 "Selected (top = current)": [
  null,
  "Вибрані (верхня = поточна)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Повторне форматування для вибраного формату пристрою «$0» неможливе."
 ],
 "Send us feedback on your installation": [
  null,
  "Надішліть нам відгук щодо встановленої системи"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server is not reachable": [
  null,
  "Не вдалося отримати доступ до сервера"
 ],
 "Set custom hostname": [
  null,
  "Встановити нетипову назву вузла"
 ],
 "Share disk with other operating systems": [
  null,
  "Надати диск у спільне використання для інших операційних систем"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Надати диск у спільне використання для інших операційних систем: $0"
 ],
 "Show AM/PM": [
  null,
  "Показувати _ДО/ПО"
 ],
 "Show API key": [
  null,
  "Показати ключ до API"
 ],
 "Show PIN": [
  null,
  "Показати PIN"
 ],
 "Show confirmed password": [
  null,
  "Показати підтверджений пароль"
 ],
 "Show passphrase": [
  null,
  "Показати пароль"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Software installation": [
  null,
  "Встановлення програмного забезпечення"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Встановлення програмного забезпечення: завершено налаштовування сховища даних. Тепер встановлюємо програмне забезпечення на ваш пристрій."
 ],
 "Software selection": [
  null,
  "Вибір програмного забезпечення"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Перш ніж можна буде продовжувати, слід завершити деякі кроки встановлення."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Не вистачає декількох обов'язкових розділів: $0"
 ],
 "Space": [
  null,
  "Місце"
 ],
 "Stacktrace": [
  null,
  "Трасування стеку"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Storage configuration": [
  null,
  "Налаштування сховища даних"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Налаштовування сховища даних: зараз виконуємо налаштовування сховища даних."
 ],
 "Storage editor": [
  null,
  "Редактор сховищ даних"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Сховище даних на основі налаштувань зі сторінки «Змінити сховище даних»."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Компонування сховища даних визначається файлом kickstart. Із запланованим компонуванням розділів можна буде ознайомитися на підсумковому кроці."
 ],
 "Storage plugin failed": [
  null,
  "Помилка додатка сховища даних"
 ],
 "Storage requirements not met": [
  null,
  "Вимоги до сховища даних не виконано"
 ],
 "Strong": [
  null,
  "Складний"
 ],
 "Successfully installed": [
  null,
  "Успішно встановлено"
 ],
 "Successfully unlocked $0.": [
  null,
  "Успішно розблоковано $0."
 ],
 "Suggested keyboards": [
  null,
  "Пропоновані клавіатури"
 ],
 "Suggested languages": [
  null,
  "Пропоновані мови"
 ],
 "System": [
  null,
  "Система"
 ],
 "System configuration": [
  null,
  "Налаштування системи"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Налаштовування системи: встановлення програмного забезпечення завершено. Тепер виконуємо налаштовування системи."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Встановлення Anaconda було припинено у неочікуваний спосіб."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "З вашою проблемою можуть бути пов'язані вказані відкриті звіти щодо вад. Будь ласка, ознайомтеся з ними, перш ніж створювати власний звіт."
 ],
 "The following user will be created:": [
  null,
  "Буде створено такі записи користувачів:",
  "Буде створено такі записи користувачів:",
  "Буде створено такі записи користувачів:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Для встановлення потрібно $0 місця на дисках; втім, місткість вибраних дисків складає лише $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Продовження встановлення неможливе через критичну помилку."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Продовження встановлення неможливе через критичну помилку: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Вказаний вами пароль містить символи, які не є символами ASCII. У вас може не бути можливості перемкнути розкладку клавіатури під час його введення."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "У вибраній типовій розкладці клавіатури не передбачено підтримки символів ASCII. Будь ласка, виберіть як типову розкладку з можливістю введення символів ASCII."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "За допомогою редактора сховищ даних ви можете змінювати розміри розділів, вилучати і створювати їх. Редактор може визначати LVM тощо. Ним слід користуватися як інструментом для досвідчених користувачів, його не призначено для використання під час стандартного встановлення."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Ці файли журналу можуть містити конфіденційні дані, зокрема IP-адреси, назви облікових записів користувачів та інші подробиці щодо системи."
 ],
 "This hostname can't be submitted": [
  null,
  "Цю назву вузла не може бути надіслано"
 ],
 "This is unstable, pre-release software": [
  null,
  "Це нестабільне програмне забезпечення недостатньої якості"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Цю розкладку буде використано для розблокування системи під час завантаження"
 ],
 "This may take a moment": [
  null,
  "Зачекайте, будь ласка"
 ],
 "This will take a few moments": [
  null,
  "Зачекайте, будь ласка"
 ],
 "Time": [
  null,
  "Час"
 ],
 "Timezone": [
  null,
  "Часовий пояс"
 ],
 "Title": [
  null,
  "Заголовок"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Щоб розпочати користування $0, перезавантажте вашу систему."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Щоб продовжити, виберіть пристрої для встановлення на них системи."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Щоб скористатися цим варіантом, змініть розміри розділів або вилучіть наявні розділи, щоб звільнити принаймні $0."
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Не вдалося запланувати вилучення $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Не вдалося запланувати зміну розмірів $0"
 ],
 "Undo last action": [
  null,
  "Скасувати останню дію"
 ],
 "Unlock": [
  null,
  "Розблокувати"
 ],
 "Unlock encrypted devices": [
  null,
  "Розблокувати зашифровані пристрої"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Розблокуйте зашифровані розділи, щоб зберегти наявні дані і переглянути більше способів встановлення."
 ],
 "Use configured storage": [
  null,
  "Скористатися налаштованим сховищем даних"
 ],
 "Use entire disk": [
  null,
  "Використати увесь диск"
 ],
 "Use free space": [
  null,
  "Використати вільне місце"
 ],
 "Use local account": [
  null,
  "Використовувати локальний обліковий запис"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Використати пристрій RAID для автоматичного поділу на розділи"
 ],
 "User creation": [
  null,
  "Створення запису користувача"
 ],
 "User name": [
  null,
  "Ім’я користувача"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Ім'я користувача може складатися лише з таких символів: літер a-z, цифр 0-9, дефісів $0, крапок $1, символів підкреслення $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Ім’я користувача не може бути зарезервованим словом"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Довжина імені користувача не повинна перевищувати 32 символи"
 ],
 "Validating...": [
  null,
  "Перевірка чинності…"
 ],
 "Weak": [
  null,
  "Простий"
 ],
 "Welcome": [
  null,
  "Вітаємо"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Вітаємо у Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Вітаємо. Давайте встановлювати $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "При надсиланні цього звіту щодо вади буде автоматично вивантажено такі файли журналу: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Розміри розділів Windows з шифруванням BitLocker не можна змінювати"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Тут ви можете або звільнити достатньо місця і надати засобу встановлення можливість автоматично визначити параметри або налаштувати параметри розділів вручну."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Ви можете створити ключ до програмного інтерфейсу для вашого облікового запису Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Щоб продовжувати, вам слід увімкнути обліковий запис root або створити локальний обліковий запис користувача."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Для вмикання автоматичного встановлення дати і часу комп'ютер має встановити з'єднання з мережею."
 ],
 "Your progress will not be saved.": [
  null,
  "Поступ не буде збережено."
 ],
 "completed step": [
  null,
  "завершений крок"
 ],
 "current step": [
  null,
  "поточний крок"
 ],
 "delete": [
  null,
  "вилучити"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "encrypt": [
  null,
  "зашифрувати"
 ],
 "encrypted": [
  null,
  "зашифрований"
 ],
 "extended partition": [
  null,
  "розширений розділ"
 ],
 "format as $0": [
  null,
  "форматувати як $0"
 ],
 "here": [
  null,
  "тут"
 ],
 "incomplete": [
  null,
  "Не завершено"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "pending step": [
  null,
  "крок у черзі"
 ],
 "report the issue manually": [
  null,
  "створити звіт щодо вади вручну"
 ],
 "resized from $0": [
  null,
  "змінено розмір з $0"
 ],
 "shrink": [
  null,
  "стиснути"
 ],
 "shrink to $0": [
  null,
  "стиснути до $0"
 ],
 "transient, will use DHCP": [
  null,
  "проміжна, буде використано DHCP"
 ],
 "undo": [
  null,
  "скасувати"
 ]
});
