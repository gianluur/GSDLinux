cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "bn",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
