cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "et",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 viga",
  "$0 viga"
 ],
 "$0 installation": [
  null,
  "Paigaldus: $0"
 ],
 "$0 installer": [
  null,
  "Paigaldaja: $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "„$0“ on MBR-tüüpi laiendatud partitsioon, mis sisaldab loogilisi partitsioone. Kõikide loogiliste partitsioonidega eemaldad ka laiendatud partitsiooni(d)."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Nõutav on $0, kuid vaid $1 on saadaval."
 ],
 "$0 warning": [
  null,
  "$0 hoiatus",
  "$0 hoiatust"
 ],
 "$0 will be deleted": [
  null,
  "$0 kustutatakse"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "„$0“ failisüsteem ei saa asuda krüptitud blokkseadmes"
 ],
 "'$0' must be assigned to $1": [
  null,
  "„$0“ peab olema määratud „$1“ seadmele"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "„$0“ peab asuma „$1“ vorminduses seadmel"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "„$0“ peab asuma EFI süsteemipartitsioonil. Valitud partitsioon küll kasutab FAT-vormingus failisüsteemi, kui pole ESP-tunnusega märgitud. Seadista partitsioon EFI süsteemipartitsiooniks ja lülita sisse ESP-tunnus."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Leidus MDRAID-i seadmel „$1“ asuv „$0“ partitsioon. MDRAID-i seadmetel asuvad alglaaduri partitsioonid pole toetatud."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Tavaline kasutajakonto, millel on peakasutaja õigused ja mis võimaldab teha süsteemiüleseid muudatusi."
 ],
 "Abort installation": [
  null,
  "Katkesta paigaldus"
 ],
 "About": [
  null,
  "Teave"
 ],
 "Account": [
  null,
  "Kasutajakonto"
 ],
 "Actions": [
  null,
  "Tegevused"
 ],
 "Add another server...": [
  null,
  "Lisa veel üks server..."
 ],
 "Add mount": [
  null,
  "Lisa haakepunkt"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Lisad sinu valitud keskonna jaoks"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Lisad, mis pole sinu valitud keskonna kohased"
 ],
 "Additional languages": [
  null,
  "Täiendavad keeled"
 ],
 "Additional software for the selected environment": [
  null,
  "Täiendav tarkvara valitud keskkonna jaoks"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Kõik andmeruumi halduris tehtud muudatused jõustuvad kohe."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Kõikide seda salasõna kasutavata seadmete lukustus avatakse"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda veebipõhine kasutajaliides"
 ],
 "Anaconda project page": [
  null,
  "Anaconda projekti veebileht"
 ],
 "Apply mount point assignment and install": [
  null,
  "Rakenda haakepunktide määramine ja paigalda"
 ],
 "Applying changes...": [
  null,
  "Rakendan muudatusi…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Seo partitsioonid haakepunktidega. On mõttekas näiteks omaloodud andmeruumijaotuse eelseadistamisel."
 ],
 "Automatic log file upload": [
  null,
  "Logifailide automaatne üleslaadimine"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Kasutades ajaservereid määra kuupäev ja kellaaeg automaatelt"
 ],
 "Automatically set timezone": [
  null,
  "Seadista ajavöönd automaatselt"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Vaba andmeruumi saadaval: $0. Paigaldus vajab: $1."
 ],
 "Back": [
  null,
  "Tagasi"
 ],
 "Base environment": [
  null,
  "Aluskeskkond"
 ],
 "Brief description of the issue": [
  null,
  "Vea või probleemi lühikirjeldus"
 ],
 "Bug report details": [
  null,
  "Veateate üksikasjad"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API võti"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Jätkates selle tarkvara kasutamist sa mõistad riske mis seostuvad tarkvara eelversioonidega ja nõustud nendega. Lisaks kasutad seda tarkvara vaid testimiseks ja arenduseks ning toote edaspidise parandamise nimel oled nõus arendajatele teada andma leitud vigadest ja probleemidest."
 ],
 "Cancel": [
  null,
  "Katkesta"
 ],
 "Change": [
  null,
  "Muuda"
 ],
 "Change destination": [
  null,
  "Muuda sihtandmekandjat"
 ],
 "Change hostname": [
  null,
  "Muuda hostinime"
 ],
 "Change partition layout": [
  null,
  "Muuda partitsioonide jaotust"
 ],
 "Change system keyboard layout": [
  null,
  "Muuda süsteemi klahvistiku paigutust"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Siinkohal tehtud muudatused mõjutavad süsteemi koheselt ja pole mitte mingit võimalust seda tagasi pöörata."
 ],
 "Checking installation configuration...": [
  null,
  "Kontrollin paigalduse seadistust..."
 ],
 "Checking storage configuration": [
  null,
  "Kontrollin andmeruumi seadistust"
 ],
 "Clear search": [
  null,
  "Tühjenda otsing"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Kui tahad jätkata neile hoiatustele vaatamata, siis klõpsa uuesti nuppu „Edasi“."
 ],
 "Close": [
  null,
  "Sulge"
 ],
 "Close storage editor": [
  null,
  "Sulge andmeruumi muutja"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit andmeruumis ei leidu salasõna, millega krüptitud seadet saaks avada."
 ],
 "Completed": [
  null,
  "Valmis"
 ],
 "Configuration is incomplete": [
  null,
  "Seadistus on poolik"
 ],
 "Configure NTP servers": [
  null,
  "Seadista NTP-servereid"
 ],
 "Configure custom NTP servers": [
  null,
  "Seadista enda eelistatud NTP-servereid"
 ],
 "Configure network": [
  null,
  "Seadista võrku"
 ],
 "Configure storage": [
  null,
  "Seadista andmeruumi"
 ],
 "Configure storage again": [
  null,
  "Seadista uuesti andmeruumi"
 ],
 "Confirm passphrase": [
  null,
  "Korda salasõna"
 ],
 "Continue": [
  null,
  "Jätka"
 ],
 "Continue installation": [
  null,
  "Jätka paigaldamisega"
 ],
 "Continue installation?": [
  null,
  "Kas jätkad paigaldamisega?"
 ],
 "Continue with installation": [
  null,
  "Jätka paigaldamisega"
 ],
 "Correct these issues before continuing.": [
  null,
  "Palun paranda need vead enne jätkamist."
 ],
 "Create Account": [
  null,
  "Lisa kasutajakonto"
 ],
 "Create account": [
  null,
  "Lisa kasutajakonto"
 ],
 "Currently installed: $0": [
  null,
  "Hetkel paigaldatud: $0"
 ],
 "Custom": [
  null,
  "Kohandatud"
 ],
 "Date": [
  null,
  "Kuupäev"
 ],
 "Date and time": [
  null,
  "Kuupäev ja kellaaeg"
 ],
 "Delete partition": [
  null,
  "Kustuta partitsioon"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Mõnede partitsioonide kustutamine takistaks $0 käivitumist: $1"
 ],
 "Description": [
  null,
  "Kirjeldus"
 ],
 "Destination": [
  null,
  "Sihtkoht"
 ],
 "Destination is encrypted": [
  null,
  "Sihtobjekt on krüptitud"
 ],
 "Detailed description of the issue": [
  null,
  "Vea või probleemi üksikasjalik kirjeldus"
 ],
 "Detected valid storage layout:": [
  null,
  "Tuvastasin korrektse andmeruumi jaotuse:"
 ],
 "Device": [
  null,
  "Seade"
 ],
 "Duplicate device.": [
  null,
  "Klooni seade."
 ],
 "Duplicate mount point.": [
  null,
  "Klooni haakepunkt."
 ],
 "Enable root account": [
  null,
  "Võta juurkasutaja konto kasutusele"
 ],
 "Encrypt my data": [
  null,
  "Krüpti minu andmed"
 ],
 "Encrypted": [
  null,
  "Krüptitud"
 ],
 "Encryption": [
  null,
  "Krüptimine"
 ],
 "Enter PIN": [
  null,
  "Sisesta PIN-kood"
 ],
 "Enter PIN to access the installer": [
  null,
  "Ligipääsuks paigaldusrakendusele sisesta PIN-kood"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Veateate koostamiseks sisesta oma Bugzilla API võti. Järgmises sammus saad vaadata üle ja muuta veateate andmeid."
 ],
 "Environment": [
  null,
  "Keskkond"
 ],
 "Erase data and install": [
  null,
  "Kustuta andmed ja paigalda"
 ],
 "Error details": [
  null,
  "Vea üksikasjad"
 ],
 "Exit to live desktop": [
  null,
  "Sulge paigaldaja ja ava taustal toimiv ajutine töölaud"
 ],
 "Extended partition": [
  null,
  "Laiendatud partitsioon"
 ],
 "Failed to report issue": [
  null,
  "Veast või probleemist teatamine ei õnnestunud"
 ],
 "Failed to save layouts": [
  null,
  "Klahvistiku paigutuste salvestamine ei õnnestunud"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux vajab vähemalt $0 andmeruumi."
 ],
 "Finalization": [
  null,
  "Viimistlen ja lõpetan"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Viimistlen ja lõpetan: süsteemi seadistamine on lõppenud. Viimasteks sammudeks kulub veel mõni hetk."
 ],
 "Find layout": [
  null,
  "Otsi klahvistiku paigutust"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Parema turvalisuse nimel väldi juurkasutaja konto kasutamist otse. Selle asemel kasuta süsteemi haldamiseks ülaltoodud kasutajakontot."
 ],
 "Full name": [
  null,
  "Täisnimi"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Täisnimes ei tohi olla koolonit"
 ],
 "Helper text": [
  null,
  "Abitekst"
 ],
 "Hide API key": [
  null,
  "Peida APi võti"
 ],
 "Hide PIN": [
  null,
  "Peida PIN-kood"
 ],
 "Hide confirmed password": [
  null,
  "Peida kinnitatud salasõna"
 ],
 "Hide passphrase": [
  null,
  "Peida salasõna"
 ],
 "Hide password": [
  null,
  "Peida salasõna"
 ],
 "Hostname": [
  null,
  "Hostinimi"
 ],
 "How would you like to install?": [
  null,
  "Kuidas sa sooviksid paigaldada?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Ma saan aru, et kõik olemasolevad andmed kustutatakse",
  "Ma saan aru, et kõik olemasolevad andmed kustutatakse valitud ketastelt"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Ma saan aru, et mõned olemasolevad andmed kustutatakse"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Ma saan aru, et mõned partitsioonid kuuluvad muutmisele"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Kui väärtus jääb tühjaks, siis hostinimi luuakse ajutisena võrguteabe alusel."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Kui ükski eespool nimetatud valik ei sobi, kasuta enne jätkamist andmeruumi haldurit ja loo partitsioonid vastavalt oma vajadustele."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Kui sa seadistad partitsioone, siis järgnev on nõutav:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Kui sa ei nõustu logide automaatse üleslaadimisega, siis selle asemel võid $0. Käsitsi lisamine võimaldab sul neid ise üle vaadata ja lisada valikuluselt."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Kui sa ei mõista riske või ei nõustu nendega, siis palun välju sellest programmist."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Kui sinu probleem vastab ühele eespool nimetatud vigadest, võid ta avada ja lisada sinna oma teabe, selle asemel et koostada topeltveateadet."
 ],
 "In progress": [
  null,
  "Töös"
 ],
 "Initializing...": [
  null,
  "Valmendan..."
 ],
 "Install": [
  null,
  "Paigalda"
 ],
 "Installation completed": [
  null,
  "Paigaldamine on lõppenud"
 ],
 "Installation failed": [
  null,
  "Paigaldamine ei õnnestunud"
 ],
 "Installation method": [
  null,
  "Paigaldusmeetod"
 ],
 "Installation of the system failed": [
  null,
  "Süsteemi paigaldamine ei õnnestunud"
 ],
 "Installation of the system failed: $0": [
  null,
  "Süsteemi paigaldamine ei õnnestunud: $0"
 ],
 "Installation type": [
  null,
  "Paigalduse tüüp"
 ],
 "Installing": [
  null,
  "Paigaldan"
 ],
 "Insufficient disk space": [
  null,
  "Pole piisavalt kettaruumi"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Vigane PIN-kood. Palun proovi uuesti."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Tuvastasin vigase RAID-i seadistuse. Kui sinu RAID-i massiiv on loodud otse ketaste peale, siis peab ka partitsioonitabel olemad loodud otse massiivi peale. Kui sinu RAID-i massiiv on loodud partitsioonide peale, siis ta peab moodustama ühe failisüsteemi või vorminduse (nt. LVM PV ehk loogilise käitehalduri füüsilise köite). Kõik olemasolevaid partitsioone selles massiivis eiratakse."
 ],
 "Invalid hostname": [
  null,
  "Vigane hostinimi"
 ],
 "Jump to first incomplete step": [
  null,
  "Mine esimese pooliku sammu juurde"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Säilita senine ketaste paigutus ja kasuta vaid saadavalolevat andmeruumi ning sellega lood süsteemi, kus saab mitut operatsioonisüsteemi alglaadida."
 ],
 "Keyboard": [
  null,
  "Klahvistik"
 ],
 "Keyboard layout during boot": [
  null,
  "Klahvistiku paigutus alglaadimise ajal"
 ],
 "Language": [
  null,
  "Keel"
 ],
 "Launch storage editor": [
  null,
  "Käivita andmeruumi haldaja"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Uuri lisateavet seadistuste piiratud ligipääsu kohta"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Tühja salasõna kasutamiseks jäta mõlemad salasõna väljad tühjaks."
 ],
 "Location": [
  null,
  "Asukoht"
 ],
 "Locked devices": [
  null,
  "Lukustatud seadmed"
 ],
 "Log in": [
  null,
  "Logi sisse"
 ],
 "Make current": [
  null,
  "Muuda praeguseks"
 ],
 "Manual disk configuration": [
  null,
  "Ketta käsitsi seadistamine"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Ketta käsitsi seadistamine: haakepunktide vastendamine"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Võib sisaldada tähti, numbreid ja kriipse."
 ],
 "May need more free space": [
  null,
  "Võib vajada suuremat vaba andmeruumi"
 ],
 "Medium": [
  null,
  "Keskmine"
 ],
 "Minimum of $0 required": [
  null,
  "Vajalik on vähemalt $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Ülemseadme ja alamseadme ümbervorminduse valik ei ole vastavuses."
 ],
 "Mount point": [
  null,
  "Haakepunkt"
 ],
 "Mount point assignment": [
  null,
  "Määra haakepunkt"
 ],
 "Move down": [
  null,
  "Liiguta allapoole"
 ],
 "Move up": [
  null,
  "Liiguta ülespoole"
 ],
 "Must be at least $0 characters": [
  null,
  "Salasõna peab olema vähemalt $0 märki pikk"
 ],
 "My issue is different, continue": [
  null,
  "Minu probleem on teistsugune, jätka"
 ],
 "NTP Servers": [
  null,
  "NTP-serverid"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Needs at least $0": [
  null,
  "Vajalik on vähemalt $0"
 ],
 "Network": [
  null,
  "Võrk"
 ],
 "Network Configuration": [
  null,
  "Võrguseadistus"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Võrguühendust pole. Veast teatamiseks palun seadista või lisa ülemisest ribamenüüst võrguühendus."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Võrguühendust pole. Veast teatamiseks palun seadista või lisa võrguühendus."
 ],
 "Network plugin failed": [
  null,
  "Võrgu lisamooduli töö ebaõnnestus"
 ],
 "Next": [
  null,
  "Edasi"
 ],
 "No devices": [
  null,
  "Seadmeid pole"
 ],
 "No disks available": [
  null,
  "Kettaid pole saadaval"
 ],
 "No disks selected": [
  null,
  "Ühtegi ketast pole valitud"
 ],
 "No keyboard layouts selected": [
  null,
  "Ühtegi klahvistiku paigutust pole valitud"
 ],
 "No layouts selected yet": [
  null,
  "Ühtegi klahvistiku paigutust pole veel valitud"
 ],
 "No results found": [
  null,
  "Tulemusi ei leidu"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Valitud klahvistikupaigutus(t)e jaoks ei ole võimalik laadida korrektset VConsole'i klahvistikukaarti. Palun vali mõni muu klahvistikupaigutus."
 ],
 "Not enough available free space": [
  null,
  "Pole piisavalt vaba andmeruumi"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Valitud ketastel pole piisavalt vaba ruumi."
 ],
 "Not enough space on selected disks.": [
  null,
  "Valitud ketastel pole piisavalt ruumi."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Märkus: see on tarkvara eelversioon, mis on mõeldud vaid arenduseks ja testimiseks. Palun ÄRA KASUTA seda tarkvara ei kriitiliseks tööks, ega reaalseteks implementatsioonideks."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Ava Bugzilla veakirjelduse sisestusvorm"
 ],
 "Operating system": [
  null,
  "Operatsioonisüsteem"
 ],
 "Options": [
  null,
  "Valikud"
 ],
 "Other keyboards": [
  null,
  "Muud klahvistikud"
 ],
 "Partitions (advanced)": [
  null,
  "Partitsioonid (detailsem seadistus)"
 ],
 "Passphrase": [
  null,
  "Salasõna"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Sellele salasõnale ei vasta mitte ükski lukustatud seade"
 ],
 "Passphrases must match": [
  null,
  "Salasõnad peavad klappima"
 ],
 "Pending": [
  null,
  "Ootel"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Palun lisa veateatele $0 logifail."
 ],
 "Please enter a PIN": [
  null,
  "Palun sisesta PIN-kood"
 ],
 "Please select at least one disk to continue": [
  null,
  "Jätkamiseks palun vali vähemalt üks ketas"
 ],
 "Pool": [
  null,
  "Kogum"
 ],
 "Potential duplicate bugs found": [
  null,
  "Leidusid võimalikud topeltveateated"
 ],
 "Powered by Anaconda": [
  null,
  "Taustal töötab Anaconda"
 ],
 "Pre-release": [
  null,
  "Eelversioon"
 ],
 "Prefer to report manually? $0": [
  null,
  "Kas eelistad edastada selle käsitsi? $0"
 ],
 "Proceed with installation": [
  null,
  "Jätka paigaldamisega"
 ],
 "Quit": [
  null,
  "Välju"
 ],
 "Quit installer?": [
  null,
  "Kas väljud paigaldajast?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Operatsioonisüsteemi teabe lugemine ei õnnestunud."
 ],
 "Reading information about the computer failed.": [
  null,
  "Arvutikohase teabe lugemine ei õnnestunud."
 ],
 "Reading installer configuration failed.": [
  null,
  "Paigaldaja seadistuste lugemine ei õnnestunud."
 ],
 "Reading installer version information failed.": [
  null,
  "Paigaldaja versiooniteabe lugemine ei õnnestunud."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Tegelikus hostinimes võib olla tähemärke, numbreid, kriipse (aga mitte alguses ja lõpus) ja punkte"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Tegelik hostinimi võib olla kuni 64 tähemärki pikk"
 ],
 "Reboot": [
  null,
  "Taaskäivita"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Alglaadimisel vali Windows ja muuda seal BitLockeriga krüptitud partitsiooni suurust. Tekita paigalduse jaoks vähemalt $0 vaba andmeruumi."
 ],
 "Reboot system?": [
  null,
  "Kas taaskäivitad süsteemi?"
 ],
 "Reclaim additional space": [
  null,
  "Vabasta täiendavat andmeruumi"
 ],
 "Reclaim space": [
  null,
  "Vabasta andmeruumi"
 ],
 "Reclaim space (required)": [
  null,
  "Vabasta andmeruumi (see on nõutav)"
 ],
 "Recommended": [
  null,
  "Soovitatav"
 ],
 "Recommended partitions:": [
  null,
  "Soovituslikud partitsioonid:"
 ],
 "Reformat": [
  null,
  "Vorminda uuesti"
 ],
 "Reinstall Fedora": [
  null,
  "Paigalda Fedora uuesti"
 ],
 "Remove": [
  null,
  "Eemalda"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Eemalda valitud seadmetelt kõik partitsioonid, sealhulgas neil paiknevad operatsioonisüsteemid."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Tegemaks paigalduse jaoks ruumi muuda olemasolevate failisüsteemide suurust või eemalda nad."
 ],
 "Remove server": [
  null,
  "Eemalda server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Failisüsteemi eemaldamisel kustutatakse jäädavalt ka kõik seal sisalduvad andmed. Partitsiooni suuruse muutmisega saad kasutamata ruumi vabastada, kuid ka see pole riskivaba. Vastaval juhul palun kontrolli, et sul on kõigest oluliselt olemas varukoopia."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Asenda senine paigaldus, kuid jäta kodukausta failid alles."
 ],
 "Report Issue": [
  null,
  "Teata veast või probleemist"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Teata veast või lisa tagasiside avades Bugzilla sisestusvorm $0."
 ],
 "Report issue": [
  null,
  "Teata veast või probleemist"
 ],
 "Reporting issue...": [
  null,
  "Teatan veast või probleemist…"
 ],
 "Required": [
  null,
  "Vajalik"
 ],
 "Requirements": [
  null,
  "Nõuded"
 ],
 "Rescan devices": [
  null,
  "Skaneeri uuesti seadmeid"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Ketaste kordusskaneerimine ei õnnestunud."
 ],
 "Resize": [
  null,
  "Muuda suurust"
 ],
 "Resize partition": [
  null,
  "Muuda partitsiooni suutust"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Muudan järgnevate partitsioonide suurust „$0“ → „$1“"
 ],
 "Restrict access to the report": [
  null,
  "Piira ligipääsu teatele"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Piirab ligipääsu teatele „$0“ grupiga. $1"
 ],
 "Return to installation": [
  null,
  "Tagasi paigalduse juurde"
 ],
 "Return to storage editor": [
  null,
  "Tagasi andmeruumi halduri juurde"
 ],
 "Review and install": [
  null,
  "Vaata üle ja paigalda"
 ],
 "Root account has been configured": [
  null,
  "Peakasutaja konto on seadistatud"
 ],
 "Root account is enabled": [
  null,
  "Peakasutaja konto pole kasutusel"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Juurkasutaja (peakasutaja) konto on kasutusel, kuid ühtegi tavakasutajat pole seadistatud"
 ],
 "Root password has been set.": [
  null,
  "Juurkasutaja (peakasutaja) salasõna on määratud."
 ],
 "Save": [
  null,
  "Salvesta"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Skaneeri oma telefoniga seda QR-koodi või ava:"
 ],
 "Search for a language": [
  null,
  "Otsi keelt"
 ],
 "Search for additional software": [
  null,
  "Otsi täiendavat tarkvara"
 ],
 "Search for an environment": [
  null,
  "Otsi sobivat keskkonda"
 ],
 "Search keyboard layout": [
  null,
  "Otsi klahvistiku paigutust"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Taga oma andmete turvalisus kettapõhise krüptimisega. See kehtiks vaid uute partitsioonide puhul"
 ],
 "Select": [
  null,
  "Vali"
 ],
 "Select a device": [
  null,
  "Vali seade"
 ],
 "Select city": [
  null,
  "Vali linn"
 ],
 "Select destination": [
  null,
  "Vali sihtobjekt"
 ],
 "Select region": [
  null,
  "Vali piirkond"
 ],
 "Selected (top = current)": [
  null,
  "Valitud (ülal = praegune)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Valitud seadme vorming „$0“ on selline, mida ei saa ümbervormindada."
 ],
 "Send us feedback on your installation": [
  null,
  "Saada meile oma paigaldamise kohta tagasisidet"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server pole leitav"
 ],
 "Set custom hostname": [
  null,
  "Siesta hostinimi"
 ],
 "Share disk with other operating systems": [
  null,
  "Jaga ketast muude operatsioonisüsteemidega"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Jaga ketast muude operatsioonisüsteemidega: $0"
 ],
 "Show AM/PM": [
  null,
  "Näita AM/PM (el/pl)"
 ],
 "Show API key": [
  null,
  "Näita API võtit"
 ],
 "Show PIN": [
  null,
  "Näita PIN-koodi"
 ],
 "Show confirmed password": [
  null,
  "Näita kinnitatud salasõna"
 ],
 "Show passphrase": [
  null,
  "Näita salasõna"
 ],
 "Show password": [
  null,
  "Näita salasõna"
 ],
 "Size": [
  null,
  "Suurus"
 ],
 "Software installation": [
  null,
  "Tarkvara paigaldus"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Tarkvara paigaldus: andmeruumi seadistamine on lõppenud. Tarkvara on parasjagu sinu arvutisse/seadmesse paigaldamisel."
 ],
 "Software selection": [
  null,
  "Tarkvara valik"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Enne jätkamist palun lõpeta mõned paigalduse sammud."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Mõned nõutavad partitsioonid on puudu: $0"
 ],
 "Space": [
  null,
  "Ruum"
 ],
 "Stacktrace": [
  null,
  "Pinujälg"
 ],
 "Storage": [
  null,
  "Andmeruum"
 ],
 "Storage configuration": [
  null,
  "Andmeruumi seadistus"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Andmeruumi seadistus: seadistamine on hetkel pooleli."
 ],
 "Storage editor": [
  null,
  "Andmeruumi haldur"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Andmeruum on jagatud vastavalt sammus „Muuda andmeruumi“ tehtud seadistusele."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Andmeruumi jaotus on kirjeldatud kickstarti failis. Kavandatud partitsioneerimise saad üle vaadata kokkuvõtlikus sammus."
 ],
 "Storage plugin failed": [
  null,
  "Andmeruumi lisamooduli töö ebaõnnestus"
 ],
 "Storage requirements not met": [
  null,
  "Andmeruumi nõuded pole tagatud"
 ],
 "Strong": [
  null,
  "Tugev"
 ],
 "Successfully installed": [
  null,
  "Paigaldamine õnnestus"
 ],
 "Successfully unlocked $0.": [
  null,
  "Lukustuse eemaldamine õnnestus: $0."
 ],
 "Suggested keyboards": [
  null,
  "Soovituslikud klahvistikud"
 ],
 "Suggested languages": [
  null,
  "Soovituslikud keeled"
 ],
 "System": [
  null,
  "Süsteem"
 ],
 "System configuration": [
  null,
  "Süsteemi seadistus"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Tarkvara paigaldus: tarkvara paigaldamine on lõppenud. Kogus süsteem on nüüd seadistatud."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda paigaldus on ootamatult peatunud."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Järgnevad avatud veateated võivad olla sinu probleemiga seotud. Enne uue veateate koostamist palun kindlasti vaata nad üle."
 ],
 "The following user will be created:": [
  null,
  "Lisatakse järgnev kasutaja:",
  "Lisatakse järgnevad kasutajad:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Paigaldamine eeldab $0 vaba pinna olemasolu, kuid valitud ketta/ketaste andmeruum on vaid $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Kriitilise vea tõttu ei saa paigaldaja tööd jätkata."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Kriitilise vea tõttu ei saa paigaldaja tööd jätkata: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Klahvistikupaigutus on peale andmekandja krüptimise salafraasi kasutuselevõtmist. Palun sisesta salafraas uuesti."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Sinu sisestatud salasõnas on ASCII-väliseid tähemärke. Klahvistikupaigutuse vahetamine ei pruugi sisestamise ajal olla võimalik."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Valitud vaikimisi klahvistik ei toeta ASCII-tähemärke. Palun vali selline, mis neid toetab."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Andmeruumi halduriga saad muuta, kustutada ja luua partitsioone. Lisaks võid kirjeldada loogilisi köiteid ja teha muudki. Ta on mõeldud kasutamiseks pigem lisavõimalusena, mitte aga standardpaigalduse osana."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Nendes logifailides võib leida delikaatset teavet nagu IP-aadressid, kasutajanimed või muud süsteemi üksikasjad."
 ],
 "This hostname can't be submitted": [
  null,
  "Seda hostinime ei saa kasutada"
 ],
 "This is unstable, pre-release software": [
  null,
  "See on tarkvara katseline eelversioon"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Seda paigutust kasutatakse alglaadimise ajal sinu süsteemi lukustuse avamiseks"
 ],
 "This may take a moment": [
  null,
  "Selleks võib kuluda mõni hetk"
 ],
 "This will take a few moments": [
  null,
  "Selleks kulub mõni hetk"
 ],
 "Time": [
  null,
  "Kellaaeg"
 ],
 "Timezone": [
  null,
  "Ajavöönd"
 ],
 "Title": [
  null,
  "Pealkiri"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0 - kasutamaks uut paigaldust, taaskäivita süsteem."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Jätkamaks palun vali seadmed, kuhu tahad süsteemi paigaldada."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Selle võimaluse kasutamiseks eemalda mõni olemasolev partitsioon või vähenda tema suurust nii, et vabaneb vähemalt $0 andmeruumi."
 ],
 "Type": [
  null,
  "Tüüp"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "„$0“ - kustutamise ajastamine pole võimalik"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "„$0“ - suuruse muutmine ajastamine pole võimalik"
 ],
 "Undo last action": [
  null,
  "Võta viimane tegevus tagasi"
 ],
 "Unlock": [
  null,
  "Ava lukustus"
 ],
 "Unlock encrypted devices": [
  null,
  "Eemalda krüptitud seadmete lukustus"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Olemasolevate andmete säilitamiseks ava krüptitud partitsioonid ja näita täiendavaid paigaldusmeetodeid."
 ],
 "Use configured storage": [
  null,
  "Kasuta seadistatud andmeruumi"
 ],
 "Use entire disk": [
  null,
  "Kasuta kogu ketast"
 ],
 "Use free space": [
  null,
  "Kasuta vaba ruumi"
 ],
 "Use local account": [
  null,
  "Kasuta kohaliku kontot"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Kasuta automaatse partitsioneerimise jaoks RAID-seadet"
 ],
 "User creation": [
  null,
  "Kasutaja lisamine"
 ],
 "User name": [
  null,
  "Kasutajanimi"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Kasutajanimes võivad sisalduda vaid: täppideta tähed vahemikus a-z, numbreid 0-9, kriipsud $0, punktid $1 või alakriipsud $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Kasutajanimi ei tohi olla reserveeritud sõna"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Kasutajanimed peavad olema lühemad, kui 33 tähemärki"
 ],
 "Validating...": [
  null,
  "Kontrollin õigsust..."
 ],
 "Weak": [
  null,
  "Nõrk"
 ],
 "Welcome": [
  null,
  "Tere tulemast"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Tere tulemast, see on Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Tere tulemast. Hetkel on meil paigaldamisel $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Selle veateate edastamisel järgnevad logid laaditakse üles automaatselt: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLockeriga krüptitud Windowsi partitsioonide suurust ei saa muuta"
 ],
 "You can close this browser window now.": [
  null,
  "Võid selle brauseriakna nüüd sulgeda."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Sa võid kas vabastada piisavalt andmeruumi ja lasta paigaldusrakendusel teha ülejäänu või seadistada partitsioonid käsitsi."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Sa võid luua API-võtme oma Bugzilla kasutajakonto jaoks $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Jätkamaks pead kas sisselülitama juurkasutaja konto või lisama tavalise kohaliku kasutaja."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Kuupäeva ja kellaaja automaatseks uuendamiseks peab arvutil olema toimiv võrguühendus."
 ],
 "Your progress will not be saved.": [
  null,
  "Paigalduse olek ei saa olema salvestatud."
 ],
 "completed step": [
  null,
  "lõpetatud samm"
 ],
 "current step": [
  null,
  "praegune samm"
 ],
 "delete": [
  null,
  "kustuta"
 ],
 "edit": [
  null,
  "muuda"
 ],
 "encrypt": [
  null,
  "krüpti"
 ],
 "encrypted": [
  null,
  "krüptitud"
 ],
 "extended partition": [
  null,
  "laiendatud partitsioon"
 ],
 "format as $0": [
  null,
  "vorminda kui $0"
 ],
 "here": [
  null,
  "siin"
 ],
 "incomplete": [
  null,
  "poolik"
 ],
 "mount": [
  null,
  "haagi"
 ],
 "pending step": [
  null,
  "ootel samm"
 ],
 "report the issue manually": [
  null,
  "teata veast käsitsi"
 ],
 "resized from $0": [
  null,
  "suurus muudetud $0-st"
 ],
 "shrink": [
  null,
  "kahanda"
 ],
 "shrink to $0": [
  null,
  "kahanda kuni $0-ni"
 ],
 "transient, will use DHCP": [
  null,
  "ajutine, kasutab DHCP-d"
 ],
 "undo": [
  null,
  "võta tegevus tagasi"
 ]
});
