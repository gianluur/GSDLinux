cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "et",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpiti failid"
 ],
 "Home": [
  null,
  "Avaleht"
 ],
 "Unable to create bookmark directory": [
  null,
  "Järjehoidjate kausta loomine ei õnnestunud"
 ],
 "Unable to save bookmark file": [
  null,
  "Järjehoidjate faili salvestamine ei õnnestunud"
 ],
 "Remove from bookmarks": [
  null,
  "Eemalda järjehoidjate seast"
 ],
 "Add to bookmarks": [
  null,
  "Lisa järjehoidjana"
 ],
 "Bookmarks": [
  null,
  "Järjehoidjad"
 ],
 "Bookmarked": [
  null,
  "Lisatud järjehoidjana"
 ],
 "Not bookmarked": [
  null,
  "Pole järjehoidjana lisatud"
 ],
 "Filesystem": [
  null,
  "Failisüsteem"
 ],
 "Edit path": [
  null,
  "Muuda asukohta"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Suurus"
 ],
 "Largest size": [
  null,
  "Suurim suurus"
 ],
 "Smallest size": [
  null,
  "Väikseim suurus"
 ],
 "Modified": [
  null,
  "Muudetud"
 ],
 "First modified": [
  null,
  "Esmalt muudetud"
 ],
 "Last modified": [
  null,
  "Viimati muudetud"
 ],
 "Owner": [
  null,
  "Omanik"
 ],
 "Owner ascending": [
  null,
  "Omaniku järgi kasvavalt"
 ],
 "Owner descending": [
  null,
  "Omaniku järgi kahanevalt"
 ],
 "Permissions": [
  null,
  "Õigused"
 ],
 "Most permissive": [
  null,
  "Enamlubav"
 ],
 "Least permissive": [
  null,
  "Vähemlubav"
 ],
 "Show keyboard shortcuts": [
  null,
  "Näita klahvistiku kiirklahve"
 ],
 "Filter directory": [
  null,
  "Filtreeri kausta"
 ],
 "Display as a list": [
  null,
  "Näida loendivaates"
 ],
 "Display as a grid": [
  null,
  "Näida ruudustikuvaates"
 ],
 "Sort": [
  null,
  "Järjestus"
 ],
 "Hide hidden items": [
  null,
  "Peida peidetud objektid"
 ],
 "Show hidden items": [
  null,
  "Näita peidetud objekte"
 ],
 "$0 files": [
  null,
  "$0 faili"
 ],
 "Uploaded as $0, $1": [
  null,
  "Üleslaaditud kui: $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Kas asendada „$0“ faili?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Kasutas „$0“ on juba olemas sellise nimega fail. Kui kavatsed ta asendada, sis kirjutatakse ka sisu üle."
 ],
 "New file": [
  null,
  "Uus fail"
 ],
 "Original file on server": [
  null,
  "Algne fail serveris"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Rakenda seda tegevust kõikidele vastuolus failidele"
 ],
 "Replace": [
  null,
  "Asenda"
 ],
 "Keep original": [
  null,
  "Säilita algne"
 ],
 "Cancel": [
  null,
  "Katkesta"
 ],
 "Failed": [
  null,
  "Ebaõnnestunud"
 ],
 "Upload error": [
  null,
  "Üleslaadimisviga"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Üleslaaditud faili sihtkausta tõstmine ei õnnestu"
 ],
 "Cancelled": [
  null,
  "Katkestatud"
 ],
 "Cancelled upload of $0": [
  null,
  "Üleslaadimine on katkestatud: „$0“"
 ],
 "File uploaded": [
  null,
  "Fail on laaditud üles"
 ],
 "Files uploaded": [
  null,
  "Failid on laaditud üles"
 ],
 "Change permissions": [
  null,
  "Muuda õigusi"
 ],
 "Uploads": [
  null,
  "Üleslaadimised"
 ],
 "Cancel upload of $0": [
  null,
  "Katkesta üleslaadimine: „$0“"
 ],
 "Upload $0% completed": [
  null,
  "Üleslaadimine on valmis: $0%"
 ],
 "Upload": [
  null,
  "Laadi üles"
 ],
 "None": [
  null,
  "Puudub"
 ],
 "Execute-only": [
  null,
  "Vaid käivitatav"
 ],
 "Write-only": [
  null,
  "Vaid kirjutatav"
 ],
 "Write and execute": [
  null,
  "Kirjutatav ja käivitatav"
 ],
 "Read-only": [
  null,
  "Vaid loetav"
 ],
 "Read and execute": [
  null,
  "Loetav ja käivitatav"
 ],
 "Read and write": [
  null,
  "Loetav ja kirjutatav"
 ],
 "Read, write, and execute": [
  null,
  "Loetav, kirjutatav ja käivitatav"
 ],
 "Block device": [
  null,
  "Plokkseade"
 ],
 "Character device": [
  null,
  "Märgiseade"
 ],
 "Directory": [
  null,
  "Kaust"
 ],
 "Named pipe": [
  null,
  "Nimega konveier"
 ],
 "Symbolic link": [
  null,
  "Sümbollink"
 ],
 "Regular file": [
  null,
  "Tavaline fail"
 ],
 "Socket": [
  null,
  "Sokkel"
 ],
 "Name cannot be empty": [
  null,
  "Nimi ei saa tühjaks jääda"
 ],
 "Name too long": [
  null,
  "Nimi on liiga pikk"
 ],
 "Name cannot include a /": [
  null,
  "Nimes ei tohi olla kaldkriipsu „/“"
 ],
 "Filename is the same as original name": [
  null,
  "Failinimi on sama, kui algne nimi"
 ],
 "Directory with the same name exists": [
  null,
  "Sellise nimega kaust on juba olemas"
 ],
 "File exists": [
  null,
  "Fail on olemas"
 ],
 "Pasting failed": [
  null,
  "Asetamine ei õnnestunud"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "„$0“ on olemas, ei kirjuta seda asetamisega üle."
 ],
 "Paste": [
  null,
  "Aseta"
 ],
 "Create directory": [
  null,
  "Loo kaust"
 ],
 "Create file": [
  null,
  "Loo fail"
 ],
 "Edit permissions": [
  null,
  "Muuda õigusi"
 ],
 "Open in terminal": [
  null,
  "Ava terminalis"
 ],
 "Open text file": [
  null,
  "Ava tekstifail"
 ],
 "Copy": [
  null,
  "Kopeeri"
 ],
 "Rename": [
  null,
  "Muuda nime"
 ],
 "Delete": [
  null,
  "Kustuta"
 ],
 "Download": [
  null,
  "Laadi alla"
 ],
 "Create link": [
  null,
  "Loo link"
 ],
 "Drop files to upload": [
  null,
  "Lohista siia üleslaaditavad failid"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Kuna teine üleslaadimine on juba töös, siis faile ei saa siia lohistada"
 ],
 "Close": [
  null,
  "Sulge"
 ],
 "Go up a directory": [
  null,
  "Mine kausta jagu ülespoole"
 ],
 "Go back": [
  null,
  "Mine tagasi"
 ],
 "Go forward": [
  null,
  "Mine edasi"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktiveeri valitud objekt või sisene kausta"
 ],
 "Rename selected file or directory": [
  null,
  "Muuda valitud faili või kausta nime"
 ],
 "Create new directory": [
  null,
  "Loo uus kaust"
 ],
 "Copy selected file or directory": [
  null,
  "Kopeeri valitud fail või kaust"
 ],
 "Paste file or directory": [
  null,
  "Aseta fail või kaust"
 ],
 "Select all": [
  null,
  "Vali kõik"
 ],
 "Save current file": [
  null,
  "Salvesta praegune fail"
 ],
 "Close editor": [
  null,
  "Sulge muutmisvaade"
 ],
 "Keyboard shortcuts": [
  null,
  "Klahvistiku kiirklahvid"
 ],
 "Navigation": [
  null,
  "Liikumine"
 ],
 "Editing": [
  null,
  "Muudan"
 ],
 "Editor": [
  null,
  "Muutmisvaade"
 ],
 "Force delete $0 items": [
  null,
  "Kustuta $0 objekti sundkorras"
 ],
 "Delete $0 items?": [
  null,
  "Kas kustutad $0 objekti?"
 ],
 "Force delete file $0?": [
  null,
  "Kas kustutad „$0“ faili sundkorras?"
 ],
 "Delete file $0?": [
  null,
  "Kas kustutad „$0“ faili?"
 ],
 "Force delete link $0?": [
  null,
  "Kas kustutad „$0“ lingi sundkorras?"
 ],
 "Delete link $0?": [
  null,
  "Kas kustutad „$0“ lingi?"
 ],
 "Force delete directory $0?": [
  null,
  "Kas kustutad „$0“ kausta sundkorras?"
 ],
 "Delete directory $0?": [
  null,
  "Kas kustutad „$0“ kausta?"
 ],
 "Force delete $0": [
  null,
  "Kustuta „$0“ sundkorras"
 ],
 "Delete $0?": [
  null,
  "Kas kustutad: $0?"
 ],
 "No access": [
  null,
  "Ligipääs puudub"
 ],
 "Missing type": [
  null,
  "Tüüp on puudu"
 ],
 "Collapse": [
  null,
  "Ahenda"
 ],
 "Show all files": [
  null,
  "Näita kõiki faile"
 ],
 "$0 permissions": [
  null,
  "$0 - õigused"
 ],
 "Permissions for $0 files": [
  null,
  "„$0“ faili õigused"
 ],
 "Ownership": [
  null,
  "Omand"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Access": [
  null,
  "Ligipääs"
 ],
 "Owner access": [
  null,
  "Ligipääs omanikule"
 ],
 "Group access": [
  null,
  "Ligipääs grupile"
 ],
 "Others access": [
  null,
  "Ligipääs teistele"
 ],
 "Security context": [
  null,
  "Turvakontekst"
 ],
 "Set executable as program": [
  null,
  "Määra programmina käivitatavaks"
 ],
 "Change": [
  null,
  "Muuda"
 ],
 "Change permissions for enclosed files": [
  null,
  "Muuda kaasatud failide õigusi"
 ],
 "(original owner)": [
  null,
  "(algne omanik)"
 ],
 "keep original owners": [
  null,
  "jäta algsed omanikus alles"
 ],
 "Paste as owner": [
  null,
  "Aseta omanikuna"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Asetamisel failidel on erinevad omanikud. Vaikimisi kohendatakse omanik vastavaks sihtkausta omanikule."
 ],
 "New owner": [
  null,
  "Uus omanik"
 ],
 "Overwrite": [
  null,
  "Kirjuta üle"
 ],
 "New filename": [
  null,
  "Uus failinimi"
 ],
 "New name": [
  null,
  "Uus nimi"
 ],
 "Rename $0?": [
  null,
  "Kas muudad nime: $0?"
 ],
 "link to $0": [
  null,
  "link asukohale „$0“"
 ],
 "Create link to $0": [
  null,
  "Loo link siia: $0"
 ],
 "Target": [
  null,
  "Sihtmärk"
 ],
 "Symlink name": [
  null,
  "Sümbollingi nimi"
 ],
 "Type": [
  null,
  "Tüüp"
 ],
 "Absolute vs. Relative": [
  null,
  "Absoluutne või suhteline"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Absoluutsed sümbollingid sobivad olukorras, kus nad viitavad failidele või kaustadele, mis püsivad kogu aeg samas kohas, näiteks nagu süsteemifailid."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Absoluutsed sümbollingid sobivad olukorras, kus nii sümbollink kui tema siht võivad samal ajal muutuda, näiteks nime muutmisel või kausta teise kohta tõstmisel."
 ],
 "Absolute": [
  null,
  "Absoluutne"
 ],
 "Relative": [
  null,
  "Suhteline"
 ],
 "The file has been removed on disk": [
  null,
  "Fail on andmekandjalt eemaldatud"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Olemasolev fail muutus ootamatult"
 ],
 "Edit $0": [
  null,
  "Muuda: $0"
 ],
 "View $0": [
  null,
  "Vaata: $0"
 ],
 "The file has changed on disk": [
  null,
  "Fail on andmekandjal muutunud"
 ],
 "Reload": [
  null,
  "Laadi uuesti"
 ],
 "Ignore": [
  null,
  "Eira"
 ],
 "Save": [
  null,
  "Salvesta"
 ],
 "Save changes?": [
  null,
  "Kas salvestad muudatused?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Fail on peale avamist kustutatud ning salvestamisel ta luuakse uuesti."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Fail on andmekandjal muutunud avamishetke ja praeguse hetke vahel"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "„$0“ sisaldab salvestamata muudatusi, mis lähevad loobumisel jäädavalt kaotsi."
 ],
 "Discard": [
  null,
  "Loobu"
 ],
 "File name": [
  null,
  "Failinimi"
 ],
 "Create": [
  null,
  "Loo"
 ],
 "Cannot create file in current directory": [
  null,
  "Faili ei õnnestu sellesse kausta luua"
 ],
 "Permission denied": [
  null,
  "Juurepääs keelatud"
 ],
 "Directory name cannot be empty": [
  null,
  "Kausta nimi ei saa jääda tühjaks"
 ],
 "Directory name too long": [
  null,
  "Kausta nimi on liiga pikk"
 ],
 "Directory name cannot include a /": [
  null,
  "Kausta nimes ei saa olla kaldkriipsu /"
 ],
 "Directory name": [
  null,
  "Kausta nimi"
 ],
 "Directory owner": [
  null,
  "Kausta omanik"
 ],
 "No matching results": [
  null,
  "Vastavaid tulemusi pole"
 ],
 "Clear filter": [
  null,
  "Tühjenda filter"
 ],
 "Directory is empty": [
  null,
  "Kaust on tühi"
 ],
 "$0 item is hidden": [
  null,
  "$0 objekt on peidetud",
  "$0 objekti on peidetud"
 ],
 "Folder": [
  null,
  "Kaust"
 ],
 "File": [
  null,
  "Fail"
 ],
 "Others": [
  null,
  "Muud"
 ],
 "$0 files selected": [
  null,
  "Valitud on $0 faili"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Kaustas on $0 alamkausta ja $1 faili"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Kaustas on $0 alamkausta ja $1 faili, neist $2 on peidetud"
 ],
 "User": [
  null,
  "Kasutaja"
 ]
});
