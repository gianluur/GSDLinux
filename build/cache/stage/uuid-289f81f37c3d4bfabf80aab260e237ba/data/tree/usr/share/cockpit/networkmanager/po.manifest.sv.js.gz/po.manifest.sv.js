cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Tjänster"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "gränssnitt"
 ],
 "bridge": [
  null,
  "brygga"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "bindning"
 ],
 "team": [
  null,
  "team"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "brandvägg"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zon"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Hantera nätverksbindningar"
 ],
 "Managing networking teams": [
  null,
  "Hantera nätverksteam"
 ],
 "Managing networking bridges": [
  null,
  "Hantera nätverksbryggor"
 ],
 "Managing VLANs": [
  null,
  "Hantera VLAN"
 ],
 "Managing firewall": [
  null,
  "Hantera brandvägg"
 ]
});
