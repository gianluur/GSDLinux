cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Public key": [
  null,
  "Öffentlicher Schlüssel"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "Connect": [
  null,
  "Verbinden"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "Trust and add host": [
  null,
  "Host vertrauen und hinzufügen"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Wenn der Fingerabdruck übereinstimmt, klicken Sie 'Vertrauen und Host hinzufügen'. Andernfalls lehnen Sie die Verbindung ab und kontaktieren Sie den Administrator."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Der resultierende Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden. Wenn Sie eine andere Person bitten, die Überprüfung für Sie vorzunehmen, kann diese die Ergebnisse mit einer beliebigen Methode übermitteln."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "Verify fingerprint": [
  null,
  "Fingerabdruck verifizieren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Führen Sie diesen Befehl über ein vertrauenswürdiges Netzwerk oder physisch auf dem entfernten Rechner aus:"
 ],
 "The fingerprint should match:": [
  null,
  "Der Fingerabdruck sollte übereinstimmen:"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "Disconnected": [
  null,
  "Getrennt"
 ],
 "Permission denied": [
  null,
  "Erlaubnis verweigert"
 ],
 "Clear input value": [
  null,
  "Eingabewert löschen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit $0 zu synchronisieren"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "Create $0": [
  null,
  "$0 erstellen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Es stehen keine Methoden zur Verfügung, um Administratorrechte zu erlangen (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "less than a minute ago": [
  null,
  "vor weniger als einer Minute"
 ],
 "in less than a minute": [
  null,
  "in weniger als einer Minute"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Strong password": [
  null,
  "Starkes Passwort"
 ],
 "Acceptable password": [
  null,
  "Annehmbares Passwort"
 ],
 "Weak password": [
  null,
  "Schwaches Passwort"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Hide password": [
  null,
  "Passwort verbergen"
 ],
 "password quality": [
  null,
  "Passwortstärke"
 ],
 "Show confirmation password": [
  null,
  "Bestätigungspasswort anzeigen"
 ],
 "Hide confirmation password": [
  null,
  "Bestätigungspasswort ausblenden"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Removing $0": [
  null,
  "Entferne $0"
 ],
 "Installing $0": [
  null,
  "Installiere $0"
 ],
 "Unknown host: $0": [
  null,
  "Unbekannter Host: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort an."
 ],
 "SSH key login": [
  null,
  "SSH-Schlüssel-Anmeldung"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit hat Fehlercode gemeldet $0"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "Row expansion": [
  null,
  "Zeilenerweiterung"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Error during initialization": [
  null,
  "Fehler während der Initialisierung"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Home": [
  null,
  "Persönlicher Ordner"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Kein Verzeichnis"
 ],
 "All files": [
  null,
  "Alle Dateien"
 ],
 "Recent": [
  null,
  "Zuletzt verwendet"
 ],
 "No recent directories": [
  null,
  "Keine aktuellen Verzeichnisse"
 ],
 "No recent files": [
  null,
  "Keine aktuellen Dateien"
 ],
 "Type to filter": [
  null,
  "Zum Filtern tippen"
 ],
 "File chooser actions": [
  null,
  "Aktionen in der Dateiauswahl"
 ],
 "Open in file browser": [
  null,
  "Im Dateibrowser öffnen"
 ],
 "Hide hidden files": [
  null,
  "Versteckte Dateien ausblenden"
 ],
 "Show hidden files": [
  null,
  "Versteckte Dateien anzeigen"
 ],
 "Filesystem": [
  null,
  "Dateisystem"
 ],
 "Clear filters": [
  null,
  "Filter löschen"
 ],
 "Directory is empty": [
  null,
  "Verzeichnis ist leer"
 ],
 "Directory has no sub-directories": [
  null,
  "Verzeichnis hat keine Unterverzeichnisse"
 ],
 "This directory contains only hidden files": [
  null,
  "Dieses Verzeichnis enthält nur versteckte Dateien"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "Folder": [
  null,
  "Ordner"
 ],
 "File": [
  null,
  "Datei"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Embedded PC": [
  null,
  "Eingebetteter PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Select an option": [
  null,
  "Wählen Sie eine Option aus"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Generated": [
  null,
  "Generiert"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Delete $0": [
  null,
  "$0 löschen"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Not available": [
  null,
  "Nicht verfügbar"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Preserve": [
  null,
  "Beibehalten"
 ],
 "Random": [
  null,
  "Zufällig"
 ],
 "Stable": [
  null,
  "Stabil"
 ],
 "Use $0": [
  null,
  "$0 verwenden"
 ],
 "Failed to save settings": [
  null,
  "Fehler beim Speichern der Einstellungen"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Die Erstellung dieser $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Create it": [
  null,
  "Anlegen"
 ],
 "Invalid prefix $0": [
  null,
  "Ungültiger Prefix $0"
 ],
 "Invalid metric $0": [
  null,
  "Ungültige Metrik $0"
 ],
 "Invalid address $0": [
  null,
  "Ungültige Adresse $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Ungültiger Präfix oder ungültige Netzmaske $0"
 ],
 "Testing connection": [
  null,
  "Prüfe Verbindung"
 ],
 "Restoring connection": [
  null,
  "Verbindung wird wiederhergestellt"
 ],
 "Troubleshoot…": [
  null,
  "Fehlerbehebung…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager wird nicht ausgeführt"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ist nicht installiert"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Netzwerkgeräte und -diagramme erfordern NetworkManager"
 ],
 "Enable service": [
  null,
  "Service aktivieren"
 ],
 "Network interface '$0' not found": [
  null,
  "Netzwerkschnittstelle ‚$0‘ nicht gefunden"
 ],
 "Return to overview page": [
  null,
  "Zurück zur Übersichtsseite"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Sie sind nicht berechtigt, die Firewall zu ändern."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu deaktivieren"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu aktivieren"
 ],
 "Disable the firewall": [
  null,
  "Firewall deaktivieren"
 ],
 "Enable the firewall": [
  null,
  "Firewall aktivieren"
 ],
 "Edit service $0": [
  null,
  "Dienst $0 bearbeiten"
 ],
 "Remove service $0": [
  null,
  "Dienst $0 entfernen"
 ],
 "Included Services": [
  null,
  "Enthaltene Dienste"
 ],
 "Additional port": [
  null,
  "Zusätzlicher Port"
 ],
 "Remove additional port": [
  null,
  "Entferne zusätzlichen Port"
 ],
 "Remove zone $0": [
  null,
  "Zone $0 entfernen"
 ],
 "Add services to zone $0": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Add services": [
  null,
  "Dienste hinzufügen"
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 Zone"
 ],
 "Interface": [
  null,
  "Schnittstelle",
  "Schnittstellen"
 ],
 "Allowed addresses": [
  null,
  "Erlaubte Adressen"
 ],
 "Entire subnet": [
  null,
  "Gesamtes Subnetzwerk"
 ],
 "There are no active services in this zone": [
  null,
  "In dieser Zone gibt es keine aktiven Dienste"
 ],
 "Filter services": [
  null,
  "Filterdienste"
 ],
 "Failed to edit service": [
  null,
  "Fehler bei der Bearbeitung des Dienstes"
 ],
 "Failed to add port": [
  null,
  "Hinzufügen des Portes fehlgeschlagen"
 ],
 "Failed to add service": [
  null,
  "Hinzufügen des Services fehlgeschlagen"
 ],
 "Unknown service name": [
  null,
  "Unbekannten Servicename"
 ],
 "Invalid port number": [
  null,
  "Ungültige Port-Nummer"
 ],
 "Invalid range": [
  null,
  "Ungültiger Bereich"
 ],
 "Range must be strictly ordered": [
  null,
  "Bereich muss strikt geordnet sein"
 ],
 "Edit service": [
  null,
  "Dienst bearbeiten"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Benutzerdefinierten Dienst in Zone $0 bearbeiten"
 ],
 "Add ports": [
  null,
  "Ports hinzufügen"
 ],
 "Add ports to $0 zone": [
  null,
  "Ports zu Zone $0 hinzufügen"
 ],
 "Add services to $0 zone": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Custom ports": [
  null,
  "Eigene Ports"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Beispiel: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Komma-separierte Ports, Bereiche und Dienste sind erlaubt"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Beispiel: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Wenn leer, wird die Kennung auf Basis der zugehörigen Port-Dienste und Port-Nummern generiert"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Das Hinzufügen von eigenen Ports wird firewalld neu starten. Ein Neustart setzt alle Freischaltungen auf Laufzeitebene zurück!"
 ],
 "Failed to add zone": [
  null,
  "Hinzufügen der Zone fehlgeschlagen"
 ],
 "Add zone": [
  null,
  "Zone hinzufügen"
 ],
 "Trust level": [
  null,
  "Vertrauensstufe"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sortiert von am wenigsten bis am meisten vertrauenswürdig"
 ],
 "Custom zones": [
  null,
  "Eigene Zonen"
 ],
 "No description available": [
  null,
  "Keine Beschreibung verfügbar"
 ],
 "Included services": [
  null,
  "Enthaltene Dienste"
 ],
 "The cockpit service is automatically included": [
  null,
  "Der Cockpit-Dienst ist automatisch enthalten"
 ],
 "Interfaces": [
  null,
  "Schnittstellen"
 ],
 "Range": [
  null,
  "Bereich"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-Adresse mit Routing-Präfix. Trennen Sie mehrere Werte mit einem Komma. Beispiel: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Betätigen sie das entfernen von $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Diese Zone enthält den Cockpit-Dienst. Stellen Sie sicher, dass diese Zone nicht auf Ihre aktuelle Web-Konsolenverbindung angewendet wird."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Das entfernen der Zone wird alle Service in ihr entfernen."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Das entfernen des Cockpit-Services kann die Web Konsole nicht mehr erreichbar machen. Stelen sie sicher, dass die Zone keine Auswirkungen auf ihre aktuelle Web Konsolen Verbindung hat."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Dienst $0 aus der Zone $1 entfernen"
 ],
 "Firewall is not available": [
  null,
  "Firewall ist nicht verfügbar"
 ],
 "Please install the $0 package": [
  null,
  "Bitte installieren Sie die $0 Paket"
 ],
 "Add a new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Add new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Eingehende Anfragen werden standardmäßig blockiert. Ausgehende Anfragen werden nicht blockiert."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID darf nicht leer sein"
 ],
 "Password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "Failed to connect": [
  null,
  "Verbindung fehlgeschlagen"
 ],
 "Check your password.": [
  null,
  "Überprüfen Sie Ihr Passwort."
 ],
 "Connect to hidden network": [
  null,
  "Mit verstecktem Netzwerk verbinden"
 ],
 "Connect to $0": [
  null,
  "Verbinden zu $0"
 ],
 "Network name": [
  null,
  "Netzwerkname"
 ],
 "Security": [
  null,
  "Sicherheit"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Löschen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Einschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Switch on $0": [
  null,
  "$0 anschalten"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ausschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Switch off $0": [
  null,
  "$0 ausschalten"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Team": [
  null,
  "Team"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Brücke"
 ],
 "Unknown \"$0\"": [
  null,
  "Unbekannte \"$0\""
 ],
 "Carrier": [
  null,
  "Träger"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "No": [
  null,
  "Nein"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Unknown configuration": [
  null,
  "Unbekannte Konfiguration"
 ],
 "Additional address $val": [
  null,
  "Zusätzliche Adresse $val"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Zusätzliches DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Zusätzliche DNS-Suchdomänen $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS-Suchdomänen $val"
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Connect automatically": [
  null,
  "Verbindung automatisch herstellen"
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP-Überwachung"
 ],
 "Broken configuration": [
  null,
  "Fehlerhafte Konfiguration"
 ],
 "Team port": [
  null,
  "Netzwerk-Team Anschluss"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "Priorität $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Weiterleitungsverzögerung $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Hello-Zeit $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximales Alter der Nachrichten $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Pfadkosten $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hairpin-Modus"
 ],
 "Bridge port": [
  null,
  "Netzwerkbrücken-Port"
 ],
 "Parent $parent": [
  null,
  "Übergeordnetes Element $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Netzwerkpasswort wird nicht gespeichert. Bitte vergessen und erneut mit diesem Netzwerk verbinden."
 ],
 "Failed to connect to $0": [
  null,
  "Fehler beim Verbinden mit $0"
 ],
 "secured": [
  null,
  "gesichert"
 ],
 "open": [
  null,
  "offen"
 ],
 "Last connected: $0": [
  null,
  "Zuletzt verbunden: $0"
 ],
 "Signal strength": [
  null,
  "Signalstärke"
 ],
 "Not permitted to disconnect network": [
  null,
  "Die Trennung vom Netzwerk ist nicht zulässig"
 ],
 "Disconnect": [
  null,
  "Verbindung trennen"
 ],
 "Not permitted to connect to network": [
  null,
  "Das Verbinden mit dem Netzwerk ist nicht zulässig"
 ],
 "Forget": [
  null,
  "Vergessen"
 ],
 "$0 hidden network": [
  null,
  "$0 verstecktes Netzwerk",
  "$0 versteckte Netzwerke"
 ],
 "Filter": [
  null,
  "Filter"
 ],
 "Refresh": [
  null,
  "Aktualisieren"
 ],
 "Available networks": [
  null,
  "Verfügbare Netzwerke"
 ],
 "Network": [
  null,
  "Netzwerk"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Signal": [
  null,
  "Signal"
 ],
 "Rate": [
  null,
  "Rate"
 ],
 "Not permitted to configure network devices": [
  null,
  "Keine Berechtigung zur Konfiguration von Netzwerkgeräten"
 ],
 "Enable or disable the device": [
  null,
  "Gerät aktivieren oder deaktivieren"
 ],
 "This device cannot be managed here.": [
  null,
  "Dieses Gerät kann hier nicht verwaltet werden."
 ],
 "Connection will be lost": [
  null,
  "Verbindung geht verloren"
 ],
 "Keep connection": [
  null,
  "Verbindung halten"
 ],
 "Invalid IP address: $0": [
  null,
  "Ungültige IP-Adresse: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Ungültige Zieladresse: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Ungültige Gateway-Adresse: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Ungültige DNS-Adresse: $0"
 ],
 "Preparing": [
  null,
  "Vorbereitung läuft"
 ],
 "Configuring": [
  null,
  "Konfiguriere"
 ],
 "Authenticating": [
  null,
  "Authentifiziere"
 ],
 "Configuring IP": [
  null,
  "Konfiguriere IP"
 ],
 "Checking IP": [
  null,
  "IP wird überprüft"
 ],
 "Waiting": [
  null,
  "Wartet"
 ],
 "Active": [
  null,
  "Aktiv"
 ],
 "Deactivating": [
  null,
  "Wird deaktiviert"
 ],
 "Adhoc": [
  null,
  "Ad-hoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Vermaschtes Netz"
 ],
 "No carrier": [
  null,
  "Kein Träger"
 ],
 "Part of $0": [
  null,
  "Teil von $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ändern der Einstellungen wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Change the settings": [
  null,
  "Bridge Port-Einstellungen"
 ],
 "Add bridge": [
  null,
  "Bridge hinzufügen"
 ],
 "Edit bridge settings": [
  null,
  "Netzwerkbrücke-Einstellungen bearbeiten"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "STP-Priorität"
 ],
 "STP forward delay": [
  null,
  "STP Forward Delay"
 ],
 "STP hello time": [
  null,
  "STP Hello-Zeitintervall"
 ],
 "STP maximum message age": [
  null,
  "STP Maximum Message Age"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Aktive Sicherung"
 ],
 "Load balancing": [
  null,
  "Lastverteilung"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP-Ping"
 ],
 "NSNA ping": [
  null,
  "NSNA-Ping"
 ],
 "Add team": [
  null,
  "Team hinzufügen"
 ],
 "Edit team settings": [
  null,
  "Team Einstellungen bearbeiten"
 ],
 "Runner": [
  null,
  "Runner"
 ],
 "Balancer": [
  null,
  "Balancer"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Link watch": [
  null,
  "Link beobachten"
 ],
 "Link up delay": [
  null,
  "Verzögerung bei der Aktivierung einer Verbindung"
 ],
 "Link down delay": [
  null,
  "Verzögerung bei der Deaktivierung einer Verbindung"
 ],
 "Ping interval": [
  null,
  "Ping-Intervall"
 ],
 "Ping target": [
  null,
  "Ping-Ziel"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisch (nur DHCP)"
 ],
 "Link local": [
  null,
  "Link local"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Shared": [
  null,
  "Geteilt"
 ],
 "Prefix length or netmask": [
  null,
  "Präfix oder Netzmaske"
 ],
 "Prefix length": [
  null,
  "Präfixlänge"
 ],
 "IPv4 settings": [
  null,
  "IPv4-Einstellungen"
 ],
 "IPv6 settings": [
  null,
  "IPv6-Einstellungen"
 ],
 "Addresses": [
  null,
  "Adressen"
 ],
 "Select method": [
  null,
  "Methode auswählen"
 ],
 "Add address": [
  null,
  "Adresse hinzufügen"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "DNS Server hinzufügen"
 ],
 "DNS search domains": [
  null,
  "DNS Suchdomänen"
 ],
 "Add search domain": [
  null,
  "Suchdomäne hinzufügen"
 ],
 "Search domain": [
  null,
  "Suchdomäne"
 ],
 "Routes": [
  null,
  "Routen"
 ],
 "Add route": [
  null,
  "Route hinzufügen"
 ],
 "Metric": [
  null,
  "Metrik"
 ],
 "Enter a valid MAC address": [
  null,
  "Geben Sie eine gültige MAC-Adresse ein"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 Netzwerk",
  "$0 Netzwerke"
 ],
 "Add VPN": [
  null,
  "VPN hinzufügen"
 ],
 "Add bond": [
  null,
  "Bündelung hinzufügen"
 ],
 "Add VLAN": [
  null,
  "VLAN hinzufügen"
 ],
 "Edit rules and zones": [
  null,
  "Regeln und Zonen bearbeiten"
 ],
 "$0 active zone": [
  null,
  "$0 aktive Zone",
  "$0 aktive Zonen"
 ],
 "Managed interfaces": [
  null,
  "Verwaltete Schnittstellen"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "Sending": [
  null,
  "Senden"
 ],
 "Receiving": [
  null,
  "Empfangen"
 ],
 "Unmanaged interfaces": [
  null,
  "Unverwaltete Schnittstellen"
 ],
 "Network logs": [
  null,
  "Netzwerkprotokolle"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresse darf nicht leer sein oder ist nicht korrekt formatiert"
 ],
 "Invalid IP address '$0'": [
  null,
  "Ungültige IP-Adresse ‚$0‘"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Paket wireguard-tools ist nicht installiert"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Peer #$0 hat einen ungültigen Endpunkt. Er muss als Host:Port angegeben werden, z. B. 1.2.3.4:51820, [2001:db8::1]:51820 oder example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Peer #$0 hat ungültigen Endpunkt-Port. Port muss eine Zahl sein."
 ],
 "Listen port must be a number": [
  null,
  "Der Port, auf dem gehört wird, muss eine Nummer sein"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN hinzufügen"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN bearbeiten"
 ],
 "Private key": [
  null,
  "Privater Schlüssel"
 ],
 "Paste existing key": [
  null,
  "Vorhandenen Schlüssel einfügen"
 ],
 "Regenerate": [
  null,
  "Regenerieren"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Der öffentliche Schlüssel wird generiert, wenn ein gültiger privater Schlüssel eingegeben wird"
 ],
 "Listen port": [
  null,
  "Auf Port Lauschen"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Wird auf \"Automatisch\" gesetzt"
 ],
 "IP addresses": [
  null,
  "IP-Adressen"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Mehrere Adressen können mit Kommas oder Leerzeichen als Trennzeichen angegeben werden."
 ],
 "Peers": [
  null,
  "Peers"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Peers sind andere Rechner, die eine Verbindung zu diesem Rechner herstellen. Öffentliche Schlüssel von anderen Rechnern werden untereinander ausgetauscht."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Der Endpunkt, der als \"Server\" fungiert, muss als host:port angegeben werden, andernfalls kann er leer gelassen werden."
 ],
 "Add peer": [
  null,
  "Peer hinzufügen"
 ],
 "Endpoint": [
  null,
  "Endpunkt"
 ],
 "Allowed IPs": [
  null,
  "Erlaubte IP-Adressen"
 ],
 "No peers added.": [
  null,
  "Keine Peers hinzugefügt."
 ],
 "Edit VLAN settings": [
  null,
  "Editieren der VLAN Einstellungen"
 ],
 "Parent": [
  null,
  "Übergeordnet"
 ],
 "VLAN ID": [
  null,
  "VLAN-Kennung"
 ],
 "Transmitting": [
  null,
  "Wird übertragen"
 ],
 "MTU must be a positive number": [
  null,
  "MTU muss eine positive Zahl sein"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Set to": [
  null,
  "Einstellen"
 ],
 "Team port settings": [
  null,
  "Team port Einstellungen"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "LACP key": [
  null,
  "LACP-Schlüssel"
 ],
 "Bridge port settings": [
  null,
  "Netzwerkbrücke-Port-Einstellungen"
 ],
 "Path cost": [
  null,
  "Pfadkosten"
 ],
 "Hair pin mode": [
  null,
  "Hairpin Modus"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiver Sendeausgleich (tlb)"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiver Lastausgleich (alb)"
 ],
 "MII (recommended)": [
  null,
  "MII (empfohlen)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Bond-Einstellungen bearbeiten"
 ],
 "Network bond": [
  null,
  "Netzwerkbindung"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Ein gebündelter Netzwerkadapter kombiniert mehrere Netzweradapter zu einem logischen Netzwerkadapter mit mehr Durchsatz und Redundanz."
 ],
 "Link monitoring": [
  null,
  "Verbindungsüberwachung"
 ],
 "Monitoring interval": [
  null,
  "Überwachungsintervall"
 ],
 "Monitoring targets": [
  null,
  "Überwachungsziele"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Entfernen von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Remove $0": [
  null,
  "Entferne $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Hinzufügen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr verfügbar."
 ],
 "No interfaces available": [
  null,
  "Keine Schnittstellen verfügbar"
 ],
 "Add member": [
  null,
  "Mitglied hinzufügen"
 ],
 "Interface members": [
  null,
  "Schnittstellenmitglieder"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Dieses Werkzeug konfiguriert das System zum Erzeugen von Kernel Crashdumps. Es unterstützt \"local\" (Festplatte), \"ssh\" und \"nfs\" als Schreibziele."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ]
});
