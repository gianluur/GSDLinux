cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Schimbarea cheilor este adesea rezultatul reinstalării sistemului de operare. Cu toate acestea, o schimbare neașteptată poate indica o încercare a unei terțe părți de a vă intercepta conexiunea."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pentru a vă asigura că conexiunea dumneavoastră nu este interceptată de o terță parte rău intenționată, vă rugăm să verificați amprenta cheii gazdei:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Conectează-te"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Services": [
  null,
  "Servicii"
 ],
 "Journal": [
  null,
  "Jurnal"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Informații despre componentele mașinii"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Type": [
  null,
  "Tip"
 ],
 "Copy": [
  null,
  "Copiază"
 ],
 "Copied": [
  null,
  "Copiat"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Details": [
  null,
  "Detalii"
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Edit": [
  null,
  "Editare"
 ],
 "Remove": [
  null,
  "Elimină"
 ],
 "active": [
  null,
  "activă"
 ],
 "Default": [
  null,
  "Implicită"
 ],
 "Light": [
  null,
  "Luminoasă"
 ],
 "Dark": [
  null,
  "Întunecată"
 ],
 "Help": [
  null,
  "Ajutor"
 ],
 "Select": [
  null,
  "Selectează"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Search": [
  null,
  "Caută"
 ],
 "No results found": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nu este instalat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Pe $0 nu este instalată o versiune compatibilă a Cockpit."
 ],
 "Add": [
  null,
  "Adaugă"
 ],
 "$0 key changed": [
  null,
  "Cheia $0 a fost schimbată"
 ],
 "Trust and add host": [
  null,
  "Am încredere, adaugă gazda"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pentru a verifica o amprentă digitală, executați următoarea comandă pe $0, fie fizic, de la mașină, fie printr-o rețea de încredere:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Dacă amprenta digitală se potrivește, faceți clic pe „Am încredere, adaugă gazda”. În caz contrar, nu vă conectați și contactați administratorul."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică. Dacă îi ceri altcuiva să efectueze verificarea în locul tău, acea persoană îți poate trimite rezultatele prin orice metodă."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vă conectați la $0 pentru prima dată."
 ],
 "Verify fingerprint": [
  null,
  "Verifică amprenta digitală"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Executați această comandă într-o rețea de încredere sau direct pe mașina la distanță:"
 ],
 "The fingerprint should match:": [
  null,
  "Amprenta digitală trebuie să se potrivească:"
 ],
 "The password can not be empty": [
  null,
  "Parola nu poate fi goală"
 ],
 "The key password can not be empty": [
  null,
  "Parola cheii nu poate fi goală"
 ],
 "The key passwords do not match": [
  null,
  "Parolele cheii nu se potrivesc"
 ],
 "Log in to $0": [
  null,
  "Conectează-te la $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nu se poate efectua autentificarea la $0. Gazda nu acceptă autentificarea cu parolă și niciuna dintre cheile dvs. SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată de o parolă, iar serverul nu permite autentificarea cu o parolă. Vă rugăm să introduceți parola cheii la $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată. Vă puteți autentifica fie folosind parola de acces, fie introducând parola cheii la $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Creează o nouă cheie SSH și-o autorizează"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se va crea o nouă cheie SSH la $0 pentru $1 pe $2, iar aceasta va fi adăugată la fișierul $3 al lui $4 pe $5."
 ],
 "Key password": [
  null,
  "Parola cheii"
 ],
 "Confirm key password": [
  null,
  "Confirmă parola cheii"
 ],
 "Authorize SSH key": [
  null,
  "Autorizează cheia SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Cheia SSH $0 din $1 de pe $2 va fi adăugată la fișierul $3 din $4 de pe $5."
 ],
 "Authentication": [
  null,
  "Autentificare"
 ],
 "SSH key": [
  null,
  "Cheie SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Cheia SSH $0 va fi disponibilă pe durata restului sesiunii și va putea fi utilizată și pentru conectarea la alte gazde."
 ],
 "Permission denied": [
  null,
  "Permisiune refuzată"
 ],
 "Clear input value": [
  null,
  "Șterge valoarea introdusă"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de dată incorect și format de oră incorect"
 ],
 "Invalid time format": [
  null,
  "Format de oră nevalid"
 ],
 "Invalid date format": [
  null,
  "Format de dată incorect"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nu se poate planifica un eveniment în trecut"
 ],
 "No delay": [
  null,
  "Fără întârziere"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minute"
 ],
 "20 minutes": [
  null,
  "20 de minute"
 ],
 "40 minutes": [
  null,
  "40 de minute"
 ],
 "60 minutes": [
  null,
  "60 de minute"
 ],
 "Specific time": [
  null,
  "Momentul specificat"
 ],
 "Shut down": [
  null,
  "Oprire"
 ],
 "Reboot": [
  null,
  "Repornire"
 ],
 "Message to logged in users": [
  null,
  "Mesaj pentru utilizatorii autentificați"
 ],
 "Delay": [
  null,
  "Întârziere"
 ],
 "Pick date": [
  null,
  "Alegeți data"
 ],
 "Toggle date picker": [
  null,
  "Activează/dezactivează selectorul de dată"
 ],
 "Synchronized": [
  null,
  "Sincronizat"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizat cu $0"
 ],
 "Synchronizing": [
  null,
  "Se sincronizează"
 ],
 "Trying to synchronize with $0": [
  null,
  "Se încearcă sincronizarea cu $0"
 ],
 "Not synchronized": [
  null,
  "Nu este sincronizat"
 ],
 "Log messages": [
  null,
  "Mesaje de jurnal"
 ],
 "NTP server": [
  null,
  "server NTP"
 ],
 "Manually": [
  null,
  "În mod manual"
 ],
 "Automatically using NTP": [
  null,
  "Utilizând NTP în mod automat"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizând în mod automat servere NTP suplimentare"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizând în mod automat servere NTP specifice"
 ],
 "Time zone": [
  null,
  "Fusul orar"
 ],
 "Set time": [
  null,
  "Ajustează ora"
 ],
 "Invalid timezone": [
  null,
  "Fus orar nevalid"
 ],
 "Need at least one NTP server": [
  null,
  "Este necesar cel puțin un server NTP"
 ],
 "Change system time": [
  null,
  "Schimbă ora sistemului"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Path to file": [
  null,
  "Ruta către fișier"
 ],
 "No such file or directory": [
  null,
  "Nu există un astfel de fișier sau director"
 ],
 "Create $0": [
  null,
  "Creează $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Află mai multe"
 ],
 "You now have administrative access.": [
  null,
  "Acum aveți acces de administrator."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nu sunt disponibile metode pentru a obține acces administrativ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentificați-vă pentru a obține acces administrativ"
 ],
 "Switch to administrative access": [
  null,
  "Treceți la acces administrativ"
 ],
 "Authenticate": [
  null,
  "Autentifica"
 ],
 "Administrative access": [
  null,
  "Acces administrativ"
 ],
 "Problem becoming administrator": [
  null,
  "Probleme în devenirea administrator"
 ],
 "Method": [
  null,
  "Metodă"
 ],
 "Limit access": [
  null,
  "Limitează accesul"
 ],
 "Switch to limited access": [
  null,
  "Treceți la acces limitat"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Modul de acces limitat restricționează privilegiile administrative. Anumite secțiuni ale consolei web vor avea funcționalități reduse."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Navigatorul dvs. va reține nivelul dvs. de acces între sesiuni."
 ],
 "Limited access": [
  null,
  "Acces limitat"
 ],
 "Turn on administrative access": [
  null,
  "Activează accesul de administrator"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ani",
  "$0 de ani"
 ],
 "$0 month": [
  null,
  "$0 lună",
  "$0 luni",
  "$0 de luni"
 ],
 "$0 week": [
  null,
  "$0 săptămână",
  "$0 săptămâni",
  "$0 de săptămâni"
 ],
 "$0 day": [
  null,
  "$0 zi",
  "$0 zile",
  "$0 de zile"
 ],
 "$0 hour": [
  null,
  "$0 oră",
  "$0 ore",
  "$0 de ore"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minute",
  "$0 de minute"
 ],
 "Go to now": [
  null,
  "Mergi la acum"
 ],
 "1 hour": [
  null,
  "1 oră"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 zi"
 ],
 "1 week": [
  null,
  "1 săptămână"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nu s-a putut activa $0 în firewalld"
 ],
 "Visit firewall": [
  null,
  "Accedeți la paravanul de protecție"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adaugă $0"
 ],
 "less than a minute ago": [
  null,
  "acum mai puțin de un minut"
 ],
 "in less than a minute": [
  null,
  "în mai puțin de un minut"
 ],
 "Password is too weak": [
  null,
  "Parola este prea slabă (este ușor de ghicit)"
 ],
 "Excellent password": [
  null,
  "Parolă excelentă"
 ],
 "Password is not acceptable": [
  null,
  "Parola nu este acceptabilă"
 ],
 "Strong password": [
  null,
  "Parolă puternică"
 ],
 "Acceptable password": [
  null,
  "Parolă acceptabilă"
 ],
 "Weak password": [
  null,
  "Parolă slabă (ușor de ghicit)"
 ],
 "Show password": [
  null,
  "Afișează parola"
 ],
 "Hide password": [
  null,
  "Ascunde parola"
 ],
 "password quality": [
  null,
  "calitatea parolei"
 ],
 "Show confirmation password": [
  null,
  "Afișează parola de confirmare"
 ],
 "Hide confirmation password": [
  null,
  "Ascunde parola de confirmare"
 ],
 "Additional packages:": [
  null,
  "Pachete suplimentare:"
 ],
 "Removals:": [
  null,
  "Eliminare:"
 ],
 "Total size: $0": [
  null,
  "Dimensiunea totală: $0"
 ],
 "Install software": [
  null,
  "Instalează software-ul"
 ],
 "$0 will be installed.": [
  null,
  "$0 va fi instalat."
 ],
 "Install": [
  null,
  "Instalează"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Se așteaptă finalizarea altor operații de gestionare a software-ului"
 ],
 "Checking installed software": [
  null,
  "Se verifică software-ul instalat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nu este disponibil din niciun depozit."
 ],
 "Downloading $0": [
  null,
  "Se descarcă $0"
 ],
 "Removing $0": [
  null,
  "Se elimină $0"
 ],
 "Installing $0": [
  null,
  "Se instalează $0"
 ],
 "Unknown host: $0": [
  null,
  "Gazdă necunoscută: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nu se poate efectua autentificarea la $0 folosind autentificarea cu cheie SSH. Vă rugăm să introduceți parola."
 ],
 "SSH key login": [
  null,
  "Autentificare cu cheie SSH"
 ],
 "[no data]": [
  null,
  "[nu există date]"
 ],
 "[binary data]": [
  null,
  "[date binare]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit s-a prăbușit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a raportat codul de eroare $0"
 ],
 "show less": [
  null,
  "afișează mai puțin"
 ],
 "show more": [
  null,
  "afișează mai mult"
 ],
 "Row expansion": [
  null,
  "Extinderea rândului"
 ],
 "Row select": [
  null,
  "Selectare rând"
 ],
 "Ctrl+Insert": [
  null,
  "«Ctrl+Insert»"
 ],
 "Paste": [
  null,
  "Lipește"
 ],
 "Shift+Insert": [
  null,
  "«Shift+Insert»"
 ],
 "Paste error": [
  null,
  "Eroare la lipire"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Navigatorul dvs. nu permite lipirea din meniul contextual. Puteți folosi combinația de taste «Shift+Insert»."
 ],
 "Error during initialization": [
  null,
  "Eroare în timpul inițializării"
 ],
 "Failed": [
  null,
  "Nu a funcționat"
 ],
 "Home": [
  null,
  "Acasă"
 ],
 "Downloads": [
  null,
  "Descărcări"
 ],
 "Not a directory": [
  null,
  "Nu este un director"
 ],
 "All files": [
  null,
  "Toate fișierele"
 ],
 "Recent": [
  null,
  "Recente"
 ],
 "No recent directories": [
  null,
  "Nu există directoare recente"
 ],
 "No recent files": [
  null,
  "Nu există fișiere recente"
 ],
 "Type to filter": [
  null,
  "Tastați pentru a filtra"
 ],
 "File chooser actions": [
  null,
  "Acțiuni ale selectorului de fișiere"
 ],
 "Open in file browser": [
  null,
  "Deschide în exploratorul de fișiere"
 ],
 "Hide hidden files": [
  null,
  "Ascunde elementele ascunse"
 ],
 "Show hidden files": [
  null,
  "Afișează fișierele ascunse"
 ],
 "Filesystem": [
  null,
  "Sistem de fișiere"
 ],
 "Clear filters": [
  null,
  "Șterge filtrele"
 ],
 "Directory is empty": [
  null,
  "Directorul este gol"
 ],
 "Directory has no sub-directories": [
  null,
  "Directorul nu conține subdirectoare"
 ],
 "This directory contains only hidden files": [
  null,
  "Acest director conține doar fișiere ascunse"
 ],
 "No matching results": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Folder": [
  null,
  "Dosar"
 ],
 "File": [
  null,
  "Fișier"
 ],
 "Copy to clipboard": [
  null,
  "Copiază în clipboard"
 ],
 "Automation script": [
  null,
  "Script de automatizare"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Creează un fișier de sarcini nou cu acest conținut."
 ],
 "Ansible roles documentation": [
  null,
  "Documentația privind rolurile Ansible"
 ],
 "Shell script": [
  null,
  "script Shell"
 ],
 "No system modifications": [
  null,
  "Nicio modificare a sistemului"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Utilizatorul conectat nu are permisiunea de a vizualiza modificările aduse sistemului"
 ],
 "Loading system modifications...": [
  null,
  "Se încarcă modificările aduse sistemului..."
 ],
 "View automation script": [
  null,
  "Vizualizează scriptul de automatizare"
 ],
 "Occurrences": [
  null,
  "Apariții"
 ],
 "View all logs": [
  null,
  "Vizualizează toate jurnalele"
 ],
 "Other": [
  null,
  "Alta"
 ],
 "Unknown": [
  null,
  "Necunoscută"
 ],
 "Desktop": [
  null,
  "Calculator de birou"
 ],
 "Low profile desktop": [
  null,
  "Calculator de birou cu profil redus"
 ],
 "Pizza box": [
  null,
  "„Pizza box”"
 ],
 "Mini tower": [
  null,
  "Mini turn"
 ],
 "Tower": [
  null,
  "Turn"
 ],
 "Portable": [
  null,
  "Portabil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispozitiv de buzunar"
 ],
 "Docking station": [
  null,
  "Stație de andocare"
 ],
 "All-in-one": [
  null,
  "Toate într-unul"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Calculator compact"
 ],
 "Lunch box": [
  null,
  "„Lunch box”"
 ],
 "Main server chassis": [
  null,
  "Șasiul serverului principal"
 ],
 "Expansion chassis": [
  null,
  "Șasiu de expansiune"
 ],
 "Sub-Chassis": [
  null,
  "Sub-șasiu"
 ],
 "Bus expansion chassis": [
  null,
  "Șasiu de expansiune de magistrală"
 ],
 "Peripheral chassis": [
  null,
  "Șasiu periferic"
 ],
 "RAID chassis": [
  null,
  "Șasiu RAID"
 ],
 "Rack mount chassis": [
  null,
  "Șasiu de montare în rack"
 ],
 "Sealed-case PC": [
  null,
  "PC cu carcasă sigilată"
 ],
 "Multi-system chassis": [
  null,
  "Șasiu multi-sistem"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avansat"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Servitor blade (lamă)"
 ],
 "Tablet": [
  null,
  "Tabletă"
 ],
 "Convertible": [
  null,
  "Convertibil"
 ],
 "Detachable": [
  null,
  "Detașabil (amovibil)"
 ],
 "IoT gateway": [
  null,
  "Poartă de acces IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrat"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 Gio"
 ],
 "Single rank": [
  null,
  "Rang unic"
 ],
 "Dual rank": [
  null,
  "Rang dual"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Prezent"
 ],
 "Old password not accepted": [
  null,
  "Vechea parolă nu este acceptată"
 ],
 "Failed to change password": [
  null,
  "Schimbarea parolei a eșuat"
 ],
 "New password was not accepted": [
  null,
  "Noua parolă nu a fost acceptată"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "A expirat timpul de așteptare pentru generarea cheii prin ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Nu este o cheie privată validă"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A expirat timpul de așteptare pentru adăugarea prin ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisiuni de fișier nevalide"
 ],
 "Password not accepted": [
  null,
  "Parola nu este acceptată"
 ],
 "Select an option": [
  null,
  "Selectați o opțiune"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 a fost omorât cu semnalul $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 a ieșit cu codul $1"
 ],
 "$0 failed": [
  null,
  "$0 a eșuat"
 ],
 "Your session has been terminated.": [
  null,
  "Sesiunea dumneavoastră a fost încheiată."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesiunea dumneavoastră a expirat. Vă rugăm să vă autentificați din nou."
 ],
 "Not permitted to perform this action.": [
  null,
  "Nu este permisă efectuarea acestei acțiuni."
 ],
 "Login failed": [
  null,
  "Autentificare eșuată"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serverul a refuzat autentificarea prin orice metodă acceptată."
 ],
 "Untrusted host": [
  null,
  "Gazdă nesigură (nu este de încredere)"
 ],
 "Host key is incorrect": [
  null,
  "Cheia gazdei este incorectă"
 ],
 "Internal error": [
  null,
  "Eroare internă"
 ],
 "Connection has timed out.": [
  null,
  "Timpul de conectare a expirat."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nu este instalat în sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Nu se pot transmite datele de autentificare"
 ],
 "Server has closed the connection.": [
  null,
  "Serverul a închis conexiunea."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nu este compatibil cu software-ul din sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nu a putut stabili legătura cu gazda specificată."
 ],
 "Too much data": [
  null,
  "Prea multe date"
 ],
 "$0 is not a directory": [
  null,
  "$0 nu este un director"
 ],
 "$0 does not exist": [
  null,
  "$0 nu există"
 ],
 "Font size": [
  null,
  "Dimensiune font"
 ],
 "Decrease by one": [
  null,
  "Reduce cu unu"
 ],
 "Increase by one": [
  null,
  "Incrementează cu unu"
 ],
 "Appearance": [
  null,
  "Aspect"
 ],
 "Black": [
  null,
  "Negru"
 ],
 "White": [
  null,
  "Alb"
 ],
 "Reset": [
  null,
  "Restabilește"
 ],
 "Unable to open directory": [
  null,
  "Nu se poate deschide directorul"
 ],
 "Running process prevents directory change": [
  null,
  "Procesul care rulează împiedică schimbarea directorului"
 ],
 "Change directory": [
  null,
  "Schimbă directorul"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Schimbarea directorului va opri forțat procesul care rulează în prezent. Procesul poate fi oprit și manual în terminal înainte de a continua."
 ],
 "Terminal not available": [
  null,
  "Terminalul nu este disponibil"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Acest navigator nu are suport pentru WebGL2."
 ],
 "unknown": [
  null,
  "necunoscut"
 ],
 "Shutdown": [
  null,
  "Oprire"
 ],
 "running $0": [
  null,
  "se execută $0"
 ],
 "Current boot": [
  null,
  "Pornirea curentă"
 ],
 "Previous boot": [
  null,
  "Pornirea anterioară"
 ],
 "Last 24 hours": [
  null,
  "Ultimele 24 de ore"
 ],
 "Last 7 days": [
  null,
  "Ultimele 7 zile"
 ],
 "Only emergency": [
  null,
  "Numai în caz de urgență"
 ],
 "Alert and above": [
  null,
  "Alertă și mai sus"
 ],
 "Critical and above": [
  null,
  "Critică și mai sus"
 ],
 "Error and above": [
  null,
  "Eroare și mai sus"
 ],
 "Warning and above": [
  null,
  "Avertisment și mai sus"
 ],
 "Notice and above": [
  null,
  "Notificare și mai sus"
 ],
 "Info and above": [
  null,
  "Informații și mai sus"
 ],
 "Debug and above": [
  null,
  "Depanare și mai sus"
 ],
 "Toggle filters": [
  null,
  "Activează/dezactivează filtrele"
 ],
 "Time": [
  null,
  "Timpul"
 ],
 "Priority": [
  null,
  "Prioritate"
 ],
 "Identifier": [
  null,
  "Identificator"
 ],
 "Filters": [
  null,
  "Filtre"
 ],
 "Pause": [
  null,
  "Pauză"
 ],
 "Resume": [
  null,
  "Reluare"
 ],
 "All": [
  null,
  "Toate"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Specificațiile privind data trebuie să respecte formatul AAAA-LL-ZZ hh:mm:ss. Alternativ, sunt acceptate și expresiile „yesterday” (ieri), „today” (azi) și „tomorrow” (mâine). „now” (acum) se referă la ora curentă. În cele din urmă, se pot specifica ore relative, precedate de „-” sau „+”"
 ],
 "Since": [
  null,
  "De la"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Afișează înregistrările începând cu data specificată sau ulterioare acesteia."
 ],
 "Until": [
  null,
  "Până la"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Afișează înregistrările începând cu data specificată sau anterioare acesteia."
 ],
 "Boot": [
  null,
  "Pornire"
 ],
 "Show messages from a specific boot.": [
  null,
  "Afișează mesajele de la pornirea specificată."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Aceasta va adăuga o potrivire pentru „_BOOT_ID=”. Dacă nu se specifică nimic, vor fi afișate jurnalele pentru pornirea curentă. Dacă ID-ul de pornire este omis, o valoare pozitivă se va utiliza pentru căuta pornirile începând de la începutul jurnalului, iar o valoare egală sau mai mică decât zero va căuta pornirile începând de la sfârșitul jurnalului. Astfel, 1 înseamnă prima pornire găsită în jurnal în ordine cronologică, 2 a doua și așa mai departe; în timp ce -0 este ultima pornire, -1 penultima și așa mai departe."
 ],
 "Unit": [
  null,
  "Unitatea"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Afișează mesajele pentru unitatea systemd specificată."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Aceasta va adăuga o potrivire pentru „_SYSTEMD_UNIT=”, „COREDUMP_UNIT=” și „UNIT=” pentru a găsi toate mesajele posibile pentru unitatea specificată. Se pot include mai multe unități, separate prin virgule."
 ],
 "Free-form search": [
  null,
  "Căutare liberă"
 ],
 "Show messages containing given string.": [
  null,
  "Afișează mesajele care conțin șirul dat."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Se poate filtra orice șir de text din mesajele de jurnal. Șirul poate fi, de asemenea, sub forma unei expresii regulate. De asemenea, se acceptă filtrarea după câmpurile mesajelor de jurnal. Acestea sunt valori separate prin spațiu, sub forma CÂMP=VALOARE, unde „valoare” poate fi o listă de valori posibile separate prin virgule."
 ],
 "journalctl manpage": [
  null,
  "pagina de manual pentru journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "S-a copiat cu succes în clipboard"
 ],
 "Create timer": [
  null,
  "Creează un temporizator"
 ],
 "Edit timer": [
  null,
  "Editează temporarizatorul"
 ],
 "Timer creation failed": [
  null,
  "Crearea temporizatorului a eșuat"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Nu s-au putut obține condițiile de pornire pentru temporizator"
 ],
 "Failed to get the timer command": [
  null,
  "Nu s-a putut obține comanda temporizatorului"
 ],
 "This field cannot be empty": [
  null,
  "Acest câmp nu poate fi gol"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sunt permise doar litere, cifre, : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "Descriere"
 ],
 "Shell command": [
  null,
  "Comandă Shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Această comandă va fi executată de către „/bin/sh”."
 ],
 "Trigger": [
  null,
  "Declanșator"
 ],
 "At specific time": [
  null,
  "La momentul specificat"
 ],
 "After system boot": [
  null,
  "După pornirea sistemului"
 ],
 "Seconds": [
  null,
  "Secunde"
 ],
 "Minutes": [
  null,
  "Minute"
 ],
 "Hours": [
  null,
  "Ore"
 ],
 "Weeks": [
  null,
  "Săptămâni"
 ],
 "Delay must be a number": [
  null,
  "Întârzierea trebuie să fie un număr"
 ],
 "Repeat": [
  null,
  "Repetare"
 ],
 "Don't repeat": [
  null,
  "Nu repeta"
 ],
 "Minutely": [
  null,
  "Minut cu minut"
 ],
 "Hourly": [
  null,
  "La fiecare oră"
 ],
 "Daily": [
  null,
  "Zilnic"
 ],
 "Weekly": [
  null,
  "Săptămânal"
 ],
 "Monthly": [
  null,
  "Lunar"
 ],
 "Yearly": [
  null,
  "Anual"
 ],
 "Run at": [
  null,
  "Se execută la"
 ],
 "At second": [
  null,
  "La fiecare secundă"
 ],
 "At minute": [
  null,
  "La fiecare minut"
 ],
 "Run on": [
  null,
  "Se execută pe"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minutul trebuie să fie un număr cuprins între 0 și 59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Secunda trebuie să fie un număr cuprins între 0 și 59"
 ],
 "Repeat weekly": [
  null,
  "Repetă săptămânal"
 ],
 "Mondays": [
  null,
  "zilele de Luni"
 ],
 "Tuesdays": [
  null,
  "zilele de Marți"
 ],
 "Wednesdays": [
  null,
  "zilele de Miercuri"
 ],
 "Thursdays": [
  null,
  "zilele de Joi"
 ],
 "Fridays": [
  null,
  "zilele de Vineri"
 ],
 "Saturdays": [
  null,
  "zilele de Sâmbătă"
 ],
 "Sundays": [
  null,
  "Duminicile"
 ],
 "Repeat monthly": [
  null,
  "Repetă lunar"
 ],
 "1st": [
  null,
  "1-a"
 ],
 "2nd": [
  null,
  "a 2-a"
 ],
 "3rd": [
  null,
  "a 3-a"
 ],
 "4th": [
  null,
  "a 4-a"
 ],
 "5th": [
  null,
  "a 5-a"
 ],
 "6th": [
  null,
  "a 6-a"
 ],
 "7th": [
  null,
  "a 7-a"
 ],
 "8th": [
  null,
  "a 8-a"
 ],
 "9th": [
  null,
  "a 9-a"
 ],
 "10th": [
  null,
  "a 10-a"
 ],
 "11th": [
  null,
  "a 11-a"
 ],
 "12th": [
  null,
  "a 12-a"
 ],
 "13th": [
  null,
  "a 13-a"
 ],
 "14th": [
  null,
  "a 14-a"
 ],
 "15th": [
  null,
  "a 15-a"
 ],
 "16th": [
  null,
  "a 16-a"
 ],
 "17th": [
  null,
  "a 17-a"
 ],
 "18th": [
  null,
  "a 18-a"
 ],
 "19th": [
  null,
  "a 19-a"
 ],
 "20th": [
  null,
  "a 20-a"
 ],
 "21th": [
  null,
  "a 21-a"
 ],
 "22th": [
  null,
  "a 22-a"
 ],
 "23th": [
  null,
  "a 23-a"
 ],
 "24th": [
  null,
  "a 24-a"
 ],
 "25th": [
  null,
  "a 25-a"
 ],
 "26th": [
  null,
  "a 26-a"
 ],
 "27th": [
  null,
  "a 27-a"
 ],
 "28th": [
  null,
  "a 28-a"
 ],
 "29th": [
  null,
  "a 29-a"
 ],
 "30th": [
  null,
  "a 30-a"
 ],
 "31st": [
  null,
  "a 31-a"
 ],
 "Save": [
  null,
  "Salvează"
 ],
 "Unclean shutdown": [
  null,
  "Oprire necorespunzătoare (incorectă)"
 ],
 "View logs": [
  null,
  "Vizualizează jurnalele"
 ],
 "Dismiss": [
  null,
  "Revocare"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Oprire programată la $0"
 ],
 "Cancel poweroff": [
  null,
  "Anulează oprirea"
 ],
 "Scheduled reboot at $0": [
  null,
  "Repornire programată la $0"
 ],
 "Cancel reboot": [
  null,
  "Anulează repornirea"
 ],
 "edit": [
  null,
  "editează"
 ],
 "Set hostname": [
  null,
  "Stabilește numele de gazdă"
 ],
 "Configuration": [
  null,
  "Configurare"
 ],
 "Hostname": [
  null,
  "Nume-gazdă"
 ],
 "System time": [
  null,
  "Ora sistemului"
 ],
 "Domain": [
  null,
  "Domeniu"
 ],
 "Performance profile": [
  null,
  "Profilul de performanță"
 ],
 "Secure shell keys": [
  null,
  "Chei Secure Shell"
 ],
 "Show fingerprints": [
  null,
  "Afișează amprentele digitale"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nu s-au putut lista cheile de gazdă SSH: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Încărcarea cheilor SSH a eșuat"
 ],
 "Error message": [
  null,
  "Mesaj de eroare"
 ],
 "Loading keys...": [
  null,
  "Se încarcă cheile..."
 ],
 "No host keys found.": [
  null,
  "Nicio cheie de gazdă găsită."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Amprentele digitale ale cheilor SSH ale mașinii"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Numele real al gazdei trebuie să fie de 64 caractere sau mai puțin"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Numele real al gazdei poate conține doar litere mici, cifre, liniuțe și puncte (cu subdomenii populate)"
 ],
 "Change host name": [
  null,
  "Schimbă numele gazdei"
 ],
 "Pretty host name": [
  null,
  "Nume de gazdă drăguț"
 ],
 "Real host name": [
  null,
  "Numele real al gazdei"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Utilizatorul $0 nu are permisiunea de a modifica politicile criptografice"
 ],
 "Cryptographic policy": [
  null,
  "Politica criptografică"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Configurări recomandate și sigure pentru modelele actuale de atac."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "IMPLICITĂ cu verificarea semnăturii SHA-1 permisă."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "O interoperabilitate sporită, în detrimentul unei suprafețe de atac mai extinse."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "ÎNVECHITĂ cu interoperabilitatea Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Utilizați numai algoritmi aprobați și autorizați atunci când porniți sistemul în modul FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS, cu restricții suplimentare conform Criteriilor Comune."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protejează împotriva atacurilor anticipate pe termen scurt, în detrimentul interoperabilității."
 ],
 "Custom cryptographic policy": [
  null,
  "Politica criptografică personalizată"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Politicile criptografice reprezintă o componentă a sistemului care configurează subsistemele criptografice de bază, acoperind protocoalele TLS, IPSec, SSH, DNSSec și Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Modifică politica criptografică"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Se aplică noua politică... Acest proces poate dura câteva minute."
 ],
 "Reapply and reboot": [
  null,
  "Reaplicați și reporniți"
 ],
 "Apply and reboot": [
  null,
  "Aplică și repornește"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS nu este activat corespunzător"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Politica criptografică este incoerentă"
 ],
 "Review cryptographic policy": [
  null,
  "Revizuirea politicii criptografice"
 ],
 "System information": [
  null,
  "Informații despre sistem"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Etichetă de activ(inventar)"
 ],
 "Machine ID": [
  null,
  "Identificatorul mașinii"
 ],
 "Up since": [
  null,
  "În funcțiune de"
 ],
 "View hardware details": [
  null,
  "Vizualizează detaliile hardware-ului"
 ],
 "Last successful login:": [
  null,
  "Ultima autentificare reușită:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 încercare de autentificare eșuată",
  "$0 încercări de autentificare eșuate",
  "$0 de încercări de autentificare eșuate"
 ],
 "View login history": [
  null,
  "Vizualizează istoricul autentificărilor"
 ],
 "recommended": [
  null,
  "recomandat"
 ],
 "inconsistent": [
  null,
  "inconsistent"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Alăturarea la un domeniu necesită instalarea pachetului realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nu se poate realiza aderarea la un domeniu deoarece realmd nu este disponibil pe acest sistem"
 ],
 "Joining this domain is not supported": [
  null,
  "Alăturarea la acest domeniu nu este acceptată"
 ],
 "Login format": [
  null,
  "Format de autentificare"
 ],
 "Server software": [
  null,
  "Software de server"
 ],
 "Client software": [
  null,
  "Software client"
 ],
 "Leave domain": [
  null,
  "Părăsiți domeniul"
 ],
 "Leave $0": [
  null,
  "Părăsiți $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "După ieșirea din domeniu, numai utilizatorii cu date de autentificare locale se vor putea conecta la această mașină. Acest lucru poate afecta și alte servicii, întrucât configurările de rezoluție DNS și lista autorităților de certificare de încredere se pot modifica."
 ],
 "Validating address": [
  null,
  "Se validează adresa"
 ],
 "Contacted domain": [
  null,
  "Domeniu contactat"
 ],
 "Domain could not be contacted": [
  null,
  "Domeniul nu a putut fi contactat"
 ],
 "Domain is not supported": [
  null,
  "Domeniul nu este acceptat"
 ],
 "Domain address": [
  null,
  "Adresa domeniului"
 ],
 "Domain administrator name": [
  null,
  "Numele administratorului domeniului"
 ],
 "Domain administrator password": [
  null,
  "Parola administratorului domeniului"
 ],
 "Joining": [
  null,
  "Se alăturează"
 ],
 "Join": [
  null,
  "Alătură-te"
 ],
 "This may take a while": [
  null,
  "Această operație poate dura ceva timp"
 ],
 "Not permitted to configure realms": [
  null,
  "Nu este permisă configurarea domeniilor (realms)"
 ],
 "Join domain": [
  null,
  "Alătură-te domeniului"
 ],
 "Install realmd support": [
  null,
  "Instalează suportul pentru realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disc prezintă probleme",
  "$0 discuri prezintă probleme",
  "$0 de discuri prezintă probleme"
 ],
 "Connected to Insights": [
  null,
  "Conectat la Insights"
 ],
 "Not connected to Insights": [
  null,
  "Nu este conectat la Insights"
 ],
 "Health": [
  null,
  "Sănătate"
 ],
 "of $0 CPU": [
  null,
  "din $0 CPU",
  "din $0 CPU-uri",
  "din $0 de CPU-uri"
 ],
 "Usage": [
  null,
  "Utilizare"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memorie"
 ],
 "View metrics and history": [
  null,
  "Vizualizează măsurători și istoric"
 ],
 "Tuned is not available": [
  null,
  "Tuned nu este disponibil"
 ],
 "Tuned is not running": [
  null,
  "Tuned nu rulează"
 ],
 "Tuned is off": [
  null,
  "Tuned este dezactivat"
 ],
 "This system is using the recommended profile": [
  null,
  "Acest sistem utilizează profilul recomandat"
 ],
 "This system is using a custom profile": [
  null,
  "Acest sistem utilizează un profil personalizat"
 ],
 "none": [
  null,
  "niciunul"
 ],
 "Communication with tuned has failed": [
  null,
  "Comunicarea cu „tuned” a eșuat"
 ],
 "Failed to enable tuned": [
  null,
  "Nu s-a putut activa „tuned”"
 ],
 "Failed to disable tuned": [
  null,
  "Nu s-a putut dezactiva „tuned”"
 ],
 "Failed to disable tuned profile": [
  null,
  "Nu s-a putut dezactiva profilul „tuned”"
 ],
 "Failed to switch profile": [
  null,
  "Schimbarea profilului a eșuat"
 ],
 "None": [
  null,
  "Niciuna"
 ],
 "Disable tuned": [
  null,
  "Dezactivează „tuned”"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned a eșuat la pornire"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned este un serviciu care monitorizează sistemul și optimizează performanța în funcție de anumite sarcini. Elementul central al Tuned îl constituie profilurile, care configurează sistemul pentru diferite scenarii de utilizare."
 ],
 "Change performance profile": [
  null,
  "Modifică profilul de performanță"
 ],
 "Change profile": [
  null,
  "Modifică profilul"
 ],
 "Edit /etc/motd": [
  null,
  "Editează „/etc/motd”"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nu s-au putut salva modificările din „/etc/motd”"
 ],
 "Save changes": [
  null,
  "Salvează modificările"
 ],
 "Edit motd": [
  null,
  "Editează motd"
 ],
 "Stub": [
  null,
  "Ciot (stub)"
 ],
 "Not found": [
  null,
  "Nu s-a găsit"
 ],
 "Bad setting": [
  null,
  "Configurare incorectă"
 ],
 "Error": [
  null,
  "Eroare"
 ],
 "Merged": [
  null,
  "Fuzionat"
 ],
 "Running": [
  null,
  "În execuție"
 ],
 "Reloading": [
  null,
  "Reîncărcarea"
 ],
 "Not running": [
  null,
  "Nu rulează"
 ],
 "Failed to start": [
  null,
  "A eșuat la pornire"
 ],
 "Maintenance": [
  null,
  "Întreținere"
 ],
 "Enabled": [
  null,
  "Activat"
 ],
 "Disabled": [
  null,
  "Dezactivat"
 ],
 "Linked": [
  null,
  "Vinculat"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Mascat"
 ],
 "Static": [
  null,
  "Statică"
 ],
 "Invalid": [
  null,
  "Nevalid"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Generated": [
  null,
  "Generat"
 ],
 "Transient": [
  null,
  "Tranzitoriu"
 ],
 "Bad": [
  null,
  "Greșit"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Abonarea la semnalele systemd a eșuat: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Conectarea la dbus a eșuat: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Listarea unităților a eșuat: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 serviciu a eșuat",
  "$0 servicii au eșuat",
  "$0 se servicii au eșuat"
 ],
 "Loading of units failed": [
  null,
  "Încărcarea unităților a eșuat"
 ],
 "Loading...": [
  null,
  "Se încarcă…"
 ],
 "Listing units": [
  null,
  "Se listează unitățile"
 ],
 "Filter by name or description": [
  null,
  "Filtrează după nume sau descriere"
 ],
 "Active state": [
  null,
  "Stare activă"
 ],
 "File state": [
  null,
  "Starea fișierului"
 ],
 "$0 filters applied": [
  null,
  "$0 filtre aplicate"
 ],
 "User": [
  null,
  "Utilizator"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Utilizatorul $0 nu are permisiunea de a modifica măsurile de securitate ale CPU-ului"
 ],
 "Mitigations": [
  null,
  "Măsuri de atenuare"
 ],
 "Version": [
  null,
  "Versiunea"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Versiunea BIOS-ului"
 ],
 "BIOS date": [
  null,
  "Data BIOS-ului"
 ],
 "CPU security": [
  null,
  "Securitatea CPU-ului"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Dezactivează multithreading-ul simultan"
 ],
 "Read more...": [
  null,
  "Citește mai mult..."
 ],
 "Save and reboot": [
  null,
  "Salvează și repornește"
 ],
 "CPU security toggles": [
  null,
  "Opțiuni de securitate pentru CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Soluțiile alternative bazate pe software contribuie la prevenirea problemelor de securitate legate de procesor. Aceste măsuri de reducere a riscurilor au ca efect secundar scăderea performanței. Modificați acești parametri pe propria răspundere."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Clasa"
 ],
 "Vendor": [
  null,
  "Fabricant"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Tehnologia memoriei"
 ],
 "Size": [
  null,
  "Dimensiune"
 ],
 "State": [
  null,
  "Stare"
 ],
 "Rank": [
  null,
  "Poziție"
 ],
 "Speed": [
  null,
  "Viteză"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Vizualizarea informațiilor despre memorie necesită drepturi de administrator."
 ],
 "Overview": [
  null,
  "Vedere de ansamblu"
 ],
 "Failed to fetch logs": [
  null,
  "Nu s-au putut prelua jurnalele"
 ],
 "Clear all filters": [
  null,
  "Șterge toate filtrele"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nu se pot găsi jurnale folosind combinația actuală de filtre."
 ],
 "No logs found": [
  null,
  "Nu s-au găsit jurnale"
 ],
 "Load earlier entries": [
  null,
  "Încarcă intrările anterioare"
 ],
 "You may try to load older entries.": [
  null,
  "Puteți încerca să încărcați înregistrările mai vechi."
 ],
 "Allow running (unmask)": [
  null,
  "Permite executarea (unmask)"
 ],
 "Reload": [
  null,
  "Reîncărcare"
 ],
 "Restart": [
  null,
  "Repornește"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Start": [
  null,
  "Pornire"
 ],
 "Delete": [
  null,
  "Șterge"
 ],
 "Clear 'Failed to start'": [
  null,
  "Curățarea „A eșuat la pornire”"
 ],
 "Mask service": [
  null,
  "Mascare serviciu"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Mascarea serviciului împiedică rularea tuturor unităților dependente. Acest lucru poate avea consecințe mai grave decât se anticipa. Vă rugăm să confirmați că doriți să mascați această unitate."
 ],
 "Disallow running (mask)": [
  null,
  "Interzice executarea (mask)"
 ],
 "Unpin unit": [
  null,
  "Eliberează (unpin) unitatea"
 ],
 "Pin unit": [
  null,
  "Fixează unitatea"
 ],
 "Additional actions": [
  null,
  "Acțiuni suplimentare"
 ],
 "Note": [
  null,
  "Notă"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Această unitate nu este concepută pentru a fi activată în mod explicit."
 ],
 "Forbidden from running": [
  null,
  "Interzis să fie executat"
 ],
 "Start service": [
  null,
  "Pornire serviciu"
 ],
 "Active since ": [
  null,
  "Activ din "
 ],
 "Required by ": [
  null,
  "Solicitat de "
 ],
 "Read-only": [
  null,
  "Numai-citire"
 ],
 "Requires administration access to edit": [
  null,
  "Necesită acces de administrator pentru a edita"
 ],
 "Automatically starts": [
  null,
  "Pornește automat"
 ],
 "Updating status...": [
  null,
  "Se actualizează starea..."
 ],
 "Stop and disable": [
  null,
  "Oprește și dezactivează"
 ],
 "Start and enable": [
  null,
  "Pornește și activează"
 ],
 "Failed to load unit": [
  null,
  "Nu s-a putut încărca unitatea"
 ],
 "View all services": [
  null,
  "Vezi toate serviciile"
 ],
 "Triggers": [
  null,
  "Declanșatori"
 ],
 "Triggered by": [
  null,
  "Declanșat de"
 ],
 "Requires": [
  null,
  "Necesită"
 ],
 "Requisite": [
  null,
  "Necesar"
 ],
 "Wants": [
  null,
  "Cerut"
 ],
 "Binds to": [
  null,
  "Se leagă de"
 ],
 "Part of": [
  null,
  "Parte din"
 ],
 "Required by": [
  null,
  "Solicitat de"
 ],
 "Requisite of": [
  null,
  "Cerință a"
 ],
 "Wanted by": [
  null,
  "Căutat de"
 ],
 "Bound by": [
  null,
  "Legat de"
 ],
 "Consists of": [
  null,
  "Constă din"
 ],
 "Conflicts": [
  null,
  "Conflicte"
 ],
 "Conflicted by": [
  null,
  "În conflict cu"
 ],
 "Before": [
  null,
  "Înainte"
 ],
 "After": [
  null,
  "După"
 ],
 "On failure": [
  null,
  "În caz de eșec"
 ],
 "Propagates reload to": [
  null,
  "Propagă reîncărcarea la"
 ],
 "Reload propagated from": [
  null,
  "Reîncărcare propagată din"
 ],
 "Joins namespace of": [
  null,
  "Se alătură spațiului de nume al"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condiția $0=$1 nu a fost îndeplinită"
 ],
 "Deletion will remove the following files:": [
  null,
  "Ștergerea va elimina următoarele fișiere:"
 ],
 "Pinned unit": [
  null,
  "Unitate fixată"
 ],
 "Status": [
  null,
  "Starea"
 ],
 "Path": [
  null,
  "Ruta"
 ],
 "Listen": [
  null,
  "Ascultă"
 ],
 "Container": [
  null,
  "Container"
 ],
 "View Podman container": [
  null,
  "Vizualizează containerul Podman"
 ],
 "Condition failed": [
  null,
  "Condiție neîndeplinită"
 ],
 "Show more relationships": [
  null,
  "Afișează mai multe relații"
 ],
 "Show relationships": [
  null,
  "Afișează relațiile"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmă ștergerea lui $0"
 ],
 "Timer deletion failed": [
  null,
  "Ștergerea temporizatorului a eșuat"
 ],
 "Targets": [
  null,
  "Ținte"
 ],
 "Sockets": [
  null,
  "Socluri"
 ],
 "Timers": [
  null,
  "Temporizatoare"
 ],
 "Paths": [
  null,
  "Rute"
 ],
 "Go to $0": [
  null,
  "Mergi la $0"
 ],
 "Journal entry not found": [
  null,
  "Intrare de jurnal negăsită"
 ],
 "Journal entry": [
  null,
  "Intrare în jurnal"
 ],
 "Entry at $0": [
  null,
  "Intrare la $0"
 ],
 "Logs": [
  null,
  "Jurnale"
 ],
 "Loading unit failed": [
  null,
  "Încărcarea unității a eșuat"
 ],
 "Service logs": [
  null,
  "Jurnale de serviciu"
 ],
 "No log entries": [
  null,
  "Nu există înregistrări în jurnal"
 ],
 "Systemd units": [
  null,
  "Unități systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Nu există rezultate care să corespundă criteriilor de filtrare. Ștergeți toate filtrele pentru a afișa rezultatele."
 ],
 "Does not automatically start": [
  null,
  "Nu pornește automat"
 ],
 "Cannot be enabled": [
  null,
  "Nu poate fi activat"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Consola web rulează în modul de acces limitat."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web pentru servere Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit este un gestionator de servere care facilitează administrarea serverelor Linux prin intermediul unui navigator web. Trecerea de la terminal la instrumentul web și invers nu reprezintă nicio problemă. Un serviciu pornit prin Cockpit poate fi oprit prin terminal. La fel, dacă apare o eroare în terminal, aceasta poate fi vizualizată în interfața de jurnal a Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit este ideal pentru administratorii de sistem începători, permițându-le să efectueze cu ușurință sarcini simple, precum administrarea spațiului de stocare, verificarea jurnalelor și pornirea sau oprirea serviciilor. Puteți monitoriza și administra mai multe servere în același timp. Trebuie doar să le adăugați cu un singur clic, iar sistemul se va ocupa de restul."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "După ce Cockpit este instalat, activați-l cu comanda «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurarea Cockpit a NetworkManager și Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Acest instrument gestionează rețelele, cum ar fi legăturile, punțile, grupurile, rețelele VLAN și paravanele de protecție, folosind NetworkManager și Firewalld. NetworkManager nu este compatibil cu scripturile implicite systemd-networkd din Ubuntu și ifupdown din Debian."
 ],
 "Manage storage": [
  null,
  "Gestionează spațiul de stocare"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Acest instrument gestionează spațiul de stocare local, cum ar fi sistemele de fișiere, grupurile de volume LVM2 și montările NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Colectarea și organizarea datelor de diagnosticare și asistență"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Acest instrument generează un fișier de arhivă care conține informații de configurare și diagnosticare din sistemul în funcțiune. Fișierul de arhivă poate fi stocat local sau centralizat în scopuri de înregistrare sau monitorizare sau poate fi trimis reprezentanților serviciului de asistență tehnică, dezvoltatorilor sau administratorilor de sistem pentru a facilita identificarea problemelor tehnice și depanarea."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurarea și soluționarea problemelor în Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Acest instrument configurează politica SELinux și poate fi de ajutor în înțelegerea și rezolvarea încălcărilor politicii."
 ],
 "Collect kernel crash dumps": [
  null,
  "Colectarea fișierelor cu conținutul memoriei în momentul apariției unei erori fatale ale sistemului de către nucleu"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Acest instrument configurează sistemul pentru a genera fișiere cu conținutul memoriei din momentul apariției unei erori fatale de către nucleui. Acesta acceptă destinațiile de salvare „local” (pe disc), „ssh” și „nfs”."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrare cu ajutorul consolei web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Este necesară autentificarea pentru a efectua operații cu drepturi speciale în consola web Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "de la $0 la $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "din $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "pe $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domeniu"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Alătură-te unui domeniu"
 ]
});
