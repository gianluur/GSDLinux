cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ia",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "Installation de $0"
 ],
 "$0 installer": [
  null,
  "Installator $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 es requirite, ma solmente $1 es disponibile."
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 essera delite"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Le systema de files “$0” non pote esser sur un dispositivo de bloco cryptate"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "“$0” debe esser sur un dispositivo formatate a “$1”"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Un conto de usator standard con accesso administrative pro facer cambiamentos a tote le systema."
 ],
 "About": [
  null,
  "A proposito"
 ],
 "Account": [
  null,
  "Conto"
 ],
 "Actions": [
  null,
  "Actiones"
 ],
 "Add another server...": [
  null,
  "Adder altere servitor..."
 ],
 "Add mount": [
  null,
  "Adder montage"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "Additional languages": [
  null,
  "Linguas additional"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Tote le cambiamentos facite in le editor de immagazinage prendera effecto immediatemente."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Tote le dispositivos usante iste phrase de contrasigno essera disblocate"
 ],
 "Anaconda Web UI": [
  null,
  "Interfacie web de Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Pagina del projecto Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Applicar le assignation del puncto de montage e installar"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  ""
 ],
 "Automatic log file upload": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Definir automaticamente data e hora, usante servitores de tempore"
 ],
 "Automatically set timezone": [
  null,
  "Defnir automaticamente le fuso horari"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Spatio libere disponibile: $0. Le installation require: $1."
 ],
 "Back": [
  null,
  "Retro"
 ],
 "Base environment": [
  null,
  "Ambiente basic"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "Cancellar"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change destination": [
  null,
  "Cambiar destination"
 ],
 "Change hostname": [
  null,
  "Cambiar nomine de hospite"
 ],
 "Change partition layout": [
  null,
  "Cambiar disposition del partition"
 ],
 "Change system keyboard layout": [
  null,
  "Cambiar disposition de claviero de systema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Le cambimentos facite hic afficera immediatemente le systema. Non se pote 'disfacer'."
 ],
 "Checking storage configuration": [
  null,
  "Verification del configuration de immagazinage"
 ],
 "Clear search": [
  null,
  "Rader recerca"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Clauder"
 ],
 "Close storage editor": [
  null,
  "Clauder editor de immagazinage"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Le immagazinage de Cockpit non forni le phrase de contrasigno pro disblocar le dispositivo cryptate."
 ],
 "Completed": [
  null,
  "Completate"
 ],
 "Configure NTP servers": [
  null,
  "Configurar servitores NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurar servitores NTP personalisate"
 ],
 "Configure storage": [
  null,
  "Configurar immagazinage"
 ],
 "Configure storage again": [
  null,
  "Reconfigurar immagazinage"
 ],
 "Confirm passphrase": [
  null,
  "Confirmar phrase de contrasigno"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Continue installation": [
  null,
  "Continuar installation"
 ],
 "Continue with installation": [
  null,
  "Continuar con le installation"
 ],
 "Create Account": [
  null,
  "Crear conto"
 ],
 "Create account": [
  null,
  "Crear conto"
 ],
 "Currently installed: $0": [
  null,
  "Actualmente installate: $0"
 ],
 "Custom": [
  null,
  "Personalisate"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data e hora"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  ""
 ],
 "Description": [
  null,
  "Description"
 ],
 "Destination": [
  null,
  "Destination"
 ],
 "Destination is encrypted": [
  null,
  "Le destination es cryptate"
 ],
 "Detected valid storage layout:": [
  null,
  "Disposition de immagazinage valide detegite:"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Duplicate device.": [
  null,
  "Dispositivo duplicate."
 ],
 "Duplicate mount point.": [
  null,
  "Puncto de montage duplicate."
 ],
 "Enable root account": [
  null,
  "Habilitar conto de superusator"
 ],
 "Encrypt my data": [
  null,
  "Cryptar mi datos"
 ],
 "Encrypted": [
  null,
  "Cryptate"
 ],
 "Encryption": [
  null,
  "Cryptation"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Rader datos e installar"
 ],
 "Error details": [
  null,
  "Detalios del error"
 ],
 "Exit to live desktop": [
  null,
  "Exir al scriptorio live"
 ],
 "Extended partition": [
  null,
  "Partition extendite"
 ],
 "Failed to save layouts": [
  null,
  "Impossibile de salvar le dispositiones"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux require al minus $0 de spatio in le disco."
 ],
 "Finalization": [
  null,
  "Completamento"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalisar: Le configuration de systema es completate. Le finalisation del installation pote prender alicun momentos."
 ],
 "Find layout": [
  null,
  "Cercar disposition"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Nomine complete"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Le nomine complete non pote continer characteres de duo punctos"
 ],
 "Helper text": [
  null,
  "Texto de adjuta"
 ],
 "Hide API key": [
  null,
  "Celar clave API"
 ],
 "Hide confirmed password": [
  null,
  "Celar contrasigno confirmate"
 ],
 "Hide passphrase": [
  null,
  "Celar phase de contrasigno"
 ],
 "Hide password": [
  null,
  "Celar contrasigno"
 ],
 "Hostname": [
  null,
  "Nomine de hospite"
 ],
 "How would you like to install?": [
  null,
  "Como placerea tu installar?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "",
  ""
 ],
 "I understand that some existing data will be erased": [
  null,
  ""
 ],
 "I understand that some partitions will be modified": [
  null,
  ""
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  ""
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  ""
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  ""
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "In progresso"
 ],
 "Initializing...": [
  null,
  "Initialisante..."
 ],
 "Install": [
  null,
  "Installar"
 ],
 "Installation failed": [
  null,
  "Installation fallite"
 ],
 "Installation method": [
  null,
  "Methodo de installation"
 ],
 "Installation of the system failed": [
  null,
  "Installation del systema fallite"
 ],
 "Installation of the system failed: $0": [
  null,
  "Installation del systema fallite: $0"
 ],
 "Installation type": [
  null,
  "Typo de installation"
 ],
 "Installing": [
  null,
  "Installante"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  "Nomine de hospite non valide"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  ""
 ],
 "Keyboard": [
  null,
  ""
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  "Lingua"
 ],
 "Launch storage editor": [
  null,
  "Lancear editor de immagazinage"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Localisation"
 ],
 "Locked devices": [
  null,
  "Dispositivos blocate"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "Configuration manual de disco"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuration manual de disco: Mappamento de puncto de montage"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "May need more free space": [
  null,
  "Pote necessitar plus spatio libere"
 ],
 "Medium": [
  null,
  "Medio"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  ""
 ],
 "Mount point": [
  null,
  "Puncto de montage"
 ],
 "Mount point assignment": [
  null,
  "Assignation de puncto de montamento"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "Debe esser al minus $0 characteres"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Servitores NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nomine"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Rete"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rete non disponibile. Configura le rete in le menu del barra superior pro signalar le problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rete non disponibile. Configura le rete pro signalar le problema."
 ],
 "Next": [
  null,
  "Sequente"
 ],
 "No devices": [
  null,
  "Nulle dispositivos"
 ],
 "No disks available": [
  null,
  "Necun disco disponibile"
 ],
 "No disks selected": [
  null,
  "Nulle discos seligite"
 ],
 "No layouts selected yet": [
  null,
  "Necun dispositiones seligite ancora"
 ],
 "No results found": [
  null,
  "Nulle resultatos trovate"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "Il non ha sufficiente spatio libere"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Il non ha sufficiente spatio libere sur le discos seligite."
 ],
 "Not enough space on selected disks.": [
  null,
  "Il non ha sufficiente spatio sur le discos seligite."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  ""
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Systema operative"
 ],
 "Options": [
  null,
  "Optiones"
 ],
 "Other keyboards": [
  null,
  "Altere clavieros"
 ],
 "Partitions (advanced)": [
  null,
  "Partitiones (avantiate)"
 ],
 "Passphrase": [
  null,
  "Phrase de contrasigno"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Le phrase de contrasigno non coincideva a ulle dispositivo blocate"
 ],
 "Passphrases must match": [
  null,
  "Phrase de contrasigno debe coincider"
 ],
 "Pending": [
  null,
  "Pendente"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "Selige al minus un disco pro continuar"
 ],
 "Pool": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Actionate per Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-lanceamento"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Proceder con le installation"
 ],
 "Quit": [
  null,
  "Quitar"
 ],
 "Quit installer?": [
  null,
  "Quitar le installator?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Lectura del information re le systema operative falleva."
 ],
 "Reading information about the computer failed.": [
  null,
  ""
 ],
 "Reading installer configuration failed.": [
  null,
  "Lectura del configuration del installator fallite."
 ],
 "Reading installer version information failed.": [
  null,
  "Lectura del information del version del installator fallite."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Real hostname must be 64 characters or less": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reinitiar"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Reboot system?": [
  null,
  "Reinitiar le systema?"
 ],
 "Reclaim additional space": [
  null,
  "Recuperar spatio additional"
 ],
 "Reclaim space": [
  null,
  "Recuperar spatio"
 ],
 "Reclaim space (required)": [
  null,
  "Recuperar spatio (requirite)"
 ],
 "Recommended": [
  null,
  "Recommendate"
 ],
 "Recommended partitions:": [
  null,
  "Partitiones recommendate:"
 ],
 "Reformat": [
  null,
  "Reformatar"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstallar Fedora"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Remover tote le partitiones sur le dispositivos seligite, includente le systemas operative existente."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Remove o redimensiona le systemas de files existente pro liberar spatio pro le installation."
 ],
 "Remove server": [
  null,
  "Remover servitor"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  "Signalar problema"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Signalar un problema"
 ],
 "Required": [
  null,
  "Requirite"
 ],
 "Requirements": [
  null,
  "Requisitos"
 ],
 "Rescan devices": [
  null,
  "Rescannar dispositivos"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Falleva le rescannamento de discos."
 ],
 "Resize": [
  null,
  ""
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Retornar a installation"
 ],
 "Return to storage editor": [
  null,
  "Retornar a editor de immagazinage"
 ],
 "Review and install": [
  null,
  "Revide e installa"
 ],
 "Root account is enabled": [
  null,
  "Le conto de superusator es activate"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Le conto de superusator es activate, ma necun conto de usator ha essite configurate"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scanna le codice QR con tu telephono o visita:"
 ],
 "Search for a language": [
  null,
  "Cerca un lingua"
 ],
 "Search keyboard layout": [
  null,
  "Cerca un disposition de claviero"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  ""
 ],
 "Select": [
  null,
  "Seliger"
 ],
 "Select a device": [
  null,
  "Selige un dispositivo"
 ],
 "Select city": [
  null,
  "Selige un citate"
 ],
 "Select destination": [
  null,
  "Selige destination"
 ],
 "Select region": [
  null,
  "Selige region"
 ],
 "Selected (top = current)": [
  null,
  "Seligite (in alto = actual)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  ""
 ],
 "Send us feedback on your installation": [
  null,
  "Invia nos tu commentario sur tu installation"
 ],
 "Server": [
  null,
  "Servitor"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "Definir nomine de hospite personalisate"
 ],
 "Share disk with other operating systems": [
  null,
  ""
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Show AM/PM": [
  null,
  "Monstrar AM/PM"
 ],
 "Show confirmed password": [
  null,
  "Monstrar contrasigno confirmate"
 ],
 "Show passphrase": [
  null,
  "Monstrar phrase de contrasigno"
 ],
 "Show password": [
  null,
  "Monstrar contrasigno"
 ],
 "Size": [
  null,
  "Dimension"
 ],
 "Software installation": [
  null,
  "Installation de programma"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  ""
 ],
 "Software selection": [
  null,
  "Selection de software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  ""
 ],
 "Space": [
  null,
  "Spatio"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Immagazinage"
 ],
 "Storage configuration": [
  null,
  "Configuration de immagazinage"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  ""
 ],
 "Storage editor": [
  null,
  "Editor de immagazinage"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Immagazinage es basate sur le configuration ab “Modificar immagazinage”."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Le plugin de immagazinage falleva"
 ],
 "Storage requirements not met": [
  null,
  ""
 ],
 "Strong": [
  null,
  "Forte"
 ],
 "Successfully installed": [
  null,
  "Installate con successo"
 ],
 "Successfully unlocked $0.": [
  null,
  "Disblocate $0 con successo."
 ],
 "Suggested keyboards": [
  null,
  "Clavieros suggerite"
 ],
 "Suggested languages": [
  null,
  "Linguas suggerite"
 ],
 "System": [
  null,
  "Systema"
 ],
 "System configuration": [
  null,
  "Configuration de systema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  ""
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  ""
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This is unstable, pre-release software": [
  null,
  "Iste programma es preliminar e instabile"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "Isto pote prender un momento"
 ],
 "This will take a few moments": [
  null,
  "Isto prendera alicun momentos"
 ],
 "Time": [
  null,
  ""
 ],
 "Timezone": [
  null,
  "Fuso horari"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  ""
 ],
 "To continue, select the devices to install to.": [
  null,
  "Pro continuar, selige le dispositivos pro le installation."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Pro usar iste option, redimensiona o remove partitiones existente pro liberar al minus $0."
 ],
 "Type": [
  null,
  "Typo"
 ],
 "Unable to schedule deletion of $0": [
  null,
  ""
 ],
 "Unable to schedule resizing of $0": [
  null,
  ""
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "Disblocar"
 ],
 "Unlock encrypted devices": [
  null,
  "Disblocar dispositivos cryptate"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "Use configured storage": [
  null,
  "Usar immagazinage configurate"
 ],
 "Use entire disk": [
  null,
  "Usar tote le disco"
 ],
 "Use free space": [
  null,
  "Usar le spatio libere"
 ],
 "Use local account": [
  null,
  "Usar conto local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  ""
 ],
 "User creation": [
  null,
  "Creation de usator"
 ],
 "User name": [
  null,
  "Nomine de usator"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  ""
 ],
 "User name must not be a reserved word": [
  null,
  "Le nomine de usator non debe esser un parola reservate"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Le nomines de usator debe esser plus curte que 33 characteres"
 ],
 "Weak": [
  null,
  "Debile"
 ],
 "Welcome": [
  null,
  "Benvenite"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Benvenite a Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Benvenite. Vamos installar $0 ora."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  ""
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  ""
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "Tu progresso non essera salvate."
 ],
 "completed step": [
  null,
  "Passo completate"
 ],
 "current step": [
  null,
  "passo actual"
 ],
 "delete": [
  null,
  "supprimer"
 ],
 "edit": [
  null,
  "modificar"
 ],
 "encrypt": [
  null,
  "cryptar"
 ],
 "encrypted": [
  null,
  "cryptate"
 ],
 "extended partition": [
  null,
  "partition extendite"
 ],
 "format as $0": [
  null,
  "formatar como $0"
 ],
 "here": [
  null,
  "hic"
 ],
 "incomplete": [
  null,
  "incomplete"
 ],
 "mount": [
  null,
  "montar"
 ],
 "pending step": [
  null,
  "passo pendente"
 ],
 "report the issue manually": [
  null,
  "signalar le incidente manualmente"
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink": [
  null,
  "Reducer"
 ],
 "shrink to $0": [
  null,
  ""
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "disfacer"
 ]
});
