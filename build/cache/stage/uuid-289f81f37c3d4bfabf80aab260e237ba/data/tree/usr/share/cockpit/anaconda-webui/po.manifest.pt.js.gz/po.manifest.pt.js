cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
