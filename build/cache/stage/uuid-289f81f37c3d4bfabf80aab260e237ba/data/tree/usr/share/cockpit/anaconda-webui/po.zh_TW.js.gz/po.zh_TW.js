cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 個錯誤"
 ],
 "$0 installation": [
  null,
  "$0 安裝"
 ],
 "$0 installer": [
  null,
  "$0 安裝程式"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 是一個 MBR 延伸分割區，其中包含邏輯分割區。移除所有邏輯分割區後，延伸分割區也會自動移除。"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "需要 $0，但只有 $1 可用。"
 ],
 "$0 warning": [
  null,
  "$0 個警告"
 ],
 "$0 will be deleted": [
  null,
  "$0 將會被刪除"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' 檔案系統不能位於加密的區塊裝置上"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' 必須被指派給 '$1'"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' 必須位於格式化為 '$1' 的裝置上"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "‘$0’必須位於EFI系統分區，所選擇的分區為FAT文件系統，但是沒有被標記為ESP，將分區類型設置為EFI系統並啟用ESP標識"
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "在 MDRAID 裝置 $1 上找到 '$0' 磁碟分割。 不支援 MDRAID 裝置上的開機引導磁碟分割。"
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "具有管理權限的標準使用者帳戶，可進行系統層級的變更。"
 ],
 "Abort installation": [
  null,
  "終止安裝"
 ],
 "About": [
  null,
  "關於"
 ],
 "Account": [
  null,
  "帳號"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Add another server...": [
  null,
  "新增其他伺服器..."
 ],
 "Add mount": [
  null,
  "增加掛載"
 ],
 "Add-ons for your chosen environment": [
  null,
  "所選環境的附加元件"
 ],
 "Add-ons not specific to your environment": [
  null,
  "非特定於您環境的附加元件"
 ],
 "Additional languages": [
  null,
  "額外語言"
 ],
 "Additional software for the selected environment": [
  null,
  "所選環境的額外軟體"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "所有於儲存空間編輯器進行的變更將立即生效。"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "所有使用此密碼的設備都將被解鎖"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web 介面"
 ],
 "Anaconda project page": [
  null,
  "Anaconda 專案頁面"
 ],
 "Apply mount point assignment and install": [
  null,
  "套用掛載點分配並安裝"
 ],
 "Applying changes...": [
  null,
  "套用變更中..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "將分割區指派至掛載點，適用於預先配置的自訂佈局。"
 ],
 "Automatic log file upload": [
  null,
  "自動上傳日誌檔案"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "使用時間伺服器自動設定日期和時間"
 ],
 "Automatically set timezone": [
  null,
  "自動設定時區"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "可用空間: $0。 安裝需要: $1。"
 ],
 "Back": [
  null,
  "返回"
 ],
 "Base environment": [
  null,
  "基礎環境"
 ],
 "Brief description of the issue": [
  null,
  "問題的簡短描述"
 ],
 "Bug report details": [
  null,
  "錯誤回報詳情"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API 金鑰"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "繼續使用此軟體，即表示您了解並接受與預發佈軟體相關的風險，您打算僅將其用於測試和開發目的，並願意報告任何錯誤或問題以改進此軟體。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change": [
  null,
  "改變"
 ],
 "Change destination": [
  null,
  "更改目標位置"
 ],
 "Change hostname": [
  null,
  "更改主機名稱"
 ],
 "Change partition layout": [
  null,
  "變更分割區配置"
 ],
 "Change system keyboard layout": [
  null,
  "變更系統鍵盤配置"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "在此進行的變更將立即對系統生效。 這沒有反悔的機會。"
 ],
 "Checking installation configuration...": [
  null,
  "正在檢查安裝組態..."
 ],
 "Checking storage configuration": [
  null,
  "正在檢查儲存組態"
 ],
 "Clear search": [
  null,
  "清除搜尋"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "請再次點擊「下一步」以繼續，儘管存在這些警告。"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Close storage editor": [
  null,
  "關閉儲存編輯器"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit storage 不會提供用於解鎖加密裝置的密碼短語。"
 ],
 "Completed": [
  null,
  "已完成"
 ],
 "Configuration is incomplete": [
  null,
  "設定不完整"
 ],
 "Configure NTP servers": [
  null,
  "設定 NTP 伺服器"
 ],
 "Configure custom NTP servers": [
  null,
  "設定自訂 NTP 伺服器"
 ],
 "Configure network": [
  null,
  "設定網路"
 ],
 "Configure storage": [
  null,
  "正在配置存儲"
 ],
 "Configure storage again": [
  null,
  "重新設定儲存裝置"
 ],
 "Confirm passphrase": [
  null,
  "確認密碼"
 ],
 "Continue": [
  null,
  "繼續"
 ],
 "Continue installation": [
  null,
  "繼續安裝"
 ],
 "Continue installation?": [
  null,
  "繼續安裝？"
 ],
 "Continue with installation": [
  null,
  "繼續以繼續安裝"
 ],
 "Correct these issues before continuing.": [
  null,
  "請在繼續之前改正這些問題"
 ],
 "Create Account": [
  null,
  "建立帳號"
 ],
 "Create account": [
  null,
  "建立帳號"
 ],
 "Currently installed: $0": [
  null,
  "目前已安裝：$0"
 ],
 "Custom": [
  null,
  "自訂"
 ],
 "Date": [
  null,
  "日期"
 ],
 "Date and time": [
  null,
  "日期和時間"
 ],
 "Delete partition": [
  null,
  "刪除分區"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "刪除特定分割區可能會導致 $0 無法開機：$1"
 ],
 "Description": [
  null,
  "細節"
 ],
 "Destination": [
  null,
  "目的地"
 ],
 "Destination is encrypted": [
  null,
  "目的地已加密"
 ],
 "Detailed description of the issue": [
  null,
  "問題的詳細描述"
 ],
 "Detected valid storage layout:": [
  null,
  "已偵測到有效的儲存空間佈局："
 ],
 "Device": [
  null,
  "裝置"
 ],
 "Duplicate device.": [
  null,
  "重複的設備。"
 ],
 "Duplicate mount point.": [
  null,
  "重複的掛載點。"
 ],
 "Enable root account": [
  null,
  "啟用 root 帳號(_E)"
 ],
 "Encrypt my data": [
  null,
  "加密我的資料"
 ],
 "Encrypted": [
  null,
  "已加密"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "Enter PIN": [
  null,
  "輸入PIN密鑰"
 ],
 "Enter PIN to access the installer": [
  null,
  "輸入PIN密鑰以進入安裝器"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "輸入您的 Bugzilla API 金鑰以建立錯誤回報。您將能夠在下一步中檢視和編輯錯誤詳情。"
 ],
 "Environment": [
  null,
  "環境"
 ],
 "Erase data and install": [
  null,
  "刪除資料並安裝"
 ],
 "Error details": [
  null,
  "錯誤詳情："
 ],
 "Exit to live desktop": [
  null,
  "退出至 live 桌面"
 ],
 "Extended partition": [
  null,
  "延伸分割區"
 ],
 "Failed to report issue": [
  null,
  "無法回報問題"
 ],
 "Failed to save layouts": [
  null,
  "無法儲存配置"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux 需要至少 $0 的硬碟空間。"
 ],
 "Finalization": [
  null,
  "最後階段"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "最後階段：系統設置已經完成。 最後階段可能要一些時間。"
 ],
 "Find layout": [
  null,
  "尋找配置"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "為了更好的安全性，請避免直接使用 root 帳戶。請改用上方的本機帳戶來管理系統。"
 ],
 "Full name": [
  null,
  "全名"
 ],
 "Full name cannot contain colon characters": [
  null,
  "全名不能包含冒號"
 ],
 "Helper text": [
  null,
  "輔助文字"
 ],
 "Hide API key": [
  null,
  "隱藏 API 金鑰"
 ],
 "Hide PIN": [
  null,
  "隱藏 PIN 金鑰"
 ],
 "Hide confirmed password": [
  null,
  "隱藏確認密碼"
 ],
 "Hide passphrase": [
  null,
  "隱藏密碼"
 ],
 "Hide password": [
  null,
  "隱藏密碼"
 ],
 "Hostname": [
  null,
  "主機名稱"
 ],
 "How would you like to install?": [
  null,
  "您想如何安裝？"
 ],
 "I understand that all existing data will be erased": [
  null,
  "我知曉所有現存的資料將會從被選擇的磁盤清除"
 ],
 "I understand that some existing data will be erased": [
  null,
  "我知曉某些現存資料將會被清除"
 ],
 "I understand that some partitions will be modified": [
  null,
  "我知曉有些分割區將會被變更"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "如果留空，主機名稱將為臨時名稱並由網路資訊設定。"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "如果以上選項都不適用,請使用存儲編輯器一以創建自定義分區"
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "如果您正在配置分割區，需要遵循以下事項："
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "如果您不同意自動上傳日誌檔案，您可以改為 $0。手動回報可讓您檢視並選擇性地附加日誌檔案。"
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "如果您不了解或不接受此風險，請退出此程式。"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "如果你的問題與以上的某個bug相符,你可以打開這個bug然後添加你的信息而不是新建一個重複的報告"
 ],
 "In progress": [
  null,
  "正在進行"
 ],
 "Initializing...": [
  null,
  "初始化中..."
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Installation completed": [
  null,
  "安裝已完成"
 ],
 "Installation failed": [
  null,
  "安裝失敗"
 ],
 "Installation method": [
  null,
  "安裝方法"
 ],
 "Installation of the system failed": [
  null,
  "系統安裝失敗"
 ],
 "Installation of the system failed: $0": [
  null,
  "系統安裝失敗：$0"
 ],
 "Installation type": [
  null,
  "安裝類型"
 ],
 "Installing": [
  null,
  "正在安裝"
 ],
 "Insufficient disk space": [
  null,
  "磁碟空間不足"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "無效的PIN密鑰，請重新輸入"
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "偵測到無效的 RAID 設定。 如果您的 RAID 陣列直接建立在磁碟上，則必須在陣列上建立磁碟分割表。 如果 RAID 陣列是建立在磁碟分割之上，則必須包含單一檔案系統或格式 (例如 LVM PV)。 陣列上任何現有的磁碟分割都會被忽略。"
 ],
 "Invalid hostname": [
  null,
  "無效的主機名稱"
 ],
 "Jump to first incomplete step": [
  null,
  "跳轉回第一個未完成的步驟"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "保持目前硬碟佈局並使用可用空間，以與其他作業系統進行雙重開機。"
 ],
 "Keyboard": [
  null,
  "鍵盤"
 ],
 "Keyboard layout during boot": [
  null,
  "開機時的鍵盤配置"
 ],
 "Language": [
  null,
  "語言"
 ],
 "Launch storage editor": [
  null,
  "啟動儲存空間編輯器"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "知曉更多關於配置中的首先訪問信息"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "留空所有密碼字段,以使用空密碼"
 ],
 "Location": [
  null,
  "位置"
 ],
 "Locked devices": [
  null,
  "鎖定的裝置"
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Make current": [
  null,
  "設為目前"
 ],
 "Manual disk configuration": [
  null,
  "手動設定硬碟"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "手動硬碟設定：掛載點映射"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "可以包含字母、數字以及連字號。"
 ],
 "May need more free space": [
  null,
  "可能需要更多可用空間"
 ],
 "Medium": [
  null,
  "中等"
 ],
 "Minimum of $0 required": [
  null,
  "最少需要 $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "父裝置與子裝置的重新格式化選擇不匹配。"
 ],
 "Mount point": [
  null,
  "掛載點"
 ],
 "Mount point assignment": [
  null,
  "掛載點分配"
 ],
 "Move down": [
  null,
  "下移"
 ],
 "Move up": [
  null,
  "上移"
 ],
 "Must be at least $0 characters": [
  null,
  "必須至少包含 $0 個字元"
 ],
 "My issue is different, continue": [
  null,
  "我的問題是不同的,繼續"
 ],
 "NTP Servers": [
  null,
  "NTP 伺服器"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Needs at least $0": [
  null,
  "最少需要 $0"
 ],
 "Network": [
  null,
  "網路"
 ],
 "Network Configuration": [
  null,
  "網路組態"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "網路不可用。 在頂部選單欄設定網路以回報問題。"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "網路不可用。 設定網路以回報問題。"
 ],
 "Network plugin failed": [
  null,
  "網路外掛失敗"
 ],
 "Next": [
  null,
  "下一步"
 ],
 "No devices": [
  null,
  "沒有裝置"
 ],
 "No disks available": [
  null,
  "沒有可用的硬碟"
 ],
 "No disks selected": [
  null,
  "尚未選取磁碟"
 ],
 "No keyboard layouts selected": [
  null,
  "尚未選取任何鍵盤布局"
 ],
 "No layouts selected yet": [
  null,
  "尚未選取任何配置"
 ],
 "No results found": [
  null,
  "未找到結果"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "無法為所選的鍵盤配置取得有效的 VConsole 按鍵對應。請選擇其他鍵盤配置。"
 ],
 "Not enough available free space": [
  null,
  "可用空間不足"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "所選取的磁碟上的可用空間不足。"
 ],
 "Not enough space on selected disks.": [
  null,
  "所選取的磁碟上的空間不足。"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "注意：此為預發行軟體，僅供開發與測試用途。絕對不要將此軟體用於任何重要工作或生產環境。"
 ],
 "Open Bugzilla bug entry form": [
  null,
  "開啟 Bugzilla 錯誤回報表單"
 ],
 "Operating system": [
  null,
  "作業系統"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Other keyboards": [
  null,
  "其他鍵盤"
 ],
 "Partitions (advanced)": [
  null,
  "分割區（進階）"
 ],
 "Passphrase": [
  null,
  "密碼"
 ],
 "Passphrase did not match any locked device": [
  null,
  "密碼與任何鎖定的裝置都不匹配"
 ],
 "Passphrases must match": [
  null,
  "密語必須符合"
 ],
 "Pending": [
  null,
  "待處理"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "請將日誌文件 $0 附加到問題中。"
 ],
 "Please enter a PIN": [
  null,
  "請輸入有效的 PIN 密鑰。"
 ],
 "Please select at least one disk to continue": [
  null,
  "請選擇至少一個磁碟以繼續"
 ],
 "Pool": [
  null,
  "集池"
 ],
 "Potential duplicate bugs found": [
  null,
  "找到了可能重複的問題"
 ],
 "Powered by Anaconda": [
  null,
  "由 Anaconda 提供技術支援"
 ],
 "Pre-release": [
  null,
  "預先發行"
 ],
 "Prefer to report manually? $0": [
  null,
  "偏好手動回報？$0"
 ],
 "Proceed with installation": [
  null,
  "繼續安裝"
 ],
 "Quit": [
  null,
  "退出"
 ],
 "Quit installer?": [
  null,
  "退出安裝程式(_Q)?"
 ],
 "Reading information about the OS failed.": [
  null,
  "讀取作業系統資訊失敗。"
 ],
 "Reading information about the computer failed.": [
  null,
  "讀取電腦資訊失敗。"
 ],
 "Reading installer configuration failed.": [
  null,
  "讀取安裝程式設定失敗。"
 ],
 "Reading installer version information failed.": [
  null,
  "讀取安裝程式版本資訊失敗。"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "真實主機名稱只能包含字母、數字、連字號（不可作為開頭或結尾）及點號 (.)"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "真實主機名稱長度必須為 64 個或更少個字元"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "重新開機進入 Windows 以調整 BitLocker 加密磁碟分割的大小。 至少預留 $0 的可用空間供以安裝系統使用。"
 ],
 "Reboot system?": [
  null,
  "重新啟動系統？"
 ],
 "Reclaim additional space": [
  null,
  "取回額外空間"
 ],
 "Reclaim space": [
  null,
  "取回磁碟空間(_R)"
 ],
 "Reclaim space (required)": [
  null,
  "取回空間（必須）"
 ],
 "Recommended": [
  null,
  "推薦的"
 ],
 "Recommended partitions:": [
  null,
  "建議分割區："
 ],
 "Reformat": [
  null,
  "重新格式化"
 ],
 "Reinstall Fedora": [
  null,
  "重新安裝 Fedora"
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "移除所選裝置上的所有分割區，包括現有的作業系統。"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "移除或調整現有檔案系統的大小，以釋放空間進行安裝。"
 ],
 "Remove server": [
  null,
  "移除伺服器"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "移除檔案系統將會永久刪除其中包含的在該裝置的所有資料。 調整磁碟分割大小可釋放未使用的空間，但並非毫無風險。 請在回收空間之前，務必先備份重要的資料。"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "取代目前的安裝，但保留家目錄中的檔案。"
 ],
 "Report Issue": [
  null,
  "回報問題"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "透過開啟 Bugzilla 錯誤回報表單來回報問題或提供回饋。$0。"
 ],
 "Report issue": [
  null,
  "回報問題"
 ],
 "Reporting issue...": [
  null,
  "回報問題中..."
 ],
 "Required": [
  null,
  "必須"
 ],
 "Requirements": [
  null,
  "必要條件"
 ],
 "Rescan devices": [
  null,
  "重新掃描裝置"
 ],
 "Rescanning of the disks failed.": [
  null,
  "重新掃描磁碟失敗。"
 ],
 "Resize": [
  null,
  "調整大小"
 ],
 "Resize partition": [
  null,
  "调整分割區尺寸"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "重新調整以下分割區的大小從 $0：$1"
 ],
 "Restrict access to the report": [
  null,
  "限制对报告的访问"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "将报告限制为$0组。$1"
 ],
 "Return to installation": [
  null,
  "回到安裝"
 ],
 "Return to storage editor": [
  null,
  "回到儲存空間編輯器"
 ],
 "Review and install": [
  null,
  "檢查並安裝"
 ],
 "Root account has been configured": [
  null,
  "Root账户已经配置完毕"
 ],
 "Root account is enabled": [
  null,
  "Root 帳號已啟用"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root 帳號已啟用，但尚未設定任何使用者帳號"
 ],
 "Root password has been set.": [
  null,
  "已設定 Root 密碼。"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "使用您的手機掃描 QR code 並造訪："
 ],
 "Search for a language": [
  null,
  "搜尋語言"
 ],
 "Search for additional software": [
  null,
  "搜尋額外軟體"
 ],
 "Search for an environment": [
  null,
  "搜尋環境"
 ],
 "Search keyboard layout": [
  null,
  "搜尋鍵盤配置"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "使用硬碟加密來保護您的資料。 此設定僅適用於新分割區"
 ],
 "Select": [
  null,
  "選取"
 ],
 "Select a device": [
  null,
  "選取的裝置"
 ],
 "Select city": [
  null,
  "選擇城市"
 ],
 "Select destination": [
  null,
  "選取安裝目的地"
 ],
 "Select region": [
  null,
  "選擇區域"
 ],
 "Selected (top = current)": [
  null,
  "已選取（頂端 = 目前）"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "無法重新格式化所選的裝置格式 '$0' 。"
 ],
 "Send us feedback on your installation": [
  null,
  "對於您的安裝提供建議"
 ],
 "Server": [
  null,
  "伺服器"
 ],
 "Server is not reachable": [
  null,
  "伺服器無法連線"
 ],
 "Set custom hostname": [
  null,
  "設定自訂主機名稱"
 ],
 "Share disk with other operating systems": [
  null,
  "與其他作業系統共享硬碟"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "與其他作業系統共享硬碟：$0"
 ],
 "Show AM/PM": [
  null,
  "顯示上午/下午"
 ],
 "Show API key": [
  null,
  "顯示 API 金鑰"
 ],
 "Show PIN": [
  null,
  "顯示 PIN 金鑰"
 ],
 "Show confirmed password": [
  null,
  "顯示確認密碼"
 ],
 "Show passphrase": [
  null,
  "顯示密碼"
 ],
 "Show password": [
  null,
  "顯示密碼"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Software installation": [
  null,
  "軟體選擇"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "軟體選擇：儲存空間設定完成。 該軟體正在安裝至您的裝置上。"
 ],
 "Software selection": [
  null,
  "軟體選擇"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "繼續前尚有一些安装步骤需要完成"
 ],
 "Some required partitions are missing: $0": [
  null,
  "缺少部分必要的分割區：$0"
 ],
 "Space": [
  null,
  "空間"
 ],
 "Stacktrace": [
  null,
  "堆疊追蹤"
 ],
 "Storage": [
  null,
  "儲存"
 ],
 "Storage configuration": [
  null,
  "儲存裝置組態"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "儲存組態：儲存空間正在設定。"
 ],
 "Storage editor": [
  null,
  "儲存編輯器"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "儲存空間設定依據「修改儲存空間」中的配置。"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "存儲佈局是由 kickstart 文件定義的。可以在摘要步驟中查看計劃的分區佈局。"
 ],
 "Storage plugin failed": [
  null,
  "儲存空間外掛失敗"
 ],
 "Storage requirements not met": [
  null,
  "儲存空間需求不滿足"
 ],
 "Strong": [
  null,
  "強"
 ],
 "Successfully installed": [
  null,
  "安裝成功"
 ],
 "Successfully unlocked $0.": [
  null,
  "已成功解鎖 $0。"
 ],
 "Suggested keyboards": [
  null,
  "建議的鍵盤"
 ],
 "Suggested languages": [
  null,
  "建議語言"
 ],
 "System": [
  null,
  "系統"
 ],
 "System configuration": [
  null,
  "系統組態"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "系統組態：軟體安裝完成。 現在正在設定系統。"
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda 安裝意外停止。"
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "以下未解決的錯誤可能與您的問題有關。請在建立新報表前先查看這些錯誤。"
 ],
 "The following user will be created:": [
  null,
  "下列使用者將被建立："
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "安裝需要 $0 的磁碟空間；但所選磁碟的容量只有 $1。"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "安裝程式由於嚴重錯誤而無法繼續。"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "安裝程式由於嚴重錯誤而無法繼續：$0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "設定磁碟加密密碼後，鍵盤配置已變更。請重新輸入密碼。"
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "您提供的密語包含非 ASCII 字元。在輸入時您可能無法切換鍵盤布局。"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "所選的預設鍵盤配置不支援 ASCII 字元。請選擇支援 ASCII 的配置作為預設值。"
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "存儲編輯器可讓您調整、刪除及建立磁碟分割。 它可以設定 LVM 以及更多針對磁碟變動的功能。 它是用來作為進階的公用程式，而非用於一般的安裝。"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "這些日誌檔案可能包含敏感資訊，例如 IP 位址、使用者名稱或其他系統詳細資料。"
 ],
 "This hostname can't be submitted": [
  null,
  "此主機名稱無法被提交"
 ],
 "This is unstable, pre-release software": [
  null,
  "這是尚未穩定的預先發行軟體"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "此配置將用於啟動時解鎖系統"
 ],
 "This may take a moment": [
  null,
  "這可能需要一段時間"
 ],
 "This will take a few moments": [
  null,
  "這會需要一段時間"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Timezone": [
  null,
  "時區"
 ],
 "Title": [
  null,
  "標題"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "若要開始使用 $0，請重新啟動您的系統。"
 ],
 "To continue, select the devices to install to.": [
  null,
  "若要繼續。請選擇要安裝的設備。"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "要使用此選項，請調整大小或移除現有分割區以釋放至少 $0。"
 ],
 "Type": [
  null,
  "類型"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "無法安排刪除 $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "無法安排調整 $0 的大小"
 ],
 "Undo last action": [
  null,
  "取消上個動作(_U)"
 ],
 "Unlock": [
  null,
  "解除鎖定"
 ],
 "Unlock encrypted devices": [
  null,
  "解鎖加密裝置"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "解鎖加密分割區以保留現有資料並顯示更多安裝方式。"
 ],
 "Use configured storage": [
  null,
  "使用已配置的儲存空間"
 ],
 "Use entire disk": [
  null,
  "使用整個硬碟"
 ],
 "Use free space": [
  null,
  "使用可用的空間"
 ],
 "Use local account": [
  null,
  "使用本機帳號"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "使用 RAID 裝置進行自動分割"
 ],
 "User creation": [
  null,
  "創建使用者"
 ],
 "User name": [
  null,
  "使用者名稱"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "使用者名稱只能包含：英文字母 (a-z)、數字 (0-9)、連字號 ($0)、句點 ($1) 及底線 ($2)"
 ],
 "User name must not be a reserved word": [
  null,
  "使用者名稱不能是保留文字"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "使用者名稱長度必須少於 33 個字元"
 ],
 "Validating...": [
  null,
  "驗證中..."
 ],
 "Weak": [
  null,
  "脆弱"
 ],
 "Welcome": [
  null,
  "歡迎"
 ],
 "Welcome to Fedora Linux": [
  null,
  "歡迎使用 Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "歡迎。 現在就來安裝 $0 吧。"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "當您提交此錯誤回報時，以下日誌檔案將自動上傳：$0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "含有 BitLocker 加密的 Windows 分割區無法被調整大小"
 ],
 "You can close this browser window now.": [
  null,
  "現在您可以關閉此瀏覽器視窗了。"
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "您可以在此釋放足夠的空間讓安裝程式處理其餘部分，或是手動設定分割區。"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "您可以為您的 Bugzilla 帳號產生 API 金鑰 $0。"
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "您必須啟用 root 帳號或建立本機使用者帳號才能繼續。"
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "您必須連線至網路才能啟用自動日期和時間。"
 ],
 "Your progress will not be saved.": [
  null,
  "您的進度將不會被儲存。"
 ],
 "completed step": [
  null,
  "完成步驟"
 ],
 "current step": [
  null,
  "目前步驟"
 ],
 "delete": [
  null,
  "刪除"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "encrypt": [
  null,
  "加密"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "extended partition": [
  null,
  "延伸分割區"
 ],
 "format as $0": [
  null,
  "格式化為 $0"
 ],
 "here": [
  null,
  "於此處"
 ],
 "incomplete": [
  null,
  "未完成"
 ],
 "mount": [
  null,
  "掛載"
 ],
 "pending step": [
  null,
  "待執行步驟"
 ],
 "report the issue manually": [
  null,
  "手動回報問題"
 ],
 "resized from $0": [
  null,
  "已從 $0 調整大小"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "shrink to $0": [
  null,
  "已縮小至 $0"
 ],
 "transient, will use DHCP": [
  null,
  "臨時性，將使用 DHCP"
 ],
 "undo": [
  null,
  "復原"
 ]
});
