cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "Password": [
  null,
  "Password"
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Journal": [
  null,
  "Registro"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "Hardware information": [
  null,
  "Informazioni hardware"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "copia"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Remove": [
  null,
  "Rimuovi"
 ],
 "active": [
  null,
  "attivo"
 ],
 "Default": [
  null,
  "Predefinito"
 ],
 "Light": [
  null,
  "Chiaro"
 ],
 "Dark": [
  null,
  "Scuro"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Search": [
  null,
  "Ricerca"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "Trust and add host": [
  null,
  "Considera attendibile e aggiungi host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'impronta digitale risultante può essere condivisa tramite metodi pubblici, inclusa l'email. Se chiedi a qualcun altro di eseguire la verifica per te, può inviare i risultati utilizzando qualsiasi metodo."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta."
 ],
 "Verify fingerprint": [
  null,
  "Verifica impronta digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "The fingerprint should match:": [
  null,
  "L'impronta digitale dovrebbe corrispondere a:"
 ],
 "The password can not be empty": [
  null,
  "La password non può essere vuota"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossibile accedere a $0. L'host non accetta l'accesso con password né alcuna delle tue chiavi SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta da password e l'host non consente l'accesso con password. Fornire la password della chiave $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta. Puoi accedere con la tua password di accesso o fornendo la password della chiave $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La chiave SSH $0 di $1 su $2 verrà aggiunta al file $3 di $4 su $5."
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La chiave SSH $0 sarà resa disponibile per il resto della sessione e sarà utilizzabile anche per l'accesso ad altri host."
 ],
 "Permission denied": [
  null,
  "Permesso negato"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change": [
  null,
  "Modifica"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nessun metodo per ottenere l'accesso amministrativo è disponibile (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Switch to administrative access": [
  null,
  "Passa all'accesso amministrativo"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema diventando amministratore"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld$0"
 ],
 "Visit firewall": [
  null,
  "Vai al firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "less than a minute ago": [
  null,
  "meno di un minuto fa"
 ],
 "in less than a minute": [
  null,
  "in meno di un minuto"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Weak password": [
  null,
  "Password debole"
 ],
 "Show password": [
  null,
  "Mostra la password"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "password quality": [
  null,
  "qualità password"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Removing $0": [
  null,
  "Rimozione di $0"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Unknown host: $0": [
  null,
  "Host sconosciuto: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossibile accedere a $0 usando l'autenticazione con chiave SSH. Fornire la password."
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Error during initialization": [
  null,
  "Si e verificato un errore durante l'inizializzazione"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Home": [
  null,
  "Home"
 ],
 "Downloads": [
  null,
  "Scaricati"
 ],
 "Not a directory": [
  null,
  "Non è una cartella"
 ],
 "All files": [
  null,
  "Tutti i file"
 ],
 "Recent": [
  null,
  "Recenti"
 ],
 "No recent directories": [
  null,
  "Nessuna cartella recente"
 ],
 "No recent files": [
  null,
  "Nessun file recente"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "File chooser actions": [
  null,
  "Azioni per scegliere il file"
 ],
 "Open in file browser": [
  null,
  "Aprire in un esploratore dei file"
 ],
 "Hide hidden files": [
  null,
  "Nascondi file nascosti"
 ],
 "Show hidden files": [
  null,
  "Mostra file nascosti"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Clear filters": [
  null,
  "Cancella filtri"
 ],
 "Directory is empty": [
  null,
  "La cartella è vuota"
 ],
 "Directory has no sub-directories": [
  null,
  "La cartella non ha sotto-cartelle"
 ],
 "This directory contains only hidden files": [
  null,
  "Questa cartella contiene soltanto file nascosti"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "Folder": [
  null,
  "Cartella"
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "View all logs": [
  null,
  "Visualizza tutti i log"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "$0 is not a directory": [
  null,
  "$0 non è una directory"
 ],
 "$0 does not exist": [
  null,
  "$0 non esiste"
 ],
 "Font size": [
  null,
  "Dimensione font"
 ],
 "Decrease by one": [
  null,
  "Diminuisci di uno"
 ],
 "Increase by one": [
  null,
  "Aumenta di uno"
 ],
 "Appearance": [
  null,
  "Aspetto"
 ],
 "Black": [
  null,
  "Nero"
 ],
 "White": [
  null,
  "Bianco"
 ],
 "Reset": [
  null,
  "Ripristina"
 ],
 "Unable to open directory": [
  null,
  "Impossibile aprire la directory"
 ],
 "Running process prevents directory change": [
  null,
  "L'esecuzione del processo impedisce la modifica della directory"
 ],
 "Change directory": [
  null,
  "Cambia directory"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "La modifica della directory interromperà forzatamente il processo attualmente in esecuzione. Il processo può anche essere interrotto manualmente nel terminale prima di continuare."
 ],
 "Terminal not available": [
  null,
  "Terminale non disponibile"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Questo browser non supporta WebGL2."
 ],
 "unknown": [
  null,
  "sconosciuto"
 ],
 "Shutdown": [
  null,
  "Spegni"
 ],
 "running $0": [
  null,
  "$0 in esecuzione"
 ],
 "Current boot": [
  null,
  "Boot corrente"
 ],
 "Previous boot": [
  null,
  "Avvio precedente"
 ],
 "Last 24 hours": [
  null,
  "Ultime 24 ore"
 ],
 "Last 7 days": [
  null,
  "Ultimi 7 giorni"
 ],
 "Only emergency": [
  null,
  "Solo emergenza"
 ],
 "Alert and above": [
  null,
  "Allarme e oltre"
 ],
 "Critical and above": [
  null,
  "Critico e superiore"
 ],
 "Error and above": [
  null,
  "Errore e superiore"
 ],
 "Warning and above": [
  null,
  "Avvertenza e superiore"
 ],
 "Notice and above": [
  null,
  "Notice e oltre"
 ],
 "Info and above": [
  null,
  "Info e superiore"
 ],
 "Debug and above": [
  null,
  "Debug e superiore"
 ],
 "Toggle filters": [
  null,
  "Attiva/disattiva i filtri"
 ],
 "Time": [
  null,
  "Orario"
 ],
 "Priority": [
  null,
  "Priorità"
 ],
 "Identifier": [
  null,
  "Identificativo"
 ],
 "Filters": [
  null,
  "Filtri"
 ],
 "Pause": [
  null,
  "Metti in pausa"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Le specifiche della data devono essere nel formato AAAA-MM-GG hh:mm:ss. In alternativa si intendono le stringhe 'yesterday', 'today', 'tomorrow'. 'now' si riferisce all'ora corrente. Infine, possono essere specificati tempi relativi, preceduti da '-' o '+'"
 ],
 "Since": [
  null,
  "Da"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Inizia a mostrare le voci a partire dalla data specificata o da una data successiva."
 ],
 "Until": [
  null,
  "Fino a"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Inizia a mostrare le voci entro e non oltre la data specificata."
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostra i messaggi da un avvio specifico."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Questo aggiungerà una corrispondenza per '_BOOT_ID='. Se non specificato verranno mostrati i log per l'avvio corrente. Se l'ID di avvio viene omesso, un offset positivo cercherà gli avvii a partire dall'inizio del journal e un offset uguale o inferiore a zero cercherà gli avvioi a partire dalla fine del journal. Pertanto, 1 indica il primo avvio trovato nel journal in ordine cronologico, 2 il secondo e così via; mentre -0 è l'ultimo avvio, -1 l'avvio prima dell'ultimo e così via."
 ],
 "Unit": [
  null,
  "Unità"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostra i messaggi per l'unità systemd specificata."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Questo aggiungerà una corrispondenza per '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' e 'UNIT=' per trovare tutti i possibili messaggi per l'unità specificata. Può contenere più unità separate da virgola."
 ],
 "Free-form search": [
  null,
  "Ricerca libera"
 ],
 "Show messages containing given string.": [
  null,
  "Mostra i messaggi contenenti una determinata stringa."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualsiasi stringa di testo nei messaggi di registro può essere filtrata. La stringa può anche essere sotto forma di un'espressione regolare. Supporta anche il filtraggio in base ai campi del registro dei messaggi. Questi sono valori separati da spazi, nella forma CAMPO=VALORE, dove il valore può essere un elenco di valori possibili separati da virgole."
 ],
 "journalctl manpage": [
  null,
  "pagina man di journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiato con successo negli appunti"
 ],
 "Create timer": [
  null,
  "Creare timer"
 ],
 "Edit timer": [
  null,
  "Modifica timer"
 ],
 "Timer creation failed": [
  null,
  "Creazione timer fallita"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Recupero delle condizioni di avvio per il timer non riuscito"
 ],
 "Failed to get the timer command": [
  null,
  "Recupero del comando del timer non riuscito"
 ],
 "This field cannot be empty": [
  null,
  "Questo campo non può essere vuoto"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sono ammessi solo lettere, numeri, : , _ , . , @ ,"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Shell command": [
  null,
  "Command Shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Questo comando verrà eseguito da /bin/sh."
 ],
 "Trigger": [
  null,
  "Trigger"
 ],
 "At specific time": [
  null,
  "In un momento specifico"
 ],
 "After system boot": [
  null,
  "Dopo l'avvio del sistema"
 ],
 "Seconds": [
  null,
  "Secondi"
 ],
 "Minutes": [
  null,
  "Minuti"
 ],
 "Hours": [
  null,
  "Ore"
 ],
 "Weeks": [
  null,
  "Settimane"
 ],
 "Delay must be a number": [
  null,
  "Il ritardo deve essere un numero"
 ],
 "Repeat": [
  null,
  "Ripeti"
 ],
 "Don't repeat": [
  null,
  "Non ripetere"
 ],
 "Minutely": [
  null,
  "Minuti"
 ],
 "Hourly": [
  null,
  "Orario"
 ],
 "Daily": [
  null,
  "Giornaliero"
 ],
 "Weekly": [
  null,
  "Settimanalmente"
 ],
 "Monthly": [
  null,
  "Mensilmente"
 ],
 "Yearly": [
  null,
  "Annuale"
 ],
 "Run at": [
  null,
  "Esegui a"
 ],
 "At second": [
  null,
  "Al secondo"
 ],
 "At minute": [
  null,
  "Al minuto"
 ],
 "Run on": [
  null,
  "Eseguire in"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Il minuto deve essere un numero compreso tra 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Il secondo deve essere un numero compreso tra 0-59"
 ],
 "Repeat weekly": [
  null,
  "Ripeti ogni settimana"
 ],
 "Mondays": [
  null,
  "Lunedì"
 ],
 "Tuesdays": [
  null,
  "Martedì"
 ],
 "Wednesdays": [
  null,
  "Mercoledì"
 ],
 "Thursdays": [
  null,
  "Giovedì"
 ],
 "Fridays": [
  null,
  "Venerdì"
 ],
 "Saturdays": [
  null,
  "Sabati"
 ],
 "Sundays": [
  null,
  "Domeniche"
 ],
 "Repeat monthly": [
  null,
  "Ripeti mensilmente"
 ],
 "1st": [
  null,
  "1°"
 ],
 "2nd": [
  null,
  "2°"
 ],
 "3rd": [
  null,
  "3°"
 ],
 "4th": [
  null,
  "4°"
 ],
 "5th": [
  null,
  "5°"
 ],
 "6th": [
  null,
  "6°"
 ],
 "7th": [
  null,
  "7°"
 ],
 "8th": [
  null,
  "8°"
 ],
 "9th": [
  null,
  "9°"
 ],
 "10th": [
  null,
  "10°"
 ],
 "11th": [
  null,
  "11°"
 ],
 "12th": [
  null,
  "12°"
 ],
 "13th": [
  null,
  "13°"
 ],
 "14th": [
  null,
  "14°"
 ],
 "15th": [
  null,
  "15°"
 ],
 "16th": [
  null,
  "16°"
 ],
 "17th": [
  null,
  "17°"
 ],
 "18th": [
  null,
  "18°"
 ],
 "19th": [
  null,
  "19°"
 ],
 "20th": [
  null,
  "20°"
 ],
 "21th": [
  null,
  "21esimo"
 ],
 "22th": [
  null,
  "22esimo"
 ],
 "23th": [
  null,
  "23esimo"
 ],
 "24th": [
  null,
  "24°"
 ],
 "25th": [
  null,
  "25°"
 ],
 "26th": [
  null,
  "26°"
 ],
 "27th": [
  null,
  "27°"
 ],
 "28th": [
  null,
  "28°"
 ],
 "29th": [
  null,
  "29°"
 ],
 "30th": [
  null,
  "30°"
 ],
 "31st": [
  null,
  "31°"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Unclean shutdown": [
  null,
  "Spegnimento non pulito"
 ],
 "View logs": [
  null,
  "Visualizza log"
 ],
 "Dismiss": [
  null,
  "Scarta"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Spegnimento programmato alle $0"
 ],
 "Cancel poweroff": [
  null,
  "Annulla spegnimento"
 ],
 "Scheduled reboot at $0": [
  null,
  "Riavvio programmato alle $0"
 ],
 "Cancel reboot": [
  null,
  "Annulla il riavvio"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "Set hostname": [
  null,
  "Imposta il nome host"
 ],
 "Configuration": [
  null,
  "Configurazione"
 ],
 "Hostname": [
  null,
  "Nome host"
 ],
 "System time": [
  null,
  "Ora di sistema"
 ],
 "Domain": [
  null,
  "Dominio"
 ],
 "Performance profile": [
  null,
  "Profilo delle prestazioni"
 ],
 "Secure shell keys": [
  null,
  "Chiavi secure shell"
 ],
 "Show fingerprints": [
  null,
  "Mostra le impronte digitali"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "impossibile elencare le chiavi host ssh: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Caricamento delle chiavi SSH non riuscito"
 ],
 "Error message": [
  null,
  "Messaggio di errore"
 ],
 "Loading keys...": [
  null,
  "Caricamento delle chiavi..."
 ],
 "No host keys found.": [
  null,
  "Non sono state trovate chiavi host."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Impronte digitali delle chiavi SSH della macchina"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Il nome host reale deve essere di 64 caratteri o meno"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Il nome host reale può contenere solo caratteri minuscoli, cifre, trattini e punti (con sottodomini popolati)"
 ],
 "Change host name": [
  null,
  "Cambia nome host"
 ],
 "Pretty host name": [
  null,
  "Nome dell'host grazioso"
 ],
 "Real host name": [
  null,
  "Nome dell'host reale"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "L'utente $0 non è autorizzato a modificare le policy crittografiche"
 ],
 "Cryptographic policy": [
  null,
  "policy di crittografia"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Impostazioni consigliate e sicure per gli attuali modelli di minaccia."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT con verifica della firma SHA-1 consentita."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Maggiore interoperabilità a scapito di una maggiore superficie di attacco."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY con interoperabilità ad Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Utilizzare solo algoritmi approvati e consentiti durante l'avvio in modalità FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS con ulteriori restrizioni dei Criteri Comuni."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protegge dagli attacchi futuri previsti a breve termine a scapito dell'interoperabilità."
 ],
 "Custom cryptographic policy": [
  null,
  "Policy di crittografia personalizzata"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Cryptographic Policies è un componente di sistema che configura i sottosistemi crittografici di base, coprendo i protocolli TLS, IPSec, SSH, DNSSec e Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Cambia la politica di crittografia"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Applicazione di una nuova politica... L'operazione potrebbe richiedere alcuni minuti."
 ],
 "Reapply and reboot": [
  null,
  "riapplica e riavvia"
 ],
 "Apply and reboot": [
  null,
  "Applica e riavvia"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS non è abilitato correttamente"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "La policy di crittografia è incoerente"
 ],
 "Review cryptographic policy": [
  null,
  "Rivedi le policy di crittografia"
 ],
 "System information": [
  null,
  "Informazioni di sistema"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Asset tag": [
  null,
  "Tag asset"
 ],
 "Machine ID": [
  null,
  "ID macchina"
 ],
 "Up since": [
  null,
  "Attivo da"
 ],
 "View hardware details": [
  null,
  "Visualizza i dettagli hardware"
 ],
 "Last successful login:": [
  null,
  "Ultimo accesso riuscito:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 tentativo di accesso fallito",
  "$0 tentativi di accesso falliti"
 ],
 "View login history": [
  null,
  "Visualizza cronologia accessi"
 ],
 "recommended": [
  null,
  "raccomandato"
 ],
 "inconsistent": [
  null,
  "incoerente"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "L'associazione a un dominio richiede l'installazione di realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Impossibile accedere a un dominio perché realmd non è disponibile su questo sistema"
 ],
 "Joining this domain is not supported": [
  null,
  "L'associane a questo dominio non è supportata"
 ],
 "Login format": [
  null,
  "Formato di accesso"
 ],
 "Server software": [
  null,
  "Software Server"
 ],
 "Client software": [
  null,
  "Software Client"
 ],
 "Leave domain": [
  null,
  "Abbandona dominio"
 ],
 "Leave $0": [
  null,
  "Lasciare $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Dopo aver lasciato il dominio, solo gli utenti con credenziali locali potranno accedere a questa macchina. Ciò può influire anche su altri servizi poiché le impostazioni della risoluzione DNS e l'elenco delle CA affidabili potrebbero cambiare."
 ],
 "Validating address": [
  null,
  "Convalida dell'indirizzo"
 ],
 "Contacted domain": [
  null,
  "Dominio contattato"
 ],
 "Domain could not be contacted": [
  null,
  "Il dominio non può essere contattato"
 ],
 "Domain is not supported": [
  null,
  "Il dominio non è supportato"
 ],
 "Domain address": [
  null,
  "Indirizzo del dominio"
 ],
 "Domain administrator name": [
  null,
  "Nome dell'amministratore di dominio"
 ],
 "Domain administrator password": [
  null,
  "Password dell'amministratore di dominio"
 ],
 "Joining": [
  null,
  "Associazione"
 ],
 "Join": [
  null,
  "Associa"
 ],
 "This may take a while": [
  null,
  "L'operazione potrebbe richiedere del tempo"
 ],
 "Not permitted to configure realms": [
  null,
  "Non è consentito configurare i realm"
 ],
 "Join domain": [
  null,
  "Associa al dominio"
 ],
 "Install realmd support": [
  null,
  "Installa il supporto realmd"
 ],
 "$0 disk is failing": [
  null,
  "Il disco $0 è difettoso",
  "I dischi $0 sono difettosi"
 ],
 "Connected to Insights": [
  null,
  "Connesso a Insights"
 ],
 "Not connected to Insights": [
  null,
  "Non connesso a Insights"
 ],
 "Health": [
  null,
  "Salute"
 ],
 "of $0 CPU": [
  null,
  "di $0 CPU",
  "di $0 CPU"
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "View metrics and history": [
  null,
  "Visualizza metriche e cronologia"
 ],
 "Tuned is not available": [
  null,
  "Tuned non è disponibile"
 ],
 "Tuned is not running": [
  null,
  "Tuned non è in esecuzione"
 ],
 "Tuned is off": [
  null,
  "Tuned è disattivato"
 ],
 "This system is using the recommended profile": [
  null,
  "Questo sistema utilizza il profilo raccomandato"
 ],
 "This system is using a custom profile": [
  null,
  "Questo sistema utilizza un profilo personalizzato"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "Communication with tuned has failed": [
  null,
  "Comunicazione con tuned non riuscita"
 ],
 "Failed to enable tuned": [
  null,
  "Impossibile abilitare tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Impossibile disabilitare tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Impossibile disabilitare il profilo tuned"
 ],
 "Failed to switch profile": [
  null,
  "Impossibile cambiare profilo"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Disable tuned": [
  null,
  "Disabilita tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Impossibile avviare tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "tuned è un servizio che monitora il tuo sistema e ottimizza le prestazioni sotto alcuni carichi di lavoro. il cuore di tuned sono i profili, che ottimizzano il tuo sistema in casi differenti."
 ],
 "Change performance profile": [
  null,
  "Modifica del profilo performance"
 ],
 "Change profile": [
  null,
  "Cambia profilo"
 ],
 "Edit /etc/motd": [
  null,
  "Modifica /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Impossibile salvare le modifiche in /etc/motd"
 ],
 "Save changes": [
  null,
  "Salva modifiche"
 ],
 "Edit motd": [
  null,
  "Modifica motd"
 ],
 "Stub": [
  null,
  "urtare"
 ],
 "Not found": [
  null,
  "Non trovato"
 ],
 "Bad setting": [
  null,
  "Impostazione errata"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Merged": [
  null,
  "Fuso"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "Reloading": [
  null,
  "Ricarica"
 ],
 "Not running": [
  null,
  "Non in esecuzione"
 ],
 "Failed to start": [
  null,
  "Impossibile avviare"
 ],
 "Maintenance": [
  null,
  "Manutenzione"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Linked": [
  null,
  "Collegato"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Mascherato"
 ],
 "Static": [
  null,
  "Statico"
 ],
 "Invalid": [
  null,
  "Non valido"
 ],
 "Indirect": [
  null,
  "Indiretto"
 ],
 "Generated": [
  null,
  "Generato"
 ],
 "Transient": [
  null,
  "Transitorio"
 ],
 "Bad": [
  null,
  "Male"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "La sottoscrizione alle segnalazioni di sistemd è fallita$0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Connessione a dbus non riuscita: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Unità elencate fallite: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 servizio ha fallito",
  "$0 servizi hanno fallito"
 ],
 "Loading of units failed": [
  null,
  "Caricamento delle unità fallito"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Listing units": [
  null,
  "Elencando unità"
 ],
 "Filter by name or description": [
  null,
  "Filtra per nome o descrizione"
 ],
 "Active state": [
  null,
  "Stato attivo"
 ],
 "File state": [
  null,
  "Stato file"
 ],
 "$0 filters applied": [
  null,
  "$0 filtri applicati"
 ],
 "User": [
  null,
  "Utente"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "L'utente $0 non è autorizzato a modificare le mitigazioni di sicurezza della cpu"
 ],
 "Mitigations": [
  null,
  "Mitigazioni"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Versione del BIOS"
 ],
 "BIOS date": [
  null,
  "Data del BIOS"
 ],
 "CPU security": [
  null,
  "Sicurezza CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Disabilita il multithreading simultaneo"
 ],
 "Read more...": [
  null,
  "Leggi di più..."
 ],
 "Save and reboot": [
  null,
  "Salva e riavvia"
 ],
 "CPU security toggles": [
  null,
  "Impostazioni di Sicurezza della CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Soluzioni alternative basate su software aiutano a prevenire problemi di sicurezza della CPU. Queste mitigazioni hanno l'effetto collaterale di ridurre le prestazioni. Modificare queste impostazioni a proprio rischio."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Tecnologia di memoria"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Rank": [
  null,
  "Posizione"
 ],
 "Speed": [
  null,
  "Velocità"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "La visualizzazione delle informazioni sulla memoria richiede accesso amministrativo."
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "Failed to fetch logs": [
  null,
  "Impossibile recuperare i logs"
 ],
 "Clear all filters": [
  null,
  "Cancella tutti i filtri"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Non è possibile trovare alcun log utilizzando l'attuale combinazione di filtri."
 ],
 "No logs found": [
  null,
  "Nessun log trovato"
 ],
 "Load earlier entries": [
  null,
  "Carica voci precedenti"
 ],
 "You may try to load older entries.": [
  null,
  "Puoi provare a caricare voci precedenti."
 ],
 "Allow running (unmask)": [
  null,
  "Consenti esecuzione (unmask)"
 ],
 "Reload": [
  null,
  "Ricarica"
 ],
 "Restart": [
  null,
  "Riavvia"
 ],
 "Stop": [
  null,
  "Arresta"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Clear 'Failed to start'": [
  null,
  "Cancella 'Impossibile avviare'"
 ],
 "Mask service": [
  null,
  "Maschera servizio"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Il mascheramento del servizio impedisce l'avvio di tutte le unità da esso dipendenti. Questo può avere un impatto maggiore del previsto. Conferma di voler mascherare questa unità."
 ],
 "Disallow running (mask)": [
  null,
  "Non consentire l'esecuzione (mask)"
 ],
 "Unpin unit": [
  null,
  "Sblocca unità"
 ],
 "Pin unit": [
  null,
  "Unità pinnate"
 ],
 "Additional actions": [
  null,
  "Azioni aggiuntive"
 ],
 "Note": [
  null,
  "Note"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Questa unità non è stata progettata per essere abilitata esplicitamente."
 ],
 "Forbidden from running": [
  null,
  "Esecuzione non autorizzata"
 ],
 "Start service": [
  null,
  "Avvia il servizio"
 ],
 "Active since ": [
  null,
  "Attivo dal "
 ],
 "Required by ": [
  null,
  "Richiesto da "
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Requires administration access to edit": [
  null,
  "Richiede accesso amministrativo per la modifica"
 ],
 "Automatically starts": [
  null,
  "Si avvia automaticamente"
 ],
 "Updating status...": [
  null,
  "Aggiornamento dello stato..."
 ],
 "Stop and disable": [
  null,
  "Ferma e Disabilita"
 ],
 "Start and enable": [
  null,
  "Avvia e Abilita"
 ],
 "Failed to load unit": [
  null,
  "Impossibile carica l'unità"
 ],
 "View all services": [
  null,
  "Visualizza tutti i servizi"
 ],
 "Triggers": [
  null,
  "Trigger"
 ],
 "Triggered by": [
  null,
  "Attivato da"
 ],
 "Requires": [
  null,
  "Ha bisogno di"
 ],
 "Requisite": [
  null,
  "Requisito"
 ],
 "Wants": [
  null,
  "Vuole"
 ],
 "Binds to": [
  null,
  "Si lega a"
 ],
 "Part of": [
  null,
  "Parte di"
 ],
 "Required by": [
  null,
  "Richiesto da"
 ],
 "Requisite of": [
  null,
  "Requisito di"
 ],
 "Wanted by": [
  null,
  "Ricercato da"
 ],
 "Bound by": [
  null,
  "Legato da"
 ],
 "Consists of": [
  null,
  "Consiste di"
 ],
 "Conflicts": [
  null,
  "Conflitti"
 ],
 "Conflicted by": [
  null,
  "Conflitto da"
 ],
 "Before": [
  null,
  "Prima"
 ],
 "After": [
  null,
  "Dopo"
 ],
 "On failure": [
  null,
  "In caso di fallimento"
 ],
 "Propagates reload to": [
  null,
  "Propagati ricarica su"
 ],
 "Reload propagated from": [
  null,
  "Ricarica propagato da"
 ],
 "Joins namespace of": [
  null,
  "Associa al namespace di"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condizione $0=$1 non soddisfatta"
 ],
 "Deletion will remove the following files:": [
  null,
  "L'eliminazione rimuoverà i seguenti file:"
 ],
 "Pinned unit": [
  null,
  "Unità pinnate"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Path": [
  null,
  "Percorso"
 ],
 "Listen": [
  null,
  "Ascolta"
 ],
 "Container": [
  null,
  "Container"
 ],
 "View Podman container": [
  null,
  "Visualizza il contenitore Podman"
 ],
 "Condition failed": [
  null,
  "Condizione non riuscita"
 ],
 "Show more relationships": [
  null,
  "Mostra più relazioni"
 ],
 "Show relationships": [
  null,
  "Mostra relazioni"
 ],
 "Confirm deletion of $0": [
  null,
  "Conferma la cancellazione di $0"
 ],
 "Timer deletion failed": [
  null,
  "Eliminazione timer fallita"
 ],
 "Targets": [
  null,
  "Destinazioni"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Paths": [
  null,
  "Percorsi"
 ],
 "Go to $0": [
  null,
  "Vai a $0"
 ],
 "Journal entry not found": [
  null,
  "Voce del registro non trovata"
 ],
 "Journal entry": [
  null,
  "Voce del registro"
 ],
 "Entry at $0": [
  null,
  "Voce a $0"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Loading unit failed": [
  null,
  "Caricamento unità fallito"
 ],
 "Service logs": [
  null,
  "Log servizi"
 ],
 "No log entries": [
  null,
  "Nessuna voce nel log"
 ],
 "Systemd units": [
  null,
  "Unità systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Nessun risultato corrisponde ai criteri del filtro. Cancella tutti i filtri per mostrare i risultati."
 ],
 "Does not automatically start": [
  null,
  "Non si avvia automaticamente"
 ],
 "Cannot be enabled": [
  null,
  "Non può essere abilitato"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La Web Console è in esecuzione in modalità di accesso limitato."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Questo strumento configura il sistema per scrivere i dump di crash del kernel. Supporta le destinazioni di dump \"locale\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "da $0 su $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "da $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "su $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Dominio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Entra in un dominio"
 ]
});
