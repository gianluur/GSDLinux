cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-kontit"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "kontti"
 ],
 "image": [
  null,
  "levykuva"
 ]
});
