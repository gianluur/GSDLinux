cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "unmount": [
  null,
  "odmontowanie"
 ],
 "mount": [
  null,
  "montowanie"
 ],
 "format": [
  null,
  "format"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "system plików"
 ],
 "partition": [
  null,
  "partycja"
 ],
 "nfs": [
  null,
  "NFS"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "volume": [
  null,
  "wolumin"
 ],
 "disk": [
  null,
  "dysk"
 ],
 "vdo": [
  null,
  "VDO"
 ],
 "iscsi": [
  null,
  "iSCSI"
 ],
 "drive": [
  null,
  "napęd"
 ],
 "udisks": [
  null,
  "UDisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "LVM2"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "encryption": [
  null,
  "szyfrowanie"
 ],
 "nbde": [
  null,
  "NBDE"
 ],
 "tang": [
  null,
  "Tang"
 ],
 "Managing partitions": [
  null,
  "Zarządzanie partycjami"
 ],
 "Managing NFS mounts": [
  null,
  "Zarządzanie punktami montowania NFS"
 ],
 "Managing RAIDs": [
  null,
  "Zarządzanie RAID"
 ],
 "Managing LVMs": [
  null,
  "Zarządzanie LVM"
 ],
 "Managing physical drives": [
  null,
  "Zarządzanie napędami fizycznymi"
 ],
 "Managing VDOs": [
  null,
  "Zarządzanie VDO"
 ],
 "Using LUKS encryption": [
  null,
  "Używanie szyfrowania LUKS"
 ],
 "Using Tang server": [
  null,
  "Używanie serwera Tang"
 ]
});
