cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Удалить $0?"
 ],
 "Force delete": [
  null,
  "Принудительно удалить"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Must be a valid IP address": [
  null,
  "Должен быть действительный IP-адрес"
 ],
 "1 to 65535": [
  null,
  "От 1 до 65535"
 ],
 "Container port must not be empty": [
  null,
  "Порт контейнера не должен быть пустым"
 ],
 "IP address": [
  null,
  "IP-адрес"
 ],
 "IP address help": [
  null,
  "Справка по IP-адресу"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Если IP хоста установлен в 0.0.0.0 или не установлен, порт будет привязан ко всем IP-адресам на хосте."
 ],
 "Host port": [
  null,
  "Порт хоста"
 ],
 "Host port help": [
  null,
  "Справка по порту хоста"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Если порт хоста не задан, порту контейнера будет случайным образом назначен порт на хосте."
 ],
 "Container port": [
  null,
  "Порт контейнера"
 ],
 "Protocol": [
  null,
  "Протокол"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Удалить элемент"
 ],
 "Image name is required": [
  null,
  "Требуется имя образа"
 ],
 "Image name is not unique": [
  null,
  "Имя образа не уникально"
 ],
 "Failed to commit container $0": [
  null,
  "Не удалось сохранить контейнер $0"
 ],
 "New image name": [
  null,
  "Новое имя образа"
 ],
 "Tag": [
  null,
  "Метка"
 ],
 "Author": [
  null,
  "Автор"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Например, Ваше Имя <yourname@example.com>"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Pause container when creating image": [
  null,
  "Приостановить контейнер при создании образа"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Формат Docker полезен при обмене образом с Docker или Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Использовать устаревший формат Docker"
 ],
 "Commit container": [
  null,
  "Сохранить контейнер"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Создать новый образ на основе текущего состояния контейнера $0."
 ],
 "Commit": [
  null,
  "Сохранить"
 ],
 "Force commit": [
  null,
  "Принудительное сохранение"
 ],
 "Failed to force remove container $0": [
  null,
  "Не удалось принудительно удалить контейнер $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Удаление работающего контейнера приведёт к удалению всех данных в нём."
 ],
 "Failed to stop container $0": [
  null,
  "Не удалось остановить контейнер $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Не удалось остановить quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Не удалось запустить quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Не удалось запустить контейнер $0"
 ],
 "Failed to resume container $0": [
  null,
  "Не удалось возобновить контейнер $0"
 ],
 "Failed to pause container $0": [
  null,
  "Не удалось приостановить контейнер $0"
 ],
 "Failed to restart container $0": [
  null,
  "Не удалось перезапустить контейнер $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Не удалось перезапустить quadlet $0"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Restart": [
  null,
  "Перезапустить"
 ],
 "Force stop": [
  null,
  "Принудительная остановка"
 ],
 "Force restart": [
  null,
  "Принудительный перезапуск"
 ],
 "Pause": [
  null,
  "Приостановить"
 ],
 "Resume": [
  null,
  "Возобновить"
 ],
 "Checkpoint": [
  null,
  "Контрольная точка"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Restore": [
  null,
  "Восстановить"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Healthy": [
  null,
  "Работоспособен"
 ],
 "Unhealthy": [
  null,
  "Неработоспособен"
 ],
 "Checking health": [
  null,
  "Проверка состояния"
 ],
 "Prune unused containers": [
  null,
  "Очистить неиспользуемые контейнеры"
 ],
 "Terminal not available": [
  null,
  "Терминал недоступен"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Этот браузер не поддерживает WebGL2."
 ],
 "View $0 logs": [
  null,
  "Просмотреть журналы $0"
 ],
 "not available": [
  null,
  "недоступно"
 ],
 "n/a": [
  null,
  "н/д"
 ],
 "$0% of $1 limit": [
  null,
  "$0% от $1 лимита"
 ],
 "service": [
  null,
  "служба"
 ],
 "system": [
  null,
  "система"
 ],
 "user:": [
  null,
  "пользователь:"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Integration": [
  null,
  "Интеграция"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Console": [
  null,
  "Консоль"
 ],
 "Health check": [
  null,
  "Проверка состояния"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "Memory": [
  null,
  "Память"
 ],
 "Click to see published ports": [
  null,
  "Нажмите, чтобы увидеть опубликованные порты"
 ],
 "ports": [
  null,
  "порты"
 ],
 "Click to see volumes": [
  null,
  "Нажмите, чтобы увидеть тома"
 ],
 "volumes": [
  null,
  "тома"
 ],
 "Container": [
  null,
  "Контейнер"
 ],
 "Owner": [
  null,
  "Владелец"
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Actions": [
  null,
  "Действия"
 ],
 "No containers": [
  null,
  "Нет контейнеров"
 ],
 "No containers in this pod": [
  null,
  "Нет контейнеров в этом модуле"
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "No containers that match the current filter": [
  null,
  "Нет контейнеров, соответствующих текущему фильтру"
 ],
 "No running containers": [
  null,
  "Нет работающих контейнеров"
 ],
 "Show": [
  null,
  "Показать"
 ],
 "All": [
  null,
  "Все"
 ],
 "Only running": [
  null,
  "Только работающие"
 ],
 "Create pod": [
  null,
  "Создать модуль"
 ],
 "Create container": [
  null,
  "Создать контейнер"
 ],
 "Containers": [
  null,
  "Контейнеры"
 ],
 "Create container in pod": [
  null,
  "Создать контейнер в модуле"
 ],
 "pod": [
  null,
  "модуль"
 ],
 "Failed to restore container $0": [
  null,
  "Не удалось восстановить контейнер $0"
 ],
 "Restore container $0": [
  null,
  "Восстановить контейнер $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Сохранять все временные файлы контрольных точек"
 ],
 "Restore with established TCP connections": [
  null,
  "Восстановить с установленными TCP-соединениями"
 ],
 "Ignore IP address if set statically": [
  null,
  "Игнорировать IP-адрес, если он задан статически"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Игнорировать MAC-адрес, если он задан статически"
 ],
 "Pod failed to be created": [
  null,
  "Не удалось создать модуль"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Недопустимые символы. Имя может содержать только буквы, цифры и определённые знаки пунктуации (_ . -)."
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Pod name": [
  null,
  "Имя модуля"
 ],
 "System": [
  null,
  "Система"
 ],
 "User:": [
  null,
  "Пользователь:"
 ],
 "No ports exposed": [
  null,
  "Порты не открыты"
 ],
 "Port mapping": [
  null,
  "Перенаправление портов"
 ],
 "Add port mapping": [
  null,
  "Добавить перенаправление портов"
 ],
 "No volumes specified": [
  null,
  "Тома не указаны"
 ],
 "Volumes": [
  null,
  "Тома"
 ],
 "Add volume": [
  null,
  "Добавить том"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Type to filter…": [
  null,
  "Введите для фильтрации…"
 ],
 "Container path must not be empty": [
  null,
  "Путь в контейнере не должен быть пустым"
 ],
 "Host path": [
  null,
  "Путь на хосте"
 ],
 "Container path": [
  null,
  "Путь в контейнере"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Writable": [
  null,
  "Доступен для записи"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Нет метки"
 ],
 "Shared": [
  null,
  "Общий"
 ],
 "Private": [
  null,
  "Частный"
 ],
 "Read-write access": [
  null,
  "Чтение и запись"
 ],
 "Read-only access": [
  null,
  "Только чтение"
 ],
 "Show less": [
  null,
  "Показать меньше"
 ],
 "Show more": [
  null,
  "Показать больше"
 ],
 "Loading details...": [
  null,
  "Загрузка данных..."
 ],
 "Ports": [
  null,
  "Порты"
 ],
 "Environment variables": [
  null,
  "Переменные среды"
 ],
 "Failed to download image $0:$1": [
  null,
  "Не удалось загрузить образ $0:$1"
 ],
 "Error message": [
  null,
  "Сообщение об ошибке"
 ],
 "unused": [
  null,
  "неиспользуемый"
 ],
 "$0 container": [
  null,
  "$0 контейнер",
  "$0 контейнера",
  "$0 контейнеров"
 ],
 "History": [
  null,
  "История"
 ],
 "Image": [
  null,
  "Образ"
 ],
 "Created": [
  null,
  "Создан"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Место на диске"
 ],
 "Used by": [
  null,
  "Используется"
 ],
 "No images": [
  null,
  "Нет образов"
 ],
 "No images that match the current filter": [
  null,
  "Нет образов, соответствующих текущему фильтру"
 ],
 "Hide intermediate images": [
  null,
  "Скрыть промежуточные образы"
 ],
 "Show intermediate images": [
  null,
  "Показать промежуточные образы"
 ],
 "Images": [
  null,
  "Образы"
 ],
 "$0 image total, $1": [
  null,
  "Всего $0 образ, $1",
  "Всего $0 образа, $1",
  "Всего $0 образов, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 неиспользуемый образ, $1",
  "$0 неиспользуемых образа, $1",
  "$0 неиспользуемых образов, $1"
 ],
 "Hide images": [
  null,
  "Скрыть образы"
 ],
 "Show images": [
  null,
  "Показать образы"
 ],
 "Pulling": [
  null,
  "Загрузка"
 ],
 "Download new image": [
  null,
  "Загрузить новый образ"
 ],
 "Pull all images": [
  null,
  "Загрузить все образы"
 ],
 "Prune unused images": [
  null,
  "Очистить неиспользуемые образы"
 ],
 "Pull": [
  null,
  "Загрузить"
 ],
 "Up since:": [
  null,
  "Работает с:"
 ],
 "Exited": [
  null,
  "Остановлен"
 ],
 "systemd service": [
  null,
  "служба systemd"
 ],
 "View $0": [
  null,
  "Просмотр $0"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "MAC address": [
  null,
  "MAC-адрес"
 ],
 "Latest checkpoint": [
  null,
  "Последняя контрольная точка"
 ],
 "No containers are using this image": [
  null,
  "Ни один контейнер не использует этот образ"
 ],
 "Running": [
  null,
  "Работает"
 ],
 "Loading logs...": [
  null,
  "Загрузка журналов..."
 ],
 "Delete unused system images:": [
  null,
  "Удалить неиспользуемые системные образы:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Удалить неиспользуемые образы пользователя $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Не удалось очистить неиспользуемые образы"
 ],
 "Pruning images": [
  null,
  "Очистка образов"
 ],
 "Prune": [
  null,
  "Очистить"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Не удалось создать контрольную точку контейнера $0"
 ],
 "Checkpoint container $0": [
  null,
  "Создать контрольную точку контейнера $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Оставить запущенным после записи контрольной точки на диск"
 ],
 "Support preserving established TCP connections": [
  null,
  "Поддержка сохранения установленных TCP-соединений"
 ],
 "Failed to search for new images": [
  null,
  "Не удалось найти новые образы"
 ],
 "Failed to search for images: $0": [
  null,
  "Не удалось выполнить поиск образов: $0"
 ],
 "Failed to search for images.": [
  null,
  "Не удалось выполнить поиск образов."
 ],
 "Search for an image": [
  null,
  "Поиск образа"
 ],
 "Search for": [
  null,
  "Найти"
 ],
 "Search by name or description": [
  null,
  "Поиск по имени или описанию"
 ],
 "in": [
  null,
  "в"
 ],
 "All registries": [
  null,
  "Все реестры"
 ],
 "Searching...": [
  null,
  "Поиск..."
 ],
 "No images found": [
  null,
  "Образы не найдены"
 ],
 "Start typing to look for images.": [
  null,
  "Начните вводить текст для поиска образов."
 ],
 "No results for $0": [
  null,
  "Нет результатов для $0"
 ],
 "Retry another term.": [
  null,
  "Попробуйте другой запрос."
 ],
 "Download": [
  null,
  "Скачать"
 ],
 "No action": [
  null,
  "Без действий"
 ],
 "Container failed to be started": [
  null,
  "Не удалось запустить контейнер"
 ],
 "Failed to clean up container": [
  null,
  "Не удалось очистить контейнер"
 ],
 "Container failed to be created": [
  null,
  "Не удалось создать контейнер"
 ],
 "downloading": [
  null,
  "загрузка"
 ],
 "Failed to run container $0": [
  null,
  "Не удалось запустить контейнер $0"
 ],
 "Failed to create container $0": [
  null,
  "Не удалось создать контейнер $0"
 ],
 "Failed to pull image $0": [
  null,
  "Не удалось загрузить образ $0"
 ],
 "Local images": [
  null,
  "Локальные образы"
 ],
 "Name already in use": [
  null,
  "Имя уже используется"
 ],
 "Search by registry": [
  null,
  "Поиск по реестру"
 ],
 "Local": [
  null,
  "Локальный"
 ],
 "Container name": [
  null,
  "Имя контейнера"
 ],
 "Owner help": [
  null,
  "Справка по владельцу"
 ],
 "Ideal for running services": [
  null,
  "Идеально для запуска служб"
 ],
 "Resource limits can be set": [
  null,
  "Лимиты ресурсов могут быть установлены"
 ],
 "Checkpoint and restore support": [
  null,
  "Поддержка контрольных точек и восстановления"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Порты ниже 1024 могут быть перенаправлены"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Ideal for development": [
  null,
  "Идеально для разработки"
 ],
 "Restricted by user account permissions": [
  null,
  "Ограничено правами учётной записи пользователя"
 ],
 "Image selection help": [
  null,
  "Справка по выбору образа"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "хост[:порт]/[пользователь]/контейнер[:метка]"
 ],
 "Example: $0": [
  null,
  "Пример: $0"
 ],
 "Searching: $0": [
  null,
  "Поиск: $0"
 ],
 "Search string or container location": [
  null,
  "Строка поиска или расположение контейнера"
 ],
 "Pull latest image": [
  null,
  "Загрузить последний образ"
 ],
 "Entrypoint": [
  null,
  "Точка входа"
 ],
 "With terminal": [
  null,
  "С терминалом"
 ],
 "Memory limit": [
  null,
  "Лимит памяти"
 ],
 "Decrease memory": [
  null,
  "Уменьшить память"
 ],
 "Increase memory": [
  null,
  "Увеличить память"
 ],
 "Memory unit": [
  null,
  "Единица памяти"
 ],
 "KB": [
  null,
  "КБ"
 ],
 "MB": [
  null,
  "МБ"
 ],
 "GB": [
  null,
  "ГБ"
 ],
 "CPU shares": [
  null,
  "Доли ЦП"
 ],
 "CPU Shares help": [
  null,
  "Справка по долям ЦП"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Доли ЦП определяют приоритет работающих контейнеров. Приоритет по умолчанию — 1024. Более высокое число повышает приоритет этого контейнера. Более низкое число снижает приоритет."
 ],
 "Decrease CPU shares": [
  null,
  "Уменьшить доли ЦП"
 ],
 "Increase CPU shares": [
  null,
  "Увеличить доли ЦП"
 ],
 "Restart policy": [
  null,
  "Политика перезапуска"
 ],
 "Restart policy help": [
  null,
  "Справка по политике перезапуска"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Политика перезапуска при завершении контейнеров. Использование linger для автоматического запуска контейнеров может не работать в некоторых случаях, например, когда на учётной записи пользователя используются ecryptfs, systemd-homed, NFS или двухфакторная аутентификация."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Политика перезапуска при завершении контейнеров."
 ],
 "No": [
  null,
  "Нет"
 ],
 "On failure": [
  null,
  "При сбое"
 ],
 "Always": [
  null,
  "Всегда"
 ],
 "Maximum retries": [
  null,
  "Максимум попыток"
 ],
 "Decrease maximum retries": [
  null,
  "Уменьшить максимум попыток"
 ],
 "Increase maximum retries": [
  null,
  "Увеличить максимум попыток"
 ],
 "No environment variables specified": [
  null,
  "Переменные среды не указаны"
 ],
 "Add variable": [
  null,
  "Добавить переменную"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Вставьте одну или несколько строк с парами ключ=значение в любое поле для массового импорта"
 ],
 "Interval": [
  null,
  "Интервал"
 ],
 "Health check interval help": [
  null,
  "Справка по интервалу проверки состояния"
 ],
 "Interval how often health check is run.": [
  null,
  "Интервал, с которым выполняется проверка состояния."
 ],
 "Decrease interval": [
  null,
  "Уменьшить интервал"
 ],
 "Increase interval": [
  null,
  "Увеличить интервал"
 ],
 "seconds": [
  null,
  "секунды"
 ],
 "Timeout": [
  null,
  "Таймаут"
 ],
 "Health check timeout help": [
  null,
  "Справка по таймауту проверки состояния"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Максимальное время, отведённое на выполнение проверки состояния, после которого интервал считается неудачным."
 ],
 "Decrease timeout": [
  null,
  "Уменьшить таймаут"
 ],
 "Increase timeout": [
  null,
  "Увеличить таймаут"
 ],
 "Start period": [
  null,
  "Начальный период"
 ],
 "Health check start period help": [
  null,
  "Справка по начальному периоду проверки состояния"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Время инициализации, необходимое для запуска контейнера."
 ],
 "Decrease start period": [
  null,
  "Уменьшить начальный период"
 ],
 "Increase start period": [
  null,
  "Увеличить начальный период"
 ],
 "Retries": [
  null,
  "Попытки"
 ],
 "Health check retries help": [
  null,
  "Справка по попыткам проверки состояния"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Количество попыток, после которых проверка состояния считается неудачной."
 ],
 "Decrease retries": [
  null,
  "Уменьшить попытки"
 ],
 "Increase retries": [
  null,
  "Увеличить попытки"
 ],
 "When unhealthy": [
  null,
  "При неработоспособности"
 ],
 "Health failure check action help": [
  null,
  "Справка по действию при сбое проверки состояния"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Действие при переходе контейнера в неработоспособное состояние."
 ],
 "Create container in $0": [
  null,
  "Создать контейнер в $0"
 ],
 "Create and run": [
  null,
  "Создать и запустить"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Version": [
  null,
  "Версия"
 ],
 "Links": [
  null,
  "Ссылки"
 ],
 "Documentation": [
  null,
  "Документация"
 ],
 "Tags": [
  null,
  "Теги"
 ],
 "Created by": [
  null,
  "Создан"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Comments": [
  null,
  "Комментарии"
 ],
 "Unable to load image history": [
  null,
  "Не удалось загрузить историю образа"
 ],
 "Key must not be empty": [
  null,
  "Ключ не должен быть пустым"
 ],
 "Key must not begin with a digit": [
  null,
  "Ключ не должен начинаться с цифры"
 ],
 "Key contains invalid characters": [
  null,
  "Ключ содержит недопустимые символы"
 ],
 "Key": [
  null,
  "Ключ"
 ],
 "Value": [
  null,
  "Значение"
 ],
 "user": [
  null,
  "пользователь"
 ],
 "Podman service failed": [
  null,
  "Сбой службы Podman"
 ],
 "Troubleshoot": [
  null,
  "Диагностика"
 ],
 "Failed to force remove image $0": [
  null,
  "Не удалось принудительно удалить образ $0"
 ],
 "intermediate image": [
  null,
  "промежуточный образ"
 ],
 "Failed to remove image $0": [
  null,
  "Не удалось удалить образ $0"
 ],
 "intermediate": [
  null,
  "промежуточный"
 ],
 "Delete $0 image?": [
  null,
  "Удалить образ $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Для этого образа существует несколько тегов. Выберите помеченные образы для удаления."
 ],
 "Delete image": [
  null,
  "Удалить образ"
 ],
 "Delete tagged images": [
  null,
  "Удалить помеченные образы"
 ],
 "Container is not running": [
  null,
  "Контейнер не запущен"
 ],
 "Error occurred while connecting console": [
  null,
  "Произошла ошибка при подключении консоли"
 ],
 "Force delete pod $0?": [
  null,
  "Принудительно удалить модуль $0?"
 ],
 "Delete pod $0?": [
  null,
  "Удалить модуль $0?"
 ],
 "An error occurred": [
  null,
  "Произошла ошибка"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Пустой модуль $0 будет безвозвратно удалён."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Удаление этого модуля приведёт к удалению следующих контейнеров:"
 ],
 "Failed to start pod $0": [
  null,
  "Не удалось запустить модуль $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Не удалось остановить модуль $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Не удалось перезапустить модуль $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Не удалось возобновить модуль $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Не удалось приостановить модуль $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Не удалось очистить неиспользуемые контейнеры"
 ],
 "Removes selected non-running containers": [
  null,
  "Удаляет выбранные неработающие контейнеры"
 ],
 "Pruning containers": [
  null,
  "Очистка контейнеров"
 ],
 "Container name is required.": [
  null,
  "Требуется имя контейнера."
 ],
 "Failed to rename container $0": [
  null,
  "Не удалось переименовать контейнер $0"
 ],
 "New container name": [
  null,
  "Новое имя контейнера"
 ],
 "Rename container $0": [
  null,
  "Переименовать контейнер $0"
 ],
 "Paused": [
  null,
  "Приостановлена"
 ],
 "Stopped": [
  null,
  "Остановлен"
 ],
 "Removing": [
  null,
  "Удаление"
 ],
 "Configured": [
  null,
  "Настроен"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "$0 second": [
  null,
  "$0 секунда",
  "$0 секунды",
  "$0 секунд"
 ],
 "Status": [
  null,
  "Статус"
 ],
 "Failing streak": [
  null,
  "Количество неудач подряд"
 ],
 "Failed to run health check on container $0": [
  null,
  "Не удалось выполнить проверку состояния контейнера $0"
 ],
 "Run health check": [
  null,
  "Запустить проверку состояния"
 ],
 "Last 5 runs": [
  null,
  "Последние 5 запусков"
 ],
 "Started at": [
  null,
  "Запущен в"
 ],
 "Passed health run": [
  null,
  "Успешная проверка состояния"
 ],
 "Failed health run": [
  null,
  "Неудачная проверка состояния"
 ],
 "Failed to remove container $0": [
  null,
  "Не удалось удалить контейнер $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Удаление контейнера приведёт к удалению всех данных в нём."
 ]
});
