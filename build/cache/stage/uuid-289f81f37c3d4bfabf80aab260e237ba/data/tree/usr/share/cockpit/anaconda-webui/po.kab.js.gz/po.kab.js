cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "kab",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 n tuccḍa",
  "$0 n tuccḍiwin"
 ],
 "$0 installation": [
  null,
  "Asbeddi n $0"
 ],
 "$0 installer": [
  null,
  "Aseɣẓan n usbeddi $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 i laqen, maca ala $1 i yellan."
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 ad yettwakkes"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Anagraw n yifuyla '$0' ur yezmir ara ad yili ɣef yibenk n yiḥder yettwawgelhen"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' ilaq ad yili ɣef yibenk yettwameslen ɣer '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "D amiḍan n useqdac ameslugan yesɛan addaf n unedbal i usenfel deg unagraw s umata."
 ],
 "Abort installation": [
  null,
  "Sefsex asbeddi"
 ],
 "About": [
  null,
  "Ɣef"
 ],
 "Account": [
  null,
  "Amiḍan"
 ],
 "Actions": [
  null,
  "Tigawin"
 ],
 "Add another server...": [
  null,
  "Rnu aqeddac nniḍen…"
 ],
 "Add mount": [
  null,
  "Rnu tanqiḍt n userkeb"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Izegrar i twennaḍt-ik·im yettwafernen"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Izegrar ur ulmisen ara ɣer twennaḍt-ik·im"
 ],
 "Additional languages": [
  null,
  "Tutlayin nniḍen"
 ],
 "Additional software for the selected environment": [
  null,
  "Iseɣẓanen imernan i twennaḍt yettwafernen"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Isenfal akk ara deg umaẓrag n uḥraz ad ttwaṭṭfen imir."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Ibenkan akk yesseqdacen tafyirt-a n uɛeddi ad asen-ikkes usekkeṛ"
 ],
 "Anaconda Web UI": [
  null,
  "Agrudem Web n Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Asebter n usenfaṛ n Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Snes tikci n tenqiḍt n userkeb syen sebded"
 ],
 "Applying changes...": [
  null,
  "Asnas n ibeddilen..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Mudd iḥricen i tenqiḍin n userkeb. Igerrez i tneɣrufin tudmawanin n twila tuzwirt."
 ],
 "Automatic log file upload": [
  null,
  "Asali n ufaylu n uɣmis s wudem awurman"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Sbaddu azemz akked wakud s wudem awurman s useqdec n yiqeddacen n wakud"
 ],
 "Automatically set timezone": [
  null,
  "Sbadu tamnaḍṭ tasragant s wudem awurman"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Tallunt tilellit yellan: $1. : $0. Asebded yettwasra: $1."
 ],
 "Back": [
  null,
  "Uɣal"
 ],
 "Base environment": [
  null,
  "Tawennaḍt n uzadur"
 ],
 "Brief description of the issue": [
  null,
  "Aglam awezzlan n wugur"
 ],
 "Bug report details": [
  null,
  "Talqayt n uneqqis n tuccḍa"
 ],
 "Bugzilla API key": [
  null,
  "Tasarut API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Ma tkemmleḍ aseqdec n useɣẓan-a, tegziḍ u tqebleḍ ayen ara d-yeḍrun i icudden ɣer yiseɣẓanen uzwiren, meḥsub ad tesqedceḍ aya i usekyed d usnefli n yisumar kan yerna tebɣiḍ ad d-temmleḍ ibugen neɣ uguren i usnerni n umahil-a."
 ],
 "Cancel": [
  null,
  "Sefsex"
 ],
 "Change": [
  null,
  "Ẓreg"
 ],
 "Change destination": [
  null,
  "Beddel taɣerwaḍt"
 ],
 "Change hostname": [
  null,
  "Senfel asenneftaɣ"
 ],
 "Change partition layout": [
  null,
  "Snifel taneɣruft n uḥric"
 ],
 "Change system keyboard layout": [
  null,
  "Beddel taneɣruft n unasiw n unagraw"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Isenfal yettwagen dagi ad ṭṭfen imir ɣef unagraw. Ulac akk 'asefsex'."
 ],
 "Checking installation configuration...": [
  null,
  "Asenqed n tawila n usbeddi…"
 ],
 "Checking storage configuration": [
  null,
  "Asenqed n usesteb n uḥraz"
 ],
 "Clear search": [
  null,
  "Sfeḍ anadi"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Sit ɣer \"Ɣer zdat\" akken ad tkemleḍ xas akken llan isenkiden-agi."
 ],
 "Close": [
  null,
  "Mdel"
 ],
 "Close storage editor": [
  null,
  "Mdel amaẓrag n uḥraz"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Aḥraz Cockpit ur imudd ara tafyirt n uɛeddi i tukksa n usekkeṛ i yibenk yettwawgelhen."
 ],
 "Completed": [
  null,
  "Immed"
 ],
 "Configuration is incomplete": [
  null,
  "Tawila d tarummidt"
 ],
 "Configure NTP servers": [
  null,
  "Tawila n iqeddacen NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Swel iqeddacen NTP udmawanen"
 ],
 "Configure network": [
  null,
  "Swel aẓeṭṭa"
 ],
 "Configure storage": [
  null,
  "Sesteb aḥraz"
 ],
 "Configure storage again": [
  null,
  "Sesteb aḥraz i tikkelt niḍen"
 ],
 "Confirm passphrase": [
  null,
  "Sentem tafyirt n uɛeddi"
 ],
 "Continue": [
  null,
  "Kemmel"
 ],
 "Continue installation": [
  null,
  "Kemmel asbeddi"
 ],
 "Continue installation?": [
  null,
  "Kemmel asbeddi?"
 ],
 "Continue with installation": [
  null,
  "Kemmel d usebded"
 ],
 "Correct these issues before continuing.": [
  null,
  "Ṣeggem tuccḍiwin-a send ad t-kemmleḍ."
 ],
 "Create Account": [
  null,
  "Snulfu-d amiḍan"
 ],
 "Create account": [
  null,
  "Snulfu-d amiḍan"
 ],
 "Currently installed: $0": [
  null,
  "Akken kan yettwasbedd: $0"
 ],
 "Custom": [
  null,
  "Sagen"
 ],
 "Date": [
  null,
  "Azemz"
 ],
 "Date and time": [
  null,
  "Azemz d wakud"
 ],
 "Delete partition": [
  null,
  "Kkes aḥric"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Tukksa n kra n yiḥricen yezmer ad iɛekkeṛ asenker n $0: $1"
 ],
 "Description": [
  null,
  "Aglam"
 ],
 "Destination": [
  null,
  "Tanila"
 ],
 "Destination is encrypted": [
  null,
  "Tanila tettwawgelhen"
 ],
 "Detailed description of the issue": [
  null,
  "Aglam leqqayen n wugur"
 ],
 "Detected valid storage layout:": [
  null,
  "Tifin n tneɣruft n uḥraz tameɣtut:"
 ],
 "Device": [
  null,
  "Ibenk"
 ],
 "Duplicate device.": [
  null,
  "Yettuɛawed-d yibenk."
 ],
 "Duplicate mount point.": [
  null,
  "Tettuɛawed-d tenqiḍt n userkeb."
 ],
 "Enable root account": [
  null,
  "Rmed amiḍan aẓar"
 ],
 "Encrypt my data": [
  null,
  "Wgelhen isefka-w"
 ],
 "Encrypted": [
  null,
  "Yettwawgelhen"
 ],
 "Encryption": [
  null,
  "Awgelhen"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Sekcem tasarutt-ik·im API Bugzilla i tmerna n uneqqis n tuccḍa. Ad tizmireḍ ad twaliḍ sakin ad tẓergeḍ talqayt n ubug deg uḥric i d-iteddun."
 ],
 "Environment": [
  null,
  "Tawennaḍt"
 ],
 "Erase data and install": [
  null,
  "Sfeḍ isefka syen sebded"
 ],
 "Error details": [
  null,
  "Talqayt n tuccḍa"
 ],
 "Exit to live desktop": [
  null,
  "Ffeɣ ɣer tnarit tusridt"
 ],
 "Extended partition": [
  null,
  "Aḥric ɣezzifen"
 ],
 "Failed to report issue": [
  null,
  "Tuzna n tuccḍa ur teddi ara"
 ],
 "Failed to save layouts": [
  null,
  "Asekles n tneɣrufin ur yeddi ara"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux yesra xerṣum $0 seg tallunt n uḍebsi."
 ],
 "Finalization": [
  null,
  "Afakki"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Afakki: Tawila n unagraw temmed. Afakki n usbeddi yezmer ad yeṭṭef kra n wakud."
 ],
 "Find layout": [
  null,
  "Af-d taneɣruft"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "I wugar n tɣellist, ur seqdac ara, srid, amiḍan aẓar root. Deg nnuba-s, seqdec amiḍan-nni adigan i yellan nnig-a, i usefrek n unagraw."
 ],
 "Full name": [
  null,
  "Isem ummid"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Isem ummid ur yezmir ara ad yesɛu isekkilen s sin wagazen"
 ],
 "Helper text": [
  null,
  "Aḍris n tallalt"
 ],
 "Hide API key": [
  null,
  "Ffer tasarut API"
 ],
 "Hide confirmed password": [
  null,
  "Ffer awal n uɛeddi yettwasnetmen"
 ],
 "Hide passphrase": [
  null,
  "Ffer tafyirt n uɛeddi"
 ],
 "Hide password": [
  null,
  "Ffer awal n uɛeddi"
 ],
 "Hostname": [
  null,
  "Isem n usenneftaɣ"
 ],
 "How would you like to install?": [
  null,
  "Amek i yebɣiḍ ad yeddu usbeddi?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Gziɣ belli akk isefka i yellan ad ttwasefḍen",
  "Gziɣ belli akk isefka i yellan ad ttwasefḍen seg iḍebsiyen yettwafranen"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Gziɣ belli kra n yisefka i yellan ad ttwasefḍen"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Gziɣ belli kra n yiḥricen ad ttwasneflen"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Ma yella d ilem, isem n usenneftaɣ d aɛeddi kan syen ad yettusbadu s telɣur n uzeṭṭa."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Ma yella tebɣiḍ ad tgeḍ asesteb s ufus, iḥricen-a ttwasran:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ma yella ur tegziḍ ara iwellihen neɣ ayen ara yeḍrun, ttxil-k ffeɣ seg wahil."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Iteddu"
 ],
 "Initializing...": [
  null,
  "Awennez..."
 ],
 "Install": [
  null,
  "Sbedd"
 ],
 "Installation failed": [
  null,
  "Yecceḍ usbeddi"
 ],
 "Installation method": [
  null,
  "Tarrayt n usbeddi"
 ],
 "Installation of the system failed": [
  null,
  "Asebded n unagraw yecceḍ"
 ],
 "Installation of the system failed: $0": [
  null,
  "Asbeddi n unagraw yecceḍ: $0"
 ],
 "Installation type": [
  null,
  "Anaw n usbeddi"
 ],
 "Installing": [
  null,
  "Yessebdad"
 ],
 "Insufficient disk space": [
  null,
  "Ur d-yeqqim ara littseɛ deg uḍebsi"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  "Asenneftaɣ d arameɣtu"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Eǧǧ taneɣruft-a n uḍebsi, tesqedceḍ tallunt i yellan i usekker ayugan akked unagraw n wammud nniḍen."
 ],
 "Keyboard": [
  null,
  "Anasiw"
 ],
 "Keyboard layout during boot": [
  null,
  "Taneɣruft n unasiw mi ara yekker unagraw"
 ],
 "Language": [
  null,
  "Tutlayt"
 ],
 "Launch storage editor": [
  null,
  "Senker amaẓrag n uḥraz"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Issin ugar ɣef wadduf s talast deg twila"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Eǧǧ urtiyen n tefyirt n uɛeddi d ilmawen i sin, i wakken ad tesqedceḍ awal n uɛeddi ilem."
 ],
 "Location": [
  null,
  "Adig"
 ],
 "Locked devices": [
  null,
  "Ibenkan isekkṛen"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  "Err-it d amiran"
 ],
 "Manual disk configuration": [
  null,
  "Tawil n uḍbsi s ufus"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Tawila n uḍebsi s ufus: Sbadu tinqiḍin n userkeb"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Yezmer ad yesɛu isekkilen, imḍanen akked yijerriḍen."
 ],
 "May need more free space": [
  null,
  "Yezmer lḥal ad yiḥwiǧ ugar n tallunt tilellit"
 ],
 "Medium": [
  null,
  "Alemmas"
 ],
 "Minimum of $0 required": [
  null,
  "Ma drus $0 i ilaqen"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Ugur deg ufran umṣada n yibenkan amaraw d yibenk aqcic ara yalsen amsal."
 ],
 "Mount point": [
  null,
  "Tanqiḍt n userkeb"
 ],
 "Mount point assignment": [
  null,
  "Tikci n tenqiḍin n userkeb"
 ],
 "Move down": [
  null,
  "Err-it d akessar"
 ],
 "Move up": [
  null,
  "Err-it d asawen"
 ],
 "Must be at least $0 characters": [
  null,
  "Ilaq ad yesɛu ma drus $0 n yisekkilen"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Iqeddacen n NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Isem"
 ],
 "Needs at least $0": [
  null,
  "Ilaq ma drus $0"
 ],
 "Network": [
  null,
  "Aẓeṭṭa"
 ],
 "Network Configuration": [
  null,
  "Tawila n uẓeṭṭa"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Ulac azeṭṭa. Sesteb azeṭṭa deg wumuɣ n ufeggag usawen i tummla n wugur."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Ulac azeṭṭa. Sesteb azeṭṭa i tummla n wugur."
 ],
 "Network plugin failed": [
  null,
  "Azegrir n uẓeṭṭa yecceḍ"
 ],
 "Next": [
  null,
  "Uḍfir"
 ],
 "No devices": [
  null,
  "Ulac ibenkan"
 ],
 "No disks available": [
  null,
  "Ulac iḍebsiyen i yellan"
 ],
 "No disks selected": [
  null,
  "Ulac iḍebsiyen i yettwafernen"
 ],
 "No layouts selected yet": [
  null,
  "Ulac tineɣrufin yettwafernen yakan"
 ],
 "No results found": [
  null,
  "Ulac igmad yettwafen"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "Ur d-tkeffu ara tallunt tilellit i yellan"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Ulac ddeqs n tallunt tilellit ɣef yiḍebsiyen i yettwafernen."
 ],
 "Not enough space on selected disks.": [
  null,
  "Ulac ddeqs n tallunt deg yiḍebsiyen i yettwafernen."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Ulac ibenkan ara yettwaseqdacen ɣef yiḍebsiyen i yettwafernen."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Ldi tiferkit n unekcum n tuccḍa deg Bugzilla"
 ],
 "Operating system": [
  null,
  "Anagraw n wammud"
 ],
 "Options": [
  null,
  "Tixtiṛiyin"
 ],
 "Other keyboards": [
  null,
  "Inasiwen nniḍen"
 ],
 "Partitions (advanced)": [
  null,
  "Iḥricen (talqayt)"
 ],
 "Passphrase": [
  null,
  "Tafyirt n uɛeddi"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Tafyirt n uɛeddi ur temṣada ara ula d yiwen yibenk yettwasekkṛen"
 ],
 "Passphrases must match": [
  null,
  "Tifyar n uɛeddi ilaq ad mṣadant"
 ],
 "Pending": [
  null,
  "Yettṛaǧu"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Ttxil seddu afaylu n uɣmis $0 akked wugur."
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "Ttxil-k·m, fren ma ulac yiwen n uḍebsi akken ad tkemmleḍ"
 ],
 "Pool": [
  null,
  "Azagu"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "S lmendad n Anaconda"
 ],
 "Pre-release": [
  null,
  "Lqem uzwir"
 ],
 "Prefer to report manually? $0": [
  null,
  "Smenyif tuzna s ufus i uneqqis? $0"
 ],
 "Proceed with installation": [
  null,
  "Kemmel asebded"
 ],
 "Quit": [
  null,
  "Ffeɣ"
 ],
 "Quit installer?": [
  null,
  "Ffeɣ seg useɣẓan n usbeddi?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Tecceḍ tɣuri n telɣut yerzan unagraw OS yeccḍen."
 ],
 "Reading information about the computer failed.": [
  null,
  "Tecceḍ tɣuri n telɣut yerzan aselkim."
 ],
 "Reading installer configuration failed.": [
  null,
  "Tecceḍ tɣuri n twila n useɣẓan n usbeddi."
 ],
 "Reading installer version information failed.": [
  null,
  "Tecceḍ tɣuri n telɣut n lqem n useɣẓan n usbeddi."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Isem n usenneftaɣ ilaw yezmer ad ilin kan deg-s yisekkilen, izwilen, ijerriḍen (slid deg tazwara akked taggara) akked wagazen"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Isem n usenneftaɣ ilaw ilaq ad yesɛu 64 yisekkilen neɣ ddaw"
 ],
 "Reboot": [
  null,
  "Ales asenker"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Ales asenker ar Windows i usemsawi n teɣzi n yiḥricen yettwawgelhen s BitLocker. Eǧǧ ma drus $0 n tallunt d tilemt i usebded."
 ],
 "Reboot system?": [
  null,
  "Ales asenker n unagraw?"
 ],
 "Reclaim additional space": [
  null,
  "Err-d ugar n tallunt"
 ],
 "Reclaim space": [
  null,
  "Err-d tallunt"
 ],
 "Reclaim space (required)": [
  null,
  "Err-d tallunt (yettwasra)"
 ],
 "Recommended": [
  null,
  "Yettuwelleh"
 ],
 "Recommended partitions:": [
  null,
  "Iḥricen yettuwellhen:"
 ],
 "Reformat": [
  null,
  "Ales amsal"
 ],
 "Reinstall Fedora": [
  null,
  "Aɛiwed n usbeddi n Fedora"
 ],
 "Remove": [
  null,
  "Kkes"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Kkes akk iḥricen ɣef yibenkan yettwafernen, ula d inagrawen n wammud i yellan."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Kkes neɣ semsawi inagrawen n yifuyla i uslelli n tallunt i usebdeddi."
 ],
 "Remove server": [
  null,
  "Kkes aqeddac"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Tukksiwin n unagraw n yifuyla ad yekkes akk isefka yellan deg-s. Allus n beṭṭu n uḥric yezmer ad d-yebru i tallunt ur nettwaseqdac ara, maca yella deg-s umihi. Ur ttettu ara, ilaq-ak·am ad tesɛuḍ aḥraz n kra yellan d axatar uqbel ad d-terreḍ tallunt."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Beddel asebded amiran, maca ḥrez ifuyla yellan deg /home."
 ],
 "Report Issue": [
  null,
  "Mmel Ugur"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Mmel ugur"
 ],
 "Reporting issue...": [
  null,
  "Mmel ugur…"
 ],
 "Required": [
  null,
  "Yettwasra"
 ],
 "Requirements": [
  null,
  "Issutar"
 ],
 "Rescan devices": [
  null,
  "Ales aḍummu n yibenkan"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Yecceḍ wallus n uḍummu n yiḍebsiyen."
 ],
 "Resize": [
  null,
  "Semsawi teɣzi"
 ],
 "Resize partition": [
  null,
  "Ales tisekta n weḥric"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Asemsawi n teɣzi n yiḥricen-a seg $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Eg talast n wadduf ɣer uneqqis"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Eg talast n wadduf ɣer uneqqis i wagraw $0. $1"
 ],
 "Return to installation": [
  null,
  "Uɣal ɣer usebded"
 ],
 "Return to storage editor": [
  null,
  "Uɣal ɣer umaẓrag n uḥraz"
 ],
 "Review and install": [
  null,
  "Senqed syen sebded"
 ],
 "Root account is enabled": [
  null,
  "Amiḍan n waẓar (root) yermed"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Amiḍan n waẓar root yermed, maca ula d yiwen n umiḍan n useqdac ur yettuswwel"
 ],
 "Root password has been set.": [
  null,
  "Awal n uɛeddi aẓar yettusbadu."
 ],
 "Save": [
  null,
  "Sekles"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Ḍumm tangalt QR s tiliɣri-ik·im neɣ rzu ɣer:"
 ],
 "Search for a language": [
  null,
  "Nadi ɣef tutlayt"
 ],
 "Search for additional software": [
  null,
  "Nadi ɣef yiseɣẓanen-nniḍen"
 ],
 "Search for an environment": [
  null,
  "Nadi ɣef twennaḍ"
 ],
 "Search keyboard layout": [
  null,
  "Nadi ɣef tneɣruft n unasiw"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Sɣelles isefka-inek·inem s uwgelhan n uḍebsi. Yettwasnes kan i yeḥricen imaynuten"
 ],
 "Select": [
  null,
  "Fren"
 ],
 "Select a device": [
  null,
  "Fren ibenk"
 ],
 "Select city": [
  null,
  "Fren tiɣremt"
 ],
 "Select destination": [
  null,
  "Fren tanila"
 ],
 "Select region": [
  null,
  "Fren tamnaḍt"
 ],
 "Selected (top = current)": [
  null,
  "Yettwafren (afella = amiran)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Amasal n yibenk '$0' i yettwafernen ur yezmir ara ad yales amsal."
 ],
 "Send us feedback on your installation": [
  null,
  "Azen-aɣ-d tamawt-ik·im ɣef usebded"
 ],
 "Server": [
  null,
  "Aqeddac"
 ],
 "Server is not reachable": [
  null,
  "Aqeddac ur yettwawaḍ ara"
 ],
 "Set custom hostname": [
  null,
  "Sbadu asenneftaɣ udmawan"
 ],
 "Share disk with other operating systems": [
  null,
  "Bḍu aḍebsi-a akked inagrawen n wammud nniḍen"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Bḍu aḍebsi akked unagraw n wamud niḍen: $0"
 ],
 "Show AM/PM": [
  null,
  "Sken-d AM/PM"
 ],
 "Show API key": [
  null,
  "Sken-d tasarut API"
 ],
 "Show confirmed password": [
  null,
  "Sken awal n uɛeddi yettusnetmen"
 ],
 "Show passphrase": [
  null,
  "Sken tafyirt n uɛeddi"
 ],
 "Show password": [
  null,
  "Sken-d awal n uɛeddi"
 ],
 "Size": [
  null,
  "Teɣzi"
 ],
 "Software installation": [
  null,
  "Asebded n yiseɣẓanen"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Asebded n useɣẓan: Tawila n uḥraz temmed. Aseɣẓan la ttwasbeddaden tura ɣef yibenk-ik·im."
 ],
 "Software selection": [
  null,
  "Afran n yiseɣẓanen"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Mazal ilaq kra n yisurifen n usbeddi ad fakken uqbel ad tkemmleḍ."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Kra n yiḥricen i yettwasrn xuṣṣen: $0"
 ],
 "Space": [
  null,
  "Tallunt"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Aḥraz"
 ],
 "Storage configuration": [
  null,
  "Tawila n uḥraz"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Tawila n uḥraz: Aḥraz la yettwasestab."
 ],
 "Storage editor": [
  null,
  "Amaẓrag n uḥraz"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Aḥraz yebna ɣef twila n wumuɣ 'Senfel aḥraz'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Azegrir n uḥraz yecceḍ"
 ],
 "Storage requirements not met": [
  null,
  "Issutar n uḥraz ur ttuqadaren ara"
 ],
 "Strong": [
  null,
  "Yeǧhed"
 ],
 "Successfully installed": [
  null,
  "Yettwasebded akken iwata"
 ],
 "Successfully unlocked $0.": [
  null,
  "Yekkes-as usekkeṛ akken iwata i $0."
 ],
 "Suggested keyboards": [
  null,
  "Inasiwen d-yettwasumren"
 ],
 "Suggested languages": [
  null,
  "Tutlayin i d-yettwasumren"
 ],
 "System": [
  null,
  "Anagraw"
 ],
 "System configuration": [
  null,
  "Tawila n unagraw"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Tawila n unagraw: Asebded n useɣẓan yemmed. Anagraw la yettusestab."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Yeḥbes usbeddi n Anaconda s yiwet n tarrayt ur tt-nerǧa ara akk."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Aseqdac-a ad yettwarnu:",
  "Iseqdacen-a ad ttwarnun:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Asbeddi yeḥwaǧ $0 n tallunt n uḍebsi; d acu kan, ala $1 yettwafen deg ukettur n yiḍebsiyen."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Aseɣẓan n usbeddi ur yezmir ara ad ikemmel ssebba n tuccḍan tuzɣint."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Aseɣẓan n usbeddi ur yezmir ara ad ikemmel ssebba n tuccḍan tuzɣint: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Tafyirt n uɛeddi i d-tmuddeḍ deg-s isekkilen ur nelli d ASCII. Tzemreḍ ad tbeddleḍ tineɣrufin n unasiw mi ara ten-tettaruḍ."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "Isem-a n usenneftaɣ ur yezmir ara ad yettwazen"
 ],
 "This is unstable, pre-release software": [
  null,
  "Iseɣẓanen-a n lqem uzwir ur rkiden ara"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Taneɣruft-a ad yettwasseqdec i tukksa n uskweṛ n unagraw-inek·inem mi ara yekker"
 ],
 "This may take a moment": [
  null,
  "Aya yezmer ad yeṭṭef cwiṭ n wakud"
 ],
 "This will take a few moments": [
  null,
  "Ad yeṭṭef kra n wakud"
 ],
 "Time": [
  null,
  "Akud"
 ],
 "Timezone": [
  null,
  "Tamnaḍt tasragant"
 ],
 "Title": [
  null,
  "Azwel"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Ales asenker i unagraw-inek·inem akken ad tebdud aseqdec n $0."
 ],
 "To continue, select the devices to install to.": [
  null,
  "I ukemmel, fren ibenkan iɣef ara tesbeddeḍ."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "I useqdec n textiṛt-a, semsawi teɣzi neɣ kkes iḥricen yellan i uslelli xerṣum $0 n tallunt."
 ],
 "Type": [
  null,
  "Anaw"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "D awezɣi aseɣwes n tukksa n $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "D awezɣi aseɣwes n usemsawi n teɣzi n $0"
 ],
 "Undo last action": [
  null,
  "Sefsex tigawt taneggarut"
 ],
 "Unlock": [
  null,
  "Kkes asekkeṛ"
 ],
 "Unlock encrypted devices": [
  null,
  "Kkes asekkeṛ i yibenkan yettwawgelhen"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "Use configured storage": [
  null,
  "Seqdec aḥraz yettwassetben"
 ],
 "Use entire disk": [
  null,
  "Seqdec akk aḍebsi"
 ],
 "Use free space": [
  null,
  "Sseqdec tallunt tilellit"
 ],
 "Use local account": [
  null,
  "Seqdec amiḍan adigan"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Seqdec ibenk RAID i beṭṭu awurman ɣef yiḥricen"
 ],
 "User creation": [
  null,
  "Asnulfu n useqdac"
 ],
 "User name": [
  null,
  "Isem n useqdac"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Isem n useqdac ilaq ad ilin kan deg-s: isekkilen seg a-z, izwilen seg 0-9, ijerriḍen $0, agazen $1, ijerriḍen ddaw $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Isem n useqdac ur ilaq ara ad yili d win yettwaḥarran"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Ismawen n useqdac ilaq ad ilin ddaw n 33 yisekkilen"
 ],
 "Validating...": [
  null,
  "Aseɣbel…"
 ],
 "Weak": [
  null,
  "Afessas"
 ],
 "Welcome": [
  null,
  "Ansuf"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Ansuf ar Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Ansuf yis-k·m. Iyya ad nesbedd $0 tura."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Iḥricen n Windows yettwawgelhen s BitLocker ulamek msawan deg teɣzi"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Tzemreḍ ad tferneḍ ad tselelliḍ ugar n tallunt dagi yerna ad teǧǧeḍ asbeddi ad issefrek ayen niḍen i yiman-is, neɣ sbadu s ufus iḥricen."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Tzemreḍ ad tessarweḍ tasarut API i umiḍan-ik Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Yessefk ad tremdeḍ amiḍan aẓar root neɣ ad d-tesnulfuḍ amiḍan adigan n useqdac o wakken ad kemmleḍ."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Yessefk ad teqqneḍ ɣer uẓeṭṭa akken ad tremdeḍ azemz awurman d wakud."
 ],
 "Your progress will not be saved.": [
  null,
  "Akala-k ur yettwaseklas ara."
 ],
 "completed step": [
  null,
  "takkayt yemmden"
 ],
 "current step": [
  null,
  "takkayt tamirant"
 ],
 "delete": [
  null,
  "kkes"
 ],
 "edit": [
  null,
  "ẓreg"
 ],
 "encrypt": [
  null,
  "wgelhen"
 ],
 "encrypted": [
  null,
  "yettwawgelhen"
 ],
 "extended partition": [
  null,
  "aḥric ɣezzifen"
 ],
 "format as $0": [
  null,
  "amasal am $0"
 ],
 "here": [
  null,
  "da"
 ],
 "incomplete": [
  null,
  "d arurmid"
 ],
 "mount": [
  null,
  "serkeb"
 ],
 "pending step": [
  null,
  "takkayt yettṛaǧun"
 ],
 "report the issue manually": [
  null,
  "mmel-d ugur s ufus"
 ],
 "resized from $0": [
  null,
  "temsawi teɣzi-s seg $0"
 ],
 "shrink": [
  null,
  "semẓẓiy"
 ],
 "shrink to $0": [
  null,
  "semẓẓiy ɣer $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "sefsex"
 ]
});
