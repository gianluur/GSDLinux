cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Berkas Cockpit"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Unable to create bookmark directory": [
  null,
  "Tidak dapat membuat direktori penanda"
 ],
 "Unable to save bookmark file": [
  null,
  "Tidak dapat menyimpan berkas penanda"
 ],
 "Remove from bookmarks": [
  null,
  "Hapus dari penanda"
 ],
 "Add to bookmarks": [
  null,
  "Tambahkan ke penanda"
 ],
 "Bookmarks": [
  null,
  "Penanda"
 ],
 "Bookmarked": [
  null,
  "Ditandai"
 ],
 "Not bookmarked": [
  null,
  "Tidak ditandai"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Edit path": [
  null,
  "Sunting jalur"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "Largest size": [
  null,
  "Ukuran terbesar"
 ],
 "Smallest size": [
  null,
  "Ukuran terkecil"
 ],
 "Modified": [
  null,
  "Diubah"
 ],
 "First modified": [
  null,
  "Pertama diubah"
 ],
 "Last modified": [
  null,
  "Terakhir diubah"
 ],
 "Owner": [
  null,
  "Pemilik"
 ],
 "Owner ascending": [
  null,
  "Pemilik menaik"
 ],
 "Owner descending": [
  null,
  "Pemilik menurun"
 ],
 "Permissions": [
  null,
  "Izin"
 ],
 "Most permissive": [
  null,
  "Paling permisif"
 ],
 "Least permissive": [
  null,
  "Paling terbatas"
 ],
 "Show keyboard shortcuts": [
  null,
  "Tampilkan pintasan keyboard"
 ],
 "Filter directory": [
  null,
  "Saring direktori"
 ],
 "Display as a list": [
  null,
  "Tampilkan sebagai daftar"
 ],
 "Display as a grid": [
  null,
  "Tampilkan sebagai kisi"
 ],
 "Sort": [
  null,
  "Urutkan"
 ],
 "Hide hidden items": [
  null,
  "Sembunyikan item tersembunyi"
 ],
 "Show hidden items": [
  null,
  "Tampilkan item tersembunyi"
 ],
 "$0 files": [
  null,
  "$0 berkas"
 ],
 "Uploaded as $0, $1": [
  null,
  "Diunggah sebagai $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Ganti berkas $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Berkas dengan nama yang sama sudah ada di \"$0\". Menggantikannya akan menimpa isinya."
 ],
 "New file": [
  null,
  "Berkas baru"
 ],
 "Original file on server": [
  null,
  "Berkas asli di server"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Terapkan tindakan ini ke semua berkas yang bentrok"
 ],
 "Replace": [
  null,
  "Ganti"
 ],
 "Keep original": [
  null,
  "Pertahankan yang asli"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "Upload error": [
  null,
  "Kesalahan unggahan"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Tidak dapat memindahkan berkas yang diunggah ke tujuan akhir"
 ],
 "Cancelled": [
  null,
  "Dibatalkan"
 ],
 "Cancelled upload of $0": [
  null,
  "Unggahan $0 dibatalkan"
 ],
 "File uploaded": [
  null,
  "Berkas berhasil diunggah"
 ],
 "Files uploaded": [
  null,
  "Berkas berhasil diunggah"
 ],
 "Change permissions": [
  null,
  "Ubah izin"
 ],
 "Uploads": [
  null,
  "Unggahan"
 ],
 "Cancel upload of $0": [
  null,
  "Batalkan unggahan $0"
 ],
 "Upload $0% completed": [
  null,
  "Unggahan $0% selesai"
 ],
 "Upload": [
  null,
  "Unggah"
 ],
 "None": [
  null,
  "Tidak ada"
 ],
 "Execute-only": [
  null,
  "Hanya-eksekusi"
 ],
 "Write-only": [
  null,
  "Hanya-tulis"
 ],
 "Write and execute": [
  null,
  "Tulis dan eksekusi"
 ],
 "Read-only": [
  null,
  "Hanya-baca"
 ],
 "Read and execute": [
  null,
  "Baca dan eksekusi"
 ],
 "Read and write": [
  null,
  "Baca dan tulis"
 ],
 "Read, write, and execute": [
  null,
  "Baca, tulis, dan eksekusi"
 ],
 "Block device": [
  null,
  "Perangkat blok"
 ],
 "Character device": [
  null,
  "Perangkat karakter"
 ],
 "Directory": [
  null,
  "Direktori"
 ],
 "Named pipe": [
  null,
  "Pipa bernama"
 ],
 "Symbolic link": [
  null,
  "Tautan simbolik"
 ],
 "Regular file": [
  null,
  "Berkas biasa"
 ],
 "Socket": [
  null,
  "Soket"
 ],
 "Name cannot be empty": [
  null,
  "Nama tidak boleh kosong"
 ],
 "Name too long": [
  null,
  "Nama terlalu panjang"
 ],
 "Name cannot include a /": [
  null,
  "Nama tidak boleh mengandung /"
 ],
 "Filename is the same as original name": [
  null,
  "Nama berkas sama dengan nama aslinya"
 ],
 "Directory with the same name exists": [
  null,
  "Direktori dengan nama yang sama sudah ada"
 ],
 "File exists": [
  null,
  "Berkas sudah ada"
 ],
 "Pasting failed": [
  null,
  "Gagal menempel"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" sudah ada, tidak menimpa dengan tempel (paste)."
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Create directory": [
  null,
  "Buat direktori"
 ],
 "Create file": [
  null,
  "Buat berkas"
 ],
 "Edit permissions": [
  null,
  "Sunting izin"
 ],
 "Open in terminal": [
  null,
  "Buka di terminal"
 ],
 "Open text file": [
  null,
  "Buka berkas teks"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Rename": [
  null,
  "Ganti nama"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Download": [
  null,
  "Unduh"
 ],
 "Create link": [
  null,
  "Buat tautan"
 ],
 "Drop files to upload": [
  null,
  "Jatuhkan berkas untuk diunggah"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Tidak dapat menjatuhkan berkas, unggahan lain sedang berlangsung"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Go up a directory": [
  null,
  "Naik satu direktori"
 ],
 "Go back": [
  null,
  "Kembali"
 ],
 "Go forward": [
  null,
  "Maju"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktifkan item yang dipilih, masuk ke direktori"
 ],
 "Rename selected file or directory": [
  null,
  "Ganti nama berkas atau direktori yang dipilih"
 ],
 "Create new directory": [
  null,
  "Buat direktori baru"
 ],
 "Copy selected file or directory": [
  null,
  "Salin berkas atau direktori yang dipilih"
 ],
 "Paste file or directory": [
  null,
  "Tempel berkas atau direktori"
 ],
 "Select all": [
  null,
  "Pilih semua"
 ],
 "Save current file": [
  null,
  "Simpan berkas saat ini"
 ],
 "Close editor": [
  null,
  "Tutup penyunting"
 ],
 "Keyboard shortcuts": [
  null,
  "Pintasan keyboard"
 ],
 "Navigation": [
  null,
  "Navigasi"
 ],
 "Editing": [
  null,
  "Menyunting"
 ],
 "Editor": [
  null,
  "Penyunting"
 ],
 "Force delete $0 items": [
  null,
  "Paksa hapus $0 item"
 ],
 "Delete $0 items?": [
  null,
  "Hapus $0 item?"
 ],
 "Force delete file $0?": [
  null,
  "Paksa hapus berkas $0?"
 ],
 "Delete file $0?": [
  null,
  "Hapus berkas $0?"
 ],
 "Force delete link $0?": [
  null,
  "Paksa hapus tautan $0?"
 ],
 "Delete link $0?": [
  null,
  "Hapus tautan $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Paksa hapus direktori $0?"
 ],
 "Delete directory $0?": [
  null,
  "Hapus direktori $0?"
 ],
 "Force delete $0": [
  null,
  "Paksa hapus $0"
 ],
 "Delete $0?": [
  null,
  "Hapus ( $0 )?"
 ],
 "No access": [
  null,
  "Tidak ada akses"
 ],
 "Missing type": [
  null,
  "Jenis hilang"
 ],
 "Collapse": [
  null,
  "Ciutkan"
 ],
 "Show all files": [
  null,
  "Tampilkan semua berkas"
 ],
 "$0 permissions": [
  null,
  "$0 izin"
 ],
 "Permissions for $0 files": [
  null,
  "Izin untuk $0 berkas"
 ],
 "Ownership": [
  null,
  "Kepemilikan"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Access": [
  null,
  "Akses"
 ],
 "Owner access": [
  null,
  "Akses pemilik"
 ],
 "Group access": [
  null,
  "Akses grup"
 ],
 "Others access": [
  null,
  "Akses lainnya"
 ],
 "Security context": [
  null,
  "Konteks keamanan"
 ],
 "Set executable as program": [
  null,
  "Atur eksekusi sebagai program"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Change permissions for enclosed files": [
  null,
  "Ubah izin untuk berkas yang disertakan"
 ],
 "(original owner)": [
  null,
  "(pemilik asli)"
 ],
 "keep original owners": [
  null,
  "pertahankan pemilik asli"
 ],
 "Paste as owner": [
  null,
  "Tempel sebagai pemilik"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Berkas yang ditempel memiliki pemilik yang berbeda. Secara bawaan, kepemilikan akan diubah agar sesuai dengan direktori tujuan."
 ],
 "New owner": [
  null,
  "Pemilik baru"
 ],
 "Overwrite": [
  null,
  "Timpa"
 ],
 "New filename": [
  null,
  "Nama berkas baru"
 ],
 "New name": [
  null,
  "Nama baru"
 ],
 "Rename $0?": [
  null,
  "Ganti nama $0?"
 ],
 "link to $0": [
  null,
  "tautkan ke $0"
 ],
 "Create link to $0": [
  null,
  "Buat tautan ke $0"
 ],
 "Target": [
  null,
  "Target"
 ],
 "Symlink name": [
  null,
  "Nama tautan simbolik"
 ],
 "Type": [
  null,
  "Jenis"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolut vs. Relatif"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Tautan simbolik absolut ideal digunakan untuk merujuk pada berkas atau direktori yang tidak akan berpindah, seperti berkas sistem."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Tautan simbolik relatif berguna ketika tautan dan target dapat berpindah bersamaan, seperti saat mengganti nama atau memindahkan direktori induk."
 ],
 "Absolute": [
  null,
  "Absolut"
 ],
 "Relative": [
  null,
  "Relatif"
 ],
 "The file has been removed on disk": [
  null,
  "Berkas telah dihapus dari disk"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Berkas yang ada berubah secara tidak terduga"
 ],
 "Edit $0": [
  null,
  "Sunting $0"
 ],
 "View $0": [
  null,
  "Lihat ( $0 )"
 ],
 "The file has changed on disk": [
  null,
  "Berkas telah berubah di disk"
 ],
 "Reload": [
  null,
  "Muat ulang"
 ],
 "Ignore": [
  null,
  "Abaikan"
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "Save changes?": [
  null,
  "Simpan perubahan?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Berkas dihapus setelah dibuka, menyimpan akan membuatnya kembali."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Berkas telah berubah di disk antara saat dibuka dan sekarang"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 memiliki perubahan yang belum disimpan dan akan hilang secara permanen jika dibuang."
 ],
 "Discard": [
  null,
  "Buang"
 ],
 "File name": [
  null,
  "Nama berkas"
 ],
 "Create": [
  null,
  "Buat"
 ],
 "Cannot create file in current directory": [
  null,
  "Tidak dapat membuat berkas di direktori saat ini"
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Directory name cannot be empty": [
  null,
  "Nama direktori tidak boleh kosong"
 ],
 "Directory name too long": [
  null,
  "Nama direktori terlalu panjang"
 ],
 "Directory name cannot include a /": [
  null,
  "Nama direktori tidak boleh mengandung /"
 ],
 "Directory name": [
  null,
  "Nama direktori"
 ],
 "Directory owner": [
  null,
  "Pemilik direktori"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "Clear filter": [
  null,
  "Hapus filter"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "$0 item is hidden": [
  null,
  "$0 item tersembunyi"
 ],
 "Folder": [
  null,
  "Folder"
 ],
 "File": [
  null,
  "Berkas"
 ],
 "Others": [
  null,
  "Lainnya"
 ],
 "$0 files selected": [
  null,
  "$0 berkas dipilih"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Direktori berisi $0 direktori, $1 berkas"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Direktori berisi $0 direktori, $1 berkas, $2 tersembunyi"
 ],
 "User": [
  null,
  "Pengguna"
 ]
});
