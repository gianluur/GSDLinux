cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "te",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
