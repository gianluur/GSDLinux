cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Palvelut"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "network": [
  null,
  "verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "liitäntä"
 ],
 "bridge": [
  null,
  "silta"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "sidos"
 ],
 "team": [
  null,
  "joukkue"
 ],
 "port": [
  null,
  "portti"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "palomuuri"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "vyöhyke"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Verkkosidosten hallinta"
 ],
 "Managing networking teams": [
  null,
  "Verkkojoukkojen hallinta"
 ],
 "Managing networking bridges": [
  null,
  "Verkkosiltojen hallinta"
 ],
 "Managing VLANs": [
  null,
  "VLANien hallinta"
 ],
 "Managing firewall": [
  null,
  "Palomuurin hallinta"
 ]
});
