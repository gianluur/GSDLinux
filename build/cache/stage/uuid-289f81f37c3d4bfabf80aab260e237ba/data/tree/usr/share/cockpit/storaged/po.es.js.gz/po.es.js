cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la huella de clave del anfitrión:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Add key": [
  null,
  "Añadir clave"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Select": [
  null,
  "Seleccionar"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "Set": [
  null,
  "Establecer"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Port": [
  null,
  "Puerto"
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "Trust and add host": [
  null,
  "Confiar en el anfitrión y añadirlo"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Confiar en el anfitrión y añadirlo\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "La huella resultante puede ser distribuida por medios públicos, incluyendo correo electrónico, sin riesgos. Si está pidiendo a alguien que haga la verificación por usted, pueden enviarle los resultados usando cualquier método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Se está conectando con $0 por primera vez."
 ],
 "Verify fingerprint": [
  null,
  "Verifique la huella"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Ejecute este comando en la máquina remota a través de una red de confianza o de forma física:"
 ],
 "The fingerprint should match:": [
  null,
  "La huella debería coincidir con:"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No fue capaz de iniciar sesión en $0. El hospedaje no acepta inicio de sesión por contraseña ni ninguna de sus claves SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una clave SSH nueva y autorícela"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Authorize SSH key": [
  null,
  "Autorice la clave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "Permission denied": [
  null,
  "Permiso denegado"
 ],
 "Clear input value": [
  null,
  "Vaciar valor de entrada"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP adicionales"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "Create $0": [
  null,
  "Crear $0"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "You now have administrative access.": [
  null,
  "Ahora tienes acceso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "No hay métodos disponibles para obtener acceso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentíquese para obtener acceso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Cambiar a acceso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acceso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema al cambiar a administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acceso"
 ],
 "Switch to limited access": [
  null,
  "Pasar a acceso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "El modo de acceso limitado restringe los privilegios administrativos. Algunas partes de la consola web tendrán funcionalidad reducida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Su navegador recordará su nivel de acceso entre sesiones."
 ],
 "Limited access": [
  null,
  "Acceso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar el acceso administrativo"
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "less than a minute ago": [
  null,
  "es menos que hace un minuto"
 ],
 "in less than a minute": [
  null,
  "es menos de un minuto"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Strong password": [
  null,
  "Contraseña fuerte"
 ],
 "Acceptable password": [
  null,
  "Contraseña aceptable"
 ],
 "Weak password": [
  null,
  "Contraseña débil"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "Show confirmation password": [
  null,
  "Mostrar contraseña de confirmación"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar contraseña de confirmación"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Removing $0": [
  null,
  "Retirando $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Hospedaje desconocido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña."
 ],
 "SSH key login": [
  null,
  "Clave SSH de acceso"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportó un error con código $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "Row expansion": [
  null,
  "Fila de expansión"
 ],
 "Row select": [
  null,
  "Seleccionar fila"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Error al pegar"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tu navegador no admite pegar desde el menú contextual. Puedes usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Error durante la inicialización"
 ],
 "Failed": [
  null,
  "Falló"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Teclee para filtrar"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Sistema de archivos"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Archivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Automation script": [
  null,
  "Script de automatización"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crear un archivo de tarea con este contenido."
 ],
 "Ansible roles documentation": [
  null,
  "Documentación de los roles de Ansible"
 ],
 "Shell script": [
  null,
  "Script de shell"
 ],
 "No system modifications": [
  null,
  "No hay modificaciones para el sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "El usuario autenticado no tiene permisos para ver las modificaciones del sistema"
 ],
 "Loading system modifications...": [
  null,
  "Cargando modificaciones del sistema..."
 ],
 "View automation script": [
  null,
  "Ver el script de automatización"
 ],
 "Occurrences": [
  null,
  "Ocurrencias"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo inválido"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Select an option": [
  null,
  "Seleccione una opción"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminado con señal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 finalizó con el código $1"
 ],
 "$0 failed": [
  null,
  "$0 incorrecto"
 ],
 "Your session has been terminated.": [
  null,
  "Su sesión se ha terminado."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Su sesión ha expirado. Por favor inicie sesión otra vez."
 ],
 "Not permitted to perform this action.": [
  null,
  "No está permitido llevar a cabo esta acción."
 ],
 "Login failed": [
  null,
  "Inicio de sesión fallido"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "El servido rehusó autenticar usando los métodos soportados."
 ],
 "Untrusted host": [
  null,
  "Anfitrión no seguro"
 ],
 "Host key is incorrect": [
  null,
  "La tecla del anfitrión es incorrecta"
 ],
 "Internal error": [
  null,
  "Error interno"
 ],
 "Connection has timed out.": [
  null,
  "La conexión ha caducado."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit no está instalado en el sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "No se pueden transferir los datos de acceso"
 ],
 "Server has closed the connection.": [
  null,
  "El servidor ha cerrado la conexión."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit no es compatible con el software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit no se pudo conectar con el anfitrión especificado."
 ],
 "Too much data": [
  null,
  "Demasiados datos"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "View logs": [
  null,
  "Ver todos los registros"
 ],
 "Dismiss": [
  null,
  "Despedir"
 ],
 "edit": [
  null,
  "editar"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "none": [
  null,
  "ninguno"
 ],
 "Not found": [
  null,
  "No se ha encontrado"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Running": [
  null,
  "Ejecutando"
 ],
 "Not running": [
  null,
  "No está ejecutándose"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "User": [
  null,
  "Usuario"
 ],
 "Vendor": [
  null,
  "Proveedor"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Stop": [
  null,
  "Detener"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirme el borrado de $0"
 ],
 "Username": [
  null,
  "Usuario"
 ],
 "Actions": [
  null,
  "Acciones"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Delete group": [
  null,
  "Eliminar grupo"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Lock": [
  null,
  "Bloquear"
 ],
 "Use $0": [
  null,
  "Utilice $0"
 ],
 "Service": [
  null,
  "Servicio"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Address": [
  null,
  "Dirección"
 ],
 "$0 disk is missing": [
  null,
  "Falta $0 disco",
  "Faltan $0 discos"
 ],
 "Location": [
  null,
  "Ubicación"
 ],
 "Compression": [
  null,
  "Compresión"
 ],
 "Storage logs": [
  null,
  "Registros de almacenamiento"
 ],
 "Name cannot be empty.": [
  null,
  "Nombre no puede estar vacío."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nombre no puede superar los 127 caracteres."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nombre no puede contener el carácter «$0»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nombre no puede contener espacios."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nombre no puede superar los $0 caracteres"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nombre no puede superar los $0 bytes"
 ],
 "$name (from $host)": [
  null,
  "$name (del $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Grupo de volúmenes de aprovisionamiento fino"
 ],
 "Thin logical volume": [
  null,
  "Volumen lógico fino"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volumen lógico(Instantánea)"
 ],
 "Logical volume": [
  null,
  "Volumen lógico"
 ],
 "MDRAID device $0": [
  null,
  "Dispositivo MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupo de volúmenes LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volumen lógico cifrado de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partición cifrada de $0"
 ],
 "Logical volume of $0": [
  null,
  "Volumen lógico de $0"
 ],
 "Partition of $0": [
  null,
  "Partición de $0"
 ],
 "Encrypted $0": [
  null,
  "$0 cifrado"
 ],
 "unpartitioned space on $0": [
  null,
  "espacio no particionado en $0"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "mount": [
  null,
  "mount"
 ],
 "remove from btrfs volume": [
  null,
  "quitar del volumen btrfs"
 ],
 "stop": [
  null,
  "detener"
 ],
 "remove from MDRAID": [
  null,
  "quitar del MDRAID"
 ],
 "remove from LVM2": [
  null,
  "quitar de LVM2"
 ],
 "btrfs device": [
  null,
  "Dispositivo btrfs"
 ],
 "btrfs volume": [
  null,
  "Volumen btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Nombre no puede superar los 255 caracteres."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Nombre no puede contener el carácter «/»."
 ],
 "Create and mount": [
  null,
  "Crear y montar"
 ],
 "Create only": [
  null,
  "Sólo crear"
 ],
 "Create subvolume": [
  null,
  "Crear un subvolumen"
 ],
 "Mount Point": [
  null,
  "Punto de montaje"
 ],
 "delete": [
  null,
  "Eliminar"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "¿Eliminar el subvolumen $0 permanentemente?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "El borrado elimina todos los datos en este subvolumen y todos sus heredados."
 ],
 "Edit mount point": [
  null,
  "Editar punto de montaje"
 ],
 "Unmount": [
  null,
  "Desmontar"
 ],
 "Mount": [
  null,
  "Montar"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Al menos un subvolumen necesita estar montado"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "No se puede ser borrado el último subvolúmen montado"
 ],
 "btrfs subvolume": [
  null,
  "Subvolumen btrfs"
 ],
 "Snapshot origin": [
  null,
  "Instantánea origen"
 ],
 "Mount point": [
  null,
  "Punto de montaje"
 ],
 "No subvolumes": [
  null,
  "No hay subvolúmenes"
 ],
 "btrfs subvolumes": [
  null,
  "Subvolúmenes btrfs"
 ],
 "Snapshots": [
  null,
  "Instantáneas"
 ],
 "No snapshots found": [
  null,
  "No se encontró instantánea"
 ],
 "snapshot": [
  null,
  "instantánea"
 ],
 "$0 is in use": [
  null,
  "$0 está en uso"
 ],
 "Permanently delete $0?": [
  null,
  "¿Eliminar $0 permanentemente?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Borrar elimina todos los datos en un volumen btrfs."
 ],
 "Delete filesystem": [
  null,
  "Borrar sistema de archivos"
 ],
 "Change label": [
  null,
  "Cambiar etiqueta"
 ],
 "Filesystem is mounted read-only": [
  null,
  "El sistema de archivos está montado para solo lectura"
 ],
 "Label": [
  null,
  "Etiqueta"
 ],
 "Capacity": [
  null,
  "Capacidad"
 ],
 "btrfs devices": [
  null,
  "Dispositivos btrfs"
 ],
 "No devices found": [
  null,
  "No se encontraron dispositivos"
 ],
 "btrfs filesystem": [
  null,
  "Sistema de archivos btrfs"
 ],
 "Successful": [
  null,
  "Correcto"
 ],
 "Aborted": [
  null,
  "Interrumpido"
 ],
 "In progress": [
  null,
  "En curso"
 ],
 "Interrupted": [
  null,
  "Interrumpido"
 ],
 "Did not complete": [
  null,
  "No completado"
 ],
 "Failed (Unknown)": [
  null,
  "Incorrecto (desconocido)"
 ],
 "Failed (Electrical)": [
  null,
  "Incorrecto (eléctrico)"
 ],
 "Failed (Servo)": [
  null,
  "Incorrecto (servidor)"
 ],
 "Failed (Read)": [
  null,
  "Incorrecto (lectura)"
 ],
 "Failed (Damaged)": [
  null,
  "Incorrecto (dañado)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Interrumpido por un Restablecimiento de Nivel de Controladora"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Interrumpido debido a una retirada de un espacio de nombre desde el inventario del espacio de nombre"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Interrumpido debido al procesado de una instrucción de Formato NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Sucedió un error fatal durante la operación de auto-prueba"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Completado con un segmento que fallaba y el segmento que falló no es conocido"
 ],
 "Completed with one or more failed segments": [
  null,
  "Completado con uno o más segmentos incorrectos"
 ],
 "Aborted for unknown reason": [
  null,
  "Interrumpido por razón desconocida"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Interrumpido debido a operación de purga"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Capacidad distribuida está por debajo del umbral"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatura fuera de los umbrales recomendados"
 ],
 "Degraded": [
  null,
  "Degradado"
 ],
 "All media is in read-only mode": [
  null,
  "Todos los medios están en modo de solo lectura"
 ],
 "Volatile memory backup failed": [
  null,
  "Respaldo de memoria volátil incorrecto"
 ],
 "Persistent memory has become read-only": [
  null,
  "La memoria persistente se ha vuelto de solo lectura"
 ],
 "Run short test": [
  null,
  "Ejecutar pruebas breves"
 ],
 "Run extended test": [
  null,
  "Ejecutar texto extendido"
 ],
 "Abort test": [
  null,
  "Interrumpir prueba"
 ],
 "Disk is failing": [
  null,
  "El disco está fallando"
 ],
 "Disk is OK": [
  null,
  "El disco está OK"
 ],
 "Assessment": [
  null,
  "Evaluación"
 ],
 "Power on hours": [
  null,
  "Energía en horas"
 ],
 "$0 hours": [
  null,
  "$0 horas"
 ],
 "Self-test status": [
  null,
  "Estado auto-diagnóstico"
 ],
 "Number of bad sectors": [
  null,
  "Número de sectores incorrectos"
 ],
 "Attributes failing": [
  null,
  "Atributos defectuosos"
 ],
 "Media drive": [
  null,
  "Unidad de medios"
 ],
 "Solid State Drive": [
  null,
  "Unidad de Estado Sólido"
 ],
 "Hard Disk Drive": [
  null,
  "Controlador de Disco Duro"
 ],
 "iSCSI Drive": [
  null,
  "Disco iSCSI"
 ],
 "Drive": [
  null,
  "Disco"
 ],
 "Device health (SMART)": [
  null,
  "Salud de la unidad (SMART)"
 ],
 "Firmware version": [
  null,
  "Versión del firmware"
 ],
 "Serial number": [
  null,
  "Número de serie"
 ],
 "World wide name": [
  null,
  "Nombre World Wide"
 ],
 "No media inserted": [
  null,
  "No hay un medio insertado"
 ],
 "Device file": [
  null,
  "Fichero de dispositivo"
 ],
 "Multipathed devices": [
  null,
  "Dispositivos multiruta"
 ],
 "Free space": [
  null,
  "Espacio libre"
 ],
 "Create partition": [
  null,
  "Crear una partición"
 ],
 "Extended partition": [
  null,
  "Partición extendida"
 ],
 "$0 partitions": [
  null,
  "$0 particiones"
 ],
 "Partitions": [
  null,
  "Particiones"
 ],
 "No partitions found": [
  null,
  "No se encontraron particiones"
 ],
 "Unexpected partitions": [
  null,
  "Particiones inesperadas"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Las particiones no están admitidas en este dispositivo de bloque. Si es utilizada como un disco para una máquina virtual, las particiones deben ser gestionadas por el sistema operativo interno a la máquina virtual."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Eliminando una partición borrará toda la información que hay en ella."
 ],
 "No free space after this partition": [
  null,
  "No hay espacio libre después de esta partición"
 ],
 "EFI system partition": [
  null,
  "Partición de sistema EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partición de arranque BIOS"
 ],
 "Partition": [
  null,
  "Partición"
 ],
 "Shrink": [
  null,
  "Encogimiento"
 ],
 "Grow": [
  null,
  "Crecer"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partición de arranque PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "Área de intercambio Linux"
 ],
 "Linux filesystem data": [
  null,
  "Sistema de archivos de datos Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partición del gestor de volúmenes Logical Volume Manager"
 ],
 "Custom": [
  null,
  "Personalizado"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tipo debe contener exactamente dos caracteres hexadecimales (0 a 9, A a F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tipo sólo puede contener los caracteres de 0 a 9, de A a F y «-»."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tipo debe tener el formato NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Establecer el tipo de partición de $0"
 ],
 "Custom type": [
  null,
  "Tipo personalizado"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Cambiar el tipo de partición puede impedir que el sistema arranque."
 ],
 "This partition is not completely used by its content.": [
  null,
  "El contenido de esta partición no la está usando por completo."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "El tamaño de la partición es $0. El tamaño del contenido es $1."
 ],
 "Shrink partition": [
  null,
  "Reducir partición"
 ],
 "Grow content": [
  null,
  "Incrementar el contenido"
 ],
 "initialize": [
  null,
  "inicializar"
 ],
 "Initialize disk $0": [
  null,
  "Inicializar disco $0"
 ],
 "Partitioning": [
  null,
  "Particionamiento"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatible con todos los sistemas y dispositivos (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatible con los sistemas modernos y discos duros > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "No se particiona"
 ],
 "Overwrite": [
  null,
  "Sobrescribir"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Sobrescribir los datos existentes con ceros (más lento)"
 ],
 "Initialize": [
  null,
  "Inicializar"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inicializando un disco eliminará todos los datos que contenga."
 ],
 "Device is read-only": [
  null,
  "El dispositivo es de sólo lectura"
 ],
 "Create partition table": [
  null,
  "Crear una tabla de particiones"
 ],
 "Size must be a number": [
  null,
  "El tamaño debe ser un número"
 ],
 "Size cannot be zero": [
  null,
  "El tamaño no puede ser cero"
 ],
 "Size cannot be negative": [
  null,
  "El tamaño no puede ser negativo"
 ],
 "Size is too large": [
  null,
  "El tamaño es demasiado grande"
 ],
 "Size must be at least $0": [
  null,
  "El tamaño debe ser al menos $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volumen físico de un grupo de volúmenes LVM2"
 ],
 "member of MDRAID device": [
  null,
  "Miembro de dispositivo MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "Dispositivo de respaldo para dispositivo VDO"
 ],
 "member of Stratis pool": [
  null,
  "miembro del grupo de almacenamiento Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Sistema de archivos fuera del destino"
 ],
 "device of btrfs volume": [
  null,
  "dispositivo de volumen btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Este dispositivo está en uso."
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Use": [
  null,
  "Modo de empleo"
 ],
 "Services using the location": [
  null,
  "Servicios usando la ubicación"
 ],
 "Processes using the location": [
  null,
  "Procesos usando la ubicación"
 ],
 "Currently in use": [
  null,
  "Usado actualmente"
 ],
 "(Not part of target)": [
  null,
  "(No es parte del destino)"
 ],
 "These changes will be made:": [
  null,
  "Se realizarán los siguientes cambios:"
 ],
 "Action": [
  null,
  "Acción"
 ],
 "Important data might be deleted:": [
  null,
  "Datos importantes podrían ser borrados:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Los procesos y servicios relacionados serán detenidos forzadamente."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Los procesos relacionados serán detenidos forzadamente."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Los servicios relacionados serán detenidos forzadamente."
 ],
 "Checking filesystem usage": [
  null,
  "Comprobando el empleo del sistema de archivos"
 ],
 "$0 used, $1 total": [
  null,
  "$0 utilizado, $1 en total"
 ],
 "Device contains unrecognized data": [
  null,
  "El dispositivo contiene datos no reconocidos"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Unidad cifrada bloqueada puede contener datos"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confirmo que quiero perder estos datos para siempre"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "El punto de montaje $0 está siendo usado por los siguientes procesos:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "El punto de montaje $0 está siendo usado por los siguientes servicios:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Los procesos y servicios listados serán detenidos forzadamente."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Los procesos listados serán detenidos forzadamente."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Los servicios listados serán detenidos forzadamente."
 ],
 "Sorry": [
  null,
  "Lo siento"
 ],
 "Usage of $0": [
  null,
  "Uso de $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Grupo VDO LVM2"
 ],
 "Data used": [
  null,
  "Datos utilizados"
 ],
 "Metadata used": [
  null,
  "Metadatos utilizados"
 ],
 "Use compression": [
  null,
  "Usar compresión"
 ],
 "Deduplication": [
  null,
  "Deduplicación"
 ],
 "Use deduplication": [
  null,
  "Usar deduplicación"
 ],
 "Rename volume group": [
  null,
  "Renombrar un grupo de volumen"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Este grupo de volumen contiene el sistema de archivo raíz. Renombrarlo quizá requiere más cambios para la configuración del cargador de arranque o la línea de instrucción del kernel."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "La eliminación borrará toda la información en un grupo de volúmenes."
 ],
 "Create snapshot": [
  null,
  "Crear una instantánea"
 ],
 "Add disks": [
  null,
  "Añadir discos"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "No disks are available.": [
  null,
  "No hay discos disponibles."
 ],
 "At least one disk is needed.": [
  null,
  "Se necesita al menos un disco."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Al grupo de volúmenes le faltan volúmenes físicos"
 ],
 "No free space": [
  null,
  "No queda espacio disponible"
 ],
 "LVM2 volume group": [
  null,
  "Grupo de volúmenes LVM2"
 ],
 "Add physical volume": [
  null,
  "Añadir volumen físico"
 ],
 "LVM2 logical volumes": [
  null,
  "Volúmenes lógicos LVM2"
 ],
 "Create new logical volume": [
  null,
  "Crear un volumen lógico"
 ],
 "No logical volumes": [
  null,
  "No hay volúmenes lógicos"
 ],
 "Remove missing physical volumes?": [
  null,
  "¿Eliminar los volúmenes físicos faltantes?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "A este grupo de volúmenes le faltan algunos volúmenes físicos."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "A un grupo de volúmenes sin volúmenes físicos no se le puede cambiar el nombre."
 ],
 "Physical volumes": [
  null,
  "Volúmenes físicos"
 ],
 "No physical volumes found": [
  null,
  "No se encontraron volúmenes físicos"
 ],
 "LVM2 physical volumes": [
  null,
  "Volúmenes físicos LVM2"
 ],
 "Rename logical volume": [
  null,
  "Cambiar el nombre de volumen lógico"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "¿Eliminar permanentemente el volumen lógico $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Eliminando un volumen lógico borrará toda la información que hay en él."
 ],
 "Unable to repair logical volume $0": [
  null,
  "No se puede reparar el volumen lógico $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "No hay suficiente espacio disponible que pueda usarse para una reparación. Se necesitan al menos $0 en volúmenes físicos que estén disponibles para este volumen lógico."
 ],
 "An additional $0 must be selected": [
  null,
  "Se debe seleccionar $0 adicional"
 ],
 "Repair logical volume $0": [
  null,
  "Reparar volumen lógico $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Seleccione los volúmenes físicos que se serían utilizados para reparar el volumen lógico. Se necesitan al menos $0."
 ],
 "Physical Volumes": [
  null,
  "Volúmenes Físicos"
 ],
 "Repair": [
  null,
  "Reparar"
 ],
 "deactivate": [
  null,
  "desactivar"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "¿Desactivar volumen lógico $0/$1?"
 ],
 "Deactivate": [
  null,
  "Desactivar"
 ],
 "Not enough space to grow": [
  null,
  "No hay espacio suficiente para expandir"
 ],
 "LVM2 logical volume": [
  null,
  "Volumen lógico LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Rayado (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Espejo (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Divisiones y espejos (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Paridad dedicada (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Paridad distribuida (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Doble paridad distribuida (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "El contenido de este volumen lógico no lo está usando por completo."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "El tamaño del volumen es $0. El tamaño del contenido es $1."
 ],
 "Shrink volume": [
  null,
  "Encoger un volumen"
 ],
 "Layout": [
  null,
  "Distribución del teclado"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Este volumen lógico ha perdido algunos de sus volúmenes físicos y ya no se puede utilizar. Debe eliminarlo y crear uno nuevo para ocupar su lugar."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Este volumen lógico ha perdido algunos de sus volúmenes físicos pero aún no ha perdido ningún dato. Debe repararlo para restaurar su redundancia original."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Este volumen lógico ha perdido algunos de sus volúmenes físicos, pero es posible que aún no haya perdido ningún dato. Es posible que puedas repararlo."
 ],
 "Stripes": [
  null,
  "Divisiones"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizado"
 ],
 "Create volume group": [
  null,
  "Crear un grupo de volúmenes"
 ],
 "LVM2 physical volume": [
  null,
  "Volumen físico LVM2"
 ],
 "Last cannot be removed": [
  null,
  "El último no puede ser eliminado"
 ],
 "Not enough free space": [
  null,
  "No hay suficiente espacio libre"
 ],
 "Volume group": [
  null,
  "Grupo de volúmenes"
 ],
 "Create thin volume": [
  null,
  "Crear un volumen de aprovisionamiento fino"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volúmenes lógicos LVM2 con aprovisionamiento ligero"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Crear un nuevo volumen lógico con aprovisionamiento ligero"
 ],
 "Not enough space": [
  null,
  "No hay espacio suficiente"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Grupo para volúmenes lógicos LVM2 con aprovisionamiento ligero"
 ],
 "Inactive logical volume": [
  null,
  "Volumen lógico inactivo"
 ],
 "Activate": [
  null,
  "Activar"
 ],
 "Unsupported logical volume": [
  null,
  "Volumen lógico no soportado"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERROR INTERNO - Este volumen lógico está marcado como activo y debe tener un dispositivo de bloque asociado. Sin embargo, no se pudo encontrar ningún dispositivo de bloqueo de este tipo."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Instalar $0 eliminaría $1."
 ],
 "Installing packages": [
  null,
  "Instalando paquetes"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo de bloques para sistemas de archivos"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Grupo para volúmenes de aprovisionamiento fino"
 ],
 "Linear": [
  null,
  "Lineal"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volumen de sistema de archivos VDO (compresión/desduplicación)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Los datos se almacenarán en los volúmenes físicos seleccionados sin ninguna redundancia adicional ni mejoras de rendimiento."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Los datos se almacenarán en los volúmenes físicos seleccionados de forma alterna para mejorar el rendimiento. Es necesario seleccionar al menos dos volúmenes."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Los datos se almacenarán en dos o más copias en los volúmenes físicos seleccionados, para mejorar la confiabilidad. Es necesario seleccionar al menos dos volúmenes."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Los datos se almacenarán en dos copias y también de forma alterna en los volúmenes físicos seleccionados, para mejorar tanto la confiabilidad como el rendimiento. Es necesario seleccionar al menos cuatro volúmenes."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Los datos se almacenarán en los volúmenes físicos seleccionados para que uno de ellos pueda perderse sin afectar los datos. Es necesario seleccionar al menos tres volúmenes."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Los datos se almacenarán en los volúmenes físicos seleccionados para que uno de ellos pueda perderse sin afectar los datos. Los datos también se almacenan de forma alterna para mejorar el rendimiento. Es necesario seleccionar al menos tres volúmenes."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Los datos se almacenarán en los volúmenes físicos seleccionados de modo que se puedan perder hasta dos de ellos al mismo tiempo sin afectar los datos. Los datos también se almacenan de forma alterna para mejorar el rendimiento. Es necesario seleccionar al menos cinco volúmenes."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Todos los $0 volúmenes físicos seleccionados son necesarios para la distribución elegida."
 ],
 "Create logical volume": [
  null,
  "Crear un volumen lógico"
 ],
 "Purpose": [
  null,
  "Propósito"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "El paquete $0 será instalado para crear dispositivos VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 necesita un número par de volúmenes físicos"
 ],
 "Logical size": [
  null,
  "Tamaño lógico"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Ahorre espacio en la compresión individual de bloques con LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Ahorre espacio almacenando bloques de datos idénticos solo una vez"
 ],
 "Creating VDO device": [
  null,
  "Crear un dispositivo VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Este montaje NFS está en uso y solo se pueden cambiar sus opciones."
 ],
 "NFS mount": [
  null,
  "Montar NFS"
 ],
 "New NFS mount": [
  null,
  "Nuevo montaje NFS"
 ],
 "Server address": [
  null,
  "Dirección del servidor"
 ],
 "Server cannot be empty.": [
  null,
  "Servidor no puede estar vacío."
 ],
 "Path on server": [
  null,
  "Ruta en el servidor"
 ],
 "Path on server cannot be empty.": [
  null,
  "La ruta en el servidor no puede estar vacía."
 ],
 "Path on server must start with \"/\".": [
  null,
  "La ruta en el servidor debe empezar con \"/\"."
 ],
 "Local mount point": [
  null,
  "Punto de montaje local"
 ],
 "Mount point cannot be empty.": [
  null,
  "El punto de montaje no puede estar vacío."
 ],
 "Mount point must start with \"/\".": [
  null,
  "El punto de montaje debe empezar con \"/\"."
 ],
 "Mount options": [
  null,
  "Opciones de montaje"
 ],
 "Mount at boot": [
  null,
  "Montar en el arranque"
 ],
 "Mount read only": [
  null,
  "Montar en modo sólo lectura"
 ],
 "Custom mount options": [
  null,
  "Opciones de montaje personalizadas"
 ],
 "Unable to unmount filesystem": [
  null,
  "No se pudo desmontar el sistema de archivos"
 ],
 "Stop and unmount": [
  null,
  "Parar y desmontar"
 ],
 "Unable to remove mount": [
  null,
  "No se pudo eliminar el montaje"
 ],
 "Stop and remove": [
  null,
  "Parar y eliminar"
 ],
 "(not mounted)": [
  null,
  "(no montado)"
 ],
 "Start multipath": [
  null,
  "Inicio multitrayecto"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Hay dispositivos con múltiples rutas en el sistema, pero no se está ejecutando el servicio de rutas."
 ],
 "Show all $0 rows": [
  null,
  "Mostrar todas las $0 filas"
 ],
 "Category": [
  null,
  "Categoría"
 ],
 "more info": [
  null,
  "más información"
 ],
 "Encryption": [
  null,
  "Encriptación"
 ],
 "encrypted": [
  null,
  "cifrado"
 ],
 "Last modified: $0": [
  null,
  "Última modificación: $0"
 ],
 "Stored passphrase": [
  null,
  "Contraseña almacenada"
 ],
 "Encryption options": [
  null,
  "Opciones de cifrado"
 ],
 "Encryption type": [
  null,
  "Tipo de cifrado"
 ],
 "Cleartext device": [
  null,
  "Dispositivo en texto en blanco"
 ],
 "yes": [
  null,
  "sí"
 ],
 "Disk passphrase": [
  null,
  "Contraseña del disco"
 ],
 "Passphrase cannot be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "Unlocking disk": [
  null,
  "Desbloqueando disco"
 ],
 "Checking for $0 package": [
  null,
  "Comprobando si el paquete $0 está instalado"
 ],
 "The $0 package must be installed.": [
  null,
  "Se debe instalar el paquete $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "El paquete $0 no está disponible desde ningún repositorio."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Error al instalar $0: PackageKit o dnf5daemon-server no están instalados"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Error no esperado de PackageManager durante la instalación de $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Comprobando soporte para NBDE en el initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Se debe regenerar el initrd."
 ],
 "Regenerating initrd": [
  null,
  "Regenerando el initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Añadiendo rd.neednet=1 a la línea de comandos del kernel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Añadiendo \"$0\" a las opciones de sistema de archivos"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Añadiendo \"$0\" a las opciones de cifrado"
 ],
 "Enabling $0": [
  null,
  "Habilitando $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Añadir cifrado de disco enlazado a la red"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "El sistema no permite actualmente desbloquear el sistema de archivos raíz con un servidor Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "El sistema no permite actualmente desbloquear un sistema de archivos con un servidor Tang durante el arranque."
 ],
 "These additional steps are necessary:": [
  null,
  "Son necesarios estos pasos adicionales:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Para guardar una nueva contraseña se necesita primero desbloquear el disco. Por favor, introduzca una contraseña actual del disco."
 ],
 "Fix NBDE support": [
  null,
  "Arreglar soporte para NBDE"
 ],
 "Adding key": [
  null,
  "Añadiendo clave"
 ],
 "Key source": [
  null,
  "Clave fuente"
 ],
 "Repeat passphrase": [
  null,
  "Repita la contraseña"
 ],
 "Passphrase": [
  null,
  "Contraseña"
 ],
 "Tang keyserver": [
  null,
  "Servidor de claves Tang"
 ],
 "New passphrase": [
  null,
  "Nueva frase de paso"
 ],
 "Passphrases do not match": [
  null,
  "La contraseña no coincide"
 ],
 "Keyserver address": [
  null,
  "Dirección del servidor de claves"
 ],
 "Change passphrase": [
  null,
  "Cambiar la contraseña"
 ],
 "Old passphrase": [
  null,
  "Contraseña antigua"
 ],
 "Edit Tang keyserver": [
  null,
  "Editar el servidor de llaves Tang"
 ],
 "Verify key": [
  null,
  "Verificar clave"
 ],
 "Trust key": [
  null,
  "Clave de confianza"
 ],
 "Passphrase can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Eliminar la contraseña puede prevenir el desbloqueo $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirme la eliminación con otra contraseña alternativa"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Eliminar una contraseña sin confirmar con otra contraseña puede impedir el desbloqueo o la gestión de claves, si otras contraseñas se pierden o se olvidan."
 ],
 "Passphrase from any other key slot": [
  null,
  "Contraseña de cualquier otro guardaclaves"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "¿Eliminar la contraseña del guardaclaves $0?"
 ],
 "Remove $0?": [
  null,
  "¿Eliminar $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "La eliminación puede impedir el desbloqueo de $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "¿Quitar servidor de claves Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "¿Eliminar la clave dentro del zócalo $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "El usuario actual no tiene permitido ver la información de las claves."
 ],
 "No keys added": [
  null,
  "Sin claves añadidas"
 ],
 "Slot $0": [
  null,
  "Compartimento $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editar una clave requiere un guardaclaves libre"
 ],
 "The last key slot can not be removed": [
  null,
  "No se puede eliminar el último guardaclaves"
 ],
 "Keyserver": [
  null,
  "Servidor de claves"
 ],
 "Unknown type": [
  null,
  "Tipo desconocido"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Los guardaclaves de tipo desconocido no se pueden editar aquí"
 ],
 "Keys": [
  null,
  "Claves"
 ],
 "$0 slot remains": [
  null,
  "$0 ranura disponible",
  "$0 ranuras disponibles"
 ],
 "No available slots": [
  null,
  "No hay ranuras disponibles"
 ],
 "No free key slots": [
  null,
  "No hay guardaclaves libres"
 ],
 "Locked data": [
  null,
  "Datos bloqueados"
 ],
 "lock": [
  null,
  "bloquear"
 ],
 "Lock $0?": [
  null,
  "¿Bloquear a $0?"
 ],
 "Address cannot be empty": [
  null,
  "La dirección no puede estar vacía"
 ],
 "Address is not a valid URL": [
  null,
  "La dirección no es una URL válida"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Compruebe el hash de clave con el servidor Tang."
 ],
 "How to check": [
  null,
  "Cómo comprobarlo"
 ],
 "In a terminal, run: ": [
  null,
  "En un terminal, ejecute: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "¡Copiado correctamente al portapapeles!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Compruebe que el hash SHA-256 o SHA-1 del comando coincide con este diálogo."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Subvolumen btrfs $0 de $1"
 ],
 "Mount point cannot be empty": [
  null,
  "El punto de montaje no puede estar vacío"
 ],
 "Mount point is already used for $0": [
  null,
  "El punto de montaje se está utilizando para $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Los sistemas de archivos ya están montados dentro de este punto de montaje."
 ],
 "Please unmount them first.": [
  null,
  "Por favor, desmóntelos primero."
 ],
 "read only": [
  null,
  "solo lectura"
 ],
 "never mount at boot": [
  null,
  "nunca se monta en el arranque"
 ],
 "after network": [
  null,
  "después de la red"
 ],
 "ignore failure": [
  null,
  "se ignora fallo"
 ],
 "stop boot on failure": [
  null,
  "se detiene el arranque si falla"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "El sistema de archivos no tiene un punto de montaje asignado."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "El sistema de archivos no tiene un punto de montaje permanente."
 ],
 "The filesystem is not mounted.": [
  null,
  "El sistema de archivos no está montado."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "El sistema de archivos se desbloqueará en el siguiente arranque. Puede que se requiera introducir una contraseña."
 ],
 "(no assigned mount point)": [
  null,
  "(no tiene punto de montaje)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "El sistema de archivos está montado en $0 pero se montará en $1 en el próximo arranque."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montar automáticamente $0 en el arranque"
 ],
 "Mount on $0 now": [
  null,
  "Montar en $0 ahora"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "El sistema de archivos no está montado pero se montará en el próximo arranque."
 ],
 "Do not mount automatically on boot": [
  null,
  "No se monta automáticamente en el arranque"
 ],
 "Mount now": [
  null,
  "Montar ahora"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "El sistema de archivos está montado pero no se montará después del arranque."
 ],
 "Mount also automatically on boot": [
  null,
  "Montar automáticamente en el arranque"
 ],
 "Unmount now": [
  null,
  "Desmontar ahora"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "El sistema de archivos está montado en $0 pero no se montará en el próximo arranque."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "El sistema de archivos está configurado para ser montado automáticamente al arranque pero su contenedor de cifrado no estará desbloqueado para entonces."
 ],
 "Unlock automatically on boot": [
  null,
  "Desbloquear automáticamente en el arranque"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Punto de montaje de sistema inconsistente"
 ],
 "$0 filesystem": [
  null,
  "$0 sistema de archivos"
 ],
 "Filesystem name": [
  null,
  "Nombre del sistema de archivos"
 ],
 "Filesystem is locked": [
  null,
  "El sistema de archivos está bloqueado"
 ],
 "Mounts before services start": [
  null,
  "Se monta antes de que se inicien los servicios"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Apropiado para puntos de montaje críticos, como /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "El arranque falla si el sistema de archivos no se puede montar, previniendo acceso remoto"
 ],
 "Mounts in parallel with services": [
  null,
  "Se monta en paralelo con los servicios"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "El arranque no falla aunque el sistema de archivos no se monte"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Se monta en paralelo con los servicios, pero después de que la red esté disponible"
 ],
 "Does not mount during boot": [
  null,
  "No se monta durante el arranque"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Útil para puntos de montaje que son opcionales o que necesitan interacción (como contraseñas)"
 ],
 "At boot": [
  null,
  "Al arranque"
 ],
 "Mount before services start": [
  null,
  "Montar antes de que se inicien los servicios"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montar sin esperas, ignorar si falla"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montar después de que la red esté disponible, ignorar si falla"
 ],
 "Do not mount": [
  null,
  "No montar"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Este dispositivo no se puede utilizar como destino de instalación."
 ],
 "Mount filesystem": [
  null,
  "Montar sistema de archivos"
 ],
 "Unmount filesystem $0": [
  null,
  "Desmontar el sistema de archivos $0"
 ],
 "Mount configuration": [
  null,
  "Configuración de montaje"
 ],
 "Swap": [
  null,
  "Área de intercambio"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Desbloquear grupo de almacenamiento Stratis cifrado"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Introduzca la contraseña del grupo de almacenamiento de estos dispositivos de bloques:"
 ],
 "Stratis pool": [
  null,
  "Grupo de almacenamiento Stratis"
 ],
 "stopped": [
  null,
  "detenido"
 ],
 "Block devices": [
  null,
  "Dispositivos de bloques"
 ],
 "No block devices found": [
  null,
  "No se encontraron dispositivos de bloques"
 ],
 "Stratis block devices": [
  null,
  "Dispositivos de bloques Stratis"
 ],
 "Stratis block device": [
  null,
  "Dispositivo de bloques Stratis"
 ],
 "data": [
  null,
  "datos"
 ],
 "cache": [
  null,
  "Antememoria"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Proporcione un conjunto de claves existente."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Si el servidor de clave en $0 no es alcanzable, puede proporcionar una frase secreta existente."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Si no se alcanza ninguno de los servidores de claves, puede proporcionar una frase secreta existente."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Si ninguno de los desbloqueos no interactivos funciona, puede proporcionar una frase-contraseña existente."
 ],
 "Pool passphrase": [
  null,
  "Contraseña del grupo de almacenamiento"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "El servidor de claves en $0 debe ser accesible."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Al menos un servidor de claves debe ser alcanzable."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Al menos uno de los métodos de desbloqueo no interactivos debe funcionar."
 ],
 "Create filesystem": [
  null,
  "Crear un sistema de archivos"
 ],
 "Stratis filesystem": [
  null,
  "Sistema de archivos Stratis"
 ],
 "Set initial size": [
  null,
  "Establecer tamaño inicial"
 ],
 "Limit size": [
  null,
  "Tamaño límite"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Eliminando un grupo de almacenamiento Stratis borrará toda la información que hay en él."
 ],
 "Rename Stratis pool": [
  null,
  "Renombrar grupo de almacenamiento Stratis"
 ],
 "Add block devices": [
  null,
  "Añadir dispositivos de bloques"
 ],
 "Tier": [
  null,
  "Clasificación"
 ],
 "Data": [
  null,
  "Datos"
 ],
 "Cache": [
  null,
  "Caché"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Para añadir dispositivos de bloque se debe desbloquear el disco."
 ],
 "Encrypted Stratis pool": [
  null,
  "Consorcio cifrado Stratis"
 ],
 "Delete pool": [
  null,
  "Eliminar consorcio"
 ],
 "Encryption tokens": [
  null,
  "Vales de cifrado"
 ],
 "Stratis filesystems": [
  null,
  "Sistemas de archivos Stratis"
 ],
 "Create new filesystem": [
  null,
  "Crear un nuevo sistema de archivos"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Este grupo de almacenamiento no usa todo el espacio de sus dispositivos de bloques."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Algunos dispositivos de bloques en este grupo de almacenamiento han aumentado su tamaño después de que el grupo se crease. El grupo de almacenamiento puede ser extendido sin peligro para usar el nuevo espacio disponible."
 ],
 "Grow the pool to take all space": [
  null,
  "Extender el volumen para que ocupe todo el espacio"
 ],
 "This pool is in a degraded state.": [
  null,
  "Este grupo de almacenamiento está degradado."
 ],
 "No filesystems": [
  null,
  "Ningún sistema de archivos"
 ],
 "Stratis filesystems pool": [
  null,
  "Grupo de sistemas de archivos Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Esta contraseña es el único método para desbloquear el grupo de almacenamiento y no puede ser eliminada."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Este servidor de claves es el único método para desbloquear el grupo de almacenamiento y no puede ser eliminado."
 ],
 "Add passphrase": [
  null,
  "Añadir frase-contraseña"
 ],
 "Add keyserver": [
  null,
  "Añadir servidor de claves"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis «$0»"
 ],
 "Last token can not be removed": [
  null,
  "Último vale puede no ser eliminado"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Ya no hay espacio para frases de contraseña ni servidores de claves."
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Para guardar una nueva contraseña se necesita primero desbloquear el disco."
 ],
 "Remove passphrase?": [
  null,
  "¿Eliminar la contraseña?"
 ],
 "Add Tang keyserver": [
  null,
  "Añadir servidor de claves Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Añadir un servidor de claves requiere desbloquear el grupo de almacenamiento."
 ],
 "Remove Clevis token?": [
  null,
  "¿Eliminar vale de Clevis?"
 ],
 "Metadata format": [
  null,
  "Formato de metadatos"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Los pools con formato de metadatos V1 están restringidos a como máximo una frase de contraseña y como máximo un servidor de claves."
 ],
 "Overprovisioning": [
  null,
  "Sobreposicionamiento"
 ],
 "Allow overprovisioning": [
  null,
  "Permitir sobreaprovisionamiento"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Tamaños del sistema de archivos virtuales son más grandes que la compartición. Sobreaprovisionamiento puede no estar desactivado."
 ],
 "Allocated": [
  null,
  "Asignado"
 ],
 "Name can not be empty.": [
  null,
  "Nombre no puede estar vacío."
 ],
 "A pool with this name exists already.": [
  null,
  "Ya existe un grupo de almacenamiento con este nombre."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un sistema de archivos con ese nombre ya existe en este grupo de almacenamiento."
 ],
 "Create Stratis pool": [
  null,
  "Crear un grupo de almacenamiento Stratis"
 ],
 "No block devices are available.": [
  null,
  "No hay dispositivos de bloques disponibles."
 ],
 "At least one block device is needed.": [
  null,
  "Se necesita al menos un dispositivo de bloques."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Cifrar datos con una contraseña"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Cifrar datos con un servidor de claves Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Crear una instantánea del sistema de archivos $0"
 ],
 "Create snapshot and mount": [
  null,
  "Crear una instantánea y montar"
 ],
 "Create snapshot only": [
  null,
  "Sólo crear una instantánea"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Eliminando un sistema de archivos borrará toda la información que haya en él."
 ],
 "Snapshot": [
  null,
  "Crear una instantánea"
 ],
 "Rename filesystem": [
  null,
  "Renombrar sistema de archivos"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Establecer límite de tamaño del sistema de archivos virtuales"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limita el tamaño de los sistemas de archivos virtual"
 ],
 "Virtual size limit": [
  null,
  "Límite de tamaño virtual"
 ],
 "Virtual size": [
  null,
  "Tamaño virtual"
 ],
 "Create RAID device": [
  null,
  "Crear un dispositivo RAID"
 ],
 "RAID level": [
  null,
  "Nivel de RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Franja)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Espejo)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Paridad dedicada)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Paridad distribuida)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Doble paridad distribuida)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Franja de espejos)"
 ],
 "Chunk size": [
  null,
  "Tamaño de la porción"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Se necesita al menos $0 disco.",
  "Se necesita al menos $0 discos."
 ],
 "MDRAID disk": [
  null,
  "disco MDRAID"
 ],
 "In sync": [
  null,
  "En sincronía"
 ],
 "Spare": [
  null,
  "Repuesto"
 ],
 "Recovering": [
  null,
  "Recuperando"
 ],
 "Write-mostly": [
  null,
  "Escribir casi todo"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Unknown ($0)": [
  null,
  "Desconocido ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "El dispositivo MDRAID debe estar ejecutándose"
 ],
 "MDRAID device is recovering": [
  null,
  "El dispositivo MDRAID se está recuperando"
 ],
 "Need a spare disk": [
  null,
  "Necesita un disco de repuesto"
 ],
 "Last disk can not be removed": [
  null,
  "El último disco no se puede eliminar"
 ],
 "MDRAID device": [
  null,
  "Dispositivo MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirme la parada de $0"
 ],
 "Stop device": [
  null,
  "Parar dispositivo"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "La eliminación borrará todos los datos en el dispositivo MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "El dispositivo MDRAID debe estar ejecutándose"
 ],
 "Add disk": [
  null,
  "Añadir disco"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 discos"
 ],
 "$0 chunk size": [
  null,
  "tamaño de fragmento de $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "El dispositivo de MDRAID está degradado"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Este dispositivo MDRAID no tiene un mapa de bits. Un bitmap puede reducir significativamente los tiempos de sincronización."
 ],
 "Add a bitmap": [
  null,
  "Añadir un mapa de bit"
 ],
 "No disks found": [
  null,
  "No se encontraron discos"
 ],
 "MDRAID disks": [
  null,
  "discos MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "La eliminación borrará toda la información en un dispositivo VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "No ha finalizado la creación de este dispositivo VDO y no se podrá utilizar."
 ],
 "Remove device": [
  null,
  "Eliminar el dispositivo"
 ],
 "Grow to take all space": [
  null,
  "Expandir para tomar todo el espacio"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Este dispositivo VDO no usa todos sus dispositivos de respaldo."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Sólo $0 de $1 fue utilizado."
 ],
 "Grow logical size of $0": [
  null,
  "Expandir el tamaño lógico de $0"
 ],
 "Physical": [
  null,
  "Físico"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 de datos + $1 de sobrecoste utilizados de $2 ($3)"
 ],
 "Logical": [
  null,
  "Lógico"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "utilizado $0 de $1 ($2 guardado)"
 ],
 "Index memory": [
  null,
  "Índice de memoria"
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-diagnóstico de $target"
 ],
 "Ejecting $target": [
  null,
  "Expulsando a $target"
 ],
 "Unlocking $target": [
  null,
  "Desbloquendo $target"
 ],
 "Locking $target": [
  null,
  "Bloquendo $target"
 ],
 "Modifying $target": [
  null,
  "Modificando $target"
 ],
 "Resizing $target": [
  null,
  "Redimensionando $target"
 ],
 "Starting swapspace $target": [
  null,
  "Iniciando espacio del área de intercambio $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Deteniendo el espacio del área de intercambio $target"
 ],
 "Mounting $target": [
  null,
  "Montando $target"
 ],
 "Unmounting $target": [
  null,
  "Desmontando $target"
 ],
 "Checking $target": [
  null,
  "Comprobando $target"
 ],
 "Repairing $target": [
  null,
  "Reparando a $target"
 ],
 "Erasing $target": [
  null,
  "Eliminando $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Creando un sistema de archivos en $target"
 ],
 "Setting up loop device $target": [
  null,
  "Configurando el dispositivo de retorno $target"
 ],
 "Deleting $target": [
  null,
  "Eliminando $target"
 ],
 "Creating partition $target": [
  null,
  "Creando una partición en $target"
 ],
 "Cleaning up for $target": [
  null,
  "Limpiando el $target"
 ],
 "Securely erasing $target": [
  null,
  "Eliminando de forma segura $target"
 ],
 "Very securely erasing $target": [
  null,
  "Borrado de forma muy segura $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Deteniendo dispositivo MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Iniciando dispositivo MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Marcando $target como fallido"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Retirando el $target desde dispositivo MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Crear un dispositivo MDRAID en $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Comprobando el dispositivo MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Comprobando y reparando el dispositivo MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Recuperando el dispositivo MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Sincronizando el dispositivo MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Activando $target"
 ],
 "Deactivating $target": [
  null,
  "Desactivando el $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Creando una instantánea de $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Crear un grupo de volúmenes LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Eliminando grupo del volumen LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Añadiendo volumen físico a $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Eliminando el volumen físico de $target"
 ],
 "Emptying $target": [
  null,
  "Eliminando el contenido de $target"
 ],
 "Creating logical volume $target": [
  null,
  "Creando un volumen lógico en $target"
 ],
 "Renaming $target": [
  null,
  "Renombrando a $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Actividad '$operation' en $target"
 ],
 "unknown target": [
  null,
  "destino u objetivo desconocido"
 ],
 "Jobs": [
  null,
  "Tareas"
 ],
 "Reading": [
  null,
  "Leyendo"
 ],
 "Writing": [
  null,
  "Escribiendo"
 ],
 "Install Stratis support": [
  null,
  "Instalar soporte para Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "El paquete $0 debe instalarse para crear grupos de almacenamiento Stratis."
 ],
 "Install NFS support": [
  null,
  "Instalar el soporte NFS"
 ],
 "Create MDRAID device": [
  null,
  "Cree un dispositivo MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Crear un grupo de volúmenes LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Cambiar el nombre iniciador del iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Añadir portal iSCSI"
 ],
 "Local storage": [
  null,
  "Almacenamiento local"
 ],
 "Networked storage": [
  null,
  "Almacenamiento de red"
 ],
 "Create storage device": [
  null,
  "Crear un dispositivo de almacenamiento"
 ],
 "No storage found": [
  null,
  "No se encontró almacenamiento"
 ],
 "Server address cannot be empty.": [
  null,
  "La dirección del servidor no puede estar vacía."
 ],
 "Next": [
  null,
  "Siguiente"
 ],
 "Invalid username or password": [
  null,
  "Nombre de usuario o contraseña inválidos"
 ],
 "Unknown host name": [
  null,
  "Nombre del anfitrión desconocido"
 ],
 "Unable to reach server": [
  null,
  "Imposible conectar al servidor"
 ],
 "Available targets on $0": [
  null,
  "Objetivos disponibles en $0"
 ],
 "Authentication required": [
  null,
  "Se necesita autenticación"
 ],
 "iSCSI portal": [
  null,
  "portal de iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Discos iSCSI"
 ],
 "No drives found": [
  null,
  "No se encontraron unidades"
 ],
 "Target": [
  null,
  "Objetivo"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Los dispositivos de respaldo VDO no se pueden hacer más pequeños"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Los dispositivos de bloques de Stratis no se pueden reducir más"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Los datos que no están reconocidos no se pueden hacer más pequeños aquí."
 ],
 "Unlock before resizing": [
  null,
  "Desbloquear antes de cambiar el tamaño"
 ],
 "$0 can not be resized here": [
  null,
  "$0 no se puede redimensionar aquí"
 ],
 "$0 can not be resized": [
  null,
  "$0 no se pueden redimensionar"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 no se pueden reducir"
 ],
 "$0 can not be made larger": [
  null,
  "$0 no se pueden extender"
 ],
 "Physical volumes can not be resized here": [
  null,
  "No se pueden redimensionar volúmenes físicos aquí"
 ],
 "Swap can not be resized here": [
  null,
  "El área de intercambio no se puede redimensionar aquí"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Los datos no reconocidos no pueden hacerse más pequeños aquí"
 ],
 "Activate before resizing": [
  null,
  "Activar antes de cambiar el tamaño"
 ],
 "Grow logical volume": [
  null,
  "Expandir el volumen lógico"
 ],
 "Grow partition": [
  null,
  "Extender partición"
 ],
 "grow": [
  null,
  "incrementar"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Se deben seleccionar exactamente $0 volúmenes físicos"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Para cambiar el tamaño de un sistema de archivos cifrado, se necesita primero desbloquear el disco. Por favor, introduzca una contraseña actual del disco."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Es necesario seleccionar exactamente $0 volúmenes físicos, uno para cada franja del volumen lógico."
 ],
 "Shrink logical volume": [
  null,
  "Encoger un volumen lógico"
 ],
 "shrink": [
  null,
  "reducir"
 ],
 "Unformatted data": [
  null,
  "Datos sin formato"
 ],
 "Block device": [
  null,
  "Dispositivo de bloque"
 ],
 "Device number": [
  null,
  "Número del dispositivo"
 ],
 "Create partition on $0": [
  null,
  "Crear una partición en $0"
 ],
 "Format $0": [
  null,
  "Formatear $0"
 ],
 "No filesystem": [
  null,
  "Ningún sistema de archivo"
 ],
 "(recommended)": [
  null,
  "(recomendado)"
 ],
 "No encryption": [
  null,
  "Sin cifrado"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Reutilizar cifrado existente ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Reutilizar cifrado existente"
 ],
 "format": [
  null,
  "formato"
 ],
 "Format and mount": [
  null,
  "Formatear y montar"
 ],
 "Format only": [
  null,
  "Sólo formatear"
 ],
 "Format": [
  null,
  "Formatear"
 ],
 "Create and start": [
  null,
  "Crear e iniciar"
 ],
 "Format and start": [
  null,
  "Formatear e iniciar"
 ],
 "Store passphrase": [
  null,
  "Guardar contraseña"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Se necesita desbloquear el disco antes de formatearlo. Por favor, introduzca una frase-contraseña existente."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formateando eliminará todos los datos de un dispositivo de almacenamiento."
 ],
 "Unrecognized data": [
  null,
  "Datos no reconocidos"
 ],
 "Storage can not be managed on this system.": [
  null,
  "El almacenamiento no se puede gestionar en este sistema."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit es un gestor de servidores que facilita la administración de servidores Linux a través de un navegador web. Es posible alternar entre el portal web y la consola sin problemas. Un servicio que haya empezado por Cockpit se puede parar desde la terminal. Asimismo, si se produce un error en el terminal, podrá verlo en la bitácora de Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit es ideal para administradores de sistemas nóveles, ya que permite realizar con sencillez tareas como gestionar almacenamiento, inspeccionar bitácoras e iniciar y detener servicios. Puede monitorizar y administrar varios servidores a la vez. Tan solo añádalos con solo pulsar un botón y sus máquinas se encargarán del resto."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una vez que se instale Cockpit, habilítelo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuración en Cockpit de NetworkManager y Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta herramienta gestiona la configuración de red como agrupaciones, puentes, grupos, las VLAN y cortafuegos usando NetworkManager y Firewalld. NetworkManager es incompatible con systemd-networkd habilitado por defecto en Ubuntu y con los scripts de ifupdown de Debian."
 ],
 "Manage storage": [
  null,
  "Gestionar el almacenamiento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta herramienta gestiona el almacenamiento local, como sistemas de archivos, grupos de volúmenes LVM2 y montajes NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Recoger y empaquetar datos de diagnóstico y soporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta herramienta genera un archivo de configuración e información de diagnóstico del sistema en ejecución. El archivo puede ser almacenado localmente o centralmente para propósitos de registro o seguimiento, o puede ser enviado a representantes de soporte técnico, desarrolladores o administradores de sistemas para asistir con la detección de fallos y su corrección."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuración de Security Enhanced Linux y resolución de problemas"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta herramienta configura la política de SELinux y puede ayudarle a comprender y resolver infracciones de la política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Recoger volcados de colapso del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta herramienta configura el sistema para que escriba los volcados de colapso del kernel. Admite volcados de destino\"local\" (disco), \"ssh\" y \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrando con la consola Web de Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Se requiere autenticación para elevar privilegios y realizar tareas de administración en la consola Web de Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
