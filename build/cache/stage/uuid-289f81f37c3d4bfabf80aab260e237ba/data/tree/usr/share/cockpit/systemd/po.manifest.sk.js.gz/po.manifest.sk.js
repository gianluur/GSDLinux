cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Služby"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "time": [
  null,
  "čas"
 ],
 "date": [
  null,
  "dátum"
 ],
 "restart": [
  null,
  "reštartovať"
 ],
 "shut": [
  null,
  "vypnúť"
 ],
 "domain": [
  null,
  "Doména"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "operating system": [
  null,
  "Operačný systém"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "Inventárny štítok"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "napájanie"
 ],
 "version": [
  null,
  "Verzia"
 ],
 "host": [
  null,
  "stroj"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "zmiernenie"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "pamäť"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "history": [
  null,
  "história"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "disky"
 ],
 "network": [
  null,
  "sieť"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "Configuring system settings": [
  null,
  "Aplikujem nastavenia systému"
 ],
 "service": [
  null,
  "služba"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cieľ"
 ],
 "socket": [
  null,
  "soket"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "path": [
  null,
  "umiestnenie"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "boot"
 ],
 "mask": [
  null,
  "maska"
 ],
 "unmask": [
  null,
  "odmaskovať"
 ],
 "enable": [
  null,
  "povoliť"
 ],
 "disable": [
  null,
  "vypnúť"
 ],
 "Managing services": [
  null,
  "Správa služieb"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "warning": [
  null,
  "varovanie"
 ],
 "error": [
  null,
  "Chyba"
 ],
 "debug": [
  null,
  "ladenie"
 ],
 "crash": [
  null,
  "pád"
 ],
 "coredump": [
  null,
  "výpis jadra"
 ],
 "Reviewing logs": [
  null,
  "Kontrolujem záznamy udalostí"
 ],
 "console": [
  null,
  "konzola"
 ],
 "command": [
  null,
  "Príkaz"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
