cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
