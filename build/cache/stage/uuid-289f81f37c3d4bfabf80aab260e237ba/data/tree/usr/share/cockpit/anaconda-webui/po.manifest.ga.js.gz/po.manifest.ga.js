cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1 ? 0 : n==2 ? 1 : n<7 ? 2 : n<11 ? 3 : 4)),
  "language": "ga",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
