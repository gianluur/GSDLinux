cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Radera $0?"
 ],
 "Force delete": [
  null,
  "Framtvinga borttagande"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Must be a valid IP address": [
  null,
  "Måste vara en giltig IP adress"
 ],
 "1 to 65535": [
  null,
  "1 till 65535"
 ],
 "Container port must not be empty": [
  null,
  "Behållarporten får inte vara tom"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "IP address help": [
  null,
  "IP-adress hjälp"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Om värd-IP är inställd på 0.0.0.0 eller inte alls, kommer porten att bindas till alla IP-adresser på värden."
 ],
 "Host port": [
  null,
  "Värdport"
 ],
 "Host port help": [
  null,
  "Värdport hjälp"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Om värdporten inte är inställd kommer behållareporten att slumpmässigt tilldelas en port på värden."
 ],
 "Container port": [
  null,
  "Behållarport"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Ta bort post"
 ],
 "Image name is required": [
  null,
  "Avbildsnamn krävs"
 ],
 "Image name is not unique": [
  null,
  "Avbildsnamn är inte unikt"
 ],
 "Failed to commit container $0": [
  null,
  "Kunde inte fastställa behållaren $0"
 ],
 "New image name": [
  null,
  "Nytt Avbildsnamn"
 ],
 "Tag": [
  null,
  "Tagg"
 ],
 "Author": [
  null,
  "Upphovsman"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exempel, Ditt Namn <dittnamn@exempel.com>"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Pause container when creating image": [
  null,
  "Pausa behållaren när du skapar en avbild"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-format är användbart när du delar avbilden med Docker eller Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Använd gammalt Docker-format"
 ],
 "Commit container": [
  null,
  "Commit behållare"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Skapa en ny avbild baserad på det aktuella läget för $0 behållaren."
 ],
 "Commit": [
  null,
  "Fastställ"
 ],
 "Force commit": [
  null,
  "Framtvinga commit"
 ],
 "Failed to force remove container $0": [
  null,
  "Misslyckades att tvingande ta bort behållare $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "När en container som körs raderas försvinner även all data i den."
 ],
 "Failed to stop container $0": [
  null,
  "Misslyckades att stoppa behållaren $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Misslyckades att stoppa quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Misslyckades med att starta quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Misslyckades att starta behållaren $0"
 ],
 "Failed to resume container $0": [
  null,
  "Misslyckades att återuppta behållaren $0"
 ],
 "Failed to pause container $0": [
  null,
  "Misslyckades med att pausa behållaren $0"
 ],
 "Failed to restart container $0": [
  null,
  "Misslyckades att starta om behållaren $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Misslyckades att starta om quadlet $0"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Restart": [
  null,
  "Starta om"
 ],
 "Force stop": [
  null,
  "Framtvinga stopp"
 ],
 "Force restart": [
  null,
  "Framtvinga omstart"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Resume": [
  null,
  "Återuppta"
 ],
 "Checkpoint": [
  null,
  "Checkpunkt"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Restore": [
  null,
  "Återställ"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Healthy": [
  null,
  "Hälsosam"
 ],
 "Unhealthy": [
  null,
  "Ohälsosam"
 ],
 "Checking health": [
  null,
  "Kontrollerar hälsa"
 ],
 "Prune unused containers": [
  null,
  "Rensa oanvända behållare"
 ],
 "Terminal not available": [
  null,
  "Terminal är inte tillgänglig"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Den här webbläsaren stöder inte WebGL2."
 ],
 "View $0 logs": [
  null,
  "Visa $0 loggar"
 ],
 "not available": [
  null,
  "inte tillgängligt"
 ],
 "n/a": [
  null,
  "ej tillämpligt"
 ],
 "$0% of $1 limit": [
  null,
  "$0 % av gränsen $1"
 ],
 "service": [
  null,
  "tjänst"
 ],
 "system": [
  null,
  "system"
 ],
 "user:": [
  null,
  "användare:"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Integration": [
  null,
  "Integration"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Health check": [
  null,
  "Hälsokontroll"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Click to see published ports": [
  null,
  "Klicka för att se publicerade portar"
 ],
 "ports": [
  null,
  "portar"
 ],
 "Click to see volumes": [
  null,
  "Klicka för att se volymer"
 ],
 "volumes": [
  null,
  "volymer"
 ],
 "Container": [
  null,
  "Behållare"
 ],
 "Owner": [
  null,
  "Ägare"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "No containers": [
  null,
  "Inga behållare"
 ],
 "No containers in this pod": [
  null,
  "Inga behållare i denna kapsel"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "No containers that match the current filter": [
  null,
  "Inga behållare som stämmer med det aktuella filtret"
 ],
 "No running containers": [
  null,
  "Inga körande behållare"
 ],
 "Show": [
  null,
  "Visa"
 ],
 "All": [
  null,
  "Alla"
 ],
 "Only running": [
  null,
  "Endast körande"
 ],
 "Create pod": [
  null,
  "Skapa pod"
 ],
 "Create container": [
  null,
  "Skapa behållare"
 ],
 "Containers": [
  null,
  "Behållare"
 ],
 "Create container in pod": [
  null,
  "Skapa behållare i kapsel"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Misslyckades att återställa behållaren $0"
 ],
 "Restore container $0": [
  null,
  "Återställ behållaren $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Behåll alla tillfälliga checkpunktsfiler"
 ],
 "Restore with established TCP connections": [
  null,
  "Återställ med etablerade TCP-förbindelser"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorera IP-adressen om den är statiskt satt"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorera MAC-adressen om den är statiskt satt"
 ],
 "Pod failed to be created": [
  null,
  "Podden kunde inte skapas"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Ogiltiga tecken. Namn kan bara innehålla bokstäver, siffror och vissa skiljetecken (_ . -)."
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Pod name": [
  null,
  "Pod namn"
 ],
 "System": [
  null,
  "System"
 ],
 "User:": [
  null,
  "Användare:"
 ],
 "No ports exposed": [
  null,
  "Inga portar exponerade"
 ],
 "Port mapping": [
  null,
  "Portkartering"
 ],
 "Add port mapping": [
  null,
  "Lägg till portmappning"
 ],
 "No volumes specified": [
  null,
  "Inga volymer specificerade"
 ],
 "Volumes": [
  null,
  "Volymer"
 ],
 "Add volume": [
  null,
  "Lägg till volym"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Type to filter…": [
  null,
  "Skriv för att filtrera …"
 ],
 "Container path must not be empty": [
  null,
  "Behållarens sökväg får inte vara tom"
 ],
 "Host path": [
  null,
  "Värdsökväg"
 ],
 "Container path": [
  null,
  "Behållarsökväg"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Writable": [
  null,
  "Skrivbar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Ingen Etikett"
 ],
 "Shared": [
  null,
  "Delad"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Read-write access": [
  null,
  "Läs och skrivåtkomst"
 ],
 "Read-only access": [
  null,
  "Skrivskyddad åtkomst"
 ],
 "Show less": [
  null,
  "Visa mindre"
 ],
 "Show more": [
  null,
  "Visa mer"
 ],
 "Loading details...": [
  null,
  "Läser in detaljer …"
 ],
 "Ports": [
  null,
  "Portar"
 ],
 "Environment variables": [
  null,
  "Miljövariabler"
 ],
 "Failed to download image $0:$1": [
  null,
  "Kunde inte ladda ner avbild $0:$1"
 ],
 "Error message": [
  null,
  "Felmeddelande"
 ],
 "unused": [
  null,
  "oanvänd"
 ],
 "$0 container": [
  null,
  "$0 behållare",
  "$0 behållare"
 ],
 "History": [
  null,
  "Historik"
 ],
 "Image": [
  null,
  "Avbild"
 ],
 "Created": [
  null,
  "Skapad"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Disk utrymme"
 ],
 "Used by": [
  null,
  "Används av"
 ],
 "No images": [
  null,
  "Inga avbilder"
 ],
 "No images that match the current filter": [
  null,
  "Inga avbilder som stämmer med det aktuella filtret"
 ],
 "Hide intermediate images": [
  null,
  "Dölj mellanliggande avbilder"
 ],
 "Show intermediate images": [
  null,
  "Visa mellanliggande avbilder"
 ],
 "Images": [
  null,
  "Avbilder"
 ],
 "$0 image total, $1": [
  null,
  "$0 avbild, total, $1",
  "$0 avbilder, totalt, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 oanvänd avbild, $1",
  "$0 oanvända avbilder, $1"
 ],
 "Hide images": [
  null,
  "Dölj avbilder"
 ],
 "Show images": [
  null,
  "Visa avbilder"
 ],
 "Pulling": [
  null,
  "Hämtar"
 ],
 "Download new image": [
  null,
  "Ladda ner ny avbild"
 ],
 "Pull all images": [
  null,
  "Hämta alla avbilder"
 ],
 "Prune unused images": [
  null,
  "Rensa oanvända avbilder"
 ],
 "Pull": [
  null,
  "Hämta"
 ],
 "Up since:": [
  null,
  "Uppe sedan:"
 ],
 "Exited": [
  null,
  "Avslutats"
 ],
 "systemd service": [
  null,
  "systemd tjänst"
 ],
 "View $0": [
  null,
  "Visa $0"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "MAC address": [
  null,
  "MAC-adress"
 ],
 "Latest checkpoint": [
  null,
  "Senaste checkpunkt"
 ],
 "No containers are using this image": [
  null,
  "Inga behållare använder denna avbild"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "Loading logs...": [
  null,
  "Läser in loggar …"
 ],
 "Delete unused system images:": [
  null,
  "Ta bort oanvända systemavbilder:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Radera oanvända avbilder för användare $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Misslyckades att rensa oanvända avbilder"
 ],
 "Pruning images": [
  null,
  "Rensar avbilder"
 ],
 "Prune": [
  null,
  "Rensa"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kunde inte ta checkpunkt av behållare $0"
 ],
 "Checkpoint container $0": [
  null,
  "Ta checkpunkt på behållare $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Låt fortsätta köra efter att skriva checkpunkt till disk"
 ],
 "Support preserving established TCP connections": [
  null,
  "Stöd att bevara etablerade TCP-förbindelser"
 ],
 "Failed to search for new images": [
  null,
  "Misslyckades att söka efter nya avbilder"
 ],
 "Failed to search for images: $0": [
  null,
  "Misslyckades att söka efter avbilder: $0"
 ],
 "Failed to search for images.": [
  null,
  "Misslyckades att söka efter avbilder."
 ],
 "Search for an image": [
  null,
  "Sök efter en avbild"
 ],
 "Search for": [
  null,
  "Sök efter"
 ],
 "Search by name or description": [
  null,
  "Sök efter namn eller beskrivning"
 ],
 "in": [
  null,
  "i"
 ],
 "All registries": [
  null,
  "Alla register"
 ],
 "Searching...": [
  null,
  "Söker …"
 ],
 "No images found": [
  null,
  "Inga avbilder funna"
 ],
 "Start typing to look for images.": [
  null,
  "Börja skriva för att leta efter avbilder."
 ],
 "No results for $0": [
  null,
  "Inga resultat för $0"
 ],
 "Retry another term.": [
  null,
  "Försök igen med en annan term."
 ],
 "Download": [
  null,
  "Ladda ner"
 ],
 "No action": [
  null,
  "Ingen åtgärd"
 ],
 "Container failed to be started": [
  null,
  "Behållaren misslyckades att startas"
 ],
 "Failed to clean up container": [
  null,
  "Misslyckades med att rensa upp behållaren"
 ],
 "Container failed to be created": [
  null,
  "Behållaren misslyckades att skapas"
 ],
 "downloading": [
  null,
  "hämtar"
 ],
 "Failed to run container $0": [
  null,
  "Misslyckades att köra container $0"
 ],
 "Failed to create container $0": [
  null,
  "Misslyckades att skapa container $0"
 ],
 "Failed to pull image $0": [
  null,
  "Misslyckades med att hämta avbilden $0"
 ],
 "Local images": [
  null,
  "Lokala avbilder"
 ],
 "Name already in use": [
  null,
  "Namn används redan"
 ],
 "Search by registry": [
  null,
  "Sök efter register"
 ],
 "Local": [
  null,
  "Lokal"
 ],
 "Container name": [
  null,
  "Behållarnamn"
 ],
 "Owner help": [
  null,
  "Ägare hjälp"
 ],
 "Ideal for running services": [
  null,
  "Ideal för att köra tjänster"
 ],
 "Resource limits can be set": [
  null,
  "Resursgränser kan ställas in"
 ],
 "Checkpoint and restore support": [
  null,
  "checkpunkt och återställnings stöd"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portar under 1024 kan inte mappas"
 ],
 "User": [
  null,
  "Användare"
 ],
 "Ideal for development": [
  null,
  "Ideal för utveckling"
 ],
 "Restricted by user account permissions": [
  null,
  "Begränsat av användarkontobehörigheter"
 ],
 "Image selection help": [
  null,
  "Avbildsval hjälp"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "värd[:port]/[användare]/behållare[:tagg]"
 ],
 "Example: $0": [
  null,
  "Exempel: $0"
 ],
 "Searching: $0": [
  null,
  "Söker: $0"
 ],
 "Search string or container location": [
  null,
  "Söksträng eller behållareplats"
 ],
 "Pull latest image": [
  null,
  "Hämta senaste avbild"
 ],
 "Entrypoint": [
  null,
  "Ingångspunkt"
 ],
 "With terminal": [
  null,
  "Med terminal"
 ],
 "Memory limit": [
  null,
  "Minnesgräns"
 ],
 "Decrease memory": [
  null,
  "Minska minne"
 ],
 "Increase memory": [
  null,
  "Öka minne"
 ],
 "Memory unit": [
  null,
  "Minnesenhet"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU-andelar"
 ],
 "CPU Shares help": [
  null,
  "CPU-andelar hjälp"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-andelar avgör prioriteten på körande behållare. Standardprioriteten är 1024. Ett högre tal prioriterar denna behållare. Ett lägre tal sänker prioriteten."
 ],
 "Decrease CPU shares": [
  null,
  "Minska CPU-andelar"
 ],
 "Increase CPU shares": [
  null,
  "Öka CPU-andelar"
 ],
 "Restart policy": [
  null,
  "Starta om policy"
 ],
 "Restart policy help": [
  null,
  "Starta om policy hjälp"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Starta om policyn till att följa när behållare avslutar. Att använda fortlevande (linger) för automatstartande behållare fungerar kanske inte i vissa situationer, som när ecryptfs, systemd-homed, NFS eller 2FA används för ett användarkonto."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Starta om policy att följa när behållare avslutas."
 ],
 "No": [
  null,
  "Nej"
 ],
 "On failure": [
  null,
  "Vid misslyckande"
 ],
 "Always": [
  null,
  "Alltid"
 ],
 "Maximum retries": [
  null,
  "Maximalt antal försök igen"
 ],
 "Decrease maximum retries": [
  null,
  "Minska maximalt antal försök igen"
 ],
 "Increase maximum retries": [
  null,
  "Öka maximalt antal försök igen"
 ],
 "No environment variables specified": [
  null,
  "Inga miljövariabler specificerade"
 ],
 "Add variable": [
  null,
  "Lägg till variabel"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Klistra in en eller flera rader med nyckel=värdepar i valfritt fält för massimport"
 ],
 "Interval": [
  null,
  "Intervall"
 ],
 "Health check interval help": [
  null,
  "Hälsokontrollens intervallhjälp"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervallet hur ofta hälsokontroller körs."
 ],
 "Decrease interval": [
  null,
  "Minska intervallet"
 ],
 "Increase interval": [
  null,
  "Öka intervallet"
 ],
 "seconds": [
  null,
  "sekunder"
 ],
 "Timeout": [
  null,
  "Tidsgräns"
 ],
 "Health check timeout help": [
  null,
  "Hälsokontrollens tidsgränshjälp"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Den maximala tiden som tillåts för att klara av hälsokontrollen före ett intervall betraktas som misslyckat."
 ],
 "Decrease timeout": [
  null,
  "Minska timeout"
 ],
 "Increase timeout": [
  null,
  "Öka timeout"
 ],
 "Start period": [
  null,
  "Startperiod"
 ],
 "Health check start period help": [
  null,
  "Hälsokontrollens startintervallshjälp"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Initieringstiden sombehövs för att en behållare skall komma igång."
 ],
 "Decrease start period": [
  null,
  "Minska startintervallet"
 ],
 "Increase start period": [
  null,
  "Öka startintervallet"
 ],
 "Retries": [
  null,
  "Omförsök"
 ],
 "Health check retries help": [
  null,
  "Hälsokontrollens återförsökshjälp"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Antalet återförsök som tillåts före en hälsokontroll betraktas som ohälsosam."
 ],
 "Decrease retries": [
  null,
  "Minska återförsök"
 ],
 "Increase retries": [
  null,
  "Öka återförsöken"
 ],
 "When unhealthy": [
  null,
  "När ohälsosam"
 ],
 "Health failure check action help": [
  null,
  "Hälsokontrollens checkåtgärd hjälp"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Åtgärd att ta när behållaren övergår till ett ohälsosamt tillstånd."
 ],
 "Create container in $0": [
  null,
  "Skapa behållare i $0"
 ],
 "Create and run": [
  null,
  "Skapa och kör"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Version": [
  null,
  "Version"
 ],
 "Links": [
  null,
  "Länkar"
 ],
 "Documentation": [
  null,
  "Dokumentation"
 ],
 "Tags": [
  null,
  "Taggar"
 ],
 "Created by": [
  null,
  "Skapad av"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Comments": [
  null,
  "Kommentarer"
 ],
 "Unable to load image history": [
  null,
  "Kunde inte ladda avbildshistoriken"
 ],
 "Key must not be empty": [
  null,
  "Nyckel får inte vara tom"
 ],
 "Key must not begin with a digit": [
  null,
  "Nyckel får inte börja med en siffra"
 ],
 "Key contains invalid characters": [
  null,
  "Nyckel innehåller ogiltiga tecken"
 ],
 "Key": [
  null,
  "Nyckel"
 ],
 "Value": [
  null,
  "Värde"
 ],
 "user": [
  null,
  "användare"
 ],
 "Podman service failed": [
  null,
  "Podman-tjänsten misslyckades"
 ],
 "Troubleshoot": [
  null,
  "Felsök"
 ],
 "Failed to force remove image $0": [
  null,
  "Misslyckades att tvingande ta bort avbilden $0"
 ],
 "intermediate image": [
  null,
  "mellanliggande avbild"
 ],
 "Failed to remove image $0": [
  null,
  "Misslyckades att ta bort avbilden $0"
 ],
 "intermediate": [
  null,
  "mellanliggande"
 ],
 "Delete $0 image?": [
  null,
  "Radera $0 avbild?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Flera taggar finns för denna avbild. Välj vilka taggade avbilder som skall raderas."
 ],
 "Delete image": [
  null,
  "Radera avbild"
 ],
 "Delete tagged images": [
  null,
  "Radera taggade avbilder"
 ],
 "Container is not running": [
  null,
  "Behållaren kör inte"
 ],
 "Error occurred while connecting console": [
  null,
  "Ett fel uppstod vid anslutning till konsolen"
 ],
 "Force delete pod $0?": [
  null,
  "Framtvinga borttagande av podd $0?"
 ],
 "Delete pod $0?": [
  null,
  "Radera podd $0?"
 ],
 "An error occurred": [
  null,
  "Ett fel uppstod"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Tom podd $0 kommer att tas bort permanent."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Att ta bort denna kapsel kommer ta bort följande behållare:"
 ],
 "Failed to start pod $0": [
  null,
  "Misslyckades att starta kapseln $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Misslyckades att stoppa kapseln $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Misslyckades att starta om kapseln $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Misslyckades att återuppta kapseln $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Misslyckades att pausa kapseln $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Misslyckades att rensa oanvända behållare"
 ],
 "Removes selected non-running containers": [
  null,
  "Tar bort valda icke-körande behållare"
 ],
 "Pruning containers": [
  null,
  "Rensar behållare"
 ],
 "Container name is required.": [
  null,
  "Behållarnamn krävs."
 ],
 "Failed to rename container $0": [
  null,
  "Misslyckades att byta namn på container $0"
 ],
 "New container name": [
  null,
  "Nytt behållarnamn"
 ],
 "Rename container $0": [
  null,
  "Byt namn på behållaren $0"
 ],
 "Paused": [
  null,
  "Pausad"
 ],
 "Stopped": [
  null,
  "Stoppad"
 ],
 "Removing": [
  null,
  "Tar bort"
 ],
 "Configured": [
  null,
  "Konfigurerad"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "$0 second": [
  null,
  "$0 sekund",
  "$0 sekunder"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Failing streak": [
  null,
  "Misslyckanden i följd"
 ],
 "Failed to run health check on container $0": [
  null,
  "Misslyckades att köra hälsokontrollen på behållare $0"
 ],
 "Run health check": [
  null,
  "Kör hälsokontroll"
 ],
 "Last 5 runs": [
  null,
  "Senaste 5 körningarna"
 ],
 "Started at": [
  null,
  "Startad vid"
 ],
 "Passed health run": [
  null,
  "Lyckad hälsokontrollskörning"
 ],
 "Failed health run": [
  null,
  "Misslyckad hälsokörning"
 ],
 "Failed to remove container $0": [
  null,
  "Misslyckades att ta bort behållaren $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "När en behållare raderas försvinner även all data i den."
 ]
});
