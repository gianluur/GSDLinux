cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Služby"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "network": [
  null,
  "sieť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "rozhranie"
 ],
 "bridge": [
  null,
  "most"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "spojenie (bond)"
 ],
 "team": [
  null,
  "teaming"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zóna"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Správa sieťových spojení (bond)"
 ],
 "Managing networking teams": [
  null,
  "Správa sieťového teamingu"
 ],
 "Managing networking bridges": [
  null,
  "Správa sieťových mostov"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sietí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ]
});
