cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "et",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
