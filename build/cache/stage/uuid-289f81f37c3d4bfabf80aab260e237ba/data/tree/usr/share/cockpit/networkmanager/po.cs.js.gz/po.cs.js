cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Firewall": [
  null,
  "Brána firewall"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Public key": [
  null,
  "Veřejná část klíče"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Select": [
  null,
  "Vybrat"
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "Connect": [
  null,
  "Připojit"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "Disconnected": [
  null,
  "Odpojeno"
 ],
 "Permission denied": [
  null,
  "Přístup zamítnut"
 ],
 "Clear input value": [
  null,
  "Vymazat vstupní hodnotu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky pomocí NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticky pomocí dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky pomocí konkrétních NTP serverů"
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "Create $0": [
  null,
  "Vytvořit $0"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nejsou k dispozici žádné metody pro získání přístupu pro správu (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "$0 will be installed.": [
  null,
  "Bude nainstalováno $0."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásilo chybový kód $0"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Chyba při inicializaci"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Home": [
  null,
  "Domovská složka"
 ],
 "Downloads": [
  null,
  "Stahování"
 ],
 "Not a directory": [
  null,
  "Nejedná se o složku"
 ],
 "All files": [
  null,
  "Všechny soubory"
 ],
 "Recent": [
  null,
  "Nedávné"
 ],
 "No recent directories": [
  null,
  "Žádné nedávné složky"
 ],
 "No recent files": [
  null,
  "Žádné nedávné soubory"
 ],
 "Type to filter": [
  null,
  "Filtrujte psaním"
 ],
 "File chooser actions": [
  null,
  "Akce dialogu výběru souboru"
 ],
 "Open in file browser": [
  null,
  "Otevřít v procházení souborů"
 ],
 "Hide hidden files": [
  null,
  "Nezobrazovat skryté soubory"
 ],
 "Show hidden files": [
  null,
  "Zobrazit skryté soubory"
 ],
 "Filesystem": [
  null,
  "Souborový systém"
 ],
 "Clear filters": [
  null,
  "Vyčistit filtry"
 ],
 "Directory is empty": [
  null,
  "Složka je prázdná"
 ],
 "Directory has no sub-directories": [
  null,
  "Složka nemá žádné podsložky"
 ],
 "This directory contains only hidden files": [
  null,
  "Tato složka obsahuje pouze skryté soubory"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "Folder": [
  null,
  "Složka"
 ],
 "File": [
  null,
  "Soubor"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Select an option": [
  null,
  "Vyberte možnost"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "None": [
  null,
  "Žádné"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Generated": [
  null,
  "Vytvořeno"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Delete $0": [
  null,
  "Smazat $0"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Not available": [
  null,
  "Není k dispozici"
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Permanent": [
  null,
  "Trvalá"
 ],
 "Preserve": [
  null,
  "Zachovat"
 ],
 "Random": [
  null,
  "Náhodné"
 ],
 "Stable": [
  null,
  "Stabilní"
 ],
 "Use $0": [
  null,
  "Použít $0"
 ],
 "Failed to save settings": [
  null,
  "Nastavení se nepodařilo uložit"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vytvoření tohoto $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Create it": [
  null,
  "Vytvořit to"
 ],
 "Invalid prefix $0": [
  null,
  "Neplatná předpona $0"
 ],
 "Invalid metric $0": [
  null,
  "Neplatná metrika $0"
 ],
 "Invalid address $0": [
  null,
  "Neplatná adresa $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Neplatná předpona nebo maska sítě $0"
 ],
 "Testing connection": [
  null,
  "Zkouška spojení"
 ],
 "Restoring connection": [
  null,
  "Obnovování spojení"
 ],
 "Troubleshoot…": [
  null,
  "Řešit potíže…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager není spuštěný"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager není nainstalovaný"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Síťová zařízení a grafy vyžadují NetworkManager"
 ],
 "Enable service": [
  null,
  "Zapnout službu"
 ],
 "Network interface '$0' not found": [
  null,
  "Síťové rozhraní „$0“ nenalezeno"
 ],
 "Return to overview page": [
  null,
  "Vrátit se na stránku přehledu"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nemáte oprávnění upravovat bránu firewall."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nemáte oprávnění pro vypnutí brány firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nemáte oprávnění pro zapnutí brány firewall"
 ],
 "Disable the firewall": [
  null,
  "Vypnout bránu firewall"
 ],
 "Enable the firewall": [
  null,
  "Zapnout bránu firewall"
 ],
 "Edit service $0": [
  null,
  "Upravit službu $0"
 ],
 "Remove service $0": [
  null,
  "Odebrat službu $0"
 ],
 "Included Services": [
  null,
  "Obsažené služby"
 ],
 "Additional port": [
  null,
  "Další port"
 ],
 "Remove additional port": [
  null,
  "Odebrat dodatečný port"
 ],
 "Remove zone $0": [
  null,
  "Odebrat zónu $0"
 ],
 "Add services to zone $0": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Add services": [
  null,
  "Přidat služby"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "zóna $0"
 ],
 "Interface": [
  null,
  "Rozhraní",
  "Rozhraní",
  "Rozhraní"
 ],
 "Allowed addresses": [
  null,
  "Adresy, které umožněny"
 ],
 "Entire subnet": [
  null,
  "Celá podsíť"
 ],
 "There are no active services in this zone": [
  null,
  "V této zóně se nenacházejí žádné aktivní služby"
 ],
 "Filter services": [
  null,
  "Filtrovat služby"
 ],
 "Failed to edit service": [
  null,
  "Službu se nepodařilo upravit"
 ],
 "Failed to add port": [
  null,
  "Přidání portu se nezdařilo"
 ],
 "Failed to add service": [
  null,
  "Službu se nepodařilo přidat"
 ],
 "Unknown service name": [
  null,
  "Neznámý název služby"
 ],
 "Invalid port number": [
  null,
  "Neplatné číslo portu"
 ],
 "Invalid range": [
  null,
  "Neplatný rozsah"
 ],
 "Range must be strictly ordered": [
  null,
  "Je třeba, aby rozsah byl striktně řazený"
 ],
 "Edit service": [
  null,
  "Upravit službu"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Upravit uživatelsky určenou službu v zóně $0"
 ],
 "Add ports": [
  null,
  "Přidat porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Přidat porty do zóny $0"
 ],
 "Add services to $0 zone": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Custom ports": [
  null,
  "Uživatelsky určené porty"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Příklad: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Jsou přijímány čárkou oddělované porty, rozsahy a služby"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Příklad: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Pokud nevyplněno, identifikátor bude vytvořen na základě souvisejících služeb na portu a čísel portů"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Přidání uživatelsky určených portů znovunačte firewalld. To povede ke ztrátě jakéhokoli nastavení, které bylo učiněno pouze za běhu a neuloženo!"
 ],
 "Failed to add zone": [
  null,
  "Zónu se nepodařilo přidat"
 ],
 "Add zone": [
  null,
  "Přidat zónu"
 ],
 "Trust level": [
  null,
  "Stupeň důvěryhodnosti"
 ],
 "Sorted from least to most trusted": [
  null,
  "Seřazeno od nejméně po nejvíce důvěryhodné"
 ],
 "Custom zones": [
  null,
  "Uživatelsky určené zóny"
 ],
 "No description available": [
  null,
  "Není k dispozici žádný popis"
 ],
 "Included services": [
  null,
  "Obsažené služby"
 ],
 "The cockpit service is automatically included": [
  null,
  "Služba cockpit je obsažena automaticky"
 ],
 "Interfaces": [
  null,
  "Rozhraní"
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP adresa se směrovací předponou (prefix). Vícero hodnot oddělujte čárkou. Příklad: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Potvrdit odebrání $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Tato zóna obsahuje službu cockpit. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Odebrání zóny odebere také všechny služby, které obsahuje."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Odebrání služby cockpit může vést k tomu, že webová konzole přestane být dostupná. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Odebrat službu $0 ze zóny $1"
 ],
 "Firewall is not available": [
  null,
  "Brána firewall není k dispozici"
 ],
 "Please install the $0 package": [
  null,
  "Nainstalujte balíček $0"
 ],
 "Add a new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Add new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Ve výchozím stavu jsou příchozí požadavky blokovány. Ty odchozí nejsou."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID je třeba vyplnit"
 ],
 "Password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "Failed to connect": [
  null,
  "Nepodařilo se připojit"
 ],
 "Check your password.": [
  null,
  "Zkontrolujte své heslo."
 ],
 "Connect to hidden network": [
  null,
  "Připojit se ke skryté síti"
 ],
 "Connect to $0": [
  null,
  "Připojit se k $0"
 ],
 "Network name": [
  null,
  "Název sítě"
 ],
 "Security": [
  null,
  "Zabezpečení"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 osobní"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Smazání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zapnutí $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Switch on $0": [
  null,
  "Zapnout $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vypnutí $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Switch off $0": [
  null,
  "Vypnout $0"
 ],
 "Bond": [
  null,
  "Spřažení linek (bond)"
 ],
 "Team": [
  null,
  "Spřažení linek (team)"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Most"
 ],
 "Unknown \"$0\"": [
  null,
  "Neznámé „$0“"
 ],
 "Carrier": [
  null,
  "Nosný signál"
 ],
 "Yes": [
  null,
  "Ano"
 ],
 "No": [
  null,
  "Ne"
 ],
 "Inactive": [
  null,
  "Neaktivní"
 ],
 "Unknown configuration": [
  null,
  "Neznámé nastavení"
 ],
 "Additional address $val": [
  null,
  "Další adresa $val"
 ],
 "Address $val": [
  null,
  "Adresa $val"
 ],
 "Gateway $gateway": [
  null,
  "Brána $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Další DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Další DNS domény k prohledávání $val"
 ],
 "DNS search domains $val": [
  null,
  "Prohledávat DNS domény $val"
 ],
 "General": [
  null,
  "Obecné"
 ],
 "Connect automatically": [
  null,
  "Připojit se automaticky"
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP monitorování"
 ],
 "Broken configuration": [
  null,
  "Chybné nastavení"
 ],
 "Team port": [
  null,
  "Port spřažení linek (team)"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "Priorita $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Prodleva přeposílání $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Oznamovací čas $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximální stáří zpráv $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Náklady trasy $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hair pin režim"
 ],
 "Bridge port": [
  null,
  "Port mostu"
 ],
 "Parent $parent": [
  null,
  "Nadřazené $parent"
 ],
 "ID $id": [
  null,
  "Identif. $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Heslo k síti není uloženo. Nechte ji zapomenout a znovu se pak k ní připojte."
 ],
 "Failed to connect to $0": [
  null,
  "Nepodařilo se připojit k $0"
 ],
 "secured": [
  null,
  "zabezpečené"
 ],
 "open": [
  null,
  "nešifrovaná (otevřená)"
 ],
 "Last connected: $0": [
  null,
  "Naposledy připojeno: $0"
 ],
 "Signal strength": [
  null,
  "Síla signálu"
 ],
 "Not permitted to disconnect network": [
  null,
  "Nemáte oprávnění odpojovat od sítě"
 ],
 "Disconnect": [
  null,
  "Odpojit"
 ],
 "Not permitted to connect to network": [
  null,
  "Nemáte oprávnění připojovat k síti"
 ],
 "Forget": [
  null,
  "Zapomenout"
 ],
 "$0 hidden network": [
  null,
  "$0 skrytá síť",
  "$0 skryté sítě",
  "$0 skrytých sítí"
 ],
 "Filter": [
  null,
  "Filtrovat"
 ],
 "Refresh": [
  null,
  "Načíst znovu"
 ],
 "Available networks": [
  null,
  "Sítě k dispozici"
 ],
 "Network": [
  null,
  "Síť"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Signal": [
  null,
  "Signál"
 ],
 "Rate": [
  null,
  "Rychlost"
 ],
 "Not permitted to configure network devices": [
  null,
  "Nemáte oprávnění nastavovat síťová zařízení"
 ],
 "Enable or disable the device": [
  null,
  "Povolit nebo zakázat zařízení"
 ],
 "This device cannot be managed here.": [
  null,
  "Toto zařízení zde nelze spravovat."
 ],
 "Connection will be lost": [
  null,
  "Spojení bude ztraceno"
 ],
 "Keep connection": [
  null,
  "Zachovat spojení"
 ],
 "Invalid IP address: $0": [
  null,
  "Neplatná IP adresa: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Neplatná cílová adresa: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Neplatná adresa brány: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Neplatná adresa DNS: $0"
 ],
 "Preparing": [
  null,
  "Příprava"
 ],
 "Configuring": [
  null,
  "Nastavuje se"
 ],
 "Authenticating": [
  null,
  "Ověřování se"
 ],
 "Configuring IP": [
  null,
  "Nastavuje se IP adresa"
 ],
 "Checking IP": [
  null,
  "Kontroluje se IP adresa"
 ],
 "Waiting": [
  null,
  "Čeká se"
 ],
 "Active": [
  null,
  "Aktivní"
 ],
 "Deactivating": [
  null,
  "Deaktivuje se"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Bez signálu"
 ],
 "Part of $0": [
  null,
  "Součástí $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Změna nastavení přeruší spojení se serverem a znepřístupní tak uživatelské rozhraní pro jeho správu."
 ],
 "Change the settings": [
  null,
  "Změnit nastavení"
 ],
 "Add bridge": [
  null,
  "Přidat síťový most"
 ],
 "Edit bridge settings": [
  null,
  "Upravit nastavení mostu"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "STP priorita"
 ],
 "STP forward delay": [
  null,
  "STP prodleva přeposílání"
 ],
 "STP hello time": [
  null,
  "STP uvítací doba"
 ],
 "STP maximum message age": [
  null,
  "STP maximální stáří zprávy"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Aktivní záloha"
 ],
 "Load balancing": [
  null,
  "Rozkládání zátěže"
 ],
 "Broadcast": [
  null,
  "Vysílání"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Pasivní"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Přidat spřažení (team)"
 ],
 "Edit team settings": [
  null,
  "Upravit nastavení spřažení (team)"
 ],
 "Runner": [
  null,
  "Spouštěč"
 ],
 "Balancer": [
  null,
  "Rozkládání zátěže"
 ],
 "Primary": [
  null,
  "Primární"
 ],
 "Link watch": [
  null,
  "Hlídání linky"
 ],
 "Link up delay": [
  null,
  "Prodleva aktivní linky"
 ],
 "Link down delay": [
  null,
  "Prodleva neaktivní linky"
 ],
 "Ping interval": [
  null,
  "Interval pro ping"
 ],
 "Ping target": [
  null,
  "Cíl pro ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaticky (pouze DHCP)"
 ],
 "Link local": [
  null,
  "Místní propoj"
 ],
 "Manual": [
  null,
  "Ruční"
 ],
 "Shared": [
  null,
  "Sdílené"
 ],
 "Prefix length or netmask": [
  null,
  "Délka předpony nebo maska sítě"
 ],
 "Prefix length": [
  null,
  "Délka předpony"
 ],
 "IPv4 settings": [
  null,
  "Nastavení IPv4"
 ],
 "IPv6 settings": [
  null,
  "Nastavení IPv6"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Select method": [
  null,
  "Vybrat metodu"
 ],
 "Add address": [
  null,
  "Přidat adresu"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Remove item": [
  null,
  "Odebrat položku"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Přidat DNS server"
 ],
 "DNS search domains": [
  null,
  "Prohledávané DNS domény"
 ],
 "Add search domain": [
  null,
  "Přidat prohledávanou doménu"
 ],
 "Search domain": [
  null,
  "Prohledávané domény"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Add route": [
  null,
  "Přidat trasu"
 ],
 "Metric": [
  null,
  "Metrika"
 ],
 "Enter a valid MAC address": [
  null,
  "Zadejte platnou MAC adresu"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC adresa"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 síť",
  "$0 sítě",
  "$0 sítí"
 ],
 "Add VPN": [
  null,
  "Přidat VPN"
 ],
 "Add bond": [
  null,
  "Přidat spřažení linek (bond)"
 ],
 "Add VLAN": [
  null,
  "Přidat VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Upravit pravidla a zóny"
 ],
 "$0 active zone": [
  null,
  "$0 aktivní zóna",
  "$0 aktivní zóny",
  "$0 aktivních zón"
 ],
 "Managed interfaces": [
  null,
  "Spravovaná rozhraní"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "Sending": [
  null,
  "Odesílání"
 ],
 "Receiving": [
  null,
  "Příchozí"
 ],
 "Unmanaged interfaces": [
  null,
  "Nespravovaná rozhraní"
 ],
 "Network logs": [
  null,
  "Záznamy událostí sítě"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresy nemají správný formát"
 ],
 "Invalid IP address '$0'": [
  null,
  "Neplatná IP adresa „$0“"
 ],
 "wireguard-tools package is not installed": [
  null,
  "není nainstalovaný balíček wireguard-tools"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Protějšek č.$0 nemá platný port koncového bodu. Je třeba, aby bylo zadáno jako stroj:port, např. 1.2.3.4:51820, [2001:db8::1]:51820 nebo example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Protějšek č.$0 nemá platný port koncového bodu. Je třeba, aby port bylo číslo."
 ],
 "Listen port must be a number": [
  null,
  "Je třeba, aby port, na kterém očekávat spojení, bylo číslo"
 ],
 "Add WireGuard VPN": [
  null,
  "Přidat WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Upravit WireGuard VPN"
 ],
 "Private key": [
  null,
  "Soukromý klíč"
 ],
 "Paste existing key": [
  null,
  "Vložit existující klíč"
 ],
 "Regenerate": [
  null,
  "Znovu vytvořit"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Veřejný klíč bude vytvořen v okamžiku zadání platného soukromého"
 ],
 "Listen port": [
  null,
  "Port na kterém očekávat spojení"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Bude nastaveno na „Automaticky“"
 ],
 "IP addresses": [
  null,
  "IP adresy"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Je možné zadat vícero adres (oddělovaných čárkami nebo mezerami)."
 ],
 "Peers": [
  null,
  "Protějšky"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Protějšky jsou ostatní stroje, které se připojují k tomuto. Veřejné klíč z ostatních strojů budou sdíleny mezi sebou."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Je třeba zadat koncový bod sloužící jako „server“ v podobě stroj:port, jinak je možné ponechat nevyplněné."
 ],
 "Add peer": [
  null,
  "Přidat protějšek"
 ],
 "Endpoint": [
  null,
  "Koncový bod"
 ],
 "Allowed IPs": [
  null,
  "IP adresy, které umožněny"
 ],
 "No peers added.": [
  null,
  "Nepřidány žádné protějšky."
 ],
 "Edit VLAN settings": [
  null,
  "Upravit nastavení VLAN"
 ],
 "Parent": [
  null,
  "Nadřazené"
 ],
 "VLAN ID": [
  null,
  "Identif. VLAN"
 ],
 "Transmitting": [
  null,
  "Odchozí"
 ],
 "MTU must be a positive number": [
  null,
  "Je třeba, aby MTU bylo kladné číslo"
 ],
 "Ethernet MTU": [
  null,
  "MTU ethernetu"
 ],
 "Set to": [
  null,
  "Nastavit na"
 ],
 "Team port settings": [
  null,
  "Nastavení portu spřažení linek (team)"
 ],
 "Sticky": [
  null,
  "Lepkavé"
 ],
 "LACP key": [
  null,
  "LACP klíč"
 ],
 "Bridge port settings": [
  null,
  "Nastavení portu mostu"
 ],
 "Path cost": [
  null,
  "Náklady trasy"
 ],
 "Hair pin mode": [
  null,
  "Hair pin režim"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Přizpůsobující se rozkládání přenosové zátěže odesílání"
 ],
 "Adaptive load balancing": [
  null,
  "Přizpůsobující se rozkládání zátěže"
 ],
 "MII (recommended)": [
  null,
  "MII (doporučeno)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Upravit nastavení spřažení linek (bond)"
 ],
 "Network bond": [
  null,
  "Síťové spřažení linek (bond)"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Síťové spřažení spojuje vícero síťových rozhraní do jednoho logického s vyšší propustností nebo odolností proti výpadku."
 ],
 "Link monitoring": [
  null,
  "Monitorování linky"
 ],
 "Monitoring interval": [
  null,
  "Interval monitorování"
 ],
 "Monitoring targets": [
  null,
  "Cíle monitorování"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odebrání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Remove $0": [
  null,
  "Odebrat $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Přidání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "No interfaces available": [
  null,
  "Nejsou k dispozici žádná rozhraní"
 ],
 "Add member": [
  null,
  "Přidat člena"
 ],
 "Interface members": [
  null,
  "Členové rozhraní"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ]
});
