cockpit.locale({
 "": {
  "plural-forms": ((n) => (n % 10 == 1 && (n % 100 < 11 || n % 100 > 19)) ? 0 : ((n % 10 >= 2 && n % 10 <= 9 && (n % 100 < 11 || n % 100 > 19)) ? 1 : 2)),
  "language": "lt",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 diegimas"
 ],
 "$0 installer": [
  null,
  "$0 diegyklė"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 yra MBR išplėstinis skaidinys, kuriame yra loginių skaidinių. Pašalinus visus loginius skaidinius, bus automatiškai pašalintas ir išplėstinis skaidinys."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 bus ištrinta"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "$0 negali būti šifruotas blokinis įrenginys"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' turi būti '$1' tipo įrenginyje"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  "Apie"
 ],
 "Account": [
  null,
  "Paskyra"
 ],
 "Actions": [
  null,
  "Veiksmai"
 ],
 "Add mount": [
  null,
  "Apie prijungimą"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "Additional languages": [
  null,
  "Papildomos kalbos"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Visi saugyklos rengyklėje atlikti pakeitimai įsigalioja nedelsiant."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Visi įrenginiai, naudojantys šią slaptafrazę, bus atrakinti"
 ],
 "Anaconda Web UI": [
  null,
  "„Anaconda“ žiniatinklio sąsaja"
 ],
 "Anaconda project page": [
  null,
  "Anaconda projekto puslapis"
 ],
 "Apply mount point assignment and install": [
  null,
  "Pritaikyti prijungimo taško priskyrimą ir įdiegti"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Priskirkite skaidinius prijungimo taškui. Naudinga iš anksto sukonfigūruotiems pasirinktiniams maketams."
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Laisva vieta: $0. Įdiegimui reikalinga: $1."
 ],
 "Back": [
  null,
  "Grįžti"
 ],
 "Base environment": [
  null,
  "Pagrindinė aplinka"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Tęsdami jūs suprantate ir sutinkate su negalutine programine įranga susijusiomis rizikomis bei ketinate ją naudoti tik testavimo bei kūrimo reikmėms ir pageidaujate pranešti apie bet kokias klaidas ar problemas, taip pagerinant šį darbą."
 ],
 "Cancel": [
  null,
  "Atsisakyti"
 ],
 "Change": [
  null,
  "Pakeisti"
 ],
 "Change destination": [
  null,
  "Pakeiskite paskirties vietą"
 ],
 "Change hostname": [
  null,
  "Pakeisti kompiuterio pavadinimą"
 ],
 "Change system keyboard layout": [
  null,
  ""
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Čia atlikti pakeitimai iš karto paveiks sistemą. Nėra „anuliuoti“."
 ],
 "Checking storage configuration": [
  null,
  "Tikrinama saugyklos konfigūracija"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Užverti"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "„Cockpit“ saugykloje nepateikta slaptafrazė šifruotam įrenginiui atrakinti."
 ],
 "Completed": [
  null,
  "Užbaigta"
 ],
 "Configure NTP servers": [
  null,
  "Konfigūruoti NTP serverius"
 ],
 "Configure storage": [
  null,
  "Konfigūruoti saugyklą"
 ],
 "Configure storage again": [
  null,
  "Konfigūruojti saugyklą dar kartą"
 ],
 "Confirm passphrase": [
  null,
  "Patvirtinti slaptafrazę"
 ],
 "Continue": [
  null,
  "Pratęsti"
 ],
 "Continue installation": [
  null,
  "Tęsti diegimą"
 ],
 "Continue with installation": [
  null,
  "Tęsti diegimą"
 ],
 "Create Account": [
  null,
  "Sukurti paskyrą"
 ],
 "Create account": [
  null,
  "Sukurti paskyrą"
 ],
 "Currently installed: $0": [
  null,
  "Šiuo metu įdiegta: $0"
 ],
 "Custom": [
  null,
  "Pasirinktinis"
 ],
 "Date": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Kai kurių skaidinių ištrynimas gali neleisti $0 paleisti: $1"
 ],
 "Description": [
  null,
  "Aprašymas"
 ],
 "Destination": [
  null,
  "Paskirtis"
 ],
 "Destination is encrypted": [
  null,
  "Paskirties vieta yra užšifruota"
 ],
 "Detected valid storage layout:": [
  null,
  "Aptiktas tinkamas saugyklos išdėstymas:"
 ],
 "Device": [
  null,
  "Įrenginys"
 ],
 "Duplicate device.": [
  null,
  "Dubliuotas įrenginys."
 ],
 "Duplicate mount point.": [
  null,
  "Dubliuotas prijungimo taškas."
 ],
 "Enable root account": [
  null,
  "Įgalinti root paskyrą"
 ],
 "Encrypt my data": [
  null,
  "Šifruoti mano duomenis"
 ],
 "Encrypted": [
  null,
  "Šifruota"
 ],
 "Encryption": [
  null,
  "Šifravimas"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Ištrinti duomenis ir įdiegti"
 ],
 "Error details": [
  null,
  "Detali klaida"
 ],
 "Exit to live desktop": [
  null,
  "Išeiti į tiesioginį darbalaukį"
 ],
 "Extended partition": [
  null,
  "Išplėstinis skirsnis"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "„Fedora Linux“ reikalauja mažiausiai $0 vietos diske."
 ],
 "Finalization": [
  null,
  "Baigiama"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Baigiama: sistemos konfigūracija užbaigta. Diegimo baigimas gali kiek užtrukti."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Pilnas vardas"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Pilnas vardas negali turėti dvitaškių"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Slėpti patvirtintą slaptažodį"
 ],
 "Hide passphrase": [
  null,
  "Slėpti slaptafrazę"
 ],
 "Hide password": [
  null,
  "Slėpti slaptažodį"
 ],
 "Hostname": [
  null,
  "Pagrindinio kompiuterio pavadinimas"
 ],
 "How would you like to install?": [
  null,
  "Kaip norite įdiegti?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Suprantu, kad kai kurie esami duomenys bus ištrinti"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Suprantu, kad kai kurie skirsniai bus modifikuoti"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Jei laukas tuščias, pagrindinio kompiuterio pavadinimas bus trumpalaikis ir nustatomas pagal tinklo informaciją."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Jei konfigūruojate skaidinius, reikia:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Jei nesuprantate arba nesutinkate su rizikomis, išeikite iš programos."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Vyksta"
 ],
 "Initializing...": [
  null,
  "Inicijuojama..."
 ],
 "Install": [
  null,
  "Diegti"
 ],
 "Installation failed": [
  null,
  "Diegimas nepavyko"
 ],
 "Installation method": [
  null,
  "Diegimo metodas"
 ],
 "Installation of the system failed: $0": [
  null,
  "Nepavyko įdiegti sistemos: $0"
 ],
 "Installation type": [
  null,
  "Diegimo tipas"
 ],
 "Installing": [
  null,
  "Diegiama"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Išsaugokite dabartinį disko išdėstymą ir naudokite laisvą vietą, kad galėtumėte atlikti dvigubą įkrovą su kita OS."
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  "Kalbos"
 ],
 "Launch storage editor": [
  null,
  "Paleiskite saugyklos rengyklę"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Vieta"
 ],
 "Locked devices": [
  null,
  "Užrakinti įrenginiai"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "Rankinė disko konfigūracija"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Rankinė disko konfigūracija: prijungimo taškų susiejimas"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Gali būti raidžių, skaičių ir brūkšnelių."
 ],
 "Medium": [
  null,
  "Laikmena"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Neatitikimas tarp tėvinio įrenginio ir vaikinio įrenginio performatavimo pasirinkimų."
 ],
 "Mount point": [
  null,
  "Prijungimo taškas"
 ],
 "Mount point assignment": [
  null,
  "Prijungimo taškų priskyrimas"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "Turi būti bent $0 simbolių ilgio"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "Name": [
  null,
  "Pavadinimas"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Tinklas"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Tinklas neprieinamas. Norėdami pranešti apie klaidą, sukonfigūruokite tinklą viršutinės juostos meniu."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Tinklas nepasiekiamas. Sukonfigūruokite tinklą, kad praneštumėte apie problemą."
 ],
 "Next": [
  null,
  "Kitas"
 ],
 "No devices": [
  null,
  "Nėra įrenginių"
 ],
 "No disks available": [
  null,
  "Diskų nėra"
 ],
 "No disks selected": [
  null,
  "Nepasirinkti diskai"
 ],
 "No results found": [
  null,
  "Rezultatų nerasta"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Pasirinktuose diskuose nepakanka vietos."
 ],
 "Not enough space on selected disks.": [
  null,
  "Pasirinktuose diskuose nepakanka vietos."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Pastaba: tai yra neišleista programinė įranga, kuri yra skirta tik kūrimo bei testavimo reikmėms. NENAUDOKITE šios įrangos kritiniam darbui ar realioms aplinkoms."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Operacinė sistema"
 ],
 "Options": [
  null,
  "Parametrai"
 ],
 "Partitions (advanced)": [
  null,
  "Skirsniai (išplėstiniai)"
 ],
 "Passphrase": [
  null,
  "Slaptafrazė"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Slaptafrazė neatitiko jokio užrakinto įrenginio"
 ],
 "Passphrases must match": [
  null,
  "Slaptafrazės turi sutapti"
 ],
 "Pending": [
  null,
  "Laukia"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Prisekite prie klaidos žurnalo failą $0."
 ],
 "Pool": [
  null,
  "Rinkinys"
 ],
 "Powered by Anaconda": [
  null,
  "Naudoja Anaconda"
 ],
 "Pre-release": [
  null,
  "Išankstinis leidimas"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Tęskite diegimą"
 ],
 "Quit": [
  null,
  "Išeiti"
 ],
 "Quit installer?": [
  null,
  "Išeiti iš diegyklės?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Nepavyko perskaityti informacijos apie OS."
 ],
 "Reading information about the computer failed.": [
  null,
  "Nepavyko perskaityti informacijos apie kompiuterį."
 ],
 "Reading installer configuration failed.": [
  null,
  "Nepavyko perskaityti diegyklės konfigūracijos."
 ],
 "Reading installer version information failed.": [
  null,
  "Nepavyko perskaityti diegyklės versijos informacijos."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Tikrame kompiuterio pavadinime gali būti tik raidės, skaitmenys, brūkšneliai (negali prasidėti ar pasibaigti jais) ir taškai"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Tikrasis kompiuterio pavadinimas turi būti ne ilgesnis nei 64 simboliai"
 ],
 "Reboot": [
  null,
  "Perleisti"
 ],
 "Reboot system?": [
  null,
  "Perleisti sistemą?"
 ],
 "Reclaim additional space": [
  null,
  "Susigrąžinkite papildomą vietą"
 ],
 "Reclaim space": [
  null,
  "Susigrąžinkite vietą"
 ],
 "Reclaim space (required)": [
  null,
  "Susigrąžinkite vietą (būtina)"
 ],
 "Recommended": [
  null,
  "Rekomenduojama"
 ],
 "Recommended partitions:": [
  null,
  "Rekomenduojami skirsniai:"
 ],
 "Reformat": [
  null,
  "Performatuoti"
 ],
 "Reinstall Fedora": [
  null,
  "Iš naujo įdiekite „Fedora“"
 ],
 "Remove": [
  null,
  "Pašalinti"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Pašalinkite visus pasirinktų įrenginių skaidinius, įskaitant esamas operacines sistemas."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Pašalinkite esamas failų sistemas arba pakeiskite jų dydį, kad atlaisvintumėte vietos diegimui."
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Pakeiskite esamą diegimą, bet palikite failus namuose."
 ],
 "Report Issue": [
  null,
  "Pranešti apie problemą"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Pranešti apie problemą"
 ],
 "Required": [
  null,
  "Būtina"
 ],
 "Requirements": [
  null,
  "Reikalavimai"
 ],
 "Rescan devices": [
  null,
  "Iš naujo nuskaityti įrenginius"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Nepavyko perskaityti diskų."
 ],
 "Resize": [
  null,
  "Pakeisti dydį"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Šių skaidinių dydžio keitimas iš $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Grįžkite į diegimą"
 ],
 "Return to storage editor": [
  null,
  "Grįžti į saugyklos rengyklę"
 ],
 "Review and install": [
  null,
  "Peržiūrėti ir įdiegti"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  "Root slaptažodis nustatytas."
 ],
 "Save": [
  null,
  "Išsaugoti"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Nuskaitykite QR kodą telefonu arba apsilankykite:"
 ],
 "Search for a language": [
  null,
  "Ieškokite kalbos"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Apsaugokite savo duomenis naudodami disko šifravimą. Taikoma tik naujiems skaidiniams"
 ],
 "Select": [
  null,
  "Pasirinkti"
 ],
 "Select a device": [
  null,
  "Pasirinkite įrenginį"
 ],
 "Select destination": [
  null,
  "Pasirinkite paskirties vietą"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Pasirinkto įrenginio formato „$0“ negalima suformatuoti iš naujo."
 ],
 "Send us feedback on your installation": [
  null,
  "Atsiųskite mums atsiliepimą apie įdiegimą"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "Nustatyti kompiuterio pavadinimą"
 ],
 "Show confirmed password": [
  null,
  "Rodyti patvirtintą slaptažodį"
 ],
 "Show passphrase": [
  null,
  "Rodyti slaptafrazę"
 ],
 "Show password": [
  null,
  "Rodyti slaptažodį"
 ],
 "Size": [
  null,
  "Dydis"
 ],
 "Software installation": [
  null,
  "Programinės įrangos pasirinkimas"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Programinės įrangos diegimas: saugyklos konfigūracija baigta. Programinė įranga dabar yra diegiama jūsų įrenginyje."
 ],
 "Software selection": [
  null,
  "Programinės įrangos pasirinkimas"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Trūksta kai kurių būtinų skaidinių: $0"
 ],
 "Space": [
  null,
  "Vieta"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Saugykla"
 ],
 "Storage configuration": [
  null,
  "Saugyklos konfigūracija"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Saugyklos konfigūracija: saugykla šiuo metu yra konfigūruojama."
 ],
 "Storage editor": [
  null,
  "Saugyklos redaktorius"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Saugykla pagrįsta konfigūracija iš „Keisti saugyklą“."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Saugyklos papildiniui nepavyko"
 ],
 "Storage requirements not met": [
  null,
  "Saugyklos reikalavimai nepatenkinti"
 ],
 "Strong": [
  null,
  "Stiprus"
 ],
 "Successfully installed": [
  null,
  "Sėkmingai įdiegta"
 ],
 "Successfully unlocked $0.": [
  null,
  "Sėkmingai atrakinta $0."
 ],
 "Suggested languages": [
  null,
  "Siūlomos kalbos"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Sistemos konfigūracija"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Sistemos konfigūracija: programinės įrangos diegimas baigtas. Sistema dabar yra konfigūruojama."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Diegyklė negali tęsti dėl kritinės klaidos."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Diegyklė negali tęsti dėl kritinės klaidos: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Jūsų pateiktoje slaptafrazėje yra ne ASCII simbolių. Gali būti, kad negalėsite keisti klaviatūros išdėstymų ąį įvesdami."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "Šio kompiuterio pavadinimo pateikti negalima"
 ],
 "This is unstable, pre-release software": [
  null,
  "Tai nestabili, neišleista programinė įranga"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "Tai gali užtrukti"
 ],
 "This will take a few moments": [
  null,
  "Tai užtruks keletą akimirkų"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Norėdami pradėti naudoti $0, iš naujo paleiskite sistemą."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Norėdami tęsti, pasirinkite įrenginius diegimui."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Norėdami naudoti šią parinktį, pakeiskite esamų skaidinių dydį arba pašalinkite jas, kad atlaisvintumėte bent $0."
 ],
 "Type": [
  null,
  "Tipas"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Neįmanoma suplanuoti $0 ištrynimo"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Neįmanoma suplanuoti $0 dydžio keitimo"
 ],
 "Unlock": [
  null,
  "Atrakinti"
 ],
 "Unlock encrypted devices": [
  null,
  "Atrakinti šifruotus įrenginius"
 ],
 "Use configured storage": [
  null,
  "Naudokite sukonfigūruotą saugyklą"
 ],
 "Use entire disk": [
  null,
  "Naudokite visą diską"
 ],
 "User creation": [
  null,
  "Naudotojo kūrimas"
 ],
 "User name": [
  null,
  "Naudotojo vardas"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Vartotojo varde gali būti tik: raidės nuo a iki z, skaitmenys nuo 0 iki 9, brūkšnys $0, taškas $1, pabraukimas $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Vartotojo vardas neturi būti rezervuotas žodis"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Vartotojų vardai turi būti trumpesni nei 33 simboliai"
 ],
 "Weak": [
  null,
  "Silpnas"
 ],
 "Welcome": [
  null,
  "Sveiki"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Sveiki. Įdiekime $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "„Windows“ skaidinių su „BitLocker“ šifravimu pakeisti negalima"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Čia galite atlaisvinti pakankamai vietos ir leisti diegimo vedliui tvarkyti likusią dalį arba rankiniu būdu nustatyti skaidinius."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "Jūsų progresas nebus įrašytas."
 ],
 "completed step": [
  null,
  "užbaigtas žingsnis"
 ],
 "current step": [
  null,
  "dabartinis žingsnis"
 ],
 "delete": [
  null,
  "ištrinti"
 ],
 "edit": [
  null,
  "redaguoti"
 ],
 "encrypt": [
  null,
  "šifruoti"
 ],
 "encrypted": [
  null,
  "užšifruota"
 ],
 "extended partition": [
  null,
  "išplėstinis skirsnis"
 ],
 "format as $0": [
  null,
  "formatuoti kaip $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "prijungti"
 ],
 "pending step": [
  null,
  "laukiantis žingsnis"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "dydis pakeistas iš $0"
 ],
 "shrink": [
  null,
  "sumažinti"
 ],
 "shrink to $0": [
  null,
  "sumažinti iki $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "anuliuoti"
 ]
});
