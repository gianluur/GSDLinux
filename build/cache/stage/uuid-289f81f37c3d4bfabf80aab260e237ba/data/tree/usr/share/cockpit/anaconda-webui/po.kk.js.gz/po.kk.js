cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "kk",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 қатесі"
 ],
 "$0 installation": [
  null,
  "$0 орнатуы"
 ],
 "$0 installer": [
  null,
  "$0 орнатқышы"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 - логикалық бөлімдерді қамтитын MBR кеңейтілген бөлімі. Барлық логикалық бөлімдерді өшіру кеңейтілген бөлімді де автоматты түрде өшіреді."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 қажет, бірақ тек $1 қолжетімді."
 ],
 "$0 warning": [
  null,
  "$0 ескерту"
 ],
 "$0 will be deleted": [
  null,
  "$0 өшірілетін болады"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' файлдық жүйесі шифрленген блоктық құрылғыда бола алмайды"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' $1 үшін тағайындалуы тиіс"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' '$1' түріндегі бөлімде болуы тиіс"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' EFI жүйелік бөлімінде болуы керек. Таңдалған бөлім FAT файлдық жүйесін қолданады, бірақ ESP ретінде белгіленбеген. Бөлім түрін EFI System деп қойып, esp жалаушасын іске қосыңыз."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "MDRAID $1 құрылғысында '$0' бөлімі табылды. MDRAID құрылғыларындағы жүктеуіш бөлімдеріне қолдау көрсетілмейді."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Жүйелік өзгерістер жасау үшін админ ретінде қол жеткізу мүмкіндігі бар стандартты пайдаланушы тіркелгісі."
 ],
 "Abort installation": [
  null,
  "Орнату үзу"
 ],
 "About": [
  null,
  "Осы туралы"
 ],
 "Account": [
  null,
  "Тіркелгі"
 ],
 "Actions": [
  null,
  "Әрекеттер"
 ],
 "Add another server...": [
  null,
  "Басқа серверді қосу..."
 ],
 "Add mount": [
  null,
  "Тіркелу нүктесін қосу"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Сіз таңдаған ортаға арналған қосымшалар"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Ортаңызға тән емес қосымшалар"
 ],
 "Additional languages": [
  null,
  "Қосымша тілдер"
 ],
 "Additional software for the selected environment": [
  null,
  "Таңдалған ортаға арналған қосымша бағдарламалық қамтама"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Сақтауыш түзеткішінде жасалған барлық өзгерістер дереу күшіне енеді."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Бұл кілттік фразаны қолданатын барлық құрылғылар блоктаудан босатылады"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda веб-интерфейсі"
 ],
 "Anaconda project page": [
  null,
  "Anaconda жобасының парағы"
 ],
 "Apply mount point assignment and install": [
  null,
  "Тіркеу нүктелерді тағайындауды іске асыру және орнату"
 ],
 "Applying changes...": [
  null,
  "Өзгерістерді іске асыру..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Бөлімдерді тіркеу нүктелеріне тағайындау. Алдын ала конфигурацияланған пайдаланушы жаймалары үшін пайдалы."
 ],
 "Automatic log file upload": [
  null,
  "Журналдарды автоматты түрде жүктеп салу"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Уақыт серверлерін пайдаланып, күн мен уақытты автоматты түрде орнату"
 ],
 "Automatically set timezone": [
  null,
  "Уақыт белдеуін автоматты түрде орнату"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Қолжетімді бос орын: $0. Орнату үшін қажет: $1."
 ],
 "Back": [
  null,
  "Артқа"
 ],
 "Base environment": [
  null,
  "Базалық орта"
 ],
 "Brief description of the issue": [
  null,
  "Мәселенің қысқаша сипаттамасы"
 ],
 "Bug report details": [
  null,
  "Ақаулық есептеменің толық ақпараты"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API кілті"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Бұл бағдарламалық қамтаманы қолдануды жалғастыру арқылы сіз алдын ала шығарылған бағдарламалық қамтамаға қатысты қауіптерді түсінесіз және қабылдайсыз, оны тек тестілеу және әзірлеу мақсаттары үшін пайдаланғыңыз келеді және осы жұмысты жақсарту үшін кез келген қателер мен мәселелер туралы хабарлауға дайын боласыз."
 ],
 "Cancel": [
  null,
  "Бас тарту"
 ],
 "Change": [
  null,
  "Өзгерту"
 ],
 "Change destination": [
  null,
  "Мақсатты орынды өзгерту"
 ],
 "Change hostname": [
  null,
  "Хост атын өзгерту"
 ],
 "Change partition layout": [
  null,
  "Бөлім орналасуын өзгерту"
 ],
 "Change system keyboard layout": [
  null,
  "Жүйелік пернетақта жаймасын өзгерту"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Мұнда жасалған өзгерістер жүйеге дереу әсер етеді. 'Болдырмау' мүмкіндігі жоқ."
 ],
 "Checking installation configuration...": [
  null,
  "Орнату конфигурациясын тексеру..."
 ],
 "Checking storage configuration": [
  null,
  "Сақтау құрылғылары баптауларын тексеру"
 ],
 "Clear search": [
  null,
  "Іздеуді тазарту"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Осы ескертулерге қарамастан жалғастыру үшін 'Келесі' батырмасын қайта шертіңіз."
 ],
 "Close": [
  null,
  "Жабу"
 ],
 "Close storage editor": [
  null,
  "Сақтағыш түзеткішін жабу"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit сақтағышы шифрленген құрылғының құлпын ашу үшін кілтсөзді бермеді."
 ],
 "Completed": [
  null,
  "Аяқталды"
 ],
 "Configuration is incomplete": [
  null,
  "Конфигурация толық емес"
 ],
 "Configure NTP servers": [
  null,
  "NTP серверлерін баптау"
 ],
 "Configure custom NTP servers": [
  null,
  "Реттелетін NTP серверлерін баптау"
 ],
 "Configure network": [
  null,
  "Желіні баптау"
 ],
 "Configure storage": [
  null,
  "Сақтағышты баптау"
 ],
 "Configure storage again": [
  null,
  "Сақтағышты қайта баптау"
 ],
 "Confirm passphrase": [
  null,
  "Кілттік фразаны растау"
 ],
 "Continue": [
  null,
  "Жалғастыру"
 ],
 "Continue installation": [
  null,
  "Орнату жалғастыру"
 ],
 "Continue installation?": [
  null,
  "Орнату жалғастыру керек пе?"
 ],
 "Continue with installation": [
  null,
  "Орнатуды жалғастыру"
 ],
 "Correct these issues before continuing.": [
  null,
  "Жалғастыру алдында осы мәселелерді түзетіңіз."
 ],
 "Create Account": [
  null,
  "Тіркелгі жасау"
 ],
 "Create account": [
  null,
  "Тіркелгі жасау"
 ],
 "Currently installed: $0": [
  null,
  "Қазір орнатылған: $0"
 ],
 "Custom": [
  null,
  "Таңдауыңызша"
 ],
 "Date": [
  null,
  "Күн"
 ],
 "Date and time": [
  null,
  "Күн мен уақыт"
 ],
 "Delete partition": [
  null,
  "Бөлімді өшіру"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Кейбір бөлімдерді өшіру $0 жүктелуіне кедергі келтіруі мүмкін: $1"
 ],
 "Description": [
  null,
  "Сипаттамасы"
 ],
 "Destination": [
  null,
  "Мақсаты"
 ],
 "Destination is encrypted": [
  null,
  "Мақсатты орын шифрленген"
 ],
 "Detailed description of the issue": [
  null,
  "Мәселенің толық сипаттамасы"
 ],
 "Detected valid storage layout:": [
  null,
  "Жарамды сақтауыш жаймасы анықталды:"
 ],
 "Device": [
  null,
  "Құрылғы"
 ],
 "Duplicate device.": [
  null,
  "Қайталанатын құрылғы."
 ],
 "Duplicate mount point.": [
  null,
  "Қайталанатын тіркеу нүктесі."
 ],
 "Enable root account": [
  null,
  "root тіркелгісін іске қосу"
 ],
 "Encrypt my data": [
  null,
  "Менің деректерімді шифрлеу"
 ],
 "Encrypted": [
  null,
  "Шифрленген"
 ],
 "Encryption": [
  null,
  "Шифрлеу"
 ],
 "Enter PIN": [
  null,
  "PIN енгізу"
 ],
 "Enter PIN to access the installer": [
  null,
  "Орнатқышқа қол жеткізу үшін PIN енгізіңіз"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Ақаулық туралы есепті жасау үшін өзіңіздің Bugzilla API кілтін енгізіңіз. Келесі қадамда сіз ақаулықтың толық ақпаратын қарап, түзете алатын боласыз."
 ],
 "Environment": [
  null,
  "Орта"
 ],
 "Erase data and install": [
  null,
  "Деректерді өшіру және орнату"
 ],
 "Error details": [
  null,
  "Қате ақпараты"
 ],
 "Exit to live desktop": [
  null,
  "Жұмыс үстеліне шығу"
 ],
 "Extended partition": [
  null,
  "Кеңейтілген бөлім"
 ],
 "Failed to report issue": [
  null,
  "Мәселе туралы хабарлау сәтсіз аяқталды"
 ],
 "Failed to save layouts": [
  null,
  "Жаймаларды сақтау сәтсіз аяқталды"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux үшін кемінде $0 диск орны қажет."
 ],
 "Finalization": [
  null,
  "Аяқтау"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Аяқтау: Жүйені баптау аяқталды. Орнатуды аяқтау біраз уақытты алуы мүмкін."
 ],
 "Find layout": [
  null,
  "Жайманы табу"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Жақсырақ қауіпсіздік үшін root тіркелгісін тікелей қолданбаңыз. Оның орнына жүйені басқару үшін жоғарыдағы жергілікті тіркелгіні қолданыңыз."
 ],
 "Full name": [
  null,
  "Толық аты"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Толық атында үтірлер болмауы тиіс"
 ],
 "Helper text": [
  null,
  "Көмекші мәтін"
 ],
 "Hide API key": [
  null,
  "API кілтін жасыру"
 ],
 "Hide PIN": [
  null,
  "PIN жасыру"
 ],
 "Hide confirmed password": [
  null,
  "Расталған парольді жасыру"
 ],
 "Hide passphrase": [
  null,
  "Кілттік фразаны жасыру"
 ],
 "Hide password": [
  null,
  "Парольді жасыру"
 ],
 "Hostname": [
  null,
  "Хост аты"
 ],
 "How would you like to install?": [
  null,
  "Қалай орнатуды қалайсыз?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Мен таңдалған дискілердегі барлық бар деректердің өшірілетінін түсінемін"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Мен кейбір бар деректердің өшірілетінін түсінемін"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Мен кейбір бөлімдердің өзгертілетінін түсінемін"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Егер бос болса, хост аты уақытша болады және желілік ақпарат арқылы орнатылады."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Егер жоғарыдағы опциялардың ешқайсысы сәйкес келмесе, жалғастырмас бұрын пайдаланушылық бөлімдеуді жасау үшін сақтау қоймасының өңдегішін пайдаланыңыз."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Егер бөлімдерді конфигурацияласаңыз, келесілер қажет:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Егер лог файлдарын автоматты түрде жүктеп салуға келіспесеңіз, оның орнына $0 аласыз. Қолмен хабарлау сізге лог файлдарын қарап шығуға және таңдамалы түрде тіркеуге мүмкіндік береді."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Егер сіз қауіп-қатерді түсінбесеңіз немесе қабылдамасаңыз, осы бағдарламадан шығыңыз."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Егер мәселеңіз жоғарыдағы ақаулардың біріне сәйкес келсе, қайталанатын есеп жасаудың орнына оны ашып, ақпаратыңызды сонда қоса аласыз."
 ],
 "In progress": [
  null,
  "Орындалу үстінде"
 ],
 "Initializing...": [
  null,
  "Инициализациялануда..."
 ],
 "Install": [
  null,
  "Орнату"
 ],
 "Installation completed": [
  null,
  "Орнату аяқталды"
 ],
 "Installation failed": [
  null,
  "Орнату сәтсіз аяқталды"
 ],
 "Installation method": [
  null,
  "Орнату тәсілі"
 ],
 "Installation of the system failed": [
  null,
  "Жүйені орнату сәтсіз аяқталды"
 ],
 "Installation of the system failed: $0": [
  null,
  "Жүйені орнату сәтсіз аяқталды: $0"
 ],
 "Installation type": [
  null,
  "Орнату түрі"
 ],
 "Installing": [
  null,
  "Орнатылуда"
 ],
 "Insufficient disk space": [
  null,
  "Диск орны жеткіліксіз"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Жарамсыз PIN. Қайталап көріңіз."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Жарамсыз RAID конфигурациясы анықталды. Егер RAID массиві тікелей дискілердің үстінде жасалса, массивте бөлімдер кестесі жасалуы тиіс. Егер RAID массиві бөлімдердің үстінде жасалса, ол бір файлдық жүйені немесе пішімді (мысалы, LVM PV) қамтуы тиіс. Осы массивтегі кез келген бар бөлімдер еленбейді."
 ],
 "Invalid hostname": [
  null,
  "Жарамсыз хост аты"
 ],
 "Jump to first incomplete step": [
  null,
  "Бірінші толық емес қадамға өту"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Басқа ОЖ-мен қатар жүктеу үшін ағымдағы диск жаймасын сақтау және қолжетімді орынды пайдалану."
 ],
 "Keyboard": [
  null,
  "Пернетақта"
 ],
 "Keyboard layout during boot": [
  null,
  "Жүктелу кезіндегі пернетақта жаймасы"
 ],
 "Language": [
  null,
  "Тіл"
 ],
 "Launch storage editor": [
  null,
  "Сақтауыш түзеткішін орындау"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Конфигурациядағы шектелген қол жеткізу туралы көбірек білу"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Бос парольді қолдану үшін екі кілттік фраза өрісін де бос қалдырыңыз."
 ],
 "Location": [
  null,
  "Орналасу"
 ],
 "Locked devices": [
  null,
  "Құлыпталған құрылғылар"
 ],
 "Log in": [
  null,
  "Кіру"
 ],
 "Make current": [
  null,
  "Ағымдағы қылу"
 ],
 "Manual disk configuration": [
  null,
  "Дисктерді қолмен баптау"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Дисктерді қолмен баптау: Тіркеу нүктелерін сәйкестендіру"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Әріптер, сандар және сызықшалардан тұруы мүмкін."
 ],
 "May need more free space": [
  null,
  "Көбірек бос орын қажет болуы мүмкін"
 ],
 "Medium": [
  null,
  "Орташа"
 ],
 "Minimum of $0 required": [
  null,
  "Кем дегенде $0 қажет"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Аталық құрылғы мен еншілес құрылғыны қайта пішімдеу таңдауы арасындағы сәйкессіздік."
 ],
 "Mount point": [
  null,
  "Тіркеу нүктесі"
 ],
 "Mount point assignment": [
  null,
  "Тіркеу нүктелерін тағайындау"
 ],
 "Move down": [
  null,
  "Төмен жылжыту"
 ],
 "Move up": [
  null,
  "Жоғары жылжыту"
 ],
 "Must be at least $0 characters": [
  null,
  "Кем дегенде $0 таңбадан тұруы тиіс"
 ],
 "My issue is different, continue": [
  null,
  "Менің мәселем басқа, жалғастыру"
 ],
 "NTP Servers": [
  null,
  "NTP серверлері"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Аты"
 ],
 "Needs at least $0": [
  null,
  "Кем дегенде $0 қажет"
 ],
 "Network": [
  null,
  "Желі"
 ],
 "Network Configuration": [
  null,
  "Желі баптауы"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Желі қолжетімді емес. Мәселені хабарлау үшін жоғарыдағы панель мәзірінде желіні баптаңыз."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Желі қолжетімді емес. Мәселе туралы хабарлау үшін желіні баптаңыз."
 ],
 "Network plugin failed": [
  null,
  "Желі плагині сәтсіз аяқталды"
 ],
 "Next": [
  null,
  "Келесі"
 ],
 "No devices": [
  null,
  "Құрылғылар жоқ"
 ],
 "No disks available": [
  null,
  "Қолжетімді дискілер жоқ"
 ],
 "No disks selected": [
  null,
  "Дисктер таңдалмады"
 ],
 "No keyboard layouts selected": [
  null,
  "Бірде-бір пернетақта жаймасы таңдалмады"
 ],
 "No layouts selected yet": [
  null,
  "Әлі ешқандай жайма таңдалмады"
 ],
 "No results found": [
  null,
  "Нәтижелер жоқ"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Таңдалған пернетақта жаймалары үшін жарамды VConsole пернелер картасын алу мүмкін емес. Басқа пернетақта жаймасын таңдаңыз."
 ],
 "Not enough available free space": [
  null,
  "Бос орын жеткіліксіз"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Таңдалған дисктерде бос орын жеткіліксіз."
 ],
 "Not enough space on selected disks.": [
  null,
  "Таңдалған дисктерде орын жеткіліксіз."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Ескерту: Бұл тек әзірлеу және сынау мақсаттарына арналған алдын ала шығарылған бағдарламалық қамтама. Бұл бағдарламалық қамтаманы кез келген маңызды жұмыс немесе өндіріс ортасы үшін ҚОЛДАНБАҢЫЗ."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Bugzilla ақаулықты енгізу пішінін ашу"
 ],
 "Operating system": [
  null,
  "Операциялық жүйе"
 ],
 "Options": [
  null,
  "Опциялар"
 ],
 "Other keyboards": [
  null,
  "Басқа пернетақталар"
 ],
 "Partitions (advanced)": [
  null,
  "Бөлімдер (кеңейтілген)"
 ],
 "Passphrase": [
  null,
  "Кілттік фраза"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Кілттік фраза бірде-бір құлыпталған құрылғыға сәйкес келмейді"
 ],
 "Passphrases must match": [
  null,
  "Кілттік фразалар өзара сәйкес келуі тиіс"
 ],
 "Pending": [
  null,
  "Күту"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Мәселеге $0 журнал файлын тіркеңіз."
 ],
 "Please enter a PIN": [
  null,
  "PIN енгізіңіз"
 ],
 "Please select at least one disk to continue": [
  null,
  "Жалғастыру үшін кем дегенде бір дискіні таңдаңыз"
 ],
 "Pool": [
  null,
  "Пул"
 ],
 "Potential duplicate bugs found": [
  null,
  "Ықтимал қайталанатын ақаулар табылды"
 ],
 "Powered by Anaconda": [
  null,
  "Anaconda негізінде"
 ],
 "Pre-release": [
  null,
  "Алдын ала шығарылымы"
 ],
 "Prefer to report manually? $0": [
  null,
  "Қолмен хабарлауды қалайсыз ба? $0"
 ],
 "Proceed with installation": [
  null,
  "Орнатуды жалғастыру"
 ],
 "Quit": [
  null,
  "Шығу"
 ],
 "Quit installer?": [
  null,
  "Орнатқыштан шығу керек пе?"
 ],
 "Reading information about the OS failed.": [
  null,
  "ОЖ туралы ақпаратты оқу сәтсіз аяқталды."
 ],
 "Reading information about the computer failed.": [
  null,
  "Компьютер туралы ақпаратты оқу сәтсіз аяқталды."
 ],
 "Reading installer configuration failed.": [
  null,
  "Орнатқыш баптауларын оқу сәтсіз аяқталды."
 ],
 "Reading installer version information failed.": [
  null,
  "Орнатқыш нұсқасы ақпаратын оқу сәтсіз аяқталды."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Нақты хост аты тек таңбалардан, цифрлардан, сызықшалардан (басында немесе соңында емес) және нүктелерден тұруы мүмкін"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Нақты хост аты 64 таңбадан аспауы керек"
 ],
 "Reboot": [
  null,
  "Қайта жүктеу"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "BitLocker-мен шифрленген бөлімдердің өлшемін өзгерту үшін Windows-қа қайта жүктеңіз. Орнату үшін кем дегенде $0 бос орын дайындаңыз."
 ],
 "Reboot system?": [
  null,
  "Жүйені қайта іске қосу керек пе?"
 ],
 "Reclaim additional space": [
  null,
  "Қосымша орынды босату"
 ],
 "Reclaim space": [
  null,
  "Орынды босату"
 ],
 "Reclaim space (required)": [
  null,
  "Орынды босату (қажет)"
 ],
 "Recommended": [
  null,
  "Ұсынылатын"
 ],
 "Recommended partitions:": [
  null,
  "Ұсынылатын бөлімдер:"
 ],
 "Reformat": [
  null,
  "Қайта пішімдеу"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora-ны қайта орнату"
 ],
 "Remove": [
  null,
  "Өшіру"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Таңдалған құрылғылардағы барлық бөлімдерді, соның ішінде бар операциялық жүйелерді өшіру."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Орнату үшін орын босату мақсатында бар файлдық жүйелерді өшіру немесе өлшемін өзгерту."
 ],
 "Remove server": [
  null,
  "Серверді өшіру"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Файлдық жүйені өшіру оның ішіндегі барлық деректерді біржола өшіреді. Бөлімнің өлшемін өзгерту пайдаланылмаған орынды босатуы мүмкін, бірақ бұл қауіпсіз емес. Орынды босатпас бұрын маңызды деректердің резервтік көшірмелері бар екеніне көз жеткізіңіз."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Ағымдағы орнатуды ауыстыру, бірақ home ішіндегі файлдарды сақтау."
 ],
 "Report Issue": [
  null,
  "Мәселе туралы хабарлау"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Bugzilla ақаулықты енгізу $0 пішінін ашу арқылы ақаулық туралы хабарлаңыз немесе кері байланыс беріңіз."
 ],
 "Report issue": [
  null,
  "Мәселе туралы хабарлау"
 ],
 "Reporting issue...": [
  null,
  "Ақаулық туралы хабарлануда..."
 ],
 "Required": [
  null,
  "Міндетті"
 ],
 "Requirements": [
  null,
  "Талаптар"
 ],
 "Rescan devices": [
  null,
  "Құрылғыларды қайта сканерлеу"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Дисктерді қайта сканерлеу сәтсіз аяқталды."
 ],
 "Resize": [
  null,
  "Өлшемін өзгерту"
 ],
 "Resize partition": [
  null,
  "Бөлім өлшемін өзгерту"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "$0 ішінен келесі бөлімдердің өлшемін өзгерту: $1"
 ],
 "Restrict access to the report": [
  null,
  "Есепке қол жеткізуді шектеу"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Есепті $0 тобына шектейді. $1"
 ],
 "Return to installation": [
  null,
  "Орнатуға қайту"
 ],
 "Return to storage editor": [
  null,
  "Сақтауыш түзеткішіне оралу"
 ],
 "Review and install": [
  null,
  "Қарап шығу және орнату"
 ],
 "Root account has been configured": [
  null,
  "Root тіркелгісі бапталды"
 ],
 "Root account is enabled": [
  null,
  "Root тіркелгісі іске қосылған"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root тіркелгісі іске қосылған, бірақ ешбір пайдаланушы тіркелгісі бапталмаған"
 ],
 "Root password has been set.": [
  null,
  "Root паролі орнатылған."
 ],
 "Save": [
  null,
  "Сақтау"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Телефоныңызбен QR кодын сканерлеңіз немесе мына сілтемеге өтіңіз:"
 ],
 "Search for a language": [
  null,
  "Тілді іздеу"
 ],
 "Search for additional software": [
  null,
  "Қосымша бағдарламалық қамтаны іздеу"
 ],
 "Search for an environment": [
  null,
  "Ортаны іздеу"
 ],
 "Search keyboard layout": [
  null,
  "Тілді таңдау"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Деректеріңізді диск негізіндегі шифрлеу арқылы қорғаңыз. Тек жаңа бөлімдерге іске асырылады"
 ],
 "Select": [
  null,
  "Таңдау"
 ],
 "Select a device": [
  null,
  "Құрылғыны таңдау"
 ],
 "Select city": [
  null,
  "Таңдау"
 ],
 "Select destination": [
  null,
  "Мақсатын таңдау"
 ],
 "Select region": [
  null,
  "Аймақты таңдау"
 ],
 "Selected (top = current)": [
  null,
  "Таңдалған (жоғарғысы = ағымдағы)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Таңдалған құрылғының \"$0\" пішімін қайта пішімдеу мүмкін емес."
 ],
 "Send us feedback on your installation": [
  null,
  "Орнату туралы пікір жіберіңіз"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server is not reachable": [
  null,
  "Сервер қолжетімді емес"
 ],
 "Set custom hostname": [
  null,
  "Хост атын орнату"
 ],
 "Share disk with other operating systems": [
  null,
  "Дискті басқа операциялық жүйелермен бөлісу"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Дискті басқа операциялық жүйелермен бөлісу: $0"
 ],
 "Show AM/PM": [
  null,
  "AM/PM көрсету"
 ],
 "Show API key": [
  null,
  "API кілтін көрсету"
 ],
 "Show PIN": [
  null,
  "PIN көрсету"
 ],
 "Show confirmed password": [
  null,
  "Расталған парольді көрсету"
 ],
 "Show passphrase": [
  null,
  "Кілттік фразаны көрсету"
 ],
 "Show password": [
  null,
  "Парольді көрсету"
 ],
 "Size": [
  null,
  "Өлшемі"
 ],
 "Software installation": [
  null,
  "Бағд. қамтаманы орнату"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Бағд. қамтаманы орнату: Сақтауышты баптау аяқталды. Енді бағдарламалық қамтама құрылғыңызға орнатылып жатыр."
 ],
 "Software selection": [
  null,
  "Бағд. қамтаманы таңдау"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Жалғастыру үшін әлі де кейбір орнату қадамдарын орындау керек."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Кейбір қажетті бөлімдер жоқ: $0"
 ],
 "Space": [
  null,
  "Орын"
 ],
 "Stacktrace": [
  null,
  "Стек трейсі"
 ],
 "Storage": [
  null,
  "Сақтауыш"
 ],
 "Storage configuration": [
  null,
  "Сақтауыш құрылғылар баптаулары"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Сақтауыш баптаулары: Ағымдағы уақытта сақтауыш бапталуда."
 ],
 "Storage editor": [
  null,
  "Сақтауыш түзеткіші"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Сақтауыш 'Сақтауышты түзету' конфигурациясына негізделген."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Сақтау қоймасының жаймасы kickstart файлымен анықталған. Жоспарланған бөлімдер жаймасын қорытынды қадамында қарап шығуға болады."
 ],
 "Storage plugin failed": [
  null,
  "Сақтауыш плагині істен шықты"
 ],
 "Storage requirements not met": [
  null,
  "Сақтауыш орны талаптары орындалмады"
 ],
 "Strong": [
  null,
  "Күшті"
 ],
 "Successfully installed": [
  null,
  "Сәтті орнатылды"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 құлыптаудан сәтті босатылды."
 ],
 "Suggested keyboards": [
  null,
  "Ұсынылатын пернетақталар"
 ],
 "Suggested languages": [
  null,
  "Ұсынылатын тілдер"
 ],
 "System": [
  null,
  "Жүйе"
 ],
 "System configuration": [
  null,
  "Жүйе баптаулары"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Жүйе баптаулары: Бағд. қамтаманы орнату аяқталды. Жүйе енді бапталуда."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda орнатуы күтпеген түрде аяқталды."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Төмендегі ашық ақаулар мәселеңізге қатысты болуы мүмкін. Жаңа есеп жасамас бұрын оларды тексеріңіз."
 ],
 "The following user will be created:": [
  null,
  "Келесі пайдаланушы(лар) жасалады:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Орнату үшін $0 диск орны қажет; дегенмен, таңдалған дискілердің сыйымдылығы тек $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Орнатқыш өз жұмысын қатаң қате салдарынан жалғастыра алмайды."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Орнатқыш өз жұмысын қатаң қате салдарынан жалғастыра алмайды: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Дискіні шифрлеу кілттік фразасы орнатылғаннан бері пернетақта жаймасы өзгерді. Кілттік фразаны қайта енгізіңіз."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Сіз көрсеткен кілттік фразада ASCII емес таңбалар бар. Теру кезінде пернетақта жаймалары арасында ауыса алмауыңыз мүмкін."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Таңдалған әдепкі пернетақта жаймасы ASCII таңбаларына қолдау көрсетпейді. Әдепкі ретінде ASCII-ді қолдайтын жайманы таңдаңыз."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Сақтауыш түзеткіші бөлімдердің өлшемін өзгертуге, өшіруге және жасауға мүмкіндік береді. Ол LVM және т.б. баптай алады. Ол кеңейтілген утилита ретінде пайдалануға арналған және әдеттегі орнату кезінде пайдалануға арналмаған."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Бұл лог файлдарында IP адрестері, пайдаланушы аттары немесе басқа жүйелік мәліметтер сияқты сезімтал ақпарат болуы мүмкін."
 ],
 "This hostname can't be submitted": [
  null,
  "Бұл хост атын жіберу мүмкін емес"
 ],
 "This is unstable, pre-release software": [
  null,
  "Бұл тұрақсыз, шығарылымға дейінгі бағд. қамтама"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Бұл жайма жүйені жүктеу кезінде құлпын ашу үшін пайдаланылады"
 ],
 "This may take a moment": [
  null,
  "Бұл біраз уақытты алуы мүмкін"
 ],
 "This will take a few moments": [
  null,
  "Бұл біраз уақыт алады"
 ],
 "Time": [
  null,
  "Уақыт"
 ],
 "Timezone": [
  null,
  "Уақыт белдеуі"
 ],
 "Title": [
  null,
  "Атауы"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0 пайдалануды бастау үшін жүйені қайта жүктеңіз."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Жалғастыру үшін, жүйе орнатылатын құрылғыларды таңдаңыз."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Бұл опцияны қолдану үшін, кем дегенде $0 босату үшін бар болып тұрған бөлімдер өлшемдерін өзгертіңіз немесе оларды өшіріңіз."
 ],
 "Type": [
  null,
  "Түрі"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0 өшіруді жоспарлау мүмкін емес"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0 өлшемін өзгертуді жоспарлау мүмкін емес"
 ],
 "Undo last action": [
  null,
  "Соңғы әрекетті болдырмау"
 ],
 "Unlock": [
  null,
  "Босату"
 ],
 "Unlock encrypted devices": [
  null,
  "Шифрленген құрылғыларды босату"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Бар деректерді сақтау және көбірек орнату әдістерін көрсету үшін шифрленген бөлімдердің құлпын ашыңыз."
 ],
 "Use configured storage": [
  null,
  "Бапталған сақтауыш орнын пайдалану"
 ],
 "Use entire disk": [
  null,
  "Бүкіл дискіні пайдалану"
 ],
 "Use free space": [
  null,
  "Бос орынды пайдалану"
 ],
 "Use local account": [
  null,
  "Жергілікті тіркелгіні пайдалану"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Автоматты түрде бөлімдерге бөлу үшін RAID құрылғысын пайдалану"
 ],
 "User creation": [
  null,
  "Пайдаланушыны жасау"
 ],
 "User name": [
  null,
  "Пайдаланушы аты"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Пайдаланушы атында тек мыналар болуы мүмкін: a-z әріптері, 0-9 цифрлары, дефис $0, нүкте $1, астын сызу $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Пайдаланушы аты резервтелген сөз болмауы тиіс"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Пайдаланушы аты 33 таңбадан қысқа болуы тиіс"
 ],
 "Validating...": [
  null,
  "Тексерілуде..."
 ],
 "Weak": [
  null,
  "Әлсіз"
 ],
 "Welcome": [
  null,
  "Қош келдіңіз"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Fedora Linux жүйесіне қош келдіңіз"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Қош келдіңіз. Енді $0 орнатайық."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Осы ақаулық туралы есепті жіберген кезде, келесі лог файлдары автоматты түрде жүктеп салынады: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker шифрлеуі бар Windows бөлімдерінің өлшемін өзгерту мүмкін емес"
 ],
 "You can close this browser window now.": [
  null,
  "Бұл браузер терезесін енді жабуға болады."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Осында жеткілікті орын босатып, қалғанын орнатқышқа тапсыра аласыз немесе бөлімдерді қолмен баптай аласыз."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Bugzilla тіркелгіңіз үшін API кілтін $0 жасай аласыз."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Жалғастыру үшін root тіркелгісін іске қосу немесе жергілікті пайдаланушы тіркелгісін жасау керек."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Автоматты күн мен уақытты іске қосу үшін желіге қосылған болуыңыз керек."
 ],
 "Your progress will not be saved.": [
  null,
  "Сіздің үрдісіңіз сақталмайды."
 ],
 "completed step": [
  null,
  "аяқталған қадам"
 ],
 "current step": [
  null,
  "ағымдағы қадам"
 ],
 "delete": [
  null,
  "өшіру"
 ],
 "edit": [
  null,
  "түзету"
 ],
 "encrypt": [
  null,
  "шифрлеу"
 ],
 "encrypted": [
  null,
  "шифрленген"
 ],
 "extended partition": [
  null,
  "кеңейтілген бөлім"
 ],
 "format as $0": [
  null,
  "$0 ретінде пішімдеу"
 ],
 "here": [
  null,
  "осында"
 ],
 "incomplete": [
  null,
  "толық емес"
 ],
 "mount": [
  null,
  "тіркеу"
 ],
 "pending step": [
  null,
  "күту қадамы"
 ],
 "report the issue manually": [
  null,
  "ақаулық туралы қолмен хабарлай"
 ],
 "resized from $0": [
  null,
  "$0 өлшемінен өзгертілген"
 ],
 "shrink": [
  null,
  "сығу"
 ],
 "shrink to $0": [
  null,
  "$0 дейін сығу"
 ],
 "transient, will use DHCP": [
  null,
  "уақытша, DHCP қолданатын болады"
 ],
 "undo": [
  null,
  "болдырмау"
 ]
});
