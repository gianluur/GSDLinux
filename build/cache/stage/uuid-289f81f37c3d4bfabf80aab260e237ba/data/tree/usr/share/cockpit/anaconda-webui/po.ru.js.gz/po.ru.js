cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 ошибка",
  "$0 ошибки",
  "$0 ошибок"
 ],
 "$0 installation": [
  null,
  "Установка $0"
 ],
 "$0 installer": [
  null,
  "Программа установки $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 - это расширенный раздел MBR, содержащий логические разделы. Удаление всех логических разделов также автоматически удалит расширенный раздел."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Требуется $0, но имеется только $1."
 ],
 "$0 warning": [
  null,
  "$0 предупреждение",
  "$0 предупреждения",
  "$0 предупреждений"
 ],
 "$0 will be deleted": [
  null,
  "$0 будет удалён"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Файловая система '$0' не может находиться на зашифрованном блочном устройстве"
 ],
 "'$0' must be assigned to $1": [
  null,
  "«$0» должно быть назначено на $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' должно находиться на устройстве, отформатированном под '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "«$0» должен находиться на разделе EFI System. Выбранный раздел использует файловую систему FAT, но не помечен как ESP. Установите тип раздела на EFI System и включите флаг esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Найден раздел „$0“ на MDRAID-устройстве $1. Разделы загрузчика на устройствах MDRAID не поддерживаются."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Стандартная учетная запись пользователя с правами администратора для внесения общесистемных изменений."
 ],
 "Abort installation": [
  null,
  "Прервать установку"
 ],
 "About": [
  null,
  "О программе"
 ],
 "Account": [
  null,
  "Учётная запись"
 ],
 "Actions": [
  null,
  "Действия"
 ],
 "Add another server...": [
  null,
  "Добавить другой сервер…"
 ],
 "Add mount": [
  null,
  "Добавить точку монтирования"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Дополнения к выбранному окружению"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Не относящиеся к окружению дополнения"
 ],
 "Additional languages": [
  null,
  "Дополнительные языки"
 ],
 "Additional software for the selected environment": [
  null,
  "Дополнительное ПО для выбранного вами окружения"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Все изменения, сделанные в редакторе хранилищ, вступают в силу немедленно."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Все устройства, использующие эту парольную фразу, будут разблокированы"
 ],
 "Anaconda Web UI": [
  null,
  "Веб-интерфейс Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Страница проекта Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Применить назначение точки монтирования и установить"
 ],
 "Applying changes...": [
  null,
  "Применение изменений..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Назначение разделов точкам монтирования. Подходит для заранее настроенной разметки диска."
 ],
 "Automatic log file upload": [
  null,
  "Автоматическая загрузка файла журнала"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Автоматическая установка даты и времени с исп. серверов времени"
 ],
 "Automatically set timezone": [
  null,
  "Автоматическая установка часового пояса"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Доступное пространство: $0. Требуется для установки: $1."
 ],
 "Back": [
  null,
  "Назад"
 ],
 "Base environment": [
  null,
  "Базовое окружение"
 ],
 "Brief description of the issue": [
  null,
  "Краткое описание проблемы"
 ],
 "Bug report details": [
  null,
  "Подробности сообщения об ошибке"
 ],
 "Bugzilla API key": [
  null,
  "Ключ API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Продолжая использовать это программное обеспечение, вы понимаете и принимате риски, связанные с предварительной версией программного обеспечения, и вы намереваетесь использовать его только для тестирования и разработки и готовы сообщать обо всех ошибках и проблемах, чтобы улучшить эту работу."
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change destination": [
  null,
  "Изменить назначение"
 ],
 "Change hostname": [
  null,
  "Изменить имя узла"
 ],
 "Change partition layout": [
  null,
  "Изменить схему разделов"
 ],
 "Change system keyboard layout": [
  null,
  "Изменить системную раскладку клавиатуры"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Изменения, внесенные здесь, немедленно отразятся на системе. Опции отмены нет."
 ],
 "Checking installation configuration...": [
  null,
  "Проверка конфигурации установки..."
 ],
 "Checking storage configuration": [
  null,
  "Проверка настроек устройств хранения"
 ],
 "Clear search": [
  null,
  "Сбросить поиск"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Нажмите «Далее» ещё раз, чтобы проигнорировать предупреждения и продолжить."
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Close storage editor": [
  null,
  "Закрыть редактор хранилища"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Хранилище Cockpit не предоставило кодовую фразу для разблокировки зашифрованного устройства."
 ],
 "Completed": [
  null,
  "Завершено"
 ],
 "Configuration is incomplete": [
  null,
  "Конфигурация неполная"
 ],
 "Configure NTP servers": [
  null,
  "Настроить серверы NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Настройка пользовательских серверов NTP"
 ],
 "Configure network": [
  null,
  "Настройка сети"
 ],
 "Configure storage": [
  null,
  "Настройка хранилища"
 ],
 "Configure storage again": [
  null,
  "Снова настройте хранилище"
 ],
 "Confirm passphrase": [
  null,
  "Подтвердите парольную фразу"
 ],
 "Continue": [
  null,
  "Продолжить"
 ],
 "Continue installation": [
  null,
  "Продолжить установку"
 ],
 "Continue installation?": [
  null,
  "Продолжить установку?"
 ],
 "Continue with installation": [
  null,
  "Продолжение установки"
 ],
 "Correct these issues before continuing.": [
  null,
  "Исправьте эти проблемы, прежде чем продолжить."
 ],
 "Create Account": [
  null,
  "Создание уч. записи"
 ],
 "Create account": [
  null,
  "Создать уч. запись"
 ],
 "Currently installed: $0": [
  null,
  "Сейчас установлена: $0"
 ],
 "Custom": [
  null,
  "По-своему"
 ],
 "Date": [
  null,
  "Дата"
 ],
 "Date and time": [
  null,
  "Дата и время"
 ],
 "Delete partition": [
  null,
  "Удалить раздел"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Удаление некоторых разделов может помешать загрузке $0: $1"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Destination": [
  null,
  "Назначение"
 ],
 "Destination is encrypted": [
  null,
  "Место назначения зашифровано"
 ],
 "Detailed description of the issue": [
  null,
  "Подробное описание проблемы"
 ],
 "Detected valid storage layout:": [
  null,
  "Обнаруженая действительная схема хранения:"
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Duplicate device.": [
  null,
  "Дублирование устройства."
 ],
 "Duplicate mount point.": [
  null,
  "Дублирование точки монтирования."
 ],
 "Enable root account": [
  null,
  "Включить учётную запись root"
 ],
 "Encrypt my data": [
  null,
  "Зашифровать данные"
 ],
 "Encrypted": [
  null,
  "Зашифровано"
 ],
 "Encryption": [
  null,
  "Шифрование"
 ],
 "Enter PIN": [
  null,
  "Введите ПИН-код"
 ],
 "Enter PIN to access the installer": [
  null,
  "Введите ПИН-код для доступа к установщику"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Чтобы создать отчет об ошибке, введите свой API-ключ Bugzilla. На следующем шаге вы сможете просмотреть и отредактировать сведения об ошибке."
 ],
 "Environment": [
  null,
  "Окружение"
 ],
 "Erase data and install": [
  null,
  "Стереть данные и установить"
 ],
 "Error details": [
  null,
  "Сведения об ошибке"
 ],
 "Exit to live desktop": [
  null,
  "Выйти на рабочий стол"
 ],
 "Extended partition": [
  null,
  "Расширенный раздел"
 ],
 "Failed to report issue": [
  null,
  "Не удалось сообщить о проблеме"
 ],
 "Failed to save layouts": [
  null,
  "Не удалось сохранить схему разбиения разделов"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux требует не менее $0 дискового пространства."
 ],
 "Finalization": [
  null,
  "Завершение"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Завершение: настройка системы завершена. Завершение установки может занять некоторое время."
 ],
 "Find layout": [
  null,
  "Найти раскладку"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "В целях безопасности избегайте прямого использования учётной записи root. Вместо этого используйте локальную учётную запись, указанную выше, для управления системой."
 ],
 "Full name": [
  null,
  "Полное имя"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Полное имя не может содержать двоеточий"
 ],
 "Helper text": [
  null,
  "Текст справки"
 ],
 "Hide API key": [
  null,
  "Скрыть API-ключ"
 ],
 "Hide PIN": [
  null,
  "Скрыть ПИН-код"
 ],
 "Hide confirmed password": [
  null,
  "Скрыть подтвержденный пароль"
 ],
 "Hide passphrase": [
  null,
  "Скрыть парольную фразу"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Hostname": [
  null,
  "Имя узла"
 ],
 "How would you like to install?": [
  null,
  "Как хотите выполнить установку?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Я понимаю, что все существующие данные будут удалены",
  "Я понимаю, что все существующие данные будут удалены с выбранных дисков",
  "Я понимаю, что все существующие данные будут удалены с выбранных дисков"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Я понимаю, что некоторые существующие данные будут удалены"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Я понимаю, что некоторые разделы будут изменены"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Если пусто, имя узла будет временным и будет задаваться информацией о сети."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Если ни один из указанных выше вариантов не подходит, используйте редактор хранилища для создания пользовательской разметки перед продолжением."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Если Вы настраиваете разделы, необходимо следующее:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Если вы не согласны с автоматической отправкой журналов, вы можете вместо этого использовать $0. Ручная отчетность позволяет вам самостоятельно просматривать и выборочно прикреплять файлы журналов."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Если Вы не понимаете или не принимаете риски, тогда выйдите из этой программы."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Если ваша проблема соответствует одной из указанных выше ошибок, вы можете открыть её и добавить свою информацию туда, вместо создания дублирующего отчёта."
 ],
 "In progress": [
  null,
  "В ходе выполнения"
 ],
 "Initializing...": [
  null,
  "Инициализация..."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Installation completed": [
  null,
  "Установка завершена"
 ],
 "Installation failed": [
  null,
  "Сбой установки"
 ],
 "Installation method": [
  null,
  "Метод установки"
 ],
 "Installation of the system failed": [
  null,
  "Сбой установки системы"
 ],
 "Installation of the system failed: $0": [
  null,
  "Установка системы не удалась: $0"
 ],
 "Installation type": [
  null,
  "Тип установки"
 ],
 "Installing": [
  null,
  "Выполняется установка"
 ],
 "Insufficient disk space": [
  null,
  "Недостаточно места на диске"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Неверный ПИН-код. Пожалуйста, попробуйте снова."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Обнаружена недопустимая конфигурация RAID-массива. Если RAID-массив создается непосредственно на дисках, на нем должна быть создана таблица разделов. Если RAID-массив создается поверх разделов, он должен содержать одну файловую систему или формат (например, LVM PV). Все существующие разделы на этом массиве будут проигнорированы."
 ],
 "Invalid hostname": [
  null,
  "Неверное имя узла"
 ],
 "Jump to first incomplete step": [
  null,
  "Перейти к первому незавершенному шагу"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Сохранить текущую схему диска и использовать свободное пространство для двойной загрузки с другой ОС."
 ],
 "Keyboard": [
  null,
  "Клавиатура"
 ],
 "Keyboard layout during boot": [
  null,
  "Раскладка клавиатуры при запуске"
 ],
 "Language": [
  null,
  "Язык"
 ],
 "Launch storage editor": [
  null,
  "Запустить редактор хранилища"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Подробнее об ограниченном доступе в конфигурации"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Оставьте оба поля пароля пустыми, чтобы использовать пустой пароль."
 ],
 "Location": [
  null,
  "Местоположение"
 ],
 "Locked devices": [
  null,
  "Заблокированные устройства"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Make current": [
  null,
  "Сделать текущим"
 ],
 "Manual disk configuration": [
  null,
  "Настройка диска вручную"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Настройка диска вручную: распределение точек монтирования"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Может содержать буквы, цифры и тире."
 ],
 "May need more free space": [
  null,
  "Может потребоваться больше свободного места"
 ],
 "Medium": [
  null,
  "Носитель"
 ],
 "Minimum of $0 required": [
  null,
  "Требуется минимум $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Несоответствие между выбором форматирования родительского и дочернего устройств."
 ],
 "Mount point": [
  null,
  "Точка монтирования"
 ],
 "Mount point assignment": [
  null,
  "Назначить точки монтирования"
 ],
 "Move down": [
  null,
  "Вниз"
 ],
 "Move up": [
  null,
  "Вверх"
 ],
 "Must be at least $0 characters": [
  null,
  "Должно быть не менее $0 символов"
 ],
 "My issue is different, continue": [
  null,
  "Моя проблема другая, продолжить"
 ],
 "NTP Servers": [
  null,
  "Сервера NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Needs at least $0": [
  null,
  "Требуется как минимум $0"
 ],
 "Network": [
  null,
  "Сеть"
 ],
 "Network Configuration": [
  null,
  "Настройка сети"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Сеть недоступна. Настройте сеть в меню верхней панели, чтобы сообщить о проблеме."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Сеть недоступна. Настройте сеть, чтобы сообщить о проблеме."
 ],
 "Network plugin failed": [
  null,
  "Сбой плагина сети"
 ],
 "Next": [
  null,
  "Далее"
 ],
 "No devices": [
  null,
  "Нет устройств"
 ],
 "No disks available": [
  null,
  "Нет доступных дисков"
 ],
 "No disks selected": [
  null,
  "Ни одного диска не выбрано"
 ],
 "No keyboard layouts selected": [
  null,
  "Не выбрано ни одной раскладки клавиатуры"
 ],
 "No layouts selected yet": [
  null,
  "Раскладки пока не выбраны"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Для выбранной раскладки клавиатуры невозможно получить действительную раскладку клавиатуры VConsole. Выберите другую раскладку."
 ],
 "Not enough available free space": [
  null,
  "Недостаточно свободного места"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Недостаточно свободного места на выбранных дисках."
 ],
 "Not enough space on selected disks.": [
  null,
  "Недостаточно места на выбранных дисках."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Примечание: это предварительно выпущенное программное обеспечение, предназначенное только для целей разработки и тестирования. НЕ используйте это программное обеспечение для какой-либо важной работы или в условиях производства."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Открыть форму регистрации ошибок Bugzilla"
 ],
 "Operating system": [
  null,
  "Операционная система"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other keyboards": [
  null,
  "Другие клавиатуры"
 ],
 "Partitions (advanced)": [
  null,
  "Разделы (расширенный)"
 ],
 "Passphrase": [
  null,
  "Парольная фраза"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Парольная фраза не совпала ни с одним заблокированным устройством"
 ],
 "Passphrases must match": [
  null,
  "Парольные фразы должны совпадать"
 ],
 "Pending": [
  null,
  "Ожидание"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Прикрепите файл журнала $0 к сообщению о проблеме."
 ],
 "Please enter a PIN": [
  null,
  "Пожалуйста, введите ПИН-код"
 ],
 "Please select at least one disk to continue": [
  null,
  "Для продолжения выберите хотя бы один диск"
 ],
 "Pool": [
  null,
  "Пул"
 ],
 "Potential duplicate bugs found": [
  null,
  "Найдены возможные дублирующиеся ошибки"
 ],
 "Powered by Anaconda": [
  null,
  "На основе Anaconda"
 ],
 "Pre-release": [
  null,
  "Предварительный выпуск"
 ],
 "Prefer to report manually? $0": [
  null,
  "Предпочитаете ручные отчёты? $0"
 ],
 "Proceed with installation": [
  null,
  "Приступить к установке"
 ],
 "Quit": [
  null,
  "Выход"
 ],
 "Quit installer?": [
  null,
  "Выйти из программы установки?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Не удалось прочитать информацию об ОС."
 ],
 "Reading information about the computer failed.": [
  null,
  "Не удалось прочитать информацию о компьютере."
 ],
 "Reading installer configuration failed.": [
  null,
  "Не удалось прочитать конфигурацию программы установки."
 ],
 "Reading installer version information failed.": [
  null,
  "Не удалось прочитать информацию о версии программы установки."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Настоящее имя узла может содержать только символы, цифры, тире (не начинающие и не заканчивающие символ) и точки"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Настоящее имя узла должно состоять из 64 символов или меньше"
 ],
 "Reboot": [
  null,
  "Перезагрузить"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Перезагрузитесь в Windows, чтобы изменить размер разделов, зашифрованных BitLocker. Для установки освободите не менее $0 свободного пространства."
 ],
 "Reboot system?": [
  null,
  "Перезагрузить систему?"
 ],
 "Reclaim additional space": [
  null,
  "Освободите дополнительное пространство"
 ],
 "Reclaim space": [
  null,
  "Освободить"
 ],
 "Reclaim space (required)": [
  null,
  "Освободить пространство (требуется)"
 ],
 "Recommended": [
  null,
  "Рекомендуется"
 ],
 "Recommended partitions:": [
  null,
  "Рекомендуемые разделы:"
 ],
 "Reformat": [
  null,
  "Переформатирование"
 ],
 "Reinstall Fedora": [
  null,
  "Переустановить Fedora"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Удалить все разделы на выбранных устройствах, включая существующие операционные системы."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Удалите или измените размер существующих файловых систем, чтобы освободить место для установки."
 ],
 "Remove server": [
  null,
  "Удалить сервер"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Удаление файловой системы приведет к безвозвратному удалению всех содержащихся в ней данных. Изменение размера раздела может освободить неиспользуемое пространство, но это небезопасно. Перед тем как освобождать место, обязательно создайте резервные копии всех важных данных."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Заменить текущую установку, сохранив файлы папки Home."
 ],
 "Report Issue": [
  null,
  "Сообщить о проблеме"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Сообщите о проблеме или оставьте отзыв, открыв форму для регистрации ошибок Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Сообщить о проблеме"
 ],
 "Reporting issue...": [
  null,
  "Отправка сообщения о проблеме..."
 ],
 "Required": [
  null,
  "Необходимо"
 ],
 "Requirements": [
  null,
  "Требования"
 ],
 "Rescan devices": [
  null,
  "Повторно сканировать устройства"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Повторное сканирование дисков не удалось."
 ],
 "Resize": [
  null,
  "Изменить размер"
 ],
 "Resize partition": [
  null,
  "Изм. размер раздела"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Изменение размера следующих разделов с $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Ограничить доступ к отчету"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Ограничивает отчет группой $0. $1"
 ],
 "Return to installation": [
  null,
  "Вернуться к установке"
 ],
 "Return to storage editor": [
  null,
  "Возврат к редактору хранилища"
 ],
 "Review and install": [
  null,
  "Обзор и установка"
 ],
 "Root account has been configured": [
  null,
  "Учётная запись root настроена"
 ],
 "Root account is enabled": [
  null,
  "Учётная запись Root включена"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Уч. запись Root включена, но уч. запись пользователя не настроена"
 ],
 "Root password has been set.": [
  null,
  "Пароль root задан."
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Отсканируйте QR-код с телефона или посетите сайт:"
 ],
 "Search for a language": [
  null,
  "Поиск языка"
 ],
 "Search for additional software": [
  null,
  "Поиск дополнительного ПО"
 ],
 "Search for an environment": [
  null,
  "Поиск окружения"
 ],
 "Search keyboard layout": [
  null,
  "Искать раскладку клавиатуры"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Защитите свои данные с помощью шифрования на основе диска. Применяется только к новым разделам"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "Select a device": [
  null,
  "Выбрать устройство"
 ],
 "Select city": [
  null,
  "Выбрать город"
 ],
 "Select destination": [
  null,
  "Выберете назначение"
 ],
 "Select region": [
  null,
  "Выбрать регион"
 ],
 "Selected (top = current)": [
  null,
  "Выбранные (верхняя = текущая)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Формат выбранного устройства '$0' не может быть переформатирован."
 ],
 "Send us feedback on your installation": [
  null,
  "Отправьте нам отзыв о Вашем опыте с установкой"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server is not reachable": [
  null,
  "Сервер недоступен"
 ],
 "Set custom hostname": [
  null,
  "Установить пользовательское имя узла"
 ],
 "Share disk with other operating systems": [
  null,
  "Исп. диск совместно с другими операционными системами"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Исп. диск совместно с другими операционными системами: $0"
 ],
 "Show AM/PM": [
  null,
  "12/24-часовой формат"
 ],
 "Show API key": [
  null,
  "Показать API-ключ"
 ],
 "Show PIN": [
  null,
  "Показать ПИН-код"
 ],
 "Show confirmed password": [
  null,
  "Показать подтвержденный пароль"
 ],
 "Show passphrase": [
  null,
  "Показать парольную фразу"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Software installation": [
  null,
  "Установка программного обеспечения"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Установка программного обеспечения: настройка хранилища данных завершена. Теперь программное обеспечение устанавливается на ваше устройство."
 ],
 "Software selection": [
  null,
  "Выбор программ"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Перед продолжением необходимо выполнить еще несколько шагов установки."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Некоторые необходимые разделы отсутствуют: $0"
 ],
 "Space": [
  null,
  "Пространство"
 ],
 "Stacktrace": [
  null,
  "Трассировка стека"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Storage configuration": [
  null,
  "Конфигурация устройств хранения"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Конфигурация хранилища: в настоящее время хранилище настраивается."
 ],
 "Storage editor": [
  null,
  "Редактор хранилища"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Хранилище основано на конфигурации из раздела \"Изменить хранилище\"."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Схема разбиения диска определяется файлом Kickstart. Запланированную схему разбиения диска можно просмотреть на этапе обзора итогов."
 ],
 "Storage plugin failed": [
  null,
  "Сбой плагина хранилища"
 ],
 "Storage requirements not met": [
  null,
  "Не соблюдены требования к хранилищу"
 ],
 "Strong": [
  null,
  "Сложный"
 ],
 "Successfully installed": [
  null,
  "Установка завершена успешно"
 ],
 "Successfully unlocked $0.": [
  null,
  "Успешно разблокировано $0."
 ],
 "Suggested keyboards": [
  null,
  "Предлагаемые клавиатуры"
 ],
 "Suggested languages": [
  null,
  "Предлагаемые языки"
 ],
 "System": [
  null,
  "Система"
 ],
 "System configuration": [
  null,
  "Конфигурация системы"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Конфигурация системы: установка программного обеспечения завершена. Сейчас система настраивается."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Работа программы установки Anaconda была неожиданно прервана."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Следующие открытые ошибки могут быть связаны с вашей проблемой. Пожалуйста, просмотрите их перед созданием нового отчёта."
 ],
 "The following user will be created:": [
  null,
  "Будет создан следующий пользователь:",
  "Будут созданы следующие пользователи:",
  "Будут созданы следующие пользователи:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Для установки требуется $0 дискового пространства, однако емкость выбранных дисков составляет лишь $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Установка не может быть продолжена из-за критической ошибки."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Установка не может быть продолжена из-за критической ошибки: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Раскладка клавиатуры изменилась с момента установки парольной фразы для шифрования диска. Пожалуйста, введите парольную фразу заново."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Парольная фраза содержит символы, не входящие в набор ASCII. Функции переключения раскладки клавиатуры могут быть недоступны при её вводе."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Выбранная по умолчанию раскладка клавиатуры не поддерживает ASCII-символы. Выберите раскладку по умолчанию с поддержкой ASCII."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Редактор хранилища позволяет изменять размеры, удалять и создавать разделы. В нем можно настроить LVM и многое другое. Он предназначен для использования в качестве расширенной утилиты и не предназначен для использования в обычной установке."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Эти файлы журналов могут содержать конфиденциальную информацию, такую как IP-адреса, имена пользователей или другие системные данные."
 ],
 "This hostname can't be submitted": [
  null,
  "Это имя узла не может быть представлено"
 ],
 "This is unstable, pre-release software": [
  null,
  "Стабильность предварительной версии дистрибутива не гарантируется"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Эта раскладка будет использоваться для разблокировки системы при запуске"
 ],
 "This may take a moment": [
  null,
  "Это может занять некоторое время"
 ],
 "This will take a few moments": [
  null,
  "Это займёт некоторое время"
 ],
 "Time": [
  null,
  "Время"
 ],
 "Timezone": [
  null,
  "Часовой пояс"
 ],
 "Title": [
  null,
  "Заголовок"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Чтобы начать использовать $0, перезагрузите систему."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Чтобы продолжить, выберите устройства для установки."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Чтобы воспользоваться этой опцией, измените размер или удалите существующие разделы, чтобы освободить хотя бы $0."
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Невозможно запланировать удаление $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Невозможно запланировать изменение размера $0"
 ],
 "Undo last action": [
  null,
  "Отменить последнее действие"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Unlock encrypted devices": [
  null,
  "Разблокировать зашифрованые устройства"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Разблокируйте зашифрованные разделы, чтобы сохранить существующие данные и отобразить больше способов установки."
 ],
 "Use configured storage": [
  null,
  "Использовать настроенное хранилище"
 ],
 "Use entire disk": [
  null,
  "Использовать весь диск"
 ],
 "Use free space": [
  null,
  "Исп. свободное пространство"
 ],
 "Use local account": [
  null,
  "Исп. локальную учётную запись"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Исп. устройство RAID для автоматического разбиения на разделы"
 ],
 "User creation": [
  null,
  "Создание пользователя"
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Имя пользователя может содержать только: буквы от a-z, цифры 0-9, тире $0, точку $1, знак подчеркивания $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Имя пользователя не должно быть зарезервированным словом"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Имена пользователей должны быть короче 33 символов"
 ],
 "Validating...": [
  null,
  "Проверка..."
 ],
 "Weak": [
  null,
  "Простой"
 ],
 "Welcome": [
  null,
  "Приветствие"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Добро пожаловать в Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Добро пожаловать. Давайте установим $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "При отправке этого отчета об ошибке будут автоматически загружены следующие файлы журнала: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Разделы Windows с шифрованием BitLocker не могут быть изменены в размере"
 ],
 "You can close this browser window now.": [
  null,
  "Теперь вы можете закрыть это окно браузера."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Вы можете либо освободить достаточно места и позволить программе установки справиться с остальным, либо вручную настроить разделы."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Вы можете сгенерировать ключ API для своей учётной записи Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Для продолжения вам необходимо включить учётную запись root или создать локальную учётную запись пользователя."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Чтобы включить функцию автоматического определения даты и времени, необходимо подключиться к сети."
 ],
 "Your progress will not be saved.": [
  null,
  "Ваш прогресс не будет сохранен."
 ],
 "completed step": [
  null,
  "завершённый шаг"
 ],
 "current step": [
  null,
  "текущий шаг"
 ],
 "delete": [
  null,
  "удалить"
 ],
 "edit": [
  null,
  "изменить"
 ],
 "encrypt": [
  null,
  "зашифровать"
 ],
 "encrypted": [
  null,
  "зашифровано"
 ],
 "extended partition": [
  null,
  "расширенный раздел"
 ],
 "format as $0": [
  null,
  "форматировать как $0"
 ],
 "here": [
  null,
  "здесь"
 ],
 "incomplete": [
  null,
  "неполный"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "pending step": [
  null,
  "предстоящий шаг"
 ],
 "report the issue manually": [
  null,
  "ручной отчёт о проблеме"
 ],
 "resized from $0": [
  null,
  "изменен размер с $0"
 ],
 "shrink": [
  null,
  "уменьшить"
 ],
 "shrink to $0": [
  null,
  "уменьшить до $0"
 ],
 "transient, will use DHCP": [
  null,
  "временный, будет использовать DHCP"
 ],
 "undo": [
  null,
  "отменить"
 ]
});
