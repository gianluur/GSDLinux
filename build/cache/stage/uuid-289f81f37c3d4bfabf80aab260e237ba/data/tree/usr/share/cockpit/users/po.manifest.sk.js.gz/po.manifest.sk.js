cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "user": [
  null,
  "používateľ"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "heslo"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "username"
 ],
 "login": [
  null,
  "prihlásenie"
 ],
 "access": [
  null,
  "prístup"
 ],
 "roles": [
  null,
  "role"
 ],
 "keys": [
  null,
  "kľúče"
 ],
 "Managing user accounts": [
  null,
  "Správa používateľských účtov"
 ]
});
