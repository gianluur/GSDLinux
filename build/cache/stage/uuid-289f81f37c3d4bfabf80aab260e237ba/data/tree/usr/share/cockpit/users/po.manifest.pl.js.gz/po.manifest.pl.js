cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Accounts": [
  null,
  "Konta"
 ],
 "user": [
  null,
  "użytkownik"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "hasło"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nazwa użytkownika"
 ],
 "login": [
  null,
  "logowanie"
 ],
 "access": [
  null,
  "dostęp"
 ],
 "roles": [
  null,
  "role"
 ],
 "keys": [
  null,
  "klucze"
 ],
 "Managing user accounts": [
  null,
  "Zarządzanie kontami użytkowników"
 ]
});
