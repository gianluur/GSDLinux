cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "mount": [
  null,
  "montar"
 ],
 "format": [
  null,
  "formatar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ],
 "partition": [
  null,
  "partição"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volume"
 ],
 "disk": [
  null,
  "disco"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "unidade"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "criptografia"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Gestão de partições"
 ],
 "Managing NFS mounts": [
  null,
  "Gerenciando montagens NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gerenciando RAIDs"
 ],
 "Managing LVMs": [
  null,
  "Gerenciando LVMs"
 ],
 "Managing physical drives": [
  null,
  "Gerenciando discos físicos"
 ],
 "Managing VDOs": [
  null,
  "Gerenciando VDOs"
 ],
 "Using LUKS encryption": [
  null,
  "Usando criptografia LUKS"
 ],
 "Using Tang server": [
  null,
  "Usando servidor Tang"
 ]
});
