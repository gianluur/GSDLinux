cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "網路"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Accounts": [
  null,
  "帳號管理"
 ],
 "user": [
  null,
  "使用者"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "密碼"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "使用者名稱"
 ],
 "login": [
  null,
  "登入"
 ],
 "access": [
  null,
  "存取"
 ],
 "roles": [
  null,
  "角色"
 ],
 "keys": [
  null,
  "金鑰"
 ],
 "Managing user accounts": [
  null,
  "管理使用者帳號"
 ]
});
