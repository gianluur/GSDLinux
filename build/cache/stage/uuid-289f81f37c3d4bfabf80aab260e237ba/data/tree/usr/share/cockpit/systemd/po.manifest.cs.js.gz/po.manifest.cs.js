cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Služby"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "time": [
  null,
  "čas"
 ],
 "date": [
  null,
  "datum"
 ],
 "restart": [
  null,
  "restartovat"
 ],
 "shut": [
  null,
  "vyp"
 ],
 "domain": [
  null,
  "doména"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "operating system": [
  null,
  "operační systém"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "inventární štítek"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "napájení"
 ],
 "version": [
  null,
  "verze"
 ],
 "host": [
  null,
  "stroj"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "omezení vlivu"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "paměť"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "operační paměť"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "history": [
  null,
  "historie"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "disky"
 ],
 "network": [
  null,
  "síť"
 ],
 "cgroups": [
  null,
  "řídící skupiny"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "Configuring system settings": [
  null,
  "Nastavování systému"
 ],
 "service": [
  null,
  "služba"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cíl"
 ],
 "socket": [
  null,
  "soket"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "path": [
  null,
  "popis umístění"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "boot"
 ],
 "mask": [
  null,
  "maska"
 ],
 "unmask": [
  null,
  "zrušit maskování"
 ],
 "enable": [
  null,
  "zapnout"
 ],
 "disable": [
  null,
  "vypnout"
 ],
 "Managing services": [
  null,
  "Správa služeb"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "warning": [
  null,
  "varování"
 ],
 "error": [
  null,
  "chyba"
 ],
 "debug": [
  null,
  "ladění"
 ],
 "crash": [
  null,
  "pád"
 ],
 "coredump": [
  null,
  "výpis paměti"
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocování záznamu událostí"
 ],
 "console": [
  null,
  "konzole"
 ],
 "command": [
  null,
  "příkaz"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
