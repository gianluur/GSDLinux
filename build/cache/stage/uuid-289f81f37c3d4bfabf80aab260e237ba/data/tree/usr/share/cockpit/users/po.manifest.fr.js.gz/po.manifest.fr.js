cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Accounts": [
  null,
  "Comptes"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "mot de passe"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nom d’utilisateur"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "accès"
 ],
 "roles": [
  null,
  "rôles"
 ],
 "keys": [
  null,
  "clés"
 ],
 "Managing user accounts": [
  null,
  "Gestion des comptes utilisateurs"
 ]
});
