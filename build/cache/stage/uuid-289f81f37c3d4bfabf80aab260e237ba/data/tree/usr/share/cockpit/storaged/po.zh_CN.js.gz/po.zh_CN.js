cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "密钥发生变化通常是因为重新安装了操作系统。但是，意外的变更也可能意味着有第三方正试图拦截您的连接。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要确保您的连接没有被恶意第三方截取，请验证主机密钥指纹："
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "结果指纹可以通过公共方法（包括电子邮件）共享。"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Server": [
  null,
  "服务器"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copied": [
  null,
  "复制的"
 ],
 "Unlock": [
  null,
  "解锁"
 ],
 "Add key": [
  null,
  "添加密钥"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Select": [
  null,
  "选择"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安装"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "主机 $0 上找不到版本兼容的 Cockpit。"
 ],
 "Set": [
  null,
  "设置"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Port": [
  null,
  "端口"
 ],
 "$0 key changed": [
  null,
  "已更改 $0 个密钥"
 ],
 "Trust and add host": [
  null,
  "信任并添加主机"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要验证指纹，在 $0 上运行以下内容（在实际的物理机器上本地进行，或通过一个可信任的网络进行）："
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指纹匹配，请点击“信任并添加主机”。否则，请不要连接并联系您的管理员。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成的指纹可以通过公共方法（包括电子邮件）共享。如果您需要其他人为您进行验证，他们可以使用任何方法发送结果。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次连接到 $0。"
 ],
 "Verify fingerprint": [
  null,
  "验证指纹"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "通过一个可信网络运行这个命令，或在远程机器上运行这个命令："
 ],
 "The fingerprint should match:": [
  null,
  "指纹应匹配："
 ],
 "The password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key passwords do not match": [
  null,
  "密钥密码不匹配"
 ],
 "Log in to $0": [
  null,
  "登录到 $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "无法登录到 $0 。主机不接受密码登录，或您的任何 SSH 密钥。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受密码保护的，主机不允许使用密码登录。请在 $1 提供密钥的密码。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受保护的。您可以用您的登录密码或通过在 $1 提供密钥的密码来登录。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "创建一个新的 SSH 密钥，并对其进行授权"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "将在 $2 上为 $1 创建位于 $0 的新 SSH 密钥，并将其添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Key password": [
  null,
  "密钥密码"
 ],
 "Confirm key password": [
  null,
  "确认密钥密码"
 ],
 "Authorize SSH key": [
  null,
  "授权 SSH 密钥"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 密钥 $0 将被添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Authentication": [
  null,
  "认证"
 ],
 "SSH key": [
  null,
  "SSH 密钥"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 密钥 $0 将会在剩余的会话中可用，也可以在登录到其他主机时可用。"
 ],
 "Permission denied": [
  null,
  "权限被拒绝"
 ],
 "Clear input value": [
  null,
  "清除输入值"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "Create $0": [
  null,
  "创建 $0"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "You now have administrative access.": [
  null,
  "您已经获取了管理员权限。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "没有可用于获取管理权限的方法 (sudo -A, pkexec)。"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "请进行身份验证以获取管理员权限"
 ],
 "Switch to administrative access": [
  null,
  "切换到管理员权限"
 ],
 "Authenticate": [
  null,
  "认证"
 ],
 "Administrative access": [
  null,
  "管理员权限"
 ],
 "Problem becoming administrator": [
  null,
  "成为管理员时出现问题"
 ],
 "Method": [
  null,
  "模式"
 ],
 "Limit access": [
  null,
  "限制访问"
 ],
 "Switch to limited access": [
  null,
  "切换到限制权限"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限制访问模式会限制管理员权限。Web 控制台部分功能将会减少。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的浏览器将会在不同会话之间记住您的访问级别。"
 ],
 "Limited access": [
  null,
  "被限制的访问"
 ],
 "Turn on administrative access": [
  null,
  "开启管理员权限"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "less than a minute ago": [
  null,
  "少于一分钟前"
 ],
 "in less than a minute": [
  null,
  "少于一分钟"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Excellent password": [
  null,
  "密码强度优秀"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Unknown host: $0": [
  null,
  "未知主机：$0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "无法使用 SSH 密钥身份验证登录到 $0。请提供密码。"
 ],
 "SSH key login": [
  null,
  "SSH 密钥登录"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit 已报告错误码 $0"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "Row expansion": [
  null,
  "行扩展"
 ],
 "Row select": [
  null,
  "行选择"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Error during initialization": [
  null,
  "初始化时出错"
 ],
 "Failed": [
  null,
  "失败"
 ],
 "Home": [
  null,
  ""
 ],
 "Not a directory": [
  null,
  "不是目录"
 ],
 "Type to filter": [
  null,
  "输入内容来过滤"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "文件系统"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "Folder": [
  null,
  "文件夹"
 ],
 "File": [
  null,
  "文件"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "当前登录的用户无权查看系统更改"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Select an option": [
  null,
  "选择一个选项"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 exited with code $1": [
  null,
  "$0 退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "$0 失败"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Server has closed the connection.": [
  null,
  "服务器已关闭了连接。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Save": [
  null,
  "保存"
 ],
 "View logs": [
  null,
  "查看日志"
 ],
 "Dismiss": [
  null,
  "清除"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Usage": [
  null,
  "占用率"
 ],
 "none": [
  null,
  "空"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Running": [
  null,
  "正在运行"
 ],
 "Not running": [
  null,
  "未运行"
 ],
 "Loading...": [
  null,
  "加载中……"
 ],
 "User": [
  null,
  "用户"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "大小"
 ],
 "State": [
  null,
  "状态"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Confirm deletion of $0": [
  null,
  "确认删除 $0"
 ],
 "Username": [
  null,
  "用户名"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Rename": [
  null,
  "重命名"
 ],
 "Started": [
  null,
  "启动"
 ],
 "Delete group": [
  null,
  "删除用户组"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Lock": [
  null,
  "锁定"
 ],
 "Use $0": [
  null,
  "使用 $0"
 ],
 "Service": [
  null,
  "服务"
 ],
 "Disconnect": [
  null,
  "断开"
 ],
 "Address": [
  null,
  "地址"
 ],
 "$0 disk is missing": [
  null,
  "找不到 $0 个磁盘"
 ],
 "Location": [
  null,
  "位置"
 ],
 "Compression": [
  null,
  "压缩"
 ],
 "Storage logs": [
  null,
  "存储日志"
 ],
 "Name cannot be empty.": [
  null,
  "名称不能为空。"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名称不能长于127个字符。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名称不能包含字符 '$0'。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名称不能包含空格。"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名称不能长于 $0 个字符"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名称不能长于 $0 字节"
 ],
 "$name (from $host)": [
  null,
  "$name（位于 $host）"
 ],
 "Pool for thin logical volumes": [
  null,
  "瘦逻辑卷池"
 ],
 "Thin logical volume": [
  null,
  "精简逻辑卷"
 ],
 "Logical volume (snapshot)": [
  null,
  "逻辑卷 (快照)"
 ],
 "Logical volume": [
  null,
  "逻辑卷"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID 设备 $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 卷组 $0"
 ],
 "VDO device $0": [
  null,
  "VDO 设备 $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 的已加密逻辑卷"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 的已加密分区"
 ],
 "Logical volume of $0": [
  null,
  "$0 的逻辑卷"
 ],
 "Partition of $0": [
  null,
  "$0 的分区"
 ],
 "Encrypted $0": [
  null,
  "已加密 $0"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 上未分区的空间"
 ],
 "unmount": [
  null,
  "卸载"
 ],
 "mount": [
  null,
  "挂载"
 ],
 "remove from btrfs volume": [
  null,
  "从 btrfs 卷中删除"
 ],
 "stop": [
  null,
  "停止"
 ],
 "remove from MDRAID": [
  null,
  "从 MDRAID 中删除"
 ],
 "remove from LVM2": [
  null,
  "从 LVM2 中删除"
 ],
 "btrfs device": [
  null,
  "btrfs 设备"
 ],
 "btrfs volume": [
  null,
  "btrfs 卷"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "名称不能超过 255 个字符。"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "名称不能包含字符 '/'。"
 ],
 "Create and mount": [
  null,
  "创建并挂载"
 ],
 "Create only": [
  null,
  "仅创建"
 ],
 "Create subvolume": [
  null,
  "创建子卷"
 ],
 "Mount Point": [
  null,
  "挂载点"
 ],
 "delete": [
  null,
  "删除"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "永久删除子卷 $0？"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "删除会擦除这个子卷上的所有数据，包括它的所有嵌套子卷。"
 ],
 "Edit mount point": [
  null,
  "编辑挂载点"
 ],
 "Unmount": [
  null,
  "卸载"
 ],
 "Mount": [
  null,
  "挂载"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "至少需要挂载一个子卷"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "最后一次挂载的子卷无法被删除"
 ],
 "btrfs subvolume": [
  null,
  "btrfs 子卷"
 ],
 "Snapshot origin": [
  null,
  "快照源"
 ],
 "Mount point": [
  null,
  "挂载点"
 ],
 "No subvolumes": [
  null,
  "没有子卷"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs 子卷"
 ],
 "Snapshots": [
  null,
  "快照"
 ],
 "No snapshots found": [
  null,
  "找不到快照"
 ],
 "snapshot": [
  null,
  "快照"
 ],
 "$0 is in use": [
  null,
  "$0 正在使用"
 ],
 "Permanently delete $0?": [
  null,
  "永久删除 $0？"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "删除将清除 btrfs 卷上的所有数据。"
 ],
 "Delete filesystem": [
  null,
  "删除文件系统"
 ],
 "Change label": [
  null,
  "更改标签"
 ],
 "Filesystem is mounted read-only": [
  null,
  "文件系统被挂载为只读"
 ],
 "Label": [
  null,
  "标签"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "btrfs devices": [
  null,
  "btrfs 设备"
 ],
 "No devices found": [
  null,
  "没有找到设备"
 ],
 "btrfs filesystem": [
  null,
  "btrfs 文件系统"
 ],
 "Successful": [
  null,
  "成功"
 ],
 "Aborted": [
  null,
  "已中止"
 ],
 "In progress": [
  null,
  "进行中"
 ],
 "Interrupted": [
  null,
  "中断"
 ],
 "Did not complete": [
  null,
  "沒有完成"
 ],
 "Failed (Unknown)": [
  null,
  "失败 (未知)"
 ],
 "Failed (Electrical)": [
  null,
  "失败 (电气)"
 ],
 "Failed (Servo)": [
  null,
  "失败 (伺服)"
 ],
 "Failed (Read)": [
  null,
  "失败 (读取)"
 ],
 "Failed (Damaged)": [
  null,
  "失败 (损坏)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "通过控制器级重置中止"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "由于从命名空间清单中删除命名空间而中止"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "由于处理格式化 NVM 命令而中止"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "自检操作期间发生致命错误"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "已完成，但有一个段失败，并且失败的段未知"
 ],
 "Completed with one or more failed segments": [
  null,
  "已完成，但有一个或多个段失败"
 ],
 "Aborted for unknown reason": [
  null,
  "因未知原因中止"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "由于清理操作而中止"
 ],
 "Spare capacity is below the threshold": [
  null,
  "剩余产能低于阈值"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "温度超出建议的临界值"
 ],
 "Degraded": [
  null,
  "已降级"
 ],
 "All media is in read-only mode": [
  null,
  "所有媒体均处于只读模式"
 ],
 "Volatile memory backup failed": [
  null,
  "易失性内存备份失败"
 ],
 "Persistent memory has become read-only": [
  null,
  "持久性内存已变为只读"
 ],
 "Run short test": [
  null,
  "运行短测试"
 ],
 "Run extended test": [
  null,
  "运行扩展测试"
 ],
 "Abort test": [
  null,
  "中止测试"
 ],
 "Disk is failing": [
  null,
  "磁盘失败"
 ],
 "Disk is OK": [
  null,
  "磁盘良好"
 ],
 "Assessment": [
  null,
  "评估报告"
 ],
 "Power on hours": [
  null,
  "通电时间"
 ],
 "$0 hours": [
  null,
  "$0 小时"
 ],
 "Self-test status": [
  null,
  "自检状态"
 ],
 "Number of bad sectors": [
  null,
  "坏扇区数量"
 ],
 "Attributes failing": [
  null,
  "属性失败"
 ],
 "Media drive": [
  null,
  "介质驱动器"
 ],
 "Solid State Drive": [
  null,
  "固态驱动器"
 ],
 "Hard Disk Drive": [
  null,
  "硬盘设备"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI 驱动器"
 ],
 "Drive": [
  null,
  "驱动"
 ],
 "Device health (SMART)": [
  null,
  "设备健康（SMART）"
 ],
 "Firmware version": [
  null,
  "固件版本"
 ],
 "Serial number": [
  null,
  "序列号"
 ],
 "World wide name": [
  null,
  "全局范围名称"
 ],
 "No media inserted": [
  null,
  "没有插入介质"
 ],
 "Device file": [
  null,
  "设备文件"
 ],
 "Multipathed devices": [
  null,
  "多路径设备"
 ],
 "Free space": [
  null,
  "空闲空间"
 ],
 "Create partition": [
  null,
  "创建分区"
 ],
 "Extended partition": [
  null,
  "扩展分区"
 ],
 "$0 partitions": [
  null,
  "$0 分区"
 ],
 "Partitions": [
  null,
  "分区"
 ],
 "No partitions found": [
  null,
  "没有找到分区"
 ],
 "Unexpected partitions": [
  null,
  "非预期的分区"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "此块设备不支持分区。若其被用作虚拟机磁盘，分区必须由虚拟机内部的操作系统管理。"
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "删除分区将删除其中的所有数据。"
 ],
 "No free space after this partition": [
  null,
  "这个分区后没有可用空间"
 ],
 "EFI system partition": [
  null,
  "EFI 系统分区"
 ],
 "BIOS boot partition": [
  null,
  "BIOS 引导分区"
 ],
 "Partition": [
  null,
  "分区"
 ],
 "Shrink": [
  null,
  "缩小"
 ],
 "Grow": [
  null,
  "扩展"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP 引导分区"
 ],
 "Linux swap space": [
  null,
  "Linux 交换空间"
 ],
 "Linux filesystem data": [
  null,
  "Linux 文件系统数据"
 ],
 "Logical Volume Manager partition": [
  null,
  "逻辑卷管理器分区"
 ],
 "Custom": [
  null,
  "自定义"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "类型必须正好包含两个十六进制字符 (0 到 9，A 到 F)。"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "类型只能包含字符 0 到 9，A 到 F，和 \"-\"。"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "类型的格式为 NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN。"
 ],
 "Set partition type of $0": [
  null,
  "设置分区类型 $0"
 ],
 "Custom type": [
  null,
  "自定义类型"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "更改分区类型可能会阻止系统引导。"
 ],
 "This partition is not completely used by its content.": [
  null,
  "此分区不会被其内容完全使用。"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "分区大小是 $0。内容大小为 $1。"
 ],
 "Shrink partition": [
  null,
  "缩小分区"
 ],
 "Grow content": [
  null,
  "扩展内容"
 ],
 "initialize": [
  null,
  "初始化"
 ],
 "Initialize disk $0": [
  null,
  "初始化磁盘 $0"
 ],
 "Partitioning": [
  null,
  "分区"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "兼容所有系统和设备 (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "兼容现代系统，且硬盘空间大于 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "无分区"
 ],
 "Overwrite": [
  null,
  "覆盖"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "用 0 覆盖现有数据（较慢）"
 ],
 "Initialize": [
  null,
  "初始化"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初始化会擦除磁盘上的所有数据。"
 ],
 "Device is read-only": [
  null,
  "设备只读"
 ],
 "Create partition table": [
  null,
  "创建分区表"
 ],
 "Size must be a number": [
  null,
  "大小必须是数字"
 ],
 "Size cannot be zero": [
  null,
  "大小不能为零"
 ],
 "Size cannot be negative": [
  null,
  "大小不能为负数"
 ],
 "Size is too large": [
  null,
  "大小太大"
 ],
 "Size must be at least $0": [
  null,
  "大小必须最小为 $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 卷组的物理卷"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID 设备的成员"
 ],
 "backing device for VDO device": [
  null,
  "VDO 设备的备份设备"
 ],
 "member of Stratis pool": [
  null,
  "Stratis 池的成员"
 ],
 "Filesystem outside the target": [
  null,
  "目标之外的文件系统"
 ],
 "device of btrfs volume": [
  null,
  "btrfs 卷的设备"
 ],
 "This device is currently in use.": [
  null,
  "该设备正在被使用。"
 ],
 "Device": [
  null,
  "设备"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Services using the location": [
  null,
  "使用位置的服务"
 ],
 "Processes using the location": [
  null,
  "使用位置的进程"
 ],
 "Currently in use": [
  null,
  "当前在用"
 ],
 "(Not part of target)": [
  null,
  "（不是目标的一部分）"
 ],
 "These changes will be made:": [
  null,
  "将做出这些更改："
 ],
 "Action": [
  null,
  "操作"
 ],
 "Important data might be deleted:": [
  null,
  "重要数据可能会被删除："
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "相关进程和服务将被强制停止。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "相关进程将被强制停止。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "相关服务将被强制停止。"
 ],
 "Checking filesystem usage": [
  null,
  "检查文件系统的使用情况"
 ],
 "$0 used, $1 total": [
  null,
  "已使用 $0 ，共 $1"
 ],
 "Device contains unrecognized data": [
  null,
  "设备包含无法被识别的数据"
 ],
 "Locked encrypted device might contain data": [
  null,
  "已锁定的加密设备可能含有数据"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "我确认我希望永久删除这些数据"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "挂载点 $0 正在被这些进程使用："
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "命令"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "挂载点 $0 正在被这些服务使用："
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "列出的进程和服务将被强制停止。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "列出的进程将被强制停止。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "列出的服务将被强制停止。"
 ],
 "Sorry": [
  null,
  "抱歉"
 ],
 "Usage of $0": [
  null,
  "$0 的用法"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO 池"
 ],
 "Data used": [
  null,
  "使用的数据"
 ],
 "Metadata used": [
  null,
  "已使用的元数据"
 ],
 "Use compression": [
  null,
  "使用压缩"
 ],
 "Deduplication": [
  null,
  "去重"
 ],
 "Use deduplication": [
  null,
  "使用 deduplication"
 ],
 "Rename volume group": [
  null,
  "重命名卷组"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "此卷组包含根文件系统。将其重命名可能需要进一步更改引导加载程序配置或内核命令行。"
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "删除会擦除卷组上的所有数据."
 ],
 "Create snapshot": [
  null,
  "创建快照"
 ],
 "Add disks": [
  null,
  "添加磁盘"
 ],
 "Disks": [
  null,
  "磁盘"
 ],
 "No disks are available.": [
  null,
  "没有可用的磁盘。"
 ],
 "At least one disk is needed.": [
  null,
  "至少需要 1 块磁盘。"
 ],
 "Volume group is missing physical volumes": [
  null,
  "卷组缺少物理卷"
 ],
 "No free space": [
  null,
  "没有剩余空间"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 卷组"
 ],
 "Add physical volume": [
  null,
  "添加物理卷"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 逻辑卷"
 ],
 "Create new logical volume": [
  null,
  "创建新逻辑卷"
 ],
 "No logical volumes": [
  null,
  "没有逻辑卷"
 ],
 "Remove missing physical volumes?": [
  null,
  "删除缺少的物理卷？"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "这个卷组缺少一些物理卷。"
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "无法重命名物理卷丢失的卷组。"
 ],
 "Physical volumes": [
  null,
  "物理卷"
 ],
 "No physical volumes found": [
  null,
  "没有找到物理卷"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 物理卷"
 ],
 "Rename logical volume": [
  null,
  "重命名逻辑卷"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "永久删除逻辑卷 $0/$1？"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "删除逻辑卷将擦除其中的所有数据。"
 ],
 "Unable to repair logical volume $0": [
  null,
  "无法修复逻辑卷 $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "无法进行修复所需的足够的可用空间。在物理卷上至少需要有还没有被这个逻辑卷使用的 $0 可用空间。"
 ],
 "An additional $0 must be selected": [
  null,
  "必须额外选择 $0"
 ],
 "Repair logical volume $0": [
  null,
  "修复逻辑卷 $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "选择应该用来修复逻辑卷的物理卷。最少需要 $0。"
 ],
 "Physical Volumes": [
  null,
  "物理卷"
 ],
 "Repair": [
  null,
  "修复"
 ],
 "deactivate": [
  null,
  "取消激活"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "取消激活逻辑卷 $0/$1？"
 ],
 "Deactivate": [
  null,
  "取消激活"
 ],
 "Not enough space to grow": [
  null,
  "没有足够的空间来扩展"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 逻辑卷"
 ],
 "Striped (RAID 0)": [
  null,
  "条带 (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "镜像 (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "条带和镜像 (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "专用奇偶校验 (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "分布式奇偶校验 (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "双重分布式奇偶校验 (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "这个逻辑卷没有被它的内容完全使用。"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "卷大小为 $0。内容大小为 $1。"
 ],
 "Shrink volume": [
  null,
  "缩小卷"
 ],
 "Layout": [
  null,
  "布局"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，无法再被使用。您需要删除它并创建一个新卷来代替它。"
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，但还没有丢失任何数据。您应该修复它来恢复其原始的冗余功能。"
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "这个逻辑卷已丢失其部分物理卷，但可能还没有丢失任何数据。您可能可以修复它。"
 ],
 "Stripes": [
  null,
  "条带"
 ],
 "$0 synchronized": [
  null,
  "$0 同步"
 ],
 "Create volume group": [
  null,
  "创建卷组"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2物理卷"
 ],
 "Last cannot be removed": [
  null,
  "最后一个无法删除"
 ],
 "Not enough free space": [
  null,
  "没有足够的可用空间"
 ],
 "Volume group": [
  null,
  "卷组"
 ],
 "Create thin volume": [
  null,
  "创建精简卷"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "精简置备的 LVM2 逻辑卷"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "创建新的精简配置逻辑卷"
 ],
 "Not enough space": [
  null,
  "没有足够空间"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "用于精简置备的 LVM2 逻辑卷的池"
 ],
 "Inactive logical volume": [
  null,
  "不活跃的逻辑卷"
 ],
 "Activate": [
  null,
  "激活"
 ],
 "Unsupported logical volume": [
  null,
  "不支持的逻辑卷"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "内部错误 - 此逻辑卷被标记为 active，应该有一个关联的块设备。但是，无法找到这样的块设备。"
 ],
 "Installing $0 would remove $1.": [
  null,
  "安装 $0 将删除 $1 。"
 ],
 "Installing packages": [
  null,
  "安装软件包"
 ],
 "Block device for filesystems": [
  null,
  "文件系统的块设备"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "瘦分配配置卷的池"
 ],
 "Linear": [
  null,
  "线性"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO 文件系统卷（压缩/去除重复）"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "数据将存储在所选物理卷上，它们没有额外的冗余功能或性能改进。"
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "数据将交替存储在选定的物理卷上以提高性能。至少需要选择两个卷。"
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "数据将以两个或多个副本的形式存储在所选物理卷上，以提高可靠性。至少需要选择两个卷。"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "数据将存储为两份副本，并交替存储在选定的物理卷上，以提高可靠性和性能。至少需要选择四个卷。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "数据将存储在选定的物理卷上，这样其中一个卷丢失也不会影响数据。至少需要选择三个卷。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "数据将存储在所选物理卷上，因此即使其中一个丢失也不会影响数据。数据还会以交错方式存储以提高性能。至少需要选择三个卷。"
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "数据将存储在所选物理卷上，因此即使其中最多两个同时丢失也不会影响数据。数据还会以交错方式存储以提高性能。至少需要选择五个卷。"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "所选布局需要所有选定的 $0 物理卷。"
 ],
 "Create logical volume": [
  null,
  "创建逻辑卷"
 ],
 "Purpose": [
  null,
  "目的"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 软件包必须安装才能创建 VDO 设备。"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 需要有偶数数量的物理卷"
 ],
 "Logical size": [
  null,
  "逻辑大小"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "使用 LZ4 压缩独立块以节省空间"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "通过对相同数据块只保存一次来节省空间"
 ],
 "Creating VDO device": [
  null,
  "创建 VDO 设备"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "此 NFS 挂载正在使用中，只能更改其选项。"
 ],
 "NFS mount": [
  null,
  "NFS 挂载"
 ],
 "New NFS mount": [
  null,
  "新的 NFS 挂载"
 ],
 "Server address": [
  null,
  "服务器地址"
 ],
 "Server cannot be empty.": [
  null,
  "名称不能为空。"
 ],
 "Path on server": [
  null,
  "服务器上的路径"
 ],
 "Path on server cannot be empty.": [
  null,
  "服务器上的路径不能为空。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "服务器上的路径必须以“/”开头。"
 ],
 "Local mount point": [
  null,
  "挂载点"
 ],
 "Mount point cannot be empty.": [
  null,
  "挂载点不能为空。"
 ],
 "Mount point must start with \"/\".": [
  null,
  "挂载点必须以“/”开头。"
 ],
 "Mount options": [
  null,
  "挂载选项"
 ],
 "Mount at boot": [
  null,
  "引导时挂载"
 ],
 "Mount read only": [
  null,
  "只读挂载"
 ],
 "Custom mount options": [
  null,
  "自定义挂载选项"
 ],
 "Unable to unmount filesystem": [
  null,
  "无法卸载文件系统"
 ],
 "Stop and unmount": [
  null,
  "停止并卸载"
 ],
 "Unable to remove mount": [
  null,
  "无法删除挂载"
 ],
 "Stop and remove": [
  null,
  "停止并删除"
 ],
 "(not mounted)": [
  null,
  "（未挂载）"
 ],
 "Start multipath": [
  null,
  "启用多路径"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "该系统上有带有多路径的设备，但是多路径服务未运行。"
 ],
 "Show all $0 rows": [
  null,
  "显示所有 $0 行"
 ],
 "Category": [
  null,
  "类别"
 ],
 "more info": [
  null,
  "更多信息"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "Last modified: $0": [
  null,
  "最后修改于： $0"
 ],
 "Stored passphrase": [
  null,
  "保存的密码"
 ],
 "Encryption options": [
  null,
  "加密选项"
 ],
 "Encryption type": [
  null,
  "加密类型"
 ],
 "Cleartext device": [
  null,
  "明文设备"
 ],
 "yes": [
  null,
  "是"
 ],
 "Disk passphrase": [
  null,
  "磁盘密码"
 ],
 "Passphrase cannot be empty": [
  null,
  "密码不能为空"
 ],
 "Unlocking disk": [
  null,
  "解锁磁盘"
 ],
 "Checking for $0 package": [
  null,
  "检查 $0 软件包"
 ],
 "The $0 package must be installed.": [
  null,
  "必须安装 $0 软件包。"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "所有仓库都不提供 $0。"
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "安装错误 $0: PackageKit 或dnf5daemon-server 没有安装"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "安装 $0 过程中出现意外的 PackageManager 错误：$1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "在 initrd 中检查 NBDE 支持"
 ],
 "The initrd must be regenerated.": [
  null,
  "必须重新生成 initrd。"
 ],
 "Regenerating initrd": [
  null,
  "重新生成 initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "在内核命令行中添加 rd.neednet=1"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "将 \"$0\" 添加到文件系统选项"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "将 \"$0\" 添加到加密选项"
 ],
 "Enabling $0": [
  null,
  "启用 $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "添加网络绑定磁盘加密"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "系统目前不支持通过 Tang 密钥服务器解锁根文件系统。"
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "系统目前不支持在引导过程中通过 Tang 密钥服务器解锁文件系统。"
 ],
 "These additional steps are necessary:": [
  null,
  "这些额外步骤是必需的："
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "保存新密码需要解锁磁盘。请提供当前的磁盘密码。"
 ],
 "Fix NBDE support": [
  null,
  "修复 NBDE 支持"
 ],
 "Adding key": [
  null,
  "添加密钥"
 ],
 "Key source": [
  null,
  "密钥源"
 ],
 "Repeat passphrase": [
  null,
  "重复密码"
 ],
 "Passphrase": [
  null,
  "密码"
 ],
 "Tang keyserver": [
  null,
  "Tang 密钥服务器"
 ],
 "New passphrase": [
  null,
  "新密码"
 ],
 "Passphrases do not match": [
  null,
  "密码不匹配"
 ],
 "Keyserver address": [
  null,
  "Keyserver 地址"
 ],
 "Change passphrase": [
  null,
  "修改密码"
 ],
 "Old passphrase": [
  null,
  "旧密码"
 ],
 "Edit Tang keyserver": [
  null,
  "编辑 Tang 密钥服务器"
 ],
 "Verify key": [
  null,
  "验证密钥"
 ],
 "Trust key": [
  null,
  "信任密钥"
 ],
 "Passphrase can not be empty": [
  null,
  "密码不能为空"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "删除密码可能会阻止解锁 $0。"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "使用一个备用密码短语确认删除"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "当删除密码短语而没有确认另外一个密码短语时，如果忘记或丢失了其他密码短语，则可能无法取消锁定或进行密钥管理。"
 ],
 "Passphrase from any other key slot": [
  null,
  "来自其他密钥插槽的密码短语"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "删除密钥插槽 $0 中的密码短语？"
 ],
 "Remove $0?": [
  null,
  "移除 $0？"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "删除可能会阻止解锁 $0。"
 ],
 "Remove Tang keyserver?": [
  null,
  "删除 Tang 密钥服务器？"
 ],
 "Remove key in slot $0?": [
  null,
  "删除插槽 $0 中的密钥？"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "当前登录的用户不允许查看有关密钥的信息。"
 ],
 "No keys added": [
  null,
  "没有添加密钥"
 ],
 "Slot $0": [
  null,
  "插槽 $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "编辑密钥需要一个空闲插槽"
 ],
 "The last key slot can not be removed": [
  null,
  "无法删除最后一个密钥槽"
 ],
 "Keyserver": [
  null,
  "密钥服务器"
 ],
 "Unknown type": [
  null,
  "未知类型"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "这里无法编辑未知类型的密钥 slot"
 ],
 "Keys": [
  null,
  "密钥"
 ],
 "$0 slot remains": [
  null,
  "$0 个剩余插槽"
 ],
 "No available slots": [
  null,
  "没有可用的插槽"
 ],
 "No free key slots": [
  null,
  "没有空闲的密钥 slot"
 ],
 "Locked data": [
  null,
  "锁定的数据"
 ],
 "lock": [
  null,
  "锁定"
 ],
 "Lock $0?": [
  null,
  "锁定 $0 ?"
 ],
 "Address cannot be empty": [
  null,
  "地址不能为空"
 ],
 "Address is not a valid URL": [
  null,
  "该地址为无效 URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "使用 Tang 服务器检查密钥哈希。"
 ],
 "How to check": [
  null,
  "如何检查"
 ],
 "In a terminal, run: ": [
  null,
  "在终端中，运行： "
 ],
 "Successfully copied to clipboard!": [
  null,
  "成功复制到剪贴板！"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "检查命令中的 SHA-256 或 SHA-1 哈希值是否与此对话框匹配。"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs 子卷 $0（共 $1）"
 ],
 "Mount point cannot be empty": [
  null,
  "挂载点不能为空"
 ],
 "Mount point is already used for $0": [
  null,
  "挂载点已用于 $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "文件系统已在此挂载点下挂载。"
 ],
 "Please unmount them first.": [
  null,
  "请首先卸载它们。"
 ],
 "read only": [
  null,
  "只读"
 ],
 "never mount at boot": [
  null,
  "永远不会在引导时挂载"
 ],
 "after network": [
  null,
  "网络后"
 ],
 "ignore failure": [
  null,
  "忽略失败"
 ],
 "stop boot on failure": [
  null,
  "在失败时停止引导"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "文件系统没有分配挂载点。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "文件系统没有永久的挂载点。"
 ],
 "The filesystem is not mounted.": [
  null,
  "文件系统未挂载。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "文件系统将被解锁，并在下次引导时被挂载。这可能需要输入密码短语。"
 ],
 "(no assigned mount point)": [
  null,
  "（没有分配的挂载点）"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "该文件系统当前已被加载于 $0，但在下次引导后将被挂载到 $1。"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "在引导时在 $0 自动挂载"
 ],
 "Mount on $0 now": [
  null,
  "现在在 $0 挂载"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "该文件系统当前没有被加载，但在下次引导后将被挂载。"
 ],
 "Do not mount automatically on boot": [
  null,
  "不要在启动时自动安装"
 ],
 "Mount now": [
  null,
  "现在挂载"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "该文件系统当前已被加载，但在下次引导后将不再被挂载。"
 ],
 "Mount also automatically on boot": [
  null,
  "在引导时也自动挂载"
 ],
 "Unmount now": [
  null,
  "现在卸载"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "该文件系统当前已被加载于 $0，但在下次引导后将不再被挂载。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "文件系统被配置为在引导时自动挂载，但它的加密容器不会被解锁。"
 ],
 "Unlock automatically on boot": [
  null,
  "在引导时自动解锁"
 ],
 "Inconsistent filesystem mount": [
  null,
  "不一致的文件系统挂载"
 ],
 "$0 filesystem": [
  null,
  "$0 文件系统"
 ],
 "Filesystem name": [
  null,
  "文件系统名称"
 ],
 "Filesystem is locked": [
  null,
  "文件系统被锁住"
 ],
 "Mounts before services start": [
  null,
  "服务启动前挂载"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "适用于关键挂载，如 /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "如果文件系统没有挂载，引导会失败，防止远程访问"
 ],
 "Mounts in parallel with services": [
  null,
  "与服务并行挂载"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "当文件系统没有挂载时，引导仍然成功"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "与服务并行挂载，但是在网络可用后"
 ],
 "Does not mount during boot": [
  null,
  "在引导过程中不挂载"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "对于可选或需要交互的挂载（如密码短语）很有用"
 ],
 "At boot": [
  null,
  "在引导时"
 ],
 "Mount before services start": [
  null,
  "服务启动前挂载"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "无需等待即可挂载，忽略失败"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "网络可用后挂载，忽略失败"
 ],
 "Do not mount": [
  null,
  "不要挂载"
 ],
 "This device can not be used for the installation target.": [
  null,
  "这个设备不能用于安装目标。"
 ],
 "Mount filesystem": [
  null,
  "挂载文件系统"
 ],
 "Unmount filesystem $0": [
  null,
  "卸载文件系统 $0"
 ],
 "Mount configuration": [
  null,
  "挂载配置"
 ],
 "Swap": [
  null,
  "交换空间"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "解锁加密的 Stratis 池"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "为这些块设备上的池提供密码短语："
 ],
 "Stratis pool": [
  null,
  "Stratis 池"
 ],
 "stopped": [
  null,
  "停止"
 ],
 "Block devices": [
  null,
  "块设备"
 ],
 "No block devices found": [
  null,
  "没有找到块设备"
 ],
 "Stratis block devices": [
  null,
  "Stratis 块设备"
 ],
 "Stratis block device": [
  null,
  "Stratis 块设备"
 ],
 "data": [
  null,
  "数据"
 ],
 "cache": [
  null,
  "缓存"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "请提供现有的池密码。"
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "若密钥服务器 $0 不可达，您可以提供一个现有密码。"
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "若所有密钥服务器均不可达，您可以提供一个现有密码。"
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "若所有非交互式解锁方式均无效，您可以提供一个现有密码。"
 ],
 "Pool passphrase": [
  null,
  "池密码"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "位于 $0 的密钥服务器必须可达。"
 ],
 "At least one keyserver must be reachable.": [
  null,
  "至少需要一个密钥服务器可达。"
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "至少需要一种有效的非交互式解锁方式。"
 ],
 "Create filesystem": [
  null,
  "创建文件系统"
 ],
 "Stratis filesystem": [
  null,
  "Stratis 文件系统"
 ],
 "Set initial size": [
  null,
  "设置初始大小"
 ],
 "Limit size": [
  null,
  "限制大小"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "删除 Stratis 池将会清除其包含的所有数据。"
 ],
 "Rename Stratis pool": [
  null,
  "重命名 Stratis 池"
 ],
 "Add block devices": [
  null,
  "添加块设备"
 ],
 "Tier": [
  null,
  "层"
 ],
 "Data": [
  null,
  "数据"
 ],
 "Cache": [
  null,
  "缓存"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "添加块设备需要解锁池。"
 ],
 "Encrypted Stratis pool": [
  null,
  "加密的 Stratis 池"
 ],
 "Delete pool": [
  null,
  "删除池"
 ],
 "Encryption tokens": [
  null,
  "加密令牌"
 ],
 "Stratis filesystems": [
  null,
  "Stratis 文件系统"
 ],
 "Create new filesystem": [
  null,
  "创建新文件系统"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "该池不使用其块设备上的所有空间。"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "创建池后，该池的某些块设备的大小已增大。 可以安全地扩大池以使用新的可用空间。"
 ],
 "Grow the pool to take all space": [
  null,
  "扩展池以占据所有空间"
 ],
 "This pool is in a degraded state.": [
  null,
  "这个池处于降级状态。"
 ],
 "No filesystems": [
  null,
  "无文件系统"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis 文件系统池"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "此密码是解锁该池的唯一方式，无法删除。"
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "该密钥服务器是解锁池的唯一方法并且无法删除。"
 ],
 "Add passphrase": [
  null,
  "添加密码"
 ],
 "Add keyserver": [
  null,
  "添加密钥服务器"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "不能删除最后一个令牌"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "没有更多空间可用于密码或密钥服务器。"
 ],
 "Confirm": [
  null,
  "确认"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "添加密码需要解锁池。"
 ],
 "Remove passphrase?": [
  null,
  "删除密码?"
 ],
 "Add Tang keyserver": [
  null,
  "添加 Tang 密钥服务器"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "添加密钥服务器需要解锁池。"
 ],
 "Remove Clevis token?": [
  null,
  "删除Clevis令牌？"
 ],
 "Metadata format": [
  null,
  "元数据格式"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "元数据格式为 V1 的池被限制为至多一个密码与至多一个密钥服务器。"
 ],
 "Overprovisioning": [
  null,
  "过度置备"
 ],
 "Allow overprovisioning": [
  null,
  "允许过度置备"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "虚拟文件系统大小比池大。无法禁用过度置备。"
 ],
 "Allocated": [
  null,
  "已分配"
 ],
 "Name can not be empty.": [
  null,
  "名称不能为空."
 ],
 "A pool with this name exists already.": [
  null,
  "已有重名存储池。"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "存储池中存在重名文件系统。"
 ],
 "Create Stratis pool": [
  null,
  "创建 Stratis 池"
 ],
 "No block devices are available.": [
  null,
  "没有可用的块设备。"
 ],
 "At least one block device is needed.": [
  null,
  "至少需要 1 个块设备。"
 ],
 "Encrypt data with a passphrase": [
  null,
  "使用密码加密数据"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "使用 Tang 密钥服务器加密数据"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "创建文件系统 $0 的快照"
 ],
 "Create snapshot and mount": [
  null,
  "创建快照和挂载"
 ],
 "Create snapshot only": [
  null,
  "仅创建快照"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "删除文件系统将会删除其中的所有数据。"
 ],
 "Snapshot": [
  null,
  "快照"
 ],
 "Rename filesystem": [
  null,
  "重命名文件系统"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "设置虚拟文件系统大小的限制"
 ],
 "Limit virtual filesystem size": [
  null,
  "限制虚拟文件系统大小"
 ],
 "Virtual size limit": [
  null,
  "虚拟大小限制"
 ],
 "Virtual size": [
  null,
  "虚拟大小"
 ],
 "Create RAID device": [
  null,
  "创建 RAID 设备"
 ],
 "RAID level": [
  null,
  "RAID 级别"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (条带)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (镜像)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (奇偶校验)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (奇偶校验)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (双倍奇偶校验)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (条带镜像)"
 ],
 "Chunk size": [
  null,
  "区块大小"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "至少需要 $0 块磁盘。"
 ],
 "MDRAID disk": [
  null,
  "MDRAID 磁盘"
 ],
 "In sync": [
  null,
  "同步中"
 ],
 "Spare": [
  null,
  "备用"
 ],
 "Recovering": [
  null,
  "恢复"
 ],
 "Write-mostly": [
  null,
  "主要写"
 ],
 "Blocked": [
  null,
  "受阻"
 ],
 "Unknown ($0)": [
  null,
  "未知 ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID 设备必须正在运行"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID 设备正在恢复"
 ],
 "Need a spare disk": [
  null,
  "需要一个备用磁盘"
 ],
 "Last disk can not be removed": [
  null,
  "不能删除最后一个磁盘"
 ],
 "MDRAID device": [
  null,
  "MDRAID 设备"
 ],
 "Confirm stopping of $0": [
  null,
  "确认停止 $0"
 ],
 "Stop device": [
  null,
  "停止设备"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "删除将清除 MDRAID 设备中的所有数据。"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID 设备必须正在运行"
 ],
 "Add disk": [
  null,
  "添加磁盘"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 个磁盘"
 ],
 "$0 chunk size": [
  null,
  "$0 块大小"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID 设备处于降级状态"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "这个 MDRAID 设备没有 write-intent 位图。这个位图可以显著减少同步时间。"
 ],
 "Add a bitmap": [
  null,
  "添加位图"
 ],
 "No disks found": [
  null,
  "没有找到磁盘"
 ],
 "MDRAID disks": [
  null,
  "MDRAID 磁盘"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "删除会擦除 VDO 设备上的所有数据."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "此 VDO 设备的创建未完成，无法使用该设备。"
 ],
 "Remove device": [
  null,
  "删除设备"
 ],
 "Grow to take all space": [
  null,
  "扩展到占据所有空间"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "此 VDO 设备不使用其所有后台设备。"
 ],
 "Only $0 of $1 are used.": [
  null,
  "仅使用了 $1 的 $0。"
 ],
 "Grow logical size of $0": [
  null,
  "扩展 $0 的逻辑大小"
 ],
 "Physical": [
  null,
  "物理"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "已使用 $0 数据 + $1 额外开销，共 $2（$3）"
 ],
 "Logical": [
  null,
  "逻辑"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "已使用 $0，共 $1（已保存 $2）"
 ],
 "Index memory": [
  null,
  "索引内存"
 ],
 "SMART self-test of $target": [
  null,
  "$target SMART 自检"
 ],
 "Ejecting $target": [
  null,
  "弹出 $target"
 ],
 "Unlocking $target": [
  null,
  "解锁 $target"
 ],
 "Locking $target": [
  null,
  "锁定 $target"
 ],
 "Modifying $target": [
  null,
  "修改 $target"
 ],
 "Resizing $target": [
  null,
  "调整大小 $target"
 ],
 "Starting swapspace $target": [
  null,
  "启动交换空间 $target"
 ],
 "Stopping swapspace $target": [
  null,
  "停止启动交换空间 $target"
 ],
 "Mounting $target": [
  null,
  "挂载 $target"
 ],
 "Unmounting $target": [
  null,
  "卸载 $target"
 ],
 "Checking $target": [
  null,
  "检查 $target"
 ],
 "Repairing $target": [
  null,
  "正在修复 $target"
 ],
 "Erasing $target": [
  null,
  "擦除 $target"
 ],
 "Creating filesystem on $target": [
  null,
  "在 $target 中创建文件系统"
 ],
 "Setting up loop device $target": [
  null,
  "创建 loop 设备 $target"
 ],
 "Deleting $target": [
  null,
  "删除 $target"
 ],
 "Creating partition $target": [
  null,
  "创建分区 $target"
 ],
 "Cleaning up for $target": [
  null,
  "清理 $target"
 ],
 "Securely erasing $target": [
  null,
  "安全擦除 $target"
 ],
 "Very securely erasing $target": [
  null,
  "非常安全地擦除 $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "停止 MDRAID 设备 $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "启动 MDRAID 设备 $target"
 ],
 "Marking $target as faulty": [
  null,
  "标记 $target 为故障"
 ],
 "Removing $target from MDRAID device": [
  null,
  "从 MDRAID 设备中删除 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "创建 MDRAID 设备 $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "检查 MDRAID 设备 $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "检查并修复 MDRAID 设备 $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "恢复 MDRAID 设备 $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "同步 MDRAID 设备 $target"
 ],
 "Activating $target": [
  null,
  "正在启用逻辑卷 $target"
 ],
 "Deactivating $target": [
  null,
  "取消激活 $target"
 ],
 "Creating snapshot of $target": [
  null,
  "创建 $target 的快照"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "创建 LVM2 卷组 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "删除 LVM2 卷组 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "添加物理卷至 $target"
 ],
 "Removing physical volume from $target": [
  null,
  "从 $target 删除物理卷"
 ],
 "Emptying $target": [
  null,
  "清空 $target"
 ],
 "Creating logical volume $target": [
  null,
  "创建逻辑卷 $target"
 ],
 "Renaming $target": [
  null,
  "重命名 $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "对 $target 的操作 '$operation'"
 ],
 "unknown target": [
  null,
  "未知目标"
 ],
 "Jobs": [
  null,
  "任务"
 ],
 "Reading": [
  null,
  "读取中"
 ],
 "Writing": [
  null,
  "写入中"
 ],
 "Install Stratis support": [
  null,
  "安装 Stratis 支持"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "$0 软件包必须安装才能创建 Stratis 池。"
 ],
 "Install NFS support": [
  null,
  "安装 NFS 支持"
 ],
 "Create MDRAID device": [
  null,
  "创建 MDRAID 设备"
 ],
 "Create LVM2 volume group": [
  null,
  "创建 LVM2 卷组"
 ],
 "Change iSCSI initiator name": [
  null,
  "变更 iSCSI Initiator 名称"
 ],
 "Add iSCSI portal": [
  null,
  "添加 iSCSI 门户"
 ],
 "Local storage": [
  null,
  "本地存储"
 ],
 "Networked storage": [
  null,
  "网络存储"
 ],
 "Create storage device": [
  null,
  "创建存储设备"
 ],
 "No storage found": [
  null,
  "没有找到存储"
 ],
 "Server address cannot be empty.": [
  null,
  "服务器地址不能为空。"
 ],
 "Next": [
  null,
  "下一步"
 ],
 "Invalid username or password": [
  null,
  "无效的用户名或密码"
 ],
 "Unknown host name": [
  null,
  "未知主机名"
 ],
 "Unable to reach server": [
  null,
  "无法到达服务器"
 ],
 "Available targets on $0": [
  null,
  "$0 上可用的目标"
 ],
 "Authentication required": [
  null,
  "需要验证"
 ],
 "iSCSI portal": [
  null,
  "iSCSI 门户"
 ],
 "iSCSI drives": [
  null,
  "iSCSI 驱动器"
 ],
 "No drives found": [
  null,
  "没有找到驱动器"
 ],
 "Target": [
  null,
  "目标"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO 后台设备不能更小"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs 无法变得更小"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "这里不能把无法识别的数据变小。"
 ],
 "Unlock before resizing": [
  null,
  "在调整大小前解锁"
 ],
 "$0 can not be resized here": [
  null,
  "无法在此改变 $0 的大小"
 ],
 "$0 can not be resized": [
  null,
  "无法改变 $0 的大小"
 ],
 "$0 can not be made smaller": [
  null,
  "无法缩小 $0"
 ],
 "$0 can not be made larger": [
  null,
  "无法扩容 $0"
 ],
 "Physical volumes can not be resized here": [
  null,
  "此处无法调整物理卷的大小"
 ],
 "Swap can not be resized here": [
  null,
  "无法在此处调整交换空间的大小"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "未识别的数据无法在此处变得更小"
 ],
 "Activate before resizing": [
  null,
  "调整大小前激活"
 ],
 "Grow logical volume": [
  null,
  "扩展逻辑卷"
 ],
 "Grow partition": [
  null,
  "扩容分区"
 ],
 "grow": [
  null,
  "扩容"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "必须选择 $0 个物理卷"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "对一个加密的文件系统调整大小需要解锁磁盘。请提供磁盘的密码。"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "必须选择 $0 个物理卷，每个逻辑卷条带使用一个。"
 ],
 "Shrink logical volume": [
  null,
  "缩小逻辑卷"
 ],
 "shrink": [
  null,
  "缩小"
 ],
 "Unformatted data": [
  null,
  "未格式化的数据"
 ],
 "Block device": [
  null,
  "块设备"
 ],
 "Device number": [
  null,
  "设备号"
 ],
 "Create partition on $0": [
  null,
  "在 $0 上创建分区"
 ],
 "Format $0": [
  null,
  "格式化 $0"
 ],
 "No filesystem": [
  null,
  "无文件系统"
 ],
 "(recommended)": [
  null,
  "（推荐）"
 ],
 "No encryption": [
  null,
  "无加密"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "重用现有的加密($0)"
 ],
 "Reuse existing encryption": [
  null,
  "重用现有的加密"
 ],
 "format": [
  null,
  "格式"
 ],
 "Format and mount": [
  null,
  "格式和挂载"
 ],
 "Format only": [
  null,
  "仅格式"
 ],
 "Format": [
  null,
  "格式化"
 ],
 "Create and start": [
  null,
  "创建并启动"
 ],
 "Format and start": [
  null,
  "格式和启动"
 ],
 "Store passphrase": [
  null,
  "存储密码"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "在格式化之前需要解锁磁盘。请提供现有的密码短语。"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "格式化会擦除存储设备上的所有数据。"
 ],
 "Unrecognized data": [
  null,
  "无法识别的数据"
 ],
 "Storage can not be managed on this system.": [
  null,
  "存储不能在这个系统上管理。"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一款服务器管理工具，可让您通过 Web 浏览器轻松管理 Linux 服务器。在终端和 Web 界面之间切换毫无障碍。通过 Cockpit 启动的服务也可以在终端中停止。同样，如果终端中出现错误，也可以在 Cockpit 的日志界面中看到。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常适合新的系统管理员使用，让他们能够轻松完成存储管理、查看日志以及启动和停止服务等简单任务。您可以同时监控和管理多台服务器。只需单击一下即可添加服务器，让这些主机协同工作。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、组合、VLAN 和防火墙等。NetworkManager 与 Ubuntu 默认的 systemd-networkd 以及 Debian 的 ifupdown 脚本不兼容。"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具用于配置 SELinux 策略，并可帮助理解和解决策略违规问题。"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具用于将系统配置为写入内核崩溃转储。它支持“local”（磁盘）、“ssh” 和“nfs” 转储目标。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "format-bytes\u0004bytes": [
  null,
  "字节"
 ]
});
