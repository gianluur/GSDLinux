cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Journal": [
  null,
  "ジャーナル"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "Hardware information": [
  null,
  "ハードウェア情報"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "Default": [
  null,
  "デフォルト"
 ],
 "Light": [
  null,
  "ライト"
 ],
 "Dark": [
  null,
  "ダーク"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Select": [
  null,
  "選択"
 ],
 "System": [
  null,
  "システム"
 ],
 "Search": [
  null,
  "検索"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "Add": [
  null,
  "追加"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $4 の $3 ファイルに追加されました。"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "Permission denied": [
  null,
  "パーミッションが拒否されました"
 ],
 "Clear input value": [
  null,
  "入力値の消去"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "Create $0": [
  null,
  "$0 を作成"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Method": [
  null,
  "方法"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "less than a minute ago": [
  null,
  "一分以内"
 ],
 "in less than a minute": [
  null,
  "一分以内"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Unknown host: $0": [
  null,
  "不明なホスト: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 鍵認証を使用して $0 にログインできません。パスワードを入力してください。"
 ],
 "SSH key login": [
  null,
  "SSH 鍵ログイン"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit が、エラーコード $0 を報告しました"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "Row expansion": [
  null,
  "行の拡張"
 ],
 "Row select": [
  null,
  "行の選択"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "フィルターのために入力"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ファイルシステム"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Pizza box": [
  null,
  "ピザ箱"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Select an option": [
  null,
  "オプションの選択"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "$0 is not a directory": [
  null,
  "$0 はディレクトリーではありません"
 ],
 "$0 does not exist": [
  null,
  "$0 が存在しません"
 ],
 "Font size": [
  null,
  "フォントのサイズ"
 ],
 "Decrease by one": [
  null,
  "1 つ減らす"
 ],
 "Increase by one": [
  null,
  "1 つ増やす"
 ],
 "Appearance": [
  null,
  "外観"
 ],
 "Black": [
  null,
  "黒"
 ],
 "White": [
  null,
  "白"
 ],
 "Reset": [
  null,
  "リセット"
 ],
 "Unable to open directory": [
  null,
  "ディレクトリーを開けません"
 ],
 "Running process prevents directory change": [
  null,
  "実行中のプロセスがあるためディレクトリーを変更できません"
 ],
 "Change directory": [
  null,
  "ディレクトリーの変更"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "ディレクトリーを変更すると、現在実行中のプロセスが強制的に停止します。続行する前に、ターミナルでプロセスを手動で停止することもできます。"
 ],
 "Terminal not available": [
  null,
  "ターミナルは利用できません"
 ],
 "This browser does not support WebGL2.": [
  null,
  "このブラウザはWebGL2に対応していません。"
 ],
 "unknown": [
  null,
  "不明"
 ],
 "Shutdown": [
  null,
  "シャットダウン"
 ],
 "running $0": [
  null,
  "実行中 $0"
 ],
 "Current boot": [
  null,
  "現在の起動"
 ],
 "Previous boot": [
  null,
  "以前のブート"
 ],
 "Last 24 hours": [
  null,
  "過去 24 時間"
 ],
 "Last 7 days": [
  null,
  "過去 7 日間"
 ],
 "Only emergency": [
  null,
  "緊急のみ"
 ],
 "Alert and above": [
  null,
  "アラート以上のレベル"
 ],
 "Critical and above": [
  null,
  "重大以上のレベル"
 ],
 "Error and above": [
  null,
  "エラー以上のレベル"
 ],
 "Warning and above": [
  null,
  "警告以上のレベル"
 ],
 "Notice and above": [
  null,
  "注意以上のレベル"
 ],
 "Info and above": [
  null,
  "情報以上のレベル"
 ],
 "Debug and above": [
  null,
  "デバッグ以上のレベル"
 ],
 "Toggle filters": [
  null,
  "フィルターの切り替え"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Priority": [
  null,
  "優先度"
 ],
 "Identifier": [
  null,
  "識別子"
 ],
 "Filters": [
  null,
  "フィルター"
 ],
 "Pause": [
  null,
  "一時停止"
 ],
 "Resume": [
  null,
  "再開"
 ],
 "All": [
  null,
  "すべて"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日付の指定は、YYYY-MM-DD hh:mm:ss の形式にする必要があります。'yesterday'、'today'、'tomorrow' という文字列も認識されます。'now' は現在の時刻を指します。相対時間も指定できます。その場合は '-' または '+' を先頭に付けます"
 ],
 "Since": [
  null,
  "フィルター開始時刻"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "指定の日付以降のエントリーまたは新しいエントリーを表示します。"
 ],
 "Until": [
  null,
  "フィルター終了時刻"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "指定の日付以前のエントリーまたはそれ以前のエントリーを表示します。"
 ],
 "Boot": [
  null,
  "ブート"
 ],
 "Show messages from a specific boot.": [
  null,
  "特定のブートのメッセージを表示します。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "これにより、_BOOT_ID=' 一致を追加します。指定のない場合は、現在のブートのログが表示されます。ブート ID を省略すると、正のオフセットはジャーナルの開始からブートを探します。また、ゼロまたはゼロ未満のオフセットは、ジャーナルの最後からブートを探します。したがって、1 は時系列順でジャーナルで見つかった最初のブートを意味し、2 は 2 番目のブートを意味します (以下、同様)。また、-0 は最後のブート、-1 は最後の前のブートとなります。"
 ],
 "Unit": [
  null,
  "ユニット"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "指定した systemd ユニットのメッセージを表示します。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "これにより、'_SYSTEMD_UNIT='、'COREDUMP_UNIT='、'UNIT=' と一致させ、指定のユニットに対する考えられるメッセージをすべて特定します。複数のユニットをコンマで区切ることができます。"
 ],
 "Free-form search": [
  null,
  "フリーフォーム検索"
 ],
 "Show messages containing given string.": [
  null,
  "与えられた文字列が含まれるメッセージを表示します。"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ログメッセージのテキスト文字列はフィルターでフィルタリングできます。文字列は、正規表現の形式でも指定できます。また、メッセージログフィールドによるフィルタリングもサポートできます。これらは、FIELD=VALUE の形式でスペースで区切った値は、使用できる値のカンマ区切りのリストになります。"
 ],
 "journalctl manpage": [
  null,
  "journalctl man ページ"
 ],
 "Successfully copied to clipboard": [
  null,
  "クリップボードへのコピーに成功しました"
 ],
 "Create timer": [
  null,
  "タイマーの作成"
 ],
 "Timer creation failed": [
  null,
  "タイマーの作成に失敗しました"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "このフィールドは必須の項目です"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "アルファベット、数字、:、 _ 、.、@、- のみを使用できます"
 ],
 "Description": [
  null,
  "説明"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "トリガー"
 ],
 "At specific time": [
  null,
  "特定の時間"
 ],
 "After system boot": [
  null,
  "システムブート後"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Minutes": [
  null,
  "分"
 ],
 "Hours": [
  null,
  "時"
 ],
 "Weeks": [
  null,
  "週"
 ],
 "Delay must be a number": [
  null,
  "遅延は数字である必要があります"
 ],
 "Repeat": [
  null,
  "繰り返し"
 ],
 "Don't repeat": [
  null,
  "繰り返さない"
 ],
 "Minutely": [
  null,
  "1 分間隔"
 ],
 "Hourly": [
  null,
  "1 時間ごと"
 ],
 "Daily": [
  null,
  "毎日"
 ],
 "Weekly": [
  null,
  "毎週"
 ],
 "Monthly": [
  null,
  "毎月"
 ],
 "Yearly": [
  null,
  "毎年"
 ],
 "Run at": [
  null,
  "実行時刻"
 ],
 "At second": [
  null,
  "秒"
 ],
 "At minute": [
  null,
  "分"
 ],
 "Run on": [
  null,
  "以下で実行"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分は 0〜59 の数字である必要があります"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "秒は 0〜59 の数字でなければなりません"
 ],
 "Repeat weekly": [
  null,
  "毎週繰り返す"
 ],
 "Mondays": [
  null,
  "毎週月曜日"
 ],
 "Tuesdays": [
  null,
  "毎週火曜日"
 ],
 "Wednesdays": [
  null,
  "毎週水曜日"
 ],
 "Thursdays": [
  null,
  "毎週木曜日"
 ],
 "Fridays": [
  null,
  "毎週金曜日"
 ],
 "Saturdays": [
  null,
  "毎週土曜日"
 ],
 "Sundays": [
  null,
  "毎週日曜日"
 ],
 "Repeat monthly": [
  null,
  "毎月繰り返す"
 ],
 "1st": [
  null,
  "1 日"
 ],
 "2nd": [
  null,
  "2 日"
 ],
 "3rd": [
  null,
  "3 日"
 ],
 "4th": [
  null,
  "4 日"
 ],
 "5th": [
  null,
  "5 日"
 ],
 "6th": [
  null,
  "6 日"
 ],
 "7th": [
  null,
  "7 日"
 ],
 "8th": [
  null,
  "8 日"
 ],
 "9th": [
  null,
  "9 日"
 ],
 "10th": [
  null,
  "10 日"
 ],
 "11th": [
  null,
  "11 日"
 ],
 "12th": [
  null,
  "12 日"
 ],
 "13th": [
  null,
  "13 日"
 ],
 "14th": [
  null,
  "14 日"
 ],
 "15th": [
  null,
  "15 日"
 ],
 "16th": [
  null,
  "16 日"
 ],
 "17th": [
  null,
  "17 日"
 ],
 "18th": [
  null,
  "18 日"
 ],
 "19th": [
  null,
  "19 日"
 ],
 "20th": [
  null,
  "20 日"
 ],
 "21th": [
  null,
  "21 日"
 ],
 "22th": [
  null,
  "22 日"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "24 日"
 ],
 "25th": [
  null,
  "25 日"
 ],
 "26th": [
  null,
  "26 日"
 ],
 "27th": [
  null,
  "27 日"
 ],
 "28th": [
  null,
  "28 日"
 ],
 "29th": [
  null,
  "29 日"
 ],
 "30th": [
  null,
  "30 日"
 ],
 "31st": [
  null,
  "31 日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "View logs": [
  null,
  "ログの表示"
 ],
 "Dismiss": [
  null,
  "解除"
 ],
 "Scheduled poweroff at $0": [
  null,
  "電源オフが $0 に予定されています"
 ],
 "Cancel poweroff": [
  null,
  "電源オフの取り消し"
 ],
 "Scheduled reboot at $0": [
  null,
  "再起動が $0 に予定されています"
 ],
 "Cancel reboot": [
  null,
  "再起動の取り消し"
 ],
 "edit": [
  null,
  "編集"
 ],
 "Set hostname": [
  null,
  "ホスト名を設定します"
 ],
 "Configuration": [
  null,
  "設定"
 ],
 "Hostname": [
  null,
  "ホスト名"
 ],
 "System time": [
  null,
  "システム時間"
 ],
 "Domain": [
  null,
  "ドメイン"
 ],
 "Performance profile": [
  null,
  "パフォーマンスプロファイル"
 ],
 "Secure shell keys": [
  null,
  "Secure shell キー"
 ],
 "Show fingerprints": [
  null,
  "フィンガープリントの表示"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh ホスト鍵の一覧表示に失敗しました: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH キーの読み込みに失敗しました"
 ],
 "Error message": [
  null,
  "エラーメッセージ"
 ],
 "Loading keys...": [
  null,
  "キーをロード中..."
 ],
 "No host keys found.": [
  null,
  "ホストキーが見つかりません。"
 ],
 "Machine SSH key fingerprints": [
  null,
  "マシンSSH 鍵フィンガープリント"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "実際のホスト名は 64 文字以下である必要があります"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "実際のホスト名には小文字、数字、ダッシュ、およびピリオドのみを使用できます (入力されたサブドメインを含む)"
 ],
 "Change host name": [
  null,
  "ホスト名の変更"
 ],
 "Pretty host name": [
  null,
  "プリティホスト名"
 ],
 "Real host name": [
  null,
  "実際のホスト名"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "ユーザー $0 は、暗号化ポリシーの変更を許可されていません"
 ],
 "Cryptographic policy": [
  null,
  "暗号化ポリシー"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "現在の脅威モデルに推奨される安全な設定。"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "SHA-1 署名検証があるデフォルトは使用できます。"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "攻撃対象が増えるという代償を払ってでも、相互運用性を高めます。"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "Active Directory との相互運用性があるレガシー。"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS モードで起動する場合は、承認および許可されたアルゴリズムのみを使用してください。"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "さらにコモンクライテリアの制限がある FIPS。"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "相互運用性を犠牲にして、近い将来に予想される攻撃から保護します。"
 ],
 "Custom cryptographic policy": [
  null,
  "カスタム暗号化ポリシー"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "暗号化ポリシーは、TLS、IPSec、SSH、DNSSec、および Kerberos プロトコルに対応するコア暗号化サブシステムを設定するシステムコンポーネントです。"
 ],
 "Change cryptographic policy": [
  null,
  "暗号化ポリシーの変更"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "新しいポリシーを適用しています... これには数分かかる場合があります。"
 ],
 "Reapply and reboot": [
  null,
  "再適用して再起動する"
 ],
 "Apply and reboot": [
  null,
  "適用して再起動する"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS が適切に有効化されていません"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "暗号化ポリシーに一貫性がありません"
 ],
 "Review cryptographic policy": [
  null,
  "暗号化ポリシーを確認する"
 ],
 "System information": [
  null,
  "システム情報"
 ],
 "Model": [
  null,
  "モデル"
 ],
 "Asset tag": [
  null,
  "アセットタグ"
 ],
 "Machine ID": [
  null,
  "マシン ID"
 ],
 "Up since": [
  null,
  "起動時間:"
 ],
 "View hardware details": [
  null,
  "ハードウェアの詳細の表示"
 ],
 "Last successful login:": [
  null,
  "最後の正常ログイン:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 がログインの試行に失敗しました"
 ],
 "View login history": [
  null,
  "ログイン履歴の表示"
 ],
 "recommended": [
  null,
  "推奨"
 ],
 "inconsistent": [
  null,
  "一貫性がない"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "ドメインに参加するには、realmd のインストールが必要です"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "realmd がこのシステムで利用できないため、ドメインに参加できません"
 ],
 "Joining this domain is not supported": [
  null,
  "このドメインの参加はサポートされていません"
 ],
 "Login format": [
  null,
  "ログインフォーマット"
 ],
 "Server software": [
  null,
  "サーバーソフトウェア"
 ],
 "Client software": [
  null,
  "クライアントソフトウェア"
 ],
 "Leave domain": [
  null,
  "ドメインの脱退"
 ],
 "Leave $0": [
  null,
  "$0 の脱退"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "ドメインの終了後は、ローカル認証情報を持つユーザーだけが、このマシンにログインできます。DNS 解決設定および信頼される CA の一覧が変更する可能性があるため、他のサービスにも影響を及ぼす場合があります。"
 ],
 "Validating address": [
  null,
  "アドレスの検証"
 ],
 "Contacted domain": [
  null,
  "接続されたドメイン"
 ],
 "Domain could not be contacted": [
  null,
  "ドメイン に接続できませんでした"
 ],
 "Domain is not supported": [
  null,
  "ドメインはサポートされません"
 ],
 "Domain address": [
  null,
  "ドメインアドレス"
 ],
 "Domain administrator name": [
  null,
  "ドメイン管理者名"
 ],
 "Domain administrator password": [
  null,
  "ドメイン管理者パスワード"
 ],
 "Joining": [
  null,
  "参加する"
 ],
 "Join": [
  null,
  "参加"
 ],
 "This may take a while": [
  null,
  "これにはしばらく時間がかかることがあります"
 ],
 "Not permitted to configure realms": [
  null,
  "レルムの設定が許可されていません"
 ],
 "Join domain": [
  null,
  "ドメイン参加"
 ],
 "Install realmd support": [
  null,
  "realmd サポートをインストールする"
 ],
 "$0 disk is failing": [
  null,
  "ディスク $0 で障害が発生中"
 ],
 "Not connected to Insights": [
  null,
  "Insights に接続されていません"
 ],
 "Health": [
  null,
  "ヘルス"
 ],
 "of $0 CPU": [
  null,
  "CPU 数 ($0)"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "View metrics and history": [
  null,
  "メトリックスおよび履歴の表示"
 ],
 "Tuned is not available": [
  null,
  "Tuned が利用できません"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未実行"
 ],
 "Tuned is off": [
  null,
  "Tuned がオフです"
 ],
 "This system is using the recommended profile": [
  null,
  "このシステムは推奨プロファイルを使用しています"
 ],
 "This system is using a custom profile": [
  null,
  "このシステムはカスタムプロファイルを使用しています"
 ],
 "none": [
  null,
  "なし"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned との通信に失敗しました"
 ],
 "Failed to enable tuned": [
  null,
  "tuned の有効化に失敗しました"
 ],
 "Failed to disable tuned": [
  null,
  "tuned の無効化に失敗しました"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned プロファイルの無効化に失敗しました"
 ],
 "Failed to switch profile": [
  null,
  "プロファイルの切り替えに失敗しました"
 ],
 "None": [
  null,
  "なし"
 ],
 "Disable tuned": [
  null,
  "tuned の無効化"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned の起動に失敗しました"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned は、システムを監視し、特定のワークロードでパフォーマンスを最適化するサービスです。Tuned のコアは、さまざまなユースケースに合わせてシステムを調整するプロファイルです。"
 ],
 "Change performance profile": [
  null,
  "パフォーマンスプロファイルの変更"
 ],
 "Change profile": [
  null,
  "プロファイルの変更"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd を編集する"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "変更を /etc/motd に保存できませんでした"
 ],
 "Save changes": [
  null,
  "変更の保存"
 ],
 "Edit motd": [
  null,
  "motd を編集する"
 ],
 "Stub": [
  null,
  "スタブ"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Bad setting": [
  null,
  "正しくない設定"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Merged": [
  null,
  "マージ済み"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "Reloading": [
  null,
  "リロード中"
 ],
 "Not running": [
  null,
  "未実行"
 ],
 "Failed to start": [
  null,
  "起動に失敗"
 ],
 "Maintenance": [
  null,
  "メンテナンス"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Linked": [
  null,
  "リンク済み"
 ],
 "Alias": [
  null,
  "エイリアス"
 ],
 "Masked": [
  null,
  "マスク"
 ],
 "Static": [
  null,
  "静的"
 ],
 "Invalid": [
  null,
  "無効"
 ],
 "Indirect": [
  null,
  "間接"
 ],
 "Generated": [
  null,
  "生成しました"
 ],
 "Transient": [
  null,
  "一時的"
 ],
 "Bad": [
  null,
  "正しくない"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd シグナルへのサブスクライブに失敗しました: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus への接続に失敗しました: $0"
 ],
 "Listing units failed: $0": [
  null,
  "ユニットの一覧表示に失敗しました: $0"
 ],
 "$0 service has failed": [
  null,
  "失敗したサービスの数 ($0)"
 ],
 "Loading of units failed": [
  null,
  "ユニットの読み込みに失敗しました"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Listing units": [
  null,
  "ユニットの一覧表示"
 ],
 "Filter by name or description": [
  null,
  "名前または説明による絞り込み"
 ],
 "Active state": [
  null,
  "アクティブ状態"
 ],
 "File state": [
  null,
  "ファイル状態"
 ],
 "$0 filters applied": [
  null,
  ""
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "ユーザー $0 は、cpu セキュリティー緩和の変更を許可されていません"
 ],
 "Mitigations": [
  null,
  "緩和"
 ],
 "Version": [
  null,
  "バージョン"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS のバージョン"
 ],
 "BIOS date": [
  null,
  "BIOS の日付"
 ],
 "CPU security": [
  null,
  "CPU セキュリティー"
 ],
 "Disable simultaneous multithreading": [
  null,
  "同時マルチスレッディングの無効化"
 ],
 "Read more...": [
  null,
  "さらに読む..."
 ],
 "Save and reboot": [
  null,
  "保存および再起動"
 ],
 "CPU security toggles": [
  null,
  "CPU セキュリティートグル"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "ソフトウェアベースの回避策により、CPU セキュリティー問題を回避します。これらの緩和策にはパフォーマンスの低下という副次的な影響があります。リスクをご理解の上、これらの設定を変更してください。"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "クラス"
 ],
 "Vendor": [
  null,
  "ベンダー"
 ],
 "Slot": [
  null,
  "スロット"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "メモリーテクノロジー"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "State": [
  null,
  "状態"
 ],
 "Rank": [
  null,
  "ランク"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "メモリー情報を表示するには、管理アクセスが必要です。"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "Failed to fetch logs": [
  null,
  "ログの取得に失敗しました"
 ],
 "Clear all filters": [
  null,
  "すべてのフィルターの消去"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "現在のフィルターの組み合わせを使用して、ログを見つけることができません。"
 ],
 "No logs found": [
  null,
  "ログが見つかりません"
 ],
 "Load earlier entries": [
  null,
  "以前のエントリーのロード"
 ],
 "You may try to load older entries.": [
  null,
  "古いエントリーのロードを試行することができます。"
 ],
 "Allow running (unmask)": [
  null,
  "実行を許可 (マスク解除)"
 ],
 "Reload": [
  null,
  "再ロード"
 ],
 "Restart": [
  null,
  "再起動"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Clear 'Failed to start'": [
  null,
  "'起動に失敗' を消去"
 ],
 "Mask service": [
  null,
  "サービスのマスク"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "サービスをマスクすると、すべての依存するユニットが実行されなくなります。大きな影響が及ぶ可能性があります。このユニットをマスクすることを確認してください。"
 ],
 "Disallow running (mask)": [
  null,
  "実行を禁止 (マスク)"
 ],
 "Unpin unit": [
  null,
  "ユニットの固定を解除する"
 ],
 "Pin unit": [
  null,
  "ユニットを固定する"
 ],
 "Additional actions": [
  null,
  "その他の動作"
 ],
 "Note": [
  null,
  "注記"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "このユニットは明示的に有効にするよう設計されていません。"
 ],
 "Forbidden from running": [
  null,
  "実行が禁止されています"
 ],
 "Start service": [
  null,
  "サービスの起動"
 ],
 "Active since ": [
  null,
  "アクティブになった日時 "
 ],
 "Required by ": [
  null,
  "以下により必要 "
 ],
 "Read-only": [
  null,
  "読み取り専用"
 ],
 "Requires administration access to edit": [
  null,
  "編集には管理者アクセスが必要"
 ],
 "Automatically starts": [
  null,
  "自動起動"
 ],
 "Updating status...": [
  null,
  "ステータスを更新中..."
 ],
 "Stop and disable": [
  null,
  "停止と無効化"
 ],
 "Start and enable": [
  null,
  "起動と有効化"
 ],
 "Failed to load unit": [
  null,
  "ユニットのロードに失敗しました"
 ],
 "View all services": [
  null,
  "すべてのサービスの表示"
 ],
 "Triggers": [
  null,
  "トリガー"
 ],
 "Triggered by": [
  null,
  "トリガー元"
 ],
 "Requires": [
  null,
  "必須"
 ],
 "Requisite": [
  null,
  "必須"
 ],
 "Wants": [
  null,
  "必要"
 ],
 "Binds to": [
  null,
  "バインドする"
 ],
 "Part of": [
  null,
  "一部"
 ],
 "Required by": [
  null,
  "必要とされる"
 ],
 "Requisite of": [
  null,
  "必須の"
 ],
 "Wanted by": [
  null,
  "以下で必要"
 ],
 "Bound by": [
  null,
  "バインドされた"
 ],
 "Consists of": [
  null,
  "構成するもの"
 ],
 "Conflicts": [
  null,
  "競合"
 ],
 "Conflicted by": [
  null,
  "競合する"
 ],
 "Before": [
  null,
  "前"
 ],
 "After": [
  null,
  "後"
 ],
 "On failure": [
  null,
  "障害発生時"
 ],
 "Propagates reload to": [
  null,
  "再ロード先を伝搬"
 ],
 "Reload propagated from": [
  null,
  "伝搬元を再ロード"
 ],
 "Joins namespace of": [
  null,
  "名前空間に参加"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 を満たしていませんでした"
 ],
 "Deletion will remove the following files:": [
  null,
  "削除すると、以下のファイルが削除されます:"
 ],
 "Pinned unit": [
  null,
  "固定されたユニット"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Path": [
  null,
  "パス"
 ],
 "Listen": [
  null,
  "リッスン"
 ],
 "Container": [
  null,
  "コンテナー"
 ],
 "Condition failed": [
  null,
  "条件が満たされませんでした"
 ],
 "Show more relationships": [
  null,
  "その他の関係の表示"
 ],
 "Show relationships": [
  null,
  "関係の表示"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Timer deletion failed": [
  null,
  "タイマーの削除に失敗しました"
 ],
 "Targets": [
  null,
  "ターゲット"
 ],
 "Sockets": [
  null,
  "ソケット"
 ],
 "Timers": [
  null,
  "タイマー"
 ],
 "Paths": [
  null,
  "パス"
 ],
 "Go to $0": [
  null,
  "$0 に移動"
 ],
 "Journal entry not found": [
  null,
  "ジャーナルエントリーが見つかりません"
 ],
 "Journal entry": [
  null,
  "ジャーナルエントリー"
 ],
 "Entry at $0": [
  null,
  "$0 のエントリー"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Loading unit failed": [
  null,
  "ユニットのロードに失敗しました"
 ],
 "Service logs": [
  null,
  "サービスログ"
 ],
 "No log entries": [
  null,
  "ログエントリーなし"
 ],
 "Systemd units": [
  null,
  "システム単位"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "絞り込みの基準と一致する結果がありません。結果を見るためには全ての絞り込み基準を解除してください。"
 ],
 "Does not automatically start": [
  null,
  "自動起動しません"
 ],
 "Cannot be enabled": [
  null,
  "有効にできません"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web コンソールが制限付きアクセスモードで実行されています。"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "このツールは、システムがカーネルクラッシュダンプを書き込むように設定します。\"local\"（ディスク）、\"ssh\"、および \"nfs\" をターゲットとしてサポートしています。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 の $0 から"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 から"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 上"
 ],
 "dialog-title\u0004Domain": [
  null,
  "ドメイン"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "ドメインへの参加"
 ]
});
