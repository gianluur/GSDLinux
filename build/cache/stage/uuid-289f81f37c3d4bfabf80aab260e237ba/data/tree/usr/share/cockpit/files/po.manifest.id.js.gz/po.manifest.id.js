cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Penjelajah berkas"
 ],
 "files": [
  null,
  "berkas"
 ],
 "explorer": [
  null,
  "penjelajah"
 ],
 "filesystem": [
  null,
  "sistem berkas"
 ]
});
