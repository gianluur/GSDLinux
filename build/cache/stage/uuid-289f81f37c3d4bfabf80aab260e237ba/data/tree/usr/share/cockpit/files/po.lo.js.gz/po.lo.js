cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "ໜ້າຫຼັກ (Home)"
 ],
 "Unable to create bookmark directory": [
  null,
  "ບໍ່ສາມາດສ້າງໄດເຣັກທໍຣີບຸກມາກໄດ້"
 ],
 "Unable to save bookmark file": [
  null,
  "ບໍ່ສາມາດບັນທຶກໄຟລ໌ບຸກມາກໄດ້"
 ],
 "Remove from bookmarks": [
  null,
  "ລຶບອອກຈາກບຸກມາກ"
 ],
 "Add to bookmarks": [
  null,
  "ເພີ່ມເຂົ້າໃນບຸກມາກ"
 ],
 "Bookmarks": [
  null,
  "ບຸກມາກ"
 ],
 "Filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "Edit path": [
  null,
  "ແກ້ໄຂເສັ້ນທາງ (Path)"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "ຂະໜາດ"
 ],
 "Largest size": [
  null,
  "ຂະໜາດໃຫຍ່ທີ່ສຸດ"
 ],
 "Smallest size": [
  null,
  "ຂະໜາດນ້ອຍທີ່ສຸດ"
 ],
 "Modified": [
  null,
  "ແກ້ໄຂເມື່ອ"
 ],
 "First modified": [
  null,
  "ແກ້ໄຂຄັ້ງທຳອິດ"
 ],
 "Last modified": [
  null,
  "ແກ້ໄຂຫຼ້າສຸດ"
 ],
 "Owner": [
  null,
  "ເຈົ້າຂອງ"
 ],
 "Owner ascending": [
  null,
  "ເຈົ້າຂອງ (ນ້ອຍໄປຫາຫຼາຍ)"
 ],
 "Owner descending": [
  null,
  "ເຈົ້າຂອງ (ຫຼາຍໄປຫານ້ອຍ)"
 ],
 "Permissions": [
  null,
  "ການອະນຸຍາດ"
 ],
 "Most permissive": [
  null,
  "ການອະນຸຍາດຫຼາຍທີ່ສຸດ"
 ],
 "Least permissive": [
  null,
  "ການອະນຸຍາດໜ້ອຍທີ່ສຸດ"
 ],
 "Show keyboard shortcuts": [
  null,
  "ສະແດງຄີລັດຄີບອດ"
 ],
 "Filter directory": [
  null,
  "ຕອງໄດເຣັກທໍຣີ"
 ],
 "Display as a list": [
  null,
  "ສະແດງເປັນລາຍການ"
 ],
 "Display as a grid": [
  null,
  "ສະແດງເປັນຕາຕະລາງ"
 ],
 "Sort": [
  null,
  "ຈັດລຽງ"
 ],
 "Hide hidden items": [
  null,
  "ເຊື່ອງລາຍການທີ່ຖືກເຊື່ອງ"
 ],
 "Show hidden items": [
  null,
  "ສະແດງລາຍການທີ່ຖືກເຊື່ອງ"
 ],
 "$0 files": [
  null,
  "$0 ໄຟລ໌"
 ],
 "Uploaded as $0, $1": [
  null,
  "ອັບໂຫຼດເປັນ $0, $1"
 ],
 "Replace file $0?": [
  null,
  "ແທນທີ່ໄຟລ໌ $0 ບໍ່?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "ມີໄຟລ໌ທີ່ມີຊື່ດຽວກັນນີ້ຢູ່ແລ້ວໃນ \"$0\". ການແທນທີ່ມັນຈະເປັນການຂຽນທັບເນື້ອໃນຂອງມັນ."
 ],
 "New file": [
  null,
  "ໄຟລ໌ໃໝ່"
 ],
 "Original file on server": [
  null,
  "ໄຟລ໌ເດີມໃນເຊີເວີ"
 ],
 "Apply this action to all conflicting files": [
  null,
  "ນຳໃຊ້ການດຳເນີນການນີ້ກັບທຸກໄຟລ໌ທີ່ມີຂໍ້ຂັດແຍ່ງ"
 ],
 "Replace": [
  null,
  "ແທນທີ່"
 ],
 "Keep original": [
  null,
  "ຮັກສາແບບເດີມໄວ້"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Failed": [
  null,
  "ຫຼົ້ມເຫຼວ"
 ],
 "Upload error": [
  null,
  "ການອັບໂຫຼດຜິດພາດ"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "ບໍ່ສາມາດຍ້າຍໄຟລ໌ທີ່ອັບໂຫຼດໄປຫາປາຍທາງສຸດທ້າຍໄດ້"
 ],
 "Cancelled": [
  null,
  "ຍົກເລີກແລ້ວ"
 ],
 "Cancelled upload of $0": [
  null,
  "ຍົກເລີກການອັບໂຫຼດຂອງ $0 ແລ້ວ"
 ],
 "File uploaded": [
  null,
  "ອັບໂຫຼດໄຟລ໌ສຳເລັດແລ້ວ"
 ],
 "Files uploaded": [
  null,
  "ອັບໂຫຼດໄຟລ໌ສຳເລັດແລ້ວ"
 ],
 "Change permissions": [
  null,
  "ປ່ຽນການອະນຸຍາດ"
 ],
 "Uploads": [
  null,
  "ລາຍການອັບໂຫຼດ"
 ],
 "Cancel upload of $0": [
  null,
  "ຍົກເລີກການອັບໂຫຼດຂອງ $0"
 ],
 "Upload $0% completed": [
  null,
  "ອັບໂຫຼດ $0% ສຳເລັດແລ້ວ"
 ],
 "Upload": [
  null,
  "ອັບໂຫຼດ"
 ],
 "None": [
  null,
  "ບໍ່ມີ"
 ],
 "Execute-only": [
  null,
  "ປະຕິບັດການເທົ່ານັ້ນ (Execute-only)"
 ],
 "Write-only": [
  null,
  "ຂຽນຢ່າງດຽວ"
 ],
 "Write and execute": [
  null,
  "ຂຽນ ແລະ ປະຕິບັດການ"
 ],
 "Read-only": [
  null,
  "ອ່ານຢ່າງດຽວ"
 ],
 "Read and execute": [
  null,
  "ອ່ານ ແລະ ປະຕິບັດການ"
 ],
 "Read and write": [
  null,
  "ອ່ານ ແລະ ຂຽນ"
 ],
 "Read, write, and execute": [
  null,
  "ອ່ານ, ຂຽນ, ແລະ ປະຕິບັດການ"
 ],
 "Block device": [
  null,
  "ອຸປະກອນບລັອກ"
 ],
 "Character device": [
  null,
  "ອຸປະກອນຕົວອັກສອນ"
 ],
 "Directory": [
  null,
  "ໄດເຣັກທໍຣີ"
 ],
 "Named pipe": [
  null,
  "Named pipe"
 ],
 "Symbolic link": [
  null,
  "ລິ້ງສັນຍະລັກ (Symbolic link)"
 ],
 "Regular file": [
  null,
  "ໄຟລ໌ປົກກະຕິ"
 ],
 "Socket": [
  null,
  "ຊັອກເກັດ (Socket)"
 ],
 "Name cannot be empty": [
  null,
  "ຊື່ບໍ່ສາມາດວ່າງເປົ່າໄດ້"
 ],
 "Name too long": [
  null,
  "ຊື່ຍາວເກີນໄປ"
 ],
 "Name cannot include a /": [
  null,
  "ຊື່ບໍ່ສາມາດມີເຄື່ອງໝາຍ /"
 ],
 "Filename is the same as original name": [
  null,
  "ຊື່ໄຟລ໌ຄືກັນກັບຊື່ເດີມ"
 ],
 "Directory with the same name exists": [
  null,
  "ມີໄດເຣັກທໍຣີທີ່ມີຊື່ດຽວກັນນີ້ຢູ່ແລ້ວ"
 ],
 "File exists": [
  null,
  "ໄຟລ໌ມີຢູ່ແລ້ວ"
 ],
 "Pasting failed": [
  null,
  "ການວາງຫຼົ້ມເຫຼວ"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" ມີຢູ່ແລ້ວ, ຈະບໍ່ວາງທັບ."
 ],
 "Paste": [
  null,
  "ວາງ (Paste)"
 ],
 "Create directory": [
  null,
  "ສ້າງໄດເຣັກທໍຣີ"
 ],
 "Create file": [
  null,
  "ສ້າງໄຟລ໌"
 ],
 "Edit permissions": [
  null,
  "ແກ້ໄຂການອະນຸຍາດ"
 ],
 "Open in terminal": [
  null,
  "ເປີດໃນເທີມິນໍ (Terminal)"
 ],
 "Open text file": [
  null,
  "ເປີດໄຟລ໌ຂໍ້ຄວາມ"
 ],
 "Copy": [
  null,
  "ກັອບປີ້"
 ],
 "Rename": [
  null,
  "ປ່ຽນຊື່"
 ],
 "Delete": [
  null,
  "ລຶບ"
 ],
 "Download": [
  null,
  "ດາວໂຫຼດ"
 ],
 "Create link": [
  null,
  "ສ້າງລິ້ງ"
 ],
 "Drop files to upload": [
  null,
  "ວາງໄຟລ໌ເພື່ອອັບໂຫຼດ"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "ບໍ່ສາມາດວາງໄຟລ໌ໄດ້, ກຳລັງມີການອັບໂຫຼດອື່ນດຳເນີນການຢູ່"
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Go up a directory": [
  null,
  "ຂຶ້ນໄປໜຶ່ງໄດເຣັກທໍຣີ"
 ],
 "Go back": [
  null,
  "ກັບຄືນ"
 ],
 "Go forward": [
  null,
  "ໄປຂ້າງໜ້າ"
 ],
 "Activate selected item, enter directory": [
  null,
  "ເປີດໃຊ້ລາຍການທີ່ເລືອກ, ເຂົ້າສູ່ໄດເຣັກທໍຣີ"
 ],
 "Rename selected file or directory": [
  null,
  "ປ່ຽນຊື່ໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີທີ່ເລືອກ"
 ],
 "Create new directory": [
  null,
  "ສ້າງໄດເຣັກທໍຣີໃໝ່"
 ],
 "Copy selected file or directory": [
  null,
  "ກັອບປີ້ໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີທີ່ເລືອກ"
 ],
 "Paste file or directory": [
  null,
  "ວາງໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີ"
 ],
 "Select all": [
  null,
  "ເລືອກທັງໝົດ"
 ],
 "Save current file": [
  null,
  ""
 ],
 "Close editor": [
  null,
  ""
 ],
 "Keyboard shortcuts": [
  null,
  "ຄີລັດຄີບອດ"
 ],
 "Navigation": [
  null,
  "ການນຳທາງ"
 ],
 "Editing": [
  null,
  "ກຳລັງແກ້ໄຂ"
 ],
 "Force delete $0 items": [
  null,
  "ບັງຄັບລຶບ $0 ລາຍການ"
 ],
 "Delete $0 items?": [
  null,
  "ລຶບ $0 ລາຍການບໍ່?"
 ],
 "Force delete file $0?": [
  null,
  "ບັງຄັບລຶບໄຟລ໌ $0 ບໍ່?"
 ],
 "Delete file $0?": [
  null,
  "ລຶບໄຟລ໌ $0 ບໍ່?"
 ],
 "Force delete link $0?": [
  null,
  "ບັງຄັບລຶບລິ້ງ $0 ບໍ່?"
 ],
 "Delete link $0?": [
  null,
  "ລຶບລິ້ງ $0 ບໍ່?"
 ],
 "Force delete directory $0?": [
  null,
  "ບັງຄັບລຶບໄດເຣັກທໍຣີ $0 ບໍ່?"
 ],
 "Delete directory $0?": [
  null,
  "ລຶບໄດເຣັກທໍຣີ $0 ບໍ່?"
 ],
 "Force delete $0": [
  null,
  "ບັງຄັບລຶບ $0"
 ],
 "Delete $0?": [
  null,
  "ລຶບ $0 ບໍ່?"
 ],
 "No access": [
  null,
  "ບໍ່ມີສິດເຂົ້າເຖິງ"
 ],
 "Missing type": [
  null,
  "ບໍ່ພົບປະເພດ"
 ],
 "Collapse": [
  null,
  "ຍໍ້ເຂົ້າ"
 ],
 "Show all files": [
  null,
  "ສະແດງໄຟລ໌ທັງໝົດ"
 ],
 "$0 permissions": [
  null,
  "ການອະນຸຍາດ $0"
 ],
 "Permissions for $0 files": [
  null,
  "ການອະນຸຍາດສຳລັບ $0 ໄຟລ໌"
 ],
 "Ownership": [
  null,
  "ຄວາມເປັນເຈົ້າຂອງ"
 ],
 "Group": [
  null,
  "ກຸ່ມ"
 ],
 "Access": [
  null,
  "ການເຂົ້າເຖິງ"
 ],
 "Owner access": [
  null,
  "ການເຂົ້າເຖິງຂອງເຈົ້າຂອງ"
 ],
 "Group access": [
  null,
  "ການເຂົ້າເຖິງຂອງກຸ່ມ"
 ],
 "Others access": [
  null,
  "ການເຂົ້າເຖິງຂອງຜູ້ອື່ນ"
 ],
 "Security context": [
  null,
  "ບໍລິບົດຄວາມປອດໄພ"
 ],
 "Set executable as program": [
  null,
  "ຕັ້ງຄ່າໃຫ້ປະຕິບັດການເປັນໂປຣແກຣມ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Change permissions for enclosed files": [
  null,
  "ປ່ຽນການອະນຸຍາດສຳລັບໄຟລ໌ທີ່ຢູ່ພາຍໃນ"
 ],
 "(original owner)": [
  null,
  "(ເຈົ້າຂອງເດີມ)"
 ],
 "keep original owners": [
  null,
  "ຮັກສາເຈົ້າຂອງເດີມໄວ້"
 ],
 "Paste as owner": [
  null,
  "ວາງໃນຖານະເຈົ້າຂອງ"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "ໄຟລ໌ທີ່ກຳລັງວາງມີເຈົ້າຂອງທີ່ແຕກຕ່າງກັນ. ໂດຍຄ່າເລີ່ມຕົ້ນ, ຄວາມເປັນເຈົ້າຂອງຈະຖືກປ່ຽນໃຫ້ກົງກັບໄດເຣັກທໍຣີປາຍທາງ."
 ],
 "New owner": [
  null,
  "ເຈົ້າຂອງໃໝ່"
 ],
 "Overwrite": [
  null,
  "ຂຽນທັບ"
 ],
 "New filename": [
  null,
  "ຊື່ໄຟລ໌ໃໝ່"
 ],
 "New name": [
  null,
  "ຊື່ໃໝ່"
 ],
 "Rename $0?": [
  null,
  "ປ່ຽນຊື່ $0 ບໍ່?"
 ],
 "link to $0": [
  null,
  "ລິ້ງໄປຫາ $0"
 ],
 "Create link to $0": [
  null,
  "ສ້າງລິ້ງໄປຫາ $0"
 ],
 "Target": [
  null,
  "ເປົ້າໝາຍ"
 ],
 "Symlink name": [
  null,
  "ຊື່ Symlink"
 ],
 "Type": [
  null,
  "ປະເພດ"
 ],
 "Absolute vs. Relative": [
  null,
  "ແບບສົມບູນ (Absolute) ທຽບກັບ ແບບສຳພັດ (Relative)"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Symlink ແບບສົມບູນ (Absolute) ແມ່ນເໝາະສົມເມື່ອອ້າງອີງເຖິງໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີທີ່ຈະບໍ່ມີການຍ້າຍ, ເຊັ່ນ ໄຟລ໌ລະບົບ."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Symlink ແບບສຳພັດ (Relative) ແມ່ນມີປະໂຫຍດເມື່ອທັງ symlink ແລະ ເປົ້າໝາຍອາດຈະຍ້າຍໄປພ້ອມກັນ, ເຊັ່ນ ເມື່ອມີການປ່ຽນຊື່ ຫຼື ຍ້າຍໄດເຣັກທໍຣີແມ່."
 ],
 "Absolute": [
  null,
  "ສົມບູນ (Absolute)"
 ],
 "Relative": [
  null,
  "ແບບສຳພັດ (Relative)"
 ],
 "The file has been removed on disk": [
  null,
  "ໄຟລ໌ຖືກລຶບອອກຈາກດິສກ໌ແລ້ວ"
 ],
 "The existing file changed unexpectedly": [
  null,
  "ໄຟລ໌ທີ່ມີຢູ່ໄດ້ປ່ຽນແປງໂດຍບໍ່ຄາດຄິດ"
 ],
 "Edit $0": [
  null,
  "ແກ້ໄຂ $0"
 ],
 "View $0": [
  null,
  "ເບິ່ງ $0"
 ],
 "The file has changed on disk": [
  null,
  "ໄຟລ໌ມີການປ່ຽນແປງໃນດິສກ໌"
 ],
 "Reload": [
  null,
  "ໂຫລດໃໝ່"
 ],
 "Ignore": [
  null,
  "ລະເວັ້ນ"
 ],
 "Save": [
  null,
  "ບັນທຶກ"
 ],
 "Save changes?": [
  null,
  "ບັນທຶກການປ່ຽນແປງບໍ່?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "ໄຟລ໌ຖືກລຶບໄປຫຼັງຈາກທີ່ມັນຖືກເປີດ, ການບັນທຶກຈະເປັນການສ້າງມັນຄືນໃໝ່."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "ໄຟລ໌ມີການປ່ຽນແປງໃນດິສກ໌ລະຫວ່າງຕອນທີ່ມັນຖືກເປີດ ແລະ ຕອນນີ້"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 ມີການປ່ຽນແປງທີ່ຍັງບໍ່ທັນໄດ້ບັນທຶກ ເຊິ່ງຈະສູນຫາຍໄປຢ່າງຖາວອນຫາກຖິ້ມໄປ."
 ],
 "Discard": [
  null,
  "ຖິ້ມໄປ"
 ],
 "File name": [
  null,
  "ຊື່ໄຟລ໌"
 ],
 "Create": [
  null,
  "ສ້າງ"
 ],
 "Cannot create file in current directory": [
  null,
  "ບໍ່ສາມາດສ້າງໄຟລ໌ໃນໄດເຣັກທໍຣີປັດຈຸບັນໄດ້"
 ],
 "Permission denied": [
  null,
  "ການອະນຸຍາດຖືກປະຕິເສດ"
 ],
 "Directory name cannot be empty": [
  null,
  "ຊື່ໄດເຣັກທໍຣີບໍ່ສາມາດວ່າງເປົ່າໄດ້"
 ],
 "Directory name too long": [
  null,
  "ຊື່ໄດເຣັກທໍຣີຍາວເກີນໄປ"
 ],
 "Directory name cannot include a /": [
  null,
  "ຊື່ໄດເຣັກທໍຣີບໍ່ສາມາດມີເຄື່ອງໝາຍ /"
 ],
 "Directory name": [
  null,
  "ຊື່ໄດເຣັກທໍຣີ"
 ],
 "Directory owner": [
  null,
  "ເຈົ້າຂອງໄດເຣັກທໍຣີ"
 ],
 "No matching results": [
  null,
  "ບໍ່ພົບຜົນລັບທີ່ກົງກັນ"
 ],
 "Clear filter": [
  null,
  "ລຶບຕົວຕອງ"
 ],
 "Directory is empty": [
  null,
  "ໄດເຣັກທໍຣີວ່າງເປົ່າ"
 ],
 "$0 item is hidden": [
  null,
  "$0 ລາຍການຖືກເຊື່ອງໄວ້"
 ],
 "Folder": [
  null,
  "ໂຟນເດີ"
 ],
 "File": [
  null,
  "ໄຟລ໌"
 ],
 "Others": [
  null,
  "ອື່ນໆ"
 ],
 "$0 files selected": [
  null,
  "ເລືອກແລ້ວ $0 ໄຟລ໌"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "ໄດເຣັກທໍຣີປະກອບມີ $0 ໄດເຣັກທໍຣີ, $1 ໄຟລ໌"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "ໄດເຣັກທໍຣີປະກອບມີ $0 ໄດເຣັກທໍຣີ, $1 ໄຟລ໌, ເຊື່ອງໄວ້ $2"
 ],
 "User": [
  null,
  "ຜູ້ໃຊ້"
 ]
});
