cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Services"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "network": [
  null,
  "réseau"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "Interface"
 ],
 "bridge": [
  null,
  "pont"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "agrégation"
 ],
 "team": [
  null,
  "équipe"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "pare-feu"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zone"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "Managing networking bonds": [
  null,
  "Gestion des agrégations de réseaux"
 ],
 "Managing networking teams": [
  null,
  "Gestion du réseau"
 ],
 "Managing networking bridges": [
  null,
  "Gérer les ponts de mise en réseau"
 ],
 "Managing VLANs": [
  null,
  "Gestion des réseaux locaux virtuels (VLAN)"
 ],
 "Managing firewall": [
  null,
  "Gestion du pare-feu"
 ]
});
