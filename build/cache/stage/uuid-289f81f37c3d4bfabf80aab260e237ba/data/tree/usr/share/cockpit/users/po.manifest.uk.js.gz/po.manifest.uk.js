cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Accounts": [
  null,
  "Облікові записи"
 ],
 "user": [
  null,
  "користувач"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "пароль"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "користувач"
 ],
 "login": [
  null,
  "вхід"
 ],
 "access": [
  null,
  "доступ"
 ],
 "roles": [
  null,
  "ролі"
 ],
 "keys": [
  null,
  "ключі"
 ],
 "Managing user accounts": [
  null,
  "Керування обліковими записами користувачів"
 ]
});
