cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "Errore $0",
  "Errori $0"
 ],
 "$0 installation": [
  null,
  "Installazione $0"
 ],
 "$0 installer": [
  null,
  "$0 installer"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 è una partizione estesa MBR che contiene partizioni logiche. La rimozione di tutte le partizioni logiche rimuoverà automaticamente anche la partizione estesa."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "È richiesto $0, ma è disponibile solo $1."
 ],
 "$0 warning": [
  null,
  "$0 avviso",
  "$0 avvisi"
 ],
 "$0 will be deleted": [
  null,
  "$0 verrà eliminato"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Il file system '$0' non può trovarsi su un dispositivo a blocchi crittografato"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' deve essere assegnato a $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' dev'essere su un dispositivo formattato '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' deve trovarsi in una partizione di sistema EFI (ESP). La partizione selezionata utilizza un file system FAT, ma non è contrassegnata come ESP. Imposta il tipo di partizione su EFI System e attiva il flag esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Trovata partizione '$0' sul dispositivo MDRAID $1. Le partizioni del bootloader sui dispositivi MDRAID non sono supportate."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Un account utente standard con accesso amministratore per apportare modifiche a tutto il sistema."
 ],
 "Abort installation": [
  null,
  "Annulla installazione"
 ],
 "About": [
  null,
  "Informazioni"
 ],
 "Account": [
  null,
  "Account"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Add another server...": [
  null,
  "Aggiungi un altro server..."
 ],
 "Add mount": [
  null,
  "Aggiungi punto di mount"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Componenti aggiuntivi per l’ambiente scelto"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Componenti aggiuntivi non specifici per il tuo ambiente"
 ],
 "Additional languages": [
  null,
  "Lingue aggiuntive"
 ],
 "Additional software for the selected environment": [
  null,
  "Software aggiuntivo per l'ambiente selezionato"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Tutte le modifiche apportate nell'editor di archiviazione hanno effetto immediato."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Tutti i dispositivi che usano questa passphrase verranno sbloccati"
 ],
 "Anaconda Web UI": [
  null,
  "Interfaccia utente Web di Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Pagina web del progetto Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Applicare l'assegnazione del punto di mount e procedi con l'installazione"
 ],
 "Applying changes...": [
  null,
  "Applica modifiche..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Assegnare partizioni ai punti di montaggio. Utile per layout personalizzati preconfigurati."
 ],
 "Automatic log file upload": [
  null,
  "Caricamento automatico di file di log"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Imposta automaticamente data e ora, utilizzando i time server"
 ],
 "Automatically set timezone": [
  null,
  "Imposta automaticamente il fuso orario"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Spazio libero disponibile: $0. L'installazione richiede: $1."
 ],
 "Back": [
  null,
  "Indietro"
 ],
 "Base environment": [
  null,
  "Ambiente base"
 ],
 "Brief description of the issue": [
  null,
  "Breve descrizione del problema"
 ],
 "Bug report details": [
  null,
  "Dettagli del report del bug"
 ],
 "Bugzilla API key": [
  null,
  "Chiave API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Continuando a usare questo software, capisci e accetti i rischi associati al software pre-rilasciascio, che intendi usarlo solo per scopi di test e sviluppo e sei disposto a segnalare qualsiasi bug o problema per migliorare questo lavoro."
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change destination": [
  null,
  "Cambia destinazione"
 ],
 "Change hostname": [
  null,
  "Cambia nome host"
 ],
 "Change partition layout": [
  null,
  "Modifica il layout della partizione"
 ],
 "Change system keyboard layout": [
  null,
  "Cambia layout della tastiera di sistema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Le modifiche apportate qui avranno effetto immediato sul sistema. Non è possibile annullare l'operazione."
 ],
 "Checking installation configuration...": [
  null,
  "Controllo configurazione dell'installazione..."
 ],
 "Checking storage configuration": [
  null,
  "Controllo della configurazione dello storage"
 ],
 "Clear search": [
  null,
  "Cancella Ricerca"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Fare nuovamente clic su \"Avanti\" per procedere nonostante questi avvisi."
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Close storage editor": [
  null,
  "Chiudi editor dello storage"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "L'archiviazione del Cruscotto non ha fornito la passphrase per sbloccare il dispositivo crittografato."
 ],
 "Completed": [
  null,
  "Completato"
 ],
 "Configuration is incomplete": [
  null,
  "Configurazione incompleta"
 ],
 "Configure NTP servers": [
  null,
  "Configura server NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurare server NTP personalizzati"
 ],
 "Configure network": [
  null,
  "Configura rete"
 ],
 "Configure storage": [
  null,
  "Configura storage"
 ],
 "Configure storage again": [
  null,
  "Configurare di nuovo l'archiviazione"
 ],
 "Confirm passphrase": [
  null,
  "Conferma la password"
 ],
 "Continue": [
  null,
  "Continua"
 ],
 "Continue installation": [
  null,
  "Continua l'installazione"
 ],
 "Continue installation?": [
  null,
  "Continua l'installazione?"
 ],
 "Continue with installation": [
  null,
  "Continua con l'installazione"
 ],
 "Correct these issues before continuing.": [
  null,
  "Completare tutte le sezioni prima di continuare."
 ],
 "Create Account": [
  null,
  "Creare Account"
 ],
 "Create account": [
  null,
  "Creare account"
 ],
 "Currently installed: $0": [
  null,
  "Attualmente installato: $0"
 ],
 "Custom": [
  null,
  "Personalizzata"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data e ora"
 ],
 "Delete partition": [
  null,
  "Elimina partizione"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "L'eliminazione di alcune partizioni potrebbe impedire l'avvio di $0: $1"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Destination": [
  null,
  "Destinazione"
 ],
 "Destination is encrypted": [
  null,
  "La destinazione è crittografata"
 ],
 "Detailed description of the issue": [
  null,
  "Descrizione dettagliata del problema"
 ],
 "Detected valid storage layout:": [
  null,
  "Rilevato layout di archiviazione valido:"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Duplicate device.": [
  null,
  "Dispositivo duplicato."
 ],
 "Duplicate mount point.": [
  null,
  "Punto di mount duplicato."
 ],
 "Enable root account": [
  null,
  "_Abilita l'account di root"
 ],
 "Encrypt my data": [
  null,
  "Cifra i miei dati"
 ],
 "Encrypted": [
  null,
  "Crittografato"
 ],
 "Encryption": [
  null,
  "Cifratura"
 ],
 "Enter PIN": [
  null,
  "Inserisci PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Inserisci il PIN per accedere al programma di installazione"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Inserisci la tua chiave API di Bugzilla per creare un report di bug. Potrai rivedere e modificare i dettagli del bug nel prossimo passo."
 ],
 "Environment": [
  null,
  "Environment"
 ],
 "Erase data and install": [
  null,
  "Cancella i dati e installa"
 ],
 "Error details": [
  null,
  "Dettagli dell'errore"
 ],
 "Exit to live desktop": [
  null,
  "Esci sul desktop live"
 ],
 "Extended partition": [
  null,
  "Partizione estesa"
 ],
 "Failed to report issue": [
  null,
  "Invio del problema non riuscito"
 ],
 "Failed to save layouts": [
  null,
  "Impossibile salvare i layout"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux richiede almeno $0 di spazio su disco."
 ],
 "Finalization": [
  null,
  "Finalizzazione"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizzazione: La configurazione del sistema è completa. Il completamento dell'installazione può richiedere alcuni istanti."
 ],
 "Find layout": [
  null,
  "Trova disposizione"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Per una maggiore sicurezza, evita di utilizzare direttamente l'account root. Utilizza invece l'account locale sopra indicato per gestire il sistema."
 ],
 "Full name": [
  null,
  "Nome completo"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Il nome completo non può contenere il carattere due punti"
 ],
 "Helper text": [
  null,
  "Testo di aiuto"
 ],
 "Hide API key": [
  null,
  "Nascondi la chiave API"
 ],
 "Hide PIN": [
  null,
  "Nascondi PIN"
 ],
 "Hide confirmed password": [
  null,
  "Nascondi la password confermata"
 ],
 "Hide passphrase": [
  null,
  "Nascondi la password"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "Hostname": [
  null,
  "Nome host"
 ],
 "How would you like to install?": [
  null,
  "Come vuoi effettuare l'installazione?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Capisco che tutti i dati esistenti verranno cancellati",
  "Capisco che tutti i dati esistenti verranno cancellati"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Capisco che alcuni dati esistenti verranno cancellati"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Capisco che alcune partizioni verranno modificate"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Se vuoto, il nome host sarà temporaneo e impostato dalle informazioni di rete."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Se nessuna delle opzioni precedenti è applicabile, utilizza l'editor di archiviazione per creare un partizionamento personalizzato prima di procedere."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Se stai configurando le partizioni è richiesto quanto segue:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Se non acconsenti al caricamento automatico dei file di log, puoi invece $0. La segnalazione manuale ti permette di rivedere e allegare selettivamente tu stesso i file di log."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Se non capite o accettate i rischi, uscite da questo programma."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Se il tuo problema corrisponde a uno dei bug sopra elencati, puoi aprirlo e aggiungere le tue informazioni lì invece di creare una segnalazione duplicata."
 ],
 "In progress": [
  null,
  "Avanzamento"
 ],
 "Initializing...": [
  null,
  "Inizializzazione..."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Installation failed": [
  null,
  "Installazione fallita"
 ],
 "Installation method": [
  null,
  "Metodo di installazione"
 ],
 "Installation of the system failed": [
  null,
  "L'installazione del sistema non è riuscita"
 ],
 "Installation of the system failed: $0": [
  null,
  "Installazione del sistema fallita: $0"
 ],
 "Installation type": [
  null,
  "Tipo di installazione"
 ],
 "Installing": [
  null,
  "Installazione in corso"
 ],
 "Insufficient disk space": [
  null,
  "Spazio su disco insufficiente"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "PIN non valido. Riprova."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Rilevata configurazione RAID non valida. Se il tuo array RAID è creato direttamente sui dischi, è necessario creare una tabella delle partizioni sull'array. Se il tuo array RAID è creato su partizioni, deve contenere un singolo filesystem o formato (ad esempio, LVM PV). Eventuali partizioni esistenti su questo array verranno ignorate."
 ],
 "Invalid hostname": [
  null,
  "Nome host non valido"
 ],
 "Jump to first incomplete step": [
  null,
  "Passa a step non completato"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Mantieni il layout corrente del disco e utilizza lo spazio disponibile per eseguire il dual-boot con un altro sistema operativo."
 ],
 "Keyboard": [
  null,
  "Tastiera"
 ],
 "Keyboard layout during boot": [
  null,
  "Layout della tastiera durante l'avvio"
 ],
 "Language": [
  null,
  "Lingua"
 ],
 "Launch storage editor": [
  null,
  "Avvia l'editor di archiviazione"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Ulteriori informazioni sull’accesso limitato nella configurazione"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Lasciare vuoti entrambi i campi della passphrase per utilizzare una password vuota."
 ],
 "Location": [
  null,
  "Posizione"
 ],
 "Locked devices": [
  null,
  "Dispositivi bloccati"
 ],
 "Log in": [
  null,
  "Log in"
 ],
 "Make current": [
  null,
  "Rendi attuale"
 ],
 "Manual disk configuration": [
  null,
  "Configurazione manuale del disco"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configurazione manuale del disco: definizione del punto di mount"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Può contenere lettere, numeri e trattini."
 ],
 "May need more free space": [
  null,
  "Potrebbe essere necessario più spazio libero"
 ],
 "Medium": [
  null,
  "Media"
 ],
 "Minimum of $0 required": [
  null,
  "Minimo richiesto $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Mancata corrispondenza tra la riformattazione del dispositivo padre e del dispositivo figlio."
 ],
 "Mount point": [
  null,
  "Punto di mount"
 ],
 "Mount point assignment": [
  null,
  "Assegnazione del punto di mount"
 ],
 "Move down": [
  null,
  "Sposta in basso"
 ],
 "Move up": [
  null,
  "Sposta in alto"
 ],
 "Must be at least $0 characters": [
  null,
  "Deve essere di almeno $0 caratteri"
 ],
 "My issue is different, continue": [
  null,
  "Il mio problema è diverso, continua"
 ],
 "NTP Servers": [
  null,
  "Server NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Needs at least $0": [
  null,
  "Necessita di almeno $0"
 ],
 "Network": [
  null,
  "Rete"
 ],
 "Network Configuration": [
  null,
  "Test configurazione"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rete non disponibile. Configura la rete dal menu nella barra superiore per segnalare il problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rete non disponibile. Configura la rete per segnalare il problema."
 ],
 "Network plugin failed": [
  null,
  "Plugin di rete fallito"
 ],
 "Next": [
  null,
  "Avanti"
 ],
 "No devices": [
  null,
  "Nessun dispositivo"
 ],
 "No disks available": [
  null,
  "Nessun disco disponibile"
 ],
 "No disks selected": [
  null,
  "Nessun disco selezionato"
 ],
 "No keyboard layouts selected": [
  null,
  "Nessuna disposizione di tastiera selezionata"
 ],
 "No layouts selected yet": [
  null,
  "Nessun layout selezionato ancora"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Non è possibile ottenere una mappatura tasti VConsole valida per i layout di tastiera selezionati. Selezionare un layout di tastiera diverso."
 ],
 "Not enough available free space": [
  null,
  "Non c'è abbastanza spazio libero disponibile"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Spazio insufficiente sui dischi selezionati."
 ],
 "Not enough space on selected disks.": [
  null,
  "Spazio insufficiente sui dischi selezionati."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Avviso: Questo è un software pre-rilasciascio che è inteso solo per scopi di sviluppo e test. NON utilizzare questo software per qualsiasi lavoro critico o per ambienti di produzione."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Apri modulo di inserimento bug Bugzilla"
 ],
 "Operating system": [
  null,
  "Sistema Operativo"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Other keyboards": [
  null,
  "Altre tastiere"
 ],
 "Partitions (advanced)": [
  null,
  "Partizioni (avanzate)"
 ],
 "Passphrase": [
  null,
  "Password"
 ],
 "Passphrase did not match any locked device": [
  null,
  "La passphrase non corrisponde a nessun dispositivo bloccato"
 ],
 "Passphrases must match": [
  null,
  "Le password devono corrispondere"
 ],
 "Pending": [
  null,
  "In attesa"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Per favore, allega il file di log $0 al problema."
 ],
 "Please enter a PIN": [
  null,
  "Inserisci un PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Seleziona almeno un disco per continuare"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Trovati potenziali bug duplicati"
 ],
 "Powered by Anaconda": [
  null,
  "Powered by Anaconda"
 ],
 "Pre-release": [
  null,
  "pre-rilascio"
 ],
 "Prefer to report manually? $0": [
  null,
  "Preferisci segnalare manualmente? $0"
 ],
 "Proceed with installation": [
  null,
  "Procedere con l'installazione"
 ],
 "Quit": [
  null,
  "Abbandona"
 ],
 "Quit installer?": [
  null,
  "Abbandona il programma di installazione?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Lettura delle informazioni sul sistema operativo fallita."
 ],
 "Reading information about the computer failed.": [
  null,
  "La lettura delle informazioni sul computer non è riuscita."
 ],
 "Reading installer configuration failed.": [
  null,
  "Lettura della configurazione del programma di installazione fallita."
 ],
 "Reading installer version information failed.": [
  null,
  "Lettura delle informazioni sulla versione del programma di installazione fallita."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Il nome host reale può contenere solo caratteri, cifre, trattini (non l'inizio o la fine di un carattere) e punti"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Il nome host reale deve contenere al massimo 64 caratteri"
 ],
 "Reboot": [
  null,
  "Riavvio"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Riavvia in Windows per ridimensionare le partizioni crittografate con BitLocker. Lascia almeno $0 di spazio libero disponibile per l'installazione."
 ],
 "Reboot system?": [
  null,
  "Riavvia il sistema?"
 ],
 "Reclaim additional space": [
  null,
  "Recupera spazio aggiuntivo"
 ],
 "Reclaim space": [
  null,
  "_Recupera spazio"
 ],
 "Reclaim space (required)": [
  null,
  "Recupera spazio (richiesto)"
 ],
 "Recommended": [
  null,
  "raccomandato"
 ],
 "Recommended partitions:": [
  null,
  "Partizioni consigliate:"
 ],
 "Reformat": [
  null,
  "Riformattare"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstalla Fedora"
 ],
 "Remove": [
  null,
  "Rimuovi"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Rimuovi tutte le partizioni sui dispositivi selezionati, inclusi i sistemi operativi esistenti."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Rimuovi o ridimensiona i filesystem esistenti per liberare spazio per l'installazione."
 ],
 "Remove server": [
  null,
  "Rimuovi server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "La rimozione di un filesystem eliminerà permanentemente tutti i dati che contiene. Il ridimensionamento di una partizione può liberare spazio inutilizzato, ma non è privo di rischi. Assicurati di avere backup di tutto ciò che è importante prima di recuperare spazio."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Sostituisci l'installazione corrente, ma mantieni i file nella home."
 ],
 "Report Issue": [
  null,
  "Segnala il Problema"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Segnala un problema o fornisci feedback aprendo il modulo di inserimento bug Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Segnala il problema"
 ],
 "Reporting issue...": [
  null,
  "Segnala un problema..."
 ],
 "Required": [
  null,
  "Richiesto"
 ],
 "Requirements": [
  null,
  "Requisiti"
 ],
 "Rescan devices": [
  null,
  "riscansiona i device"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Nuova scansione dei dischi fallita."
 ],
 "Resize": [
  null,
  "Ridimensiona"
 ],
 "Resize partition": [
  null,
  "Ridimensiona la partizione"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Ridimensionare le seguenti partizioni da $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Limita l'accesso al report"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Limita il report al gruppo $0. $1"
 ],
 "Return to installation": [
  null,
  "Torna all'installazione"
 ],
 "Return to storage editor": [
  null,
  "Torna all'editor di archiviazione"
 ],
 "Review and install": [
  null,
  "Verifica e installa"
 ],
 "Root account has been configured": [
  null,
  "L'account root è stato configurato"
 ],
 "Root account is enabled": [
  null,
  "L'account root è abilitato"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "L'account root è abilitato, ma non è stato configurato alcun account utente"
 ],
 "Root password has been set.": [
  null,
  "La password di root è stata impostata."
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scansiona il codice QR con il tuo telefono o visita:"
 ],
 "Search for a language": [
  null,
  "Cerca una lingua"
 ],
 "Search for additional software": [
  null,
  "Cerca software aggiuntivo"
 ],
 "Search for an environment": [
  null,
  "Cerca un ambiente"
 ],
 "Search keyboard layout": [
  null,
  "Cerca il layout della tastiera"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Proteggi i tuoi dati utilizzando la crittografia basata su disco. Si applica solo alle nuove partizioni"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "Select a device": [
  null,
  "Seleziona un dispositivo"
 ],
 "Select city": [
  null,
  "Seleziona città"
 ],
 "Select destination": [
  null,
  "Seleziona la destinazione"
 ],
 "Select region": [
  null,
  "Seleziona regione"
 ],
 "Selected (top = current)": [
  null,
  "Selezionato (in alto = corrente)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Il formato \"$0\" del dispositivo selezionato non può essere riformattato."
 ],
 "Send us feedback on your installation": [
  null,
  "Inviaci un feedback sulla tua installazione"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Il server non è raggiungibile"
 ],
 "Set custom hostname": [
  null,
  "Imposta il nome host personalizzato"
 ],
 "Share disk with other operating systems": [
  null,
  "Condividi il disco con altri sistemi operativi"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Condividi disco con altri sistemi operativi: $0"
 ],
 "Show AM/PM": [
  null,
  "Mostra AM/PM"
 ],
 "Show API key": [
  null,
  "Mostra chiave API"
 ],
 "Show PIN": [
  null,
  "Mostra PIN"
 ],
 "Show confirmed password": [
  null,
  "Mostra la password di conferma"
 ],
 "Show passphrase": [
  null,
  "Vedi la password"
 ],
 "Show password": [
  null,
  "Mostra la password"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Software installation": [
  null,
  "Installazione software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Installazione del software: Configurazione dello storage completata. Il software viene ora installato sul dispositivo."
 ],
 "Software selection": [
  null,
  "Selezione software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Alcuni step dell'installazione devono essere ancora completati prima di continuare."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Mancano alcune partizioni richieste: $0"
 ],
 "Space": [
  null,
  "Spazio"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Storage configuration": [
  null,
  "Configurazione dello Storage"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configurazione dello storage: Lo storage è in corso di configurazione."
 ],
 "Storage editor": [
  null,
  "Editor di archiviazione"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "L'archiviazione si basa sulla configurazione di \"Modifica archiviazione\"."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "La struttura di archiviazione è definita dal file kickstart. La struttura di partizionamento prevista può essere verificata nella fase di riepilogo."
 ],
 "Storage plugin failed": [
  null,
  "Plug-in di archiviazione non riuscito"
 ],
 "Storage requirements not met": [
  null,
  "Requisiti di archiviazione non soddisfatti"
 ],
 "Strong": [
  null,
  "Forte"
 ],
 "Successfully installed": [
  null,
  "Installazione riuscita"
 ],
 "Successfully unlocked $0.": [
  null,
  "Sblocco riuscito $0."
 ],
 "Suggested keyboards": [
  null,
  "Tastiere consigliate"
 ],
 "Suggested languages": [
  null,
  "Lingue suggerite"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Configurazione di sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configurazione del sistema: Installazione del software completata. Il sistema viene ora configurato."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "L'installazione di Anaconda si è interrotta inaspettatamente."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "I seguenti bug aperti potrebbero essere correlati al tuo problema. Si prega di consultarli prima di creare una nuova segnalazione."
 ],
 "The following user will be created:": [
  null,
  "Il seguente utente viene creato:",
  "I seguente utente viene creato:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "L'installazione richiede $1 di spazio su disco; tuttavia, la capacità dei dischi selezionati è solo $0."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "L'installazione non può continuare a causa di un errore critico."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "L'installazione non può continuare a causa di un errore critico: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "La passphrase che hai fornito contiene caratteri non ASCII. Potresti non essere in grado di passare da un layout di tastiera all'altro quando lo digiti."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Il layout di tastiera predefinito selezionato non supporta i caratteri ASCII. Seleziona un layout che supporti i caratteri ASCII come predefinito."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "L'editor di archiviazione ti permette di ridimensionare, eliminare e creare partizioni. Può configurare LVM e molto altro. È pensato come utilità avanzata e non è destinato all'uso in un'installazione tipica."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Questi file di registro possono contenere informazioni sensibili, quali indirizzi IP, nomi utente o altri dettagli di sistema."
 ],
 "This hostname can't be submitted": [
  null,
  "Questo nome host non può essere inviato"
 ],
 "This is unstable, pre-release software": [
  null,
  "Questo software è una pre-rilascio instabile"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Questo layout verrà utilizzato per sbloccare il tuo sistema all'avvio"
 ],
 "This may take a moment": [
  null,
  "Attendere prego"
 ],
 "This will take a few moments": [
  null,
  "L'operazione richiederà alcuni istanti"
 ],
 "Time": [
  null,
  "Orario"
 ],
 "Timezone": [
  null,
  "Fuso orario"
 ],
 "Title": [
  null,
  "Titolo"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Per iniziare a usare $0, riavvia il sistema."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Per continuare, selezionare i dispositivi su cui effettuare l'installazione."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Per usare questa opzione, ridimensionare o eliminare le partizioni su disco per liberare $0 di spazio."
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Impossibile pianificare l'eliminazione di $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Impossibile pianificare il ridimensionamento di $0"
 ],
 "Undo last action": [
  null,
  "Annulla l'ultima azione"
 ],
 "Unlock": [
  null,
  "Sblocca"
 ],
 "Unlock encrypted devices": [
  null,
  "Sblocca i dispositivi cifrati"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Sblocca le partizioni crittografate per conservare i dati esistenti e mostrare più metodi di installazione."
 ],
 "Use configured storage": [
  null,
  "Utilizza spazio di archiviazione configurato"
 ],
 "Use entire disk": [
  null,
  "Utilizza l'intero disco"
 ],
 "Use free space": [
  null,
  "Usa lo spazio libero"
 ],
 "Use local account": [
  null,
  "Utilizza l'account locale"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Usa il dispositivo RAID per il partizionamento automatico"
 ],
 "User creation": [
  null,
  "Creazione utente"
 ],
 "User name": [
  null,
  "Nome utente"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Il nome utente può contenere solo: lettere dalla a-z, cifre 0-9, trattino $0, punto $1, trattino basso $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Il nome utente non deve essere una parola riservata"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "I nomi utente devono contenere meno di 33 caratteri"
 ],
 "Validating...": [
  null,
  "Validazione..."
 ],
 "Weak": [
  null,
  "Debole"
 ],
 "Welcome": [
  null,
  "Benvenuto"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Benvenuti in Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Benvenuto. Installiamo $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Quando invii questo report di bug, i seguenti file di log verranno caricati automaticamente: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Le partizioni Windows con crittografia BitLocker non possono essere ridimensionate"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Puoi liberare spazio sufficiente qui e lasciare che il programma di installazione gestisca il resto o impostare manualmente le partizioni."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Puoi generare la chiave API per il tuo account Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Per procedere è necessario abilitare l'account root o creare un account utente locale."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Per abilitare la data e l'ora automatiche è necessario essere connessi a una rete."
 ],
 "Your progress will not be saved.": [
  null,
  "I progressi non verranno salvati."
 ],
 "completed step": [
  null,
  "Step completati"
 ],
 "current step": [
  null,
  "step corrente"
 ],
 "delete": [
  null,
  "Cancella"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "encrypt": [
  null,
  "cifrare"
 ],
 "encrypted": [
  null,
  "crittografato"
 ],
 "extended partition": [
  null,
  "partizione estesa"
 ],
 "format as $0": [
  null,
  "formatta come $0"
 ],
 "here": [
  null,
  "qui"
 ],
 "incomplete": [
  null,
  "incompleto"
 ],
 "mount": [
  null,
  "monta"
 ],
 "pending step": [
  null,
  "step mancanti"
 ],
 "report the issue manually": [
  null,
  "segnalare manualmente il problema"
 ],
 "resized from $0": [
  null,
  "ridimensionato da $0"
 ],
 "shrink": [
  null,
  "riduci"
 ],
 "shrink to $0": [
  null,
  "ridursi a $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "indietro"
 ]
});
