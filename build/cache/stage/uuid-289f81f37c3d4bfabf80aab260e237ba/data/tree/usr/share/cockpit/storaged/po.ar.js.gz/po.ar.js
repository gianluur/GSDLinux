cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Server": [
  null,
  "خادم"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Unlock": [
  null,
  "ألغِ القفل"
 ],
 "Add key": [
  null,
  "إضافة مفتاح"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "Select": [
  null,
  "تحديد"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "Set": [
  null,
  "تعيين"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Port": [
  null,
  "منفذ"
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "Permission denied": [
  null,
  "الإذن مرفوض"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "You now have administrative access.": [
  null,
  "لديك الآن حق الوصول الإداري."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "الرجاء المصادقة للحصول على صلاحيات إدارية"
 ],
 "Switch to administrative access": [
  null,
  "التبديل إلى الوصول الإداري"
 ],
 "Authenticate": [
  null,
  "مصادقة"
 ],
 "Administrative access": [
  null,
  "صلاحيات المسؤول"
 ],
 "Problem becoming administrator": [
  null,
  "مشكلة في الحصول على صلاحيات المسؤول"
 ],
 "Method": [
  null,
  "الطريقة"
 ],
 "Limit access": [
  null,
  "تقييد الوصول"
 ],
 "Switch to limited access": [
  null,
  "التبديل إلى الوصول محدود الصلاحيات"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "يُقيّد وضع الوصول المقيد الصلاحيات الإدارية. ستكون بعض أجزاء لوحة التحكم عبر الويب محدودة الوظائف."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "سيتذكر متصفحك مستوى وصولك عبر الجلسات."
 ],
 "Limited access": [
  null,
  "وصول مقيَّد"
 ],
 "Turn on administrative access": [
  null,
  "فعّل الوصول الإداري"
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "أبلغت PackageKit عن رمز الخطأ $0"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "نوع عامل التصفية"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Shell script": [
  null,
  "سكريبت الصدفة"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "View logs": [
  null,
  "عرض السجلات"
 ],
 "Dismiss": [
  null,
  "استبعاد"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "Model": [
  null,
  "النموذج"
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "none": [
  null,
  "لا شيء"
 ],
 "Not found": [
  null,
  "غير موجود"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "Not running": [
  null,
  "لا يعمل"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "Vendor": [
  null,
  "المُنتِج"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Confirm deletion of $0": [
  null,
  "تأكيد حذف $0"
 ],
 "Username": [
  null,
  "اسم المستخدم"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Rename": [
  null,
  "أعد التسمية"
 ],
 "Started": [
  null,
  "بدأ"
 ],
 "Delete group": [
  null,
  "حذف المجموعة"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Lock": [
  null,
  "قفل"
 ],
 "Use $0": [
  null,
  "اشتخدم $0"
 ],
 "Service": [
  null,
  "خدمة"
 ],
 "Disconnect": [
  null,
  "قطع الاتصال"
 ],
 "Address": [
  null,
  "العنوان"
 ],
 "$0 disk is missing": [
  null,
  "$0 لا أقراص مفقودة",
  "$0 قرص واحد مفقود",
  "$0 قرصين مفقودين",
  "$0 أقراص مفقودة",
  "$0 قرصا مفقودا",
  "$0 قرص مفقود"
 ],
 "Location": [
  null,
  "الموقع"
 ],
 "Compression": [
  null,
  "الضغط"
 ],
 "Storage logs": [
  null,
  "سجلات التخزين"
 ],
 "Name cannot be empty.": [
  null,
  "لا يمكن ترك الاسم فارغاً."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "لا يمكن أن يكون الاسم أطول من 127 حرف."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "لا يمكن أن يتضمن الإسم المحرف \"$0\"."
 ],
 "Name cannot contain whitespace.": [
  null,
  "لا يمكن أن يتضمن الاسم."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "لا يمكن أن يكون الاسم أطول من $0 حرف"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "لا يمكن أن يكون الاسم أطول من $0 بايت"
 ],
 "$name (from $host)": [
  null,
  "$name (من $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "مجموعة وحدات تخزين منطقية رقيقة"
 ],
 "Thin logical volume": [
  null,
  "وحدة تخزين منطقية رقيقة"
 ],
 "Logical volume (snapshot)": [
  null,
  "وحدة تخزين منطقية (ملتقطة)"
 ],
 "Logical volume": [
  null,
  "وحدة تخزين منطقية"
 ],
 "MDRAID device $0": [
  null,
  "جهاز MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "مجموعة وحدات تخزين LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "جهاز VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "وحدة تخزين منطقية مشفرة من $0"
 ],
 "Encrypted partition of $0": [
  null,
  "قسم مشفر $0"
 ],
 "Logical volume of $0": [
  null,
  "وحدة تخزين منطقية من $0"
 ],
 "Partition of $0": [
  null,
  "قسم $0"
 ],
 "Encrypted $0": [
  null,
  "$0 مشفَّر"
 ],
 "unpartitioned space on $0": [
  null,
  "مساحة غير مقسمة على $0"
 ],
 "unmount": [
  null,
  "إلغاء التركيب"
 ],
 "mount": [
  null,
  "ركِّب"
 ],
 "remove from btrfs volume": [
  null,
  "إزالة من وحدة تخزين btrfs"
 ],
 "stop": [
  null,
  "توقف"
 ],
 "remove from MDRAID": [
  null,
  "إزالة من MDRAID"
 ],
 "remove from LVM2": [
  null,
  "إزالة من LVM2"
 ],
 "btrfs device": [
  null,
  "جهاز btrfs"
 ],
 "btrfs volume": [
  null,
  "وحدة تحزيم btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "الاسم لا يمكن أن يكون أطول من ٢٥٥ حرفاً."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "الاسم لا يمكن أن يحتوي على '/'."
 ],
 "Create and mount": [
  null,
  "إنشاء ثم تركيب"
 ],
 "Create only": [
  null,
  "أنشئ فقط"
 ],
 "Create subvolume": [
  null,
  "إنشاء وحدة تخزين فرعية"
 ],
 "Mount Point": [
  null,
  "نقطة الوصل"
 ],
 "delete": [
  null,
  "حذف"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "متأكد من حذف وحدة التخزين الفرعية $0؟"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "يؤدي الحذف إلى محو جميع البيانات الموجودة على هذا الحجم الفرعي وجميع البيانات التابعة له."
 ],
 "Edit mount point": [
  null,
  "تعديل نقطة تركيب"
 ],
 "Unmount": [
  null,
  "فك تركيب"
 ],
 "Mount": [
  null,
  "اوصل"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "\"يجب تركيب وحدة فرعية واحدة على الأقل"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "لا يمكن حذف آخر وحدة تخزين فرعية مركَّبة"
 ],
 "btrfs subvolume": [
  null,
  "وحدة تخزين btrfs فرعية"
 ],
 "Snapshot origin": [
  null,
  "مصدر اللقطة"
 ],
 "Mount point": [
  null,
  "نقطة وصل"
 ],
 "No subvolumes": [
  null,
  "لا وحظات تخزين فرعية"
 ],
 "btrfs subvolumes": [
  null,
  "وحدات تخزين btrfs الفرعية"
 ],
 "Snapshots": [
  null,
  "اللقطات"
 ],
 "No snapshots found": [
  null,
  "لا يوجد لقطات"
 ],
 "snapshot": [
  null,
  "لقطة نظام"
 ],
 "$0 is in use": [
  null,
  "$0 قيد الاستخدام"
 ],
 "Permanently delete $0?": [
  null,
  "متأكد من حذف $0؟"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على وحدة تخزين btrfs."
 ],
 "Delete filesystem": [
  null,
  "حذف نظام ملفات"
 ],
 "Change label": [
  null,
  "تغيير التسمية"
 ],
 "Filesystem is mounted read-only": [
  null,
  "تم تركيب نظام الملفات للقراءة فقط"
 ],
 "Label": [
  null,
  "العنوان"
 ],
 "Capacity": [
  null,
  "السعة"
 ],
 "btrfs devices": [
  null,
  "أجهزة btrfs"
 ],
 "No devices found": [
  null,
  "لم يتم إيجاد أجهزة"
 ],
 "btrfs filesystem": [
  null,
  "نظام ملفات btrfs"
 ],
 "Successful": [
  null,
  "ناجح"
 ],
 "Aborted": [
  null,
  "ملغي"
 ],
 "In progress": [
  null,
  "قيد المعالجة"
 ],
 "Interrupted": [
  null,
  "مُقاطَع"
 ],
 "Did not complete": [
  null,
  "غير مكتمل"
 ],
 "Failed (Unknown)": [
  null,
  "فشل (مجهول السبب)"
 ],
 "Failed (Electrical)": [
  null,
  "فشل (كهربائي)"
 ],
 "Failed (Servo)": [
  null,
  "فشل (نظام التحكم Servo)"
 ],
 "Failed (Read)": [
  null,
  "فشل (قراءة)"
 ],
 "Failed (Damaged)": [
  null,
  "فشل (تلف)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "أُلغي بسبب إعادة ضبط على مستوى المتحكم"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "تم إلغاء العملية لأن مساحة الأسماء حُذفت من النظام"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "أُلغيَت العملية بسبب معالجة أمر تهيئة NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "حدث خطأ كارثي أثناء عملية الفحص الذاتي"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "مكتمل مع فشل جزء غير معروف"
 ],
 "Completed with one or more failed segments": [
  null,
  "اكتمل مع وجود جزء أو أكثر من الأجزاء فاشلة"
 ],
 "Aborted for unknown reason": [
  null,
  "أُلغيَت العملية لسبب غير معروف"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "أُلغيَت العملية بسبب تنفيذ عملية تعقيم"
 ],
 "Spare capacity is below the threshold": [
  null,
  "السعة الاحتياطية أقل من الحد الأدنى"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "درجة الحرارة خارج الحدود الموصى بها"
 ],
 "Degraded": [
  null,
  "متدهور"
 ],
 "All media is in read-only mode": [
  null,
  "كل الوسائط ففي وضعية القراءة فقط"
 ],
 "Volatile memory backup failed": [
  null,
  "فشل النسخ الاحتياطي للذاكرة المتطايرة"
 ],
 "Persistent memory has become read-only": [
  null,
  "أصبحت الذاكرة الدائمة في وضع القراءة فقط"
 ],
 "Run short test": [
  null,
  "إجراء اختبار قصير"
 ],
 "Run extended test": [
  null,
  "إجراء اختبار موسع"
 ],
 "Abort test": [
  null,
  "إلغاء الاختبار"
 ],
 "Disk is failing": [
  null,
  "القرص معطل"
 ],
 "Disk is OK": [
  null,
  "القرص سليم"
 ],
 "Assessment": [
  null,
  "التقييم"
 ],
 "Power on hours": [
  null,
  "ساعات التشغيل"
 ],
 "$0 hours": [
  null,
  "$0 ساعات"
 ],
 "Self-test status": [
  null,
  "حالة الفحص الذاتي"
 ],
 "Number of bad sectors": [
  null,
  "عدد القطاعات التالفة"
 ],
 "Attributes failing": [
  null,
  "سمات معطوبة"
 ],
 "Media drive": [
  null,
  "قرص وسائط"
 ],
 "Solid State Drive": [
  null,
  "قرص الحالة الصلبة"
 ],
 "Hard Disk Drive": [
  null,
  "القرص الصلب"
 ],
 "iSCSI Drive": [
  null,
  "محرك أقراص iSCSI"
 ],
 "Drive": [
  null,
  "محرك أقراص"
 ],
 "Device health (SMART)": [
  null,
  "صحة الجهاز (SMART)"
 ],
 "Firmware version": [
  null,
  "إصدار التعريف"
 ],
 "Serial number": [
  null,
  "الرقم التسلسلي"
 ],
 "World wide name": [
  null,
  "الاسم العالمي"
 ],
 "No media inserted": [
  null,
  "لا وسائط مدرجة"
 ],
 "Device file": [
  null,
  "ملف الجهاز"
 ],
 "Multipathed devices": [
  null,
  "الأجهزة متعددة الشرائح"
 ],
 "Free space": [
  null,
  "المساحة الحرّة"
 ],
 "Create partition": [
  null,
  "إنشاء قسم"
 ],
 "Extended partition": [
  null,
  "قسم موسع"
 ],
 "$0 partitions": [
  null,
  "$0 قسم"
 ],
 "Partitions": [
  null,
  "الأقسام"
 ],
 "No partitions found": [
  null,
  "لم يتم العثور على أي أقسام"
 ],
 "Unexpected partitions": [
  null,
  "أقسام غير متوقعة"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "الأقسام غير مدعومة على جهاز الكتلة هذا. إذا تم استخدامه كقرص لجهاز افتراضي، يجب إدارة الأقسام عبر نظام التشغيل داخل الجهاز الافتراضي."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "سيؤدي حذف قسم إلى حذف كل البيانات الموجودة فيه."
 ],
 "No free space after this partition": [
  null,
  "لا مساحة حرة بعد هذا القسم"
 ],
 "EFI system partition": [
  null,
  "قسم نظام EFI"
 ],
 "BIOS boot partition": [
  null,
  "قسم إقلاع الـ BIOS"
 ],
 "Partition": [
  null,
  "قسم"
 ],
 "Shrink": [
  null,
  "قلّص"
 ],
 "Grow": [
  null,
  "النمو"
 ],
 "PowerPC PReP boot partition": [
  null,
  "قسم إقلاع PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "سعة Linux swap"
 ],
 "Linux filesystem data": [
  null,
  "بيانات نظام ملفات Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "مدير أقسام وحدات التقسيم المنطقية"
 ],
 "Custom": [
  null,
  "مخصّص"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "يجب أن يتألف النوع من محرفين ستة عشرية بالضبط (من 0 إلى 9، ومن A إلى F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "يمكن أن يحتوي النوع على الأرقام من 0 إلى 9 والحروف من A إلى F ورمز \"-\" فقط."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "يجب أن يكون النوع بالشكل التالي: NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "تعيين نوع القسم لـ $0"
 ],
 "Custom type": [
  null,
  "نوع مخصص"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "قد يؤدي تغيير أنواع الأقسام إلى منع النظام من الإقلاع."
 ],
 "This partition is not completely used by its content.": [
  null,
  "هذا القسم غير مستخدم بالكامل من قبل محتواه."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "حجم القسم $0. حجم المحتوى $1."
 ],
 "Shrink partition": [
  null,
  "قلِّص القسم"
 ],
 "Grow content": [
  null,
  "نمو المحتوى"
 ],
 "initialize": [
  null,
  "تمهيد"
 ],
 "Initialize disk $0": [
  null,
  "تمهيد القرص $0"
 ],
 "Partitioning": [
  null,
  "التقسم"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "متوافق مع جميع الأنظمة والأجهزة (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "**متوافق مع الأنظمة الحديثة والأقراص الصلبة الأكبر من 2 تيرابايت (GPT)*"
 ],
 "No partitioning": [
  null,
  "لا تقسيم"
 ],
 "Overwrite": [
  null,
  "الكتابة فوق"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "الكتابة فوق البيانات الموجودة بأصفار (أبطأ)"
 ],
 "Initialize": [
  null,
  "تمهيد"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "التمهيد سيحذف كل البيانات من القرص."
 ],
 "Device is read-only": [
  null,
  "الجهاز للقراءة فقط"
 ],
 "Create partition table": [
  null,
  "إنشاء جدول تقسيم"
 ],
 "Size must be a number": [
  null,
  "الحجم يجب أن يكون عدداً"
 ],
 "Size cannot be zero": [
  null,
  "الحجم لا يمكن أن يكون صفراً"
 ],
 "Size cannot be negative": [
  null,
  "الحجم لا يمكن أن يكون عدداً سالباً"
 ],
 "Size is too large": [
  null,
  "الحجم كبير جداً"
 ],
 "Size must be at least $0": [
  null,
  "يجب ألا يقل الحجم عن $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "القرص المادي الخاص بمجموعة وحدة التخزين من نوع LVM2"
 ],
 "member of MDRAID device": [
  null,
  "عضو في جهاز MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "جهاز التخزين الأساسي لجهاز VDO"
 ],
 "member of Stratis pool": [
  null,
  "عضو في مجمع Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "نظام الملفات خارج نطاق الهدف"
 ],
 "device of btrfs volume": [
  null,
  "جهاز وحدة تخزين btrfs"
 ],
 "This device is currently in use.": [
  null,
  "هذا الجهاز حالياً قيد الاستخدام."
 ],
 "Device": [
  null,
  "جهاز"
 ],
 "Use": [
  null,
  "استخدم"
 ],
 "Services using the location": [
  null,
  "خدمات تستخدم الموقع"
 ],
 "Processes using the location": [
  null,
  "عمليات تستخدم الموقع"
 ],
 "Currently in use": [
  null,
  "قيد الاستخدام"
 ],
 "(Not part of target)": [
  null,
  "(ليس جزءًا من الهدف)"
 ],
 "These changes will be made:": [
  null,
  "سيتم إجراء هذه التغييرات:"
 ],
 "Action": [
  null,
  "نشاط"
 ],
 "Important data might be deleted:": [
  null,
  "قد يتم حذف بيانات مهمة:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات والخدمات ذات الصلة بالقوة."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات ذات الصلة بالقوة."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "سيتم إيقاف الخدمات ذات الصلة بالقوة."
 ],
 "Checking filesystem usage": [
  null,
  "التحقق من استخدام نظام الملفات"
 ],
 "$0 used, $1 total": [
  null,
  "$0 مستخدمة من أصل $1"
 ],
 "Device contains unrecognized data": [
  null,
  "يحوي الجهاز على بيانات غير معترف بها"
 ],
 "Locked encrypted device might contain data": [
  null,
  "قد يحتوي الجهاز المشفّر المقفل على بيانات"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "أؤكد أنني أريد التخلص من هذه البيانات إلى الأبد"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "نقطة التركيب $0 مستخدمة من قبل هذه العمليات:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "أمر"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "نقطة التركيب $0 مستخدمة من قبل هذه الخدمات:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات والخدمات المدرجة بالقوة."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات المدرجة بالقوة."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "سيتم إيقاف الخدمات المدرجة بالقوة."
 ],
 "Sorry": [
  null,
  "عذراً"
 ],
 "Usage of $0": [
  null,
  "استخدام $0"
 ],
 "LVM2 VDO pool": [
  null,
  "مجمع LVM2 VDO"
 ],
 "Data used": [
  null,
  "البيانات المستخدمة"
 ],
 "Metadata used": [
  null,
  "البيانات الوصفية المستخدمة"
 ],
 "Use compression": [
  null,
  "‎استخدام الضغط"
 ],
 "Deduplication": [
  null,
  "النسخ المكرر"
 ],
 "Use deduplication": [
  null,
  "استخدام الاستنساخ المكرر"
 ],
 "Rename volume group": [
  null,
  "إعادة تسمية مجموعة وحدات تخزين"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "تحوي مجموعة وحدات التخزين هذه على نظام الملفات الجذر. قد تتطلب إعادة تسميته تغييرات أخرى على تهيئة مُحمّل الإقلاع أو سطر أوامر نواة النظام."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على مجموعة وحدات التخزين."
 ],
 "Create snapshot": [
  null,
  "إنشاء لقطة"
 ],
 "Add disks": [
  null,
  "إضافة أقراص"
 ],
 "Disks": [
  null,
  "الأقراص"
 ],
 "No disks are available.": [
  null,
  "لا يوجد أقراص متاحة."
 ],
 "At least one disk is needed.": [
  null,
  "يحتاج إلى قرص صلب واحد على الأقل."
 ],
 "Volume group is missing physical volumes": [
  null,
  "مجموعة التخزين تفتقد إلى وحدات التخزين المادية"
 ],
 "No free space": [
  null,
  "لا مساحة حرة"
 ],
 "LVM2 volume group": [
  null,
  "مجموعة وحظات تخزين LVM2"
 ],
 "Add physical volume": [
  null,
  "إضافة قرص فيزيائي"
 ],
 "LVM2 logical volumes": [
  null,
  "وحدات تخزين LVM2 منطقية"
 ],
 "Create new logical volume": [
  null,
  "إنشاء قرص منطقي جديد"
 ],
 "No logical volumes": [
  null,
  "لا وحدات تخزين منطقية"
 ],
 "Remove missing physical volumes?": [
  null,
  "إزالة الأقراص المادية المفقودة؟"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "مجموعة التخزين هذه تفتقد بعض الأقراص المادية."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "لا يمكن إعادة تسمية مجموعة وحدات التخزين التي تحوي على أقراص مادية مفقودة."
 ],
 "Physical volumes": [
  null,
  "وحدات التخزين المادية"
 ],
 "No physical volumes found": [
  null,
  "لا يوجد وحدة تخزين فيزيائية"
 ],
 "LVM2 physical volumes": [
  null,
  "وحدات تخزين LVM2 فيزيائية"
 ],
 "Rename logical volume": [
  null,
  "إعادة تسمية وحدة التخزين المنطقية"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "متأكد من حذف وحدة التخزين المنطقية $0/$1؟"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "سيؤدي حذف وحدة التخزين المنطقية إلى حذف جميع البيانات الموجودة فيه."
 ],
 "Unable to repair logical volume $0": [
  null,
  "تعذر إصلاح وحدة التخزين المنطقية $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "لا توجد مساحة كافية متاحة يمكن استخدامها للإصلاح. يلزم وجود مساحة لا تقل عن $0 على الأقراص المادية غير المستخدمة بالفعل لهذه الوحدة المنطقية."
 ],
 "An additional $0 must be selected": [
  null,
  "يجب تحديد $0 إضافي"
 ],
 "Repair logical volume $0": [
  null,
  "إصلاح وحدة التخزين المنطقية $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "حدد وحدات التخزين المادبة التي يجب استخدامها لإصلاح وحدة التخزين المنطقية. مطلوب $0 على الأقل."
 ],
 "Physical Volumes": [
  null,
  "وحدات التخزين المادية"
 ],
 "Repair": [
  null,
  "الإصلاح"
 ],
 "deactivate": [
  null,
  "إِلغاء التنشيط"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "إلغاء تنشيط وحدة التخزين المنطقية $0/$1؟"
 ],
 "Deactivate": [
  null,
  "إلغاء التنشيط"
 ],
 "Not enough space to grow": [
  null,
  "لا يوجد مساحة كافية للزيادة"
 ],
 "LVM2 logical volume": [
  null,
  "وحدة تحزين LVM2 منطقية"
 ],
 "Striped (RAID 0)": [
  null,
  "مخطط (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "النسخ المتطابق (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "مخطط ومرآة (RAID 10)‎"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "التكافؤ المخصص (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "التكافؤ الموزع (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "التكافؤ الموزع المزدوج (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "وحدة التخزين المنطقية هذه غير مستخدمة بالكامل من قبل محتواها."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "حجم وحدة التحزين $0. حجم المحتوى $1."
 ],
 "Shrink volume": [
  null,
  "قلِّص وحدة التخزين"
 ],
 "Layout": [
  null,
  "التخطيط"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية ولم تعد صالحة للاستخدام. يجب حذفها وإنشاء وحدة جديدة لتحل محلها."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية لكنها لم تفقد أي بيانات بعد. يجب إصلاحها لاستعادة التكرارية الأصلية."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية ، لكن ربما لم تفقد أي بيانات بعد. قد تتمكن من إصلاحها."
 ],
 "Stripes": [
  null,
  "stripes"
 ],
 "$0 synchronized": [
  null,
  "$0 متزامن"
 ],
 "Create volume group": [
  null,
  "إنشاء مجموعة أقراص"
 ],
 "LVM2 physical volume": [
  null,
  "وحدة تخزين LVM2 فيزيائية"
 ],
 "Last cannot be removed": [
  null,
  "لا يمكن إزالة الأخير"
 ],
 "Not enough free space": [
  null,
  "لا مساحة تخزين كافية"
 ],
 "Volume group": [
  null,
  "مجموعة وحدة تحزين"
 ],
 "Create thin volume": [
  null,
  "إنشاء وحدة تخزين رفيعة"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "وحدات التخزين المنطقية LVM2 ذات التزويد الرقيق"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "إنشاء وحدة تخزين منطقية مخصصة رقيقة"
 ],
 "Not enough space": [
  null,
  "لا مساحة كافية"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "مجمع تخزين لوحدات التخزين المنطقية رقيقة التخصيص (LVM2)"
 ],
 "Inactive logical volume": [
  null,
  "وحدة تخزين منطقية غير مفعلة"
 ],
 "Activate": [
  null,
  "التنشيط"
 ],
 "Unsupported logical volume": [
  null,
  "وحدة ت=تخزين منطقية غير مدعومة"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "خطأ داخلي - تم وضع علامة على وحدة التخزين المنطقية هذه على أنها نشطة ويجب أن يكون لها جهاز كتلة مقترن. رغم ذلك، لا جهاز كتلة تم العثور عليه."
 ],
 "Installing $0 would remove $1.": [
  null,
  "سيؤدي تثبيت $0 لإزالة $1."
 ],
 "Installing packages": [
  null,
  "تثبيت الحزم"
 ],
 "Block device for filesystems": [
  null,
  "جهاز الحظر لأنظمة الملفات"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "مجموعة تخزين لوحدات التخزين المنطقية رقيقة التخصيص"
 ],
 "Linear": [
  null,
  "خطي"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "وحدة تخزين نظام الملفات باستخدام VDO (ميزات الضغط وإزالة النسخ المكرَّر)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة دون أي تكرار إضافي أو تحسينات في الأداء."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بطريقة متناوبة لتحسين الأداء. يجب تحديد وحدتي تخزين على الأقل."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات كنسختين أو أكثر على وحدات التخزين المادية المحددة، لتحسين الموثوقية. يجب تحديد وحدتي تخزين على الأقل."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات كنسختين، وكذلك بالتناوب، على وحدات التخزين المادية المحددة، لتحسين الموثوقية والأداء. يجب اختيار أربعة وحدات تخزين على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان أحدها دون التأثير على البيانات. يجب تحديد ثلاث وحدات على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان أحدها دون التأثير على البيانات. يتم تخزين البيانات أيضاً بطريقة متناوبة لتحسين الأداء. يجب تحديد ثلاث وحدات على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان ما يصل إلى اثنين منها في نفس الوقت دون التأثير على البيانات. يتم تخزين البيانات أيضاً بطريقة متناوبة لتحسين الأداء. يجب تحديد خمسة وحدات على الأقل."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "جميع وحدات التخزين الفيزيائية المحددة ($0) ضرورية للمخطط المختار."
 ],
 "Create logical volume": [
  null,
  "إنشاء قرص منطقي"
 ],
 "Purpose": [
  null,
  "الغرض"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "سيتم تثبيت الحزمة $0 لإنشاء أجهزة VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "يتطلب RAID 10 عددًا زوجيًا من الأقراص الفعلية"
 ],
 "Logical size": [
  null,
  "الحجم المنطقي"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "توفير المساحة عن طريق ضغط الكتل الفردية عبر LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "توفير المساحة عن طريق تخزين كتل بيانات متطابقة لمرة واحدة فقط"
 ],
 "Creating VDO device": [
  null,
  "إنشاء جهاز VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "نقطة تركيب NFS هذه قيد الاستخدام، ويمكن فقط تعديل خياراتها."
 ],
 "NFS mount": [
  null,
  "تركيب NFS"
 ],
 "New NFS mount": [
  null,
  "تركيب NFS جديد"
 ],
 "Server address": [
  null,
  "عنوان خادم"
 ],
 "Server cannot be empty.": [
  null,
  "الخادم لا يممن أن يكون فارغاً."
 ],
 "Path on server": [
  null,
  "المسار على الخادم"
 ],
 "Path on server cannot be empty.": [
  null,
  "المسار على الخادم لا يمكن أن يكون فارغاً."
 ],
 "Path on server must start with \"/\".": [
  null,
  "المسار على الخادم يجب أن يبدأ مع \"/\"."
 ],
 "Local mount point": [
  null,
  "نقطة تركيب محلية"
 ],
 "Mount point cannot be empty.": [
  null,
  "نقطة التركيب لا يمكن تركها فارغة."
 ],
 "Mount point must start with \"/\".": [
  null,
  "نقطة التركيب يجب أن تبدأ مع \"/\"."
 ],
 "Mount options": [
  null,
  "خيارات الوصل"
 ],
 "Mount at boot": [
  null,
  "التركيب عند الإقلاع"
 ],
 "Mount read only": [
  null,
  "تركيب للقراءة فقط"
 ],
 "Custom mount options": [
  null,
  "خيارات تركيب مخصصة"
 ],
 "Unable to unmount filesystem": [
  null,
  "تعذر فك تركيب نظام الملفات"
 ],
 "Stop and unmount": [
  null,
  "إيقاف ثم إزالة تركيب"
 ],
 "Unable to remove mount": [
  null,
  "تعذرت إزالة التركيب"
 ],
 "Stop and remove": [
  null,
  "إيقاف ثم إزالة"
 ],
 "(not mounted)": [
  null,
  "(لم يتم تركيبه)"
 ],
 "Start multipath": [
  null,
  "بدء التشغيل متعدد المسارات"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "توجد أجهزة ذات مسارات متعددة على النظام، إلا أن خدمة تعدد المسارات لا تعمل."
 ],
 "Show all $0 rows": [
  null,
  "إظهار كل الصفوف الـ $0"
 ],
 "Category": [
  null,
  "الفئة"
 ],
 "more info": [
  null,
  "معلومات إضافية"
 ],
 "Encryption": [
  null,
  "تشفير"
 ],
 "encrypted": [
  null,
  "مشفّر"
 ],
 "Last modified: $0": [
  null,
  "آخر تعديل: $0"
 ],
 "Stored passphrase": [
  null,
  "عبارة المرور مخزنة"
 ],
 "Encryption options": [
  null,
  "إعدادات التشفير"
 ],
 "Encryption type": [
  null,
  "تشفير النوع"
 ],
 "Cleartext device": [
  null,
  "جهاز Cleartext"
 ],
 "yes": [
  null,
  "نعم"
 ],
 "Disk passphrase": [
  null,
  "عبارة مرور القرص"
 ],
 "Passphrase cannot be empty": [
  null,
  "عبارة المرور لا يمكن تركها فارغة"
 ],
 "Unlocking disk": [
  null,
  "إلغاء قفل القرص"
 ],
 "Checking for $0 package": [
  null,
  "التحقق من وجود حزمة $0"
 ],
 "The $0 package must be installed.": [
  null,
  "الحزمة $0 يجب أن تكون مثبتة."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "الحزمة $0 غير متاحة على أي مستودع."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "خطأ في تثبيت $0: PackageKit أو dnf5daemon-server غير مثبَّت"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "حدث خطأ غير متوقع في PackageManager أثناء تثبيت $0:$1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "التحقق من وجود دعم NBDE في نظام التشغيل initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "يجب إعادة توليظ initrd."
 ],
 "Regenerating initrd": [
  null,
  "إعادة توليد initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "إضافة rd.neednet=1 إلى سطر أوامر نواة النظام"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "إضافة \"$0\" لخيارات نظام الملفات"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "إضافة \"$0\" لخيارات التشفير"
 ],
 "Enabling $0": [
  null,
  "تفعيل $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "إضافة تشفير القرص المربوط بالشبكة"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "النظام لا يدعم حاليًا فك تشفير نظام الملفات الجذر باستخدام خادم مفاتيح Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "النظام لا يدعم حاليًا فتح نظام ملفات مشفر باستخدام خادم مفاتيح Tang أثناء الإقلاع."
 ],
 "These additional steps are necessary:": [
  null,
  "هذه الخطوات الإضافية ضرورية:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "يتطلب حفظ عبارة مرور جديدة إلغاء قفل القرص. يرجى تقديم عبارة مرور القرص الحالية."
 ],
 "Fix NBDE support": [
  null,
  "إصلاح دعم NBDE"
 ],
 "Adding key": [
  null,
  "جاري إضافة مفتاح"
 ],
 "Key source": [
  null,
  "مصدر المفتاح"
 ],
 "Repeat passphrase": [
  null,
  "تكرار عبارة المرور"
 ],
 "Passphrase": [
  null,
  "عبارة المرور"
 ],
 "Tang keyserver": [
  null,
  "خادم مفتاح Tang"
 ],
 "New passphrase": [
  null,
  "عبارة المرور الجديدة"
 ],
 "Passphrases do not match": [
  null,
  "عبارتا المرور غير متطابقتين"
 ],
 "Keyserver address": [
  null,
  "عنوان خادم المفاتيح"
 ],
 "Change passphrase": [
  null,
  "تغيير عبارة المرور"
 ],
 "Old passphrase": [
  null,
  "عبارة المرور القديمة"
 ],
 "Edit Tang keyserver": [
  null,
  "تعديل مفتاح خادم Tang"
 ],
 "Verify key": [
  null,
  "مفتاح التحقق"
 ],
 "Trust key": [
  null,
  "مفتاح موثوق"
 ],
 "Passphrase can not be empty": [
  null,
  "عبارة المرور لا يمكن أن تكون فارغة"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "قد تؤدي إزالة عبارة المرور إلى منع إلغاء قفل $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "تأكيد الإزالة مع عبارة مرور بديلة"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "قد تؤدي إزالة عبارة المرور دون تأكيد عبارة مرور أخرى إلى منع فتح القفل أو إدارة المفاتيح، في حالة نسيان أو فقدان غيرها."
 ],
 "Passphrase from any other key slot": [
  null,
  "عبارة المرور من أي فتحة مفتاح آخر"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "إزالة عبارة المرور في مفتاح فتحة $0؟"
 ],
 "Remove $0?": [
  null,
  "إزالة $0؟"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "قد يمنع الإزالة من إلغاء قفل $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "إزالة خادم مفاتيح Tang؟"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول حالياً بالاطلاع على معلومات تخص المفاتيح."
 ],
 "No keys added": [
  null,
  "لا مفاتيح مضافة"
 ],
 "Slot $0": [
  null,
  "الفتحة $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "تعديب مفتاح يتطلب فتحة فارغة"
 ],
 "The last key slot can not be removed": [
  null,
  "لا يمكن إزالة فتحة المفتاح الأخير"
 ],
 "Keyserver": [
  null,
  "خادم المفاتيح"
 ],
 "Unknown type": [
  null,
  "نوع غير معروف"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "لا يمكن تعديل فتحات المفاتيح ذات الأنواع غير المعروفة هنا"
 ],
 "Keys": [
  null,
  "المفاتيح"
 ],
 "$0 slot remains": [
  null,
  "لا فتحة متبقية",
  "فتحة واحدة متبقية",
  "فتحتان متبقيتان",
  "$0 فتحة متبقية",
  "$0 فتحة متبقية",
  "$0 فتحة متبقية"
 ],
 "No available slots": [
  null,
  "لا فُتحات متاحة"
 ],
 "No free key slots": [
  null,
  "لا توجد فتحات مفاتيح متاحة"
 ],
 "Locked data": [
  null,
  "بيانات مقفلة"
 ],
 "lock": [
  null,
  "قفل"
 ],
 "Lock $0?": [
  null,
  "قفل $0؟"
 ],
 "Address cannot be empty": [
  null,
  "لا يمكن ترك العنوان فارغاً"
 ],
 "Address is not a valid URL": [
  null,
  "العنوان ليس رابط URL سليم"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "تحقق من تجزئة المفتاح مع خادم Tang."
 ],
 "How to check": [
  null,
  "كيفية التحقق"
 ],
 "In a terminal, run: ": [
  null,
  "في الطرفية، قم بتنفيذ: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "تم النسخ بنجاح إلى الحافظة!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "تحقق من تطابق تجزئة SHA-256 أو SHA-1 من الأمر مع مربع الحوار هذا."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "وحدة تحزين btrfs فرعية $0 لـ $1"
 ],
 "Mount point cannot be empty": [
  null,
  "نقطة التركيب لا يمكن تركها فارغة"
 ],
 "Mount point is already used for $0": [
  null,
  "نقطة التركيب مستخدمة بالفعل من $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "أنظمة الملفات تم تركيبها بالفعل أسفل نقطة التركيب هذه."
 ],
 "Please unmount them first.": [
  null,
  "الرجاء إلغاء تركيبهم أولاً."
 ],
 "read only": [
  null,
  "القراءة فقط"
 ],
 "never mount at boot": [
  null,
  "لا تركب أبدًا عند الإقلاع"
 ],
 "after network": [
  null,
  "بعد إعداد الشبكة"
 ],
 "ignore failure": [
  null,
  "تجاهل الفشل"
 ],
 "stop boot on failure": [
  null,
  "إيقاف التشغيل عند الإخفاق"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "لا يحوي نظام الملفات على نقطة تحميل معيّنة."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "لا يحوي نظام الملفات على نقطة تحميل دائمة."
 ],
 "The filesystem is not mounted.": [
  null,
  "نظام الملفات غير مركَّب."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "سيتم فتح نظام الملفات وتركيبه عند الإقلاع التالي. قد يتطلب ذلك إدخال عبارة مرور."
 ],
 "(no assigned mount point)": [
  null,
  "(لا توجد نقطة تركيب معينة)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "نظام الملفات مركَّب حاليًا على $0 ولكن سيتم تثبيته على $1 عند الإقلاع التالي."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "التركيب تلقائياً على $0 عند الإقلاع"
 ],
 "Mount on $0 now": [
  null,
  "التركيب على $0 الآن"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "نظام الملفات غير مركّب حالياً لكن سيتم تركيبه عند الإقلاع التالي."
 ],
 "Do not mount automatically on boot": [
  null,
  "لا تقم بالتركيب تلقائياً عند الإقلاع"
 ],
 "Mount now": [
  null,
  "التركيب الآن"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "نظام الملفات مركَّب حاليًا لكن لن يتم تركيبه بعد الإقلاع التالي."
 ],
 "Mount also automatically on boot": [
  null,
  "التركيب أيضًا يتم تلقائياً عند الإقلاع"
 ],
 "Unmount now": [
  null,
  "فك التركيب الآن"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "نظام الملفات مثبت حاليًا على $0 لكن لن يتم تثبيته بعد الإقلاع التالي."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "تم إعداد نظام الملفات ليتم تركيبه تلقائيًاً عند الإقلاع ، لكن لن يتم إلغاء قفل حاوية التشفير الخاصة به في ذلك الوقت."
 ],
 "Unlock automatically on boot": [
  null,
  "إلغِ القفل تلقائياً عند الإقلاع"
 ],
 "Inconsistent filesystem mount": [
  null,
  "تركيب نظام ملفات غير متوافق"
 ],
 "$0 filesystem": [
  null,
  "$0 نظام ملفات"
 ],
 "Filesystem name": [
  null,
  "اسم نظام الملفات"
 ],
 "Filesystem is locked": [
  null,
  "نظام الملفات مقفل"
 ],
 "Mounts before services start": [
  null,
  "التركيبات قبل بدء الخدمات"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "مناسب لنقاط التركيب الحرجة ، مثل ‎/var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "سيفشل التمهيد إذا لم يتم تحميل نظام الملفات، مما يمنع التحكم عن بُعد"
 ],
 "Mounts in parallel with services": [
  null,
  "‏‎التركيبات بالتوازي مع الخدمات"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "يظل التمهيد ناجحاً عندما لا يتم تحميل نظام الملفات"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "التركيبات تبدأ بالتوازي مع الخدمات، لكن بعد توفر الشبكة"
 ],
 "Does not mount during boot": [
  null,
  "لا يتم تركيبه أثناء الإقلاع"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "مفيد للتركيبات الإضافية أو التي تحتاج إلى تفاعل (مثل عبارات المرور)"
 ],
 "At boot": [
  null,
  "عند بدء التشغيل"
 ],
 "Mount before services start": [
  null,
  "التركيب قبل بدء الخدمات"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "التركيب دون انتظار، تجاهل الفشل"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "التركيب بعد عودة الشبكة، تجاهل الفشل"
 ],
 "Do not mount": [
  null,
  "لا تركِّب"
 ],
 "This device can not be used for the installation target.": [
  null,
  "لا يمكن استخدام هذا الجهاز كهدف للتثبيت."
 ],
 "Mount filesystem": [
  null,
  "تركيبز نظام الملفات"
 ],
 "Unmount filesystem $0": [
  null,
  "فك تركيب نظام الملفات $0"
 ],
 "Mount configuration": [
  null,
  "تهيئة التركيب"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "تم استخدامه"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "فتح مجمع Stratis المشفر"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "قدّم عبارة المرور لمجمع التخزين على أجهزة الكتل هذه:"
 ],
 "Stratis pool": [
  null,
  "مجمع Stratis"
 ],
 "stopped": [
  null,
  "متوقف"
 ],
 "Block devices": [
  null,
  "أجهزة الحظر"
 ],
 "No block devices found": [
  null,
  "لم يتم إيجاد أجهزة كتلة"
 ],
 "Stratis block devices": [
  null,
  "أجهزة كتلة ثابتة"
 ],
 "Stratis block device": [
  null,
  "جهاز كتلة ثابت"
 ],
 "data": [
  null,
  "بيانات"
 ],
 "cache": [
  null,
  "ذاكرة التخزين المؤقت"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "يُرجى تقديم عبارة مرور موجودة للمجمّع."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "إذا كان خادم المفاتيح في $0 غير قابل للوصول، يمكنك توفير عبارة مرور موجودة."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "إذا لم يكن أي من خوادم المفاتيح قابلاً للوصول، يمكنك توفير عبارة مرور موجودة."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "إذا لم تنجح أي من طرق إلغاء القفل غير التفاعلية، يمكنك توفير عبارة مرور موجودة."
 ],
 "Pool passphrase": [
  null,
  "مجمع عبارات المرور"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "يجب أن يكون خادم المفاتيح في $0 قابلاً للوصول."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "يجب أن يكون خادم مفاتيح واحد على الأقل قابلاً للوصول."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "يجب أن تَعمل إحدى طرق إلغاء القفل غير التفاعلية على الأقل."
 ],
 "Create filesystem": [
  null,
  "إنشاء نظام ملفات"
 ],
 "Stratis filesystem": [
  null,
  "نظام ملفات Stratis"
 ],
 "Set initial size": [
  null,
  "تعيين حجم مبدئي"
 ],
 "Limit size": [
  null,
  "حجم القيد"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "سيؤدي حذف مجمع Stratis إلى مسح جميع البيانات التي يحتوي عليها."
 ],
 "Rename Stratis pool": [
  null,
  "إعادة تسمية مجمع Stratis"
 ],
 "Add block devices": [
  null,
  "إضافة أجهزة كتلية"
 ],
 "Tier": [
  null,
  "فئة"
 ],
 "Data": [
  null,
  "البيانات"
 ],
 "Cache": [
  null,
  "ذاكرة التخزين المؤقت"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "تتطلب إضافة أجهزة الكُتل إلغاء قفل المجمع."
 ],
 "Encrypted Stratis pool": [
  null,
  "مجمع Stratis المشفر"
 ],
 "Delete pool": [
  null,
  "حذف المجمع"
 ],
 "Encryption tokens": [
  null,
  "رموز التشفير"
 ],
 "Stratis filesystems": [
  null,
  "أنظمة ملفات Stratis"
 ],
 "Create new filesystem": [
  null,
  "إنشاء نظام ملفات جديد"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "لا يستخدم هذا المجمع كل المساحة الموجودة على أجهزة الكتل الخاصة به."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "بعض أجهزة الكتل في مجمّع التخزين هذا قد زاد حجمها بعد إنشائه.. يمكن توسيع المجمع بأمان لاستخدام المساحة المتاحة الجديدة."
 ],
 "Grow the pool to take all space": [
  null,
  "قم بتنمية التجمع ليأخذ كل المساحة"
 ],
 "This pool is in a degraded state.": [
  null,
  "هذا المجمع في حالة متدهورة."
 ],
 "No filesystems": [
  null,
  "لا أنظمة ملفات"
 ],
 "Stratis filesystems pool": [
  null,
  "مجمع أنظمة ملفات Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "عبارة المرور هذه هي الطريقة الوحيدة لإلغاء قفل المجمع ولا يمكن إزالتها."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "خادم المفاتيح هذا هو الطريقة الوحيدة لإلغاء قفل المجمع ولا يمكن إزالته."
 ],
 "Add passphrase": [
  null,
  "إضافة عبارة مرور"
 ],
 "Add keyserver": [
  null,
  "إضافة مفتاح خادم"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "لا بمكن إزالة الرمز الأخير"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "لا مزيد من المساحة لعبارات المرور أو خوادم المفاتيح."
 ],
 "Confirm": [
  null,
  "أكِّد"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "تتطلب إضافة عبارة مرور إلغاء قفل المجمع."
 ],
 "Remove passphrase?": [
  null,
  "إزالة عبارة المرور؟"
 ],
 "Add Tang keyserver": [
  null,
  "إضافة خادم مفاتيح Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "إضافة خادم مفاتيح تتطلب فك قفل مجموعة التخزين."
 ],
 "Remove Clevis token?": [
  null,
  "إزالة الجهاز؟"
 ],
 "Metadata format": [
  null,
  "تنسيق البيانات الوصفية"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "تقتصر المجمّعات ذات تنسيق البيانات الوصفية V1 على عبارة مرور واحدة على الأكثر وخادم مفاتيح واحد على الأكثر."
 ],
 "Overprovisioning": [
  null,
  "التوفير الزائد"
 ],
 "Allow overprovisioning": [
  null,
  "تمكين التخصيص الزائد للموارد"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "أحجام أنظمة الملفات الافتراضية أكبر من المخزن. لا يمكن تعطيل التوفير الزائد."
 ],
 "Allocated": [
  null,
  "محجوز"
 ],
 "Name can not be empty.": [
  null,
  "الاسم لا يمكن أن يكون فارغاً."
 ],
 "A pool with this name exists already.": [
  null,
  "يوجد بالفعل مجموعة تخزين بهذا الاسم."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "نظام ملفات بهذا الاسم موجود بالفعل في هذا المخزن."
 ],
 "Create Stratis pool": [
  null,
  "إنشاء مجموعة Stratis"
 ],
 "No block devices are available.": [
  null,
  "لا أجهزة كتلة متوفرة."
 ],
 "At least one block device is needed.": [
  null,
  "يحتاج إلى جهاز تخزين واحد على الأقل."
 ],
 "Encrypt data with a passphrase": [
  null,
  "شفر البيانات مع عبارة مرور"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "تشفير الببانات مع مفتاح خادم Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "إنشاء لقطة لنظام الملفات$0"
 ],
 "Create snapshot and mount": [
  null,
  "إنشاء لقطة وتركيبها"
 ],
 "Create snapshot only": [
  null,
  "إنشاء اللقطة فقط"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "سيؤدي حذف نظام الملفات إلى حذف جميع البيانات الموجودة فيه."
 ],
 "Snapshot": [
  null,
  "لقطة نظام"
 ],
 "Rename filesystem": [
  null,
  "إعادة تسمية نظام الملفات"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "تعيين الحد لحجم نظام الملفات الافتراضي"
 ],
 "Limit virtual filesystem size": [
  null,
  "تقييد حجم نظام الملفات الافتراضي"
 ],
 "Virtual size limit": [
  null,
  "حد الحجم الافتراضي"
 ],
 "Virtual size": [
  null,
  "الحجم الافتراضي"
 ],
 "Create RAID device": [
  null,
  "نشاء جهاز RAID"
 ],
 "RAID level": [
  null,
  "مستوى RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (تجزيء)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (مرآة)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (تعادل مخصص)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (تعادل مخصص)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (تعادل مزدوج موزع)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (تجزيء المرايا)"
 ],
 "Chunk size": [
  null,
  "حجم القطعة"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "لا يحتاج لأي قرص.",
  "يحتاج إلى قرص واحد على الأقل.",
  "يحتاج إلى قرصين على الأقل.",
  "يحتاج إلى $0 أقراص على الأقل.",
  "يحتاج إلى $0 قرصاً على الأقل.",
  "يحتاج إلى $0 قرصاً على الأقل."
 ],
 "MDRAID disk": [
  null,
  "قرص MDRAID"
 ],
 "In sync": [
  null,
  "قيد المزامنة"
 ],
 "Spare": [
  null,
  "احتياطي"
 ],
 "Recovering": [
  null,
  "الاسترداد"
 ],
 "Write-mostly": [
  null,
  "وضع الكتابة الغالبة"
 ],
 "Blocked": [
  null,
  "محظور"
 ],
 "Unknown ($0)": [
  null,
  "($0) غير معروف"
 ],
 "The MDRAID device must be running": [
  null,
  "يجب أن يكون جهاز MDRAID قيد العمل"
 ],
 "MDRAID device is recovering": [
  null,
  "جهاز MDRAID قيد الاسترداد"
 ],
 "Need a spare disk": [
  null,
  "بحاجة إلى قرص احتياطي"
 ],
 "Last disk can not be removed": [
  null,
  "لا بمكن إزالة القرص الأخير"
 ],
 "MDRAID device": [
  null,
  "جهاز MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "تأكيد إيقاف $0"
 ],
 "Stop device": [
  null,
  "إيقاف الجهاز"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "يؤدي الحذف إلى مسح كافة البيانات الموجودة على جهاز MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "جهاز MDRAID يجب أن يعمل"
 ],
 "Add disk": [
  null,
  "إضافة قرص"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 أقراص"
 ],
 "$0 chunk size": [
  null,
  "$0 حجم الكتلة"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "جهاز MDRAID في حالة متدهورة"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "جهاز MDRAID هذا لا يحتوي على خريطة نوايا الكتابة (write-intent bitmap). وجود مثل هذه الخريطة يمكن أن يقلل أوقات المزامنة بشكل كبير."
 ],
 "Add a bitmap": [
  null,
  "إضافة صورة نقطية"
 ],
 "No disks found": [
  null,
  "لا يوجد أقراص"
 ],
 "MDRAID disks": [
  null,
  "أقراص MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على جهاز VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "لم يتم الانتهاء من إنشاء جهاز VDO هذا ولا يمكن استخدام الجهاز."
 ],
 "Remove device": [
  null,
  "إزالة الجهاز"
 ],
 "Grow to take all space": [
  null,
  "النمو لأخذ كل المساحة"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "جهاز VDO هذا لا يستخدم كامل مساحة الجهاز الداعم له."
 ],
 "Only $0 of $1 are used.": [
  null,
  "فقط $0 من $1 مستخدم."
 ],
 "Grow logical size of $0": [
  null,
  "زيادة الحجم المنطقي لـ $0"
 ],
 "Physical": [
  null,
  "مادي"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "تم استخدام ‎$0 بيانات + ‎$1 كتكلفة إضافية من أصل ‎$2 (‎$3)"
 ],
 "Logical": [
  null,
  "منطقي"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 مستخدمة من $1 (تم حفظ $2)"
 ],
 "Index memory": [
  null,
  "ذاكرة الفهرسة"
 ],
 "SMART self-test of $target": [
  null,
  "اختبار ذاتي SMART لـ $target"
 ],
 "Ejecting $target": [
  null,
  "إخراج $target"
 ],
 "Unlocking $target": [
  null,
  "إلغاء قفل $target"
 ],
 "Locking $target": [
  null,
  "قفل $target"
 ],
 "Modifying $target": [
  null,
  "تعديل $target"
 ],
 "Resizing $target": [
  null,
  "إعادة تحجيم $target"
 ],
 "Starting swapspace $target": [
  null,
  "تشغيل مساحة swap $target"
 ],
 "Stopping swapspace $target": [
  null,
  "إيقاف مساحة swap $target"
 ],
 "Mounting $target": [
  null,
  "تركيب $target"
 ],
 "Unmounting $target": [
  null,
  "جاري فك تركيب $target"
 ],
 "Checking $target": [
  null,
  "فحص $target"
 ],
 "Repairing $target": [
  null,
  "إصلاح $target"
 ],
 "Erasing $target": [
  null,
  "مسح $target"
 ],
 "Creating filesystem on $target": [
  null,
  "إنشاء نظام ملفات على $target"
 ],
 "Setting up loop device $target": [
  null,
  "جاري إعداد جهاز الحلقة $target"
 ],
 "Deleting $target": [
  null,
  "جاري حذف $target"
 ],
 "Creating partition $target": [
  null,
  "إنشاء قسم $target"
 ],
 "Cleaning up for $target": [
  null,
  "جارٍ المسح لـ $target"
 ],
 "Securely erasing $target": [
  null,
  "جاري المسح الآمن لـ $target"
 ],
 "Very securely erasing $target": [
  null,
  "مسح $target بأمان شديد"
 ],
 "Stopping MDRAID device $target": [
  null,
  "إيقاف جهاز MDRAID$target"
 ],
 "Starting MDRAID device $target": [
  null,
  "بدء جهاز MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "تصنيف $target كعنصر معطوب"
 ],
 "Removing $target from MDRAID device": [
  null,
  "إزالة $target من جهاز MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "إنشاء جهاز MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "التحقق من جهاز MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "فحص وإصلاح جهاز MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "استعادة جهاز MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "مزامنة جهاز MDRAID $target"
 ],
 "Activating $target": [
  null,
  "جاري تفعيل $target"
 ],
 "Deactivating $target": [
  null,
  "إلغاء تنشيط $target"
 ],
 "Creating snapshot of $target": [
  null,
  "إنشاء لقطة لـ $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "إنشاء مجموعة وحدات تخزين LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "جار حذف مجموعة وحدة تحزين LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "إضافة قرص فيزيائي إلى $target"
 ],
 "Removing physical volume from $target": [
  null,
  "إزالة وحدة التخزين المادية من $target"
 ],
 "Emptying $target": [
  null,
  "تفريغ $target"
 ],
 "Creating logical volume $target": [
  null,
  "إنشاء وحدة تخزين منطقية $target"
 ],
 "Renaming $target": [
  null,
  "إعادة تسمية $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "العملية '$operation' على '$target'"
 ],
 "unknown target": [
  null,
  "هدف غير معروف"
 ],
 "Jobs": [
  null,
  "الوظائف"
 ],
 "Reading": [
  null,
  "القرآءة"
 ],
 "Writing": [
  null,
  "الكتابة"
 ],
 "Install Stratis support": [
  null,
  "تثبيت دعم Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "يجب أن تكزن الحزمة $0 مثبتة لإنشاء مجاميع Stratis."
 ],
 "Install NFS support": [
  null,
  "تثبيت خدمة NFS"
 ],
 "Create MDRAID device": [
  null,
  "إنشاء جهاز MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "إنشاء مجموعة أقراص LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "تغيير اسم المُبادر iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "إضافة مدخل iSCSI"
 ],
 "Local storage": [
  null,
  "التخزين المحلي"
 ],
 "Networked storage": [
  null,
  "الشبكات المخزنة"
 ],
 "Create storage device": [
  null,
  "إنشاء جهاز تحزين"
 ],
 "No storage found": [
  null,
  "لا بوجد تخزين"
 ],
 "Server address cannot be empty.": [
  null,
  "عنوان الخادم لا يممن أن يكون فارغاً."
 ],
 "Next": [
  null,
  "التالي"
 ],
 "Invalid username or password": [
  null,
  "اسم المستخدم او كلمة السر غير صالحتان"
 ],
 "Unknown host name": [
  null,
  "اسم مضيف غير معروف"
 ],
 "Unable to reach server": [
  null,
  "تعذر الوصول إلى الخادم"
 ],
 "Available targets on $0": [
  null,
  "توجد أهداف متاحة على $0"
 ],
 "Authentication required": [
  null,
  "المصادقة مطلوبة"
 ],
 "iSCSI portal": [
  null,
  "بوابة iSCSI"
 ],
 "iSCSI drives": [
  null,
  "محركات أقراص iSCSI"
 ],
 "No drives found": [
  null,
  "لا يوجد أجهزة"
 ],
 "Target": [
  null,
  "الهدف"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "لا يمكن تصغير أجهزة دعم VDO"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "لا يمكن تقليص حجم أجهزة الكتل (blockdevs) في نظام Stratis"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "لا يمكن تصغير البيانات غير المعروفة هنا."
 ],
 "Unlock before resizing": [
  null,
  "إلغِ القفل قبل إعادة التحجيم"
 ],
 "$0 can not be resized here": [
  null,
  "$0 لا يمكن تغيير حجمه هنا"
 ],
 "$0 can not be resized": [
  null,
  "$0 لا يمكن تغيير حجمه"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 لا يمكن تصغيره"
 ],
 "$0 can not be made larger": [
  null,
  "$0 لا يمكن تكبيره"
 ],
 "Physical volumes can not be resized here": [
  null,
  "وحدات التخزين المادة لا يمكن إعادة تحجيمها هنا"
 ],
 "Swap can not be resized here": [
  null,
  "لا يمكن إعادة تحجيم Swap هنا"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "لا يمكن تصغير البيانات غير المعروفة هنا"
 ],
 "Activate before resizing": [
  null,
  "التنشيط قبل تغيير الحجم"
 ],
 "Grow logical volume": [
  null,
  "نمو وحدة التخزين المنطقية"
 ],
 "Grow partition": [
  null,
  "نمو القسم"
 ],
 "grow": [
  null,
  "النمو"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "يجب تحديد $0 من الأحجام الفيزائية بالضبط"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "يتطلب تغيير حجم نظام الملفات المشفر إلغاء تأمين القرص. يرجى تقديم عبارة مرور القرص الحالية."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "يجب تحديد $0 وحدات تخزين فيزيائية بالضبط، واحد لكل شريط من وحدة التخزين المنطقية."
 ],
 "Shrink logical volume": [
  null,
  "قلّص وحدة التخزين المنطقية"
 ],
 "shrink": [
  null,
  "قلِّص"
 ],
 "Unformatted data": [
  null,
  "بيانات غير منسقة"
 ],
 "Block device": [
  null,
  "حجب الجحاز"
 ],
 "Device number": [
  null,
  "رقم الجهاز"
 ],
 "Create partition on $0": [
  null,
  "إنشاء قسم على $0"
 ],
 "Format $0": [
  null,
  "تهيئة $0"
 ],
 "No filesystem": [
  null,
  "لا نظام ملفات"
 ],
 "(recommended)": [
  null,
  "(مُستحسَن)"
 ],
 "No encryption": [
  null,
  "‪لا تشفير"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "إعادة استخدام التشفير الموجود ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "إعادة استخدام التشفير الموجود"
 ],
 "format": [
  null,
  "تَهيئة"
 ],
 "Format and mount": [
  null,
  "اهيئة وتركيب"
 ],
 "Format only": [
  null,
  "التهيئة فقط"
 ],
 "Format": [
  null,
  "تهيئة"
 ],
 "Create and start": [
  null,
  "إنشاء وبدء"
 ],
 "Format and start": [
  null,
  "تهيئة وبدء"
 ],
 "Store passphrase": [
  null,
  "تخزين عبارة المرور"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "يجب إلغاء قفل القرص قبل التهيئة. يرجى تقديم عبارة مرور موجودة."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "التهئية ستمسح كل البيانات من جهاز التخزين."
 ],
 "Unrecognized data": [
  null,
  "بيانات غير معروفة"
 ],
 "Storage can not be managed on this system.": [
  null,
  "لا يمكن إدارة التخزين على هذا النظام."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "format-bytes\u0004bytes": [
  null,
  "بايتات"
 ]
});
