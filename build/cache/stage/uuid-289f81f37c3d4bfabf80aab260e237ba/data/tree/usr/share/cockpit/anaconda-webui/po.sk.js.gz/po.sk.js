cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 chyba",
  "$0 chyby",
  "$0 chýb"
 ],
 "$0 installation": [
  null,
  "Inštalácia $0"
 ],
 "$0 installer": [
  null,
  "Inštalátor $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 je rozšírený oddiel MBR, ktorý obsahuje logické oddiely. Odstránenie všetkých logických oddielov automaticky odstráni aj rozšírený oddiel."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Vyžaduje sa $0, ale k dispozícii je iba $1."
 ],
 "$0 warning": [
  null,
  "$0 upozornenie",
  "$0 upozornenia",
  "$0 upozornení"
 ],
 "$0 will be deleted": [
  null,
  "$0 bude odstránené"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' nemôže byť na šifrovanom blokovom zariadení"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' musí byť priradené k '$1'"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' musí byť na zariadení naformátovanom na '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' musí byť na systémovom oddiele EFI. Vybraný oddiel používa súborový systém FAT, ale nie je označený ako ESP. Nastavte typ oddielu na EFI System a aktivujte príznak esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Na zariadení MDRAID $1 bol nájdený oddiel '$0'. Oddiely zavádzača systému na zariadeniach MDRAID nie sú podporované."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Štandardný používateľský účet s administrátorským prístupom na vykonávanie systémových zmien."
 ],
 "Abort installation": [
  null,
  "Prerušiť inštaláciu"
 ],
 "About": [
  null,
  "O aplikácii"
 ],
 "Account": [
  null,
  "Účet"
 ],
 "Actions": [
  null,
  "Akcie"
 ],
 "Add another server...": [
  null,
  "Pridať ďalší server..."
 ],
 "Add mount": [
  null,
  "Pridať bod pripojenia"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Doplnky pre vybraté prostredie"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Doplnky, ktoré nie sú špecifické pre vaše prostredie"
 ],
 "Additional languages": [
  null,
  "Dodatočné jazyky"
 ],
 "Additional software for the selected environment": [
  null,
  "Doplnkový softvér pre vybraté prostredie"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Všetky zmeny vykonané v editore úložiska sa prejavia okamžite."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Všetky zariadenia používajúce toto heslo budú odomknuté"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Stránka projektu Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Použiť priradenie bodov pripojenia a nainštalovať"
 ],
 "Applying changes...": [
  null,
  "Aplikujú sa zmeny..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Priradiť oddiely k bodom pripojenia. Užitočné pre predkonfigurované vlastné rozloženia."
 ],
 "Automatic log file upload": [
  null,
  "Automatické nahranie súboru s logmi"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Automaticky nastaviť dátum a čas pomocou časových serverov"
 ],
 "Automatically set timezone": [
  null,
  "Automaticky nastaviť časové pásmo"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Dostupné voľné miesto: $0. Inštalácia vyžaduje: $1."
 ],
 "Back": [
  null,
  "Späť"
 ],
 "Base environment": [
  null,
  "Základné prostredie"
 ],
 "Brief description of the issue": [
  null,
  "Stručný popis problému"
 ],
 "Bug report details": [
  null,
  "Podrobnosti hlásenia chyby"
 ],
 "Bugzilla API key": [
  null,
  "Kľúč Bugzilla API"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Používaním tohto softvéru chápete a akceptujete riziká spojené s predčasne vydaným softvérom, ktorý máte v úmysle používať iba na testovacie a vývojové účely, a ste ochotní hlásiť akékoľvek chyby za účelom zlepšenia tejto práce."
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change destination": [
  null,
  "Zmeniť cieľ"
 ],
 "Change hostname": [
  null,
  "Zmeniť názov počítača"
 ],
 "Change partition layout": [
  null,
  "Zmeniť rozloženie oddielov"
 ],
 "Change system keyboard layout": [
  null,
  "Zmeniť systémové rozloženie klávesnice"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Tu vykonané zmeny okamžite ovplyvnia systém. Neexistuje žiadne 'vrátiť späť'."
 ],
 "Checking installation configuration...": [
  null,
  "Kontroluje sa konfigurácia inštalácie..."
 ],
 "Checking storage configuration": [
  null,
  "Kontroluje sa konfigurácia úložiska"
 ],
 "Clear search": [
  null,
  "Vymazať vyhľadávanie"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Kliknite znova na 'Ďalej' na pokračovanie napriek týmto upozorneniam."
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Close storage editor": [
  null,
  "Zatvoriť editor úložiska"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Úložisko Cockpitu neposkytlo heslo na odomknutie šifrovaného zariadenia."
 ],
 "Completed": [
  null,
  "Dokončené"
 ],
 "Configuration is incomplete": [
  null,
  "Konfiguráciu je neúplná"
 ],
 "Configure NTP servers": [
  null,
  "Nastaviť servery NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Nastaviť vlastné servery NTP"
 ],
 "Configure network": [
  null,
  "Konfigurovať sieť"
 ],
 "Configure storage": [
  null,
  "Konfigurovať úložisko"
 ],
 "Configure storage again": [
  null,
  "Znova konfigurovať úložisko"
 ],
 "Confirm passphrase": [
  null,
  "Potvrdenie hesla"
 ],
 "Continue": [
  null,
  "Pokračovať"
 ],
 "Continue installation": [
  null,
  "Pokračovať v inštalácii"
 ],
 "Continue installation?": [
  null,
  "Pokračovať v inštalácii?"
 ],
 "Continue with installation": [
  null,
  "Pokračovať v inštalácii"
 ],
 "Correct these issues before continuing.": [
  null,
  "Pred pokračovaním opravte tieto problémy."
 ],
 "Create Account": [
  null,
  "Vytvoriť účet"
 ],
 "Create account": [
  null,
  "Vytvoriť účet"
 ],
 "Currently installed: $0": [
  null,
  "Aktuálne nainštalované: $0"
 ],
 "Custom": [
  null,
  "Vlastné"
 ],
 "Date": [
  null,
  "Dátum"
 ],
 "Date and time": [
  null,
  "Dátum a čas"
 ],
 "Delete partition": [
  null,
  "Odstrániť oddiel"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Odstránenie určitých oddielov môže $0 zabrániť spusteniu: $1"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Destination": [
  null,
  "Cieľ"
 ],
 "Destination is encrypted": [
  null,
  "Cieľ je zašifrovaný"
 ],
 "Detailed description of the issue": [
  null,
  "Podrobný popis problému"
 ],
 "Detected valid storage layout:": [
  null,
  "Zistené platné rozloženie úložiska:"
 ],
 "Device": [
  null,
  "Zariadenie"
 ],
 "Duplicate device.": [
  null,
  "Duplicitné zariadenie."
 ],
 "Duplicate mount point.": [
  null,
  "Duplicitný bod pripojenia."
 ],
 "Enable root account": [
  null,
  "Povoliť účet root"
 ],
 "Encrypt my data": [
  null,
  "Zašifrovať moje údaje"
 ],
 "Encrypted": [
  null,
  "Šifrované"
 ],
 "Encryption": [
  null,
  "Šifrovanie"
 ],
 "Enter PIN": [
  null,
  "Zadať PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Zadajte PIN pre prístup k inštalátoru"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Zadajte svoj kľúč Bugzilla API na vytvorenie hlásenia chyby. V nasledujúcom kroku budete môcť preskúmať a upraviť podrobnosti hlásenia."
 ],
 "Environment": [
  null,
  "Prostredie"
 ],
 "Erase data and install": [
  null,
  "Vymazať údaje a nainštalovať"
 ],
 "Error details": [
  null,
  "Podrobnosti o chybe"
 ],
 "Exit to live desktop": [
  null,
  "Odísť do live desktopu"
 ],
 "Extended partition": [
  null,
  "Rozšírený oddiel"
 ],
 "Failed to report issue": [
  null,
  "Nepodarilo sa nahlásiť problém"
 ],
 "Failed to save layouts": [
  null,
  "Nepodarilo sa uložiť rozloženia"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux vyžaduje aspoň $0 miesta na disku"
 ],
 "Finalization": [
  null,
  "Finalizácia"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizácia: Konfigurácia systému je dokončená. Finalizácia inštalácie môže chvíľu trvať."
 ],
 "Find layout": [
  null,
  "Nájsť rozloženie"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Pre väčšiu bezpečnosť sa vyhnite priamemu používaniu účtu root. Namiesto toho používajte na správu systému vyššie uvedený lokálny účet."
 ],
 "Full name": [
  null,
  "Celé meno"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Celé meno nemôže obsahovať znak dvojbodky"
 ],
 "Helper text": [
  null,
  "Pomocný text"
 ],
 "Hide API key": [
  null,
  "Skryť kľúč API"
 ],
 "Hide PIN": [
  null,
  "Skryť PIN"
 ],
 "Hide confirmed password": [
  null,
  "Skryť potvrdené heslo"
 ],
 "Hide passphrase": [
  null,
  "Skryť heslo"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "Hostname": [
  null,
  "Názov počítača"
 ],
 "How would you like to install?": [
  null,
  "Ako chcete inštalovať?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Rozumiem, že všetky existujúce údaje budú vymazané",
  "Rozumiem, že všetky existujúce údaje z vybraných diskov budú vymazané",
  "Rozumiem, že všetky existujúce údaje z vybraných diskov budú vymazané"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Rozumiem, že niektoré existujúce údaje budú vymazané"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Rozumiem, že niektoré oddiely budú upravené"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Ak je prázdny, názov počítača bude dočasný a nastavený podľa informácií zo siete."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Ak sa nehodí žiadna z vyššie uvedených možností, pred pokračovaním použite editor úložiska na vytvorenie vlastného rozdelenia diskov."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Ak konfigurujete oddiely, vyžaduje sa nasledovné:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Ak nesúhlasíte s automatickým odoslaním súboru s logom, môžete miesto toho $0. Manuálne hlásenie vám umožní preskúmať a vybrať, ktoré súbory s logom priložíte."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ak nechápete, alebo neakceptujete riziká, potom ukončite tento program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Ak váš problém zodpovedá jednej z vyššie uvedených chýb, môžete ju otvoriť a doplniť svoje informácie tam namiesto vytvárania duplicitného hlásenia."
 ],
 "In progress": [
  null,
  "Prebieha"
 ],
 "Initializing...": [
  null,
  "Inicializácia..."
 ],
 "Install": [
  null,
  "Inštalácia"
 ],
 "Installation completed": [
  null,
  "Inštalácia je dokončená"
 ],
 "Installation failed": [
  null,
  "Inštalácia zlyhala"
 ],
 "Installation method": [
  null,
  "Metóda inštalácie"
 ],
 "Installation of the system failed": [
  null,
  "Inštalácia systému zlyhala"
 ],
 "Installation of the system failed: $0": [
  null,
  "Inštalácia systému zlyhala: $0"
 ],
 "Installation type": [
  null,
  "Typ Inštalácie"
 ],
 "Installing": [
  null,
  "Inštaluje sa"
 ],
 "Insufficient disk space": [
  null,
  "Nedostatok miesta na disku"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Nesprávny PIN. Skúste to znova."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Zistená neplatná konfigurácia RAID. Ak je vaše RAID pole vytvorené priamo na diskoch, musí byť na poli vytvorená tabuľka oddielov. Ak je vaše RAID pole vytvorené na oddieloch, musí obsahovať jediný súborový systém alebo formát (napr. LVM PV). Akékoľvek existujúce oddiely na tomto poli budú ignorované."
 ],
 "Invalid hostname": [
  null,
  "Neplatný názov počítača"
 ],
 "Jump to first incomplete step": [
  null,
  "Preskočiť na prvý nedokončený krok"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Zachovať aktuálne rozloženie disku a využiť dostupné miesto na dual-boot s iným operačným systémom."
 ],
 "Keyboard": [
  null,
  "Klávesnica"
 ],
 "Keyboard layout during boot": [
  null,
  "Rozloženie klávesnice počas zavádzania systému"
 ],
 "Language": [
  null,
  "Jazyk"
 ],
 "Launch storage editor": [
  null,
  "Spustiť editor úložiska"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Ďalšie informácie o obmedzenom prístupe v konfigurácii"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Ponechajte obe polia pre heslo prázdne, ak chcete použiť prázdne heslo."
 ],
 "Location": [
  null,
  "Umiestnenie"
 ],
 "Locked devices": [
  null,
  "Zamknuté zariadenia"
 ],
 "Log in": [
  null,
  "Prihlásiť sa"
 ],
 "Make current": [
  null,
  "Nastaviť ako aktuálne"
 ],
 "Manual disk configuration": [
  null,
  "Manuálna konfigurácia disku"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manuálna konfigurácia disku: Priradenie bodov pripojenia"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Môže obsahovať písmená, číslice a pomlčky."
 ],
 "May need more free space": [
  null,
  "Môže byť potrebné viac voľného miesta"
 ],
 "Medium": [
  null,
  "Stredné"
 ],
 "Minimum of $0 required": [
  null,
  "Minimálne požadované $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Nesúlad medzi výberom preformátovania nadradeného a podradeného zariadenia."
 ],
 "Mount point": [
  null,
  "Bod pripojenia"
 ],
 "Mount point assignment": [
  null,
  "Priradenie bodov pripojenia"
 ],
 "Move down": [
  null,
  "Posunúť nadol"
 ],
 "Move up": [
  null,
  "Posunúť nahor"
 ],
 "Must be at least $0 characters": [
  null,
  "Musí mať aspoň $0 znakov"
 ],
 "My issue is different, continue": [
  null,
  "Môj problém je iný, pokračovať"
 ],
 "NTP Servers": [
  null,
  "NTP servery"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Needs at least $0": [
  null,
  "Potrebuje minimálne $0"
 ],
 "Network": [
  null,
  "Sieť"
 ],
 "Network Configuration": [
  null,
  "Sieťová konfigurácia"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Sieť nie je k dispozícii. Ak chcete nahlásiť problém, nakonfigurujte sieť v ponuke na hornej lište."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Sieť nie je k dispozícii. Ak chcete nahlásiť problém, nakonfigurujte sieť."
 ],
 "Network plugin failed": [
  null,
  "Zlyhal plugin siete"
 ],
 "Next": [
  null,
  "Ďalej"
 ],
 "No devices": [
  null,
  "Žiadne zariadenia"
 ],
 "No disks available": [
  null,
  "Žiadne dostupné disky"
 ],
 "No disks selected": [
  null,
  "Nie sú vybrané žiadne disky"
 ],
 "No keyboard layouts selected": [
  null,
  "Neboli vybrané žiadne rozloženia klávesnice"
 ],
 "No layouts selected yet": [
  null,
  "Zatiaľ neboli vybrané žiadne rozloženia"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Pre vybrané rozloženie klávesnice nemožno získať platnú mapu kláves VConsole. Vyberte iné rozloženie klávesnice."
 ],
 "Not enough available free space": [
  null,
  "Nedostatok dostupného voľného miesta"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Nedostatok voľného miesta na vybraných diskoch."
 ],
 "Not enough space on selected disks.": [
  null,
  "Nedostatok voľného miesta na vybraných diskoch."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Upozornenie: Toto je predčasné vydaný softvér, ktorý je určený iba na účely vývoja a testovania. Nepoužívajte tento softvér pre žiadnu kritickú prácu ani pre produkčné prostredia."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Otvoriť formulár zadania chyby v Bugzille"
 ],
 "Operating system": [
  null,
  "Operačný systém"
 ],
 "Options": [
  null,
  "Voľby"
 ],
 "Other keyboards": [
  null,
  "Ďalšie klávesnice"
 ],
 "Partitions (advanced)": [
  null,
  "Oddiely (pokročilé)"
 ],
 "Passphrase": [
  null,
  "Heslo"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Heslo sa nezhoduje s žiadnym zamknutým zariadením"
 ],
 "Passphrases must match": [
  null,
  "Heslá sa musia zhodovať"
 ],
 "Pending": [
  null,
  "Čakajúce"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Prosím, priložte súbor s logmi $0 k tomuto problému."
 ],
 "Please enter a PIN": [
  null,
  "Zadajte PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Vyberte aspoň jeden disk pre pokračovanie"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Nájdené potenciálne duplicitné chyby"
 ],
 "Powered by Anaconda": [
  null,
  "Poháňané Anacondou"
 ],
 "Pre-release": [
  null,
  "Predčasné vydanie"
 ],
 "Prefer to report manually? $0": [
  null,
  "Preferujete manuálne nahlásenie? $0"
 ],
 "Proceed with installation": [
  null,
  "Pokračovať v inštalácii"
 ],
 "Quit": [
  null,
  "Ukončiť"
 ],
 "Quit installer?": [
  null,
  "Ukončiť inštalátor?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Načítanie informácií o operačnom systéme zlyhalo."
 ],
 "Reading information about the computer failed.": [
  null,
  "Načítanie informácií o počítači zlyhalo."
 ],
 "Reading installer configuration failed.": [
  null,
  "Načítanie konfigurácie inštalátora zlyhalo."
 ],
 "Reading installer version information failed.": [
  null,
  "Načítanie informácií o verzii inštalátora zlyhalo."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Skutočný názov počítač môže obsahovať iba znaky, číslice, pomlčky (nie na začiatku alebo konci) a bodky"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Názov počítača musí mať 64 znakov alebo menej"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reštartujte do systému Windows, aby ste zmenšili oddiely šifrované BitLockerom. Uvoľnite aspoň $0 voľného miesta pre inštaláciu."
 ],
 "Reboot system?": [
  null,
  "Reštartovať systém?"
 ],
 "Reclaim additional space": [
  null,
  "Uvoľniť dodatočné miesto"
 ],
 "Reclaim space": [
  null,
  "Uvoľniť miesto"
 ],
 "Reclaim space (required)": [
  null,
  "Uvoľniť miesto (požadované)"
 ],
 "Recommended": [
  null,
  "Odporúčané"
 ],
 "Recommended partitions:": [
  null,
  "Odporúčané oddiely:"
 ],
 "Reformat": [
  null,
  "Preformátovať"
 ],
 "Reinstall Fedora": [
  null,
  "Preinštalovať Fedoru"
 ],
 "Remove": [
  null,
  "Odstrániť"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Odstrániť všetky oddiely na vybraných zariadeniach, vrátane existujúcich operačných systémov."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Odstráňte alebo zmeňte veľkosť existujúcich súborových systémov, aby ste uvoľnili miesto pre inštaláciu."
 ],
 "Remove server": [
  null,
  "Odstrániť server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Odstránenie súborového systému trvalo vymaže všetky údaje, ktoré obsahuje. Zmena veľkosti oddielu môže uvoľniť nevyužité miesto, ale nie je bez rizika. Uistite sa, že máte zálohy všetkého dôležitého pred tým, ako získate miesto späť."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Nahradiť aktuálnu inštaláciu, ale ponechať súbory v domovskom priečinku."
 ],
 "Report Issue": [
  null,
  "Nahlásiť problém"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Nahláste problém alebo poskytnite spätnú väzbu otvorením formulára zadania chyby v Bugzille $0."
 ],
 "Report issue": [
  null,
  "Nahlásiť problém"
 ],
 "Reporting issue...": [
  null,
  "Nahlasovanie problému..."
 ],
 "Required": [
  null,
  "Požadované"
 ],
 "Requirements": [
  null,
  "Požiadavky"
 ],
 "Rescan devices": [
  null,
  "Znovu preskúmať zariadenia"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Opätovné preskúmanie diskov zlyhalo."
 ],
 "Resize": [
  null,
  "Zmeniť veľkosť"
 ],
 "Resize partition": [
  null,
  "Zmeniť veľkosť oddielu"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Zmena veľkosti nasledujúcich oddielov z $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Obmedziť prístup k hláseniu"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Obmedzí prístup k hláseniu len pre skupinu $0. $1"
 ],
 "Return to installation": [
  null,
  "Návrat k inštalácii"
 ],
 "Return to storage editor": [
  null,
  "Návrat do editora úložiska"
 ],
 "Review and install": [
  null,
  "Skontrolovať a nainštalovať"
 ],
 "Root account has been configured": [
  null,
  "Účet root bol nakonfigurovaný"
 ],
 "Root account is enabled": [
  null,
  "Účet správcu je povolený"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Účet správcu je povolený, ale nebol nakonfigurovaný žiadny používateľský účet"
 ],
 "Root password has been set.": [
  null,
  "Heslo správcu bolo nastavené."
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Naskenujte QR kód svojím telefónom alebo navštívte:"
 ],
 "Search for a language": [
  null,
  "Hľadať jazyk"
 ],
 "Search for additional software": [
  null,
  "Vyhľadať ďalší softvér"
 ],
 "Search for an environment": [
  null,
  "Vyhľadať prostredie"
 ],
 "Search keyboard layout": [
  null,
  "Vyhľadať rozloženie klávesnice"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Zabezpečte svoje údaje pomocou šifrovania disku. Platí iba pre nové oddiely"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "Select a device": [
  null,
  "Vyberte zariadenie"
 ],
 "Select city": [
  null,
  "Vyberte mesto"
 ],
 "Select destination": [
  null,
  "Vyberte cieľ"
 ],
 "Select region": [
  null,
  "Vyberte región"
 ],
 "Selected (top = current)": [
  null,
  "Vybrané (hore = aktuálne)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Formát vybraného zariadenia '$0' nie je možné preformátovať."
 ],
 "Send us feedback on your installation": [
  null,
  "Pošlite nám spätnú väzbu o vašej inštalácii"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server nie je dostupný"
 ],
 "Set custom hostname": [
  null,
  "Nastaviť vlastný názov počítača"
 ],
 "Share disk with other operating systems": [
  null,
  "Zdieľať disk s inými operačnými systémami"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Zdieľať disk s inými operačnými systémami: $0"
 ],
 "Show AM/PM": [
  null,
  "Zobraziť AM/PM"
 ],
 "Show API key": [
  null,
  "Zobraziť kľúč API"
 ],
 "Show PIN": [
  null,
  "Zobraziť PIN"
 ],
 "Show confirmed password": [
  null,
  "Zobraziť potvrdené heslo"
 ],
 "Show passphrase": [
  null,
  "Zobraziť heslo"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "Software installation": [
  null,
  "Inštalácia softvéru"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Inštalácia softvéru: Konfigurácia úložiska je dokončená. Momentálne prebieha inštalácia softvéru do vášho zariadenia."
 ],
 "Software selection": [
  null,
  "Výber softvéru"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Pred pokračovaním je potrebné dokončiť niektoré kroky inštalácie."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Chýbajú niektoré požadované oddiely: $0"
 ],
 "Space": [
  null,
  "Miesto"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Storage configuration": [
  null,
  "Konfigurácia úložiska"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Konfigurácia úložiska: Momentálne prebieha konfigurácia úložiska."
 ],
 "Storage editor": [
  null,
  "Editor úložiska"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Úložisko je založené na konfigurácii z 'Upraviť úložisko'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Rozloženie úložiska je definované súborom kickstart. Plánované rozloženie oddielov si môžete prezrieť v kroku s prehľadom."
 ],
 "Storage plugin failed": [
  null,
  "Zlyhal plugin úložiska"
 ],
 "Storage requirements not met": [
  null,
  "Požiadavky na úložisko neboli splnené"
 ],
 "Strong": [
  null,
  "Silné"
 ],
 "Successfully installed": [
  null,
  "Úspešne nainštalované"
 ],
 "Successfully unlocked $0.": [
  null,
  "Úspešne odomknuté $0."
 ],
 "Suggested keyboards": [
  null,
  "Navrhované klávesnice"
 ],
 "Suggested languages": [
  null,
  "Odporúčané jazyky"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System configuration": [
  null,
  "Konfigurácia systému"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Konfigurácia systému: Inštalácia softvéru je dokončená. Momentálne prebieha konfigurácia systému."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Inštalácia Anacondy sa neočakávane zastavila."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Nasledujúce otvorené chyby môžu súvisieť s vaším problémom. Pred vytvorením nového hlásenie si ich prosím prezrite."
 ],
 "The following user will be created:": [
  null,
  "Bude vytvorený nasledujúci používateľ:",
  "Budú vytvorení nasledujúci používatelia:",
  "Budú vytvorení nasledujúci používatelia:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Inštalácia vyžaduje $0 miesta na disku, ale kapacita vybraných diskov je však iba $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Inštalátor nemôže pokračovať kvôli kritickej chybe."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Inštalátor nemôže pokračovať kvôli kritickej chybe: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Heslo, ktoré ste zadali, obsahuje znaky mimo kódovania ASCII. Možno nebudete schopný pri jeho zadávaní prepínať medzi rozloženiami klávesnice."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Vybrané predvolené rozloženie klávesnice nepodporuje znaky ASCII. Ako predvolené vyberte rozloženie, ktoré podporuje znaky ASCII."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Editor úložiska umožňuje zmeniť veľkosť, odstrániť a vytvoriť oddiely. Umožňuje nastaviť LVM a oveľa viac. Je určený na použitie ako pokročilý nástroj a nie je určený na použitie v typickej inštalácii."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Tieto súbory s logmi môžu obsahovať citlivé informácie, ako sú IP adresy, používateľské mená alebo ďalšie systémové údaje."
 ],
 "This hostname can't be submitted": [
  null,
  "Tento názov počítača nie je možné nastaviť"
 ],
 "This is unstable, pre-release software": [
  null,
  "Toto je nestabilný, predčasne uvoľnený softvér"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Toto rozloženie sa použije na odomknutie vášho systému pri zavádzaní systému"
 ],
 "This may take a moment": [
  null,
  "Môže to chvíľu trvať"
 ],
 "This will take a few moments": [
  null,
  "Chvíľu to potrvá"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Timezone": [
  null,
  "Časové pásmo"
 ],
 "Title": [
  null,
  "Nadpis"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Ak chcete začať používať $0, reštartujte svoj systém."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Ak chcete pokračovať, vyberte zariadenia, na ktoré chcete inštalovať."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Aby ste mohli použiť túto možnosť, zmeňte veľkosť alebo odstráňte existujúce oddiely, aby ste uvoľnili aspoň $0."
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Nepodarilo sa naplánovať odstránenie $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Nepodarilo sa naplánovať zmenu veľkosti $0"
 ],
 "Undo last action": [
  null,
  "Vrátiť poslednú akciu"
 ],
 "Unlock": [
  null,
  "Odomknúť"
 ],
 "Unlock encrypted devices": [
  null,
  "Odomknúť šifrované zariadenia"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Odomknite šifrované oddiely, aby ste si zachovali existujúce údaje a zobrazili viac metód inštalácie"
 ],
 "Use configured storage": [
  null,
  "Použiť nakonfigurované úložisko"
 ],
 "Use entire disk": [
  null,
  "Použiť celý disk"
 ],
 "Use free space": [
  null,
  "Použiť voľné miesto"
 ],
 "Use local account": [
  null,
  "Použiť lokálny účet"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Použiť RAID zariadenie pre automatické rozdelenie"
 ],
 "User creation": [
  null,
  "Vytvorenie používateľa"
 ],
 "User name": [
  null,
  "Používateľské meno"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Používateľské meno môže obsahovať iba: písmená a-z, číslice 0-9, pomlčku $0, bodku $1, podčiarkovník $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Používateľské meno nesmie byť rezervované slovo"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Používateľské meno musí byť kratšie ako 33 znakov"
 ],
 "Validating...": [
  null,
  "Overovanie..."
 ],
 "Weak": [
  null,
  "Slabé"
 ],
 "Welcome": [
  null,
  "Vitajte"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Vitajte vo Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Vitajte. Poďme teraz nainštalovať $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Keď odošlete toto hlásenie chyby, nasledujúce súbory s logmi sa automaticky odošlú: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Veľkosť oddielov Windows so šifrovaním BitLocker nie je možné zmeniť"
 ],
 "You can close this browser window now.": [
  null,
  "Toto okno prehliadača môžete teraz zatvoriť."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Tu môžete buď uvoľniť dostatok miesta a nechať inštalátor, aby sa postaral o zvyšok, alebo oddiely nastaviť manuálne."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Kľúč API pre svoj účet môžete vygenerovať v Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Aby ste mohli pokračovať, musíte povoliť účet správcu alebo vytvoriť lokálny používateľský účet."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Na povolenie automatického nastavenia dátumu a času musíte byť pripojení k sieti."
 ],
 "Your progress will not be saved.": [
  null,
  "Váš postup sa neuloží."
 ],
 "completed step": [
  null,
  "dokončený krok"
 ],
 "current step": [
  null,
  "aktuálny krok"
 ],
 "delete": [
  null,
  "odstrániť"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "encrypt": [
  null,
  "šifrovať"
 ],
 "encrypted": [
  null,
  "šifrované"
 ],
 "extended partition": [
  null,
  "rozšírený oddiel"
 ],
 "format as $0": [
  null,
  "naformátovať ako $0"
 ],
 "here": [
  null,
  "tu"
 ],
 "incomplete": [
  null,
  "nedokončené"
 ],
 "mount": [
  null,
  "pripojiť"
 ],
 "pending step": [
  null,
  "čakajúci krok"
 ],
 "report the issue manually": [
  null,
  "nahlásiť problém manuálne"
 ],
 "resized from $0": [
  null,
  "zmenená veľkosť z $0"
 ],
 "shrink": [
  null,
  "zmenšiť"
 ],
 "shrink to $0": [
  null,
  "zmenšiť na $0"
 ],
 "transient, will use DHCP": [
  null,
  "dočasné, bude použitý DHCP"
 ],
 "undo": [
  null,
  "späť"
 ]
});
