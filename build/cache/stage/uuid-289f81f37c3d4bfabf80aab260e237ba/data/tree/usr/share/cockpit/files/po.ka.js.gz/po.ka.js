cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "საწყისი"
 ],
 "Unable to create bookmark directory": [
  null,
  "სანიშნეების საქაღალდის შექმნა შეუძლებელია"
 ],
 "Unable to save bookmark file": [
  null,
  "სანიშნეს ფაილის შენახვა შეუძლებელია"
 ],
 "Remove from bookmarks": [
  null,
  "სანიშნეებიდან წაშლა"
 ],
 "Add to bookmarks": [
  null,
  "სანიშნეებში დამატება"
 ],
 "Bookmarks": [
  null,
  "სანიშნეები"
 ],
 "Bookmarked": [
  null,
  "ჩამატებულია სანიშნეებში"
 ],
 "Not bookmarked": [
  null,
  "სანიშნეებში არაა"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Edit path": [
  null,
  "ბილიკის ჩასწორება"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Largest size": [
  null,
  "უდიდესი ზომა"
 ],
 "Smallest size": [
  null,
  "უმცირესი ზომა"
 ],
 "Modified": [
  null,
  "შეცვლილია"
 ],
 "First modified": [
  null,
  "პირველი ცვლილება"
 ],
 "Last modified": [
  null,
  "ბოლო ცვლილება"
 ],
 "Owner": [
  null,
  "მფლობელი"
 ],
 "Owner ascending": [
  null,
  "მფლობელი აღმავალი"
 ],
 "Owner descending": [
  null,
  "მფლობელი დაღმავალი"
 ],
 "Permissions": [
  null,
  "წვდომები"
 ],
 "Most permissive": [
  null,
  "ყველაზე მეტი დაშვებით"
 ],
 "Least permissive": [
  null,
  "ყველაზე ნაკლები დაშვებით"
 ],
 "Show keyboard shortcuts": [
  null,
  "კლავიატურის მალსახმობების ჩვენება"
 ],
 "Filter directory": [
  null,
  "საქაღალდის ფილტრი"
 ],
 "Display as a list": [
  null,
  "სიის სახით ჩვენება"
 ],
 "Display as a grid": [
  null,
  "ბადის სახით ჩვენება"
 ],
 "Sort": [
  null,
  "დალაგება"
 ],
 "Hide hidden items": [
  null,
  "დამალული ელემენტების დამალვა"
 ],
 "Show hidden items": [
  null,
  "დამალული ელემენტების ჩვენება"
 ],
 "$0 files": [
  null,
  "$0 ფაილი"
 ],
 "Uploaded as $0, $1": [
  null,
  "ატვირთულია, როგორც $0.$1"
 ],
 "Replace file $0?": [
  null,
  "ჩავანაცვლო ფაილი $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "ფაილი იგივე სახელით \"$0\"-ში უკვე არსებობს. მისი ჩანაცვლება მის შემცველობას თავზე გადააწერს."
 ],
 "New file": [
  null,
  "ახალი ფაილი"
 ],
 "Original file on server": [
  null,
  "ორიგინალი ფაილი სერვერზე"
 ],
 "Apply this action to all conflicting files": [
  null,
  "ამ ქმედების გადატარება ყველა კონფლიქტურ ფაილზე"
 ],
 "Replace": [
  null,
  "ჩანაცვლება"
 ],
 "Keep original": [
  null,
  "ორიგინალის შენარჩუნება"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Failed": [
  null,
  "ჩავარდა"
 ],
 "Upload error": [
  null,
  "ატვირთვის შეცდომა"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "ატვირთული ფაილების საბოლოო სამიზნეზე გადატანა შეუძლებელია"
 ],
 "Cancelled": [
  null,
  "გაუქმებულია"
 ],
 "Cancelled upload of $0": [
  null,
  "$0-ის ატვირთვა შეწყდა"
 ],
 "File uploaded": [
  null,
  "ფაილი ატვირთულია"
 ],
 "Files uploaded": [
  null,
  "ფაილები ატვირთულია"
 ],
 "Change permissions": [
  null,
  "წვდომების შეცვლა"
 ],
 "Uploads": [
  null,
  "ატვირთვები"
 ],
 "Cancel upload of $0": [
  null,
  "$0-ის ატვირთვის შეწყვეტა"
 ],
 "Upload $0% completed": [
  null,
  "ატვირთვის $0% დასრულდა"
 ],
 "Upload": [
  null,
  "ატვირთვა"
 ],
 "None": [
  null,
  "არაფერი"
 ],
 "Execute-only": [
  null,
  "მხოლოდ-გამშვები"
 ],
 "Write-only": [
  null,
  "მხოლოდ-ჩაწერადი"
 ],
 "Write and execute": [
  null,
  "ჩაწერა და შესრულება"
 ],
 "Read-only": [
  null,
  "მხოლოდ-წასაკითხად"
 ],
 "Read and execute": [
  null,
  "წაკითხვა და გაშვება"
 ],
 "Read and write": [
  null,
  "წაკითხვა და ჩაწერა"
 ],
 "Read, write, and execute": [
  null,
  "წაკითხვა, ჩაწერა და გაშვება"
 ],
 "Block device": [
  null,
  "ბლოკური მოწყობილობა"
 ],
 "Character device": [
  null,
  "სიმბოლური მოწყობილობა"
 ],
 "Directory": [
  null,
  "საქაღალდე"
 ],
 "Named pipe": [
  null,
  "სახელიანი ფაიფი"
 ],
 "Symbolic link": [
  null,
  "სიმბმული"
 ],
 "Regular file": [
  null,
  "ჩვეულებრივი ფაილი"
 ],
 "Socket": [
  null,
  "სოკეტი"
 ],
 "Name cannot be empty": [
  null,
  "სახელი არ შეიძლება იყოს ცარიელი"
 ],
 "Name too long": [
  null,
  "სახელი ძალიან გრძელია"
 ],
 "Name cannot include a /": [
  null,
  "სახელი, არ შეიძლება, სიმბოლოს '/' შეიცავდეს"
 ],
 "Filename is the same as original name": [
  null,
  "ფაილის სახელი იგივეა, რაც საწყისი სახელი"
 ],
 "Directory with the same name exists": [
  null,
  "საქაღალდე იგივე სახელით უკვე არსებობს"
 ],
 "File exists": [
  null,
  "ფაილი არსებობს"
 ],
 "Pasting failed": [
  null,
  "ჩასმა ჩავარდა"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" არსებობს. ჩასმით მას თავზე არ გადაეწერება."
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Create directory": [
  null,
  "საქაღალდის შექმნა"
 ],
 "Create file": [
  null,
  "ფაილის შექმნა"
 ],
 "Edit permissions": [
  null,
  "წვდომების ჩასწორება"
 ],
 "Open in terminal": [
  null,
  "ტერმინალში გახსნა"
 ],
 "Open text file": [
  null,
  "ტექსტური ფაილის გახსნა"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Rename": [
  null,
  "გადარქმევა"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Download": [
  null,
  "გადმოწერა"
 ],
 "Create link": [
  null,
  "ბმულის შექმნა"
 ],
 "Drop files to upload": [
  null,
  "ასატვირთად დაყარეთ ფაილები"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "ფაილებს ვერ დაყრით, რადგან ფაილების ატვირთვა უკვე მიმდინარეობს"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Go up a directory": [
  null,
  "ზემო საქაღალდეზე გადასვლა"
 ],
 "Go back": [
  null,
  "უკან გადასვლა"
 ],
 "Go forward": [
  null,
  "წინ გადასვლა"
 ],
 "Activate selected item, enter directory": [
  null,
  "მონიშნული ელემენტის გააქტიურება საქაღალდეში შესვლა"
 ],
 "Rename selected file or directory": [
  null,
  "მონიშნული ფაილის ან საქაღალდის სახელის გადარქმევა"
 ],
 "Create new directory": [
  null,
  "ახალი საქაღალდის შექმნა"
 ],
 "Copy selected file or directory": [
  null,
  "მონიშნული ფაილის ან საქაღალდის კოპირება"
 ],
 "Paste file or directory": [
  null,
  "ფაილის ან საქაღალდის ჩასმა"
 ],
 "Select all": [
  null,
  "ყველას მონიშვნა"
 ],
 "Save current file": [
  null,
  "მიმდინარე ფაილის შენახვა"
 ],
 "Close editor": [
  null,
  "რედაქტორის დახურვა"
 ],
 "Keyboard shortcuts": [
  null,
  "კლავიატურის მალსახმობები"
 ],
 "Navigation": [
  null,
  "ნავიგაცია"
 ],
 "Editing": [
  null,
  "ჩასწორება"
 ],
 "Editor": [
  null,
  "რედაქტორი"
 ],
 "Force delete $0 items": [
  null,
  "$0 ელემენტის ნაძალადევი წაშლა"
 ],
 "Delete $0 items?": [
  null,
  "წავშალო $0 ელემენტი?"
 ],
 "Force delete file $0?": [
  null,
  "წავშალო ძალით ფაილი $0?"
 ],
 "Delete file $0?": [
  null,
  "წავშალო ფაილი $0?"
 ],
 "Force delete link $0?": [
  null,
  "წავშალო ძალით ბმული $0?"
 ],
 "Delete link $0?": [
  null,
  "წავშალო ბმული $0?"
 ],
 "Force delete directory $0?": [
  null,
  "წავშალო ძალით საქაღალდე $0?"
 ],
 "Delete directory $0?": [
  null,
  "წავშალო საქაღალდე $0?"
 ],
 "Force delete $0": [
  null,
  "$0-ის ნაძალადევი წაშლა"
 ],
 "Delete $0?": [
  null,
  "წავშალო $0?"
 ],
 "No access": [
  null,
  "წვდომის გარეშე"
 ],
 "Missing type": [
  null,
  "ნაკლული ტიპი"
 ],
 "Collapse": [
  null,
  "ჩამოშლა"
 ],
 "Show all files": [
  null,
  "ყველა ფაილის ჩვენება"
 ],
 "$0 permissions": [
  null,
  "$0 წვდომა"
 ],
 "Permissions for $0 files": [
  null,
  "წვდომები $0 ფაილისთვის"
 ],
 "Ownership": [
  null,
  "მფლობელობა"
 ],
 "Group": [
  null,
  "ჯგუფი"
 ],
 "Access": [
  null,
  "წვდომა"
 ],
 "Owner access": [
  null,
  "მფლობელის წვდომა"
 ],
 "Group access": [
  null,
  "ჯგუფის წვდომა"
 ],
 "Others access": [
  null,
  "სხვების წვდომა"
 ],
 "Security context": [
  null,
  "უსაფრთხოების კონტექსტი"
 ],
 "Set executable as program": [
  null,
  "პროგრამის გაშვებადად დაყენება"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change permissions for enclosed files": [
  null,
  "ჩასმული ფაილების წვდომების შეცვლა"
 ],
 "(original owner)": [
  null,
  "(ორიგინალი მფლობელი)"
 ],
 "keep original owners": [
  null,
  "ორიგინალი მფლობელების შენარჩუნება"
 ],
 "Paste as owner": [
  null,
  "ჩასმა მფლობელის სახელით"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "ჩასმული ფაილების მფლობელი განსხვავებულია. ნაგულისხმევად მფლობელობა შეიცვლება, რომ ის სამიზნე საქაღალდისას დაემთხვეს."
 ],
 "New owner": [
  null,
  "ახალი მფლობელი"
 ],
 "Overwrite": [
  null,
  "გადაწერა"
 ],
 "New filename": [
  null,
  "ახალი ფაილის სახელი"
 ],
 "New name": [
  null,
  "ახალი სახელი"
 ],
 "Rename $0?": [
  null,
  "გადავარქვა სახელი ფაილს $0?"
 ],
 "link to $0": [
  null,
  "ბმული $0-ზე"
 ],
 "Create link to $0": [
  null,
  "ბმულის შექმნა $0-მდე"
 ],
 "Target": [
  null,
  "სამიზნე"
 ],
 "Symlink name": [
  null,
  "სიმბმულის სახელი"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Absolute vs. Relative": [
  null,
  "აბსოლუტური vs ფარდობითი"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "აბსოლუტური სიმბმულები იდეალურია, როცა მიმართავთ ფაილებს, ან საქაღალდეებს, რომლის გადატანაც არ მოხდება. მაგ: სისტემური ფაილები."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "შედარებითი სიმბმულები სასარგებლოა, როცა ორივე, სიმბმულიც და სამიზნეც შეიძლება, ერთდროულად იქნეს გადაადგილებული. მაგალითად, როცა სახელს არქმევთ, ან გადაგაგაქვთ მშობელი საქაღალდე."
 ],
 "Absolute": [
  null,
  "აბსოლუტური"
 ],
 "Relative": [
  null,
  "შედარებითი"
 ],
 "The file has been removed on disk": [
  null,
  "ფაილი წაიშალა დისკიდან"
 ],
 "The existing file changed unexpectedly": [
  null,
  "არსებული ფაილი წარმატებით შეიცვალა"
 ],
 "Edit $0": [
  null,
  "$0-ის ჩასწორება"
 ],
 "View $0": [
  null,
  "$0-ის ნახვა"
 ],
 "The file has changed on disk": [
  null,
  "ფაილი შეიცვალა დისკზე"
 ],
 "Reload": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Ignore": [
  null,
  "დაიგნორება"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save changes?": [
  null,
  "შევინახო ცვლილებები?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "ფაილი წაიშალა მას შემდეგ, რაც გახსენით. შენახვა მას თავიდან შექმნის."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "ფაილი შეიცვალა დისკზე მას შემდეგ, რაც ის გახსენით"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0-ს აქვს შეუნახავი ცვლილებები, რომლებიც სამუდამოდ დაიკარგება, თუ არ შეინახავთ."
 ],
 "Discard": [
  null,
  "მოცილება"
 ],
 "File name": [
  null,
  "ფაილის სახელი"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Cannot create file in current directory": [
  null,
  "მიმდინარე საქაღალდეში ფაილის შექმნა შეუძლებელია"
 ],
 "Permission denied": [
  null,
  "წვდომა აკრძალულია"
 ],
 "Directory name cannot be empty": [
  null,
  "საქაღალდის სახელი ცარიელი ვერ იქნება"
 ],
 "Directory name too long": [
  null,
  "საქაღალდის სახელი ძალიან გრძელია"
 ],
 "Directory name cannot include a /": [
  null,
  "საქაღალდის სახელი, არ შეიძლება, სიმბოლოს '/' შეიცავდეს"
 ],
 "Directory name": [
  null,
  "საქაღალდის სახელი"
 ],
 "Directory owner": [
  null,
  "საქაღალდის მფლობელი"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "Clear filter": [
  null,
  "ფილტრის გასუფთავება"
 ],
 "Directory is empty": [
  null,
  "საქაღალდე ცარიელია"
 ],
 "$0 item is hidden": [
  null,
  "$0 ელემენტი დამალულია",
  "$0 ელემენტი დამალულია"
 ],
 "Folder": [
  null,
  "საქაღალდე"
 ],
 "File": [
  null,
  "ფაილი"
 ],
 "Others": [
  null,
  "სხვები"
 ],
 "$0 files selected": [
  null,
  "მონიშნულია $0 ფაილი"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "საქაღალდე შეიცავს $0 საქაღალდეს და $1 ფაილს"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "საქაღალდე შეიცავს $0 საქაღალდეს, $1 ფაილს და $2 დამალულ ფაილს"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ]
});
