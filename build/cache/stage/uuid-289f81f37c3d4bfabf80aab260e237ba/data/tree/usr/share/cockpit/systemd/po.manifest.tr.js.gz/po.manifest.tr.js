cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Hizmetler"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "time": [
  null,
  "saat"
 ],
 "date": [
  null,
  "tarih"
 ],
 "restart": [
  null,
  "yeniden başlat"
 ],
 "shut": [
  null,
  "kapat"
 ],
 "domain": [
  null,
  "etki alanı"
 ],
 "machine": [
  null,
  "makine"
 ],
 "operating system": [
  null,
  "işletim sistemi"
 ],
 "os": [
  null,
  "is"
 ],
 "asset tag": [
  null,
  "demirbaş etiketi"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "güç"
 ],
 "version": [
  null,
  "sürüm"
 ],
 "host": [
  null,
  "anamakine"
 ],
 "hardware": [
  null,
  "donanım"
 ],
 "mitigation": [
  null,
  "azaltma"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "bellek"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "seri"
 ],
 "graphs": [
  null,
  "grafikler"
 ],
 "metrics": [
  null,
  "ölçümler"
 ],
 "history": [
  null,
  "geçmiş"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "diskler"
 ],
 "network": [
  null,
  "ağ"
 ],
 "cgroups": [
  null,
  "cgruplar"
 ],
 "performance": [
  null,
  "performans"
 ],
 "Configuring system settings": [
  null,
  "Sistem ayarlarını yapılandırma"
 ],
 "service": [
  null,
  "hizmet"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "hedef"
 ],
 "socket": [
  null,
  "soket"
 ],
 "timer": [
  null,
  "zamanlayıcı"
 ],
 "path": [
  null,
  "yol"
 ],
 "unit": [
  null,
  "birim"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "önyükleme"
 ],
 "mask": [
  null,
  "maskele"
 ],
 "unmask": [
  null,
  "maskelemeyi kaldır"
 ],
 "enable": [
  null,
  "etkinleştir"
 ],
 "disable": [
  null,
  "etkisizleştir"
 ],
 "Managing services": [
  null,
  "Hizmetleri yönetme"
 ],
 "journal": [
  null,
  "günlük"
 ],
 "warning": [
  null,
  "uyarı"
 ],
 "error": [
  null,
  "hata"
 ],
 "debug": [
  null,
  "hata ayıklama"
 ],
 "crash": [
  null,
  "çökme"
 ],
 "coredump": [
  null,
  "çekirdek dökümü"
 ],
 "Reviewing logs": [
  null,
  "Günlükleri gözden geçirme"
 ],
 "console": [
  null,
  "konsol"
 ],
 "command": [
  null,
  "komut"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "kabuk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
