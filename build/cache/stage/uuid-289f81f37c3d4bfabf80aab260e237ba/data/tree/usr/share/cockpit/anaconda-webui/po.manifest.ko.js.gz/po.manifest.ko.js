cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "아나콘다"
 ]
});
