cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Server": [
  null,
  "서버"
 ],
 "Services": [
  null,
  "서비스"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "Firewall": [
  null,
  "방화벽"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Copied": [
  null,
  "복사됨"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Details": [
  null,
  "상세정보"
 ],
 "Public key": [
  null,
  "공개 키"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Edit": [
  null,
  "편집"
 ],
 "Select": [
  null,
  "선택"
 ],
 "Unexpected error": [
  null,
  "예상치 못한 오류"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit이 설치되어 있지 않습니다"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "호환 가능한 Cockpit 버전이 $0 에서 설치되지 않았습니다."
 ],
 "Connect": [
  null,
  "연결"
 ],
 "Add": [
  null,
  "추가"
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "Trust and add host": [
  null,
  "호스트 신뢰 및 추가"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0 에서 다음을 실행합니다:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "만약 지문이 일치하면, '키 ' 호스트 신뢰 및 추가'를 눌러주세요. 그렇지 않다면, 연결하지 않고 관리자에게 문의하세요."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "결과 지문은 전자우편을 포함하는 공개 방식을 통해 공유되어도 해도 좋습니다. 만약 누군가 당신을 위해 인증하도록 요청하는 경우, 어떤 방식을 사용하든 결과를 전송 할 수 있습니다."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0 에 연결됩니다."
 ],
 "Verify fingerprint": [
  null,
  "지문 검증"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "신뢰하는 네트워크 또는 원격 장비에서 물리적으로 이와 같은 명령을 실행합니다:"
 ],
 "The fingerprint should match:": [
  null,
  "지문 표시가 일치해야 합니다:"
 ],
 "The password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "The key password can not be empty": [
  null,
  "키 비밀번호를 비워둘 수 없습니다"
 ],
 "The key passwords do not match": [
  null,
  "키 비밀번호가 일치하지 않습니다"
 ],
 "Log in to $0": [
  null,
  "$0 로 로그인"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 에 로그인 할 수 없습니다. 호스트는 비밀번호 로그인 또는 자신의 SSH 키를 허용하지 않습니다."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위한 SSH 키가 비밀번호에 의해 보호되고 있으며, 그리고 호스트는 비밀번호로 로그인을 허용 하지 않습니다. $1 에서 키의 비밀번호를 제공하세요."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위해 SSH 키가 보호되고 있습니다. 당신은 $1 에서 자신의 로그인 비밀번호에 의하거나 키의 비밀번호 제공을 통해 로그인 할 수 있습니다.."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "신규 SSH 키를 생성하고 승인합니다"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 에서 신규 SSH 키는 $1 에서($2 에 대해) 생성되고 $3 파일($4 의($5 에 대한))에 추가됩니다."
 ],
 "Key password": [
  null,
  "키 비밀번호"
 ],
 "Confirm key password": [
  null,
  "키 비밀빈호 확인"
 ],
 "Authorize SSH key": [
  null,
  "SSH 키 승인"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$1 의 SSH 키 $0 ($2 에서)는 $4 의 $3 ($5 에서)파일로 추가됩니다."
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "SSH key": [
  null,
  "SSH 키"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 키 $0 는 세션의 나머지 부분에서 사용 할 수 있고 다른 호스트에 로그인 할 때에도 사용 할 수 있습니다."
 ],
 "Disconnected": [
  null,
  "연결 해제됩니다"
 ],
 "Permission denied": [
  null,
  "권한이 거부되었습니다"
 ],
 "Clear input value": [
  null,
  "입력 값 초기화"
 ],
 "Invalid date format and invalid time format": [
  null,
  "잘못된 날짜 형식 및 잘못된 시간 형식"
 ],
 "Invalid time format": [
  null,
  "잘못된 시간 형식"
 ],
 "Invalid date format": [
  null,
  "잘못된 날짜 형식"
 ],
 "Cannot schedule event in the past": [
  null,
  "이전 이벤트를 예약할 수 없습니다"
 ],
 "No delay": [
  null,
  "지연 없음"
 ],
 "1 minute": [
  null,
  "1 분"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "20 minutes": [
  null,
  "20분"
 ],
 "40 minutes": [
  null,
  "40 분"
 ],
 "60 minutes": [
  null,
  "60 분"
 ],
 "Specific time": [
  null,
  "특정 시간"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Message to logged in users": [
  null,
  "로그인한 사용자에게 보내는 메세지"
 ],
 "Delay": [
  null,
  "지연"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Synchronized": [
  null,
  "동기화됩니다"
 ],
 "Synchronized with $0": [
  null,
  "$0 와 동기화됩니다"
 ],
 "Synchronizing": [
  null,
  "동기화 중"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 와 동기화를 시도 중입니다"
 ],
 "Not synchronized": [
  null,
  "동기화 되어 있지 않습니다"
 ],
 "Log messages": [
  null,
  "로그 메세지"
 ],
 "NTP server": [
  null,
  "NTP 서버"
 ],
 "Manually": [
  null,
  "수동"
 ],
 "Automatically using NTP": [
  null,
  "자동으로 NTP 사용"
 ],
 "Automatically using additional NTP servers": [
  null,
  "추가 NTP 서버를 자동으로 사용"
 ],
 "Automatically using specific NTP servers": [
  null,
  "특정 NTP 서버를 자동으로 사용"
 ],
 "Time zone": [
  null,
  "시간대"
 ],
 "Set time": [
  null,
  "시간 설정"
 ],
 "Invalid timezone": [
  null,
  "잘못된 시간대"
 ],
 "Need at least one NTP server": [
  null,
  "최소 하나의 NTP 서버가 필요합니다"
 ],
 "Change system time": [
  null,
  "시스템 시간 변경"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "Create $0": [
  null,
  "$0 생성"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "You now have administrative access.": [
  null,
  "이제 관리자 접근 권한이 있습니다."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "관리자 접근을 획득 할 수 있는 방법이 없습니다 (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "관리 접근 권한을 얻으려면 인증하세요"
 ],
 "Switch to administrative access": [
  null,
  "관리자 접근으로 전환"
 ],
 "Authenticate": [
  null,
  "인증"
 ],
 "Administrative access": [
  null,
  "관리 접근"
 ],
 "Problem becoming administrator": [
  null,
  "관리자에게서 발생한 문제"
 ],
 "Method": [
  null,
  "방식"
 ],
 "Limit access": [
  null,
  "접근 제한"
 ],
 "Switch to limited access": [
  null,
  "제한된 접근으로 전환"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "제한된 접근 방식은 관리 권한을 제한합니다. 웹 콘솔의 일부 부분은 기능이 축소됩니다."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "당신의 검색기는 세션을 통해 자신의 접근 수준을 기억합니다."
 ],
 "Limited access": [
  null,
  "제한된 접근"
 ],
 "Turn on administrative access": [
  null,
  "관리자 접근 켜기"
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Zone": [
  null,
  "영역"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "less than a minute ago": [
  null,
  "1분도 채 지나지 않아"
 ],
 "in less than a minute": [
  null,
  "1분도 안되어"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Strong password": [
  null,
  "강력한 비밀번호"
 ],
 "Acceptable password": [
  null,
  "허용되는 비밀번호"
 ],
 "Weak password": [
  null,
  "취약한 비밀번호"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "Show confirmation password": [
  null,
  "비밀번호 확인을 표시합니다"
 ],
 "Hide confirmation password": [
  null,
  "확인 비밀번호 숨기기"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "$0 will be installed.": [
  null,
  "$0 가 설치됩니다."
 ],
 "Install": [
  null,
  "설치"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 는 저장소에서 사용 할 수 없습니다."
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Unknown host: $0": [
  null,
  "알 수 없는 호스트: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 키 인증을 사용하여 $0 에 로그인 할 수 없습니다. 비밀번호를 입력하세요."
 ],
 "SSH key login": [
  null,
  "SSH 키 로그인"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit가 오류 코드 $0 를 보고했습니다"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "Row expansion": [
  null,
  "행 확장"
 ],
 "Row select": [
  null,
  "행 선택"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "붙임 오류"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "당신의 검색기는 내용 메뉴에서 붙여넣기를 허용하지 않습니다. Shift+Insert를 사용 할 수 있습니다."
 ],
 "Error during initialization": [
  null,
  "초기화 중에 오류"
 ],
 "Failed": [
  null,
  "실패함"
 ],
 "Home": [
  null,
  "홈"
 ],
 "Downloads": [
  null,
  "내려받기"
 ],
 "Not a directory": [
  null,
  "디렉토리가 아닙니다"
 ],
 "All files": [
  null,
  "모든 파일"
 ],
 "Recent": [
  null,
  "최근"
 ],
 "No recent directories": [
  null,
  "최근 디렉토리 없음"
 ],
 "No recent files": [
  null,
  "최근 파일 없음"
 ],
 "Type to filter": [
  null,
  "필터 입력"
 ],
 "File chooser actions": [
  null,
  "파일 선택기 작업"
 ],
 "Open in file browser": [
  null,
  "파일 검색기에서 열기"
 ],
 "Hide hidden files": [
  null,
  "숨겨진 파일을 숨깁니다"
 ],
 "Show hidden files": [
  null,
  "숨긴 파일 표시"
 ],
 "Filesystem": [
  null,
  "파일시스템"
 ],
 "Clear filters": [
  null,
  "필터 지우기"
 ],
 "Directory is empty": [
  null,
  "디렉토리가 비어 있습니다"
 ],
 "Directory has no sub-directories": [
  null,
  "디렉토리는 하위-디렉토리가 없습니다"
 ],
 "This directory contains only hidden files": [
  null,
  "이 디렉토리는 숨겨진 파일만 포함합니다"
 ],
 "No matching results": [
  null,
  "일치하는 결과를 찾을 수 없습니다"
 ],
 "Folder": [
  null,
  "폴더"
 ],
 "File": [
  null,
  "파일"
 ],
 "Copy to clipboard": [
  null,
  "클립보드로 복사"
 ],
 "Automation script": [
  null,
  "자동 스크립트"
 ],
 "Ansible": [
  null,
  "앤서블"
 ],
 "Create new task file with this content.": [
  null,
  "이 컨텐츠로 신규 작업 파일을 만듭니다."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 역할 문서"
 ],
 "Shell script": [
  null,
  "쉘 스크립트"
 ],
 "No system modifications": [
  null,
  "시스템 수정 없음"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "로그인한 사용자는 시스템 수정 사항을 볼 수 없습니다"
 ],
 "Loading system modifications...": [
  null,
  "시스템 수정을 불러오는 중..."
 ],
 "View automation script": [
  null,
  "자동 스크립트 보기"
 ],
 "Occurrences": [
  null,
  "발생"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "Other": [
  null,
  "기타"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "Rack mount chassis": [
  null,
  "랙 적재 구조"
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Present": [
  null,
  "존재"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen을 통한 메세지 제공시간이 초과되었습니다"
 ],
 "Not a valid private key": [
  null,
  "유효한 개인 키가 없습니다"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Invalid file permissions": [
  null,
  "잘못된 파일 권한"
 ],
 "Password not accepted": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Select an option": [
  null,
  "옵션을 선택합니다"
 ],
 "$0 killed with signal $1": [
  null,
  "$1 시그널에 의해 $0 가 종료되었습니다"
 ],
 "$0 exited with code $1": [
  null,
  "$0가 코드 $1로 종료됨"
 ],
 "$0 failed": [
  null,
  "$0 실패"
 ],
 "Your session has been terminated.": [
  null,
  "세션이 종료되었습니다."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "세션이 만료되었습니다. 다시 로그인하십시오."
 ],
 "Not permitted to perform this action.": [
  null,
  "이 작업을 실행할 수 있는 권한이 없습니다."
 ],
 "Login failed": [
  null,
  "로그인 실패"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "서버가 지원되는 방법을 사용하여 인증을 거부했습니다."
 ],
 "Untrusted host": [
  null,
  "지원되지 않는 호스트"
 ],
 "Host key is incorrect": [
  null,
  "호스트 키가 잘못되었습니다"
 ],
 "Internal error": [
  null,
  "내부 오류"
 ],
 "Connection has timed out.": [
  null,
  "연결 시간 초과."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "시스템에 Cockpit이 설치되어 있지 않습니다."
 ],
 "Cannot forward login credentials": [
  null,
  "로그인 정보를 전송할 수 없습니다"
 ],
 "Server has closed the connection.": [
  null,
  "서버 연결이 종료되었습니다."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit은 시스템의 소프트웨어와 호환성이 없습니다."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit을 지정된 호스트에 연결 할 수 없습니다."
 ],
 "Too much data": [
  null,
  "데이터가 너무 많습니다"
 ],
 "Priority": [
  null,
  "우선순위"
 ],
 "Description": [
  null,
  "설명"
 ],
 "Save": [
  null,
  "저장"
 ],
 "edit": [
  null,
  "편집"
 ],
 "None": [
  null,
  "없음"
 ],
 "Enabled": [
  null,
  "사용"
 ],
 "Disabled": [
  null,
  "사용 안함"
 ],
 "Generated": [
  null,
  "생성됨"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Start service": [
  null,
  "서비스 시작"
 ],
 "Status": [
  null,
  "상태"
 ],
 "Delete $0": [
  null,
  "$0 삭제"
 ],
 "Group": [
  null,
  "그룹"
 ],
 "Actions": [
  null,
  "동작"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Not available": [
  null,
  "사용 불가"
 ],
 "Ignore": [
  null,
  "무시"
 ],
 "Permanent": [
  null,
  "영구적"
 ],
 "Preserve": [
  null,
  "유지"
 ],
 "Random": [
  null,
  "임의"
 ],
 "Stable": [
  null,
  "안정적"
 ],
 "Use $0": [
  null,
  "$0 사용"
 ],
 "Failed to save settings": [
  null,
  "설정을 저장하는데 실패함"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "이와 같은 $0 를 생성하기는 서버와의 연결이 끊어지고 관리 UI를 사용 할 수 없게 합니다."
 ],
 "Create it": [
  null,
  "만들기"
 ],
 "Invalid prefix $0": [
  null,
  "잘못된 접두어 $0"
 ],
 "Invalid metric $0": [
  null,
  "잘못된 메트릭 $0"
 ],
 "Invalid address $0": [
  null,
  "잘못된 주소 $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "잘못된 접두어 또는 넷마스크 $0"
 ],
 "Testing connection": [
  null,
  "연결 시험 중"
 ],
 "Restoring connection": [
  null,
  "연결 복원 중"
 ],
 "Troubleshoot…": [
  null,
  "문제 해결…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager가 동작하지 않음"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager가 설치되어 있지 않습니다"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "네트워크 장치 및 그래프에는 NetworkManager가 필요합니다"
 ],
 "Enable service": [
  null,
  "서비스 활성화"
 ],
 "Network interface '$0' not found": [
  null,
  "네트워크 연결장치 '$0'를 찾을 수 없습니다"
 ],
 "Return to overview page": [
  null,
  "개요 부분으로 돌아가기"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "방화벽을 수정할 수있는 권한이 없습니다."
 ],
 "Not authorized to disable the firewall": [
  null,
  "방화벽을 비활성화할 권한이 없습니다"
 ],
 "Not authorized to enable the firewall": [
  null,
  "방화벽을 활성화할 권한이 없습니다"
 ],
 "Disable the firewall": [
  null,
  "방화벽 비활성화"
 ],
 "Enable the firewall": [
  null,
  "방화벽 활성화"
 ],
 "Edit service $0": [
  null,
  "서비스 $0 편집"
 ],
 "Remove service $0": [
  null,
  "$0 서비스 제거"
 ],
 "Included Services": [
  null,
  "포함된 서비스"
 ],
 "Additional port": [
  null,
  "추가 포트"
 ],
 "Remove additional port": [
  null,
  "추가 포트를 제거합니다"
 ],
 "Remove zone $0": [
  null,
  "$0 영역 제거"
 ],
 "Add services to zone $0": [
  null,
  "$0 영역에 서비스 추가"
 ],
 "Add services": [
  null,
  "서비스 추가"
 ],
 "Service": [
  null,
  "서비스"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 영역"
 ],
 "Interface": [
  null,
  "연결장치"
 ],
 "Allowed addresses": [
  null,
  "허용된 주소"
 ],
 "Entire subnet": [
  null,
  "전체 서브넷"
 ],
 "There are no active services in this zone": [
  null,
  "이 영역에는 활성 서비스가 없습니다"
 ],
 "Filter services": [
  null,
  "필터 서비스"
 ],
 "Failed to edit service": [
  null,
  "서비스 편집하는데 실패"
 ],
 "Failed to add port": [
  null,
  "포트를 추가하지 못했습니다"
 ],
 "Failed to add service": [
  null,
  "서비스 추가 실패"
 ],
 "Unknown service name": [
  null,
  "알 수 없는 서비스 이름"
 ],
 "Invalid port number": [
  null,
  "잘못된 포트 번호"
 ],
 "Invalid range": [
  null,
  "잘못된 범위"
 ],
 "Range must be strictly ordered": [
  null,
  "범위의 순서를 준수해야 합니다"
 ],
 "Edit service": [
  null,
  "서비스 편집"
 ],
 "Edit custom service in $0 zone": [
  null,
  "$0 영역에서 사용자 정의 서비스 편집"
 ],
 "Add ports": [
  null,
  "포트 추가"
 ],
 "Add ports to $0 zone": [
  null,
  "$0 영역에 포트 추가"
 ],
 "Add services to $0 zone": [
  null,
  "$0 영역에 서비스 추가"
 ],
 "Custom ports": [
  null,
  "사용자 지정 포트"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "예: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "쉼표로-구분된 포트, 범위, 서비스가 허용됩니다"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "예: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "만약 비워져 있으면, ID는 연관된 포트 서비스와 포트 번호를 기반으로 발생합니다"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "사용자 지정 포트를 추가하면 방화벽이 다시 적재됩니다. 방화벽을 다시 적재하면 런타임 전용 설정이 손실됩니다!"
 ],
 "Failed to add zone": [
  null,
  "영역 추가 실패"
 ],
 "Add zone": [
  null,
  "영역 추가"
 ],
 "Trust level": [
  null,
  "신뢰 단계"
 ],
 "Sorted from least to most trusted": [
  null,
  "신뢰도가 가장 낮은 순에서 가장 높은 순으로 정렬"
 ],
 "Custom zones": [
  null,
  "사용자 지정 영역"
 ],
 "No description available": [
  null,
  "사용 가능한 설명 없음"
 ],
 "Included services": [
  null,
  "포함된 서비스"
 ],
 "The cockpit service is automatically included": [
  null,
  "cockpit 서비스가 자동으로 포함됩니다"
 ],
 "Interfaces": [
  null,
  "연결장치"
 ],
 "Range": [
  null,
  "범위"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "라우팅 프리픽스와 IP 주소. 쉼표로 여러 값을 구분합니다. 예시: 192.0.2.0/24, 2001 : db8 :: / 32"
 ],
 "Confirm removal of $0": [
  null,
  "$0 제거 확인"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "이 영역에는 Cockpit 서비스가 포함되어 있습니다. 이 영역이 현재 웹 콘솔 연결에 적용되지 않는지 확인하십시오."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "영역을 제거하면 영역 내의 모든 서비스가 제거됩니다."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cockpit 서비스 제거는 web 콘솔에 접근하지 못 할 수 있습니다. 이 영역이 현재 사용 중인 web 콘솔 연결에 적용되지 않는지 확인하십시오."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$1 영역에서 $0 서비스 제거"
 ],
 "Firewall is not available": [
  null,
  "방화벽을 사용 할 수 없습니다"
 ],
 "Please install the $0 package": [
  null,
  "$0 꾸러미를 설치해 주십시오"
 ],
 "Add a new zone": [
  null,
  "신규 영역 추가"
 ],
 "Add new zone": [
  null,
  "신규 영역 추가"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "기본적으로 들어오는 요청은 차단됩니다. 외부로 나가는 요청은 차단되지 않습니다."
 ],
 "Connected": [
  null,
  "연결됨"
 ],
 "Wireless": [
  null,
  "무선"
 ],
 "Wired": [
  null,
  "유선"
 ],
 "No networks found": [
  null,
  "네트워크를 찾을 수 없습니다"
 ],
 "No interface selected": [
  null,
  "선택된 연결장치가 없습니다"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "네트워크 연결장치를 선택하여 연결을 구성합니다."
 ],
 "SSID can not be empty": [
  null,
  "SSID는 비워두면 안됩니다"
 ],
 "Password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "Failed to connect": [
  null,
  "연결하는 데 실패함"
 ],
 "Check your password.": [
  null,
  "자신의 비밀번호 점검."
 ],
 "Connect to hidden network": [
  null,
  "숨긴 네트워크로 연결"
 ],
 "Connect to $0": [
  null,
  "$0 에 연결"
 ],
 "Network name": [
  null,
  "네트워크 이름"
 ],
 "Security": [
  null,
  "보안"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 개인"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 을 삭제하기는 서버와의 연결이 끊어지고 관리 UI를 사용 할 수 없게 합니다."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 을 켜면 서버와의 연결이 끊어지며 관리 UI를 사용 할 수 없게 됩니다."
 ],
 "Switch on $0": [
  null,
  "$0 켜기"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 를 끄면 서버와의 연결이 끊어지며 관리 UI를 사용 할 수 없게 됩니다."
 ],
 "Switch off $0": [
  null,
  "$0 끄기"
 ],
 "Bond": [
  null,
  "본드"
 ],
 "Team": [
  null,
  "팀"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "브릿지"
 ],
 "Unknown \"$0\"": [
  null,
  "알 수 없는 \"$0\""
 ],
 "Carrier": [
  null,
  "캐리어"
 ],
 "Yes": [
  null,
  "네"
 ],
 "No": [
  null,
  "아니오"
 ],
 "Inactive": [
  null,
  "비활성"
 ],
 "Unknown configuration": [
  null,
  "알 수 없는 설정"
 ],
 "Additional address $val": [
  null,
  "추가 주소 $val"
 ],
 "Address $val": [
  null,
  "주소 $val"
 ],
 "Gateway $gateway": [
  null,
  "게이트웨이 $gateway"
 ],
 "Additional DNS $val": [
  null,
  "추가 DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "추가 DNS 검색 도메인 $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS 검색 도메인 $val"
 ],
 "General": [
  null,
  "일반"
 ],
 "Connect automatically": [
  null,
  "자동으로 연결"
 ],
 "Automatic": [
  null,
  "자동"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP 모니터링"
 ],
 "Broken configuration": [
  null,
  "손상된 설정"
 ],
 "Team port": [
  null,
  "팀 포트"
 ],
 "Spanning tree protocol": [
  null,
  "스패닝 트리 통신규약"
 ],
 "Priority $priority": [
  null,
  "우선순위 $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "포워드 딜레이 $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Hello 타임 $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "최대 메세지 수명 $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "경로 비용 $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hairpin 모드"
 ],
 "Bridge port": [
  null,
  "브릿지 포트"
 ],
 "Parent $parent": [
  null,
  "부모 $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "와이어가드"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "네트워크 비밀번호가 저장되지 않았습니다. 이 네트워크 연결을 해제하고 다시 연결해주세요."
 ],
 "Failed to connect to $0": [
  null,
  "$0 로 연결하는 데 실패함"
 ],
 "secured": [
  null,
  "안전함"
 ],
 "open": [
  null,
  "개방"
 ],
 "Last connected: $0": [
  null,
  "최근 연결됨: $0"
 ],
 "Signal strength": [
  null,
  "신호 강도"
 ],
 "Not permitted to disconnect network": [
  null,
  "네트워크 해제를 허용하지 않습니다"
 ],
 "Disconnect": [
  null,
  "연결 끊김"
 ],
 "Not permitted to connect to network": [
  null,
  "네트워크 연결을 허용하지 않습니다"
 ],
 "Forget": [
  null,
  "무시"
 ],
 "$0 hidden network": [
  null,
  "$0 숨긴 네트워크"
 ],
 "Filter": [
  null,
  "필터"
 ],
 "Refresh": [
  null,
  "새로고침"
 ],
 "Available networks": [
  null,
  "가용 네트워크"
 ],
 "Network": [
  null,
  "네트워크"
 ],
 "Mode": [
  null,
  "방식"
 ],
 "Signal": [
  null,
  "신호"
 ],
 "Rate": [
  null,
  "비율"
 ],
 "Primary action": [
  null,
  "주요 동작"
 ],
 "Secondary actions": [
  null,
  "보조 동작"
 ],
 "Not permitted to configure network devices": [
  null,
  "네트워크 장치 구성을 허용하지 않습니다"
 ],
 "Enable or disable the device": [
  null,
  "장치 활성화 또는 비활성화"
 ],
 "This device cannot be managed here.": [
  null,
  "이 장치는 여기서 관리 할 수 없습니다."
 ],
 "Connection will be lost": [
  null,
  "연결이 끊어졌습니다"
 ],
 "Keep connection": [
  null,
  "계속 연결"
 ],
 "Invalid IP address: $0": [
  null,
  "잘못된 주소: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "잘못된 대상 주소: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "잘못된 게이트웨이 주소: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "잘못된 DNS 주소: $0"
 ],
 "Preparing": [
  null,
  "준비 중입니다"
 ],
 "Configuring": [
  null,
  "설정 중입니다"
 ],
 "Authenticating": [
  null,
  "인증 중입니다"
 ],
 "Configuring IP": [
  null,
  "IP 인증 중입니다"
 ],
 "Checking IP": [
  null,
  "IP확인 중입니다"
 ],
 "Waiting": [
  null,
  "대기 중입니다"
 ],
 "Active": [
  null,
  "활성"
 ],
 "Deactivating": [
  null,
  "비활성화 중 입니다"
 ],
 "Adhoc": [
  null,
  "애드훅"
 ],
 "Infra": [
  null,
  "인프라"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "매쉬"
 ],
 "No carrier": [
  null,
  "캐리어 없음"
 ],
 "Part of $0": [
  null,
  "$0 의 일부분"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "설정을 변경하면 서버와의 연결이 끊어지고, 관리 UI를 사용 할 수 없게 됩니다."
 ],
 "Change the settings": [
  null,
  "설정 변경"
 ],
 "Add bridge": [
  null,
  "브릿지 추가"
 ],
 "Edit bridge settings": [
  null,
  "브릿지 설정 편집"
 ],
 "Ports": [
  null,
  "포트"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "스패닝 트리 통신규약(STP)"
 ],
 "STP priority": [
  null,
  "STP 우선순위"
 ],
 "STP forward delay": [
  null,
  "STP 전송 지연"
 ],
 "STP hello time": [
  null,
  "STP Hello 타임"
 ],
 "STP maximum message age": [
  null,
  "STP 최대 메시지 보관 기간"
 ],
 "Round robin": [
  null,
  "라운드 로빈"
 ],
 "Active backup": [
  null,
  "활성 백업"
 ],
 "Load balancing": [
  null,
  "부하 분산"
 ],
 "Broadcast": [
  null,
  "브로트캐스트"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "수동"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP 핑"
 ],
 "NSNA ping": [
  null,
  "NSNA 핑"
 ],
 "Add team": [
  null,
  "팀 추가"
 ],
 "Edit team settings": [
  null,
  "팀 설정 편집"
 ],
 "Runner": [
  null,
  "실행자"
 ],
 "Balancer": [
  null,
  "벨런서"
 ],
 "Primary": [
  null,
  "주"
 ],
 "Link watch": [
  null,
  "연결 보기"
 ],
 "Link up delay": [
  null,
  "연결 동작 지연"
 ],
 "Link down delay": [
  null,
  "연결 종료 지연"
 ],
 "Ping interval": [
  null,
  "핑 간격"
 ],
 "Ping target": [
  null,
  "핑 대상"
 ],
 "Automatic (DHCP only)": [
  null,
  "자동(DHCP만)"
 ],
 "Link local": [
  null,
  "로컬 연결"
 ],
 "Manual": [
  null,
  "수동"
 ],
 "Shared": [
  null,
  "공유되었습니다"
 ],
 "Prefix length or netmask": [
  null,
  "접두 길이 또는 넷마스크"
 ],
 "Prefix length": [
  null,
  "접두 길이"
 ],
 "IPv4 settings": [
  null,
  "IPv4 설정"
 ],
 "IPv6 settings": [
  null,
  "IPv6 설정"
 ],
 "Addresses": [
  null,
  "주소"
 ],
 "Select method": [
  null,
  "선택 방법"
 ],
 "Add address": [
  null,
  "주소 추가"
 ],
 "Address": [
  null,
  "주소"
 ],
 "Remove item": [
  null,
  "항목 제거"
 ],
 "Gateway": [
  null,
  "게이트웨이"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "DNS 서버 추가"
 ],
 "DNS search domains": [
  null,
  "DNS 검색 도메인"
 ],
 "Add search domain": [
  null,
  "검색 DNS 추가"
 ],
 "Search domain": [
  null,
  "검색 도메인"
 ],
 "Routes": [
  null,
  "경로"
 ],
 "Add route": [
  null,
  "라우트 추가"
 ],
 "Metric": [
  null,
  "메트릭"
 ],
 "Enter a valid MAC address": [
  null,
  "유효한 MAC 주소를 입력하세요"
 ],
 "Ethernet MAC": [
  null,
  "이더넷 MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 네트워크"
 ],
 "Add VPN": [
  null,
  "VPN 추가"
 ],
 "Add bond": [
  null,
  "본드 추가"
 ],
 "Add VLAN": [
  null,
  "VLAN 추가"
 ],
 "Edit rules and zones": [
  null,
  "규칙 및 영역 편집"
 ],
 "$0 active zone": [
  null,
  "$0 활성 영역"
 ],
 "Managed interfaces": [
  null,
  "관리 연결장치"
 ],
 "IP address": [
  null,
  "IP 주소"
 ],
 "Sending": [
  null,
  "전송중"
 ],
 "Receiving": [
  null,
  "수신중"
 ],
 "Unmanaged interfaces": [
  null,
  "관리하지 않는 연결장치"
 ],
 "Network logs": [
  null,
  "네트워크 기록"
 ],
 "Addresses are not formatted correctly": [
  null,
  "주소가 올바른 형식이 아닙니다"
 ],
 "Invalid IP address '$0'": [
  null,
  "잘못된 IP 주소 '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools 꾸러미는 이 설치되지 않았습니다"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "peer #$0 는 잘못된 종료점을 가지고 있습니다. host:port, 예제) 1.2.3.4:51820, [2001:db8::1]:51820 또는 example.com:51820처럼 지정되어야 합니다"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "장치(peer) #$0 는 잘못된 종료점을 가지고 있습니다. 포트는 숫자이어야 합니다."
 ],
 "Listen port must be a number": [
  null,
  "수신 포트는 숫자여야 합니다"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN 추가"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN를 편집합니다"
 ],
 "Private key": [
  null,
  "개인 키"
 ],
 "Paste existing key": [
  null,
  "기존 키를 붙입니다"
 ],
 "Regenerate": [
  null,
  "다시-생성합니다"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "공개 키는 유효한 개인 키가 입력 될 때에 생성됩니다"
 ],
 "Listen port": [
  null,
  "수신 포트"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "\"자동\"으로 설정됩니다"
 ],
 "IP addresses": [
  null,
  "IP 주소"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "다중 주소는 구분 기호로 쉼표(,) 또는 공백을 사용해 지정해야 합니다."
 ],
 "Peers": [
  null,
  "장치(peer)"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "장치(peer)는 이와 같은 장치에 연결되어 있는 다른 장비입니다. 다른 장비에서 공용 키는 서로 공유됩니다."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"서버\"로 동작하는 종료점은 호스트:포트로 지정되어야 하며, 다시 말하면 공백으로 놔둘 수 있습니다."
 ],
 "Add peer": [
  null,
  "장치(peer) 추가"
 ],
 "Endpoint": [
  null,
  "종료점"
 ],
 "Allowed IPs": [
  null,
  "허용된 IP"
 ],
 "No peers added.": [
  null,
  "추가된 장치(peer)가 없습니다."
 ],
 "Edit VLAN settings": [
  null,
  "VLAN 설정 편집"
 ],
 "Parent": [
  null,
  "부모"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "전송중"
 ],
 "MTU must be a positive number": [
  null,
  "MTU는 양수여야 합니다"
 ],
 "Ethernet MTU": [
  null,
  "이더넷 MTU"
 ],
 "Set to": [
  null,
  "설정"
 ],
 "Team port settings": [
  null,
  "팀 포트 설정"
 ],
 "Sticky": [
  null,
  "끈적"
 ],
 "LACP key": [
  null,
  "LACP 키"
 ],
 "Bridge port settings": [
  null,
  "브릿지 포트 설정"
 ],
 "Path cost": [
  null,
  "경로 비용"
 ],
 "Hair pin mode": [
  null,
  "Hair pin 모드"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "적응형 전송 로드 밸런싱"
 ],
 "Adaptive load balancing": [
  null,
  "적응형 로드 밸런싱"
 ],
 "MII (recommended)": [
  null,
  "MII(권장 사항)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "본드 설정 편집"
 ],
 "Network bond": [
  null,
  "네트워크 본드"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "네트워크 본딩은 여러 네트워크 연결장치를 하나의 논리적 연결장치로 결합하여 처리량 또는 중복성을 증가시킵니다."
 ],
 "Link monitoring": [
  null,
  "연결 모니터링"
 ],
 "Monitoring interval": [
  null,
  "관리 주기"
 ],
 "Monitoring targets": [
  null,
  "관리 대상"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 을 제거하면 서버와의 연결이 끊어지고 관리 UI를 사용 할 수 없게 됩니다."
 ],
 "Remove $0": [
  null,
  "$0 삭제"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 을 추가하면 서버와의 연결이 끊어지고 관리 UI를 사용 할 수 없게 됩니다."
 ],
 "No interfaces available": [
  null,
  "사용 가능한 연결장치가 없습니다"
 ],
 "Add member": [
  null,
  "멤버 추가"
 ],
 "Interface members": [
  null,
  "연결장치 구성원"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 및 Firewalld의 Cockpit 구성"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "이와 같은 도구는 NetworkManager 및 Firewalld를 사용하여 bonds, bridges, teams, VLAN과 방화벽과 같은 네트워킹을 관리합니다. NetworkManager는 우분투 기본 systemd-netowrkd 및 데비안의 ifupdown 스크립트와는 호환되지 않습니다."
 ],
 "Manage storage": [
  null,
  "관리 저장소"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "이와 같은 도구는 파일시스템, LVM2 볼륨 그룹, 그리고 NFS 적재와 같은 로컬 저장소를 관리합니다."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "진단 및 지원 자료 수집 및 꾸러미"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "이와 같은 도구는 동작 중인 시스템에서 구성 및 진단 정보의 아카이브를 생성합니다. 아카이브는 기록 또는 추적 목적으로 로컬 또는 집중적으로 저장되거나 기술적 오류-찾기와 디버깅을 지원하기 위해 기술 지원 담당자, 개발자 또는 시스템 관리자에게 보낼 수 있습니다."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "보안이 향상된 리눅스 구성과 문제해결"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "이와 같은 도구는 SELinux 정책을 구성하고 정책 위반을 이해하고 해결하는데 도움을 줄 수 있습니다."
 ],
 "Collect kernel crash dumps": [
  null,
  "커널 충돌 덤프 수집"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "이와 같은 도구는 커널 충돌 덤프를 작성하도록 시스템을 구성합니다. 이는 \"로컬\" (디스크), \"ssh\" 및 \"nfs\" 덤프 대상을 지원합니다."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔로 관리"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔의 권한 작업을 수행하려면 인증이 필요합니다"
 ]
});
