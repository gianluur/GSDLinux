cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Delete $0?": [
  null,
  "حذف $0؟"
 ],
 "Force delete": [
  null,
  "حذف إجباري"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Must be a valid IP address": [
  null,
  "يجب أن يكةن عنوان IP صالحاً"
 ],
 "1 to 65535": [
  null,
  "1 إلى 65535"
 ],
 "Container port must not be empty": [
  null,
  "يجب ألا يكةن منفذ الحاوية فارغاً"
 ],
 "IP address": [
  null,
  "عنوان IP"
 ],
 "IP address help": [
  null,
  "مساعدة عنوان IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "إذا تم تعيين عنوان IP المضيف على 0.0.0.0.0 أو لم يتم تعيينه على الإطلاق، فسيتم ربط المنفذ بجميع عناوين IP على المضيف."
 ],
 "Host port": [
  null,
  "منفذ المضيف"
 ],
 "Host port help": [
  null,
  "مساعدة منفذ المضيف"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "إذا لم يتم تعيين منفذ المضيف، فسيتم تعيين منفذ الحاوية بشكل عشوائي على المضيف."
 ],
 "Container port": [
  null,
  "منفذ الحاوية"
 ],
 "Protocol": [
  null,
  "بروتوكول"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "إزالة العنصر"
 ],
 "Image name is required": [
  null,
  "اسم الصورة مطلوب"
 ],
 "Image name is not unique": [
  null,
  "اسم الصورة ليس فريداً"
 ],
 "Failed to commit container $0": [
  null,
  "فشل في إيداع الحاوية $0"
 ],
 "New image name": [
  null,
  "اسم صورة جديد"
 ],
 "Tag": [
  null,
  "علامة"
 ],
 "Author": [
  null,
  "آخر"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "على سبيل المثال، اسمك <yourname@example.com>"
 ],
 "Command": [
  null,
  "أمر"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Pause container when creating image": [
  null,
  "إيقاف الحاوية مؤقتاً عند إنشاء الصورة"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "تنسيق Docker مفيد عند مشاركة الصورة مع Docker أو Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "استخدام تنسيق Docker القديم"
 ],
 "Commit container": [
  null,
  "أودع حاوية"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "إنشاء صورة جديدة بناءً على الحالة الحالية للحاوية $0."
 ],
 "Commit": [
  null,
  "إيداع"
 ],
 "Force commit": [
  null,
  "فرض الإيداع"
 ],
 "Failed to force remove container $0": [
  null,
  "فشل في الإزالة الإجبارية للحاوية $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "سيؤدي حذف حاوية قيد التشغيل إلى مسح جميع البيانات الموجودة فيها."
 ],
 "Failed to stop container $0": [
  null,
  "فشل في إيقاف الحاوية $0"
 ],
 "Failed to start container $0": [
  null,
  "فشل بدء الحاوية $0"
 ],
 "Failed to resume container $0": [
  null,
  "فشل في استئناف الحاوية $0"
 ],
 "Failed to pause container $0": [
  null,
  "فشل في الإيقاف المؤقت للحاوية $0"
 ],
 "Failed to restart container $0": [
  null,
  "فشل في إعادة تشغيل الحاوية $0"
 ],
 "Rename": [
  null,
  "أعد التسمية"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Restart": [
  null,
  "أعد التشغيل"
 ],
 "Force stop": [
  null,
  "فرض الإيقاف"
 ],
 "Force restart": [
  null,
  "فرض إعادة التشغيل"
 ],
 "Pause": [
  null,
  "إيقاف مؤقَّت"
 ],
 "Resume": [
  null,
  "استئناف"
 ],
 "Checkpoint": [
  null,
  "نقطة الفحص"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Restore": [
  null,
  "استعادة"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Healthy": [
  null,
  "صحي"
 ],
 "Unhealthy": [
  null,
  "غير صحي"
 ],
 "Checking health": [
  null,
  "فحص الصحة"
 ],
 "Prune unused containers": [
  null,
  "تقليم الحاويات غير المستخدمة"
 ],
 "This browser does not support WebGL2.": [
  null,
  ""
 ],
 "View $0 logs": [
  null,
  "عرض سجلات $0"
 ],
 "not available": [
  null,
  "غير متوفر"
 ],
 "n/a": [
  null,
  "غير متاح"
 ],
 "$0% of $1 limit": [
  null,
  "$0 من $1 حد"
 ],
 "service": [
  null,
  "الخدمة"
 ],
 "system": [
  null,
  "النظام"
 ],
 "user:": [
  null,
  "المستخدم:"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Integration": [
  null,
  "تكامل"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "Console": [
  null,
  "وحدة تحكم"
 ],
 "Health check": [
  null,
  "صحة الفحص"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "Click to see published ports": [
  null,
  "انقر للاطلاع على المنافذ التي تم نشرها"
 ],
 "ports": [
  null,
  "المنافذ"
 ],
 "Click to see volumes": [
  null,
  "انقر لرؤية وحدات التخزين"
 ],
 "volumes": [
  null,
  "وحدات التخزين"
 ],
 "Container": [
  null,
  "حاوية"
 ],
 "Owner": [
  null,
  "المالك"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "No containers": [
  null,
  "لا حاويات"
 ],
 "No containers in this pod": [
  null,
  "لا حاويات في هذا الـ pod"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "No containers that match the current filter": [
  null,
  "لا توجد حاويات مطابقة لعامل التصفية الحالي"
 ],
 "No running containers": [
  null,
  "لا حاويات قيد التشغيل"
 ],
 "Show": [
  null,
  "عرض"
 ],
 "All": [
  null,
  "الكل"
 ],
 "Only running": [
  null,
  "التشغيل فقط"
 ],
 "Create pod": [
  null,
  "إنشاء pod"
 ],
 "Create container": [
  null,
  "إنشاء حاوية"
 ],
 "Containers": [
  null,
  "الحاويات"
 ],
 "Create container in pod": [
  null,
  "إنشاء حاوية ضمن pod"
 ],
 "pod": [
  null,
  "Pod"
 ],
 "Failed to restore container $0": [
  null,
  "فشل في إعادة تخزين الحاوية $0"
 ],
 "Restore container $0": [
  null,
  "استعادة الحاوية $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "الاحتفاظ بجميع ملفات نقاط التفتيش المؤقتة"
 ],
 "Restore with established TCP connections": [
  null,
  "الاستعادة مع اتصالات TCP القائمة"
 ],
 "Ignore IP address if set statically": [
  null,
  "تجاهل عنوان IP إذا تم تعيينه بشكل ثابت"
 ],
 "Ignore MAC address if set statically": [
  null,
  "تجاهل عنوان MAC إذا تم تعيينه بشكل ثابت"
 ],
 "Pod failed to be created": [
  null,
  "فشل إنشاء الـ Pod"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "أحرف غير صالحة. يمكن أن يحتوي الاسم فقط على أحرف وأرقام وعلامات ترقيم معينة (_ . -)."
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Pod name": [
  null,
  "اسم الـ Pod"
 ],
 "System": [
  null,
  "النظام"
 ],
 "User:": [
  null,
  "المستخدم:"
 ],
 "No ports exposed": [
  null,
  "لا توجد منافذ مكشوفة"
 ],
 "Port mapping": [
  null,
  "تعيين المنفذ"
 ],
 "Add port mapping": [
  null,
  "إضافة تخطيط المنفذ"
 ],
 "No volumes specified": [
  null,
  "لا وحدات تحزين محددة"
 ],
 "Volumes": [
  null,
  "وحدات التخزين"
 ],
 "Add volume": [
  null,
  "إضافة وحدة تخزين"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Type to filter…": [
  null,
  "نوع عامل التصفية…"
 ],
 "Container path must not be empty": [
  null,
  "بجب ألا يكون مسار الحاوية فارغاً"
 ],
 "Host path": [
  null,
  "مسار المضيف"
 ],
 "Container path": [
  null,
  "مسار الحاوية"
 ],
 "Mode": [
  null,
  "الطور"
 ],
 "Writable": [
  null,
  "قابل للكتابة"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "لا يوجد علامة"
 ],
 "Shared": [
  null,
  "مشتركة"
 ],
 "Private": [
  null,
  "خاص"
 ],
 "Read-write access": [
  null,
  "وصول القرآءة-الكتابة"
 ],
 "Read-only access": [
  null,
  "وصول القرآءة فقط"
 ],
 "Show less": [
  null,
  "عرض أقل"
 ],
 "Show more": [
  null,
  "أظهر المزيد"
 ],
 "Loading details...": [
  null,
  "جاري تحميل التفاصيل..."
 ],
 "Ports": [
  null,
  "المنافذ"
 ],
 "Environment variables": [
  null,
  "متغيرات البيئة"
 ],
 "Failed to download image $0:$1": [
  null,
  "فشل في تنزيل الصورة $0:$1"
 ],
 "Error message": [
  null,
  "رسالة خطأ"
 ],
 "unused": [
  null,
  "غير مستخدم"
 ],
 "$0 container": [
  null,
  "لا حاويات",
  "حاوية واحدة",
  "حاويتان",
  "$0 حاويات",
  "$0 حاوية",
  "$0 حاوية"
 ],
 "History": [
  null,
  "تاريخ"
 ],
 "Image": [
  null,
  "صورة"
 ],
 "Created": [
  null,
  "تم إنشاؤه"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "Disk space": [
  null,
  "مساحة القرص"
 ],
 "Used by": [
  null,
  "مستخدم من قبل"
 ],
 "No images": [
  null,
  "لا صور"
 ],
 "No images that match the current filter": [
  null,
  "لا صور تتطابق مع عامل التصفية الحالي"
 ],
 "Hide intermediate images": [
  null,
  "إخفاء الصور الوسيطة"
 ],
 "Show intermediate images": [
  null,
  "إظهار الصور الوسيطة"
 ],
 "Images": [
  null,
  "الصور"
 ],
 "$0 image total, $1": [
  null,
  "بلا صورة في المجموع، $1",
  "صورة واحدة في المجموع، $1",
  "صورتان في المجموع، $1",
  "$0 صور في المجموع، $1",
  "$0 صورة في المجموع، $1",
  "$0 صورة في المجموع، $1"
 ],
 "$0 unused image, $1": [
  null,
  "لا توجد صور غير مستخدمة، $1",
  "توجد صورة واحدة غير مستخدمة،$1",
  "توجد صورتان غير مستخدمتان، $1",
  "توجد $0 صور غير مستخدمة، $1",
  "توجد $0 صورة غير مستخدمة، $1",
  "توجد $0 صورة غير مستخدمة، $1"
 ],
 "Hide images": [
  null,
  "إخفاء الصور"
 ],
 "Show images": [
  null,
  "أظهر الصور"
 ],
 "Pulling": [
  null,
  "السحب"
 ],
 "Download new image": [
  null,
  "نزِّل صورة جديدة"
 ],
 "Pull all images": [
  null,
  "سحب جميع الصور"
 ],
 "Prune unused images": [
  null,
  "تلقيم الصور الغير مستخدمة"
 ],
 "Pull": [
  null,
  "اسحب"
 ],
 "Up since:": [
  null,
  "منذ:"
 ],
 "Exited": [
  null,
  "تم الخروج"
 ],
 "systemd service": [
  null,
  "خدمة systrmd"
 ],
 "View $0": [
  null,
  "عرض $0"
 ],
 "Gateway": [
  null,
  "البوّابة"
 ],
 "MAC address": [
  null,
  "عنوان MAC"
 ],
 "Latest checkpoint": [
  null,
  "‎آخر نقطة فحص"
 ],
 "No containers are using this image": [
  null,
  "لا حاويات تستخدم هذه الصورة"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "Loading logs...": [
  null,
  "جاري تحميل السجلات..."
 ],
 "Delete unused system images:": [
  null,
  "حذف صور النظام غير المستخدمة:"
 ],
 "Delete unused images of user $0:": [
  null,
  "حذف الصور غير المستخدمة للمستخدم $0:"
 ],
 "Failed to prune unused images": [
  null,
  "فشل تقليم الصور غير المستخدمة"
 ],
 "Pruning images": [
  null,
  "تلقيم الصور"
 ],
 "Prune": [
  null,
  "التقليم"
 ],
 "Failed to checkpoint container $0": [
  null,
  "فشل التحقق من الحاوية $0"
 ],
 "Checkpoint container $0": [
  null,
  "نقطة استعادة الحاوية $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "ترك التشغيل بعد كتابة نقطة التحقق على القرص"
 ],
 "Support preserving established TCP connections": [
  null,
  "دعم الحفاظ على اتصالات TCP المنشأة"
 ],
 "Failed to search for new images": [
  null,
  "فشل البحث عن صور جديدة"
 ],
 "Failed to search for images: $0": [
  null,
  "فشل في البحث عن الصور: $0"
 ],
 "Failed to search for images.": [
  null,
  "فشل في البحث عن الصور."
 ],
 "Search for an image": [
  null,
  "البحث عن صورة"
 ],
 "Search for": [
  null,
  "البحث عن"
 ],
 "Search by name or description": [
  null,
  "البحث عبر الاسم أو الوصف"
 ],
 "in": [
  null,
  "في"
 ],
 "All registries": [
  null,
  "كافة السجلات"
 ],
 "Searching...": [
  null,
  "يجري البحث..."
 ],
 "No images found": [
  null,
  "لا صور موجودة"
 ],
 "Start typing to look for images.": [
  null,
  "ابدأ الكتابة للبحث عن الصور."
 ],
 "No results for $0": [
  null,
  "لا تنائج لـ $0"
 ],
 "Retry another term.": [
  null,
  "إعادة تجربة المدة."
 ],
 "Download": [
  null,
  "نزِّل"
 ],
 "No action": [
  null,
  "لا حدث"
 ],
 "Container failed to be started": [
  null,
  "فشل بدء الحاوية"
 ],
 "Failed to clean up container": [
  null,
  "فشل في تنظيف الحاوية"
 ],
 "Container failed to be created": [
  null,
  "فشل إنشاء الحاوية"
 ],
 "downloading": [
  null,
  "التنزيل"
 ],
 "Failed to run container $0": [
  null,
  "فشل في تشغيل الحاوية $0"
 ],
 "Failed to create container $0": [
  null,
  "فشل في إنشاء الحاوية $0"
 ],
 "Failed to pull image $0": [
  null,
  "فشل في سحب الصورة $0"
 ],
 "Local images": [
  null,
  "الصور المحلية"
 ],
 "Name already in use": [
  null,
  "الاسم مستخدم بالفعل"
 ],
 "Search by registry": [
  null,
  "البحث عبر السجل"
 ],
 "Local": [
  null,
  "محلي"
 ],
 "Container name": [
  null,
  "اسم الحاوية"
 ],
 "Owner help": [
  null,
  "مساعدة المالك"
 ],
 "Ideal for running services": [
  null,
  "نموذجية لتشغيل الخدمات"
 ],
 "Resource limits can be set": [
  null,
  "يمكن تعيين حدود للموارد"
 ],
 "Checkpoint and restore support": [
  null,
  "دعم نقاط التحقق والاستعادة"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "يمكن تعيين المنافذ الأقل من 1024"
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "Ideal for development": [
  null,
  "نموذجية للتطوير"
 ],
 "Restricted by user account permissions": [
  null,
  "مقيد بصلاحيات حساب المستخدم"
 ],
 "Image selection help": [
  null,
  "المساعدة في تحديد صورة"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "مضيف[:منفذ]/[مستخدم]/ حاوية[:علامة]"
 ],
 "Example: $0": [
  null,
  "على سبيل المثال: $0"
 ],
 "Searching: $0": [
  null,
  "البحث: $0"
 ],
 "Search string or container location": [
  null,
  "سلسلة البحث أو موقع الحاوية"
 ],
 "Pull latest image": [
  null,
  "اسحب آخر صورة"
 ],
 "Entrypoint": [
  null,
  "نقطة الدخول"
 ],
 "With terminal": [
  null,
  "مع واجهة الطرفية"
 ],
 "Memory limit": [
  null,
  "حد الذاكرة"
 ],
 "Decrease memory": [
  null,
  "تقليل الذاكرة"
 ],
 "Increase memory": [
  null,
  "زيادة الذكرة"
 ],
 "Memory unit": [
  null,
  "وحدة الذاكرة"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "أسهم وحدة المعالجة المركزية (CPU)"
 ],
 "CPU Shares help": [
  null,
  "مساعدة أسهم وحدة المعالجة المركزية (CPU)"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "مشاركات وحدة المعالجة المركزية (CPU) تحدد أولوية تشغيل الحاويات. الأولوية الافتراضية هي 1024. الرقم الأعلى يعطي الأولوية لهذه الحاوية. الرقم الأقل يقلل من الأولوية."
 ],
 "Decrease CPU shares": [
  null,
  "تقليل مشاركة CPU"
 ],
 "Increase CPU shares": [
  null,
  "زيادة مشاركات وحدة المعالجة المركزية (CPU)"
 ],
 "Restart policy": [
  null,
  "سياسة إعادة التشغيل"
 ],
 "Restart policy help": [
  null,
  "تعليمات سياسة إعادة التشغيل"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "سياسة إعادة التشغيل المبتبعة عند إنهاء الحاويات. قد لا يعمل استخدام linger لبدء تشغيل الحاويات تلقائيًا في بعض الظروف، مثل عند استخدام ecryptfs أو systemd-homed-homed أو NFS أو 2FA على حساب مستخدم."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "سياسة إعادة التشغيل الواجب اتباعها عند إنهاء الحاويات."
 ],
 "No": [
  null,
  "لا"
 ],
 "On failure": [
  null,
  "عند الفشل"
 ],
 "Always": [
  null,
  "دائماً"
 ],
 "Maximum retries": [
  null,
  "الحد الأقصى لإعادة المحاولة"
 ],
 "Decrease maximum retries": [
  null,
  "تقليل الحد الأقصى لإعادة المحاولة"
 ],
 "Increase maximum retries": [
  null,
  "زيادة الحد الأقصى لإعادة المحاولة"
 ],
 "No environment variables specified": [
  null,
  "لم يتم تحديد متغيرات البيئة"
 ],
 "Add variable": [
  null,
  "إضافة متغير"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "الصق سطرًا واحدًا أو أكثر من أزواج المفتاح= القيمة في أي حقل للاستيراد الجماعي"
 ],
 "Interval": [
  null,
  "فترة زمنية"
 ],
 "Health check interval help": [
  null,
  "المساعدة في الفترات الفاصلة بين فحوصات الصحة"
 ],
 "Interval how often health check is run.": [
  null,
  "الفاصل الزمني لعدد المرات التي يتم فيها تشغيل فحص الصحة."
 ],
 "Decrease interval": [
  null,
  "تقليل الفترة"
 ],
 "Increase interval": [
  null,
  "زيادة الفترة الزمنية"
 ],
 "seconds": [
  null,
  "الثواني"
 ],
 "Timeout": [
  null,
  "المهلة الزمنية"
 ],
 "Health check timeout help": [
  null,
  "المساعدة في مهلة التحقق من الصحة"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "الحد الأقصى للوقت المسموح به لإكمال الفحص الصحي قبل اعتبار أن الفاصل الزمني فشل."
 ],
 "Decrease timeout": [
  null,
  "تقليل المهلة"
 ],
 "Increase timeout": [
  null,
  "زيادة المهلة الزمنية"
 ],
 "Start period": [
  null,
  "فترة البدء"
 ],
 "Health check start period help": [
  null,
  "المساعدة في فترة بدء الفحص الصحة"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "وقت التهيئة الأولية اللازم لتهيئة الحاوية للتمهيد."
 ],
 "Decrease start period": [
  null,
  "تقليل فترة البدء"
 ],
 "Increase start period": [
  null,
  "زيادة فترة البدء"
 ],
 "Retries": [
  null,
  "إعادة المحاولة"
 ],
 "Health check retries help": [
  null,
  "مساعدة إعادة محاولة التحقق من الصحة"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "عدد مرات إعادة المحاولة المسموح بها قبل اعتبار فحص الصحة غير صحي."
 ],
 "Decrease retries": [
  null,
  "تقليل عدد مرات إعادة المحاولة"
 ],
 "Increase retries": [
  null,
  "زيادة عدد مرات إعادة المحاولة"
 ],
 "When unhealthy": [
  null,
  "عندما تكون غير صحية"
 ],
 "Health failure check action help": [
  null,
  "المساعدة في إجراء التحقق من الفشل الصحي"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "الإجراء الذي يجب اتخاذه بمجرد انتقال الحاوية إلى حالة غير صحية."
 ],
 "Create container in $0": [
  null,
  "إنشاء حاوية في $0"
 ],
 "Create and run": [
  null,
  "إنشاء ثم تشغيل"
 ],
 "Description": [
  null,
  ""
 ],
 "Version": [
  null,
  ""
 ],
 "Links": [
  null,
  ""
 ],
 "Documentation": [
  null,
  ""
 ],
 "Tags": [
  null,
  "العلامات"
 ],
 "Created by": [
  null,
  "تم إنشاؤه بواسطة"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Comments": [
  null,
  "تعليقات"
 ],
 "Unable to load image history": [
  null,
  "غير قادر على تحميل تاريخ الصورة"
 ],
 "Key must not be empty": [
  null,
  "يجب ألا يكون المفتاح فارغاً"
 ],
 "Key must not begin with a digit": [
  null,
  "يجب ألا يبدأ المفتاح بعدد"
 ],
 "Key contains invalid characters": [
  null,
  "يحتوي المفتاح على أحرف غير صالحة"
 ],
 "Key": [
  null,
  "مفتاح"
 ],
 "Value": [
  null,
  "قيمة"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "Podman service failed": [
  null,
  "خدمة Podman تعطلت"
 ],
 "Troubleshoot": [
  null,
  "استكشاف الأخطاء وإصلاحها"
 ],
 "Failed to force remove image $0": [
  null,
  "فشل في الإزالة الإجبارية للصورة $0"
 ],
 "intermediate image": [
  null,
  "صورة وسيطة"
 ],
 "Failed to remove image $0": [
  null,
  "فشل في إزالة الصورة $0"
 ],
 "intermediate": [
  null,
  "وسيط"
 ],
 "Delete $0 image?": [
  null,
  "حذف الصورة $0؟"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "توجد عدة أوسمة لهذه الصورة. حدد الصور الموسومة لحذفها."
 ],
 "Delete image": [
  null,
  "حذف صورة"
 ],
 "Delete tagged images": [
  null,
  "حذف الصور الموسومة"
 ],
 "Container is not running": [
  null,
  "الحاوية لا تعمل"
 ],
 "Error occurred while connecting console": [
  null,
  "حدث خطأ أثناء توصيل وحدة التحكم"
 ],
 "Force delete pod $0?": [
  null,
  "تريد فرض حذف الـ pod: $0؟"
 ],
 "Delete pod $0?": [
  null,
  "حذف الـ pod $0؟"
 ],
 "An error occurred": [
  null,
  "حدث خطأ ما"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "ستتم إزالة الـ pod: $0 بشكل دائم."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "سيؤدي حذف هذا الـ pod إلى إزالة الحاويات التالية:"
 ],
 "Failed to start pod $0": [
  null,
  "فشل في بدء الـ pod: $0"
 ],
 "Failed to stop pod $0": [
  null,
  "فشل في إيقاف الـ pod: $0"
 ],
 "Failed to restart pod $0": [
  null,
  "فشل في إعادة تشغيل الـ pod: $0"
 ],
 "Failed to resume pod $0": [
  null,
  "فشل في استئناف الـ pod: $0"
 ],
 "Failed to pause pod $0": [
  null,
  "فشل في الإيقاف المؤقت للـ pod: $0"
 ],
 "Failed to prune unused containers": [
  null,
  "فشل تقليم الحاويات غير المستخدمة"
 ],
 "Removes selected non-running containers": [
  null,
  "أزل الحاويات المحددة التي ليست قيد التشغيل"
 ],
 "Pruning containers": [
  null,
  "تلقيم الحاويات"
 ],
 "Container name is required.": [
  null,
  "اسم الحاوية مطلوب."
 ],
 "Failed to rename container $0": [
  null,
  "فشل في إعادة تسمية الحاوية $0"
 ],
 "New container name": [
  null,
  "اسم حاوية جديد"
 ],
 "Rename container $0": [
  null,
  "إعادة تسمية الحاوية $0"
 ],
 "Paused": [
  null,
  "تم إيقافه مؤقتاً"
 ],
 "Stopped": [
  null,
  "تم إيقافه"
 ],
 "Removing": [
  null,
  "قيد الإزالة"
 ],
 "Configured": [
  null,
  "تم تكوينه"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "$0 second": [
  null,
  "$0 ثانية",
  "ثانية واحدة",
  "ثانيتان",
  "$0 ثوانِ",
  "$0 ثانية",
  "$0 ثانية"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Failing streak": [
  null,
  "سلسلة الإخفاق الممتالية"
 ],
 "Failed to run health check on container $0": [
  null,
  "فشل تشغيل فحص الحالة الصحية على الحاوية $0"
 ],
 "Run health check": [
  null,
  "شغَّل فحص الصحة"
 ],
 "Last 5 runs": [
  null,
  "آخر ٥ مرات تشغيل"
 ],
 "Started at": [
  null,
  "بدأ عند"
 ],
 "Passed health run": [
  null,
  "اجتازت اختبار الصحة"
 ],
 "Failed health run": [
  null,
  "فشل التشغيل الصحي"
 ],
 "Failed to remove container $0": [
  null,
  "فشل في إزالة الحاوية $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "سيؤدي حذف حاوية إلى مسح جميع البيانات الموجودة فيها."
 ]
});
