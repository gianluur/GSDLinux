cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "ບັນດາບໍລິການ"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "network": [
  null,
  "ເຄືອຂ່າຍ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "ອິນເຕີເຟສ"
 ],
 "bridge": [
  null,
  "ບຣິດ (bridge)"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "bond"
 ],
 "team": [
  null,
  "team"
 ],
 "port": [
  null,
  "ພອດ"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "ໄຟວໍ"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "ໂຊນ"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "ການຈັດການເນັດເວີກບອນ (bonds)"
 ],
 "Managing networking teams": [
  null,
  "ການຈັດການເນັດເວີກທີມ (teams)"
 ],
 "Managing networking bridges": [
  null,
  "ການຈັດການເນັດເວີກບຣິດ (bridges)"
 ],
 "Managing VLANs": [
  null,
  "ການຈັດການ VLAN"
 ],
 "Managing firewall": [
  null,
  "ການຈັດການໄຟວໍ"
 ]
});
