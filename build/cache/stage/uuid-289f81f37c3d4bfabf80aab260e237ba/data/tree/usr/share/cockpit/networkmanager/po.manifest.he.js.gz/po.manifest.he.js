cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Services": [
  null,
  "שירותים"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "network": [
  null,
  "רשת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "מנשק"
 ],
 "bridge": [
  null,
  "גשר"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "מאגד"
 ],
 "team": [
  null,
  "ציוות"
 ],
 "port": [
  null,
  "פתחה"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "חומת אש"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "אזור"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "ניהול מאגדי רשת"
 ],
 "Managing networking teams": [
  null,
  "ניהול ציוותי רשת"
 ],
 "Managing networking bridges": [
  null,
  "ניהול גישורי רשת"
 ],
 "Managing VLANs": [
  null,
  "ניהול VLANים"
 ],
 "Managing firewall": [
  null,
  "ניהול חומת אש"
 ]
});
