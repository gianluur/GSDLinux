cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Ștergeți $0?"
 ],
 "Force delete": [
  null,
  "Forțează ștergerea"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Must be a valid IP address": [
  null,
  "Trebuie să fie o adresă IP validă"
 ],
 "1 to 65535": [
  null,
  "1 - 65535"
 ],
 "Container port must not be empty": [
  null,
  "Portul containerului nu trebuie să fie gol"
 ],
 "IP address": [
  null,
  "Adresă IP"
 ],
 "IP address help": [
  null,
  "Ajutor pentru adresa IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Dacă adresa IP a gazdei este definită la 0.0.0.0 sau nu este definită deloc, portul va fi asociat tuturor adreselor IP de pe gazdă."
 ],
 "Host port": [
  null,
  "Portul gazdă"
 ],
 "Host port help": [
  null,
  "Ajutor pentru portul gazdă"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Dacă portul gazdă nu este definit, portului containerului i se va atribui aleatoriu un port pe gazdă."
 ],
 "Container port": [
  null,
  "Portul containerului"
 ],
 "Protocol": [
  null,
  "Protocol"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Elimină elementul"
 ],
 "Image name is required": [
  null,
  "Numele imaginii este obligatoriu"
 ],
 "Image name is not unique": [
  null,
  "Numele imaginii nu este unic"
 ],
 "Failed to commit container $0": [
  null,
  "Validarea containerului $0 a eșuat"
 ],
 "New image name": [
  null,
  "Nume nou pentru imagine"
 ],
 "Tag": [
  null,
  "Eticheta"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exemplu: Numele dvs. <numele_dvs@example.com>"
 ],
 "Command": [
  null,
  "Comandă"
 ],
 "Options": [
  null,
  "Opțiuni"
 ],
 "Pause container when creating image": [
  null,
  "Pune în pauză containerul la crearea imaginii"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Formatul Docker este util atunci când se partajează imaginea cu Docker sau Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Utilizează formatul Docker vechi"
 ],
 "Commit container": [
  null,
  "Validare container"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Creează o nouă imagine pe baza stării actuale a containerului $0."
 ],
 "Commit": [
  null,
  "Validare"
 ],
 "Force commit": [
  null,
  "Forțează validarea"
 ],
 "Failed to force remove container $0": [
  null,
  "Eliminarea forțată a containerului $0 a eșuat"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Ștergerea unui container care rulează va șterge toate datele din acesta."
 ],
 "Failed to stop container $0": [
  null,
  "Oprirea containerului $0 a eșuat"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Nu s-a reușit oprirea quadlet-ului $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Nu s-a reușit pornirea quadlet-ului $0"
 ],
 "Failed to start container $0": [
  null,
  "Pornirea containerului $0 a eșuat"
 ],
 "Failed to resume container $0": [
  null,
  "Reluarea containerului $0 a eșuat"
 ],
 "Failed to pause container $0": [
  null,
  "Punerea în pauză a containerului $0 a eșuat"
 ],
 "Failed to restart container $0": [
  null,
  "Repornirea containerului $0 a eșuat"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Nu s-a reușit repornirea quadlet-ului $0"
 ],
 "Rename": [
  null,
  "Redenumește"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Restart": [
  null,
  "Repornește"
 ],
 "Force stop": [
  null,
  "Forțează oprirea"
 ],
 "Force restart": [
  null,
  "Forțează repornirea"
 ],
 "Pause": [
  null,
  "Pauză"
 ],
 "Resume": [
  null,
  "Reluare"
 ],
 "Checkpoint": [
  null,
  "Punct de control"
 ],
 "Start": [
  null,
  "Pornire"
 ],
 "Restore": [
  null,
  "Restaurare"
 ],
 "Delete": [
  null,
  "Șterge"
 ],
 "Healthy": [
  null,
  "Funcționare excelentă"
 ],
 "Unhealthy": [
  null,
  "Funcționare defectuoasă"
 ],
 "Checking health": [
  null,
  "Verificarea stării de funcționare"
 ],
 "Prune unused containers": [
  null,
  "Elimină containerele neutilizate"
 ],
 "Terminal not available": [
  null,
  "Terminalul nu este disponibil"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Acest navigator nu are suport pentru WebGL2."
 ],
 "View $0 logs": [
  null,
  "Vizualizare $0 jurnale"
 ],
 "not available": [
  null,
  "nu este disponibilă"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "$0% of $1 limit": [
  null,
  "$0% din limita de $1"
 ],
 "service": [
  null,
  "serviciu"
 ],
 "system": [
  null,
  "sistem"
 ],
 "user:": [
  null,
  "utilizator:"
 ],
 "Details": [
  null,
  "Detalii"
 ],
 "Integration": [
  null,
  "Integrare"
 ],
 "Logs": [
  null,
  "Jurnale"
 ],
 "Console": [
  null,
  "Consolă"
 ],
 "Health check": [
  null,
  "Verificarea stării de funcționare"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memorie"
 ],
 "Click to see published ports": [
  null,
  "Faceți clic cu butonul mausului pentru a vedea porturile publicate"
 ],
 "ports": [
  null,
  "porturi"
 ],
 "Click to see volumes": [
  null,
  "Faceți clic cu butonul mausului pentru a vedea volumele"
 ],
 "volumes": [
  null,
  "volume"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Owner": [
  null,
  "Proprietar"
 ],
 "State": [
  null,
  "Stare"
 ],
 "Actions": [
  null,
  "Acțiuni"
 ],
 "No containers": [
  null,
  "Niciun container"
 ],
 "No containers in this pod": [
  null,
  "Nu există containere în această capsulă"
 ],
 "Loading...": [
  null,
  "Se încarcă…"
 ],
 "No containers that match the current filter": [
  null,
  "Nu există containere care să corespundă filtrului actual"
 ],
 "No running containers": [
  null,
  "Nu există containere în execuție"
 ],
 "Show": [
  null,
  "Afișează"
 ],
 "All": [
  null,
  "Toate"
 ],
 "Only running": [
  null,
  "Doar cele în execuție"
 ],
 "Create pod": [
  null,
  "Creează capsulă „pod”"
 ],
 "Create container": [
  null,
  "Creează container"
 ],
 "Containers": [
  null,
  "Containere"
 ],
 "Create container in pod": [
  null,
  "Creează container în capsulă „pod”"
 ],
 "pod": [
  null,
  "capsulă „pod”"
 ],
 "Failed to restore container $0": [
  null,
  "Restaurarea containerului $0 a eșuat"
 ],
 "Restore container $0": [
  null,
  "Restaurează containerul $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Păstrează toate fișierele temporare ale punctelor de control"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurează cu conexiunile TCP stabilite"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignoră adresa IP dacă este definită static"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignoră adresa MAC dacă este definită static"
 ],
 "Pod failed to be created": [
  null,
  "Crearea capsulei a eșuat"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caractere nevalide. Numele poate conține doar litere, cifre și anumite semne de punctuație (_ . -)."
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Pod name": [
  null,
  "Numele capsulei"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "User:": [
  null,
  "Utilizator:"
 ],
 "No ports exposed": [
  null,
  "Nu există porturi expuse"
 ],
 "Port mapping": [
  null,
  "Corespondența de porturi"
 ],
 "Add port mapping": [
  null,
  "Adaugă corespondența de porturi"
 ],
 "No volumes specified": [
  null,
  "Nu s-au specificat volume"
 ],
 "Volumes": [
  null,
  "Volume"
 ],
 "Add volume": [
  null,
  "Adaugă volum"
 ],
 "Create": [
  null,
  "Creează"
 ],
 "Type to filter…": [
  null,
  "Tastați pentru a filtra…"
 ],
 "Container path must not be empty": [
  null,
  "Ruta containerului nu trebuie să fie goală"
 ],
 "Host path": [
  null,
  "Ruta către gazdă"
 ],
 "Container path": [
  null,
  "Ruta containerului"
 ],
 "Mode": [
  null,
  "Mod"
 ],
 "Writable": [
  null,
  "Poate fi scris"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Fără etichetă"
 ],
 "Shared": [
  null,
  "Partajată"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Read-write access": [
  null,
  "Acces numai-pentru-scriere"
 ],
 "Read-only access": [
  null,
  "Acces numai-pentru-citire"
 ],
 "Show less": [
  null,
  "Afișează mai puțin"
 ],
 "Show more": [
  null,
  "Afișează mai mult"
 ],
 "Loading details...": [
  null,
  "Se încarcă detaliile..."
 ],
 "Ports": [
  null,
  "Porturi"
 ],
 "Environment variables": [
  null,
  "Variabile de mediu"
 ],
 "Failed to download image $0:$1": [
  null,
  "Nu s-a putut descărca imaginea $0:$1"
 ],
 "Error message": [
  null,
  "Mesaj de eroare"
 ],
 "unused": [
  null,
  "neutilizat"
 ],
 "$0 container": [
  null,
  "$0 container",
  "$0 containere",
  "$0 de containere"
 ],
 "History": [
  null,
  "Istoric"
 ],
 "Image": [
  null,
  "Imagine"
 ],
 "Created": [
  null,
  "Creat"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Spațiu pe disc"
 ],
 "Used by": [
  null,
  "Utilizat de"
 ],
 "No images": [
  null,
  "Nicio imagine"
 ],
 "No images that match the current filter": [
  null,
  "Nu există imagini care să corespundă filtrului actual"
 ],
 "Hide intermediate images": [
  null,
  "Ascunde imaginile intermediare"
 ],
 "Show intermediate images": [
  null,
  "Afișează imaginile intermediare"
 ],
 "Images": [
  null,
  "Imagini"
 ],
 "$0 image total, $1": [
  null,
  "$0 imagine în total, $1",
  "$0 imagini în total, $1",
  "$0 de imagini în total, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 imagine neutilizată, $1",
  "$0 imagini neutilizate, $1",
  "$0 de imagini neutilizate, $1"
 ],
 "Hide images": [
  null,
  "Ascunde imagini"
 ],
 "Show images": [
  null,
  "Afișează imagini"
 ],
 "Pulling": [
  null,
  "Se descarcă"
 ],
 "Download new image": [
  null,
  "Descărcați o imagine nouă"
 ],
 "Pull all images": [
  null,
  "Descarcă toate imaginile"
 ],
 "Prune unused images": [
  null,
  "Elimină imaginile neutilizate"
 ],
 "Pull": [
  null,
  "Descarcă"
 ],
 "Up since:": [
  null,
  "În funcțiune de:"
 ],
 "Exited": [
  null,
  "Terminat"
 ],
 "systemd service": [
  null,
  "serviciu systemd"
 ],
 "View $0": [
  null,
  "Vizualizare $0"
 ],
 "Gateway": [
  null,
  "Poartă de acces"
 ],
 "MAC address": [
  null,
  "Adresa MAC"
 ],
 "Latest checkpoint": [
  null,
  "Ultimul punct de control"
 ],
 "No containers are using this image": [
  null,
  "Niciun container nu utilizează această imagine"
 ],
 "Running": [
  null,
  "În execuție"
 ],
 "Loading logs...": [
  null,
  "Se încarcă jurnalele..."
 ],
 "Delete unused system images:": [
  null,
  "Şterge imaginile de sistem neutilizate:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Şterge imaginile neutilizate ale utilizatorului $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Eliminarea imaginilor neutilizate a eșuat"
 ],
 "Pruning images": [
  null,
  "Se elimină imaginile"
 ],
 "Prune": [
  null,
  "Eliminare"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Crearea punctului de control al containerului $0 a eșuat"
 ],
 "Checkpoint container $0": [
  null,
  "Punct de control container $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Lasă rularea să continue după scrierea punctului de control pe disc"
 ],
 "Support preserving established TCP connections": [
  null,
  "Suport pentru menținerea conexiunilor TCP stabilite"
 ],
 "Failed to search for new images": [
  null,
  "Căutarea de imagini noi a eșuat"
 ],
 "Failed to search for images: $0": [
  null,
  "Căutarea imaginilor a eșuat: $0"
 ],
 "Failed to search for images.": [
  null,
  "Căutarea imaginilor a eșuat."
 ],
 "Search for an image": [
  null,
  "Căută o imagine"
 ],
 "Search for": [
  null,
  "Căutare"
 ],
 "Search by name or description": [
  null,
  "Căutare după nume sau descriere"
 ],
 "in": [
  null,
  "în"
 ],
 "All registries": [
  null,
  "Toate registrele"
 ],
 "Searching...": [
  null,
  "Se caută..."
 ],
 "No images found": [
  null,
  "Nu s-au găsit imagini"
 ],
 "Start typing to look for images.": [
  null,
  "Începeți să tastați pentru a căuta imagini."
 ],
 "No results for $0": [
  null,
  "Nu s-au găsit rezultate pentru $0"
 ],
 "Retry another term.": [
  null,
  "Încercați cu un alt termen."
 ],
 "Download": [
  null,
  "Descărcare"
 ],
 "No action": [
  null,
  "Nicio acțiune"
 ],
 "Container failed to be started": [
  null,
  "Containerul nu a putut fi pornit"
 ],
 "Failed to clean up container": [
  null,
  "Ștergerea containerului a eșuat"
 ],
 "Container failed to be created": [
  null,
  "Crearea containerului a eșuat"
 ],
 "downloading": [
  null,
  "se descarcă"
 ],
 "Failed to run container $0": [
  null,
  "Execuția containerului $0 a eșuat"
 ],
 "Failed to create container $0": [
  null,
  "Crearea containerului $0 a eșuat"
 ],
 "Failed to pull image $0": [
  null,
  "Descărcarea imaginii $0 a eșuat"
 ],
 "Local images": [
  null,
  "Imagini locale"
 ],
 "Name already in use": [
  null,
  "Numele este deja utilizat"
 ],
 "Search by registry": [
  null,
  "Căutare după registru"
 ],
 "Local": [
  null,
  "Local"
 ],
 "Container name": [
  null,
  "Numele containerului"
 ],
 "Owner help": [
  null,
  "Ajutor pentru proprietar"
 ],
 "Ideal for running services": [
  null,
  "Ideal pentru rularea serviciilor"
 ],
 "Resource limits can be set": [
  null,
  "Se pot stabili limite pentru resurse"
 ],
 "Checkpoint and restore support": [
  null,
  "Suport pentru puncte de control și restaurare"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Porturile cu numere sub 1024 pot fi asociate"
 ],
 "User": [
  null,
  "Utilizator"
 ],
 "Ideal for development": [
  null,
  "Ideal pentru dezvoltare"
 ],
 "Restricted by user account permissions": [
  null,
  "Restricționat de permisiunile contului de utilizator"
 ],
 "Image selection help": [
  null,
  "Ajutor pentru selectarea imaginii"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "gazdă[:port]/[utilizator]/container[:etichetă]"
 ],
 "Example: $0": [
  null,
  "Exemplu: $0"
 ],
 "Searching: $0": [
  null,
  "Se caută: $0"
 ],
 "Search string or container location": [
  null,
  "Șir de căutare sau locația containerului"
 ],
 "Pull latest image": [
  null,
  "Descărcă cea mai recentă imagine"
 ],
 "Entrypoint": [
  null,
  "Punct de intrare"
 ],
 "With terminal": [
  null,
  "Cu terminal"
 ],
 "Memory limit": [
  null,
  "Limita memoriei"
 ],
 "Decrease memory": [
  null,
  "Reduce cantitatea de memorie"
 ],
 "Increase memory": [
  null,
  "Mărește cantitatea de memorie"
 ],
 "Memory unit": [
  null,
  "Unitatea de măsură a memoriei"
 ],
 "KB": [
  null,
  "Ko"
 ],
 "MB": [
  null,
  "Mo"
 ],
 "GB": [
  null,
  "Go"
 ],
 "CPU shares": [
  null,
  "Cotele de CPU"
 ],
 "CPU Shares help": [
  null,
  "Ajutor pentru cotele de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Cotele de CPU determină prioritatea containerelor aflate în execuție. Prioritatea implicită este 1024. O valoare mai mare acordă prioritate acestui container. O valoare mai mică reduce prioritatea."
 ],
 "Decrease CPU shares": [
  null,
  "Reducerea cotelor CPU"
 ],
 "Increase CPU shares": [
  null,
  "Augmentarea cotelor CPU"
 ],
 "Restart policy": [
  null,
  "Politica de repornire"
 ],
 "Restart policy help": [
  null,
  "Ajutor pentru politica de repornire"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Politica de repornire care trebuie urmată la închiderea containerelor. Utilizarea opțiunii „linger” pentru pornirea automată a containerelor s-ar putea să nu funcționeze în anumite circumstanțe, cum ar fi atunci când se utilizează ecryptfs, systemd-homed, NFS sau 2FA pe un cont de utilizator."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Politica de repornire care trebuie urmată la închiderea containerelor."
 ],
 "No": [
  null,
  "Nu"
 ],
 "On failure": [
  null,
  "În caz de eșec"
 ],
 "Always": [
  null,
  "Întotdeauna"
 ],
 "Maximum retries": [
  null,
  "Numărul maxim de reîncercări"
 ],
 "Decrease maximum retries": [
  null,
  "Reduce numărul maxim de reîncercări"
 ],
 "Increase maximum retries": [
  null,
  "Mărește numărul maxim de reîncercări"
 ],
 "No environment variables specified": [
  null,
  "Nu au fost specificate variabile de mediu"
 ],
 "Add variable": [
  null,
  "Adaugă variabilă"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Lipiți una sau mai multe linii de perechi cheie=valoare în orice câmp pentru importul în bloc"
 ],
 "Interval": [
  null,
  "Interval"
 ],
 "Health check interval help": [
  null,
  "Ajutor pentru intervalul verificării stării de funcționare"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervalul la care este rulată verificarea stării de funcționare."
 ],
 "Decrease interval": [
  null,
  "Reduce intervalul"
 ],
 "Increase interval": [
  null,
  "Mărește intervalul"
 ],
 "seconds": [
  null,
  "secunde"
 ],
 "Timeout": [
  null,
  "Timpul de așteptare"
 ],
 "Health check timeout help": [
  null,
  "Ajutor pentru timpul de așteptare a verificării stării de funcționare"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Timpul maxim permis pentru finalizarea verificării stării de sănătate înainte ca aceasta să fie considerată eșuată."
 ],
 "Decrease timeout": [
  null,
  "Reduce timpul de așteptare"
 ],
 "Increase timeout": [
  null,
  "Mărește timpul de așteptare"
 ],
 "Start period": [
  null,
  "Perioada de pornire"
 ],
 "Health check start period help": [
  null,
  "Ajutor pentru perioada de pornire a verificării stării de funcționare"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Timpul de inițializare necesar pentru pornirea unui container."
 ],
 "Decrease start period": [
  null,
  "Reduce perioada de pornire"
 ],
 "Increase start period": [
  null,
  "Mărește perioada de pornire"
 ],
 "Retries": [
  null,
  "Reîncercări"
 ],
 "Health check retries help": [
  null,
  "Ajutor pentru reîncercările de verificare a stării de funcționare"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Numărul de încercări permise înainte ca o verificare a stării de funcționare să fie considerată eșuată."
 ],
 "Decrease retries": [
  null,
  "Reduce numărul de reîncercări"
 ],
 "Increase retries": [
  null,
  "Mărește numărul de reîncercări"
 ],
 "When unhealthy": [
  null,
  "Când starea de funcționare nu este bună"
 ],
 "Health failure check action help": [
  null,
  "Ajutor pentru acțiunea de efectuat la eșecul verificării stării de funcționare"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Acțiunea de efectuat odată ce containerul trece într-o stare nedorită."
 ],
 "Create container in $0": [
  null,
  "Creează container în $0"
 ],
 "Create and run": [
  null,
  "Creează și execută"
 ],
 "Description": [
  null,
  "Descriere"
 ],
 "Version": [
  null,
  "Versiunea"
 ],
 "Links": [
  null,
  "Legături"
 ],
 "Documentation": [
  null,
  "Documentație"
 ],
 "Tags": [
  null,
  "Etichete"
 ],
 "Created by": [
  null,
  "Creat de"
 ],
 "Size": [
  null,
  "Dimensiune"
 ],
 "Comments": [
  null,
  "Comentarii"
 ],
 "Unable to load image history": [
  null,
  "Nu se poate încărca istoricul imaginilor"
 ],
 "Key must not be empty": [
  null,
  "Cheia nu trebuie să fie goală"
 ],
 "Key must not begin with a digit": [
  null,
  "Cheia nu trebuie să înceapă cu o cifră"
 ],
 "Key contains invalid characters": [
  null,
  "Cheia conține caractere nevalide"
 ],
 "Key": [
  null,
  "Cheie"
 ],
 "Value": [
  null,
  "Valoarea"
 ],
 "user": [
  null,
  "utilizator"
 ],
 "Podman service failed": [
  null,
  "Serviciul Podman a eșuat"
 ],
 "Troubleshoot": [
  null,
  "Soluționare probleme"
 ],
 "Failed to force remove image $0": [
  null,
  "Eliminarea forțată a imaginii $0 a eșuat"
 ],
 "intermediate image": [
  null,
  "imagine intermediară"
 ],
 "Failed to remove image $0": [
  null,
  "Eliminarea imaginii $0 a eșuat"
 ],
 "intermediate": [
  null,
  "intermediară"
 ],
 "Delete $0 image?": [
  null,
  "Ștergeți imaginea $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Există mai multe etichete asociate acestei imagini. Selectați imaginile etichetate pe care doriți să le ștergeți."
 ],
 "Delete image": [
  null,
  "Șterge imaginea"
 ],
 "Delete tagged images": [
  null,
  "Șterge imaginile etichetate"
 ],
 "Container is not running": [
  null,
  "Containerul nu este în execuție"
 ],
 "Error occurred while connecting console": [
  null,
  "A apărut o eroare la conectarea consolei"
 ],
 "Force delete pod $0?": [
  null,
  "Forțați ștergerea capsulei „pod” $0?"
 ],
 "Delete pod $0?": [
  null,
  "Ștergeți capsula $0?"
 ],
 "An error occurred": [
  null,
  "A apărut o eroare"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Capsula goală $0 va fi eliminată definitiv."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Ștergerea acestei capsule „pod” va elimina următoarele containere:"
 ],
 "Failed to start pod $0": [
  null,
  "Pornirea capsulei „pod” $0 a eșuat"
 ],
 "Failed to stop pod $0": [
  null,
  "Oprirea capsulei „pod” $0 a eșuat"
 ],
 "Failed to restart pod $0": [
  null,
  "Repornirea capsulei „pod” $0 a eșuat"
 ],
 "Failed to resume pod $0": [
  null,
  "Reluarea capsulei „pod” $0 a eșuat"
 ],
 "Failed to pause pod $0": [
  null,
  "Punerea în pauză a capsulei „pod” $0 a eșuat"
 ],
 "Failed to prune unused containers": [
  null,
  "Eliminarea containerele neutilizate a eșuat"
 ],
 "Removes selected non-running containers": [
  null,
  "Elimină containerele selectate care nu rulează"
 ],
 "Pruning containers": [
  null,
  "Se elimină containerele"
 ],
 "Container name is required.": [
  null,
  "Numele containerului este obligatoriu."
 ],
 "Failed to rename container $0": [
  null,
  "Redenumirea containerului $0 a eșuat"
 ],
 "New container name": [
  null,
  "Nume nou pentru container"
 ],
 "Rename container $0": [
  null,
  "Redenumește containerul $0"
 ],
 "Paused": [
  null,
  "În pauză"
 ],
 "Stopped": [
  null,
  "Oprit"
 ],
 "Removing": [
  null,
  "Se elimină"
 ],
 "Configured": [
  null,
  "Configurat"
 ],
 "Error": [
  null,
  "Eroare"
 ],
 "$0 second": [
  null,
  "$0 secundă",
  "$0 secunde",
  "$0 de secunde"
 ],
 "Status": [
  null,
  "Starea"
 ],
 "Failing streak": [
  null,
  "O serie de eșecuri"
 ],
 "Failed to run health check on container $0": [
  null,
  "Executarea verificării stării de funcționare pe containerul $0 a eșuat"
 ],
 "Run health check": [
  null,
  "Rulați verificarea stării de funcționare"
 ],
 "Last 5 runs": [
  null,
  "Ultimele 5 rulări"
 ],
 "Started at": [
  null,
  "A început la"
 ],
 "Passed health run": [
  null,
  "Executarea verificării stării de funcționare a avut succes"
 ],
 "Failed health run": [
  null,
  "Executarea verificării stării de funcționare a eșuat"
 ],
 "Failed to remove container $0": [
  null,
  "Eliminarea containerului $0 a eșuat"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Ștergerea unui container va șterge toate datele din acesta."
 ]
});
