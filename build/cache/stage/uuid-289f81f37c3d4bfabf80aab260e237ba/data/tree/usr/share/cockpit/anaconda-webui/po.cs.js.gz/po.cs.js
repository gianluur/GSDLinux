cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 chyba",
  "$0 chyby",
  "$0 chyb"
 ],
 "$0 installation": [
  null,
  "Instalace $0"
 ],
 "$0 installer": [
  null,
  "Instalátor $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 je rozšířený diskový oddíl MBR s logickými diskovými oddíly. Odstraněním všech logických oddílů dojde rovněž k automatickému odstranění tohoto rozšířeného oddílu."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Je zapotřebí $0, ale k dispozici je pouze $1."
 ],
 "$0 warning": [
  null,
  "$0 varování",
  "$0 varování",
  "$0 varování"
 ],
 "$0 will be deleted": [
  null,
  "$0 bude smazáno"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Souborový systém „$0“ nelze umístit na šifrované blokové zařízení"
 ],
 "'$0' must be assigned to $1": [
  null,
  "Je třeba, aby „$0“ bylo přiřazené k $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "Je třeba, aby „$0“ bylo na zařízení naformátovaném na „$1“"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "Je třeba, aby se „$0“ nacházelo na systémovém oddílu EFI. Zvolený oddíl používá souborový systém FAT, ale není označený jako ESP. Nastavte typ oddílu na EFI systém a povolte příznak esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Na MDRAID zařízení $1 nalezen oddíl „$0“. Oddíly pro zavaděč systému, nacházející se na MDRAID zařízeních, nejsou podporovány."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Standardní uživatelský účet s přístupem ke správě pro dělání změn týkajících systému jako celku."
 ],
 "Abort installation": [
  null,
  "Přerušit instalaci"
 ],
 "About": [
  null,
  "O aplikaci"
 ],
 "Account": [
  null,
  "Účet"
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "Add another server...": [
  null,
  "Přidat další server…"
 ],
 "Add mount": [
  null,
  "Přidat přípojný bod"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Doplňky pro vámi zvolené prostředí"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Doplňky, které nejsou specifické vámi využívanému prostředí"
 ],
 "Additional languages": [
  null,
  "Dodatečné jazyky"
 ],
 "Additional software for the selected environment": [
  null,
  "Doplňkový software pro vybrané prostředí"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Veškeré změny, učiněné v editoru úložiště, na něj budou okamžitě zapsány."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Budou odemknuta veškerá zařízení používající tuto heslovou frázi"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Stránka projektu Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Uplatnit přiřazení přípojného bodu a nainstalovat"
 ],
 "Applying changes...": [
  null,
  "Uplatňování změn…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Přiřadit oddíly k přípojným bodům. Užitečné pro přednastavená uživatelsky určená rozvržení."
 ],
 "Automatic log file upload": [
  null,
  "Automatické nahrání souboru se záznamem událostí"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Automaticky nastavit datum a čas (pomocí časových serverů)"
 ],
 "Automatically set timezone": [
  null,
  "Automaticky nastavit časové pásmo"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Volný diskový prostor: $0. Instalace požaduje: $1."
 ],
 "Back": [
  null,
  "Zpět"
 ],
 "Base environment": [
  null,
  "Základní prostředí"
 ],
 "Brief description of the issue": [
  null,
  "Stručný popis problému"
 ],
 "Bug report details": [
  null,
  "Podrobnosti hlášení chyby"
 ],
 "Bugzilla API key": [
  null,
  "Klíč k Bugzilla API"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Pokračováním v používání tohoto softwaru potvrzujete, že chápete a přijímáte rizika spojená s předprodukčním softwarem, který máte v úmyslu používat pouze pro testovací a vývojové účely a jste ochotni hlásit jakékoli chyby nebo problémy za účelem zlepšení tohoto díla."
 ],
 "Cancel": [
  null,
  "Zrušit"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change destination": [
  null,
  "Změnit cíl"
 ],
 "Change hostname": [
  null,
  "Změnit název stroje"
 ],
 "Change partition layout": [
  null,
  "Změnit rozvržení oddílů"
 ],
 "Change system keyboard layout": [
  null,
  "Změnit rozvržení systémové klávesnice"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Změny zde provedené budou mít okamžitý vliv na systém. Nelze je „vzít zpět“."
 ],
 "Checking installation configuration...": [
  null,
  "Kontrola konfigurace instalace…"
 ],
 "Checking storage configuration": [
  null,
  "Zjišťuje se uspořádání úložiště"
 ],
 "Clear search": [
  null,
  "Vymazat vyhledávání"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Pokud chcete pokračovat navzdory těmto varováním, klikněte znovu na „Další“."
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Close storage editor": [
  null,
  "Zavřít editor úložiště"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Úložiště Cockpitu neposkytlo heslovou frázi pro odemknutí zašifrovaného zařízení."
 ],
 "Completed": [
  null,
  "Dokončeno"
 ],
 "Configuration is incomplete": [
  null,
  "Konfigurace není dokončena"
 ],
 "Configure NTP servers": [
  null,
  "Nastavit NTP servery"
 ],
 "Configure custom NTP servers": [
  null,
  "Nastavit uživatelsky určené NTP servery"
 ],
 "Configure network": [
  null,
  "Nastavení sítě"
 ],
 "Configure storage": [
  null,
  "Uspořádat úložiště"
 ],
 "Configure storage again": [
  null,
  "Znovu nastavit úložiště"
 ],
 "Confirm passphrase": [
  null,
  "Zopakování heslové fráze"
 ],
 "Continue": [
  null,
  "Pokračovat"
 ],
 "Continue installation": [
  null,
  "Pokračovat v instalaci"
 ],
 "Continue installation?": [
  null,
  "Pokračovat v instalaci?"
 ],
 "Continue with installation": [
  null,
  "Pokračovat v instalaci"
 ],
 "Correct these issues before continuing.": [
  null,
  "Před pokračováním napravte tyto problémy."
 ],
 "Create Account": [
  null,
  "Vytvořit účet"
 ],
 "Create account": [
  null,
  "Vytvořit účet"
 ],
 "Currently installed: $0": [
  null,
  "Nyní nainstalováno: $0"
 ],
 "Custom": [
  null,
  "Uživatelsky určené"
 ],
 "Date": [
  null,
  "Datum"
 ],
 "Date and time": [
  null,
  "Datum a čas"
 ],
 "Delete partition": [
  null,
  "Odstranit oddíl"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Smazání určitých oddílů může $0 zabránit ve spouštění: $1"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Destination": [
  null,
  "Cíl"
 ],
 "Destination is encrypted": [
  null,
  "Cíl je šifrován"
 ],
 "Detailed description of the issue": [
  null,
  "Podrobný popis problému"
 ],
 "Detected valid storage layout:": [
  null,
  "Nalezeno platné rozvržení úložiště:"
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Duplicate device.": [
  null,
  "Zduplikovat zařízení."
 ],
 "Duplicate mount point.": [
  null,
  "Zduplikovat přípojný bod."
 ],
 "Enable root account": [
  null,
  "Povolit účet správce"
 ],
 "Encrypt my data": [
  null,
  "Šifrovat má data"
 ],
 "Encrypted": [
  null,
  "Šifrováno"
 ],
 "Encryption": [
  null,
  "Šifrování"
 ],
 "Enter PIN": [
  null,
  "Zadat PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Zadejte PIN pro přístup k instalátoru"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Pokud chcete vytvořit hlášení chyby, zadejte svůj klíč k Bugzilla API. V příštím kroku budete moci revidovat a upravovat podrobnosti o chybě."
 ],
 "Environment": [
  null,
  "Prostředí"
 ],
 "Erase data and install": [
  null,
  "Vymazat data a nainstalovat"
 ],
 "Error details": [
  null,
  "Podrobnosti o chybě"
 ],
 "Exit to live desktop": [
  null,
  "Ukončit a přejít do systému spuštěného přímo z instalačního média"
 ],
 "Extended partition": [
  null,
  "Rozšířený oddíl"
 ],
 "Failed to report issue": [
  null,
  "Nepodařilo se nahlásit problém"
 ],
 "Failed to save layouts": [
  null,
  "Uložení rozložení se nezdařilo"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux vyžaduje alespoň $0 prostoru na disku."
 ],
 "Finalization": [
  null,
  "Dokončování"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Dokončování: Nastavování systému je hotové. Dokončení instalace může chvíli trvat."
 ],
 "Find layout": [
  null,
  "Najít rozložení"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Pro lepší zabezpečení se vyhněte přímému využívání účtu root. Namísto toho používejte pro správu systému výše uvedený lokální účet."
 ],
 "Full name": [
  null,
  "Celé jméno"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Celé jméno nemůže obsahovat znak dvojtečka"
 ],
 "Helper text": [
  null,
  "Text pomocného"
 ],
 "Hide API key": [
  null,
  "Skrýt klíč k API"
 ],
 "Hide PIN": [
  null,
  "Skrýt PIN"
 ],
 "Hide confirmed password": [
  null,
  "Skrýt potvrzené heslo"
 ],
 "Hide passphrase": [
  null,
  "Skrýt heslovou frázi"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Hostname": [
  null,
  "Název stroje"
 ],
 "How would you like to install?": [
  null,
  "Jak si přejete nainstalovat?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Rozumím, že veškerá stávající data budou smazána",
  "Rozumím, že veškerá stávající data budou smazána z vybraných disků",
  "Rozumím, že veškerá stávající data budou smazána z vybraných disků"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Rozumím, že některá ze stávajících dat budou smazána"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Rozumím, že některé oddíly budou změněny"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Pokud nevyplněno, název stroje bude dočasný a nastaven pomocí informací ze sítě."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Pokud se nehodí žádná z výše uvedených možností, pak než budete pokračovat, použijte editor úložiště a vytvořte si vlastní rozdělení na oddíly."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Pokud nastavujete diskové oddíly, jsou vyžadovány tyto:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Pokud nesouhlasíte s automatickým nahráním souboru se záznamem událostí, je možné namísto toho $0. Ruční hlášení vám umožní sami revidovat a selektivně připojovat soubory záznamu událostí."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Pokud těmto rizikům nerozumíte nebo jsou pro vás nepřijatelná, ukončete prosím tento program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Pokud problém, na který narážíte, odpovídá některé z výše uvedených hlášení chyb, můžete k němu přidat doplňující informace od vás, namísto vytváření duplicitního hlášení."
 ],
 "In progress": [
  null,
  "Probíhá"
 ],
 "Initializing...": [
  null,
  "Inicializace…"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Installation completed": [
  null,
  "Instalace dokončena"
 ],
 "Installation failed": [
  null,
  "Instalace se nezdařila"
 ],
 "Installation method": [
  null,
  "Metoda instalace"
 ],
 "Installation of the system failed": [
  null,
  "Instalace systému se nezdařila"
 ],
 "Installation of the system failed: $0": [
  null,
  "instalace systému se nezdařila: $0"
 ],
 "Installation type": [
  null,
  "Typ instalace"
 ],
 "Installing": [
  null,
  "Instaluje se"
 ],
 "Insufficient disk space": [
  null,
  "Nedostatek místa na disku"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Neplatný PIN. Zkuste to znovu."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Zjištěno neplatné uspořádání RAID. Pokud je RAID pole vytvořeno přímo nad disky, pak je třeba nad ním vytvořit oddíl. Pokud je pole vytvořeno nad oddíly, je třeba, aby obsahovalo jediný souborový systém nebo formát (např. LVM fyz. svazek). Jakékoli existující oddíly na tomto poli budou ignorovány."
 ],
 "Invalid hostname": [
  null,
  "Neplatný název stroje"
 ],
 "Jump to first incomplete step": [
  null,
  "Přejít na první nedokončený krok"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Ponechat stávající rozvržení jednotky a použít dostupný prostor pro alternativní zavádění vedle jiného operačního systému."
 ],
 "Keyboard": [
  null,
  "Klávesnice"
 ],
 "Keyboard layout during boot": [
  null,
  "Rozvržení klávesnice v průběhu startu systému"
 ],
 "Language": [
  null,
  "Jazyk"
 ],
 "Launch storage editor": [
  null,
  "Spustit editor úložiště"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Zjistěte více o omezeném přístupu v nastavení"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Pokud chcete použít prázdné heslo, ponechte obě kolonky nevyplněné."
 ],
 "Location": [
  null,
  "Umístění"
 ],
 "Locked devices": [
  null,
  "Uzamčená zařízení"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Make current": [
  null,
  "Nastavit jako stávající"
 ],
 "Manual disk configuration": [
  null,
  "Ruční nastavení jednotky"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Ruční nastavení pro jednotku: mapování přípojného bodu"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Může obsahovat písmena, číslice a pomlčky."
 ],
 "May need more free space": [
  null,
  "Může vyžadovat více volného prostoru"
 ],
 "Medium": [
  null,
  "Střední"
 ],
 "Minimum of $0 required": [
  null,
  "Vyžadováno alespoň $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Neshoda mezi výběrem přeformátování u nadřazeného a podřízeného zařízení."
 ],
 "Mount point": [
  null,
  "Přípojný bod"
 ],
 "Mount point assignment": [
  null,
  "Přiřazení přípojného bodu"
 ],
 "Move down": [
  null,
  "Přesunout dolů"
 ],
 "Move up": [
  null,
  "Přesunout nahoru"
 ],
 "Must be at least $0 characters": [
  null,
  "Je třeba, by bylo alespoň $0 znaků"
 ],
 "My issue is different, continue": [
  null,
  "Můj problém je odlišný – pokračovat"
 ],
 "NTP Servers": [
  null,
  "NTP servery"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Needs at least $0": [
  null,
  "Vyžaduje alespoň $0"
 ],
 "Network": [
  null,
  "Síť"
 ],
 "Network Configuration": [
  null,
  "Nastavení sítě"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Síť není k dispozici. Aby bylo možné chybu nahlásit, nastavte síť (v nabídce vpravo na horní liště)."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Síť není k dispozici. Aby bylo možné chybu nahlásit, nastavte síť."
 ],
 "Network plugin failed": [
  null,
  "Zásuvný modul sítě selhal"
 ],
 "Next": [
  null,
  "Další"
 ],
 "No devices": [
  null,
  "Žádná zařízení"
 ],
 "No disks available": [
  null,
  "Nejsou k dispozici žádné disky"
 ],
 "No disks selected": [
  null,
  "Nevybrány žádné jednotky"
 ],
 "No keyboard layouts selected": [
  null,
  "Nevybrána žádná rozložení klávesnice"
 ],
 "No layouts selected yet": [
  null,
  "Zatím nevybrána žádná rozložení"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Pro vybraná rozložení klávesnice nebylo možné obdržet žádnou platnou VConsole mapu kláves. Vybete jiné rozložení klávesnice."
 ],
 "Not enough available free space": [
  null,
  "Nedostatek volného místa k dispozici"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Na vybraných jednotkách není dostatek volného místa."
 ],
 "Not enough space on selected disks.": [
  null,
  "Na vybraných jednotkách není dostatek prostoru."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Upozornění: Toto je předprodukční software, který je určený pouze pro účely vývoje a testování. Tento software NEpoužívejte pro jakoukoli kritickou práci nebo pro produkční prostředí."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Otevřít formulář zadávání hlášení chyby do Bugzilla"
 ],
 "Operating system": [
  null,
  "Operační systém"
 ],
 "Options": [
  null,
  "Volby"
 ],
 "Other keyboards": [
  null,
  "Další klávesnice"
 ],
 "Partitions (advanced)": [
  null,
  "Rozdělení disku (pokročilé)"
 ],
 "Passphrase": [
  null,
  "Heslová fráze"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Heslová fráze neodpovídá žádnému ze zamčených zařízení"
 ],
 "Passphrases must match": [
  null,
  "Je třeba, aby se zadání heslové fráze shodovaly"
 ],
 "Pending": [
  null,
  "Čeká"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "K problému připojte soubor se záznamem událostí $0."
 ],
 "Please enter a PIN": [
  null,
  "Zadejte PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Aby bylo možné pokračovat, vyberte alespoň jeden disk"
 ],
 "Pool": [
  null,
  "Fond"
 ],
 "Potential duplicate bugs found": [
  null,
  "Nalezena potenciální duplicitní hlášení chyb"
 ],
 "Powered by Anaconda": [
  null,
  "Založeno na instalátoru Anaconda"
 ],
 "Pre-release": [
  null,
  "Předprodukční verze"
 ],
 "Prefer to report manually? $0": [
  null,
  "Chcete raději nahlásit ručně? $0"
 ],
 "Proceed with installation": [
  null,
  "Pokračovat v instalaci"
 ],
 "Quit": [
  null,
  "Ukončit"
 ],
 "Quit installer?": [
  null,
  "Ukončit instalátor?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Načítání informací o operačním systému se nezdařilo."
 ],
 "Reading information about the computer failed.": [
  null,
  "Načítání informací o počítači se nezdařilo."
 ],
 "Reading installer configuration failed.": [
  null,
  "Nepodařilo se načíst nastavení instalátoru."
 ],
 "Reading installer version information failed.": [
  null,
  "Nepodařilo se načíst verzi instalátoru."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Skutečný název stroje může obsahovat pouze písmena, číslice, pomlčky (ne však jako zahajovací nebo ukončující znak) a tečky"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Délka názvu stroje nemůže přesáhnout 64 znaků"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Restartujte do Windows aby bylo možné změnit velikost oddílů šifrovaných pomocí BitLocker. Pro instalaci uvolněte alespoň $0 prostoru."
 ],
 "Reboot system?": [
  null,
  "Restartovat systém?"
 ],
 "Reclaim additional space": [
  null,
  "Získat více místa"
 ],
 "Reclaim space": [
  null,
  "Uvolnit místo"
 ],
 "Reclaim space (required)": [
  null,
  "Uvolnit místo (vyžadováno)"
 ],
 "Recommended": [
  null,
  "Doporučeno"
 ],
 "Recommended partitions:": [
  null,
  "Doporučené oddíly:"
 ],
 "Reformat": [
  null,
  "Znovu vytvořit souborový systém"
 ],
 "Reinstall Fedora": [
  null,
  "Přeinstalovat Fedoru"
 ],
 "Remove": [
  null,
  "Odstranit"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Odebrat veškeré oddíly na zvolených zařízeních, včetně stávajících operačních systémů."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Uvolnit místo pro instalaci odstraněním nebo zmenšením existujících souborových systémů."
 ],
 "Remove server": [
  null,
  "Odebrat server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Odebrání souborového systému smaže veškerá data, která obsahuje. Změna velikosti oddílu může uvolnit nevyužívaný prostor, ale není bez rizika. Ověřte, že máte zálohy všeho důležitého a až poté prostor uvolňujte."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Nahradit stávající instalaci, ale ponechat soubory v domovské složce."
 ],
 "Report Issue": [
  null,
  "Nahlásit problém"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Nahlaste problém nebo poskytněte zpětnou vazbu otevřením formuláře $0 zadávání hlášení chyby do Bugzilla."
 ],
 "Report issue": [
  null,
  "Nahlásit problém"
 ],
 "Reporting issue...": [
  null,
  "Nahlašování problému…"
 ],
 "Required": [
  null,
  "Vyžadováno"
 ],
 "Requirements": [
  null,
  "Požadavky"
 ],
 "Rescan devices": [
  null,
  "Znovu oskenovat zařízení"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Opětovné naskenování jednotek datového úložiště se nezdařilo."
 ],
 "Resize": [
  null,
  "Změnit velikost"
 ],
 "Resize partition": [
  null,
  "Změnit velikost oddílu"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Mění se velikost následujících oddílů z $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Omezit přístup k hlášení"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Omezí hlášení na skupinu $0. $1"
 ],
 "Return to installation": [
  null,
  "Návrat k instalaci"
 ],
 "Return to storage editor": [
  null,
  "Návrat do editoru úložiště"
 ],
 "Review and install": [
  null,
  "Zkontrolovat a nainstalovat"
 ],
 "Root account has been configured": [
  null,
  "Účet správce (root) byl nastaven"
 ],
 "Root account is enabled": [
  null,
  "Účet správce (root) je povolený"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Účet root je povolený, ale nebyl nastaven žádný uživatelský účet"
 ],
 "Root password has been set.": [
  null,
  "Heslo správce (root) bylo nastaveno."
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Načtěte QR kód vaším telefonem nebo navštivte:"
 ],
 "Search for a language": [
  null,
  "Hledat jazyk"
 ],
 "Search for additional software": [
  null,
  "Hledat doplňkový software"
 ],
 "Search for an environment": [
  null,
  "Vyhledat prostředí"
 ],
 "Search keyboard layout": [
  null,
  "Rozvržení klávesnice vyhledávání"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Zabezpečte svá data pomocí šifrování disku. Lze uplatnit pouze na nové oddíly"
 ],
 "Select": [
  null,
  "Vybrat"
 ],
 "Select a device": [
  null,
  "Vybrat zařízení"
 ],
 "Select city": [
  null,
  "Vyberte město"
 ],
 "Select destination": [
  null,
  "Vyberte cíl"
 ],
 "Select region": [
  null,
  "Vyberte oblast"
 ],
 "Selected (top = current)": [
  null,
  "Vybraná (nejvyšší = současné)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Formát „$0“ vybraného zařízení není možné přeformátovat."
 ],
 "Send us feedback on your installation": [
  null,
  "Pošlete nám zpětnou vazbu o vaší instalaci"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server není dosažitelný"
 ],
 "Set custom hostname": [
  null,
  "Nastavit uživatelsky určený název stroje"
 ],
 "Share disk with other operating systems": [
  null,
  "Sdílet disk s jinými operačními systémy"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Sdílet disk s jinými operačními systémy: $0"
 ],
 "Show AM/PM": [
  null,
  "Zobrazovat dop/odp."
 ],
 "Show API key": [
  null,
  "Zobrazit klíč k API"
 ],
 "Show PIN": [
  null,
  "Zobrazit PIN"
 ],
 "Show confirmed password": [
  null,
  "Zobrazit potvrzené heslo"
 ],
 "Show passphrase": [
  null,
  "Zobrazit heslovou frázi"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Software installation": [
  null,
  "Instalace softwaru"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalace softwaru: Nastavování úložiště dokončeno. Software se nyní instaluje do vašeho zařízení."
 ],
 "Software selection": [
  null,
  "Výběr softwaru"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Před pokračováním je třeba vyřešit některé kroky instalace."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Chybí některé vyžadované oddíly: $0"
 ],
 "Space": [
  null,
  "Místo"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Storage configuration": [
  null,
  "Uspořádání úložiště"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Nastavování úložiště: Úložiště je právě nastavováno."
 ],
 "Storage editor": [
  null,
  "Editor úložiště"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Úložiště vychází z uspořádání z „Upravit úložiště“."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Rozložení úložiště je definováno souborem kickstart. Plánované rozložení oddílů můžete zkontrolovat v kroku souhrnu."
 ],
 "Storage plugin failed": [
  null,
  "Zásuvný modul úložiště selhal"
 ],
 "Storage requirements not met": [
  null,
  "Požadavky na úložiště nejsou splněny"
 ],
 "Strong": [
  null,
  "Odolné"
 ],
 "Successfully installed": [
  null,
  "Úspěšně nainstalováno"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 úspěšně odemčeno."
 ],
 "Suggested keyboards": [
  null,
  "Navržené klávesnice"
 ],
 "Suggested languages": [
  null,
  "Doporučené jazyky"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System configuration": [
  null,
  "Nastavení systému"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Nastavování systému: Instalace softwaru dokončena. Systém se nyní nastavuje."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Instalace Anaconda se neočekávaně zastavila."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Následující otevřená hlášení chyb mohou souviset s vaším problémem. Prosíme podívejte se na ně předtím, než budete vytvářet nové hlášení."
 ],
 "The following user will be created:": [
  null,
  "Bude vytvořen následující uživatel:",
  "Budou vytvořeni následující uživatelé:",
  "Budou vytvořeni následující uživatelé:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Instalace potřebuje $0 prostoru, ale kapacita vybraných jednotek je pouze $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Instalátor nemůže kvůli kritické chybě pokračovat."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Instalátor nemůže pokračovat kvůli kritické chybě: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Rozložení klávesnice se od doby nastavení heslové fráze pro šifrování disku změnilo. Zadejte prosím heslovou frázi znovu."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Zadaná heslová fráze obsahuje znaky, které jsou nad rámec ASCII kódování. Pokud při jejím zadávání nebude možné přepnout na potřebné rozložení klávesnice, nebude možné ji napsat."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Zvolené výchozí rozložení klávesnice nepodporuje znaky ASCII. Zvolte jako výchozí takové, které je umí."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Editor úložiště umožňuje měnit velikost, mazat a vytvářet oddíly. Také je možné nastavovat LVM a mnoho dalšího. Je zamýšlen být použit až jako pokročilý nástroj a ne pro typickou instalaci."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Tyto soubory záznamu událostí mohou obsahovat citlivé informace, jako jsou IP adresy, uživatelská jména, nebo další podrobnosti o systému."
 ],
 "This hostname can't be submitted": [
  null,
  "Takový název stroje nelze nastavit"
 ],
 "This is unstable, pre-release software": [
  null,
  "Toto je nestabilní, předprodukční software"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Toto rozvržení bude použito pro odemykání vašeho systému při startu systému"
 ],
 "This may take a moment": [
  null,
  "Může to chvíli trvat"
 ],
 "This will take a few moments": [
  null,
  "Chvíli to potrvá"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Timezone": [
  null,
  "Časové pásmo"
 ],
 "Title": [
  null,
  "Nadpis"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Aby bylo možné začít $0 používat, počítač restartujte."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Aby bylo možné pokračovat, vyberte zařízení, na která instalovat."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Aby bylo možné tuto volbu použít, uvolněte alespoň $0 změnou velikosti nebo přesunem existujících oddílů."
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Není možné naplánovat smazání $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Není možné naplánovat změnu velikosti $0"
 ],
 "Undo last action": [
  null,
  "Vrátit poslední akci"
 ],
 "Unlock": [
  null,
  "Odemknout"
 ],
 "Unlock encrypted devices": [
  null,
  "Odemknout šifrovaná zařízení"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Odemkněte šifrované oddíly pro ponechání existujících dat a zobrazení dalších metod instalace."
 ],
 "Use configured storage": [
  null,
  "Použít nastavené úložiště"
 ],
 "Use entire disk": [
  null,
  "Použít celý disk"
 ],
 "Use free space": [
  null,
  "Využít volný prostor"
 ],
 "Use local account": [
  null,
  "Použít lokální účet"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Použít RAID zařízení pro automatické rozdělení"
 ],
 "User creation": [
  null,
  "Vytvoření uživatele"
 ],
 "User name": [
  null,
  "Uživatelské jméno"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Uživatelské jméno může obsahovat pouze: písmena a-z, číslice 0-9, pomlčku $0, tečku $1, podtržítko $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Uživatelské jméno nemůže být některým z vyhrazených slov"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Je třeba, aby uživatelské jméno bylo kratší než 33 znaků"
 ],
 "Validating...": [
  null,
  "Ověřování správnosti formy…"
 ],
 "Weak": [
  null,
  "Snadno prolomitelné"
 ],
 "Welcome": [
  null,
  "Vítejte"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Vítejte ve Fedora Linuxu"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Vítejte. Pojďme nainstalovat systém $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Když toto hlášení chyby odešlete, budou automaticky nahrány následující soubory záznamu událostí: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Velikost oddílů Windows, šifrované pomocí BitLocker, není možné změnit"
 ],
 "You can close this browser window now.": [
  null,
  "Toto okno prohlížeče nyní můžete zavřít."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Zde můžete buď uvolnit dostatek volného prostoru a nechat instalační program, ať zařídí zbytek, nebo oddíly nastavit ručně."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Klíč k API je možné si nechat vytvořit v nastavení vašeho účtu na Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Aby bylo možné pokračovat, je třeba povolit účet root nebo vytvořit lokální uživatelský účet."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Aby bylo možné zapnout automatické nastavování data a času, je třeba být připojení k síti."
 ],
 "Your progress will not be saved.": [
  null,
  "To, co jste doposud udělali, nebude uloženo."
 ],
 "completed step": [
  null,
  "dokončený krok"
 ],
 "current step": [
  null,
  "stávající krok"
 ],
 "delete": [
  null,
  "smazat"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "encrypt": [
  null,
  "šifrovat"
 ],
 "encrypted": [
  null,
  "šifrováno"
 ],
 "extended partition": [
  null,
  "Rozšířený oddíl"
 ],
 "format as $0": [
  null,
  "vytvořit souborový systém $0"
 ],
 "here": [
  null,
  "zde"
 ],
 "incomplete": [
  null,
  "nedokončené"
 ],
 "mount": [
  null,
  "připojení"
 ],
 "pending step": [
  null,
  "čekající krok"
 ],
 "report the issue manually": [
  null,
  "nahlásit problém ručně"
 ],
 "resized from $0": [
  null,
  "změněna velikost z $0"
 ],
 "shrink": [
  null,
  "zmenšit"
 ],
 "shrink to $0": [
  null,
  "zmenšit na $0"
 ],
 "transient, will use DHCP": [
  null,
  "přechodné – použije DHCP"
 ],
 "undo": [
  null,
  "zpět"
 ]
});
