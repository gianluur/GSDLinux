cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "unmount": [
  null,
  "размонтировать"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "format": [
  null,
  "форматировать"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "файловая система"
 ],
 "partition": [
  null,
  "раздел"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "volume": [
  null,
  "том"
 ],
 "disk": [
  null,
  "диск"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "привод"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "шифрование"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Управление разделами"
 ],
 "Managing NFS mounts": [
  null,
  "Управление подключениями по NFS"
 ],
 "Managing RAIDs": [
  null,
  "Управление RAID-устройствами"
 ],
 "Managing LVMs": [
  null,
  "Управление томами LVM"
 ],
 "Managing physical drives": [
  null,
  "Управление физическими дисками"
 ],
 "Managing VDOs": [
  null,
  "Управление устройствами VDO"
 ],
 "Using LUKS encryption": [
  null,
  "С использованием шифрования LUKS"
 ],
 "Using Tang server": [
  null,
  "С использованием сервера Tang"
 ]
});
