cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "da",
  "language-direction": "ltr"
 }
});
