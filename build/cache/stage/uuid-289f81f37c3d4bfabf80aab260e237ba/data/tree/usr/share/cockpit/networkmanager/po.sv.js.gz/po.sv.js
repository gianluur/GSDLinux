cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Firewall": [
  null,
  "Brandvägg"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Public key": [
  null,
  "Publik nyckel"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "Connect": [
  null,
  "Anslut"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "Disconnected": [
  null,
  "Frånkopplad"
 ],
 "Permission denied": [
  null,
  "Åtkomst nekas"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Inga metoder för att få administrativ åtkomst finns tillgängliga (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Method": [
  null,
  "Metod"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Acceptable password": [
  null,
  "Godtagbart lösenord"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder ska slutföras"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "Downloading $0": [
  null,
  "Laddar ner $0"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterade felkod $0"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Error during initialization": [
  null,
  "Fel under initialisering"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Home": [
  null,
  "Hem"
 ],
 "Downloads": [
  null,
  "Hämtningar"
 ],
 "Not a directory": [
  null,
  "Inte en katalog"
 ],
 "All files": [
  null,
  "Alla filer"
 ],
 "Recent": [
  null,
  "Senaste"
 ],
 "No recent directories": [
  null,
  "Inga senaste kataloger"
 ],
 "No recent files": [
  null,
  "Inga senaste filer"
 ],
 "Type to filter": [
  null,
  "Skriv för att filtrera"
 ],
 "File chooser actions": [
  null,
  "Filväljare åtgärder"
 ],
 "Open in file browser": [
  null,
  "Öppna i filhanterare"
 ],
 "Hide hidden files": [
  null,
  "Dölj dolda filer"
 ],
 "Show hidden files": [
  null,
  "Visa dolda filer"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Clear filters": [
  null,
  "Rensa filter"
 ],
 "Directory is empty": [
  null,
  "Katalog är tom"
 ],
 "Directory has no sub-directories": [
  null,
  "Katalogen har inga underkataloger"
 ],
 "This directory contains only hidden files": [
  null,
  "Den här katalogen innehåller endast dolda filer"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "Folder": [
  null,
  "Mapp"
 ],
 "File": [
  null,
  "Arkiv"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Generated": [
  null,
  "Genererad"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Start service": [
  null,
  "Starta tjänst"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Delete $0": [
  null,
  "Ta bort $0"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Not available": [
  null,
  "Inte tillgängligt"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Preserve": [
  null,
  "Bevara"
 ],
 "Random": [
  null,
  "Slumpvis"
 ],
 "Stable": [
  null,
  "Stabilt"
 ],
 "Use $0": [
  null,
  "Använd $0"
 ],
 "Failed to save settings": [
  null,
  "Misslyckades att spara inställningarna"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att skapa detta $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Create it": [
  null,
  "Skapa den"
 ],
 "Invalid prefix $0": [
  null,
  "Felaktigt prefix $0"
 ],
 "Invalid metric $0": [
  null,
  "Felaktigt mått $0"
 ],
 "Invalid address $0": [
  null,
  "Felaktig adress $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Felaktigt prefix eller nätmask $0"
 ],
 "Testing connection": [
  null,
  "Testar anslutningen"
 ],
 "Restoring connection": [
  null,
  "Återställer förbindelsen"
 ],
 "Troubleshoot…": [
  null,
  "Felsök…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager kör inte"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager är inte installerad"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Nätverksenheter och -grafer behöver NetworkManager"
 ],
 "Enable service": [
  null,
  "Aktivera tjänst"
 ],
 "Network interface '$0' not found": [
  null,
  "Nätverksgränssnitt '$0' hittades inte"
 ],
 "Return to overview page": [
  null,
  "Återgå till översiktssidan"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Du har inte rättigheter att ändra brandväggen."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Inte behörig att inaktivera brandväggen"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Inte behörig att aktivera brandväggen"
 ],
 "Disable the firewall": [
  null,
  "Stäng av brandväggen"
 ],
 "Enable the firewall": [
  null,
  "Slå på brandväggen"
 ],
 "Edit service $0": [
  null,
  "Redigera tjänst $0"
 ],
 "Remove service $0": [
  null,
  "Ta bort tjänst $0"
 ],
 "Included Services": [
  null,
  "Inkluderade tjänster"
 ],
 "Additional port": [
  null,
  "Ytterligare port"
 ],
 "Remove additional port": [
  null,
  "Radera ytterligare port"
 ],
 "Remove zone $0": [
  null,
  "Ta bort zon $0"
 ],
 "Add services to zone $0": [
  null,
  "Lägg till tjänster till zon $0"
 ],
 "Add services": [
  null,
  "Lägg till tjänster"
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "zon $0"
 ],
 "Interface": [
  null,
  "Gränssnitt",
  "Gränssnitt"
 ],
 "Allowed addresses": [
  null,
  "Tillåtna adresser"
 ],
 "Entire subnet": [
  null,
  "Hela subnätet"
 ],
 "There are no active services in this zone": [
  null,
  "Det finns inga aktiva tjänster i denna zon"
 ],
 "Filter services": [
  null,
  "Filtrera tjänster"
 ],
 "Failed to edit service": [
  null,
  "Kunde inte redigera tjänst"
 ],
 "Failed to add port": [
  null,
  "Kunde inte lägga till port"
 ],
 "Failed to add service": [
  null,
  "Kunde inte lägga till tjänst"
 ],
 "Unknown service name": [
  null,
  "Okänt tjänstnamn"
 ],
 "Invalid port number": [
  null,
  "Felaktigt portnummer"
 ],
 "Invalid range": [
  null,
  "Felaktigt område"
 ],
 "Range must be strictly ordered": [
  null,
  "Räckvidden måste vara strikt ordnad"
 ],
 "Edit service": [
  null,
  "Redigera tjänst"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Redigera anpassad tjänst i $0 zon"
 ],
 "Add ports": [
  null,
  "Lägg till portar"
 ],
 "Add ports to $0 zone": [
  null,
  "Lägg till portar till zonen $0"
 ],
 "Add services to $0 zone": [
  null,
  "Lägg till tjänster till zonen $0"
 ],
 "Custom ports": [
  null,
  "Egna portar"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exempel: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Kommaseparerade portar, intervall och tjänster accepteras"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exempel: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Om det lämnas tomt kommer ett ID att genereras baserat på associerade porttjänster och portnummer"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Att lägga till egna portar startar om firewalld . En omstart gör att osparade ändringar försvinner!"
 ],
 "Failed to add zone": [
  null,
  "Kunde inte lägga till zon"
 ],
 "Add zone": [
  null,
  "Lägg till zon"
 ],
 "Trust level": [
  null,
  "Tillitsnivå"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sorterad från minst till mest betrodd"
 ],
 "Custom zones": [
  null,
  "Egna zoner"
 ],
 "No description available": [
  null,
  "Ingen beskrivning finns"
 ],
 "Included services": [
  null,
  "Inkluderade tjänster"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit tjänsten ingår automatiskt"
 ],
 "Interfaces": [
  null,
  "Gränssnitt"
 ],
 "Range": [
  null,
  "Räckvidd"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adress med prefix. Separera flera adresser med komma. Exempel: 192.0.2.0/24,2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Bekräfta borttagning av $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Denna zon innehåller cockpit-tjänsten. Se till att denna zon inte gäller din aktuella webbkonsolanslutning."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Om du tar bort zonen tas alla tjänster inom den bort."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Att ta bort cockpittjänsten kan leda till att webbkonsolen blir oåtkomlig. Se till att den här zonen inte gäller din nuvarande webbkonsolanslutning."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Ta bort tjänsten $0 från zon $1"
 ],
 "Firewall is not available": [
  null,
  "Brandväggen är inte tillgänglig"
 ],
 "Please install the $0 package": [
  null,
  "Installera paketet $0"
 ],
 "Add a new zone": [
  null,
  "Lägg till zon"
 ],
 "Add new zone": [
  null,
  "Lägg till zon"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Inkommande förfrågningar blockeras som standard. Utgående förfrågningar blockeras inte."
 ],
 "Connected": [
  null,
  "Ansluten"
 ],
 "Wireless": [
  null,
  "Trådlöst"
 ],
 "Wired": [
  null,
  "Trådat"
 ],
 "No networks found": [
  null,
  "Inga nätverk hittades"
 ],
 "No interface selected": [
  null,
  "Inget gränssnitt valt"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "Välj ett nätverksgränssnitt för att konfigurera anslutningen."
 ],
 "SSID can not be empty": [
  null,
  "SSID kan inte vara tomt"
 ],
 "Password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "Failed to connect": [
  null,
  "Misslyckades att ansluta"
 ],
 "Check your password.": [
  null,
  "Kontrollera ditt lösenord."
 ],
 "Connect to hidden network": [
  null,
  "Anslut till dolt nätverk"
 ],
 "Connect to $0": [
  null,
  "Anslut till $0"
 ],
 "Network name": [
  null,
  "Nätverksnamn"
 ],
 "Security": [
  null,
  "Säkerhet"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att sätta på $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Switch on $0": [
  null,
  "Sätt på $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att slå av $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Switch off $0": [
  null,
  "Stäng av $0"
 ],
 "Bond": [
  null,
  "Binda"
 ],
 "Team": [
  null,
  "Team"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Brygga"
 ],
 "Unknown \"$0\"": [
  null,
  "Okänt ”$0”"
 ],
 "Carrier": [
  null,
  "Transport"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "No": [
  null,
  "Nej"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Unknown configuration": [
  null,
  "Okänd konfiguration"
 ],
 "Additional address $val": [
  null,
  "Ytterligare adress $val"
 ],
 "Address $val": [
  null,
  "Adress $val"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Ytterligare DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ytterligare DNS-sökdomäner $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS-sökdomäner $val"
 ],
 "General": [
  null,
  "Allmänt"
 ],
 "Connect automatically": [
  null,
  "Anslut automatiskt"
 ],
 "Automatic": [
  null,
  "Automatisk"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP-övervakning"
 ],
 "Broken configuration": [
  null,
  "Trasig konfiguration"
 ],
 "Team port": [
  null,
  "Team-port"
 ],
 "Spanning tree protocol": [
  null,
  "Uppspännande-träd-protokollet"
 ],
 "Priority $priority": [
  null,
  "Prioritet $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Fördröjning framåt $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Hälsningstid $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximal meddelandeålder $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Sökvägskostnad $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hårnålsläge"
 ],
 "Bridge port": [
  null,
  "Bryggport"
 ],
 "Parent $parent": [
  null,
  "Förälder $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Nätverkslösenordet är inte lagrat. Glöm det och återanslut till nätverket."
 ],
 "Failed to connect to $0": [
  null,
  "Misslyckades att ansluta till $0"
 ],
 "secured": [
  null,
  "säkrat"
 ],
 "open": [
  null,
  "öppet"
 ],
 "Last connected: $0": [
  null,
  "Senast ansluten: $0"
 ],
 "Signal strength": [
  null,
  "Signalstyrka"
 ],
 "Not permitted to disconnect network": [
  null,
  "Inte tillåtet att koppla ifrån nätverket"
 ],
 "Disconnect": [
  null,
  "Koppla ifrån"
 ],
 "Not permitted to connect to network": [
  null,
  "Inte tillåtet att ansluta till nätverket"
 ],
 "Forget": [
  null,
  "Glöm bort"
 ],
 "$0 hidden network": [
  null,
  "$0 dolt nätverk",
  "$0 dolda nätverk"
 ],
 "Filter": [
  null,
  "Filter"
 ],
 "Refresh": [
  null,
  "Uppdatera"
 ],
 "Available networks": [
  null,
  "Tillgängliga nätverk"
 ],
 "Network": [
  null,
  "Nätverk"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Signal": [
  null,
  "Signal"
 ],
 "Rate": [
  null,
  "Hastighet"
 ],
 "Primary action": [
  null,
  "Primär åtgärd"
 ],
 "Secondary actions": [
  null,
  "Sekundära åtgärder"
 ],
 "Not permitted to configure network devices": [
  null,
  "Inte tillåtet att konfigurera nätverksenheter"
 ],
 "Enable or disable the device": [
  null,
  "Aktivera eller avaktivera denna enhet"
 ],
 "This device cannot be managed here.": [
  null,
  "Denna enhet kan inte hanteras här."
 ],
 "Connection will be lost": [
  null,
  "Anslutningen kommer gå förlorad"
 ],
 "Keep connection": [
  null,
  "Behåll förbindelsen"
 ],
 "Invalid IP address: $0": [
  null,
  "Ogiltig IP adress: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Ogiltig destinations adress: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Ogiltig gateway adress: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Ogiltig DNS adress: $0"
 ],
 "Preparing": [
  null,
  "Förbereder"
 ],
 "Configuring": [
  null,
  "Konfigurerar"
 ],
 "Authenticating": [
  null,
  "Autentiserar"
 ],
 "Configuring IP": [
  null,
  "Konfigurerar IP"
 ],
 "Checking IP": [
  null,
  "Kontrollerar IP"
 ],
 "Waiting": [
  null,
  "Väntar"
 ],
 "Active": [
  null,
  "Aktivt"
 ],
 "Deactivating": [
  null,
  "Avaktiverar"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infrastruktur"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Ingen bärvåg"
 ],
 "Part of $0": [
  null,
  "Del av $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ändra inställningarna kommer bryta förbindelsen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Change the settings": [
  null,
  "Ändra inställningarna"
 ],
 "Add bridge": [
  null,
  "Lägg till brygga"
 ],
 "Edit bridge settings": [
  null,
  "Redigera brygginställningar"
 ],
 "Ports": [
  null,
  "Portar"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Uppspännande-träd-protokollet (STP)"
 ],
 "STP priority": [
  null,
  "STP-prioritet"
 ],
 "STP forward delay": [
  null,
  "Fördröjning av STP-vidarebefordran"
 ],
 "STP hello time": [
  null,
  "STP Hello-tid"
 ],
 "STP maximum message age": [
  null,
  "STP maximal meddelandeålder"
 ],
 "Round robin": [
  null,
  "Turas om"
 ],
 "Active backup": [
  null,
  "Aktiv reserv"
 ],
 "Load balancing": [
  null,
  "Lastbalansering"
 ],
 "Broadcast": [
  null,
  "Utsändning"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP-ping"
 ],
 "NSNA ping": [
  null,
  "NSNA-ping"
 ],
 "Add team": [
  null,
  "Lägg till team"
 ],
 "Edit team settings": [
  null,
  "Redigera Team-inställningar"
 ],
 "Runner": [
  null,
  "Körare"
 ],
 "Balancer": [
  null,
  "Balanserare"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Link watch": [
  null,
  "Länkbetraktelse"
 ],
 "Link up delay": [
  null,
  "Fördröjning när länk uppe"
 ],
 "Link down delay": [
  null,
  "Fördröjning när länk nere"
 ],
 "Ping interval": [
  null,
  "Ping-intervall"
 ],
 "Ping target": [
  null,
  "Ping-mål"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatiskt (endast DHCP)"
 ],
 "Link local": [
  null,
  "Länklokal"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Shared": [
  null,
  "Delad"
 ],
 "Prefix length or netmask": [
  null,
  "Prefixlängd eller nätmask"
 ],
 "Prefix length": [
  null,
  "Prefixlängd"
 ],
 "IPv4 settings": [
  null,
  "IPv4-inställningar"
 ],
 "IPv6 settings": [
  null,
  "IPv6-inställningar"
 ],
 "Addresses": [
  null,
  "Adresser"
 ],
 "Select method": [
  null,
  "Välj metod"
 ],
 "Add address": [
  null,
  "Lägg till adress"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Remove item": [
  null,
  "Ta bort post"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Lägg till DNS-server"
 ],
 "DNS search domains": [
  null,
  "DNS-sökdomäner"
 ],
 "Add search domain": [
  null,
  "Lägg till sökdomän"
 ],
 "Search domain": [
  null,
  "Sökdomäner"
 ],
 "Routes": [
  null,
  "Rutter"
 ],
 "Add route": [
  null,
  "Lägg till rutt"
 ],
 "Metric": [
  null,
  "Mått"
 ],
 "Enter a valid MAC address": [
  null,
  "Ange en giltig MAC-adress"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 nätverk",
  "$0 flera nätverk"
 ],
 "Add VPN": [
  null,
  "Lägg till VPN"
 ],
 "Add bond": [
  null,
  "Lägg till bindning"
 ],
 "Add VLAN": [
  null,
  "Lägg till VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Redigera regler och zoner"
 ],
 "$0 active zone": [
  null,
  "$0 aktiv zon",
  "$0 aktiva zoner"
 ],
 "Managed interfaces": [
  null,
  "Hanterade gränssnitt"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "Sending": [
  null,
  "Skickar"
 ],
 "Receiving": [
  null,
  "Tar emot"
 ],
 "Unmanaged interfaces": [
  null,
  "Ej hanterade gränssnitt"
 ],
 "Network logs": [
  null,
  "Nätverksloggar"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresser är inte korrekt formaterade"
 ],
 "Invalid IP address '$0'": [
  null,
  "Ogiltig IP adress '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools paketet är inte installerat"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Jämlik #$0 har ogiltig ändpunkt. Det måste anges som värd:port, t.ex. 1.2.3.4:51820, [2001:db8::1]:51820 eller example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Jämlik #$0 har en ogiltig ändpunktsport. Port måste vara ett nummer."
 ],
 "Listen port must be a number": [
  null,
  "Lyssna port måste vara ett nummer"
 ],
 "Add WireGuard VPN": [
  null,
  "Lägg till WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Redigera WireGuard VPN"
 ],
 "Private key": [
  null,
  "Privatnyckel"
 ],
 "Paste existing key": [
  null,
  "Klistra in befintlig nyckel"
 ],
 "Regenerate": [
  null,
  "Regenerera"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Publik nyckel kommer att genereras när en giltig privat nyckel anges"
 ],
 "Listen port": [
  null,
  "Lyssna port"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Kommer att ställas in på \"Automatisk\""
 ],
 "IP addresses": [
  null,
  "IP-adresser"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Flera adresser kan anges med kommatecken eller mellanslag som avgränsare."
 ],
 "Peers": [
  null,
  "Jämlikar"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Jämlikar är andra maskiner som ansluter till denna. Offentliga nycklar från andra maskiner kommer att delas med varandra."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Ändpunkt som fungerar som en \"server\" måste anges som värd:port, annars kan den lämnas tom."
 ],
 "Add peer": [
  null,
  "Lägg till jämnlike"
 ],
 "Endpoint": [
  null,
  "Ändpunkt"
 ],
 "Allowed IPs": [
  null,
  "Tillåtna IP-adresser"
 ],
 "No peers added.": [
  null,
  "Inga jämlikar tillagda."
 ],
 "Edit VLAN settings": [
  null,
  "Redigera VLAN-inställningar"
 ],
 "Parent": [
  null,
  "Förälder"
 ],
 "VLAN ID": [
  null,
  "VLAN-ID"
 ],
 "Transmitting": [
  null,
  "Överföring"
 ],
 "MTU must be a positive number": [
  null,
  "MTU måste vara ett positivt tal"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Set to": [
  null,
  "Sätt till"
 ],
 "Team port settings": [
  null,
  "Team-portsinställningar"
 ],
 "Sticky": [
  null,
  "Fast"
 ],
 "LACP key": [
  null,
  "LACP-nyckel"
 ],
 "Bridge port settings": [
  null,
  "Bryggportinställningar"
 ],
 "Path cost": [
  null,
  "Sökvägskostnad"
 ],
 "Hair pin mode": [
  null,
  "Hårnålsläge"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiv lastbalansering av sändning"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiv lastbalansering"
 ],
 "MII (recommended)": [
  null,
  "MII (Rekommenderas)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Redigera bondinställningar"
 ],
 "Network bond": [
  null,
  "Nätverksbindning"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "En bindning kombinerar flera nätverksportar till en logisk port med högre hastighet eller tillförlitlighet."
 ],
 "Link monitoring": [
  null,
  "Länkövervakning"
 ],
 "Monitoring interval": [
  null,
  "Övervakningsintervall"
 ],
 "Monitoring targets": [
  null,
  "Övervakningsmål"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Remove $0": [
  null,
  "Ta bort $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att lägga till $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "No interfaces available": [
  null,
  "Inga gränssnitt tillgängliga"
 ],
 "Add member": [
  null,
  "Lägg till medlem"
 ],
 "Interface members": [
  null,
  "Gränssnittsmedlemmar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ]
});
