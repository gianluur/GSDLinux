cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Public key": [
  null,
  "Publieke sleutel"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Select": [
  null,
  "Selecteren"
 ],
 "Unexpected error": [
  null,
  "Onverwachte fout"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "Connect": [
  null,
  "Verbinden"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "Disconnected": [
  null,
  "Verbinding verbroken"
 ],
 "Permission denied": [
  null,
  "Toestemming geweigerd"
 ],
 "Clear input value": [
  null,
  "Invoerwaarde wissen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "Create $0": [
  null,
  "Maak $0 aan"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "You now have administrative access.": [
  null,
  "Je hebt nu administratieve toegang."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Authenticeer om administratieve toegang te krijgen"
 ],
 "Switch to administrative access": [
  null,
  "Schakel om naar beheerderstoegang"
 ],
 "Authenticate": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Administrative access": [
  null,
  "Administratieve toegang"
 ],
 "Problem becoming administrator": [
  null,
  "Probleem om beheerder te worden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Beperk toegang"
 ],
 "Switch to limited access": [
  null,
  "Schakel over naar beperkte toegang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "De beperkte toegangsmodus beperkt de beheerdersrechten. Sommige delen van de webconsole hebben een verminderde functionaliteit."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Je browser onthoudt je toegangsniveau tijdens sessies."
 ],
 "Limited access": [
  null,
  "Beperkte toegang"
 ],
 "Turn on administrative access": [
  null,
  "Schakel beheerderstoegang in"
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "less than a minute ago": [
  null,
  "minder dan een minuut geleden"
 ],
 "in less than a minute": [
  null,
  "in minder dan een minuut"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Unknown host: $0": [
  null,
  "Onbekende host: $0"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporteerde foutcode $0"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "Row select": [
  null,
  "Selecteer rij"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Typ om te filteren"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Bestandssysteem"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Geen overeenkomende resultaten"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Bestand"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Priority": [
  null,
  "Prioriteit"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "None": [
  null,
  "Geen"
 ],
 "Enabled": [
  null,
  "Ingeschakeld"
 ],
 "Disabled": [
  null,
  "Uitgeschakeld"
 ],
 "Generated": [
  null,
  "Gegenereerd"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Start service": [
  null,
  "Start service"
 ],
 "Status": [
  null,
  "Toestand"
 ],
 "Delete $0": [
  null,
  "Verwijder $0"
 ],
 "Group": [
  null,
  "Groep"
 ],
 "Actions": [
  null,
  "Acties"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Not available": [
  null,
  "Niet beschikbaar"
 ],
 "Ignore": [
  null,
  "Negeren"
 ],
 "Permanent": [
  null,
  "Blijvend"
 ],
 "Preserve": [
  null,
  "Behouden"
 ],
 "Random": [
  null,
  "Willekeurig"
 ],
 "Stable": [
  null,
  "Stabiel"
 ],
 "Failed to save settings": [
  null,
  "Kan instellingen niet opslaan"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Het aanmaken van deze $0 zal de verbinding met de server verbreken waardoor deze beheerdersinterface niet meer beschikbaar zal zijn."
 ],
 "Create it": [
  null,
  "Maak het aan"
 ],
 "Invalid prefix $0": [
  null,
  "Ongeldig voorvoegsel $0"
 ],
 "Invalid metric $0": [
  null,
  "Ongeldige metriek $0"
 ],
 "Invalid address $0": [
  null,
  "Ongeldig adres $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Ongeldig voorvoegsel of netmasker $0"
 ],
 "Testing connection": [
  null,
  "Verbinding testen"
 ],
 "Restoring connection": [
  null,
  "Verbinding herstellen"
 ],
 "Troubleshoot…": [
  null,
  "Problemen oplossen…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager is niet actief"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager is niet geïnstalleerd"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Netwerkapparaten en grafieken vereisen NetworkManager"
 ],
 "Enable service": [
  null,
  "Service inschakelen"
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Jr bent niet bevoegd om de firewall te wijzigen."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Niet gemachtigd om de firewall uit te schakelen"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Niet gemachtigd om de firewall in te schakelen"
 ],
 "Disable the firewall": [
  null,
  "Schakel de firewall uit"
 ],
 "Enable the firewall": [
  null,
  "Schakel de firewall in"
 ],
 "Edit service $0": [
  null,
  "Bewerk service $0"
 ],
 "Remove service $0": [
  null,
  "Verwijder service $0"
 ],
 "Remove zone $0": [
  null,
  "Verwijder zone $0"
 ],
 "Add services to zone $0": [
  null,
  "Services toevoegen aan zone $0"
 ],
 "Add services": [
  null,
  "Services toevoegen"
 ],
 "Service": [
  null,
  "Service"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 zone"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Allowed addresses": [
  null,
  "Toegestane adressen"
 ],
 "Entire subnet": [
  null,
  "Volledig subnet"
 ],
 "There are no active services in this zone": [
  null,
  "Er zijn geen actieve services in deze zone"
 ],
 "Filter services": [
  null,
  "Filter services"
 ],
 "Failed to edit service": [
  null,
  "Service bewerken mislukte"
 ],
 "Failed to add port": [
  null,
  "Kan poort niet toevoegen"
 ],
 "Failed to add service": [
  null,
  "Kan service niet toevoegen"
 ],
 "Unknown service name": [
  null,
  "Onbekende servicenaam"
 ],
 "Invalid port number": [
  null,
  "Ongeldig poortnummer"
 ],
 "Invalid range": [
  null,
  "Ongeldig bereik"
 ],
 "Range must be strictly ordered": [
  null,
  "Bereik moet strikt geordend zijn"
 ],
 "Edit service": [
  null,
  "Bewerk service"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Bewerk aangepaste service in $0 zone"
 ],
 "Add ports": [
  null,
  "Poorten toevoegen"
 ],
 "Add ports to $0 zone": [
  null,
  "Poorten toevoegen aan $0 zone"
 ],
 "Add services to $0 zone": [
  null,
  "Services toevoegen aan $0 zone"
 ],
 "Custom ports": [
  null,
  "Aangepaste poorten"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Voorbeeld: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Door komma's gescheiden poorten, bereiken en services worden geaccepteerd"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Voorbeeld: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Indien leeg gelaten, wordt ID gegenereerd op basis van bijbehorende poortservices en poortnummers"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Door aangepaste poorten toe te voegen, wordt 'firewalld' opnieuw geladen. Herladen zal leiden tot het verlies van elke runtime-only-configuratie!"
 ],
 "Failed to add zone": [
  null,
  "Kan zone niet toevoegen"
 ],
 "Add zone": [
  null,
  "Zone toevoegen"
 ],
 "Trust level": [
  null,
  "Vertrouwensniveau"
 ],
 "Sorted from least to most trusted": [
  null,
  "Gesorteerd van minst tot meest vertrouwd"
 ],
 "Custom zones": [
  null,
  "Aangepaste zones"
 ],
 "No description available": [
  null,
  "Geen beschrijving beschikbaar"
 ],
 "Included services": [
  null,
  "Inbegrepen services"
 ],
 "The cockpit service is automatically included": [
  null,
  "De cockpit-service is automatisch inbegrepen"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Range": [
  null,
  "Reeks"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adres met routeprefix. Scheid meerdere waarden met een komma. Voorbeeld: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Deze zone bevat de cockpitservice. Zorg ervoor dat deze zone niet van toepassing is op je huidige webconsoleverbinding."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Als je de zone verwijdert, worden alle services erin verwijderd."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Als je de cockpit-service verwijdert, kan de webconsole onbereikbaar worden. Zorg ervoor dat deze zone niet van toepassing is op je huidige webconsoleverbinding."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Verwijder $0 service uit $1 zone"
 ],
 "Firewall is not available": [
  null,
  "Firewall is niet beschikbaar"
 ],
 "Please install the $0 package": [
  null,
  "Installeer het $0 pakket"
 ],
 "Add a new zone": [
  null,
  "Een nieuwe zone toevoegen"
 ],
 "Add new zone": [
  null,
  "Nieuwe zone toevoegen"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Inkomende verzoeken worden standaard geblokkeerd. Uitgaande verzoeken worden niet geblokkeerd."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "Security": [
  null,
  "Veiligheid"
 ],
 "WPA/WPA2 Personal": [
  null,
  ""
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Verwijderen van $0 verbreekt de verbinding met de server waardoor de beheerdersinterface niet meer beschikbaar zal zijn."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 inschakelt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Switch on $0": [
  null,
  "Schakel $0 in"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 uitschakelt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Switch off $0": [
  null,
  "Schakel $0 uit"
 ],
 "Bond": [
  null,
  "Binding"
 ],
 "Team": [
  null,
  "Team"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Brug"
 ],
 "Unknown \"$0\"": [
  null,
  "Onbekend \"$0\""
 ],
 "Carrier": [
  null,
  "Carrier"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "No": [
  null,
  "Nee"
 ],
 "Inactive": [
  null,
  "Inactief"
 ],
 "Unknown configuration": [
  null,
  "Onbekende configuratie"
 ],
 "Additional address $val": [
  null,
  "Extra adres $val"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Extra DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Extra DNS-zoekdomeinen $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS zoekdomeinen $val"
 ],
 "General": [
  null,
  "Algemeen"
 ],
 "Connect automatically": [
  null,
  "Verbind automatisch"
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP-bewaking"
 ],
 "Broken configuration": [
  null,
  "Defecte configuratie"
 ],
 "Team port": [
  null,
  "Teampoort"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "Prioriteit $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Voorwaartse vertraging $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Hallo tijd $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximale berichtleeftijd $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Pad kost $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Haarspeld modus"
 ],
 "Bridge port": [
  null,
  "Brugpoort"
 ],
 "Parent $parent": [
  null,
  "Ouder $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  ""
 ],
 "open": [
  null,
  ""
 ],
 "Signal strength": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "Verbinding verbreken"
 ],
 "Refresh": [
  null,
  ""
 ],
 "Network": [
  null,
  "Netwerk"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Signal": [
  null,
  ""
 ],
 "Rate": [
  null,
  ""
 ],
 "Enable or disable the device": [
  null,
  "Schakel het apparaat in of uit"
 ],
 "This device cannot be managed here.": [
  null,
  "Dit apparaat kan hier niet beheerd worden."
 ],
 "Connection will be lost": [
  null,
  "Verbinding wordt verbroken"
 ],
 "Keep connection": [
  null,
  "Houd verbinding"
 ],
 "Preparing": [
  null,
  "Voorbereiden"
 ],
 "Configuring": [
  null,
  "Configureren"
 ],
 "Authenticating": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Configuring IP": [
  null,
  "Configureren van IP"
 ],
 "Checking IP": [
  null,
  "Controleren van IP"
 ],
 "Waiting": [
  null,
  "Aan het wachten"
 ],
 "Active": [
  null,
  "Actief"
 ],
 "Deactivating": [
  null,
  "Wordt gedeactiveerd"
 ],
 "Adhoc": [
  null,
  ""
 ],
 "Infra": [
  null,
  ""
 ],
 "Mesh": [
  null,
  ""
 ],
 "No carrier": [
  null,
  "Geen signaal"
 ],
 "Part of $0": [
  null,
  "Onderdeel van $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je de instellingen wijzigt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Change the settings": [
  null,
  "Verander de instellingen"
 ],
 "Add bridge": [
  null,
  "Brug toevoegen"
 ],
 "Edit bridge settings": [
  null,
  "Bewerk bruginstellingen"
 ],
 "Ports": [
  null,
  "Poorten"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "STP prioriteit"
 ],
 "STP forward delay": [
  null,
  "STP voorwaartse vertraging"
 ],
 "STP hello time": [
  null,
  "STP hallo tijd"
 ],
 "STP maximum message age": [
  null,
  "STP maximale berichtleeftijd"
 ],
 "Round robin": [
  null,
  "Round-robin"
 ],
 "Active backup": [
  null,
  "Actieve back-up"
 ],
 "Load balancing": [
  null,
  "Taakverdeling"
 ],
 "Broadcast": [
  null,
  "Uitzending"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passief"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP-ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Team toevoegen"
 ],
 "Edit team settings": [
  null,
  "Bewerk teaminstellingen"
 ],
 "Runner": [
  null,
  "Uitvoerder"
 ],
 "Balancer": [
  null,
  "Balancer"
 ],
 "Primary": [
  null,
  "Primair"
 ],
 "Link watch": [
  null,
  "Link toezicht"
 ],
 "Link up delay": [
  null,
  "Link up vertraging"
 ],
 "Link down delay": [
  null,
  "Link down vertraging"
 ],
 "Ping interval": [
  null,
  "Ping interval"
 ],
 "Ping target": [
  null,
  "Ping doel"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisch (alleen DHCP)"
 ],
 "Link local": [
  null,
  "Link lokaal"
 ],
 "Manual": [
  null,
  "Handmatig"
 ],
 "Shared": [
  null,
  "Gedeeld"
 ],
 "Prefix length or netmask": [
  null,
  "Voorvoegsel-lengte of netmasker"
 ],
 "Prefix length": [
  null,
  "Voorvoegsel-lengte"
 ],
 "IPv4 settings": [
  null,
  "IPv4-instellingen"
 ],
 "IPv6 settings": [
  null,
  "IPv6-instellingen"
 ],
 "Addresses": [
  null,
  "Adressen"
 ],
 "Select method": [
  null,
  "Selecteer methode"
 ],
 "Add address": [
  null,
  "Voeg adres toe"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Remove item": [
  null,
  "Verwijder item"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Voeg DNS-server toe"
 ],
 "DNS search domains": [
  null,
  "DNS zoekdomeinen"
 ],
 "Add search domain": [
  null,
  "Voeg zoekdomein toe"
 ],
 "Search domain": [
  null,
  "Zoek domein"
 ],
 "Routes": [
  null,
  "Routes"
 ],
 "Add route": [
  null,
  "Voeg route toe"
 ],
 "Metric": [
  null,
  "Metriek"
 ],
 "Enter a valid MAC address": [
  null,
  "Voer een geldig MAC-adres in"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "Add VPN": [
  null,
  "VPN toevoegen"
 ],
 "Add bond": [
  null,
  "Binding toevoegen"
 ],
 "Add VLAN": [
  null,
  "VLAN toevoegen"
 ],
 "Edit rules and zones": [
  null,
  "Bewerk regels en zones"
 ],
 "$0 active zone": [
  null,
  "$0 actieve zone",
  "$0 actieve zones"
 ],
 "Managed interfaces": [
  null,
  "Beheerde interfaces"
 ],
 "IP address": [
  null,
  "IP-adres"
 ],
 "Sending": [
  null,
  "Verzenden"
 ],
 "Receiving": [
  null,
  "Ontvangen"
 ],
 "Unmanaged interfaces": [
  null,
  "Onbeheerde interfaces"
 ],
 "Network logs": [
  null,
  "Netwerklogboeken"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adressen zijn niet correct geformatteerd"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Pakket wireguard-tools is niet geïnstalleerd"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Peer #$0 heeft een ongeldige eindpuntpoort. Poort moet een getal zijn."
 ],
 "Listen port must be a number": [
  null,
  "Luisterpoort moet een getal zijn"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN toevoegen"
 ],
 "Edit WireGuard VPN": [
  null,
  "Bewerk WireGuard VPN"
 ],
 "Private key": [
  null,
  "Privé sleutel"
 ],
 "Paste existing key": [
  null,
  "Plak een bestaande sleutel"
 ],
 "Regenerate": [
  null,
  "Regenereer"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Er wordt een publieke sleutel gegenereerd wanneer een geldige privésleutel wordt ingevoerd"
 ],
 "Listen port": [
  null,
  "Luisterpoort"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Wordt ingesteld op \"Automatisch\""
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Er kunnen meerdere adressen worden opgegeven met komma's of spaties als scheidingstekens."
 ],
 "Peers": [
  null,
  "Peers"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Peers zijn andere machines die verbinding maken met deze. Openbare sleutels van andere machines worden met elkaar gedeeld."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Het eindpunt dat als \"server\" fungeert, moet worden opgegeven als host:poort, anders kan het leeg worden gelaten."
 ],
 "Add peer": [
  null,
  "Voeg gelijke toe"
 ],
 "Endpoint": [
  null,
  "Eindpunt"
 ],
 "Allowed IPs": [
  null,
  "Toegestane IP's"
 ],
 "No peers added.": [
  null,
  "Geen gelijken toegevoegd."
 ],
 "Edit VLAN settings": [
  null,
  "Bewerk VLAN-instellingen"
 ],
 "Parent": [
  null,
  "Ouder"
 ],
 "VLAN ID": [
  null,
  "VLAN-ID"
 ],
 "Transmitting": [
  null,
  "Zenden"
 ],
 "MTU must be a positive number": [
  null,
  "MTU moet een positief getal zijn"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Stel in op"
 ],
 "Team port settings": [
  null,
  "Teampoortinstellingen"
 ],
 "Sticky": [
  null,
  "Kleverig"
 ],
 "LACP key": [
  null,
  "LACP-sleutel"
 ],
 "Bridge port settings": [
  null,
  "Brugpoort instellingen"
 ],
 "Path cost": [
  null,
  "Padkosten"
 ],
 "Hair pin mode": [
  null,
  "Haarspeld modus"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptieve overdrachtstaakverdeling"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptieve taakverdeling"
 ],
 "MII (recommended)": [
  null,
  "MII (Aanbevolen)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Bewerk bindingsinstellingen"
 ],
 "Network bond": [
  null,
  "Netwerkbinding"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Een netwerkverbinding combineert meerdere netwerkinterfaces tot één logische interface met een hogere doorvoer of redundantie."
 ],
 "Link monitoring": [
  null,
  "Link monitoring"
 ],
 "Monitoring interval": [
  null,
  "Bewakingsinterval"
 ],
 "Monitoring targets": [
  null,
  "Doelen controleren"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 verwijdert, wordt de verbinding met de server verbroken en wordt de beheerdersinterface onbereikbaar."
 ],
 "Remove $0": [
  null,
  "Verwijder $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Toevoegen van $0 verbreekt de verbinding met de server en maakt de beheerdersinterface onbereikbaar."
 ],
 "Add member": [
  null,
  "Voeg lid toe"
 ],
 "Interface members": [
  null,
  "Interface leden"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ]
});
