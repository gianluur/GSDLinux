cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "删除 $0 ？"
 ],
 "Force delete": [
  null,
  "强制删除"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Must be a valid IP address": [
  null,
  "必须是有效的 IP 地址"
 ],
 "1 to 65535": [
  null,
  "1 到 65535"
 ],
 "Container port must not be empty": [
  null,
  "容器端口不能为空"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "IP address help": [
  null,
  "IP 地址帮助"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "若主机IP被设为 0.0.0.0 或完全未被设置，该端口将被绑定至主机上所有的IP地址。"
 ],
 "Host port": [
  null,
  "主机端口"
 ],
 "Host port help": [
  null,
  "主机端口帮助"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "如果主机端口没有设置，容器端口将被随机分配到主机上的一个端口。"
 ],
 "Container port": [
  null,
  "容器端口"
 ],
 "Protocol": [
  null,
  "协议"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "删除项目"
 ],
 "Image name is required": [
  null,
  "镜像名称是必需的"
 ],
 "Image name is not unique": [
  null,
  "镜像名称不是唯一的"
 ],
 "Failed to commit container $0": [
  null,
  "提交容器 $0 失败"
 ],
 "New image name": [
  null,
  "新镜像名称"
 ],
 "Tag": [
  null,
  "标签"
 ],
 "Author": [
  null,
  "作者"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "示例，您的名字 <yourname@example.com>"
 ],
 "Command": [
  null,
  "命令"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Pause container when creating image": [
  null,
  "创建镜像时暂停容器"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "当与 Docker 或 Moby Engine 共享镜像时，Docker 格式非常有用"
 ],
 "Use legacy Docker format": [
  null,
  "使用旧版 Docker 格式"
 ],
 "Commit container": [
  null,
  "提交容器"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "根据 $0 容器的当前状态创建一个新镜像。"
 ],
 "Commit": [
  null,
  "提交"
 ],
 "Force commit": [
  null,
  "强制提交"
 ],
 "Failed to force remove container $0": [
  null,
  "强制移除容器 $0 失败"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "删除正在运行的容器将会清除其中的所有数据。"
 ],
 "Failed to stop container $0": [
  null,
  "停止容器 $0 失败"
 ],
 "Failed to stop quadlet $0": [
  null,
  "停止 quadlet $0 失败"
 ],
 "Failed to start quadlet $0": [
  null,
  "启动 quadlet $0 失败"
 ],
 "Failed to start container $0": [
  null,
  "启动容器 $0 失败"
 ],
 "Failed to resume container $0": [
  null,
  "恢复容器 $0 失败"
 ],
 "Failed to pause container $0": [
  null,
  "暂停容器 $0 失败"
 ],
 "Failed to restart container $0": [
  null,
  "重启容器 $0 失败"
 ],
 "Failed to restart quadlet $0": [
  null,
  "重启 quadlet $0 失败"
 ],
 "Rename": [
  null,
  "重命名"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Restart": [
  null,
  "重启"
 ],
 "Force stop": [
  null,
  "强制停止"
 ],
 "Force restart": [
  null,
  "强制重启"
 ],
 "Pause": [
  null,
  "暂停"
 ],
 "Resume": [
  null,
  "继续"
 ],
 "Checkpoint": [
  null,
  "检查点"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Restore": [
  null,
  "恢复"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Healthy": [
  null,
  "健康"
 ],
 "Unhealthy": [
  null,
  "不健康"
 ],
 "Checking health": [
  null,
  "检查健康状况"
 ],
 "Prune unused containers": [
  null,
  "删除未使用的容器"
 ],
 "Terminal not available": [
  null,
  "终端不可用"
 ],
 "This browser does not support WebGL2.": [
  null,
  "此浏览器不支持 WebGL2。"
 ],
 "View $0 logs": [
  null,
  "查看 $0 日志"
 ],
 "not available": [
  null,
  "不可用"
 ],
 "n/a": [
  null,
  "不适用"
 ],
 "$0% of $1 limit": [
  null,
  "$1 限制的 $0%"
 ],
 "service": [
  null,
  "服务"
 ],
 "system": [
  null,
  "系统"
 ],
 "user:": [
  null,
  "用户："
 ],
 "Details": [
  null,
  "详情"
 ],
 "Integration": [
  null,
  "集成"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "Console": [
  null,
  "控制台"
 ],
 "Health check": [
  null,
  "健康检查"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "内存"
 ],
 "Click to see published ports": [
  null,
  "点击以查看公布的端口"
 ],
 "ports": [
  null,
  "端口"
 ],
 "Click to see volumes": [
  null,
  "点击以查看卷"
 ],
 "volumes": [
  null,
  "卷"
 ],
 "Container": [
  null,
  "容器"
 ],
 "Owner": [
  null,
  "所有者"
 ],
 "State": [
  null,
  "状态"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "No containers": [
  null,
  "没有容器"
 ],
 "No containers in this pod": [
  null,
  "此 pod 中没有容器"
 ],
 "Loading...": [
  null,
  "加载中……"
 ],
 "No containers that match the current filter": [
  null,
  "没有符合当前筛选条件的容器"
 ],
 "No running containers": [
  null,
  "没有正在运行的容器"
 ],
 "Show": [
  null,
  "显示"
 ],
 "All": [
  null,
  "所有"
 ],
 "Only running": [
  null,
  "仅运行"
 ],
 "Create pod": [
  null,
  "创建 pod"
 ],
 "Create container": [
  null,
  "创建容器"
 ],
 "Containers": [
  null,
  "容器"
 ],
 "Create container in pod": [
  null,
  "在 pod 中创建容器"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "恢复容器 $0 失败"
 ],
 "Restore container $0": [
  null,
  "恢复容器 $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "保留所有临时检查点文件"
 ],
 "Restore with established TCP connections": [
  null,
  "使用已建立的 TCP 连接恢复"
 ],
 "Ignore IP address if set statically": [
  null,
  "如果以静态方式设置，则忽略 IP 地址"
 ],
 "Ignore MAC address if set statically": [
  null,
  "忽略被静态设定的 MAC 地址"
 ],
 "Pod failed to be created": [
  null,
  "创建 Pod 失败"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "无效的字符。名称只能包含字母、数字和某些标点符号 (_ . -)。"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Pod name": [
  null,
  "Pod 名称"
 ],
 "System": [
  null,
  "系统"
 ],
 "User:": [
  null,
  "用户："
 ],
 "No ports exposed": [
  null,
  "没有公开的端口"
 ],
 "Port mapping": [
  null,
  "端口映射"
 ],
 "Add port mapping": [
  null,
  "添加端口映射"
 ],
 "No volumes specified": [
  null,
  "没有指定卷"
 ],
 "Volumes": [
  null,
  "卷"
 ],
 "Add volume": [
  null,
  "添加卷"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Type to filter…": [
  null,
  "输入筛选条件……"
 ],
 "Container path must not be empty": [
  null,
  "容器路径不能为空"
 ],
 "Host path": [
  null,
  "主机路径"
 ],
 "Container path": [
  null,
  "容器路径"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Writable": [
  null,
  "可写入"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "无标签"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Private": [
  null,
  "私有"
 ],
 "Read-write access": [
  null,
  "读写访问"
 ],
 "Read-only access": [
  null,
  "只读访问"
 ],
 "Show less": [
  null,
  "显示更少"
 ],
 "Show more": [
  null,
  "显示更多"
 ],
 "Loading details...": [
  null,
  "加载详细信息..."
 ],
 "Ports": [
  null,
  "端口"
 ],
 "Environment variables": [
  null,
  "环境变量"
 ],
 "Failed to download image $0:$1": [
  null,
  "下载镜像 $0:$1 失败"
 ],
 "Error message": [
  null,
  "错误信息"
 ],
 "unused": [
  null,
  "未使用"
 ],
 "$0 container": [
  null,
  "$0 容器"
 ],
 "History": [
  null,
  "历史"
 ],
 "Image": [
  null,
  "镜像"
 ],
 "Created": [
  null,
  "已创建"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "磁盘空间"
 ],
 "Used by": [
  null,
  "使用者"
 ],
 "No images": [
  null,
  "没有镜像"
 ],
 "No images that match the current filter": [
  null,
  "没有符合当前筛选条件的镜像"
 ],
 "Hide intermediate images": [
  null,
  "隐藏中间镜像"
 ],
 "Show intermediate images": [
  null,
  "显示中间镜像"
 ],
 "Images": [
  null,
  "镜像"
 ],
 "$0 image total, $1": [
  null,
  "共 $0 个镜像，$1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 未使用的镜像，$1"
 ],
 "Hide images": [
  null,
  "隐藏镜像"
 ],
 "Show images": [
  null,
  "显示镜像"
 ],
 "Pulling": [
  null,
  "正在拉取"
 ],
 "Download new image": [
  null,
  "下载新镜像"
 ],
 "Pull all images": [
  null,
  "拉取所有镜像"
 ],
 "Prune unused images": [
  null,
  "删除未使用的镜像"
 ],
 "Pull": [
  null,
  "拉取"
 ],
 "Up since:": [
  null,
  "运行时间:"
 ],
 "Exited": [
  null,
  "已退出"
 ],
 "systemd service": [
  null,
  "systemd 服务"
 ],
 "View $0": [
  null,
  "查看 $0"
 ],
 "Gateway": [
  null,
  "网关"
 ],
 "MAC address": [
  null,
  "MAC 地址"
 ],
 "Latest checkpoint": [
  null,
  "最新的检查点"
 ],
 "No containers are using this image": [
  null,
  "没有使用该镜像的容器"
 ],
 "Running": [
  null,
  "正在运行"
 ],
 "Loading logs...": [
  null,
  "正在加载日志..."
 ],
 "Delete unused system images:": [
  null,
  "删除未使用的系统镜像："
 ],
 "Delete unused images of user $0:": [
  null,
  "删除用户 $0 未使用的镜像:"
 ],
 "Failed to prune unused images": [
  null,
  "删除未使用的映像失败"
 ],
 "Pruning images": [
  null,
  "删除镜像"
 ],
 "Prune": [
  null,
  "删除"
 ],
 "Failed to checkpoint container $0": [
  null,
  "为容器 $0 创建检查点失败"
 ],
 "Checkpoint container $0": [
  null,
  "为容器 $0 创建检查点"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "在将检查点写入磁盘后保持运行"
 ],
 "Support preserving established TCP connections": [
  null,
  "支持保留已建立的 TCP 连接"
 ],
 "Failed to search for new images": [
  null,
  "搜索新镜像失败"
 ],
 "Failed to search for images: $0": [
  null,
  "搜索镜像 $0 失败"
 ],
 "Failed to search for images.": [
  null,
  "搜索镜像失败。"
 ],
 "Search for an image": [
  null,
  "搜索镜像"
 ],
 "Search for": [
  null,
  "搜索"
 ],
 "Search by name or description": [
  null,
  "按名称或描述搜索"
 ],
 "in": [
  null,
  "于"
 ],
 "All registries": [
  null,
  "所有镜像仓库"
 ],
 "Searching...": [
  null,
  "搜索中..."
 ],
 "No images found": [
  null,
  "没有找到镜像"
 ],
 "Start typing to look for images.": [
  null,
  "开始键入来查找镜像。"
 ],
 "No results for $0": [
  null,
  "没有 $0 的结果"
 ],
 "Retry another term.": [
  null,
  "重试另一个项。"
 ],
 "Download": [
  null,
  "下载"
 ],
 "No action": [
  null,
  "无操作"
 ],
 "Container failed to be started": [
  null,
  "容器启动失败"
 ],
 "Failed to clean up container": [
  null,
  "清理容器失败"
 ],
 "Container failed to be created": [
  null,
  "容器创建失败"
 ],
 "downloading": [
  null,
  "下载"
 ],
 "Failed to run container $0": [
  null,
  "运行容器 $0 失败"
 ],
 "Failed to create container $0": [
  null,
  "创建容器 $0 失败"
 ],
 "Failed to pull image $0": [
  null,
  "拉取镜像 $0 失败"
 ],
 "Local images": [
  null,
  "本地镜像"
 ],
 "Name already in use": [
  null,
  "名称已被使用"
 ],
 "Search by registry": [
  null,
  "按镜像仓库搜索"
 ],
 "Local": [
  null,
  "本地"
 ],
 "Container name": [
  null,
  "容器名称"
 ],
 "Owner help": [
  null,
  "所有者帮助"
 ],
 "Ideal for running services": [
  null,
  "适合运行服务使用"
 ],
 "Resource limits can be set": [
  null,
  "可以设置资源限制"
 ],
 "Checkpoint and restore support": [
  null,
  "检查点和恢复支持"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "1024 以下的端口可以映射"
 ],
 "User": [
  null,
  "用户"
 ],
 "Ideal for development": [
  null,
  "适合开发使用"
 ],
 "Restricted by user account permissions": [
  null,
  "受用户帐户权限限制"
 ],
 "Image selection help": [
  null,
  "镜像选择帮助"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "Example: $0": [
  null,
  "示例：$0"
 ],
 "Searching: $0": [
  null,
  "搜索: $0"
 ],
 "Search string or container location": [
  null,
  "搜索字符串或容器位置"
 ],
 "Pull latest image": [
  null,
  "拉取最新的镜像"
 ],
 "Entrypoint": [
  null,
  "入口点"
 ],
 "With terminal": [
  null,
  "使用终端"
 ],
 "Memory limit": [
  null,
  "内存限制"
 ],
 "Decrease memory": [
  null,
  "减少内存"
 ],
 "Increase memory": [
  null,
  "增加内存"
 ],
 "Memory unit": [
  null,
  "内存单元"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU 权重"
 ],
 "CPU Shares help": [
  null,
  "CPU 权重帮助"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 份额决定了运行容器的优先级。默认优先级为 1024。数字越大，容器的优先级越高。数字越小，优先级越低。"
 ],
 "Decrease CPU shares": [
  null,
  "减少 CPU 共享"
 ],
 "Increase CPU shares": [
  null,
  "增加 CPU 共享"
 ],
 "Restart policy": [
  null,
  "重启策略"
 ],
 "Restart policy help": [
  null,
  "重启策略帮助"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "容器退出时重启策略。在某些情况下，使用 linger 进行自动启动容器可能无法正常工作，如在用户账户中使用了 ecryptfs、systemd-homed、NFS 或 2FA。"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "容器退出后遵循的重启策略。"
 ],
 "No": [
  null,
  "否"
 ],
 "On failure": [
  null,
  "失败时"
 ],
 "Always": [
  null,
  "总是"
 ],
 "Maximum retries": [
  null,
  "最大重试次数"
 ],
 "Decrease maximum retries": [
  null,
  "减小最大重试次数"
 ],
 "Increase maximum retries": [
  null,
  "增加最大重试次数"
 ],
 "No environment variables specified": [
  null,
  "没有指定环境变量"
 ],
 "Add variable": [
  null,
  "添加变量"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "将一个或多个键值对（key=value）粘贴到任意字段以批量导入"
 ],
 "Interval": [
  null,
  "间隔"
 ],
 "Health check interval help": [
  null,
  "健康检查间隔帮助"
 ],
 "Interval how often health check is run.": [
  null,
  "运行健康检查的间隔时间。"
 ],
 "Decrease interval": [
  null,
  "缩短间隔"
 ],
 "Increase interval": [
  null,
  "增加间隔"
 ],
 "seconds": [
  null,
  "秒"
 ],
 "Timeout": [
  null,
  "超时"
 ],
 "Health check timeout help": [
  null,
  "健康检查超时帮助"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "当间隔被视为失败前，允许完成健康检查的最长时间。"
 ],
 "Decrease timeout": [
  null,
  "减少超时"
 ],
 "Increase timeout": [
  null,
  "增加超时"
 ],
 "Start period": [
  null,
  "开始期间"
 ],
 "Health check start period help": [
  null,
  "健康检查启动周期帮助"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "容器进行 bootstrap 所需的初始化时间。"
 ],
 "Decrease start period": [
  null,
  "减少启动周期"
 ],
 "Increase start period": [
  null,
  "增加开始周期"
 ],
 "Retries": [
  null,
  "重试"
 ],
 "Health check retries help": [
  null,
  "健康检查重试帮助"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "在健康检查被视为不健康前，允许的重试次数。"
 ],
 "Decrease retries": [
  null,
  "减少重试"
 ],
 "Increase retries": [
  null,
  "增加重试"
 ],
 "When unhealthy": [
  null,
  "当不健康时"
 ],
 "Health failure check action help": [
  null,
  "健康检查失败操作帮助"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "容器转换到不健康状态后要执行的操作。"
 ],
 "Create container in $0": [
  null,
  "在 $0 中创建容器"
 ],
 "Create and run": [
  null,
  "创建并运行"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Version": [
  null,
  "版本"
 ],
 "Links": [
  null,
  "链接"
 ],
 "Documentation": [
  null,
  "文档"
 ],
 "Tags": [
  null,
  "标签"
 ],
 "Created by": [
  null,
  "创建"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Comments": [
  null,
  "注释"
 ],
 "Unable to load image history": [
  null,
  "无法加载镜像历史记录"
 ],
 "Key must not be empty": [
  null,
  "键不能为空"
 ],
 "Key must not begin with a digit": [
  null,
  "键不能以数字开头"
 ],
 "Key contains invalid characters": [
  null,
  "键包含无效字符"
 ],
 "Key": [
  null,
  "键"
 ],
 "Value": [
  null,
  "值"
 ],
 "user": [
  null,
  "用户"
 ],
 "Podman service failed": [
  null,
  "Podman 服务失败"
 ],
 "Troubleshoot": [
  null,
  "故障排除"
 ],
 "Failed to force remove image $0": [
  null,
  "强制删除镜像失败 $0"
 ],
 "intermediate image": [
  null,
  "中间层镜像"
 ],
 "Failed to remove image $0": [
  null,
  "删除镜像 $0 失败"
 ],
 "intermediate": [
  null,
  "中间层"
 ],
 "Delete $0 image?": [
  null,
  "删除 $0 镜像？"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "此镜像存在多个标签。选择要删除的有标签镜像。"
 ],
 "Delete image": [
  null,
  "删除镜像"
 ],
 "Delete tagged images": [
  null,
  "删除有标签的镜像"
 ],
 "Container is not running": [
  null,
  "容器未运行"
 ],
 "Error occurred while connecting console": [
  null,
  "连接到控制台时出现错误"
 ],
 "Force delete pod $0?": [
  null,
  "强制删除 pod $0？"
 ],
 "Delete pod $0?": [
  null,
  "删除 pod $0？"
 ],
 "An error occurred": [
  null,
  "发生了错误"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "空 pod $0 将被永久删除。"
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "删除这个 Pod 将会移除这些容器："
 ],
 "Failed to start pod $0": [
  null,
  "启动 Pod $0 失败"
 ],
 "Failed to stop pod $0": [
  null,
  "停止 Pod $0 失败"
 ],
 "Failed to restart pod $0": [
  null,
  "重启 pod $0 失败"
 ],
 "Failed to resume pod $0": [
  null,
  "恢复 Pod $0 失败"
 ],
 "Failed to pause pod $0": [
  null,
  "暂停 Pod $0 失败"
 ],
 "Failed to prune unused containers": [
  null,
  "删除未使用的容器失败"
 ],
 "Removes selected non-running containers": [
  null,
  "删除选择的、没有在运行的容器"
 ],
 "Pruning containers": [
  null,
  "正在删除容器"
 ],
 "Container name is required.": [
  null,
  "容器名称是必需的。"
 ],
 "Failed to rename container $0": [
  null,
  "重命名容器 $0 失败"
 ],
 "New container name": [
  null,
  "新容器名称"
 ],
 "Rename container $0": [
  null,
  "重命名容器 $0"
 ],
 "Paused": [
  null,
  "已暂停"
 ],
 "Stopped": [
  null,
  "已停止"
 ],
 "Removing": [
  null,
  "删除"
 ],
 "Configured": [
  null,
  "已配置"
 ],
 "Error": [
  null,
  "错误"
 ],
 "$0 second": [
  null,
  "$0 秒"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Failing streak": [
  null,
  "streak 失败"
 ],
 "Failed to run health check on container $0": [
  null,
  "在容器 $0 上运行健康检查失败"
 ],
 "Run health check": [
  null,
  "运行健康检查"
 ],
 "Last 5 runs": [
  null,
  "最后 5 个运行"
 ],
 "Started at": [
  null,
  "开始于"
 ],
 "Passed health run": [
  null,
  "通过的健康运行"
 ],
 "Failed health run": [
  null,
  "失败的健康运行"
 ],
 "Failed to remove container $0": [
  null,
  "移除容器 $0 失败"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "删除容器会清空其中的全部数据。"
 ]
});
