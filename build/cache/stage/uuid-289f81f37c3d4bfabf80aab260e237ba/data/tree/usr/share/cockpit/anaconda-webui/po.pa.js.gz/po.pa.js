cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pa",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 ਗਲਤੀ",
  "$0 ਗਲਤੀਆਂ"
 ],
 "$0 installation": [
  null,
  "$0 ਇੰਸਟਾਲੇਸ਼ਨ"
 ],
 "$0 installer": [
  null,
  "$0 ਇੰਸਟਾਲਰ"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 ਇੱਕ MBR ਇਕਸਟੈਂਡਡ ਪਾਰਟੀਸ਼ਨ ਹੈ, ਜਿਸ ਵਿੱਚ ਲਾਜ਼ੀਕਲ ਪਾਰਟੀਸ਼ਨ ਹਨ। ਸਾਰੇ ਲਾਜ਼ੀਕਲ ਪਾਰਟੀਸ਼ਨਾਂ ਨੂੰ ਹਟਾਉਣ ਨਾਲ ਇਕਸਟੈਂਡਡ ਪਾਰਟੀਸ਼ਨ ਵੀ ਆਪਣੇ-ਆਪ ਹਟਾਏ ਜਾਣਗੇ।"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 ਦੀ ਲੋੜ ਸੀ, ਪਰ ਸਿਰਫ਼ $1 ਹੀ ਮੌਜੂਦ ਹੈ।"
 ],
 "$0 warning": [
  null,
  "$0 ਚੇਤਾਵਨੀ",
  "$0 ਚੇਤਾਵਨੀਆਂ"
 ],
 "$0 will be deleted": [
  null,
  "$0 ਨੂੰ ਹਟਾਇਆ ਜਾਵੇਗਾ"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' ਫਾਇਲ-ਸਿਸਟਮ ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ ਬਲਾਕ ਡਿਵਾਈਸ ਉੱਤੇ ਨਹੀਂ ਹੋ ਸਕਦਾ ਹੈ"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' '$1' ਨੂੰ ਦਿੱਤਾ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' ਨੂੰ '$1' ਫਾਰਮੈਟ ਕੀਤੇ ਡਿਵਾਈਸ ਉੱਤੇ ਹੀ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' ਇੱਕ EFI ਸਿਸਟਮ ਪਾਰਟੀਸ਼ਨ ਉੱਤੇ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ। ਚੁਣਿਆ ਪਾਰਟੀਸ਼ਨ FAT ਫ਼ਾਇਲ-ਸਿਸਟਮ ਵਰਤਦਾ ਹੈ, ਪਰ ESP ਵਜੋਂ ਨਿਸ਼ਾਨ ਨਹੀਂ ਲਾਇਆ ਹੈ। ਪਾਰਟੀਸ਼ਨ ਦੀ ਕਿਸਮ ਨੂੰ EFI ਸਿਸਟਮ ਵਜੋਂ ਚੁਣੋ ਅਤੇ esp ਨਿਸ਼ਾਨ ਸਮਰੱਥ ਕਰੋ।"
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "ਪੂਰੇ ਸਿਸਟਮ ਲਈ ਤਬਦੀਲੀਆਂ ਕਰਨ ਵਾਸਤੇ ਐਡਮਿਨ ਪਹੁੰਚ ਨਾਲ ਸਧਾਰਨ ਵਰਤੋਂਕਾਰ ਖਾਤਾ ਹੈ।"
 ],
 "Abort installation": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਅਧੂਰੀ ਛੱਡੋ"
 ],
 "About": [
  null,
  "ਇਸ ਬਾਰੇ"
 ],
 "Account": [
  null,
  "ਖਾਤਾ"
 ],
 "Actions": [
  null,
  "ਕਾਰਵਾਈਆਂ"
 ],
 "Add another server...": [
  null,
  "...ਹੋਰ ਸਰਵਰ ਜੋੜੋ"
 ],
 "Add mount": [
  null,
  "ਮਾਊਂਟ ਨੂੰ ਜੋੜੋ"
 ],
 "Add-ons for your chosen environment": [
  null,
  "ਚੁਣੇ ਇਨਵਾਇਰਮੈਂਟ ਲਈ ਐਡ-ਆਨ"
 ],
 "Add-ons not specific to your environment": [
  null,
  "ਤੁਹਾਡੇ ਇਨਵਾਇਰਮੈਂਟ ਲਈ ਐਡ-ਆਨ ਨਹੀਂ ਦਿੱਤੇ ਗਏ"
 ],
 "Additional languages": [
  null,
  "ਹੋਰ ਵਧੀਕ ਭਾਸ਼ਾਵਾਂ"
 ],
 "Additional software for the selected environment": [
  null,
  "ਚੁਣੇ ਹੋਏ ਇਨਵਾਇਰਮੈਂਟ ਲਈ ਵਧੀਕ ਸਾਫਟਵੇਅਰ"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ ਵਿੱਚ ਕੀਤੀਆਂ ਕੋਈ ਵੀ ਤਬਦੀਲੀਆਂ ਫ਼ੌਰਨ ਲਾਗੂ ਹੁੰਦੀਆਂ ਹਨ।"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "ਇਸ ਵਾਕ ਨੂੰ ਵਰਤਣ ਵਾਲੇ ਸਾਰੇ ਡਿਵਾਈਸ ਅਣ-ਲਾਕ ਕੀਤੇ ਜਾਣਗੇ"
 ],
 "Anaconda Web UI": [
  null,
  "ਐਨਾਕਾਂਡਾ ਵੈੱਬ UI"
 ],
 "Anaconda project page": [
  null,
  "ਐਨਾਕਾਂਡਾ ਪਰੋਜੈਕਟ ਸਫ਼ਾ"
 ],
 "Apply mount point assignment and install": [
  null,
  "ਨਿਰਧਾਰਿਤ ਕੀਤੇ ਮਾਊਂਟ ਪੁਆਇੰਟ ਲਾਗੂ ਕਰੋ ਅਤੇ ਇੰਸਟਾਲ ਕਰੋ"
 ],
 "Applying changes...": [
  null,
  "ਤਬਦੀਲੀਆਂ ਲਾਗੂ ਕੀਤੀਆਂ ਜਾ ਰਹੀਆਂ ਹਨ..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "ਮਾਊਂਟ ਪੁਆਇੰਟਾਂ ਨੂੰ ਪਾਰਟੀਸ਼ਨ ਦਿਓ। ਪਹਿਲਾਂ ਹੀ ਸੰਰਚਿਤ ਕੀਤੇ ਕਸਟਮ ਲੇਆਉਂਟ ਲਈ ਫਾਇਦੇਮੰਦ ਹੈ।"
 ],
 "Automatic log file upload": [
  null,
  "ਆਪਣੇ-ਆਪ ਲਾਗ ਫ਼ਾਇਲ ਨੂੰ ਅੱਪਲੋਡ ਕਰੋ"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "ਸਮਾਂ ਸਰਵਰਾਂ ਨੂੰ ਵਰਤ ਕੇ ਆਪਣੇ-ਆਪ ਤਾਰੀਖ ਅਤੇ ਸਮਾਂ ਸੈੱਟ ਕਰੋ"
 ],
 "Automatically set timezone": [
  null,
  "ਆਪਣੇ-ਆਪ ਸਮਾਂ ਖੇਤਰ ਸੈੱਟ ਕਰੋ"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "ਮੌਜੂਦ ਖ਼ਾਲੀ ਥਾਂ: $0। ਇੰਸਟਾਲੇਸ਼ਨ ਲਈ ਚਾਹੀਦੀ ਥਾਂ: $1।"
 ],
 "Back": [
  null,
  "ਪਿੱਛੇ"
 ],
 "Base environment": [
  null,
  "ਬੇਸ ਇੰਵਾਇਰਨਮੈਂਟ"
 ],
 "Brief description of the issue": [
  null,
  "ਮਸਲੇ ਬਾਰੇ ਸੰਖੇਪ ਜਾਣਕਾਰੀ"
 ],
 "Bug report details": [
  null,
  "ਬੱਗ ਰਿਪੋਰਟ ਦੇ ਵੇਰਵੇ"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "ਇਸ ਸਾਫਟਵੇਅਰ ਨੂੰ ਵਰਤਣਾ ਜਾਰੀ ਰੱਖ ਕੇ ਤੁਸੀਂ ਅਧੂਰੇ ਰੀਲਿਜ਼ ਕੀਤੇ ਸਾਫਟਵੇਅਰ ਨਾਲ ਸੰਬੰਧਿਤ ਖ਼ਤਰਿਆਂ ਨੂੰ ਸਮਝਦੇ ਅਤੇ ਮਨਜ਼ੂਰ ਕਰਦੇ ਹੋ, ਕਿ ਤੁਸੀਂ ਇਸ ਨੂੰ ਸਿਫ਼ਰ ਟੈਸਟ ਅਤੇ ਵਿਕਾਸ ਕਰਨ ਲਈ ਵਰਤਣਾ ਚਾਹੁੰਦੇ ਹੋ ਅਤੇ ਇਸ ਕੰਮ ਵਿੱਚ ਸੁਧਾਰ ਕਰਨ ਵਸਾਤੇ ਕੋਈ ਵੀ ਬੱਗ ਜਾਂ ਸਮੱਸਿਆ ਬਾਰੇ ਜਾਣਕਾਰੀ ਦੇਣਾ ਚਾਹੁੰਦੇ ਹੋ।"
 ],
 "Cancel": [
  null,
  "ਰੱਦ ਕਰੋ"
 ],
 "Change": [
  null,
  "ਬਦਲੋ"
 ],
 "Change destination": [
  null,
  "ਟਿਕਾਣੇ ਨੂੰ ਬਦਲੋ"
 ],
 "Change hostname": [
  null,
  "ਹੋਸਟ ਨਾਂ ਨੂੰ ਬਦਲੋ"
 ],
 "Change partition layout": [
  null,
  "ਪਾਰਟੀਸ਼ਨ ਖਾਕੇ ਨੂੰ ਬਦਲੋ"
 ],
 "Change system keyboard layout": [
  null,
  "ਸਿਸਟਮ ਕੀਬੋਰਡ ਖਾਕੇ ਨੂੰ ਬਦਲੋ"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "ਇੱਥੇ ਕੀਤੀਆਂ ਤਬਦੀਲੀਆਂ ਸਿਸਟਮ ਉੱਤੇ ਫ਼ੌਰਨ ਲਾਗੂ ਹੋਣਗੀਆਂ। ਕੋਈ ਵਾਪਸੀ ਸੰਭਵ ਨਹੀਂ ਹੈ।"
 ],
 "Checking installation configuration...": [
  null,
  "...ਇੰਸਟਾਲੇਸ਼ਨ ਸੰਰਚਨਾ ਜਾਂਚੀ ਜਾ ਰਹੀ ਹੈ"
 ],
 "Checking storage configuration": [
  null,
  "ਸਟੋਰੇਜ਼ ਸੰਰਚਨਾ ਜਾਂਚੀ ਜਾ ਰਹੀ ਹੈ"
 ],
 "Clear search": [
  null,
  "ਖੋਜ ਨੂੰ ਮਿਟਾਓ"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "ਇਹਨਾਂ ਚੇਤਾਵਨੀਆਂ ਦੇ ਬਾਵਜੂਦ ਜਾਰੀ ਰੱਖਣ ਲਈ 'ਅੱਗੇ' ਨੂੰ ਕਲਿੱਕ ਕਰੋ।"
 ],
 "Close": [
  null,
  "ਬੰਦ ਕਰੋ"
 ],
 "Close storage editor": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ ਨੂੰ ਬੰਦ ਕਰੋ"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "ਕਾਕਪਿਟ ਸਟੋਰੋਜ਼ ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ ਹੋਏ ਡਿਵਾਈਸ ਨੂੰ ਅਣ-ਲਾਕ ਕਰਨ ਲਈ ਵਾਕ ਨਹੀਂ ਦਿੱਤਾ ਸੀ।"
 ],
 "Completed": [
  null,
  "ਪੂਰਾ ਹੈ"
 ],
 "Configuration is incomplete": [
  null,
  "ਸੰਰਚਨਾ ਅਧੂਰੀ ਹੈ"
 ],
 "Configure NTP servers": [
  null,
  "NTP ਸਰਵਰ ਦੀ ਸੰਰਚਨਾ"
 ],
 "Configure custom NTP servers": [
  null,
  "ਪਸੰਦੀਦਾ NTP ਸਰਵਰ ਦੀ ਸੰਰਚਨਾ"
 ],
 "Configure network": [
  null,
  "ਨੈੱਟਵਰਕ ਦੀ ਸੰਰਚਨਾ"
 ],
 "Configure storage": [
  null,
  "ਸਟੋਰੇਜ਼ ਦੀ ਸੰਰਚਨਾ"
 ],
 "Configure storage again": [
  null,
  "ਸਟੋਰੇਜ਼ ਦੀ ਸੰਰਚਨਾ ਫੇਰ ਕਰੋ"
 ],
 "Confirm passphrase": [
  null,
  "ਵਾਕ ਦੀ ਤਸਦੀਕ"
 ],
 "Continue": [
  null,
  "ਜਾਰੀ ਰੱਖੋ"
 ],
 "Continue installation": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਜਾਰੀ ਰੱਖੋ"
 ],
 "Continue installation?": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਜਾਰੀ ਰੱਖਣੀ ਹੈ?"
 ],
 "Continue with installation": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਨਾਲ ਜਾਰੀ ਰੱਖੋ"
 ],
 "Correct these issues before continuing.": [
  null,
  "ਜਾਰੀ ਰੱਖਣ ਤੋਂ ਪਹਿਲਾਂ ਇਹ ਮਸਲੇ ਠੀਕ ਕਰੋ।"
 ],
 "Create Account": [
  null,
  "ਖਾਤਾ ਬਣਾਓ"
 ],
 "Create account": [
  null,
  "ਖਾਤਾ ਬਣਾਓ"
 ],
 "Currently installed: $0": [
  null,
  "ਇਸ ਵੇਲੇ ਇੰਸਟਾਲ ਹੈ: $0"
 ],
 "Custom": [
  null,
  "ਪਸੰਦੀਦਾ"
 ],
 "Date": [
  null,
  "ਤਾਰੀਖ"
 ],
 "Date and time": [
  null,
  "ਤਾਰੀਖ ਅਤੇ ਸਮਾਂ"
 ],
 "Delete partition": [
  null,
  "ਪਾਰਟੀਸ਼ਨ ਨੂੰ ਹਟਾਓ"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "ਕੁਝ ਪਾਰਟੀਸ਼ਨ ਹਟਾਉਣ ਨਾਲ $0 ਨੂੰ ਬੂਟ ਕਰਨ ਤੋਂ ਰੋਕ ਲੱਗ ਸਕਦੀ ਹੈ: $1"
 ],
 "Description": [
  null,
  "ਵੇਰਵਾ"
 ],
 "Destination": [
  null,
  "ਟਿਕਾਣਾ"
 ],
 "Destination is encrypted": [
  null,
  "ਟਿਕਾਣਾ ਇੰਕ੍ਰਿਪਟ ਕੀਤਾ ਹੋਇਆ ਹੈ"
 ],
 "Detailed description of the issue": [
  null,
  "ਮਸਲੇ ਬਾਰੇ ਵੇਰਵੇ ਸਮੇਤ ਜਾਣਕਾਰੀ"
 ],
 "Detected valid storage layout:": [
  null,
  "ਜਾਇਜ਼ ਸਟੋਰੇਜ਼ ਖਾਕਾ ਖੋਜਿਆ ਗਿਆ:"
 ],
 "Device": [
  null,
  "ਡਿਵਾਈਸ"
 ],
 "Duplicate device.": [
  null,
  "ਮਲਟੀ-ਪਾਥ ਡਿਵਾਈਸ।"
 ],
 "Duplicate mount point.": [
  null,
  "ਡੁਪਲੀਕੇਟ ਮਾਊਂਟ ਪੁਆਇੰਟ।"
 ],
 "Enable root account": [
  null,
  "ਰੂਟ ਖਾਤਾ ਸਮਰੱਥ ਕਰੋ"
 ],
 "Encrypt my data": [
  null,
  "ਮੇਰਾ ਡਾਟਾ ਇੰਕ੍ਰਿਪਟ ਕਰੋ"
 ],
 "Encrypted": [
  null,
  "ਇੰਕ੍ਰਿਪਟ ਹੈ"
 ],
 "Encryption": [
  null,
  "ਇੰਕ੍ਰਿਪਸ਼ਨ"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Environment": [
  null,
  "ਇੰਨਵਾਇਰਨਮੈਂਟ"
 ],
 "Erase data and install": [
  null,
  "ਡਾਟੇ ਨੂੰ ਮਿਟਾਓ ਅਤੇ ਇੰਸਟਾਲ ਕਰੋ"
 ],
 "Error details": [
  null,
  "ਗਲਤੀ ਦੇ ਵੇਰਵੇ"
 ],
 "Exit to live desktop": [
  null,
  "ਲਾਈਵ ਡੈਸਕਟਾਪ ਉੱਤੇ ਜਾਓ"
 ],
 "Extended partition": [
  null,
  "ਐਕਸਟੈਂਡਡ ਪਾਰਟੀਸ਼ਨ"
 ],
 "Failed to report issue": [
  null,
  "ਮਸਲੇ ਬਾਰੇ ਰਿਪੋਰਟ ਭੇਜਣ ਲਈ ਅਸਫ਼ਲ"
 ],
 "Failed to save layouts": [
  null,
  "ਲੇਆਉਟ ਸੰਭਾਲਣ ਲਈ ਅਸਫ਼ਲ"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "ਫੇਡੋਰਾ ਲੀਨਕਸ ਲਈ ਘੱਟੋ-ਘੱਟ $0 ਡਿਸਕ ਥਾਂ ਚਾਹੀਦੀ ਹੈ।"
 ],
 "Finalization": [
  null,
  "ਪੂਰਨਾ"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "ਆਖਰੀ ਪੜਾਅ: ਸਿਸਟਮ ਦੀ ਸੰਰਚਨਾ ਪੂਰੀ ਹੋ ਗਈ ਹੈ। ਇੰਸਟਾਲੇਸ਼ਨ ਨੂੰ ਪੂਰਾ ਕਰਨ ਲਈ ਕੁਝ ਪਲ ਲੱਗ ਸਕਦੇ ਹਨ।"
 ],
 "Find layout": [
  null,
  "ਲੇਆਉਟ ਲੱਭੋ"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "ਚੰਗੀ ਸੁਰੱਖਿਆ ਵਾਸਤੇ ਰੂਟ (root) ਖਾਤੇ ਨੂੰ ਸਿੱਧਾ ਵਰਤਣ ਤੋਂ ਪਰਹੇਜ਼ ਕਰੋ। ਇਸ ਦੀ ਬਜਾਏ ਸਿਸਟਮ ਦੇ ਇੰਤਜ਼ਾਮ ਲਈ ਉੱਤੇ ਦਿੱਤੇ ਲੋਕਲ ਖਾਤੇ ਨੂੰ ਵਰਤੋਂ।"
 ],
 "Full name": [
  null,
  "ਪੂਰਾ ਨਾਂ"
 ],
 "Full name cannot contain colon characters": [
  null,
  "ਫਾਇਲ ਨਾਂ ਵਿੱਚ ਕਾਲਨ ਅੱਖਰ ਨਹੀਂ ਹੋ ਸਕਦੇ"
 ],
 "Helper text": [
  null,
  "ਸਹਾਇਕ ਲਿਖਤ"
 ],
 "Hide API key": [
  null,
  "API ਕੁੰਜੀ ਨੂੰ ਲੁਕਾਓ"
 ],
 "Hide PIN": [
  null,
  "ਪਿੰਨ ਨੂੰ ਲੁਕਾਓ"
 ],
 "Hide confirmed password": [
  null,
  "ਤਸਦੀਕ ਕੀਤੇ ਪਾਸਵਰਡ ਨੂੰ ਲੁਕਾਓ"
 ],
 "Hide passphrase": [
  null,
  "ਵਾਕ ਨੂੰ ਓਹਲੇ ਕਰੋ"
 ],
 "Hide password": [
  null,
  "ਪਾਸਵਰਡ ਨੂੰ ਲੁਕਾਓ"
 ],
 "Hostname": [
  null,
  "ਹੋਸਟ ਨਾਂ"
 ],
 "How would you like to install?": [
  null,
  "ਤੁਸੀਂ ਕਿਵੇਂ ਇੰਸਟਾਲ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "ਮੈਨੂੰ ਸਮਝਦਾ/ਸਮਝਦੀ ਹਾਂ ਕਿ ਸਾਰੇ ਮੌਜੂਦਾ ਡਾਟਾ ਨੂੰ ਮਿਟਾਇਆ ਜਾਵੇਗਾ",
  "ਮੈਨੂੰ ਸਮਝਦਾ/ਸਮਝਦੀ ਹਾਂ ਕਿ ਚੁਣੀਆਂ ਡਿਸਕਾਂ ਤੋਂ ਸਾਰੇ ਮੌਜੂਦਾ ਡਾਟਾ ਨੂੰ ਮਿਟਾਇਆ ਜਾਵੇਗਾ"
 ],
 "I understand that some existing data will be erased": [
  null,
  "ਮੈਂ ਸਮਝਦਾ/ਸਮਝਦੀ ਹਾਂ ਕਿ ਕੁਝ ਮੌਜੂਦਾ ਡਾਟੇ ਨੂੰ ਮਿਟਾਇਆ ਜਾਵੇਗਾ"
 ],
 "I understand that some partitions will be modified": [
  null,
  "ਮੈਂ ਸਮਝਦਾ/ਸਮਝਦੀ ਹਾਂ ਕਿ ਕੁਝ ਪਾਰਟੀਸ਼ਨਾਂ ਨੂੰ ਸੋਧਿਆ ਜਾਵੇਗਾ"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "ਜੇ ਖ਼ਾਲੀ ਹੋਇਆ ਤਾਂ ਹੋਸਟ-ਨਾਂ ਵਕਤੀ ਹੋਵਗਾ ਅਤੇ ਨੈੱਟਵਰਕ ਜਾਣਕਾਰੀ ਵਲੋਂ ਸੈੱਟ ਕੀਤਾ ਜਾਵੇਗਾ।"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "ਜੇ ਤੁਸੀਂ ਪਾਰਟੀਸ਼ੇਨਾਂ ਦੀ ਸੰਰਚਨਾ ਕਰ ਰਹੇ ਹੋ ਤਾਂ ਅੱਗੇ ਦਿੱਤੇ ਚਾਹੀਦੇ ਹਨ:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "ਜੇ ਤੁਸੀਂ ਖ਼ਤਰਿਆਂ ਨੂੰ ਸਮਝਦੇ ਜਾਂ ਮਨਜ਼ੂਰ ਨਹੀਂ ਕਰਦੇ ਤਾਂ ਇਸ ਪਰੋਗਰਾਮ ਨੂੰ ਬੰਦ ਕਰੋ ਜੀ।"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "ਜਾਰੀ ਹੈ"
 ],
 "Initializing...": [
  null,
  "ਇੰਸਟਾਲ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ..."
 ],
 "Install": [
  null,
  "ਇੰਸਟਾਲ"
 ],
 "Installation completed": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਪੂਰੀ ਹੋਈ"
 ],
 "Installation failed": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਅਸਫ਼ਲ ਹੈ"
 ],
 "Installation method": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਦਾ ਢੰਗ"
 ],
 "Installation of the system failed": [
  null,
  "ਸਿਸਟਮ ਦੀ ਇੰਸਟਾਲੇਸ਼ਨ ਅਸਫ਼ਲ ਹੈ"
 ],
 "Installation of the system failed: $0": [
  null,
  "ਸਿਸਟਮ ਦੀ ਇੰਸਟਾਲੇਸ਼ਨ ਅਸਫ਼ਲ ਹੈ: $0"
 ],
 "Installation type": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਦੀ ਕਿਸਮ"
 ],
 "Installing": [
  null,
  "ਇੰਸਟਾਲ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ"
 ],
 "Insufficient disk space": [
  null,
  "ਨਾ-ਕਾਫ਼ੀ ਡਿਸਕ ਥਾਂ"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  "ਗਲਤ ਹੋਸਟ-ਨਾਂ"
 ],
 "Jump to first incomplete step": [
  null,
  "ਪਹਿਲੇ ਅਧੂਰੇ ਪੜਾਅ ਉੱਤੇ ਜਾਓ"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "ਮੌਜੂਦਾ ਡਿਸਕ ਖਾਤੇ ਨੂੰ ਉਵੇਂ ਰੱਖੋ ਅਤੇ ਮੌਜੂਦਾ ਖਾਲੀ ਥਾਂ ਨੂੰ ਹੋਰ ਓਪਰੇਟਿੰਗ ਸਿਸਟਮ (OS) ਨਾਲ ਦੂਹਰਾ ਬੂਟ ਕਰਨ ਲਈ ਵਰਤੋਂ।"
 ],
 "Keyboard": [
  null,
  "ਕੀਬੋਰਡ"
 ],
 "Keyboard layout during boot": [
  null,
  "ਬੂਟ ਕਰਨ ਸਮੇਂ ਕੀਬੋਰਡ ਖਾਕਾ"
 ],
 "Language": [
  null,
  "ਭਾਸ਼ਾ"
 ],
 "Launch storage editor": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ ਨੂੰ ਚਲਾਓ"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "ਸੰਰਚਨਾ ਵਿੱਚ ਸੀਮਿਤ ਪਹੁੰਚ ਬਾਰੇ ਹੋਰ ਜਾਣੋ"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "ਖਾਲੀ ਪਾਸਵਰਡ ਵਰਤਣ ਲਈ ਦੋਵੇਂ ਵਾਕ ਵਾਲੇ ਖੇਤਰਾਂ ਨੂੰ ਖਾਲੀ ਛੱਡ ਦਿਓ।"
 ],
 "Location": [
  null,
  "ਟਿਕਾਣਾ"
 ],
 "Locked devices": [
  null,
  "ਲਾਕ ਕੀਤੇ ਡਿਵਾਈਸ"
 ],
 "Log in": [
  null,
  "ਲਾਗਇਨ"
 ],
 "Make current": [
  null,
  "ਮੌਜੂਦਾ ਬਣਾਓ"
 ],
 "Manual disk configuration": [
  null,
  "ਡਿਸਕ ਦੀ ਖੁਦ ਸੰਰਚਨਾ"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "ਡਿਸਕ ਦੀ ਖੁਦ ਸੰਰਚਨਾ: ਮਾਊਂਟ ਪੁਆਇੰਟ ਮੈਪ ਕੀਤੇ ਜਾ ਰਹੇ ਹਨ"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "ਅੱਖਰ, ਅੰਕ ਅਤੇ ਡੈਸ਼ ਹੋ ਸਕਦੀ ਹੈ।"
 ],
 "May need more free space": [
  null,
  "ਹੋਰ ਖਾਲੀ ਥਾਂ ਦੀ ਲੋੜ ਹੈ"
 ],
 "Medium": [
  null,
  "ਮੀਡੀਅਮ"
 ],
 "Minimum of $0 required": [
  null,
  "ਘੱਟੋ-ਘੱਟ $0  ਥਾਂ ਚਾਹੀਦੀ ਹੈ"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "ਮੁ਼ਢਲੇ ਡਿਵਾਈਸ ਅਤੇ ਅਗਲੇ ਡਿਵਾਈਸ ਦੀ ਮੁੜ-ਫਾਰਮੈਟ ਚੋਣ ਵਿਚਾਲੇ ਫ਼ਰਕ ਹੈ।"
 ],
 "Mount point": [
  null,
  "ਮਾਊਂਟ ਪੁਆਇੰਟ"
 ],
 "Mount point assignment": [
  null,
  "ਮਾਊਂਟ ਪੁਆਇੰਟ ਨਿਰਧਾਰਨ"
 ],
 "Move down": [
  null,
  "ਹੇਠਾਂ ਭੇਜੋ"
 ],
 "Move up": [
  null,
  "ਉੱਤੇ ਭੇਜੋ"
 ],
 "Must be at least $0 characters": [
  null,
  "ਘੱਟੋ-ਘੱਟ $0 ਅੱਖਰਾਂ ਦਾ ਹੋਣਾ ਜ਼ਰੂਰੀ ਹੈ"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP ਸਰਵਰ"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "ਨਾਂ"
 ],
 "Needs at least $0": [
  null,
  "ਘੱਟੋ-ਘੱਟ $0 ਥਾਂ ਦੀ ਲੋੜ ਹੈ"
 ],
 "Network": [
  null,
  "ਨੈੱਟਵਰਕ"
 ],
 "Network Configuration": [
  null,
  "ਨੈੱਟਵਰਕ ਦੀ ਸੰਰਚਨਾ"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "ਨੈੱਟਵਰਕ ਮੌਜੂਦ ਨਹੀਂ ਹੈ। ਮਸਲੇ ਬਾਰੇ ਜਾਣਕਾਰੀ ਦੇਣ ਲਈ ਉੱਪਰੀ ਪੱਟੀ ਮੇਨੂ ਵਿੱਚ ਨੈੱਟਵਰਕ ਦੀ ਸੰਰਚਨਾ ਕਰੋ।"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "ਨੈੱਟਵਰਕ ਮੌਜੂਦ ਨਹੀਂ ਹੈ। ਮਸਲੇ ਬਾਰੇ ਜਾਣਕਾਰੀ ਦੇਣ ਲਈ ਨੈੱਟਵਰਕ ਦੀ ਸੰਰਚਨਾ ਕਰੋ।"
 ],
 "Network plugin failed": [
  null,
  "ਨੈੱਟਵਰਕ ਪਲੱਗਇਨ ਅਸਫ਼ਲ ਹੈ"
 ],
 "Next": [
  null,
  "ਅੱਗੇ"
 ],
 "No devices": [
  null,
  "ਕੋਈ ਡਿਵਾਈਸ ਨਹੀਂ"
 ],
 "No disks available": [
  null,
  "ਕੋਈ ਡਿਸਕਾਂ ਮੌਜੂਦ ਨਹੀਂ ਹਨ"
 ],
 "No disks selected": [
  null,
  "ਕੋਈ ਡਿਸਕ ਨਹੀਂ ਚੁਣੀ ਗਈ"
 ],
 "No keyboard layouts selected": [
  null,
  "ਕੋਈ ਕੀਬੋਰਡ ਖਾਕੇ ਚੁਣੇ ਨਹੀਂ ਗਏ"
 ],
 "No layouts selected yet": [
  null,
  "ਕੋਈ ਖਾਤੇ ਹਾਲੇ ਚੁਣੇ ਨਹੀਂ ਗਏ"
 ],
 "No results found": [
  null,
  "ਕੋਈ ਨਤੀਜਾ ਨਹੀੰ ਲੱਭਾ"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "ਲੋੜੀਂਦੀ ਖਾਲੀ ਥਾਂ ਮੌਜੂਦ ਨਹੀਂ ਹੈ"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "ਚੁਣੀਆਂ ਡਿਸਕਾਂ ਉੱਤੇ ਲੋੜੀਂਦੀ ਖਾਲੀ ਥਾਂ ਨਹੀਂ ਹੈ।"
 ],
 "Not enough space on selected disks.": [
  null,
  "ਚੁਣੀਆਂ ਡਿਸਕਾਂ ਉੱਤੇ ਲੋੜੀਂਦੀ ਥਾਂ ਨਹੀਂ ਹੈ।"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "ਸੂਚਨਾ: ਇਹ ਅਧੂਰਾ ਜਾਰੀ ਕੀਤਾ ਸਾਫਟਵੇਅਰ ਸਿਰਫ਼ ਵਿਕਾਸ ਅਤੇ ਟੈਸਟ ਦੇ ਮਕਸਦ ਲਈ ਹੀ ਜਾਰੀ ਕੀਤਾ ਗਿਆ ਹੈ। ਇਸ ਸਾਫਟਵੇਅਰ ਨੂੰ ਪ੍ਰੋਡੱਕਸ਼ਨ ਮਾਹੌਲ ਵਿੱਚ ਕਿਸੇ ਵੀ ਗੰਭੀਰ ਕੰਮ ਲਈ ਕਦੇ ਨਾ ਵਰਤੋਂ।"
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "ਓਪਰੇਟਿੰਗ ਸਿਸਟਮ"
 ],
 "Options": [
  null,
  "ਚੋਣਾਂ"
 ],
 "Other keyboards": [
  null,
  "ਹੋਰ ਕੀਬੋਰਡ"
 ],
 "Partitions (advanced)": [
  null,
  "ਪਾਰਟੀਸ਼ਨ (ਤਕਨੀਕੀ)"
 ],
 "Passphrase": [
  null,
  "ਵਾਕ"
 ],
 "Passphrase did not match any locked device": [
  null,
  "ਵਾਕ ਕਿਸੇ ਵੀ ਲਾਕ ਕੀਤੇ ਡਿਵਾਈਸ ਲਈ ਮਿਲਦਾ ਨਹੀਂ ਸੀ"
 ],
 "Passphrases must match": [
  null,
  "ਵਾਕ ਮਿਲਦੇ ਹੋਣੇ ਚਾਹੀਦੇ ਹਣ"
 ],
 "Pending": [
  null,
  "ਬਾਕੀ"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "ਮਸਲੇ ਲਈ $0 ਲਾਗ ਫਾਇਲ ਨੱਥੀ ਕਰੋ।"
 ],
 "Please select at least one disk to continue": [
  null,
  "ਜਾਰੀ ਰੱਖਣ ਲਈ ਘੱਟੋ-ਘੱਟ ਇੱਕ ਡਿਸਕ ਨੂੰ ਚੁਣੋ"
 ],
 "Pool": [
  null,
  "ਪੂਲ"
 ],
 "Powered by Anaconda": [
  null,
  "ਐਨਾਕਾਂਡਾ ਰਾਹੀਂ ਸਹਾਇਕ"
 ],
 "Pre-release": [
  null,
  "ਪ੍ਰੀ-ਰੀਲਿਜ਼"
 ],
 "Prefer to report manually? $0": [
  null,
  "ਖੁਦ ਰਿਪੋਰਟ ਕਰਨਾ ਚਾਹੋਗੇ? $0"
 ],
 "Proceed with installation": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਜਾਰੀ ਰੱਖੋ"
 ],
 "Quit": [
  null,
  "ਬੰਦ ਕਰੋ"
 ],
 "Quit installer?": [
  null,
  "ਇੰਸਟਾਲਰ ਬੰਦ ਕਰਨਾ ਹੈ?"
 ],
 "Reading information about the OS failed.": [
  null,
  "ਓਪਰੇਟਿੰਗ ਸਿਸਟਮ ਬਾਰੇ ਜਾਣਕਾਰੀ ਪੜ੍ਹਨ ਲਈ ਅਸਫ਼ਲ ਹੈ।"
 ],
 "Reading information about the computer failed.": [
  null,
  "ਕੰਪਿਊਟਰ ਤੋਂ ਜਾਣਕਾਰੀ ਪੜ੍ਹਨ ਲਈ ਅਸਫ਼ਲ ਹੈ।"
 ],
 "Reading installer configuration failed.": [
  null,
  "ਇੰਸਟਾਲਰ ਦੀ ਸੰਰਚਨਾ ਪੜ੍ਹਨ ਲਈ ਅਸਫ਼ਲ ਹੈ।"
 ],
 "Reading installer version information failed.": [
  null,
  "ਇੰਸਟਾਲਰ ਦੀ ਵਰਜ਼ਨ ਸੰਰਚਨਾ ਪੜ੍ਹਨ ਲਈ ਅਸਫ਼ਲ ਹੈ।"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "ਅਸਲ ਹੋਸਟ-ਨਾਂ ਵਿੱਚ ਸਿਰਫ਼ ਅੱਖਰ, ਅੰਕ, ਡੈਸ਼ (ਸ਼ੁਰੂ ਅਤੇ ਅੰਤ ਵਿੱਚ ਨਹੀਂ ਹੋ ਸਕਦੀ) ਅਤੇ ਬਿੰਦੀਆਂ ਹੋ ਸਕਦੀਆਂ ਹਨ"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "ਅਸਲ ਹੋਸਟ ਨਾਂ ਦੀ ਲੰਬਾਈ 64 ਜਾਂ ਘੱਟ ਅੱਖਰ ਹੋਣੇ ਚਾਹੀਦੇ ਹਨ।"
 ],
 "Reboot": [
  null,
  "ਮੁੜ-ਚਾਲੂ"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "ਬਿੱਟਲਾਕਰ-ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ ਪਾਰਟੀਸ਼ਨਾਂ ਦਾ ਆਕਾਰ ਬਦਲਣ ਲਈ Windows ਵਿੱਚ ਬੂਟ ਕਰੋ। ਇੰਸਟਾਲੇਸ਼ਨ ਲਈ ਘੱਟੋ-ਘੱਟ $0 ਖਾਲੀ ਥਾਂ ਬਣਾਓ।"
 ],
 "Reboot system?": [
  null,
  "ਸਿਸਟਮ ਨੂੰ ਮੁੜ-ਚਾਲੂ ਕਰਨਾ ਹੈ?"
 ],
 "Reclaim additional space": [
  null,
  "ਵਧੀਕ ਥਾਂ ਮੁੜ-ਪ੍ਰਾਪਤ ਕਰੋ"
 ],
 "Reclaim space": [
  null,
  "ਥਾਂ ਮੁੜ-ਪ੍ਰਾਪਤ ਕਰੋ"
 ],
 "Reclaim space (required)": [
  null,
  "ਥਾਂ ਮੁੜ-ਪ੍ਰਾਪਤ ਕਰੋ (ਲਾਜ਼ਮੀ)"
 ],
 "Recommended": [
  null,
  "ਸਿਫਾਰਸ਼ੀ"
 ],
 "Recommended partitions:": [
  null,
  "ਸਿਫ਼ਾਰਸ਼ ਕੀਤੇ ਪਾਰਟੀਸ਼ਨ:"
 ],
 "Reformat": [
  null,
  "ਮੁੜ-ਫਾਰਮੈਟ ਕਰੋ"
 ],
 "Reinstall Fedora": [
  null,
  "ਫੇਡੋਰਾ ਨੂੰ ਮੁੜ-ਇੰਸਟਾਲ ਕਰੋ"
 ],
 "Remove": [
  null,
  "ਹਟਾਓ"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "ਚੁਣੇ ਡਿਵਾਈਸਾਂ ਤੋਂ ਸਾਰੇ ਪਾਰਟੀਸ਼ਨ, ਜਿਸ ਵਿੱਚ ਮੌਜੂਦਾ ਓਪਰੇਟਿੰਗ ਸਿਸਟਮ ਵੀ ਸ਼ਾਮਲ ਹਨ, ਨੂੰ ਹਟਾਓ।"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਲਈ ਥਾਂ ਨੂੰ ਖ਼ਾਲੀ ਕਰਨ ਵਾਸਤੇ ਮੌਜੂਦਾ ਫਾਇਲ-ਸਿਸਟਮਾਂ ਨੂੰ ਹਟਾਓ ਜਾਂ ਉਹਨਾਂ ਦਾ ਆਕਾਰ ਬਦਲੋ।"
 ],
 "Remove server": [
  null,
  "ਸਰਵਰ ਨੂੰ ਹਟਾਓ"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "ਕਿਸੇ ਫ਼ਾਇਲ-ਸਿਸਟਮ ਨੂੰ ਪੱਕੇ ਤੌਰ ਉੱਤੇ ਹਟਾਉਣ ਨਾਲ ਇਸ ਵਿੱਚ ਮੌਜੂਦ ਸਾਰਾ ਡਾਟਾ ਖ਼ਤਮ ਹੋ ਜਾਵੇਗਾ। ਪਾਰਟੀਸ਼ਨ ਦੇ ਆਕਾਰ ਬਦਲਣ ਨਾਲ ਥਾਂ ਖਾਲੀ ਹੋ ਸਕਦੀ ਹੈ, ਪਰ ਇਹ ਖ਼ਤਰੇ ਤੋਂ ਖਾਲੀ ਨਹੀਂ ਹੈ। ਹਰ ਚੀਜ਼ ਦਾ ਬੈਕਅੱਪ ਬਣਾਉਣਾ ਖਾਲੀ ਥਾਂ ਕਰਨ ਤੋਂ ਪਹਿਲਾਂ ਜ਼ਰੂਰੀ ਹੈ।"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "ਮੌਜੂਦਾ ਇੰਸਟਾਲੇਸ਼ਨ ਨੂੰ ਬਦਲ ਦਿਓ, ਪਰ home ਵਿੱਚ ਫਾਇਲਾਂ ਨੂੰ ਰੱਖੋ।"
 ],
 "Report Issue": [
  null,
  "ਮਸਲੇ ਬਾਰੇ ਜਾਣਕਾਰੀ"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "ਮਸਲੇ ਬਾਰ ਜਾਣਕਾਰੀ"
 ],
 "Reporting issue...": [
  null,
  "...ਮਸਲੇ ਬਾਰੇ ਜਾਣਕਾਰੀ ਭੇਜੀ ਜਾ ਰਹੀ ਹੈ"
 ],
 "Required": [
  null,
  "ਚਾਹੀਦਾ"
 ],
 "Requirements": [
  null,
  "ਲੋੜਾਂ"
 ],
 "Rescan devices": [
  null,
  "ਡਿਵਾਈਸਾਂ ਦੀ ਮੁੜ-ਜਾਂਚ ਕਰੋ"
 ],
 "Rescanning of the disks failed.": [
  null,
  "ਡਿਸਕਾਂ ਦੀ ਮੁੜ-ਜਾਂਚ ਅਸਫ਼ਲ ਹੈ।"
 ],
 "Resize": [
  null,
  "ਆਕਾਰ ਬਦਲੋ"
 ],
 "Resize partition": [
  null,
  "ਪਾਰਟੀਸ਼ਨ ਦਾ ਆਕਾਰ ਬਦਲੋ"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "$0 ਤੋਂ ਅੱਗੇ ਦਿੱਤੇ ਪਾਰਟੀਸ਼ਨ ਦਾ ਆਕਾਰ ਬਦਲਿਆ ਜਾ ਰਿਹਾ ਹੈ: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਉੱਤੇ ਵਾਪਸ"
 ],
 "Return to storage editor": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ ਉੱਤੇ ਵਾਪਸ"
 ],
 "Review and install": [
  null,
  "ਪੜਤਾਲ ਕਰੋ ਤੇ ਇੰਸਟਾਲੇਸ਼ਨ ਕਰੋ"
 ],
 "Root account has been configured": [
  null,
  "ਰੂਟ ਖਾਤਾ ਸੰਰਚਿਤ ਕੀਤਾ ਗਿਆ ਹੈ"
 ],
 "Root account is enabled": [
  null,
  "ਰੂਟ ਅਕਾਊਂਟ ਨੂੰ ਸਮਰੱਥ ਕੀਤਾ ਹੈ"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "ਰੂਟ ਅਕਾਊਂਟ ਨੂੰ ਸਮਰੱਥ ਕੀਤਾ ਹੈ, ਪਰ ਕੋਈ ਵਰਤੋਂਕਾਰ ਖਾਤਾ ਸੰਰਚਿਤ ਨਹੀਂ ਹੈ"
 ],
 "Root password has been set.": [
  null,
  "ਰੂਟ ਪਾਸਵਰਡ ਸੈੱਟ ਕੀਤਾ ਗਿਆ।"
 ],
 "Save": [
  null,
  "ਸੰਭਾਲੋ"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "ਆਪਣੇ ਫ਼ੋਨ ਨਾਲ QR ਕੋਡ ਸਕੈਨ ਕਰੋ ਜਾਂ ਖੋਲ੍ਹੋ:"
 ],
 "Search for a language": [
  null,
  "ਭਾਸ਼ਾ ਨੂੰ ਖੋਜੋ"
 ],
 "Search for additional software": [
  null,
  "ਵਧੀਕ ਸਾਫਟਵੇਅਰ ਲਈ ਖੋਜ"
 ],
 "Search for an environment": [
  null,
  "ਕਿਸੇ ਇਨਵਾਇਰਮੈਂਟ ਲਈ ਖੋਜ"
 ],
 "Search keyboard layout": [
  null,
  "ਕੀਬੋਰਡ ਖਾਕੇ ਨੂੰ ਲੱਭੋ"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "ਆਪਣੇ ਡਾਟੇ ਨੂੰ ਡਿਸਕ-ਅਧਾਰਿਤ ਇੰਕ੍ਰਿਪਸ਼ਨ ਨਾਲ ਸੁਰੱਖਿਆ ਬਣਾਓ। ਸਿਰਫ਼ ਨਵੇਂ ਪਾਰਟੀਸ਼ਨਾਂ ਲਈ ਹੀ ਲਾਗੂ ਹੁੰਦਾ ਹੈ"
 ],
 "Select": [
  null,
  "ਚੁਣੋ"
 ],
 "Select a device": [
  null,
  "ਡਿਵਾਈਸ ਨੂੰ ਚੁਣੋ"
 ],
 "Select city": [
  null,
  "ਸ਼ਹਿਰ ਨੂੰ ਚੁਣੋ"
 ],
 "Select destination": [
  null,
  "ਟਿਕਾਣੇ ਨੂੰ ਚੁਣੋ"
 ],
 "Select region": [
  null,
  "ਖੇਤਰ ਨੂੰ ਚੁਣੋ"
 ],
 "Selected (top = current)": [
  null,
  "ਚੁਣੇ (ਉੱਤੇ=ਮੌਜੂਦਾ)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "ਚੁਣੇ ਡਿਵਾਈਸ ਦਾ ਫਾਰਮੈਟ '$0' ਨੂੰ ਮੁੜ-ਫਾਰਮੈਟ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਦਾ ਹੈ।"
 ],
 "Send us feedback on your installation": [
  null,
  "ਆਪਣੀ ਇੰਸਟਾਲੇਸ਼ਨ ਬਾਰੇ ਸਾਨੂੰ ਵਿਚਾਰ ਭੇਜੋ"
 ],
 "Server": [
  null,
  "ਸਰਵਰ"
 ],
 "Server is not reachable": [
  null,
  "ਸਰਵਰ ਪਹੁੰਚ ਵਿੱਚ ਨਹੀਂ ਹੈ"
 ],
 "Set custom hostname": [
  null,
  "ਪਸੰਦੀਦਾ ਹੋਸਟ-ਨਾਂ ਸੈਟ ਕਰੋ"
 ],
 "Share disk with other operating systems": [
  null,
  "ਹੋਰ ਓਪਰੇਟਿੰਗ ਸਿਸਟਮਾਂ ਨਾਲ ਡਿਸਕ ਸਾਂਝੀ ਕਰੋ"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "ਹੋਰ ਓਪਰੇਟਿੰਗ ਸਿਸਟਮਾਂ ਨਾਲ ਡਿਸਕ ਸਾਂਝੀ ਕਰੋ: $0"
 ],
 "Show AM/PM": [
  null,
  "ਸਵੇਰ/ਸ਼ਾਮ ਵੇਖਾਓ"
 ],
 "Show API key": [
  null,
  "API ਕੁੰਜੀ ਵੇਖਾਓ"
 ],
 "Show PIN": [
  null,
  "ਪਿੰਨ ਨੂੰ ਵੇਖਾਓ"
 ],
 "Show confirmed password": [
  null,
  "ਤਸਦੀਕ ਕੀਤਾ ਪਾਸਵਰਡ ਵੇਖਾਓ"
 ],
 "Show passphrase": [
  null,
  "ਵਾਕ ਨੂੰ ਵੇਖਾਓ"
 ],
 "Show password": [
  null,
  "ਪਾਸਵਰਡ ਨੂੰ ਵੇਖਾਓ"
 ],
 "Size": [
  null,
  "ਆਕਾਰ"
 ],
 "Software installation": [
  null,
  "ਸਾਫਟਵੇਅਰ ਇੰਸਟਾਲੇਸ਼ਨ"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "ਸਾਫਟਵੇਅਰ ਇੰਸਟਾਲੇਸ਼ਨ: ਸਟੋਰੇਜ਼ ਦੀ ਸੰਰਚਨਾ ਪੂਰੀ ਹੋਈ। ਹੁਣ ਸਾਫਟਵੇਅਰ ਤੁਹਾਡੇ ਡਿਵਾਈਸ ਉੱਤੇ ਇੰਸਟਾਲ ਕੀਤੇ ਜਾ ਰਹੇ ਹਨ।"
 ],
 "Software selection": [
  null,
  "ਸਾਫਟਵੇਅਰ ਚੋਣ"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "ਜਾਰੀ ਰੱਖਣ ਤੋਂ ਪਹਿਲਾਂ ਤੁਹਾਨੂੰ ਕੁਝ ਇੰਸਟਾਲੇਸ਼ਨ ਪੜਾਆਵਾਂ ਨੂੰ ਪੂਰਾ ਕਰਨਾ ਪਵੇਗਾ।"
 ],
 "Some required partitions are missing: $0": [
  null,
  "ਕੁਝ ਚਾਹੀਦੇ ਪਾਰਟੀਸ਼ਨ ਮੌਜੂਦ ਨਹੀਂ ਹਨ: $0"
 ],
 "Space": [
  null,
  "ਥਾਂ"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "ਸਟੋਰੇਜ਼"
 ],
 "Storage configuration": [
  null,
  "ਸਟੋਰੇਜ਼ ਸੰਰਚਨਾ"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "ਸਟੋਰੇਜ਼ ਦੀ ਸੰਰਚਨਾ: ਸਟੋਰੇਜ਼ ਦੀ ਇਸ ਵੇਲੇ ਸੰਰਚਨਾ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ।"
 ],
 "Storage editor": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "ਸਟੋਰੇਜ਼ ਦੀ ਸੰਰਚਨਾ 'ਸਟੋਰੇਜ਼ ਨੂੰ ਸੋਧੋ' ਦੇ ਅਧਾਰ ਉੱਤੇ ਹੈ।"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "ਸਟੋਰੇਜ਼ ਪਲੱਗਇਨ ਅਸਫ਼ਲ ਹੈ"
 ],
 "Storage requirements not met": [
  null,
  "ਸਟੋਰੇਜ਼ ਦੀਆਂ ਲੋੜਾਂ ਪੂਰੀਆਂ ਨਹੀਂ ਹੋਈਆਂ"
 ],
 "Strong": [
  null,
  "ਮਜ਼ਬੂਤ"
 ],
 "Successfully installed": [
  null,
  "ਕਾਮਯਾਬੀ ਨਾਲ ਇੰਸਟਾਲ ਹੋਇਆ"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 ਨੂੰ ਕਾਮਯਾਬੀ ਨਾਲ ਅਣ-ਲਾਕ ਕੀਤਾ।"
 ],
 "Suggested keyboards": [
  null,
  "ਸੁਝਾਏ ਗਏ ਕੀਬੋਰਡ"
 ],
 "Suggested languages": [
  null,
  "ਸੁਝਾਈਆਂ ਗਈਆਂ ਭਾਸ਼ਾਵਾਂ"
 ],
 "System": [
  null,
  "ਸਿਸਟਮ"
 ],
 "System configuration": [
  null,
  "ਸਿਸਟਮ ਸੰਰਚਨਾ"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "ਸਿਸਟਮ ਸੰਰਚਨ: ਸਾਫਟਵੇਅਰ ਇੰਸਟਾਲੇਸ਼ਨ ਪੂਰੀ ਹੈ। ਸਿਸਟਮ ਦੀ ਹੁਣ ਸੰਰਚਨਾ ਕੀਤੀ ਜਾਵੇਗਾ।"
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "ਐਨਾਕਾਂਡਾ ਇੰਸਟਾਲੇਸ਼ਨ ਅਚਾਨਕ ਰੁਕ ਚੁੱਕੀ ਹੈ।"
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "ਅੱਗੇ ਦਿੱਤੇ ਵਰਤੋਂਕਾਰ ਨੂੰ ਬਣਾਇਆ ਜਾਵੇਗਾ:",
  "ਅੱਗੇ ਦਿੱਤੇ ਵਰਤੋਂਕਾਰਾਂ ਨੂੰ ਬਣਾਇਆ ਜਾਵੇਗਾ:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "ਇੰਸਟਾਲੇਸ਼ਨ ਲਈ $0 ਡਿਸਕ ਥਾਂ ਚਾਹੀਦੀ ਹੈ; ਪਰ ਚੁਣੀ ਗਈ ਡਿਸਕ ਦੀ ਸਮਰੱਥਾ ਸਿਰਫ਼ $1 ਹੀ ਹੈ।"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "ਇੰਸਟਾਲਰ ਗੰਭੀਰ ਗਲਤੀ ਕਰਕੇ ਜਾਰੀ ਨਹੀਂ ਰਹਿ ਸਕਦਾ ਹੈ।"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "ਇੰਸਟਾਲਰ ਗੰਭੀਰ ਗਲਤੀ ਕਰਕੇ ਜਾਰੀ ਨਹੀਂ ਰਹਿ ਸਕਦਾ ਹੈ: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "ਡਿਸਕ ਇੰਕ੍ਰਿਪਸ਼ਨ ਵਾਕ ਸੈਟ ਕਰਨ ਦੇ ਬਾਅਦ ਕੀਬੋਰਡ ਖਾਤਾ ਬਦਲਿਆ ਗਿਆ ਹੈ। ਵਾਕ ਫੇਰ ਭਰੋ ਜੀ।"
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "ਤੁਹਾਡੇ ਵਲੋਂ ਦਿੱਤੇ ਵਾਕ ਵਿੱਚ ਗ਼ੈਰ-ASCII ਅੱਖਰ ਮੌਜੂਦ ਹਨ। ਜਦੋਂ ਤੁਹਾਨੂੰ ਇਹ ਲਿਖਣ ਦੀ ਲੋੜ ਪਈ ਤਾਂ ਤੁਸੀਂ ਸ਼ਾਇਦ ਕੀਬੋਰਡ ਬਦਲ ਨਾ ਸਕੋ।"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "ਚੁਣਿਆ ਗਿਆ ਮੂਲ ਕੀਬੋਰਡ ਖਾਕਾ ASCII ਅੱਖਰਾਂ ਲਈ ਸਹਾਇਕ ਨਹੀਂ ਹੈ। ਮੂਲ ਵਜੋਂ ਕਿਸੇ ASCII-ਅਨੁਕੂਲ ਖਾਕੇ ਦੀ ਚੋਣ ਕਰੋ।"
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "ਸਟੋਰੇਜ਼ ਐਡੀਟਰ ਤੁਹਾਨੂੰ ਪਾਰਟੀਸ਼ਨ ਦਾ ਆਕਾਰ ਬਦਲਣ, ਹਟਾਉਣ ਅਤੇ ਬਣਾਉਣ ਦੀ ਸਹੂਲਤ ਦਿੰਦਾ ਹੈ। ਇਹ LVM ਸੈਟਅੱਪ ਅਤੇ ਕਈ ਕੁਝ ਕਰ ਸਕਦਾ ਹੈ। ਇਸ ਨੂੰ ਤਕਨੀਕੀ ਸਹੂਲਤ ਵਜੋਂ ਵਰਤਿਆ ਜਾਣਾ ਚਾਹੀਦਾ ਹੈ ਅਤੇ ਆਮ ਇੰਸਟਾਲੇਸ਼ਨ ਲਈ ਵਰਤਣ ਵਾਸਤੇ ਨਹੀਂ ਹੈ।"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "ਇਹਨਾਂ ਲਾਗ ਫ਼ਾਇਲਾਂ ਵਿੱਚ IP ਸਿਰਨਾਵੇਂ, ਵਰਤੋਂਕਾਰ-ਨਾਂ ਜਾਂ ਹੋਰ ਸਿਸਟਮ ਵੇਰਵਿਆਂ ਵਰਗੀਆਂ ਸੰਵੇਦਨਸ਼ੀਲ ਜਾਣਕਾਰੀਆਂ ਹੋ ਸਕਦੀਆਂ ਹਨ।"
 ],
 "This hostname can't be submitted": [
  null,
  "ਇਹ ਹੋਸਟ-ਨਾਂ ਭੇਜਿਆ ਨਹੀਂ ਜਾ ਸਕਦਾ ਹੈ"
 ],
 "This is unstable, pre-release software": [
  null,
  "ਇਹ ਅਸਥਿਰ, ਪ੍ਰੀ-ਰੀਲਿਜ਼ ਸਾਫਟਵੇਅਰ ਹੈ"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "ਇਹ ਖਾਕੇ ਨੂੰ ਬੂਟ ਹੋਣ ਸਮੇਂ ਤੁਹਾਡੇ ਸਿਸਟਮ ਨੂੰ ਅਣ-ਲਾਕ ਕਰਨ ਲਈ ਵਰਤਿਆ ਜਾਵੇਗਾ"
 ],
 "This may take a moment": [
  null,
  "ਇਸ ਨੂੰ ਪਲ ਭਰ ਲੱਗ ਸਕਦਾ ਹੈ"
 ],
 "This will take a few moments": [
  null,
  "ਇਸ ਨੂੰ ਕੁਝ ਕੁ ਪਲ਼ ਲੱਗਣਗੇ"
 ],
 "Time": [
  null,
  "ਸਮਾਂ"
 ],
 "Timezone": [
  null,
  "ਸਮਾਂ-ਖੇਤਰ:"
 ],
 "Title": [
  null,
  "ਟਾਈਟਲ"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0 ਵਰਤਣਾ ਸ਼ੁਰੂ ਕਰਨ ਲਈ, ਆਪਣੇ ਸਿਸਟਮ ਨੂੰ ਮੁੜ-ਚਾਲੂ ਕਰੋ।"
 ],
 "To continue, select the devices to install to.": [
  null,
  "ਜਾਰੀ ਰੱਖਣ ਲਈ, ਇੰਸਟਾਲ ਕਰਨ ਲਈ ਡਿਵਾਈਸਾਂ ਨੂੰ ਚੁਣੋ।"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "ਇਹ ਚੋਣ ਨੂੰ ਵਰਤਣ ਲਈ ਮੌਜੂਦਾ ਪਾਰਟੀਸ਼ਨਾਂ ਦਾ ਆਕਾਰ ਬਦਲ ਕੇ ਜਾਂ ਹਟਾ ਕੇ ਘੱਟੋ-ਘੱਟ $0 ਥਾਂ ਖਾਲੀ ਕਰੋ।"
 ],
 "Type": [
  null,
  "ਕਿਸਮ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0 ਦੇ ਹਟਾਉਣ ਨੂੰ ਮਿੱਥਣ ਲਈ ਅਸਮਰੱਥ ਹੈ"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0 ਦੇ ਆਕਾਰ ਬਦਲਣ ਨੂੰ ਮਿੱਥਣ ਲਈ ਅਸਮਰੱਥ ਹੈ"
 ],
 "Undo last action": [
  null,
  "ਆਪਸੀ ਕਾਰਵਾਈ ਵਾਪਸ ਲਵੋ"
 ],
 "Unlock": [
  null,
  "ਅਣਲਾਕ"
 ],
 "Unlock encrypted devices": [
  null,
  "ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ ਡਿਵਾਈਸਾਂ ਨੂੰ ਅਣ-ਲਾਕ ਕਰੋ"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "ਮੌਜੂਦਾ ਡਾਟੇ ਨੂੰ ਰੱਖਣ ਅਤੇ ਹੋਰ ਇੰਸਟਾਲੇਸ਼ਨ ਢੰਗ ਵੇਖਣ ਵਾਸਤੇ ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ ਪਾਰਟੀਸ਼ਨਾਂ ਨੂੰ ਅਣ-ਲਾਕ ਕਰੋ।"
 ],
 "Use configured storage": [
  null,
  "ਸੰਰਚਿਤ ਕੀਤੀ ਸਟੋਰੇਜ਼ ਨੂੰ ਵਰਤੋਂ"
 ],
 "Use entire disk": [
  null,
  "ਪੂਰੀ ਡਿਸਕ ਨੂੰ ਵਰਤੋਂ"
 ],
 "Use free space": [
  null,
  "ਖਾਲੀ ਥਾਂ ਵਰਤੋਂ"
 ],
 "Use local account": [
  null,
  "ਲੋਕਲ ਖਾਤੇ ਨੂੰ ਵਰਤੋਂ"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "ਆਪਣੇ-ਆਪ ਪਾਰਟੀਸ਼ਨਿੰਗ ਲਈ RAID ਡਿਵਾਈਸ ਨੂੰ ਵਰਤੋਂ"
 ],
 "User creation": [
  null,
  "ਵਰਤੋਂਕਾਰ ਬਣਾਉਣਾ"
 ],
 "User name": [
  null,
  "ਵਰਤੋਂਕਾਰ ਨਾਂ"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "ਵਰਤੋਂਕਾਰ ਨਾਂ ਵਿੱਚ ਸਿਰਫ਼ ਇਹੀ ਹੋ ਸਕਦੇ ਹਨ: a-z ਅੱਖਰ, 0-9 ਅੰਕ, $0 ਨਿਸ਼ਾਨ, ਬਿੰਦੀ $1, ਹੇਠਾਂ ਰੇਖਾਂ $2"
 ],
 "User name must not be a reserved word": [
  null,
  "ਵਰਤੋਂਕਾਰ ਨਾਂ ਰਾਖਵਾਂ ਸ਼ਬਦ ਨਹੀਂ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "ਵਰਤੋਂਕਾਰ ਨਾਂ ਵਿੱਚ 33 ਤੋਂ ਘੱਟ ਅੱਖਰ ਹੋਣੇ ਚਾਹੀਦੇ ਹਨ"
 ],
 "Validating...": [
  null,
  "...ਜਾਂਚ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ"
 ],
 "Weak": [
  null,
  "ਕਮਜ਼ੋਰ"
 ],
 "Welcome": [
  null,
  "ਜੀ ਆਇਆਂ ਨੂੰ"
 ],
 "Welcome to Fedora Linux": [
  null,
  "ਫੇਡੋਰਾ ਲੀਨਕਸ ਵਲੋਂ ਜੀ ਆਇਆਂ ਨੂੰ"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "ਜੀ ਆਇਆਂ ਨੂੰ। ਆਓ ਫੇਰ $0 ਇੰਸਟਾਲ ਕਰੀਏ।"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "ਬਿੱਟ-ਲਾਕਰ ਨਾਲ ਇੰਕ੍ਰਿਪਟ ਕੀਤੇ Windows ਪਾਰਟੀਸ਼ਨ ਦਾ ਆਕਾਰ ਬਦਲਿਆ ਨਹੀਂ ਜਾ ਸਕਦਾ ਹੈ"
 ],
 "You can close this browser window now.": [
  null,
  "ਹੁਣ ਤੁਸੀਂ ਇਸ ਬਰਾਊਜ਼ਰ ਵਿੰਡੋ ਨੂੰ ਬੰਦ ਕਰ ਸਕਦੇ ਹੋ।"
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "ਜਾਂ ਤਾਂ ਤੁਸੀਂ ਇੱਥੇ ਲੋੜੀਂਦੀ ਥਾਂ ਖਾਲੀ ਕਰ ਸਕਦੇ ਹੋ ਤੇ ਇੰਸਟਾਲਰ ਬਾਕੀ ਕੰਮ ਕਰ ਲਵੇਗਾ ਜਾਂ ਖੁਦ ਪਾਰਟੀਸ਼ਨ ਸੈਟ-ਅੱਪ ਕਰੋ।"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "ਜਾਰੀ ਰੱਖਣ ਵਾਸਤੇ ਤੁਹਾਨੂੰ ਰੂਟ ਖਾਤਾ ਸਮਰੱਥ ਕਰਨਾ ਜਾਂ ਲੋਕਲ ਵਰਤੋਂਕਾਰ ਖਾਤਾ ਬਣਾਉਣਾ ਪਵੇਗਾ।"
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "ਆਪਣੇ-ਆਪ ਤਾਰੀਖ ਅਤੇ ਸਮਾਂ ਸਮਰੱਥ ਕਰਨ ਲਈ ਤੁਹਾਨੂੰ ਨੈੱਟਵਰਕ ਨਾਲ ਕਨੈਕਟ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ।"
 ],
 "Your progress will not be saved.": [
  null,
  "ਤੁਹਾਡੇ ਕੀਤੇ ਕੰਮ ਨੂੰ ਸੰਭਾਲਿਆ ਨਹੀਂ ਜਾਵੇਗਾ।"
 ],
 "completed step": [
  null,
  "ਪੜਾਅ ਪੂਰਾ ਹੈ"
 ],
 "current step": [
  null,
  "ਮੌਜੂਦਾ ਪੜਾਅ"
 ],
 "delete": [
  null,
  "ਹਟਾਓ"
 ],
 "edit": [
  null,
  "ਸੋਧੋ"
 ],
 "encrypt": [
  null,
  "ਇੰਕ੍ਰਿਪਟ"
 ],
 "encrypted": [
  null,
  "ਇੰਕ੍ਰਿਪਟ ਹੈ"
 ],
 "extended partition": [
  null,
  "ਐਕਸਟੈਂਡਡ ਪਾਰਟੀਸ਼ਨ"
 ],
 "format as $0": [
  null,
  "$0 ਵਜੋਂ ਫਾਰਮੈਟ ਕਰੋ"
 ],
 "here": [
  null,
  "ਇੱਥੇ"
 ],
 "incomplete": [
  null,
  "ਅਧੂਰਾ"
 ],
 "mount": [
  null,
  "ਮਾਊਂਟ"
 ],
 "pending step": [
  null,
  "ਬਾਕੀ ਪੜਾਅ"
 ],
 "report the issue manually": [
  null,
  "ਮਸਲੇ ਬਾਰੇ ਖੁਦ ਰਿਪੋਰਟ ਦਿਓ"
 ],
 "resized from $0": [
  null,
  "$0 ਤੋਂ ਆਕਾਰ ਬਦਲਿਆ"
 ],
 "shrink": [
  null,
  "ਆਕਾਰ ਘਟਾਓ"
 ],
 "shrink to $0": [
  null,
  "$0 ਤੱਕ ਘਟਾਓ"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "ਵਾਪਸ ਲਵੋ"
 ]
});
