cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "format": [
  null,
  "формат"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "файлова система"
 ],
 "partition": [
  null,
  "розділ"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "том"
 ],
 "disk": [
  null,
  "диск"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "диск"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "шифрування"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Керування розділами диска"
 ],
 "Managing NFS mounts": [
  null,
  "Керування монтуванням NFS"
 ],
 "Managing RAIDs": [
  null,
  "Керування RAID"
 ],
 "Managing LVMs": [
  null,
  "Керування LVM"
 ],
 "Managing physical drives": [
  null,
  "Керування фізичними дисками"
 ],
 "Managing VDOs": [
  null,
  "Керування VDO"
 ],
 "Using LUKS encryption": [
  null,
  "З використанням шифрування LUKS"
 ],
 "Using Tang server": [
  null,
  "З використанням сервера Tang"
 ]
});
