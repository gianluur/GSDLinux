cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 오류"
 ],
 "$0 installation": [
  null,
  "$0 설치"
 ],
 "$0 installer": [
  null,
  "$0 설치자"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0는 논리 파티션이 포함된 MBR의 확장된 파티션입니다. 모든 논리 파티션 제거하기는 확장된 파티션도 자동으로 제거합니다."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 가 필요하나, $1 만 사용 할 수 있습니다."
 ],
 "$0 warning": [
  null,
  "$0 경고"
 ],
 "$0 will be deleted": [
  null,
  "$0가 삭제됩니다"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' 파일시스템은 암호화된 블록 장치에 있을 수 없습니다"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0'는 '$1'으로 할당 되어야 합니다"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' 는 '$1'으로 초기화된 장치에 있어야 합니다"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0'는 EFI 시스템 파티션이어야 합니다. 선택한 파티션은 FAT 파일시스템을 사용하지만, ESP로 표시되지 않습니다. 파티션 유형을 EFI System으로 설정하고 esp 플래그를 활성화합니다."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "MDRAID 장치 $1 에서 '$0' 파티션을 찾았습니다. MDRAID 장치에서 부트로더 파티션은 지원되지 않습니다."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "시스템-전반의 변경 사양을 만들기 위해 admin 접근을 갖는 표준 사용자 계정."
 ],
 "Abort installation": [
  null,
  "설치 중지"
 ],
 "About": [
  null,
  "정보"
 ],
 "Account": [
  null,
  "계정"
 ],
 "Actions": [
  null,
  "동작"
 ],
 "Add another server...": [
  null,
  "다른 서버 추가..."
 ],
 "Add mount": [
  null,
  "적재를 추가합니다"
 ],
 "Add-ons for your chosen environment": [
  null,
  "자신이 선택한 환경을 위한 추가 기능"
 ],
 "Add-ons not specific to your environment": [
  null,
  "자신의 환경에 지정되지 않은 추가 기능"
 ],
 "Additional languages": [
  null,
  "추가 할 수 있는 언어"
 ],
 "Additional software for the selected environment": [
  null,
  "선택한 환경을 위한 추가 소프트웨어"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "저장소 편집기에서 작성된 모든 변경은 즉시 영향을 미칩니다."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "이와 같은 암호문을 사용하는 모든 장치는 잠금해제 됩니다"
 ],
 "Anaconda Web UI": [
  null,
  "아나콘다 웹 UI"
 ],
 "Anaconda project page": [
  null,
  "아나콘다 프로젝트 부분"
 ],
 "Apply mount point assignment and install": [
  null,
  "적재 지점 할당을 적용하고 설치합니다"
 ],
 "Applying changes...": [
  null,
  "변경 적용하기..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "파티션을 적재 지점에 할당합니다. 사전-구성된 사용자 정의 배열을 위해 유용합니다."
 ],
 "Automatic log file upload": [
  null,
  "자동 기록 파일 올려놓기"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "시간 서버를 사용하여, 자동으로 날짜 및 시간을 설정합니다"
 ],
 "Automatically set timezone": [
  null,
  "자동으로 시간대를 설정합니다"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "사용 가능한 여유 공간: $0. 설치에 필요합니다: $1."
 ],
 "Back": [
  null,
  "뒤로"
 ],
 "Base environment": [
  null,
  "기본 환경"
 ],
 "Brief description of the issue": [
  null,
  "사건에 대한 간략한 설명"
 ],
 "Bug report details": [
  null,
  "결점 보고 세부 정보"
 ],
 "Bugzilla API key": [
  null,
  "버그질라 API 키"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "이와 같은 소프트웨어를 계속 사용하면, 시험과 개발 목적으로만 사용하고, 이 작업을 향상 시키기 위해 결점 또는 문제점을 기꺼이 보고하고자 하는 사전-출시된 소프트웨어와 관련된 위험을 이해하고 수용합니다."
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Change destination": [
  null,
  "변경 대상"
 ],
 "Change hostname": [
  null,
  "호스트이름 변경"
 ],
 "Change partition layout": [
  null,
  "파티션 구성 변경"
 ],
 "Change system keyboard layout": [
  null,
  "시스템 키보드 배열을 변경합니다"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "여기에서 변경을 했으면 시스템에 즉시 영향을 미칩니다. '실행취소' 가 없습니다."
 ],
 "Checking installation configuration...": [
  null,
  "설치 구성 확인 중..."
 ],
 "Checking storage configuration": [
  null,
  "저장소 구성 확인 중"
 ],
 "Clear search": [
  null,
  "검색 지우기"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "이들 경고에도 불구하고 계속 진행하려면 다시 '다음' 을 눌러주세요."
 ],
 "Close": [
  null,
  "종료"
 ],
 "Close storage editor": [
  null,
  "저장소 편집기 닫기"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "cockpit 저장소는 암호화된 장치를 해제하도록 암호문을 제공하지 않습니다."
 ],
 "Completed": [
  null,
  "완료되었습니다"
 ],
 "Configuration is incomplete": [
  null,
  "구성이 불완전합니다"
 ],
 "Configure NTP servers": [
  null,
  "NTP 서버 설정"
 ],
 "Configure custom NTP servers": [
  null,
  "사용자 정의 NTP 서버를 구성합니다"
 ],
 "Configure network": [
  null,
  "네트워크 구성"
 ],
 "Configure storage": [
  null,
  "저장소 구성"
 ],
 "Configure storage again": [
  null,
  "저장소를 다시 구성합니다"
 ],
 "Confirm passphrase": [
  null,
  "암호문을 확인합니다"
 ],
 "Continue": [
  null,
  "진행"
 ],
 "Continue installation": [
  null,
  "설치를 계속합니다"
 ],
 "Continue installation?": [
  null,
  "설치를 계속할까요?"
 ],
 "Continue with installation": [
  null,
  "설치를 계속합니다"
 ],
 "Correct these issues before continuing.": [
  null,
  "계속하기 전에 이들 문제를 정정합니다."
 ],
 "Create Account": [
  null,
  "계정 생성"
 ],
 "Create account": [
  null,
  "계정 생성"
 ],
 "Currently installed: $0": [
  null,
  "현재 설치됨: $0"
 ],
 "Custom": [
  null,
  "사용자 지정"
 ],
 "Date": [
  null,
  "날짜"
 ],
 "Date and time": [
  null,
  "날짜와 시간"
 ],
 "Delete partition": [
  null,
  "파티션 삭제"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "특정 파티션의 삭제는 부팅에서 $0를 예방합니다: $1"
 ],
 "Description": [
  null,
  "설명"
 ],
 "Destination": [
  null,
  "대상"
 ],
 "Destination is encrypted": [
  null,
  "대상이 암호화되었습니다"
 ],
 "Detailed description of the issue": [
  null,
  "사건에 대한 세부 설명"
 ],
 "Detected valid storage layout:": [
  null,
  "탐지된 유효 저장소 배열:"
 ],
 "Device": [
  null,
  "장치"
 ],
 "Duplicate device.": [
  null,
  "중복 장치."
 ],
 "Duplicate mount point.": [
  null,
  "중복 적재 지점."
 ],
 "Enable root account": [
  null,
  "root 계정 활성화"
 ],
 "Encrypt my data": [
  null,
  "자료를 암호화합니다"
 ],
 "Encrypted": [
  null,
  "암호화됨"
 ],
 "Encryption": [
  null,
  "암호화"
 ],
 "Enter PIN": [
  null,
  "PIN 입력"
 ],
 "Enter PIN to access the installer": [
  null,
  "설치자에 접근하려면 PIN을 입력하세요"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "자신의 버그질라 API 키를 입력하고 결점 보고를 생성하세요. 당신은 다음 단계에서 결점을 상세하게 검토하고 편집 할 수 있습니다."
 ],
 "Environment": [
  null,
  "환경"
 ],
 "Erase data and install": [
  null,
  "자료를 지우고 설치합니다"
 ],
 "Error details": [
  null,
  "오류 상세"
 ],
 "Exit to live desktop": [
  null,
  "라이브 데스크탑으로 종료"
 ],
 "Extended partition": [
  null,
  "확장된 파티션"
 ],
 "Failed to report issue": [
  null,
  "사건에 대한 보고를 실패함"
 ],
 "Failed to save layouts": [
  null,
  "배열을 저장하는 데 실패했습니다"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "페도라 리눅스는 적어도 디스크 공간의 $0가 필요합니다."
 ],
 "Finalization": [
  null,
  "마무리"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "마무리하기: 시스템 구성이 완료되었습니다. 마무리 설치는 몇 분 걸립니다."
 ],
 "Find layout": [
  null,
  "배열 찾기"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "보다 나은 보안을 위해, 직접 root 계정 사용하기를 피합니다. 대신에, 위의 로컬 계정을 사용하여 시스템을 관리하세요."
 ],
 "Full name": [
  null,
  "성명"
 ],
 "Full name cannot contain colon characters": [
  null,
  "이름에 쌍점(:)을 사용 할 수 없습니다"
 ],
 "Helper text": [
  null,
  "텍스트 도우미"
 ],
 "Hide API key": [
  null,
  "API 키 숨기기"
 ],
 "Hide PIN": [
  null,
  "PIN 숨기기"
 ],
 "Hide confirmed password": [
  null,
  "확인된 비밀번호 감추기"
 ],
 "Hide passphrase": [
  null,
  "암호문을 숨깁니다"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "Hostname": [
  null,
  "호스트이름"
 ],
 "How would you like to install?": [
  null,
  "설치 하시겠습니까?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "나는 모든 기존 자료가 선택한 디스크에서 제거 될 것이라는 점을 이해합니다"
 ],
 "I understand that some existing data will be erased": [
  null,
  "나는 일부 기존 자료가 제거 될 것이라는 점을 이해합니다"
 ],
 "I understand that some partitions will be modified": [
  null,
  "나는 일부 파티션이 수정 될 것이라는 점을 이해합니다"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "만약 비었으면, 호스트이름은 일시적이고 네트워크 정보로 설정됩니다."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "만약 위에 적용하여야 할 옵션이 없으면, 저장소 편집기를 사용하여 진행 전에 사용자 정의 파티션을 생성하세요."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "만약 당신이 파티션을 구성하는 경우 다음이 필요합니다:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "만약 당신이 자동 기록 파일을 올려놓기에 동의하지 않으면, 대신에 $0 를 할 수 있습니다. 수동 보고는 당신이 기록 파일을 스스로 검토하고 선택적으로 첨부 할 수 있도록 합니다."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "이해하지 못하거나 위험을 받아들이지 않으려면, 이 프로그램을 종료하세요."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "만약 자신의 문제가 위에 결점 하나와 일치하면, 이를 열고 중복된 보고를 생성하는 대신에 자신의 정보를 추가 할 수 있습니다."
 ],
 "In progress": [
  null,
  "진행 중"
 ],
 "Initializing...": [
  null,
  "초기화 중..."
 ],
 "Install": [
  null,
  "설치"
 ],
 "Installation completed": [
  null,
  "설치 완료됨"
 ],
 "Installation failed": [
  null,
  "설치에 실패했습니다"
 ],
 "Installation method": [
  null,
  "설치 방법"
 ],
 "Installation of the system failed": [
  null,
  "시스템 설치에 실패했습니다"
 ],
 "Installation of the system failed: $0": [
  null,
  "시스템 설치에 실패했습니다: $0"
 ],
 "Installation type": [
  null,
  "설치 유형"
 ],
 "Installing": [
  null,
  "설치 중"
 ],
 "Insufficient disk space": [
  null,
  "불충분한 디스크 공간"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "잘못된 PIN. 다시 시도하세요."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "유효하지 않은 레이드 구성이 탐지되었습니다. 만약 자신의 레이드 배열이 디스크의 상단에서 직접 생성되었으면, 파티션 테이블은 배열에서 생성되어야만 합니다. 만약 자신의 레이드 배열이 파티션의 상단에서 생성되었으면, 이는 단일 파일시스템 또는 초기화를 포함합니다(예: LVM PV). 이와 같은 배열에서 기존 파티션은 무시됩니다."
 ],
 "Invalid hostname": [
  null,
  "잘못된 호스트명"
 ],
 "Jump to first incomplete step": [
  null,
  "처음 불완전 단계로 넘어가기"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "현재의 디스크 배열을 유지하고 사용 가능한 공간을 활용하여 다른 OS와 함께 이중-부팅을 합니다."
 ],
 "Keyboard": [
  null,
  "키보드"
 ],
 "Keyboard layout during boot": [
  null,
  "부팅 중에 키보드 나열"
 ],
 "Language": [
  null,
  "언어"
 ],
 "Launch storage editor": [
  null,
  "저장소 편집기 실행"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "구성에서 제한된 접근에 대해 알아보세요"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "비워 있는 비밀번호를 사용하려면 암호구 부분을 모두 비워두세요."
 ],
 "Location": [
  null,
  "위치"
 ],
 "Locked devices": [
  null,
  "잠금된 장치"
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Make current": [
  null,
  "현재로 만들기"
 ],
 "Manual disk configuration": [
  null,
  "사용자 정의 디스크 구성"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "사용자 정의 디스크 구성: 적재 지점 대응"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "문자, 숫자 및 줄표(-)가 포함 될 수 있습니다."
 ],
 "May need more free space": [
  null,
  "더 많은 여유 공간이 필요 할 수 있습니다"
 ],
 "Medium": [
  null,
  "중간"
 ],
 "Minimum of $0 required": [
  null,
  "최소 $0 가 필요합니다"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "상위 장치와 하위 장치 재-초기화 선택이 일치하지 않습니다."
 ],
 "Mount point": [
  null,
  "적재 지점"
 ],
 "Mount point assignment": [
  null,
  "적재 지점 지정"
 ],
 "Move down": [
  null,
  "아래로 이동"
 ],
 "Move up": [
  null,
  "위로 이동"
 ],
 "Must be at least $0 characters": [
  null,
  "적어도 $0 문자이어야 합니다"
 ],
 "My issue is different, continue": [
  null,
  "나의 문제는 다르며, 계속합니다"
 ],
 "NTP Servers": [
  null,
  "NTP 서버"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Needs at least $0": [
  null,
  "최소 $0 가 필요합니다"
 ],
 "Network": [
  null,
  "네트워크"
 ],
 "Network Configuration": [
  null,
  "네트워크 구성"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "네트워크를 사용 할 수 없습니다. 상단의 표시 메뉴에서 네트워크를 구성하고 문제를 보고하세요."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "네트워크를 사용 할 수 없습니다. 네트워크를 구성하고 문제를 보고하세요."
 ],
 "Network plugin failed": [
  null,
  "실패한 네트워크 플로그인"
 ],
 "Next": [
  null,
  "다음"
 ],
 "No devices": [
  null,
  "장치 없음"
 ],
 "No disks available": [
  null,
  "사용 가능한 디스크 없음"
 ],
 "No disks selected": [
  null,
  "선택한 디스크가 없음"
 ],
 "No keyboard layouts selected": [
  null,
  "키보드 배열이 선택되지 않았습니다"
 ],
 "No layouts selected yet": [
  null,
  "아직 선택된 배열이 없습니다"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "선택한 키보드 배열을 위해 유효한 VConsole 키맵을 가져 올 수 없습니다. 다른 키보드 배열을 선택해주세요."
 ],
 "Not enough available free space": [
  null,
  "사용 할 수 있는 여유 공간이 충분하지 않습니다"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "선택한 디스크에 여유 공간이 충분하지 않습니다."
 ],
 "Not enough space on selected disks.": [
  null,
  "선택한 디스크에 공간이 충분하지 않습니다."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "주의: 이 배포판은 개발과 시험 목적을 위해서만 의도된 사전-출시된 것입니다. 심각한 작업 또는 생산환경에서 이 소프트웨를 사용하지 않도록 합니다."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "버그질라 결점 보고 양식을 엽니다"
 ],
 "Operating system": [
  null,
  "운영 체제"
 ],
 "Options": [
  null,
  "선택"
 ],
 "Other keyboards": [
  null,
  "기타 키보드"
 ],
 "Partitions (advanced)": [
  null,
  "파티션 (고급)"
 ],
 "Passphrase": [
  null,
  "암호문"
 ],
 "Passphrase did not match any locked device": [
  null,
  "암호문은 잠금된 장치와 일치하지 않습니다"
 ],
 "Passphrases must match": [
  null,
  "암호문은 일치해야 합니다"
 ],
 "Pending": [
  null,
  "보류 중"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "로그 파일 $0를 문제로 첨부해 주세요."
 ],
 "Please enter a PIN": [
  null,
  "PIN을 입력하세요"
 ],
 "Please select at least one disk to continue": [
  null,
  "계속 진행하려면 최소 하나의 디스크를 선택해야 합니다"
 ],
 "Pool": [
  null,
  "풀"
 ],
 "Potential duplicate bugs found": [
  null,
  "잠재된 중복 결점을 찾았습니다"
 ],
 "Powered by Anaconda": [
  null,
  "아나콘다 제공"
 ],
 "Pre-release": [
  null,
  "사전-출시"
 ],
 "Prefer to report manually? $0": [
  null,
  "수동으로 보고할까요? $0"
 ],
 "Proceed with installation": [
  null,
  "설치로 진행합니다"
 ],
 "Quit": [
  null,
  "종료"
 ],
 "Quit installer?": [
  null,
  "설치자 종료?"
 ],
 "Reading information about the OS failed.": [
  null,
  "OS에 대한 정보 읽기를 실패함."
 ],
 "Reading information about the computer failed.": [
  null,
  "컴퓨터에 대한 정보 읽기를 실패함."
 ],
 "Reading installer configuration failed.": [
  null,
  "설치자 구성 읽기가 실패함."
 ],
 "Reading installer version information failed.": [
  null,
  "설치자 버전 정보 읽기가 실패함."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "실제 호스트이름은 문자, 숫자, 줄표 (문자를 시작하거나 끝내지 않음) 및 점만 포함합니다"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "실제 호스트이름은 길이로 64 자 이하의 문자여야 합니다"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "BitLocker-암호화된 파티션의 크기를 조절하려면 윈도우로 재시작 합니다. 설치를 위해 사용 가능한 여유 공간이 적어도 $0 를 만들어야 합니다."
 ],
 "Reboot system?": [
  null,
  "시스템 재시작?"
 ],
 "Reclaim additional space": [
  null,
  "추가 공간 확보"
 ],
 "Reclaim space": [
  null,
  "공간 확보"
 ],
 "Reclaim space (required)": [
  null,
  "공간 확보(필수)"
 ],
 "Recommended": [
  null,
  "권장 사항"
 ],
 "Recommended partitions:": [
  null,
  "권장 파티션:"
 ],
 "Reformat": [
  null,
  "다시초기화함"
 ],
 "Reinstall Fedora": [
  null,
  "페도라를 재설치합니다"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "기존 운영체제를 포함하여, 선택된 장치에서 모든 파티션을 제거합니다."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "설치를 위해 여유 공간을 확보하도록 기존 파일시스템을 제거하거나 크기를 조정합니다."
 ],
 "Remove server": [
  null,
  "서버 삭제"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "파일시스템 제거하기는 포함된 모든 자료를 영구적으로 제거합니다. 파티션 크기 조정하기는 사용하지 않는 공간을 확보 할 수 있지만, 위험이 존재합니다. 공간을 재할당 하기 전에 중요한 것은 백업을 해야 합니다."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "현재 설치를 대체하지만 홈에 파일을 유지합니다."
 ],
 "Report Issue": [
  null,
  "문제를 보고합니다"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "문제를 보고하거나 버그질라 결점 보고 양식 $0 를 열어서 응답을 제공해 주세요."
 ],
 "Report issue": [
  null,
  "문제를 보고합니다"
 ],
 "Reporting issue...": [
  null,
  "문제 보고하기..."
 ],
 "Required": [
  null,
  "요구 사항"
 ],
 "Requirements": [
  null,
  "요구 사항"
 ],
 "Rescan devices": [
  null,
  "장치 재검색"
 ],
 "Rescanning of the disks failed.": [
  null,
  "디스크 재검색이 실패함."
 ],
 "Resize": [
  null,
  "크기조정"
 ],
 "Resize partition": [
  null,
  "파티션 크기 재지정"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "다음 파티션 크기 조정 중 $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "보고서에 대한 접근을 제한합니다"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "$0 그룹에 대한 보고를 제한합니다. $1"
 ],
 "Return to installation": [
  null,
  "설치로 돌아가기"
 ],
 "Return to storage editor": [
  null,
  "저장소 편집기로 돌아갑니다"
 ],
 "Review and install": [
  null,
  "검토하고 설치"
 ],
 "Root account has been configured": [
  null,
  "root 계정이 구성되었습니다"
 ],
 "Root account is enabled": [
  null,
  "root 계정이 비활성화 되었습니다"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "root 계정이 활성화 되었지만, 사용자 계정이 구성되지 않았습니다"
 ],
 "Root password has been set.": [
  null,
  "root 비밀번호가 설정되었습니다."
 ],
 "Save": [
  null,
  "저장"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "자신의 폰으로 QR 코드를 스캔하거나 방문하세요:"
 ],
 "Search for a language": [
  null,
  "언어 검색"
 ],
 "Search for additional software": [
  null,
  "추가 소프트웨어 검색"
 ],
 "Search for an environment": [
  null,
  "환경을 위한 검색"
 ],
 "Search keyboard layout": [
  null,
  "키보드 배열을 검색합니다"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "디스크-기반 보안을 사용하여 자신의 자료를 보호합니다. 신규 파티션에서만 적용합니다"
 ],
 "Select": [
  null,
  "선택"
 ],
 "Select a device": [
  null,
  "장치를 선택합니다"
 ],
 "Select city": [
  null,
  "도시 선택"
 ],
 "Select destination": [
  null,
  "선택 대상"
 ],
 "Select region": [
  null,
  "지역 선택"
 ],
 "Selected (top = current)": [
  null,
  "선택됨(상단 = 현재)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "선택한 장치의 형식 '$0'은 다시 초기화 될 수 없습니다."
 ],
 "Send us feedback on your installation": [
  null,
  "자신의 설치에서 우리에게 응답을 제공하세요"
 ],
 "Server": [
  null,
  "서버"
 ],
 "Server is not reachable": [
  null,
  "서버에 접근 할 수 없습니다"
 ],
 "Set custom hostname": [
  null,
  "사용자 정의 호스트이름 설정"
 ],
 "Share disk with other operating systems": [
  null,
  "다른 운영체제와 함께 디스크를 공유합니다"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "다른 운영체제와 함께 디스크 공유합니다: $0"
 ],
 "Show AM/PM": [
  null,
  "오전/오후 표시"
 ],
 "Show API key": [
  null,
  "API 키 표시"
 ],
 "Show PIN": [
  null,
  "PIN 표시"
 ],
 "Show confirmed password": [
  null,
  "확인된 비밀번호 표시"
 ],
 "Show passphrase": [
  null,
  "암호문을 표시합니다"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Software installation": [
  null,
  "소프트웨어 설치"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "소프트웨어 설치: 저장소 구성 완료. 소프트웨어는 이제 자신의 장치에 설치되어 있습니다."
 ],
 "Software selection": [
  null,
  "소프트웨어 선택"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "당신은 계속 진행하기 전에 몇 가지 설치 단계를 완료해야 합니다."
 ],
 "Some required partitions are missing: $0": [
  null,
  "일부 필수 파티션이 누락되었습니다: $0"
 ],
 "Space": [
  null,
  "공간"
 ],
 "Stacktrace": [
  null,
  "스택트레이스"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Storage configuration": [
  null,
  "저장소 구성"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "저장소 구성: 저장소는 현재 구성되어져 있는 상태입니다."
 ],
 "Storage editor": [
  null,
  "저장소 편집기"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "저장소는 '저장소 수정' 에서 구성을 기반으로 합니다."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "킥스타트 파일에서 저장소 배열은 정의됩니다. 계획된 디스크 구획 배열은 요약 단계에서 검토 할 수 있습니다."
 ],
 "Storage plugin failed": [
  null,
  "실패한 저장소 플로그인"
 ],
 "Storage requirements not met": [
  null,
  "저장소 요구사항이 충족되지 않았습니다"
 ],
 "Strong": [
  null,
  "강함"
 ],
 "Successfully installed": [
  null,
  "성공적으로 설치되었습니다"
 ],
 "Successfully unlocked $0.": [
  null,
  "성공적으로 $0가 잠금되었습니다."
 ],
 "Suggested keyboards": [
  null,
  "제안된 키보드"
 ],
 "Suggested languages": [
  null,
  "제안된 언어"
 ],
 "System": [
  null,
  "시스템"
 ],
 "System configuration": [
  null,
  "시스템 구성"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "시스템 구성: 소프트웨어 설치 완료. 시스템은 이제 구성되어져 있습니다."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "아나콘다 설치가 갑자기 중지되었습니다."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "다음과 같이 미해결 결점이 당신의 문제와 연관되어 있을 수 있습니다. 신규 보고를 생성하기 전에 이를 참조하세요."
 ],
 "The following user will be created:": [
  null,
  "다음 사용자가 생성됩니다:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "설치는 디스크 공간의 $0가 필요합니다; 하지만, 선택된 디스크의 공간은 $1만 있습니다."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "설치는 심각한 오류로 인하여 계속 할 수 없습니다."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "설치자는 심각한 오류로 인해 계속 할 수 없습니다: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "키보드 배열이 디스크 암호 암호구 설정된 이후에 변경되었습니다. 암호구를 재-입력해주세요."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "입력 한 암호문에 비 ASCII 문자가 포함되어 있습니다. 키보드 레이아웃을 입력 할 때 키보드 레이아웃을 전환하지 못할 수 있습니다."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "선택된 기본 키보드 배열은 ASCII 문자를 지원하지 않습니다. 기본과 같이 ASCII-지원 배열을 선택하세요."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "저장소 편집기는 당신이 파티션 크기 조정, 삭제 및 생성을 하도록 합니다. LVM 및 그 이상을 설정 할 수 있습니다. 이는 고급 유틸리티로 사용되도록 하는 것이고 전형적인 설치에 사용하고자 하는 바는 아닙니다."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "이들 기록 파일은 IP 주소, 사용자이름, 또는 다른 시스템의 상세한 정보와 같이 민감한 정보가 있을 수 있습니다."
 ],
 "This hostname can't be submitted": [
  null,
  "이와 같은 호스트이름은 제출 될 수 없습니다"
 ],
 "This is unstable, pre-release software": [
  null,
  "이 배포판은 불안정 할 수 있으며, 사전-출시된 소프트웨어입니다"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "이와 같은 나열은 부팅에서 자신의 시스템 잠금 해제를 위해 사용됩니다"
 ],
 "This may take a moment": [
  null,
  "시간이 좀 걸릴 수 있습니다"
 ],
 "This will take a few moments": [
  null,
  "시간이 좀 걸릴 수 있습니다"
 ],
 "Time": [
  null,
  "시간"
 ],
 "Timezone": [
  null,
  "시간대"
 ],
 "Title": [
  null,
  "제목"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0를 사용하여 시작하려면, 시스템을 재시작하세요."
 ],
 "To continue, select the devices to install to.": [
  null,
  "계속하려면, 설치하려는 장치를 선택하세요."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "이와 같은 옵션을 사용하려면, 최소 $0의 공간을 확보하려면 기존 파티션 크기를 조정하거나 제거하세요."
 ],
 "Type": [
  null,
  "유형"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0의 삭제를 예정 할 수 없습니다"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0의 크기 조정을 예정 할 수 없습니다"
 ],
 "Undo last action": [
  null,
  "마지막 동작 취소"
 ],
 "Unlock": [
  null,
  "잠금 해제"
 ],
 "Unlock encrypted devices": [
  null,
  "암호화된 장치를 해제합니다"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "암호화된 파티션을 잠금을 해제하고 기존 자료를 유지 및 더 많은 설치 방식을 표시합니다."
 ],
 "Use configured storage": [
  null,
  "구성된 저장소 사용"
 ],
 "Use entire disk": [
  null,
  "전체 디스크 사용"
 ],
 "Use free space": [
  null,
  "여유 공간 사용"
 ],
 "Use local account": [
  null,
  "로컬 계정 사용"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "자동 파티션을 위해 레이드 장치를 사용합니다"
 ],
 "User creation": [
  null,
  "사용자 생성(_U)"
 ],
 "User name": [
  null,
  "사용자 이름"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "사용자 이름은 다음만 포함해야 합니다: a~z 문자, 0-9 숫자, 줄표 $0, 마침표 $1, 밑줄 $2"
 ],
 "User name must not be a reserved word": [
  null,
  "사용자 이름은 예약된 단어가 아니어야 합니다"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "사용자 이름은 33 자보다 짧아야 합니다"
 ],
 "Validating...": [
  null,
  "검증 중..."
 ],
 "Weak": [
  null,
  "취약"
 ],
 "Welcome": [
  null,
  "환영합니다"
 ],
 "Welcome to Fedora Linux": [
  null,
  "페도라 리눅스에 오신 것을 환영합니다"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "환영합니다. 이제 $0를 설치해요."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "당신이 이와 같은 결점 보고를 제출 할 때에, 다음 기록 파일이 자동으로 올려질 것입니다: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker로 암호화된 윈도우 파티션은 크기를 조절 할 수 없습니다"
 ],
 "You can close this browser window now.": [
  null,
  "이 검색창은 이제 닫을 수 있습니다."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "당신은 여기에서 충분한 공간을 확보하고 설치자가 잔여 부분을 다루거나 파티션을 수동으로 설정 할 수 있습니다."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "당신은 자신의 버그질라 계정 $0 에서 API 키를 생성 할 수 있습니다."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "계속하려면 root 계정을 활성화 하거나 로컬 사용자 계정을 생성해야 합니다."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "자동으로 날짜 및 시간을 활성화 하려면 네트워크에 연결되어 있어야 합니다."
 ],
 "Your progress will not be saved.": [
  null,
  "당신의 진행 상황은 저장되지 않습니다."
 ],
 "completed step": [
  null,
  "완료 단계"
 ],
 "current step": [
  null,
  "현재 단계"
 ],
 "delete": [
  null,
  "삭제"
 ],
 "edit": [
  null,
  "편집"
 ],
 "encrypt": [
  null,
  "암호화"
 ],
 "encrypted": [
  null,
  "암호화됨"
 ],
 "extended partition": [
  null,
  "확장된 파티션"
 ],
 "format as $0": [
  null,
  "$0로 초기화"
 ],
 "here": [
  null,
  "여기"
 ],
 "incomplete": [
  null,
  "불완전"
 ],
 "mount": [
  null,
  "적재"
 ],
 "pending step": [
  null,
  "보류 단계"
 ],
 "report the issue manually": [
  null,
  "사건을 수동으로 보고합니다"
 ],
 "resized from $0": [
  null,
  "$0부터 크기가 조정됨"
 ],
 "shrink": [
  null,
  "축소"
 ],
 "shrink to $0": [
  null,
  "$0로 축소"
 ],
 "transient, will use DHCP": [
  null,
  "일시적으로, DHCP를 사용합니다"
 ],
 "undo": [
  null,
  "실행취소"
 ]
});
