cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Firewall": [
  null,
  "Брандмауер"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Public key": [
  null,
  "Відкритий ключ"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Select": [
  null,
  "Вибрати"
 ],
 "Unexpected error": [
  null,
  "Неочікувана помилка"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "Connect": [
  null,
  "З'єднатися"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "Disconnected": [
  null,
  "Роз'єднано"
 ],
 "Permission denied": [
  null,
  "Відмовлено у доступі"
 ],
 "Clear input value": [
  null,
  "Вилучити вхідне значення"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "You now have administrative access.": [
  null,
  "Тепер ви маєте адміністративний доступ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Немає доступних методів отримання адміністративного доступу (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Будь ласка, пройдіть розпізнавання, щоб отримати адміністративний доступ"
 ],
 "Switch to administrative access": [
  null,
  "Перемкнутися на адміністративний доступ"
 ],
 "Authenticate": [
  null,
  "Розпізнавання"
 ],
 "Administrative access": [
  null,
  "Адміністративний доступ"
 ],
 "Problem becoming administrator": [
  null,
  "Проблеми із набуттям прав адміністратора"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Обмежити доступ"
 ],
 "Switch to limited access": [
  null,
  "Перемкнутися на обмежений доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Модель із обмеженим доступом обмежує адміністративні привілеї. Функціональні можливості деяких частин вебконсолі буде суттєво зменшено."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ваш браузер запам'ятовуватиме ваш рівень доступу між сеансами."
 ],
 "Limited access": [
  null,
  "Обмежений доступ"
 ],
 "Turn on administrative access": [
  null,
  "Увімкнути адміністративний доступ"
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "Downloading $0": [
  null,
  "Отримання $0"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit повідомлено про помилку із кодом $0"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Помилка під час ініціалізації"
 ],
 "Failed": [
  null,
  "Не вдалося"
 ],
 "Home": [
  null,
  "Домівка"
 ],
 "Downloads": [
  null,
  "Отримання"
 ],
 "Not a directory": [
  null,
  "Не є каталогом"
 ],
 "All files": [
  null,
  "Усі файли"
 ],
 "Recent": [
  null,
  "Нещодавні"
 ],
 "No recent directories": [
  null,
  "Немає нещодавніх каталогів"
 ],
 "No recent files": [
  null,
  "Немає нещодавніх файлів"
 ],
 "Type to filter": [
  null,
  "Введіть щось для фільтрування"
 ],
 "File chooser actions": [
  null,
  "Дії з вибору файлів"
 ],
 "Open in file browser": [
  null,
  "Відкрити у навігаторі файловою системою"
 ],
 "Hide hidden files": [
  null,
  "Не показувати приховані файли"
 ],
 "Show hidden files": [
  null,
  "Показувати приховані файли"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Clear filters": [
  null,
  "Зняти фільтрування"
 ],
 "Directory is empty": [
  null,
  "Каталог є порожнім"
 ],
 "Directory has no sub-directories": [
  null,
  "У каталозі немає підкаталогів"
 ],
 "This directory contains only hidden files": [
  null,
  "У цьому каталозі зберігаються лише приховані файли"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "Folder": [
  null,
  "Тека"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Unknown": [
  null,
  "Невідомо"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Select an option": [
  null,
  "Виберіть варіант"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Priority": [
  null,
  "Пріоритетність"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "None": [
  null,
  "Немає"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Generated": [
  null,
  "Створений"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Start service": [
  null,
  "Запустити службу"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Delete $0": [
  null,
  "Вилучити $0"
 ],
 "Group": [
  null,
  "Група"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Not available": [
  null,
  "Недоступний"
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Permanent": [
  null,
  "Постійний"
 ],
 "Preserve": [
  null,
  "Зберегти"
 ],
 "Random": [
  null,
  "Випадковий"
 ],
 "Stable": [
  null,
  "Стабільний"
 ],
 "Use $0": [
  null,
  "Використати $0"
 ],
 "Failed to save settings": [
  null,
  "Не вдалося зберегти параметри"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Створення цієї $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Create it": [
  null,
  "Створити"
 ],
 "Invalid prefix $0": [
  null,
  "Некоректний префікс $0"
 ],
 "Invalid metric $0": [
  null,
  "Некоректна метрика $0"
 ],
 "Invalid address $0": [
  null,
  "Некоректна адреса $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Некоректний префікс або маска мережі $0"
 ],
 "Testing connection": [
  null,
  "Перевіряємо з’єднання"
 ],
 "Restoring connection": [
  null,
  "Відновлюємо з’єднання"
 ],
 "Troubleshoot…": [
  null,
  "Діагностика проблем…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager не запущено"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager не встановлено"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Для отримання списку пристроїв мережі та графіків слід встановити NetworkManager"
 ],
 "Enable service": [
  null,
  "Увімкнути службу"
 ],
 "Network interface '$0' not found": [
  null,
  "Інтерфейсу мережі «$0» не знайдено"
 ],
 "Return to overview page": [
  null,
  "Повернутися на сторінку огляду"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Вас не уповноважено на внесення змін до брандмауера."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Не уповноважено вимикати брандмауер"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Не уповноважено вмикати брандмауер"
 ],
 "Disable the firewall": [
  null,
  "Вимкнути брандмауер"
 ],
 "Enable the firewall": [
  null,
  "Увімкнути брандмауер"
 ],
 "Edit service $0": [
  null,
  "Змінити службу $0"
 ],
 "Remove service $0": [
  null,
  "Вилучити службу $0"
 ],
 "Included Services": [
  null,
  "Включені служби"
 ],
 "Additional port": [
  null,
  "Додатковий порт"
 ],
 "Remove additional port": [
  null,
  "Вилучити додатковий порт"
 ],
 "Remove zone $0": [
  null,
  "Вилучити зону $0"
 ],
 "Add services to zone $0": [
  null,
  "Додати служби до зони $0"
 ],
 "Add services": [
  null,
  "Додавання служб"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "зона $0"
 ],
 "Interface": [
  null,
  "Інтерфейс",
  "Інтерфейси",
  "Інтерфейси"
 ],
 "Allowed addresses": [
  null,
  "Дозволені адреси"
 ],
 "Entire subnet": [
  null,
  "Уся підмережа"
 ],
 "There are no active services in this zone": [
  null,
  "У цій зоні немає активних служб"
 ],
 "Filter services": [
  null,
  "Фільтрувати служби"
 ],
 "Failed to edit service": [
  null,
  "Не вдалося змінити службу"
 ],
 "Failed to add port": [
  null,
  "Не вдалося додати порт"
 ],
 "Failed to add service": [
  null,
  "Не вдалося додати службу"
 ],
 "Unknown service name": [
  null,
  "Невідома назва служби"
 ],
 "Invalid port number": [
  null,
  "Некоректний номер порту"
 ],
 "Invalid range": [
  null,
  "Некоректний діапазон"
 ],
 "Range must be strictly ordered": [
  null,
  "Діапазон має бути строго упорядковано"
 ],
 "Edit service": [
  null,
  "Змінити службу"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Редагувати нетипову службу у зоні $0"
 ],
 "Add ports": [
  null,
  "Додати порти"
 ],
 "Add ports to $0 zone": [
  null,
  "Додати порти до зони $0"
 ],
 "Add services to $0 zone": [
  null,
  "Додати служби до зони $0"
 ],
 "Custom ports": [
  null,
  "Нетипові порти"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Приклад: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Можна використовувати відокремлені комами порти, діапазони і служби"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Приклад: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Якщо не заповнювати, ідентифікатор буде створено на основі пов'язаних служб портів та номерів портів"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Додавання нетипових портів призведе до перезавантаження firewalld. Це перезавантаження спричинить втрату усіх налаштувань окремого сеансу роботи!"
 ],
 "Failed to add zone": [
  null,
  "Не вдалося додати зону"
 ],
 "Add zone": [
  null,
  "Додати зону"
 ],
 "Trust level": [
  null,
  "Рівень довіри"
 ],
 "Sorted from least to most trusted": [
  null,
  "Упорядковано від найменшої до найбільшої довіри"
 ],
 "Custom zones": [
  null,
  "Нетипові зони"
 ],
 "No description available": [
  null,
  "Немає опису"
 ],
 "Included services": [
  null,
  "Включені служби"
 ],
 "The cockpit service is automatically included": [
  null,
  "Службу cockpit включено автоматично"
 ],
 "Interfaces": [
  null,
  "Інтерфейси"
 ],
 "Range": [
  null,
  "Діапазон"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-адреса із префіксом маршрутизації. Записи значень слід відокремлювати комами. Приклад: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Підтвердження вилучення $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "У цій зоні міститься служба cockpit. Переконайтеся, що застосування цієї зони не поширюється на ваше поточне з'єднання за допомогою вебконсолі."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Вилучення запису зони призведе до вилучення усіх служб у ній."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Вилучення служби cockpit може призвести до недоступності вебконсолі. Переконайтеся, що застосування цієї зони не поширюється на ваше поточне з'єднання за допомогою вебконсолі."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Вилучити службу $0 із зони $1"
 ],
 "Firewall is not available": [
  null,
  "Брандмауер недоступний"
 ],
 "Please install the $0 package": [
  null,
  "Будь ласка, встановіть пакунок $0"
 ],
 "Add a new zone": [
  null,
  "Додати нову зону"
 ],
 "Add new zone": [
  null,
  "Додати нову зону"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Типово, вхідні запити заблоковано. Вихідні запити не заблоковано."
 ],
 "Connected": [
  null,
  "З'єднано"
 ],
 "Wireless": [
  null,
  "Бездротова"
 ],
 "Wired": [
  null,
  "Дротова"
 ],
 "No networks found": [
  null,
  "Мереж не знайдено"
 ],
 "No interface selected": [
  null,
  "Не вибрано жодного інтерфейсу"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "Виберіть інтерфейс мережі для налаштовування з'єднання."
 ],
 "SSID can not be empty": [
  null,
  "SSID не може бути порожнім"
 ],
 "Password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Failed to connect": [
  null,
  "Не вдалося встановити з'єднання"
 ],
 "Check your password.": [
  null,
  "Перевірте ваш пароль."
 ],
 "Connect to hidden network": [
  null,
  "Встановити з'єднання із прихованою мережею"
 ],
 "Connect to $0": [
  null,
  "З'єднатися з $0"
 ],
 "Network name": [
  null,
  "Назва мережі"
 ],
 "Security": [
  null,
  "Безпека"
 ],
 "WPA/WPA2 Personal": [
  null,
  "Особистий WPA/WPA2"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вилучення $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вмикання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Switch on $0": [
  null,
  "Увімкнути $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вимикання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Switch off $0": [
  null,
  "Вимкнути $0"
 ],
 "Bond": [
  null,
  "Прив’язка"
 ],
 "Team": [
  null,
  "Команда"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Місток"
 ],
 "Unknown \"$0\"": [
  null,
  "Невідомий «$0»"
 ],
 "Carrier": [
  null,
  "Носій сигналу"
 ],
 "Yes": [
  null,
  "Так"
 ],
 "No": [
  null,
  "Ні"
 ],
 "Inactive": [
  null,
  "Неактивний"
 ],
 "Unknown configuration": [
  null,
  "Невідомі налаштування"
 ],
 "Additional address $val": [
  null,
  "Додаткова адреса $val"
 ],
 "Address $val": [
  null,
  "Адреса $val"
 ],
 "Gateway $gateway": [
  null,
  "Шлюз $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Додатковий DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Додаткові домени пошуку DNS $val"
 ],
 "DNS search domains $val": [
  null,
  "Домени пошуку DNS $val"
 ],
 "General": [
  null,
  "Загальний"
 ],
 "Connect automatically": [
  null,
  "З’єднуватися автоматично"
 ],
 "Automatic": [
  null,
  "Автоматично"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Стеження за ARP"
 ],
 "Broken configuration": [
  null,
  "Помилки у налаштуваннях"
 ],
 "Team port": [
  null,
  "Порт команди"
 ],
 "Spanning tree protocol": [
  null,
  "Протокол пересування ієрархією"
 ],
 "Priority $priority": [
  null,
  "Пріоритетність $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Затримка переспрямування $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Час вітання $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Максимальний вік повідомлення $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Вартість шляху $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Режим початкової зони (hairpin)"
 ],
 "Bridge port": [
  null,
  "Порт містка"
 ],
 "Parent $parent": [
  null,
  "Батьківський $parent"
 ],
 "ID $id": [
  null,
  "Ід. $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Пароль до мережі не збережено. Будь ласка, накажіть забути про мережу і встановіть з'єднання з мережею знову."
 ],
 "Failed to connect to $0": [
  null,
  "Не вдалося ввстановити з'єднання $0"
 ],
 "secured": [
  null,
  "захищена"
 ],
 "open": [
  null,
  "відкрита"
 ],
 "Last connected: $0": [
  null,
  "Востаннє з'єднано: $0"
 ],
 "Signal strength": [
  null,
  "Потужність сигналу"
 ],
 "Not permitted to disconnect network": [
  null,
  "Не дозволено розривати з'єднання з мережею"
 ],
 "Disconnect": [
  null,
  "Від’єднатися"
 ],
 "Not permitted to connect to network": [
  null,
  "Заборонено встановлювати з'єднання з мережею"
 ],
 "Forget": [
  null,
  "Забути"
 ],
 "$0 hidden network": [
  null,
  "$0 прихована мережа",
  "$0 приховані мережі",
  "$0 прихованих мереж"
 ],
 "Filter": [
  null,
  "Фільтр"
 ],
 "Refresh": [
  null,
  "Освіжити"
 ],
 "Available networks": [
  null,
  "Доступні мережі"
 ],
 "Network": [
  null,
  "Мережа"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Signal": [
  null,
  "Сигнал"
 ],
 "Rate": [
  null,
  "Частота"
 ],
 "Primary action": [
  null,
  "Основна дія"
 ],
 "Secondary actions": [
  null,
  "Вторинні дії"
 ],
 "Not permitted to configure network devices": [
  null,
  "Не дозволено налаштовувати пристрої мережі"
 ],
 "Enable or disable the device": [
  null,
  "Увімкнути або вимкнути пристрій"
 ],
 "This device cannot be managed here.": [
  null,
  "Тут не можна керувати цим пристроєм."
 ],
 "Connection will be lost": [
  null,
  "З’єднання буде розірвано"
 ],
 "Keep connection": [
  null,
  "Підтримувати з’єднання"
 ],
 "Invalid IP address: $0": [
  null,
  "Некоректна IP-адреса: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Некоректна адреса призначення: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Некоректна адреса шлюзу: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Некоректна адреса DNS: $0"
 ],
 "Preparing": [
  null,
  "Приготування"
 ],
 "Configuring": [
  null,
  "Налаштовування"
 ],
 "Authenticating": [
  null,
  "Автентифікація"
 ],
 "Configuring IP": [
  null,
  "Налаштовуємо IP"
 ],
 "Checking IP": [
  null,
  "Перевіряємо IP"
 ],
 "Waiting": [
  null,
  "Очікування"
 ],
 "Active": [
  null,
  "Активний"
 ],
 "Deactivating": [
  null,
  "Деактивація"
 ],
 "Adhoc": [
  null,
  "Спеціальне"
 ],
 "Infra": [
  null,
  "Інфра"
 ],
 "AP": [
  null,
  "ТД"
 ],
 "Mesh": [
  null,
  "Сітка"
 ],
 "No carrier": [
  null,
  "Немає сигналу"
 ],
 "Part of $0": [
  null,
  "Є частиною $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Зміна параметрів призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Change the settings": [
  null,
  "Змінити параметри"
 ],
 "Add bridge": [
  null,
  "Додати місток"
 ],
 "Edit bridge settings": [
  null,
  "Редагувати параметри містка"
 ],
 "Ports": [
  null,
  "Порти"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Протокол пересування ієрархією (STP)"
 ],
 "STP priority": [
  null,
  "Пріоритет STP"
 ],
 "STP forward delay": [
  null,
  "Затримка переспрямування STP"
 ],
 "STP hello time": [
  null,
  "Час вітання STP"
 ],
 "STP maximum message age": [
  null,
  "Максимальний вік повідомлення STP"
 ],
 "Round robin": [
  null,
  "Циклічне"
 ],
 "Active backup": [
  null,
  "Активне резервування"
 ],
 "Load balancing": [
  null,
  "Збалансовування навантаження"
 ],
 "Broadcast": [
  null,
  "Трансляція"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Неактивний"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "Луна-імпульс ARP"
 ],
 "NSNA ping": [
  null,
  "Луна-імпульс NSNA"
 ],
 "Add team": [
  null,
  "Додати команду"
 ],
 "Edit team settings": [
  null,
  "Редагувати параметри команди"
 ],
 "Runner": [
  null,
  "Засіб для запуску"
 ],
 "Balancer": [
  null,
  "Балансир"
 ],
 "Primary": [
  null,
  "Основний"
 ],
 "Link watch": [
  null,
  "Спостереження за посиланнями"
 ],
 "Link up delay": [
  null,
  "Затримка встановлення зв’язку"
 ],
 "Link down delay": [
  null,
  "Затримка розірвання зв’язку"
 ],
 "Ping interval": [
  null,
  "Проміжок між імпульсами"
 ],
 "Ping target": [
  null,
  "Ціль тестування луною"
 ],
 "Automatic (DHCP only)": [
  null,
  "Автоматично (лише DHCP)"
 ],
 "Link local": [
  null,
  "Пов’язати локальний"
 ],
 "Manual": [
  null,
  "Вручну"
 ],
 "Shared": [
  null,
  "Спільний"
 ],
 "Prefix length or netmask": [
  null,
  "Довжина префікса або маска мережі"
 ],
 "Prefix length": [
  null,
  "Довжина префікса"
 ],
 "IPv4 settings": [
  null,
  "Параметри IPv4"
 ],
 "IPv6 settings": [
  null,
  "Параметри IPv6"
 ],
 "Addresses": [
  null,
  "Адреси"
 ],
 "Select method": [
  null,
  "Виберіть метод"
 ],
 "Add address": [
  null,
  "Додати адресу"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Remove item": [
  null,
  "Вилучити запис"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Додати сервер DNS"
 ],
 "DNS search domains": [
  null,
  "Домени пошуку DNS"
 ],
 "Add search domain": [
  null,
  "Додати домен пошуку"
 ],
 "Search domain": [
  null,
  "Домен пошуку"
 ],
 "Routes": [
  null,
  "Маршрути"
 ],
 "Add route": [
  null,
  "Додати маршрут"
 ],
 "Metric": [
  null,
  "Метрика"
 ],
 "Enter a valid MAC address": [
  null,
  "Введіть коректну MAC-адресу"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 мережа",
  "$0 мережі",
  "$0 мереж"
 ],
 "Add VPN": [
  null,
  "Додати VPN"
 ],
 "Add bond": [
  null,
  "Додати зв’язок"
 ],
 "Add VLAN": [
  null,
  "Додати VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Редагування правил і зон"
 ],
 "$0 active zone": [
  null,
  "$0 активна зона",
  "$0 активні зони",
  "$0 активних зон"
 ],
 "Managed interfaces": [
  null,
  "Керовані інтерфейси"
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "Sending": [
  null,
  "Надсилання"
 ],
 "Receiving": [
  null,
  "Отримання"
 ],
 "Unmanaged interfaces": [
  null,
  "Некеровані інтерфейси"
 ],
 "Network logs": [
  null,
  "Журнали роботи у мережі"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Адреси не форматовано належним чином"
 ],
 "Invalid IP address '$0'": [
  null,
  "Некоректна IP-адреса «$0»"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Не встановлено пакунок wireguard-tools"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "У вузла #$0 некоректна кінцева точка. Її слід вказати у форматі вузол:порт, приклад: 1.2.3.4:51820, [2001:db8::1]:51820 або example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "У вузла #$0 некоректний порт кінцевої точки. Порт має бути числом."
 ],
 "Listen port must be a number": [
  null,
  "Порт очікування має бути числом"
 ],
 "Add WireGuard VPN": [
  null,
  "Додати WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Редагувати WireGuard VPN"
 ],
 "Private key": [
  null,
  "Закритий ключ"
 ],
 "Paste existing key": [
  null,
  "Вставити наявний ключ"
 ],
 "Regenerate": [
  null,
  "Повторно створити"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Відкритий ключ буде створено, коли буде введено коректний закритий ключ"
 ],
 "Listen port": [
  null,
  "Порт очікування"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Буде встановлено значення «Автоматично»"
 ],
 "IP addresses": [
  null,
  "IP-адреси"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Можна вказати декілька адрес, відокремивши їх комами або пробілами."
 ],
 "Peers": [
  null,
  "Вузли"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Вузли є іншими машинами, які з'єднано із цією. Відкриті ключі з інших машин буде надано у спільне користування цій машині."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Слід вказати кінцеву точку, яка працюватиме як «сервер», у форматі вузол:порт, інакше, можна не заповнювати."
 ],
 "Add peer": [
  null,
  "Додати вузол"
 ],
 "Endpoint": [
  null,
  "Кінцева точка"
 ],
 "Allowed IPs": [
  null,
  "Дозволені IP-адреси"
 ],
 "No peers added.": [
  null,
  "Не додано жодного вузла."
 ],
 "Edit VLAN settings": [
  null,
  "Редагувати параметри VLAN"
 ],
 "Parent": [
  null,
  "Батьківський"
 ],
 "VLAN ID": [
  null,
  "Ід. VLAN"
 ],
 "Transmitting": [
  null,
  "Передавання"
 ],
 "MTU must be a positive number": [
  null,
  "MTU має бути додатнім числом"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Set to": [
  null,
  "Встановити значення"
 ],
 "Team port settings": [
  null,
  "Параметри порту команди"
 ],
 "Sticky": [
  null,
  "Липкий"
 ],
 "LACP key": [
  null,
  "Ключ LACP"
 ],
 "Bridge port settings": [
  null,
  "Параметри порту містка"
 ],
 "Path cost": [
  null,
  "Вартість маршруту"
 ],
 "Hair pin mode": [
  null,
  "Режим початкової зони"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Адаптивне урівноваження навантаження за передаванням"
 ],
 "Adaptive load balancing": [
  null,
  "Адаптивне урівноваження навантаження"
 ],
 "MII (recommended)": [
  null,
  "MII (рекомендоване)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Редагувати параметри прив'язки"
 ],
 "Network bond": [
  null,
  "Мережевий зв'язок"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Мережевий зв'язок поєднує декілька інтерфейсів мережі у один логічний інтерфейс із вищою пропускною здатністю або вищим рівнем резервування."
 ],
 "Link monitoring": [
  null,
  "Спостереження за зв’язком"
 ],
 "Monitoring interval": [
  null,
  "Інтервал оновлення"
 ],
 "Monitoring targets": [
  null,
  "Спостерігаємо за цілями"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вилучення $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Remove $0": [
  null,
  "Вилучити $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Додавання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "No interfaces available": [
  null,
  "Немає доступних інтерфейсів"
 ],
 "Add member": [
  null,
  "Додати учасника"
 ],
 "Interface members": [
  null,
  "Учасники інтерфейсу"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ]
});
