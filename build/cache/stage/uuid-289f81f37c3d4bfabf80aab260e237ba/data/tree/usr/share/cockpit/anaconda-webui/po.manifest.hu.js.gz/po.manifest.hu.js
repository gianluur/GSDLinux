cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "hu",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
