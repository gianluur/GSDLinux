cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "vi",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0$1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "Lỗi $0"
 ],
 "$0 installation": [
  null,
  "Cài đặt $0"
 ],
 "$0 installer": [
  null,
  "Trình cài đặt $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 là phân vùng mở rộng MBR chứa các phân vùng logic. Xóa hết các phân vùng logic cũng sẽ tự động xóa phân vùng mở rộng này."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 là bắt buộc, nhưng chỉ có $1 sẵn có."
 ],
 "$0 warning": [
  null,
  "$0 cảnh báo"
 ],
 "$0 will be deleted": [
  null,
  "$0 sẽ được xoá"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Hệ thống tập tin '$0' không thể nằm trên thiết bị khối mã hóa"
 ],
 "'$0' must be assigned to $1": [
  null,
  "$0 phải được gán cho $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' phải được lưu vào thiết bị có định dạng '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "`$0` phải nằm trên phân vùng hệ thống EFI. Phân vùng được chọn sử dụng hệ thống tệp FAT nhưng chưa được đánh dấu là ESP. Hãy đặt loại phân vùng thành EFI System và bật cờ esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Phân vùng '$0' trên thiết bị MDRAID $1 được phát hiện. Phân vùng bootloader trên thiết bị MDRAID không được hỗ trợ."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Tài khoản người dùng chuẩn có quyền quản trị để thực hiện thay đổi toàn hệ thống."
 ],
 "Abort installation": [
  null,
  "Hủy cài đặt"
 ],
 "About": [
  null,
  "Thông tin"
 ],
 "Account": [
  null,
  "Tài khoản"
 ],
 "Actions": [
  null,
  "Hoạt động"
 ],
 "Add another server...": [
  null,
  "Thêm máy chủ khác..."
 ],
 "Add mount": [
  null,
  "Thêm điểm gắn kết"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Tiện ích bổ sung cho môi trường bạn đã chọn"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Tiện ích bổ sung không phụ thuộc vào môi trường của bạn"
 ],
 "Additional languages": [
  null,
  "Ngôn ngữ bổ sung"
 ],
 "Additional software for the selected environment": [
  null,
  "Phần mềm bổ sung cho môi trường đã chọn"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Mọi thay đổi trong trình chỉnh sửa bộ nhớ đều có hiệu lực ngay tức thì."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Mọi thiết bị sử dụng chuỗi mật khẩu này sẽ được mở khoá"
 ],
 "Anaconda Web UI": [
  null,
  "Giao diện Web Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Trang dự án Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Áp dụng điểm gắn kết và cài đặt"
 ],
 "Applying changes...": [
  null,
  "Đang áp dụng thay đổi..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Gán phân vùng vào điểm gắn kết. Hữu ích cho bố cục tuỳ chỉnh cấu hình sẵn."
 ],
 "Automatic log file upload": [
  null,
  "Tự động tải lên file nhật ký"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Tự động đặt ngày giờ bằng thời gian máy chủ"
 ],
 "Automatically set timezone": [
  null,
  "Tự động thiết lập múi giờ"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Bộ nhớ còn trống: $0. Việc cài đặt cần: $1."
 ],
 "Back": [
  null,
  "Quay lại"
 ],
 "Base environment": [
  null,
  "Môi trường cơ bản"
 ],
 "Brief description of the issue": [
  null,
  "Mô tả ngắn gọn về vấn đề"
 ],
 "Bug report details": [
  null,
  "Chi tiết báo cáo lỗi"
 ],
 "Bugzilla API key": [
  null,
  "Khóa API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Bằng việc tiếp tục sử dụng phần mềm này, bạn hiểu và chấp nhận những rủi ro liên quan đến phiên bản thử nghiệm của phần mềm, chỉ sử dụng phần mềm này cho mục đích thử nghiệm và phát triển, và sẵn sàng báo cáo bất kỳ lỗi hoặc sự cố nào để cải thiện phần mềm này."
 ],
 "Cancel": [
  null,
  "Huỷ bỏ"
 ],
 "Change": [
  null,
  "Thay đổi"
 ],
 "Change destination": [
  null,
  "Thay đổi đích"
 ],
 "Change hostname": [
  null,
  "Thay đổi tên máy chủ"
 ],
 "Change partition layout": [
  null,
  "Thay đổi bố cục phân vùng"
 ],
 "Change system keyboard layout": [
  null,
  "Thay đổi bố cục bàn phím hệ thống"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Mọi thay đổi ở đây đều có hiệu lực ngay lập tức. Bạn không thể \"hoàn tác\" thay đổi."
 ],
 "Checking installation configuration...": [
  null,
  "Đang kiểm tra cấu hình cài đặt..."
 ],
 "Checking storage configuration": [
  null,
  "Đang kiểm tra các cài đặt bộ nhớ"
 ],
 "Clear search": [
  null,
  "Xóa tìm kiếm"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Nhấn \"Tiếp” lần nữa để tiếp tục dù có các cảnh báo này."
 ],
 "Close": [
  null,
  "Đóng"
 ],
 "Close storage editor": [
  null,
  "Đóng trình chỉnh sửa lưu trữ"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit lưu trữ không cung cấp cụm mật khẩu để mở khóa thiết bị mã hóa."
 ],
 "Completed": [
  null,
  "Đã hoàn tất"
 ],
 "Configuration is incomplete": [
  null,
  "Cấu hình chưa hoàn tất"
 ],
 "Configure NTP servers": [
  null,
  "Cấu hình máy chủ NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Cấu hình máy chủ NTP tùy chỉnh"
 ],
 "Configure network": [
  null,
  "Cấu hình mạng"
 ],
 "Configure storage": [
  null,
  "Cài đặt bộ nhớ"
 ],
 "Configure storage again": [
  null,
  "Cài đặt lại bộ nhớ"
 ],
 "Confirm passphrase": [
  null,
  "Xác nhận chuỗi mật khẩu"
 ],
 "Continue": [
  null,
  "Tiếp tục"
 ],
 "Continue installation": [
  null,
  "Tiếp tục cài đặt"
 ],
 "Continue installation?": [
  null,
  "Tiếp tục cài đặt?"
 ],
 "Continue with installation": [
  null,
  "Tiếp tục cài đặt"
 ],
 "Correct these issues before continuing.": [
  null,
  "Hãy khắc phục các vấn đề này trước khi tiếp tục."
 ],
 "Create Account": [
  null,
  "Tạo tài khoản"
 ],
 "Create account": [
  null,
  "Tạo tài khoản"
 ],
 "Currently installed: $0": [
  null,
  "Đang cài đặt: $0"
 ],
 "Custom": [
  null,
  "Tùy chỉnh"
 ],
 "Date": [
  null,
  "Ngày"
 ],
 "Date and time": [
  null,
  "Ngày và thời gian"
 ],
 "Delete partition": [
  null,
  "Xóa phân vùng"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Xóa một số phân vùng có thể khiến $0 không khởi động được: $1"
 ],
 "Description": [
  null,
  "Mô tả"
 ],
 "Destination": [
  null,
  "Đích đến"
 ],
 "Destination is encrypted": [
  null,
  "Đích đến đã được mã hóa"
 ],
 "Detailed description of the issue": [
  null,
  "Mô tả chi tiết về vấn đề"
 ],
 "Detected valid storage layout:": [
  null,
  "Đã phát hiện bố cục lưu trữ hợp lệ:"
 ],
 "Device": [
  null,
  "Thiết bị"
 ],
 "Duplicate device.": [
  null,
  "Thiết bị trùng lặp."
 ],
 "Duplicate mount point.": [
  null,
  "Điểm gắn kết trùng lặp."
 ],
 "Enable root account": [
  null,
  "Kích hoạt tài khoản root"
 ],
 "Encrypt my data": [
  null,
  "Mã hóa dữ liệu của tôi"
 ],
 "Encrypted": [
  null,
  "Đã mã hóa"
 ],
 "Encryption": [
  null,
  "Mã hóa"
 ],
 "Enter PIN": [
  null,
  "Nhập mã PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Nhập mã PIN để truy cập trình cài đặt"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Nhập khóa API Bugzilla của bạn để tạo báo cáo lỗi. Bạn sẽ có thể xem xét và chỉnh sửa chi tiết lỗi ở bước tiếp theo."
 ],
 "Environment": [
  null,
  "Môi trường"
 ],
 "Erase data and install": [
  null,
  "Xóa dữ liệu và cài đặt"
 ],
 "Error details": [
  null,
  "Chi tiết lỗi"
 ],
 "Exit to live desktop": [
  null,
  "Thoát về màn hình trực tiếp"
 ],
 "Extended partition": [
  null,
  "Phân vùng mở rộng"
 ],
 "Failed to report issue": [
  null,
  "Báo cáo lỗi thất bại"
 ],
 "Failed to save layouts": [
  null,
  "Lưu bố cục thất bại"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux yêu cầu tối thiểu $0 dung lượng đĩa."
 ],
 "Finalization": [
  null,
  "Hoàn tất"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Hoàn tất: Cấu hình hệ thống đã xong. Quá trình hoàn tất cài đặt có thể mất vài phút."
 ],
 "Find layout": [
  null,
  "Tìm bố cục"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Để bảo mật tốt hơn, tránh dùng tài khoản root trực tiếp. Thay vào đó, sử dụng tài khoản địa phương ở trên để quản lý hệ thống."
 ],
 "Full name": [
  null,
  "Họ và tên"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Họ và tên không được chứa ký tự dấu hai chấm"
 ],
 "Helper text": [
  null,
  "Chữ hướng dẫn"
 ],
 "Hide API key": [
  null,
  "Ẩn khóa API"
 ],
 "Hide PIN": [
  null,
  "Ẩn mã PIN"
 ],
 "Hide confirmed password": [
  null,
  "Ẩn mật khẩu đã xác nhận"
 ],
 "Hide passphrase": [
  null,
  "Ẩn cụm mật khẩu"
 ],
 "Hide password": [
  null,
  "Ẩn mật khẩu"
 ],
 "Hostname": [
  null,
  "Tên máy"
 ],
 "How would you like to install?": [
  null,
  "Bạn muốn cài đặt bằng cách nào?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Tôi hiểu rằng tất cả dữ liệu hiện có sẽ bị xóa khỏi các ổ đĩa đã chọn"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Tôi hiểu rằng một số dữ liệu đang có sẽ bị xoá"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Tôi hiểu rằng một số phân vùng ổ cứng sẽ được thay đổi"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Nếu để trống, tên máy sẽ là tạm thời và được thiết lập theo thông tin mạng."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Nếu không có tùy chọn nào ở trên phù hợp, hãy sử dụng trình chỉnh sửa bộ nhớ để tạo cấu hình phân vùng tùy chỉnh trước khi tiếp tục."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Nếu bạn tuỳ biến phân vùng ổ cứng, những thứ sau là cần thiết:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Nếu bạn không đồng ý tải lên tự động các tập tin nhật ký, bạn có thể $0 thay thế. Báo cáo thủ công cho phép bạn xem trước và chọn lọc các tập tin nhật ký để đính kèm."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Nếu bạn không hiểu hoặc không chấp nhận rủi ro, vui lòng thoát khỏi chương trình này."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Nếu vấn đề của bạn trùng khớp với một trong các lỗi ở trên, bạn có thể mở báo cáo lỗi đó và bổ sung thông tin của mình thay vì tạo một báo cáo trùng lặp."
 ],
 "In progress": [
  null,
  "Đang trong quá trình"
 ],
 "Initializing...": [
  null,
  "Đang khởi tạo..."
 ],
 "Install": [
  null,
  "Cài đặt"
 ],
 "Installation completed": [
  null,
  "Cài đặt hoàn tất"
 ],
 "Installation failed": [
  null,
  "Cài đặt thất bại"
 ],
 "Installation method": [
  null,
  "Phương thức cài đặt"
 ],
 "Installation of the system failed": [
  null,
  "Cài đặt hệ thống thất bại"
 ],
 "Installation of the system failed: $0": [
  null,
  "Việc cài đặt hệ thống thất bại: $0"
 ],
 "Installation type": [
  null,
  "Loại cài đặt"
 ],
 "Installing": [
  null,
  "Đang cài đặt"
 ],
 "Insufficient disk space": [
  null,
  "Dung lượng đĩa không đủ"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Mã PIN không hợp lệ. Vui lòng thử lại."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Phát hiện cấu hình RAID không hợp lệ. Nếu RAID được tạo trực tiếp trên ổ đĩa, cần tạo bảng phân vùng trên RAID. Nếu RAID được tạo trên phân vùng, nó phải chứa một hệ thống tập tin hoặc định dạng duy nhất (ví dụ: LVM PV). Các phân vùng hiện có trên RAID này sẽ bị bỏ qua."
 ],
 "Invalid hostname": [
  null,
  "Tên máy không hợp lệ"
 ],
 "Jump to first incomplete step": [
  null,
  "Chuyển đến bước chưa hoàn thành đầu tiên"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Giữ nguyên bố cục đĩa hiện tại và sử dụng không gian còn trống để cài đặt song song với hệ điều hành khác."
 ],
 "Keyboard": [
  null,
  "Bàn phím"
 ],
 "Keyboard layout during boot": [
  null,
  "Bố cục bàn phím khi khởi động"
 ],
 "Language": [
  null,
  "Ngôn ngữ"
 ],
 "Launch storage editor": [
  null,
  "Mở trình thiết đặt bộ nhớ"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Tìm hiểu thêm về quyền truy cập bị hạn chế trong cấu hình"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Để trống cả hai ô nhập mật khẩu để sử dụng mật khẩu rỗng."
 ],
 "Location": [
  null,
  "Vị trí"
 ],
 "Locked devices": [
  null,
  "Các thiết bị đã khoá"
 ],
 "Log in": [
  null,
  "Đăng nhập"
 ],
 "Make current": [
  null,
  "Đặt làm hiện tại"
 ],
 "Manual disk configuration": [
  null,
  "Cài đặt ổ cứng thủ công"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Cấu hình đĩa thủ công: Phân vùng gắn kết"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Có thể chứa chữ cái, số và dấu gạch ngang."
 ],
 "May need more free space": [
  null,
  "Có thể cần thêm dung lượng trống"
 ],
 "Medium": [
  null,
  "Trung gian"
 ],
 "Minimum of $0 required": [
  null,
  "Yêu cầu tối thiểu $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Lựa chọn định dạng lại không khớp giữa thiết bị cha và thiết bị con."
 ],
 "Mount point": [
  null,
  "Điểm gắn kết"
 ],
 "Mount point assignment": [
  null,
  "Phân bổ điểm gắn kết"
 ],
 "Move down": [
  null,
  "Di chuyển xuống"
 ],
 "Move up": [
  null,
  "Di chuyển lên"
 ],
 "Must be at least $0 characters": [
  null,
  "Phải chứa ít nhất $0 kí tự"
 ],
 "My issue is different, continue": [
  null,
  "Vấn đề của tôi khác, tiếp tục"
 ],
 "NTP Servers": [
  null,
  "Máy chủ NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Tên"
 ],
 "Needs at least $0": [
  null,
  "Cần ít nhất $0"
 ],
 "Network": [
  null,
  "Mạng"
 ],
 "Network Configuration": [
  null,
  "Cấu hình mạng"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Không có kết nối. Hãy thiết đặt mạng ở thanh công cụ phía trên để báo lỗi."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Không có kết nối. Hãy thiết đặt mạng để báo lỗi."
 ],
 "Network plugin failed": [
  null,
  "Lỗi plugin mạng"
 ],
 "Next": [
  null,
  "Tiếp tục"
 ],
 "No devices": [
  null,
  "Không có thiết bị"
 ],
 "No disks available": [
  null,
  "Không có thiết bị nào có sẵn"
 ],
 "No disks selected": [
  null,
  "Không có đĩa nào được chọn"
 ],
 "No keyboard layouts selected": [
  null,
  "Chưa chọn bố cục bàn phím"
 ],
 "No layouts selected yet": [
  null,
  "Chưa chọn bố cục nào"
 ],
 "No results found": [
  null,
  "Không tìm thấy kết quả"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Không có keymap VConsole hợp lệ cho bố cục bàn phím đã chọn. Vui lòng chọn bố cục bàn phím khác."
 ],
 "Not enough available free space": [
  null,
  "Không đủ dung lượng trống"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Các ổ đã chọn không đủ bộ nhớ."
 ],
 "Not enough space on selected disks.": [
  null,
  "Không đủ bộ nhớ trên các ổ đĩa đã chọn."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Lưu ý: Đây là phần mềm thử nghiệm, chỉ dành cho mục đích phát triển và thử nghiệm. KHÔNG sử dụng phần mềm này cho bất kỳ công việc quan trọng nào hoặc trong môi trường thật."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Mở biểu mẫu báo lỗi Bugzilla"
 ],
 "Operating system": [
  null,
  "Hệ điều hành"
 ],
 "Options": [
  null,
  "Tùy chọn"
 ],
 "Other keyboards": [
  null,
  "Bàn phím khác"
 ],
 "Partitions (advanced)": [
  null,
  "Phân vùng (nâng cao)"
 ],
 "Passphrase": [
  null,
  "Chuỗi mật khẩu"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Chuỗi mật khẩu không trùng với bất cứ thiết bị nào đang khoá"
 ],
 "Passphrases must match": [
  null,
  "Chuỗi mật khẩu phải trùng khớp"
 ],
 "Pending": [
  null,
  "Đang chờ xử lý"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Vui lòng đính kèm file nhật ký $0 vào báo cáo."
 ],
 "Please enter a PIN": [
  null,
  "Vui lòng nhập mã PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Vui lòng chọn ít nhất một đĩa để tiếp tục"
 ],
 "Pool": [
  null,
  "Nhóm"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Cung cấp bởi Anaconda"
 ],
 "Pre-release": [
  null,
  "Bản thử nghiệm"
 ],
 "Prefer to report manually? $0": [
  null,
  "Bạn muốn báo cáo thủ công? $0"
 ],
 "Proceed with installation": [
  null,
  "Tiếp tục đến cài đặt"
 ],
 "Quit": [
  null,
  "Thoát"
 ],
 "Quit installer?": [
  null,
  "Thoát trình cài đặt?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Đọc thông tin về OS thất bại."
 ],
 "Reading information about the computer failed.": [
  null,
  "Đọc thông tin về máy tính thất bại."
 ],
 "Reading installer configuration failed.": [
  null,
  "Đọc cấu hình trình cài đặt thất bại."
 ],
 "Reading installer version information failed.": [
  null,
  "Đọc thông tin phiên bản trình cài đặt thất bại."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Tên máy chủ thực chỉ được chứa các ký tự chữ số, gạch ngang (dashes - không được bắt đầu hoặc kết thúc bằng ký tự này) và dấu chấm"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Tên máy (hostname) phải ngắn hơn 64 kí tự"
 ],
 "Reboot": [
  null,
  "Khởi động lại"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Khởi động lại vào Windows để thay đổi kích thước phân vùng đã mã hóa bằng BitLocker. Hãy tạo ra ít nhất $0 dung lượng trống để cài đặt."
 ],
 "Reboot system?": [
  null,
  "Khởi động lại máy?"
 ],
 "Reclaim additional space": [
  null,
  "Thu hồi thêm dung lượng"
 ],
 "Reclaim space": [
  null,
  "Thu hồi dung lượng"
 ],
 "Reclaim space (required)": [
  null,
  "Thu hồi dung lượng (bắt buộc)"
 ],
 "Recommended": [
  null,
  "Đề xuất"
 ],
 "Recommended partitions:": [
  null,
  "Phân vùng được đề xuất:"
 ],
 "Reformat": [
  null,
  "Định dạng lại"
 ],
 "Reinstall Fedora": [
  null,
  "Cài đặt lại Fedora"
 ],
 "Remove": [
  null,
  "Xoá"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Xoá tất cả phân vùng trên các thiết bị đã chọn, kể cả những hệ điều hành đang tồn tại trên máy."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Xóa hoặc thay đổi kích thước hệ thống tập tin hiện có để giải phóng dung lượng cho việc cài đặt."
 ],
 "Remove server": [
  null,
  "Xóa máy chủ"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Việc xóa hệ thống tập tin sẽ xóa vĩnh viễn tất cả dữ liệu nó chứa. Thay đổi kích thước phân vùng có thể giải phóng dung lượng chưa dùng, nhưng không hoàn toàn không có rủi ro. Hãy chắc chắn rằng bạn có bản sao lưu những gì quan trọng trước khi thu hồi dung lượng."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Thay thế cài đặt hiện tại, nhưng giữ lại các file trong thư mục home."
 ],
 "Report Issue": [
  null,
  "Báo lỗi"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Báo cáo sự cố hoặc gửi phản hồi bằng cách mở biểu mẫu báo cáo lỗi trên Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Báo lỗi"
 ],
 "Reporting issue...": [
  null,
  "Đang báo lỗi..."
 ],
 "Required": [
  null,
  "Bắt buộc"
 ],
 "Requirements": [
  null,
  "Yêu cầu"
 ],
 "Rescan devices": [
  null,
  "Quét lại các thiết bị"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Quét lại các đĩa thất bại."
 ],
 "Resize": [
  null,
  "Thay đổi kích thước"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Thay đổi kích thước phân vùng từ $0 thành $1"
 ],
 "Restrict access to the report": [
  null,
  "Hạn chế quyền truy cập vào báo cáo"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Giới hạn báo cáo trong nhóm $0. $1"
 ],
 "Return to installation": [
  null,
  "Quay trở lại cài đặt"
 ],
 "Return to storage editor": [
  null,
  "Quay trở lại trình thiết đặt bộ nhớ"
 ],
 "Review and install": [
  null,
  "Xem lại và tiến hành cài đặt"
 ],
 "Root account is enabled": [
  null,
  "Tài khoản root đã được bật"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Tài khoản root đã được bật, nhưng chưa cấu hình tài khoản người dùng nào"
 ],
 "Root password has been set.": [
  null,
  "Mật khẩu root đã được thiết lập."
 ],
 "Save": [
  null,
  "Lưu"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Quét mã QR sau bằng điện thoại của bạn hoặc truy cập:"
 ],
 "Search for a language": [
  null,
  "Tìm kiếm ngôn ngữ"
 ],
 "Search for additional software": [
  null,
  "Tìm kiếm phần mềm bổ sung"
 ],
 "Search for an environment": [
  null,
  "Tìm kiếm môi trường"
 ],
 "Search keyboard layout": [
  null,
  "Tìm kiếm bố cục bàn phím"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Bảo mật dữ liệu bằng mã hóa đĩa. Chỉ áp dụng cho các phân vùng mới"
 ],
 "Select": [
  null,
  "Chọn"
 ],
 "Select a device": [
  null,
  "Chọn môt thiết bị"
 ],
 "Select city": [
  null,
  "Chọn thành phố"
 ],
 "Select destination": [
  null,
  "Chọn đích đến"
 ],
 "Select region": [
  null,
  "Chọn khu vực"
 ],
 "Selected (top = current)": [
  null,
  "Đã chọn (trên cùng = hiện tại)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Không thể định dạng lại định dạng '$0' của thiết bị đã chọn."
 ],
 "Send us feedback on your installation": [
  null,
  "Gửi phản hồi cho chúng tôi về cài đặt của bạn"
 ],
 "Server": [
  null,
  "Máy chủ"
 ],
 "Server is not reachable": [
  null,
  "Máy chủ không thể truy cập"
 ],
 "Set custom hostname": [
  null,
  "Đặt tên máy tuỳ chỉnh"
 ],
 "Share disk with other operating systems": [
  null,
  "Chia sẻ đĩa với hệ điều hành khác"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Chia sẻ đĩa với hệ điều hành khác: $0"
 ],
 "Show AM/PM": [
  null,
  "Hiển thị AM/PM"
 ],
 "Show API key": [
  null,
  "Hiển thị khóa API"
 ],
 "Show confirmed password": [
  null,
  "Hiện mật khẩu xác nhận"
 ],
 "Show passphrase": [
  null,
  "Hiện mật khẩu"
 ],
 "Show password": [
  null,
  "Hiện mật khẩu"
 ],
 "Size": [
  null,
  "Kích thước"
 ],
 "Software installation": [
  null,
  "Cài đặt phần mềm"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Cài đặt phần mềm: Cấu hình lưu trữ hoàn tất. Phần mềm đang được cài đặt vào thiết bị của bạn."
 ],
 "Software selection": [
  null,
  "Chọn phần mềm"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Một số phân vùng bắt buộc đang bị thiếu: $0"
 ],
 "Space": [
  null,
  "Khoảng trống"
 ],
 "Stacktrace": [
  null,
  "Dòng theo dõi"
 ],
 "Storage": [
  null,
  "Bộ nhớ"
 ],
 "Storage configuration": [
  null,
  "Thiết đặt bộ nhớ"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Cấu hình lưu trữ: Đang cấu hình lưu trữ."
 ],
 "Storage editor": [
  null,
  "Trình thiết đặt bộ nhớ"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Lưu trữ dựa trên cấu hình từ 'Chỉnh sửa lưu trữ'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Bố cục lưu trữ được xác định bởi tệp kickstart. Cách phân vùng dự kiến có thể được xem lại trong bước tóm tắt."
 ],
 "Storage plugin failed": [
  null,
  "Plugin lưu trữ thất bại"
 ],
 "Storage requirements not met": [
  null,
  "Yêu cầu lưu trữ chưa được đáp ứng"
 ],
 "Strong": [
  null,
  "Mạnh"
 ],
 "Successfully installed": [
  null,
  "Cài đặt thành công"
 ],
 "Successfully unlocked $0.": [
  null,
  "Đã mở khoá $0 thành công."
 ],
 "Suggested keyboards": [
  null,
  "Bàn phím được đề xuất"
 ],
 "Suggested languages": [
  null,
  "Ngôn ngữ được đề xuất"
 ],
 "System": [
  null,
  "Hệ thống"
 ],
 "System configuration": [
  null,
  "Thiết đặt hệ thống"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Cấu hình hệ thống: Cài đặt phần mềm hoàn tất. Hệ thống đang được cấu hình."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Quá trình cài đặt Anaconda đã bị dừng đột ngột."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Người dùng sau đây sẽ được tạo:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Việc cài đặt cần $0 dung lượng đĩa; tuy nhiên, dung lượng của các đĩa được chọn chỉ là $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Trình cài đặt không thể tiếp tục do lỗi nghiêm trọng."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Trình cài đặt không thể tiếp tục do lỗi nghiêm trọng: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "(Cụm) Mật khẩu mà bạn đã cung cấp chứa những kí tự không thuộc chuẩn ASCII. Bạn có thể sẽ không thể chuyển bố cục bàn phím để gõ nó."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Bố cục bàn phím mặc định được chọn không hỗ trợ ký tự ASCII. Vui lòng chọn một bố cục có khả năng ASCII làm mặc định."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Trình chỉnh sửa lưu trữ cho phép bạn thay đổi kích thước, xóa và tạo phân vùng. Nó có thể thiết lập LVM và nhiều thứ khác. Công cụ này là tiện ích nâng cao, không dành cho cài đặt thông thường."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Các tệp nhật ký này có thể chứa thông tin nhạy cảm như địa chỉ IP, tên người dùng hoặc các chi tiết hệ thống khác."
 ],
 "This hostname can't be submitted": [
  null,
  "Tên máy chủ này không thể được gửi"
 ],
 "This is unstable, pre-release software": [
  null,
  "Đây là phần mềm thử nghiệm và không ổn định"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Bố cục này sẽ được dùng để mở khóa hệ thống khi khởi động"
 ],
 "This may take a moment": [
  null,
  "Việc này cần chút thời gian"
 ],
 "This will take a few moments": [
  null,
  "Việc này sẽ cần một ít phút"
 ],
 "Time": [
  null,
  "Thời gian"
 ],
 "Timezone": [
  null,
  "Múi giờ"
 ],
 "Title": [
  null,
  "Tiêu đề"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Để bắt đầu sử dụng $0, khởi động lại máy."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Để tiếp tục, vui lòng chọn thiết bị để cài đặt."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Để sử dụng lựa chọn này, hãy thay đổi kích thước hoặc xoá phân vùng để làm trống ít nhất $0."
 ],
 "Type": [
  null,
  "Loại"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Không thể lên lịch xóa $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Không thể lên lịch thay đổi kích thước $0"
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "Mở khoá"
 ],
 "Unlock encrypted devices": [
  null,
  "Mở khoá thiết bị được mã hoá"
 ],
 "Use configured storage": [
  null,
  "Sử dụng lưu trữ đã cấu hình"
 ],
 "Use entire disk": [
  null,
  "Sử dụng toàn bộ ổ đĩa"
 ],
 "Use free space": [
  null,
  "Sử dụng dung lượng trống"
 ],
 "Use local account": [
  null,
  "Sử dụng tài khoản cục bộ"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Sử dụng thiết bị RAID cho phân vùng tự động"
 ],
 "User creation": [
  null,
  "Tạo tài khoản"
 ],
 "User name": [
  null,
  "Tên người dùng"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Tên người dùng chỉ được chứa: chữ cái a-z, chữ số 0-9, dấu gạch ngang $0, dấu chấm $1, dấu gạch dưới $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Tên người dùng không được là từ dành riêng"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Tên người dùng phải ngắn hơn 33 ký tự"
 ],
 "Validating...": [
  null,
  "Đang xác thực..."
 ],
 "Weak": [
  null,
  "Yếu"
 ],
 "Welcome": [
  null,
  "Chào mừng"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Chào mừng đến với Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Chào mừng. Hãy cài đặt $0 ngay bây giờ."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Khi bạn gửi báo cáo lỗi này, các tệp nhật ký sau sẽ được tải lên tự động: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Các phân vùng Windows được mã hóa BitLocker không thể thay đổi kích thước"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Bạn có thể giải phóng đủ dung lượng tại đây và để trình cài đặt xử lý phần còn lại, hoặc tự thiết lập các phân vùng."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Bạn có thể tạo khóa API cho tài khoản Bugzilla của mình $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Bạn phải bật tài khoản root hoặc tạo tài khoản người dùng cục bộ để tiếp tục."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Bạn phải kết nối mạng để bật ngày và giờ tự động."
 ],
 "Your progress will not be saved.": [
  null,
  "Tiến trình của bạn sẽ không được lưu."
 ],
 "completed step": [
  null,
  "buớc đã hoàn thành"
 ],
 "current step": [
  null,
  "bước hiện tại"
 ],
 "delete": [
  null,
  "xóa"
 ],
 "edit": [
  null,
  "chỉnh sửa"
 ],
 "encrypt": [
  null,
  "mã hóa"
 ],
 "encrypted": [
  null,
  "đã mã hóa"
 ],
 "extended partition": [
  null,
  "phân vùng mở rộng"
 ],
 "format as $0": [
  null,
  "Định dạng là $0"
 ],
 "here": [
  null,
  "tại đây"
 ],
 "mount": [
  null,
  "gắn kết"
 ],
 "pending step": [
  null,
  "buớc đang chờ"
 ],
 "report the issue manually": [
  null,
  "báo cáo sự cố thủ công"
 ],
 "resized from $0": [
  null,
  "đã thay đổi kích thước từ $0"
 ],
 "shrink": [
  null,
  "thu nhỏ"
 ],
 "shrink to $0": [
  null,
  "Thu nhỏ thành $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "hoàn tác"
 ]
});
