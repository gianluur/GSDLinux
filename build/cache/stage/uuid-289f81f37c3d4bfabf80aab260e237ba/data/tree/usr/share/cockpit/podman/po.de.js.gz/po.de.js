cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "$0 löschen?"
 ],
 "Force delete": [
  null,
  "Löschen erzwingen"
 ],
 "Cancel": [
  null,
  "Abbruch"
 ],
 "Must be a valid IP address": [
  null,
  "Muss eine gültige IP-Adresse sein"
 ],
 "1 to 65535": [
  null,
  "1 bis 65535"
 ],
 "Container port must not be empty": [
  null,
  "Containerport darf nicht leer sein"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address help": [
  null,
  "Hilfe zur IP-Adresse"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Wird die Host-IP auf 0.0.0.0 oder gar nicht gesetzt, so wird der Port an alle auf dem Host vorhandenen IPs gebunden."
 ],
 "Host port": [
  null,
  "Host-Port"
 ],
 "Host port help": [
  null,
  "Hilfe zum Host-Port"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Wenn der Host-Port nicht gesetzt ist, wird dem Container-Port ein zufälliger Port auf dem Host zugewiesen."
 ],
 "Container port": [
  null,
  "Container-Port"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Image name is required": [
  null,
  "Image-Name ist erforderlich"
 ],
 "Image name is not unique": [
  null,
  "Image-Name ist nicht eindeutig"
 ],
 "Failed to commit container $0": [
  null,
  "Konnte Container $0 nicht committen"
 ],
 "New image name": [
  null,
  "Neuer Image-Name"
 ],
 "Tag": [
  null,
  "Etikett"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Beispiel, Ihr Name <yourname@example.com>"
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "Options": [
  null,
  "Optionen"
 ],
 "Pause container when creating image": [
  null,
  "Container bei der Erstellung des Images pausieren"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-Format ist hilfreich, wenn das Image mit Docker oder Moby Engine geteilt wird"
 ],
 "Use legacy Docker format": [
  null,
  "Veraltetes Docker-Format verwenden"
 ],
 "Commit container": [
  null,
  "Container übergeben"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Ein neues Image auf der Grundlage des aktuellen Zustands des Containers $0 erstellen."
 ],
 "Commit": [
  null,
  "Committen"
 ],
 "Force commit": [
  null,
  "Übergabe erzwingen"
 ],
 "Failed to force remove container $0": [
  null,
  "Konnte Container $0 nicht neu entfernen"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Das Löschen eines laufenden Containers führt dazu, dass alle darin enthaltenen Daten gelöscht werden."
 ],
 "Failed to stop container $0": [
  null,
  "Konnte Container $0 nicht stoppen"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Fehler beim Stoppen von Quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Konnte Quadlet $0 nicht starten"
 ],
 "Failed to start container $0": [
  null,
  "Konnte Container $0 nicht starten"
 ],
 "Failed to resume container $0": [
  null,
  "Konnte Container $0 nicht wieder starten"
 ],
 "Failed to pause container $0": [
  null,
  "Konnte Container $0 nicht pausieren"
 ],
 "Failed to restart container $0": [
  null,
  "Konnte Container $0 nicht neu starten"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Konnte Quadlet $0 nicht neu starten"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Restart": [
  null,
  "Neustart"
 ],
 "Force stop": [
  null,
  "Stoppen erzwingen"
 ],
 "Force restart": [
  null,
  "Neustart erzwingen"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Resume": [
  null,
  "Fotfahren"
 ],
 "Checkpoint": [
  null,
  "Kontrollpunkt"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Restore": [
  null,
  "Wiederherstellen"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Healthy": [
  null,
  "Gesund"
 ],
 "Unhealthy": [
  null,
  "Ungesund"
 ],
 "Checking health": [
  null,
  "Überprüfung der Gesundheit"
 ],
 "Prune unused containers": [
  null,
  "Nicht benötigte Container löschen"
 ],
 "Terminal not available": [
  null,
  "Terminal nicht verfügbar"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Dieser Browser unterstützt WebGL2 nicht."
 ],
 "View $0 logs": [
  null,
  "$0 Logs ansehen"
 ],
 "not available": [
  null,
  "nicht verfügbar"
 ],
 "n/a": [
  null,
  "n.v."
 ],
 "$0% of $1 limit": [
  null,
  "$0% von $1 Limit"
 ],
 "service": [
  null,
  "Dienst"
 ],
 "system": [
  null,
  "System"
 ],
 "user:": [
  null,
  "Benutzer:"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Integration": [
  null,
  "Integration"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Console": [
  null,
  "Konsole"
 ],
 "Health check": [
  null,
  "Gesundheitsprüfung"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Click to see published ports": [
  null,
  "Klicken um veröffentlichte Ports zu sehen"
 ],
 "ports": [
  null,
  "Ports"
 ],
 "Click to see volumes": [
  null,
  "Klicken um Volumen zu sehen"
 ],
 "volumes": [
  null,
  "Volumen"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Owner": [
  null,
  "Eigentümer"
 ],
 "State": [
  null,
  "Zustand"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "No containers": [
  null,
  "Keine Container"
 ],
 "No containers in this pod": [
  null,
  "Keine Container in diesem Pod"
 ],
 "Loading...": [
  null,
  "Wird geladen ..."
 ],
 "No containers that match the current filter": [
  null,
  "Aktueller Filter passt auf keinen Container"
 ],
 "No running containers": [
  null,
  "Keine laufenden Container"
 ],
 "Show": [
  null,
  "Anzeigen"
 ],
 "All": [
  null,
  "Alle"
 ],
 "Only running": [
  null,
  "Nur laufenlassen"
 ],
 "Create pod": [
  null,
  "Pod erstellen"
 ],
 "Create container": [
  null,
  "Container erstellen"
 ],
 "Containers": [
  null,
  "Container"
 ],
 "Create container in pod": [
  null,
  "Container in Pod erstellen"
 ],
 "pod": [
  null,
  "Pod"
 ],
 "Failed to restore container $0": [
  null,
  "Konnte Container $0 nicht wiederherstellen"
 ],
 "Restore container $0": [
  null,
  "Container $0 wiederherstellen"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Alle temporären Kontrollpunktdateien behalten"
 ],
 "Restore with established TCP connections": [
  null,
  "Wiederherstellung mit bestehenden TCP-Verbindungen"
 ],
 "Ignore IP address if set statically": [
  null,
  "IP-Adresse ignorieren, wenn statisch festgelegt"
 ],
 "Ignore MAC address if set statically": [
  null,
  "MAC-Adresse ignorieren, wenn statisch festgelegt"
 ],
 "Pod failed to be created": [
  null,
  "Pod konnte nicht erstellt werden"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Ungültige Zeichen. Der Name darf nur Buchstaben, Zahlen und bestimmte Satzzeichen (_ . -) enthalten."
 ],
 "Name": [
  null,
  "Name"
 ],
 "Pod name": [
  null,
  "Pod-Name"
 ],
 "System": [
  null,
  "System"
 ],
 "User:": [
  null,
  "Benutzer:"
 ],
 "No ports exposed": [
  null,
  "Keine offenen Ports"
 ],
 "Port mapping": [
  null,
  "Portzuordnung"
 ],
 "Add port mapping": [
  null,
  "Port-Zuordnung hinzufügen"
 ],
 "No volumes specified": [
  null,
  "Keine Volumen angegeben"
 ],
 "Volumes": [
  null,
  "Datenträger"
 ],
 "Add volume": [
  null,
  "Volumen hinzufügen"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Type to filter…": [
  null,
  "Tippen zum filtern…"
 ],
 "Container path must not be empty": [
  null,
  "Containerpfad darf nicht leer sein"
 ],
 "Host path": [
  null,
  "Host-Pfad"
 ],
 "Container path": [
  null,
  "Container-Pfad"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Writable": [
  null,
  "Beschreibbar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Keine Bezeichnung"
 ],
 "Shared": [
  null,
  "Freigegeben"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Read-write access": [
  null,
  "Lese-/Schreibzugriff"
 ],
 "Read-only access": [
  null,
  "Nur-Lese-Zugriff"
 ],
 "Show less": [
  null,
  "Weniger anzeigen"
 ],
 "Show more": [
  null,
  "Mehr anzeigen"
 ],
 "Loading details...": [
  null,
  "Details werden geladen ..."
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Environment variables": [
  null,
  "Umgebungsvariablen"
 ],
 "Failed to download image $0:$1": [
  null,
  "Konnte Image $0 nicht herunterladen: $1"
 ],
 "Error message": [
  null,
  "Fehlermeldung"
 ],
 "unused": [
  null,
  "ungenutzt"
 ],
 "$0 container": [
  null,
  "$0 Container",
  "$0 Container"
 ],
 "History": [
  null,
  "Verlauf"
 ],
 "Image": [
  null,
  "Image"
 ],
 "Created": [
  null,
  "Erstellt"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Speicherplatz"
 ],
 "Used by": [
  null,
  "Benutzt von"
 ],
 "No images": [
  null,
  "Keine Images"
 ],
 "No images that match the current filter": [
  null,
  "Aktueller Filter passt auf kein Image"
 ],
 "Hide intermediate images": [
  null,
  "Intermediate Images verstecken"
 ],
 "Show intermediate images": [
  null,
  "Zwischen-Images anzeigen"
 ],
 "Images": [
  null,
  "Images"
 ],
 "$0 image total, $1": [
  null,
  "$0 Image insgesamt, $1",
  "$0 Images insgesamt, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 ungenutztes Image, $1",
  "$0 ungenutzte Images, $1"
 ],
 "Hide images": [
  null,
  "Images ausblenden"
 ],
 "Show images": [
  null,
  "Images anzeigen"
 ],
 "Pulling": [
  null,
  "Herunterladen"
 ],
 "Download new image": [
  null,
  "Neues Image herunterladen"
 ],
 "Pull all images": [
  null,
  "Alle Images pullen"
 ],
 "Prune unused images": [
  null,
  "Nicht benötigte Images löschen"
 ],
 "Pull": [
  null,
  "Ziehen"
 ],
 "Up since:": [
  null,
  "Läuft seit:"
 ],
 "Exited": [
  null,
  "Beendet"
 ],
 "systemd service": [
  null,
  "systemd-Dienst"
 ],
 "View $0": [
  null,
  "$0 ansehen"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "MAC address": [
  null,
  "MAC-Adresse"
 ],
 "Latest checkpoint": [
  null,
  "LetzterKontrollpunkt"
 ],
 "No containers are using this image": [
  null,
  "Keine Container benutzen dieses Image"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "Loading logs...": [
  null,
  "Protokolle werden geladen ..."
 ],
 "Delete unused system images:": [
  null,
  "Nicht verwendete System-Images löschen:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Nicht verwendete Images von Benutzer $0 löschen:"
 ],
 "Failed to prune unused images": [
  null,
  "Löschen nicht gebrauchter Images fehlgeschlagen"
 ],
 "Pruning images": [
  null,
  "Bereinige Images"
 ],
 "Prune": [
  null,
  "Reduzieren"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Überprüfung von Container $0 fehlgeschlagen"
 ],
 "Checkpoint container $0": [
  null,
  "Kontrollpunkt für Container $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Nach dem Schreiben des Kontrollpunkts auf die Festplatte weiterlaufen lassen"
 ],
 "Support preserving established TCP connections": [
  null,
  "Unterstützung der Aufrechterhaltung bestehender TCP-Verbindungen"
 ],
 "Failed to search for new images": [
  null,
  "Konnte nicht nach neuen Images suchen"
 ],
 "Failed to search for images: $0": [
  null,
  "Konnte nicht nach Images suchen: $0"
 ],
 "Failed to search for images.": [
  null,
  "Konnte nicht nach Images suchen."
 ],
 "Search for an image": [
  null,
  "Nach einem Image suchen"
 ],
 "Search for": [
  null,
  "Suchen nach"
 ],
 "Search by name or description": [
  null,
  "Nach Name oder Beschreibung suchen"
 ],
 "in": [
  null,
  "in"
 ],
 "All registries": [
  null,
  "Alle Registries"
 ],
 "Searching...": [
  null,
  "Wird gesucht ..."
 ],
 "No images found": [
  null,
  "Keine Images gefunden"
 ],
 "Start typing to look for images.": [
  null,
  "Zum Suchen nach Abbildern mit dem Tippen beginnen."
 ],
 "No results for $0": [
  null,
  "Keine Ergebnisse für $0"
 ],
 "Retry another term.": [
  null,
  "Versuchen Sie einen anderen Begriff."
 ],
 "Download": [
  null,
  "Herunterladen"
 ],
 "No action": [
  null,
  "Keine Aktion"
 ],
 "Container failed to be started": [
  null,
  "Container konnte nicht erstellt werden"
 ],
 "Failed to clean up container": [
  null,
  "Fehler bei der Bereinigung des Containers"
 ],
 "Container failed to be created": [
  null,
  "Container konnte nicht erstellt werden"
 ],
 "downloading": [
  null,
  "wird heruntergeladen"
 ],
 "Failed to run container $0": [
  null,
  "Konnte Container $0 nicht starten"
 ],
 "Failed to create container $0": [
  null,
  "Fehler bei der Erstellung des Containers $0"
 ],
 "Failed to pull image $0": [
  null,
  "Image $0 konnte nicht gepullt werden"
 ],
 "Local images": [
  null,
  "Lokale Images"
 ],
 "Name already in use": [
  null,
  "Name bereits in Gebrauch"
 ],
 "Search by registry": [
  null,
  "Nach Registry suchen"
 ],
 "Local": [
  null,
  "Lokal"
 ],
 "Container name": [
  null,
  "Container-Name"
 ],
 "Owner help": [
  null,
  "Eigentümer-Hilfe"
 ],
 "Ideal for running services": [
  null,
  "Ideal für Dienste"
 ],
 "Resource limits can be set": [
  null,
  "Ressourcen-Grenzen können gesetzt werden"
 ],
 "Checkpoint and restore support": [
  null,
  "Unterstützung von Kontrollpunkten und Wiederherstellung"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Ports unter 1024 können zugeordnet werden"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "Ideal for development": [
  null,
  "Ideal zur Entwicklung"
 ],
 "Restricted by user account permissions": [
  null,
  "Eingeschränkt durch Benutzerkonto-Privilegien"
 ],
 "Image selection help": [
  null,
  "Image-Auswahl-Hilfe"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "Host[:Port]/[Benutzer]/Container[:Tag]"
 ],
 "Example: $0": [
  null,
  "Beispiel: $0"
 ],
 "Searching: $0": [
  null,
  "Wird gesucht: $0"
 ],
 "Search string or container location": [
  null,
  "Suchbegriff oder Containerort"
 ],
 "Pull latest image": [
  null,
  "Neuestes Image pullen"
 ],
 "Entrypoint": [
  null,
  "Einsprungspunkt"
 ],
 "With terminal": [
  null,
  "Mit Terminal"
 ],
 "Memory limit": [
  null,
  "Speicher-Limit"
 ],
 "Decrease memory": [
  null,
  "Speicher verringern"
 ],
 "Increase memory": [
  null,
  "Speicher erhöhen"
 ],
 "Memory unit": [
  null,
  "Speichereinheit"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU-Shares"
 ],
 "CPU Shares help": [
  null,
  "CPU Shares Hilfe"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU Shares legt die Priorität laufender Container fest. Standardwert ist 1024. Ein höherer Wert priorisiert den Container. Ein niedrigerer Wert senkt dessen Priorität."
 ],
 "Decrease CPU shares": [
  null,
  "CPU-Anteile verringern"
 ],
 "Increase CPU shares": [
  null,
  "CPU-Anteile erhöhen"
 ],
 "Restart policy": [
  null,
  "Neustartrichtlinie"
 ],
 "Restart policy help": [
  null,
  "Neustartrichtlinien-Hilfe"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Neustart-Richtlinie, die beim Beenden von Containern befolgt werden soll. Die Verwendung von linger für das automatische Starten von Containern kann unter bestimmten Umständen nicht funktionieren, z. B. wenn ecryptfs, systemd-homed, NFS oder 2FA für ein Benutzerkonto verwendet werden."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Neustart-Richtlinie, die beim Beenden von Containern befolgt werden soll."
 ],
 "No": [
  null,
  "Nein"
 ],
 "On failure": [
  null,
  "Bei einem Ausfall"
 ],
 "Always": [
  null,
  "Immer"
 ],
 "Maximum retries": [
  null,
  "Maximale Versuche"
 ],
 "Decrease maximum retries": [
  null,
  "Maximale Wiederholungsversuche verringern"
 ],
 "Increase maximum retries": [
  null,
  "Maximale Wiederholungsversuche erhöhen"
 ],
 "No environment variables specified": [
  null,
  "Keine Umgebungsvariablen angegeben"
 ],
 "Add variable": [
  null,
  "Variable hinzufügen"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Fügen Sie eine oder mehrere Zeilen mit key=value Paaren in irgendein Feld ein für multiplen Import"
 ],
 "Interval": [
  null,
  "Intervall"
 ],
 "Health check interval help": [
  null,
  "Hilfe zum Gesundheitsprüfungsintervall"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervall, in dem die Gesundheitsprüfung durchgeführt wird."
 ],
 "Decrease interval": [
  null,
  "Intervall verringern"
 ],
 "Increase interval": [
  null,
  "Intervall erhöhen"
 ],
 "seconds": [
  null,
  "Sekunden"
 ],
 "Timeout": [
  null,
  "Zeitüberschreitung"
 ],
 "Health check timeout help": [
  null,
  "Hilfe zum Zeitlimit der Gesundheitsprüfung"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Die maximal zulässige Zeit für den Abschluss der Gesundheitsprüfung, bevor ein Intervall als fehlgeschlagen gilt."
 ],
 "Decrease timeout": [
  null,
  "Zeitüberschreitung verringern"
 ],
 "Increase timeout": [
  null,
  "Zeitüberschreitung erhöhen"
 ],
 "Start period": [
  null,
  "Startzeitraum"
 ],
 "Health check start period help": [
  null,
  "Hilfe zur Periode der Gesundheitsprüfung"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Die zum Urladen eines Containers benötigte Initialisierungszeit."
 ],
 "Decrease start period": [
  null,
  "Startzeitraum verringern"
 ],
 "Increase start period": [
  null,
  "Startzeitraum erhöhen"
 ],
 "Retries": [
  null,
  "Wiederholungsversuche"
 ],
 "Health check retries help": [
  null,
  "Hilfe zur Wiederholung der Gesundheitsprüfung"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Die Anzahl der zulässigen Wiederholungsversuche, bevor eine Gesundheitsprüfung als ungesund gilt."
 ],
 "Decrease retries": [
  null,
  "Wiederholungsversuche verringern"
 ],
 "Increase retries": [
  null,
  "Wiederholungsversuche erhöhen"
 ],
 "When unhealthy": [
  null,
  "Wenn ungesund"
 ],
 "Health failure check action help": [
  null,
  "Hilfe zur Gesundheitsprüfungs-Aktion"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Zu ergreifende Maßnahmen, wenn der Container in einen ungesunden Zustand übergeht."
 ],
 "Create container in $0": [
  null,
  "Container in $0 erstellen"
 ],
 "Create and run": [
  null,
  "Erstellen und ausführen"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Version": [
  null,
  "Version"
 ],
 "Links": [
  null,
  "Links"
 ],
 "Documentation": [
  null,
  "Dokumentation"
 ],
 "Tags": [
  null,
  "Etiketten"
 ],
 "Created by": [
  null,
  "Erstellt von"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Comments": [
  null,
  "Kommentare"
 ],
 "Unable to load image history": [
  null,
  "Image-Verlauf kann nicht geladen werden"
 ],
 "Key must not be empty": [
  null,
  "Schlüssel darf nicht leer sein"
 ],
 "Key must not begin with a digit": [
  null,
  "Schlüssel darf nicht mit einer Ziffer beginnen"
 ],
 "Key contains invalid characters": [
  null,
  "Schlüssel enthält ungültige Zeichen"
 ],
 "Key": [
  null,
  "Schlüssel"
 ],
 "Value": [
  null,
  "Wert"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "Podman service failed": [
  null,
  "Podman-Dienst fehlgeschlagen"
 ],
 "Troubleshoot": [
  null,
  "Fehler suchen"
 ],
 "Failed to force remove image $0": [
  null,
  "Fehler bei der erzwungenen Entfernung des Image $0"
 ],
 "intermediate image": [
  null,
  "Zwischen-Image"
 ],
 "Failed to remove image $0": [
  null,
  "Fehler bei der Entfernung von Image $0"
 ],
 "intermediate": [
  null,
  "intermediate"
 ],
 "Delete $0 image?": [
  null,
  "Image $0 löschen?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Mehrere Tags für dieses Image vorhanden. Getagte Images zum Löschen auswählen."
 ],
 "Delete image": [
  null,
  "Image löschen"
 ],
 "Delete tagged images": [
  null,
  "Markierte Image löschen"
 ],
 "Container is not running": [
  null,
  "Container läuft nicht"
 ],
 "Error occurred while connecting console": [
  null,
  "Beim Verbinden der Konsole ist ein Fehler aufgetreten"
 ],
 "Force delete pod $0?": [
  null,
  "Löschen von Pod $0 erzwingen?"
 ],
 "Delete pod $0?": [
  null,
  "Pod $0 löschen?"
 ],
 "An error occurred": [
  null,
  "Ein Fehler ist aufgetreten"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Leerer Pod $0 wird endgültig entfernt."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Löschen des Pods wird die folgenden Container entfernen:"
 ],
 "Failed to start pod $0": [
  null,
  "Konnte Pod $0 nicht starten"
 ],
 "Failed to stop pod $0": [
  null,
  "Fehler beim Stoppen von Pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Konnte Pod $0 nicht neu starten"
 ],
 "Failed to resume pod $0": [
  null,
  "Konnte Pod $0 nicht wieder starten"
 ],
 "Failed to pause pod $0": [
  null,
  "Konnte Pod $0 nicht pausieren"
 ],
 "Failed to prune unused containers": [
  null,
  "Löschen nicht gebrauchter Container fehlgeschlagen"
 ],
 "Removes selected non-running containers": [
  null,
  "Entfernt selektierte nicht-laufende Container"
 ],
 "Pruning containers": [
  null,
  "Räume Container auf"
 ],
 "Container name is required.": [
  null,
  "Containername ist erforderlich."
 ],
 "Failed to rename container $0": [
  null,
  "Fehler beim Umbenennen des Containers $0"
 ],
 "New container name": [
  null,
  "Neuer Containername"
 ],
 "Rename container $0": [
  null,
  "Container $0 umbenennen"
 ],
 "Paused": [
  null,
  "Pausiert"
 ],
 "Stopped": [
  null,
  "Angehalten"
 ],
 "Removing": [
  null,
  "Wird entfernt"
 ],
 "Configured": [
  null,
  "Konfiguriert"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "$0 second": [
  null,
  "$0 Sekunde",
  "$0 Sekunden"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Failing streak": [
  null,
  "Misserfolgssträhne"
 ],
 "Failed to run health check on container $0": [
  null,
  "Gesundheitsprüfung von Container $0 fehlgeschlagen"
 ],
 "Run health check": [
  null,
  "Gesundheitsprüfung durchführen"
 ],
 "Last 5 runs": [
  null,
  "Letzte 5 Durchläufe"
 ],
 "Started at": [
  null,
  "Gestartet am"
 ],
 "Passed health run": [
  null,
  "Bestandener Gesundheitstest"
 ],
 "Failed health run": [
  null,
  "Gesundheitsprüfung fehlgeschlagen"
 ],
 "Failed to remove container $0": [
  null,
  "Konnte Container $0 nicht neu entfernen"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Beim Löschen des Containers werden alle Daten darin verloren gehen."
 ]
});
