cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "si",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
