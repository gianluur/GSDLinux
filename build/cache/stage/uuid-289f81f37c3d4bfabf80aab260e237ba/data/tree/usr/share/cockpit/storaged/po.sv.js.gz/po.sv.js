cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Remove": [
  null,
  "Avlägsna"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "Set": [
  null,
  "Sätt"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "Permission denied": [
  null,
  "Åtkomst nekas"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Inga metoder för att få administrativ åtkomst finns tillgängliga (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Method": [
  null,
  "Metod"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Acceptable password": [
  null,
  "Godtagbart lösenord"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder ska slutföras"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "Downloading $0": [
  null,
  "Laddar ner $0"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterade felkod $0"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Error during initialization": [
  null,
  "Fel under initialisering"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Home": [
  null,
  "Hem"
 ],
 "Downloads": [
  null,
  "Hämtningar"
 ],
 "Not a directory": [
  null,
  "Inte en katalog"
 ],
 "All files": [
  null,
  "Alla filer"
 ],
 "Recent": [
  null,
  "Senaste"
 ],
 "No recent directories": [
  null,
  "Inga senaste kataloger"
 ],
 "No recent files": [
  null,
  "Inga senaste filer"
 ],
 "Type to filter": [
  null,
  "Skriv för att filtrera"
 ],
 "File chooser actions": [
  null,
  "Filväljare åtgärder"
 ],
 "Open in file browser": [
  null,
  "Öppna i filhanterare"
 ],
 "Hide hidden files": [
  null,
  "Dölj dolda filer"
 ],
 "Show hidden files": [
  null,
  "Visa dolda filer"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Clear filters": [
  null,
  "Rensa filter"
 ],
 "Directory is empty": [
  null,
  "Katalog är tom"
 ],
 "Directory has no sub-directories": [
  null,
  "Katalogen har inga underkataloger"
 ],
 "This directory contains only hidden files": [
  null,
  "Den här katalogen innehåller endast dolda filer"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "Folder": [
  null,
  "Mapp"
 ],
 "File": [
  null,
  "Arkiv"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "View logs": [
  null,
  "Visa loggar"
 ],
 "Dismiss": [
  null,
  "Avfärda"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "none": [
  null,
  "ingen"
 ],
 "Not found": [
  null,
  "Finns inte"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "Not running": [
  null,
  "Kör inte"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "User": [
  null,
  "Användare"
 ],
 "Vendor": [
  null,
  "Leverantör"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Confirm deletion of $0": [
  null,
  "Bekräfta raderingen av $0"
 ],
 "Username": [
  null,
  "Användarnamn"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Started": [
  null,
  "Startad"
 ],
 "Delete group": [
  null,
  "Ta bort grupp"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Use $0": [
  null,
  "Använd $0"
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Disconnect": [
  null,
  "Koppla ifrån"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk saknas",
  "$0 diskar saknas"
 ],
 "Location": [
  null,
  "Plats"
 ],
 "Compression": [
  null,
  "Komprimering"
 ],
 "Storage logs": [
  null,
  "Lagringsloggar"
 ],
 "Name cannot be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Namnet får inte vara längre än 127 tecken."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Namnet får inte innehålla tecknet ”$0”."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Namnet får inte innehålla blanktecken."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Namnet får inte vara längre än $0 tecken"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Namnet får inte vara längre än $0 byte"
 ],
 "$name (from $host)": [
  null,
  "$name (från $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool för tunna logiska volymer"
 ],
 "Thin logical volume": [
  null,
  "Tunn logisk volym"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisk volym (ögonblicksbild)"
 ],
 "Logical volume": [
  null,
  "Logisk volym"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID-enhet $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 Volymgrupp $0"
 ],
 "VDO device $0": [
  null,
  "VDO-enhet $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Krypterad logisk volym av $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Krypterad partition av $0"
 ],
 "Logical volume of $0": [
  null,
  "Logisk volym av $0"
 ],
 "Partition of $0": [
  null,
  "Partition av $0"
 ],
 "Encrypted $0": [
  null,
  "Krypterad $0"
 ],
 "unpartitioned space on $0": [
  null,
  "opartitionerat utrymmer på $0"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "mount": [
  null,
  "montering"
 ],
 "remove from btrfs volume": [
  null,
  "ta bort från btrfs volym"
 ],
 "stop": [
  null,
  "stoppa"
 ],
 "remove from MDRAID": [
  null,
  "tar bort från MDRAID"
 ],
 "remove from LVM2": [
  null,
  "ta bort från LVM2"
 ],
 "btrfs device": [
  null,
  "btrfs enhet"
 ],
 "btrfs volume": [
  null,
  "btrfs volym"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Namnet får inte vara längre än 255 tecken."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Namnet får inte innehålla tecknet '/'."
 ],
 "Create and mount": [
  null,
  "Skapa och montera"
 ],
 "Create only": [
  null,
  "Skapa endast"
 ],
 "Create subvolume": [
  null,
  "Skapa undervolym"
 ],
 "Mount Point": [
  null,
  "Monteringspunkt"
 ],
 "delete": [
  null,
  "ta bort"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Vill du permanent ta bort undervolym $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Om du raderar raderas all data på denna undervolym och alla dens barn."
 ],
 "Edit mount point": [
  null,
  "Redigera monteringspunkt"
 ],
 "Unmount": [
  null,
  "Avmontera"
 ],
 "Mount": [
  null,
  "Montering"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Åtminstone en undervolym måste monteras"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Den sista monterade undervolymen kan inte tas bort"
 ],
 "btrfs subvolume": [
  null,
  "btrfs undervolym"
 ],
 "Snapshot origin": [
  null,
  "Ögonblicksbildens ursprung"
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "No subvolumes": [
  null,
  "Inga undervolymer"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs undervolymer"
 ],
 "Snapshots": [
  null,
  "Ögonblicksbilder"
 ],
 "No snapshots found": [
  null,
  "Inga ögonblicksbilder hittades"
 ],
 "snapshot": [
  null,
  "ögonblicksbild"
 ],
 "$0 is in use": [
  null,
  "$0 används"
 ],
 "Permanently delete $0?": [
  null,
  "Permanent ta bort $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Att ta bort raderar all data på en btrfs-volym."
 ],
 "Delete filesystem": [
  null,
  "Ta bort filsystem"
 ],
 "Change label": [
  null,
  "Ändra etikett"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Filsystem är monterade skrivskyddade"
 ],
 "Label": [
  null,
  "Etikett"
 ],
 "Capacity": [
  null,
  "Kapacitet"
 ],
 "btrfs devices": [
  null,
  "btrfs enheter"
 ],
 "No devices found": [
  null,
  "Inga enheter hittades"
 ],
 "btrfs filesystem": [
  null,
  "btrfs filsystem"
 ],
 "Successful": [
  null,
  "Lyckades"
 ],
 "Aborted": [
  null,
  "Avbruten"
 ],
 "In progress": [
  null,
  "Pågående"
 ],
 "Interrupted": [
  null,
  "Avbrott"
 ],
 "Did not complete": [
  null,
  "Slutfördes inte"
 ],
 "Failed (Unknown)": [
  null,
  "Misslyckades (Okänt)"
 ],
 "Failed (Electrical)": [
  null,
  "Misslyckades (elektriskt)"
 ],
 "Failed (Servo)": [
  null,
  "Misslyckades (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Misslyckades (Läs)"
 ],
 "Failed (Damaged)": [
  null,
  "Misslyckades (Skadad)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Avbröts av en återställning av styrenhetsnivå"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Avbröts på grund av att ett namnområde har tagits bort från namnområdets inventering"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Avbröts på grund av bearbetningen av ett Format NVM-kommando"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Ett allvarligt fel inträffade under självtestet"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Slutfört med ett segment som misslyckades och segmentet som misslyckades är inte känt"
 ],
 "Completed with one or more failed segments": [
  null,
  "Slutfört med ett eller flera misslyckade segment"
 ],
 "Aborted for unknown reason": [
  null,
  "Avbröts av okänd anledning"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Avbröts på grund av en desinficeringsoperation"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Reservkapaciteten är under tröskeln"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatur utanför rekommenderade gränsvärden"
 ],
 "Degraded": [
  null,
  "Degraderad"
 ],
 "All media is in read-only mode": [
  null,
  "Alla medier är i skrivskyddat läge"
 ],
 "Volatile memory backup failed": [
  null,
  "Säkerhetskopiering av flyktigt minne misslyckades"
 ],
 "Persistent memory has become read-only": [
  null,
  "Det bestående minnet har blivit skrivskyddat"
 ],
 "Run short test": [
  null,
  "Kör kort test"
 ],
 "Run extended test": [
  null,
  "Kör förlängt test"
 ],
 "Abort test": [
  null,
  "Avbryt test"
 ],
 "Disk is failing": [
  null,
  "Disken är på väg att gå sönder"
 ],
 "Disk is OK": [
  null,
  "Disken är OK"
 ],
 "Assessment": [
  null,
  "Bedömning"
 ],
 "Power on hours": [
  null,
  "Ström på timmar"
 ],
 "$0 hours": [
  null,
  "$0 timmar"
 ],
 "Self-test status": [
  null,
  "Självtest status"
 ],
 "Number of bad sectors": [
  null,
  "Nummer av dåliga sektorer"
 ],
 "Attributes failing": [
  null,
  "Attribut misslyckas"
 ],
 "Media drive": [
  null,
  "Media enhet"
 ],
 "Solid State Drive": [
  null,
  "SSD-enhet"
 ],
 "Hard Disk Drive": [
  null,
  "Hårddiskenhet"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI-disk"
 ],
 "Drive": [
  null,
  "Enhet"
 ],
 "Device health (SMART)": [
  null,
  "Enhetshälsa (SMART)"
 ],
 "Firmware version": [
  null,
  "Version på fastprogramvara"
 ],
 "Serial number": [
  null,
  "Serienummer"
 ],
 "World wide name": [
  null,
  "Världsomfattande namn"
 ],
 "No media inserted": [
  null,
  "Inget medium isatt"
 ],
 "Device file": [
  null,
  "Enhetsfil"
 ],
 "Multipathed devices": [
  null,
  "Flervägsenheter"
 ],
 "Free space": [
  null,
  "Ledigt utrymme"
 ],
 "Create partition": [
  null,
  "Skapa en partition"
 ],
 "Extended partition": [
  null,
  "Utökad partition"
 ],
 "$0 partitions": [
  null,
  "$0 partitioner"
 ],
 "Partitions": [
  null,
  "Partitioner"
 ],
 "No partitions found": [
  null,
  "Inga partitioner hittades"
 ],
 "Unexpected partitions": [
  null,
  "Oväntade partitioner"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Partitioner stöds inte på den här blockenheten. Om den används som en disk för en virtuell maskin måste partitionerna hanteras av operativsystemet inuti den virtuella maskinen."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Att ta bort en partition kommer att ta bort all data i den."
 ],
 "No free space after this partition": [
  null,
  "Inget ledigt utrymme efter denna partition"
 ],
 "EFI system partition": [
  null,
  "EFI-systempartition"
 ],
 "BIOS boot partition": [
  null,
  "BIOS uppstartspartition"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Shrink": [
  null,
  "Krymp"
 ],
 "Grow": [
  null,
  "Utöka"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP uppstartspartition"
 ],
 "Linux swap space": [
  null,
  "Linux växlingsutrymme"
 ],
 "Linux filesystem data": [
  null,
  "Linux filsystem data"
 ],
 "Logical Volume Manager partition": [
  null,
  "Logisk volymhanterare-partition"
 ],
 "Custom": [
  null,
  "Anpassad"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ måste innehålla exakt två hexadecimala tecken (0 till 9, A till F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ kan bara innehålla tecknen 0 till 9, A till F och \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ måste ha formatet NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Ställ in partitionstyp till $0"
 ],
 "Custom type": [
  null,
  "Anpassad typ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Att ändra partitionstyper kan förhindra att systemet startar upp."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Denna partition används inte helt av innehållet."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Partitionsstorlek är $0. Innehållsstorlek är $1."
 ],
 "Shrink partition": [
  null,
  "Krymp partition"
 ],
 "Grow content": [
  null,
  "Utöka innehållet"
 ],
 "initialize": [
  null,
  "initierar"
 ],
 "Initialize disk $0": [
  null,
  "Initierar disk $0"
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel med alla system och enheter (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel med moderna system och hårddiskar > 2 TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Ingen partitionering"
 ],
 "Overwrite": [
  null,
  "Skriv över"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Skriv över befintlig data med nollor (långsammare)"
 ],
 "Initialize": [
  null,
  "Initierar"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initiering raderar all data på en disk."
 ],
 "Device is read-only": [
  null,
  "Enheten är skrivskyddad"
 ],
 "Create partition table": [
  null,
  "Skapa partitionstabell"
 ],
 "Size must be a number": [
  null,
  "Storlek måste vara ett nummer"
 ],
 "Size cannot be zero": [
  null,
  "Storleken kan inte vara noll"
 ],
 "Size cannot be negative": [
  null,
  "Storleken kan inte vara negativ"
 ],
 "Size is too large": [
  null,
  "Storleken är för stor"
 ],
 "Size must be at least $0": [
  null,
  "Storleken måste vara åtminstone $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysisk volym på LVM2 volymgrupp"
 ],
 "member of MDRAID device": [
  null,
  "medlem i MDRAID-enhet"
 ],
 "backing device for VDO device": [
  null,
  "bakomliggande enhet för VDO-enheten"
 ],
 "member of Stratis pool": [
  null,
  "medlem i Stratis pool"
 ],
 "Filesystem outside the target": [
  null,
  "Filsystem utanför mål"
 ],
 "device of btrfs volume": [
  null,
  "enhet av btrfs volym"
 ],
 "This device is currently in use.": [
  null,
  "Den här enheten används för närvarande."
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Use": [
  null,
  "Använd"
 ],
 "Services using the location": [
  null,
  "Tjänster som använder platsen"
 ],
 "Processes using the location": [
  null,
  "Processer som använder platsen"
 ],
 "Currently in use": [
  null,
  "Används just nu"
 ],
 "(Not part of target)": [
  null,
  "(Inte del av mål)"
 ],
 "These changes will be made:": [
  null,
  "Dessa ändringar kommer att göras:"
 ],
 "Action": [
  null,
  "Åtgärd"
 ],
 "Important data might be deleted:": [
  null,
  "Viktig data kan raderas:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Relaterade processer och tjänster kommer tvingas stoppa."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Relaterade processer kommer tvingas stoppa."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Relaterade tjänster kommer tvingas stoppa."
 ],
 "Checking filesystem usage": [
  null,
  "Kontrollerar filsystemsanvändning"
 ],
 "$0 used, $1 total": [
  null,
  "$0 använt, $1 totalt"
 ],
 "Device contains unrecognized data": [
  null,
  "Enhet innehåller okänd data"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Låst krypterad enhet kan innehålla data"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Jag bekräftar att jag vill förlora denna data för alltid"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Monteringspunkten $0 används av dessa processer:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Monteringspunkten $0 används av dessa tjänster:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De listade processerna och tjänsterna kommer tvingas stoppa."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De listade processerna kommer att tvingas stoppa."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De listade tjänsterna kommer att tvingas stoppa."
 ],
 "Sorry": [
  null,
  "Förlåt"
 ],
 "Usage of $0": [
  null,
  "Användning av $0"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO Pool"
 ],
 "Data used": [
  null,
  "Data använt"
 ],
 "Metadata used": [
  null,
  "Metadata använt"
 ],
 "Use compression": [
  null,
  "Använd komprimering"
 ],
 "Deduplication": [
  null,
  "Avduplicering"
 ],
 "Use deduplication": [
  null,
  "Använd deduplicering"
 ],
 "Rename volume group": [
  null,
  "Byt namn på en volymgrupp"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Denna volymgrupp innehåller rootfilsystemet. Att byta namn kan kräva ytterligare ändringar i uppstartsladdar konfigurationen eller kärnans kommandorad."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Om du raderar raderas all data i en volymgrupp."
 ],
 "Create snapshot": [
  null,
  "Skapa en ögonblicksbild"
 ],
 "Add disks": [
  null,
  "Lägg till diskar"
 ],
 "Disks": [
  null,
  "Diskar"
 ],
 "No disks are available.": [
  null,
  "Inga diskar är tillgängliga."
 ],
 "At least one disk is needed.": [
  null,
  "Åtminstone en disk behövs."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Volymgruppen saknar fysiska volymer"
 ],
 "No free space": [
  null,
  "Inget ledigt utrymme"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 Volymgrupp"
 ],
 "Add physical volume": [
  null,
  "Lägg till fysisk volym"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 logiska volymer"
 ],
 "Create new logical volume": [
  null,
  "Skapa en ny logisk volym"
 ],
 "No logical volumes": [
  null,
  "Inga logiska volymer"
 ],
 "Remove missing physical volumes?": [
  null,
  "Ta bort saknade fysiska volymer?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Den här volymgruppen saknar några fysiska volymer."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "En volymgrupp med saknade fysiska volymer kan inte döpas om."
 ],
 "Physical volumes": [
  null,
  "Fysiska volymer"
 ],
 "No physical volumes found": [
  null,
  "Inga fysiska volymer hittades"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fysiska volymer"
 ],
 "Rename logical volume": [
  null,
  "Byt namn på en logisk volym"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Vill du permanent ta bort logisk volym $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Att ta bort en logisk volym kommer att ta bort all data i den."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Kunde inte reparera logisk volym $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Det finns inte tillräckligt med utrymme som kan användas för reparation. Minst $0 behövs för fysiska volymer som inte redan används för denna logiska volym."
 ],
 "An additional $0 must be selected": [
  null,
  "Ytterligare $0 måste väljas"
 ],
 "Repair logical volume $0": [
  null,
  "Reparera logisk volym $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Välj de fysiska volymer som ska användas för att reparera den logiska volymen. Åtminstone $0 behövs."
 ],
 "Physical Volumes": [
  null,
  "Fysiska volymer"
 ],
 "Repair": [
  null,
  "Reparera"
 ],
 "deactivate": [
  null,
  "avaktivera"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Inaktivera logisk volym $0/$1?"
 ],
 "Deactivate": [
  null,
  "Avaktivera"
 ],
 "Not enough space to grow": [
  null,
  "Inte tillräckligt med utrymme för att växa"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 logisk volym"
 ],
 "Striped (RAID 0)": [
  null,
  "Remsa (Raid 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Speglad (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Remsad och speglad (Raid 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Dedikerad paritet (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuerad paritet (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dubbel distribuerad paritet (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Denna logiska volym används inte helt av innehållet."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volymstorlek är $0. Innehållsstorlek är $1."
 ],
 "Shrink volume": [
  null,
  "Krymp volym"
 ],
 "Layout": [
  null,
  "Layout"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer och kan inte längre användas. Du måste ta bort den och skapa en ny för att ta dess plats."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer men har inte förlorat några data ännu. Du bör reparera den för att återställa den ursprungliga redundansen."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Denna logiska volym har förlorat några av sina fysiska volymer men kanske inte har förlorat någon data ännu. Du kanske kan reparera den."
 ],
 "Stripes": [
  null,
  "Remsor"
 ],
 "$0 synchronized": [
  null,
  "$0 synkroniserad"
 ],
 "Create volume group": [
  null,
  "Skapa en volymgrupp"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fysisk volym"
 ],
 "Last cannot be removed": [
  null,
  "Den sista kan inte tas bort"
 ],
 "Not enough free space": [
  null,
  "Inte tillräckligt med fritt utrymme"
 ],
 "Volume group": [
  null,
  "Volymgrupp"
 ],
 "Create thin volume": [
  null,
  "Skapa en tunn volym"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tunt provisionerade LVM2 logiska volymer"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Skapa en ny logisk volym med tunn provisionering"
 ],
 "Not enough space": [
  null,
  "Inte tillräckligt med utrymme"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool för tunt underhållna LVM2 logiska volymer"
 ],
 "Inactive logical volume": [
  null,
  "Inaktiv logisk volym"
 ],
 "Activate": [
  null,
  "Aktivera"
 ],
 "Unsupported logical volume": [
  null,
  "Den logiska volymen stöds inte"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNT FEL - Denna logiska volym är markerad som aktiv och bör ha en tillhörande blockenhet. Ingen sådan blockenhet kunde dock hittas."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Att installera $0 skulle ta bort $1."
 ],
 "Installing packages": [
  null,
  "Installerar paket"
 ],
 "Block device for filesystems": [
  null,
  "Blockenhet för filsystem"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool för tunt underhållna volymer"
 ],
 "Linear": [
  null,
  "Linjär"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-filsystemvolym (komprimering/deduplicering)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna utan ytterligare redundans eller prestandaförbättringar."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna på ett alternerande sätt för att förbättra prestandan. Minst två volymer måste väljas."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data kommer att lagras som två eller flera kopior på de valda fysiska volymerna, för att förbättra tillförlitligheten. Minst två volymer måste väljas."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data kommer att lagras som två kopior och även på ett alternerande sätt på de valda fysiska volymerna, för att förbättra både tillförlitlighet och prestanda. Minst fyra volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att en av dem kan gå förlorad utan att data påverkas. Minst tre volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att en av dem kan gå förlorad utan att data påverkas. Data lagras också på ett alternerande sätt för att förbättra prestandan. Minst tre volymer måste väljas."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data kommer att lagras på de valda fysiska volymerna så att upp till två av dem kan gå förlorade samtidigt utan att data påverkas. Data lagras också på ett alternerande sätt för att förbättra prestandan. Minst fem volymer måste väljas."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Alla $0 valda fysiska volymer behövs för den layout som har valts."
 ],
 "Create logical volume": [
  null,
  "Skapa en logisk volym"
 ],
 "Purpose": [
  null,
  "Syfte"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paketet $0 kommer att installeras för att skapa VDO-enheter."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 behöver ett jämnt antal fysiska volymer"
 ],
 "Logical size": [
  null,
  "Logisk storlek"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Spara utrymme genom att komprimera enskilda block med LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Spara utrymme genom att lagra identiska datablock bara en gång"
 ],
 "Creating VDO device": [
  null,
  "Skapar VDO-enhet"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Denna NFS-montering används och endast dess alternativ kan ändras."
 ],
 "NFS mount": [
  null,
  "NFS-montering"
 ],
 "New NFS mount": [
  null,
  "Ny NFS-montering"
 ],
 "Server address": [
  null,
  "Serveradress"
 ],
 "Server cannot be empty.": [
  null,
  "Servern får inte vara tom."
 ],
 "Path on server": [
  null,
  "Sökväg på servern"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sökvägen på servern får inte vara tom."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sökvägen på servern måste börja med ”/”."
 ],
 "Local mount point": [
  null,
  "Lokal monteringspunkt"
 ],
 "Mount point cannot be empty.": [
  null,
  "Monteringspunkten får inte vara tom."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Monteringspunkten måste börja med ”/”."
 ],
 "Mount options": [
  null,
  "Monteringsflaggor"
 ],
 "Mount at boot": [
  null,
  "Montera vid uppstart"
 ],
 "Mount read only": [
  null,
  "Montera skrivskyddat"
 ],
 "Custom mount options": [
  null,
  "Anpassade monteringsalternativ"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan inte avmontera filsystem"
 ],
 "Stop and unmount": [
  null,
  "Stoppa och avmontera"
 ],
 "Unable to remove mount": [
  null,
  "Kan inte ta bort monteringen"
 ],
 "Stop and remove": [
  null,
  "Stoppa och ta bort"
 ],
 "(not mounted)": [
  null,
  "(inte monterad)"
 ],
 "Start multipath": [
  null,
  "Starta multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Det finns enheter med flera sökvägar på systemet, men multipath-tjänsten kör inte."
 ],
 "Show all $0 rows": [
  null,
  "Visa alla $0 rader"
 ],
 "Category": [
  null,
  "Kategori"
 ],
 "more info": [
  null,
  "mer information"
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "encrypted": [
  null,
  "krypterad"
 ],
 "Last modified: $0": [
  null,
  "Senast ändrad: $0"
 ],
 "Stored passphrase": [
  null,
  "Lagrad lösenfras"
 ],
 "Encryption options": [
  null,
  "Krypteringsalternativ"
 ],
 "Encryption type": [
  null,
  "Krypteringstyp"
 ],
 "Cleartext device": [
  null,
  "Klar text enhet"
 ],
 "yes": [
  null,
  "ja"
 ],
 "Disk passphrase": [
  null,
  "Disklösenfras"
 ],
 "Passphrase cannot be empty": [
  null,
  "Lösenfrasen får inte vara tom"
 ],
 "Unlocking disk": [
  null,
  "Låser upp disk"
 ],
 "Checking for $0 package": [
  null,
  "Söker efter $0 paket"
 ],
 "The $0 package must be installed.": [
  null,
  "Paketet $0 måste vara installerat."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Paketet $0 är inte tillgängligt från något arkiv."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Fel vid installation $0: PackageKit eller dnf5daemon-server är inte installerade"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Oväntat PackageManager -fel under installation av $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Söker efter NBDE-stöd i initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd måste återskapas."
 ],
 "Regenerating initrd": [
  null,
  "Regenererar initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Lägger till rd.neednet=1 till kärnans kommandorad"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Lägger till \"$0\" till filsystemsalternativ"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Lägger till \"$0\" till krypteringsalternativ"
 ],
 "Enabling $0": [
  null,
  "Aktiverar $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Lägg till nätverksbunden diskkryptering"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systemet stöder för närvarande inte upplåsning av rotfilsystemet med en Tang-nyckelserver."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systemet stöder för närvarande inte upplåsning av ett filsystem med en Tang-nyckelserver under uppstart."
 ],
 "These additional steps are necessary:": [
  null,
  "Dessa ytterligare steg är nödvändiga:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Att spara en ny lösenfras kräver att disken låses upp. Ge en aktuell disklösenfras."
 ],
 "Fix NBDE support": [
  null,
  "Fixa NBDE-stöd"
 ],
 "Adding key": [
  null,
  "Lägger till nyckel"
 ],
 "Key source": [
  null,
  "Nyckelkälla"
 ],
 "Repeat passphrase": [
  null,
  "Upprepa lösenfrasen"
 ],
 "Passphrase": [
  null,
  "Lösenfras"
 ],
 "Tang keyserver": [
  null,
  "Tang-nyckelserver"
 ],
 "New passphrase": [
  null,
  "Ny lösenfras"
 ],
 "Passphrases do not match": [
  null,
  "Lösenfraserna stämmer inte överens"
 ],
 "Keyserver address": [
  null,
  "Nyckelserverns adress"
 ],
 "Change passphrase": [
  null,
  "Ändra lösenfras"
 ],
 "Old passphrase": [
  null,
  "Gammal lösenfras"
 ],
 "Edit Tang keyserver": [
  null,
  "Redigera Tang-nyckelserver"
 ],
 "Verify key": [
  null,
  "Verifiera nyckel"
 ],
 "Trust key": [
  null,
  "Förtroendenyckel"
 ],
 "Passphrase can not be empty": [
  null,
  "Lösenfrasen kan inte vara tom"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Att ta bort lösenfrasen kan förhindra upplåsning av $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bekräfta borttagandet med en alternativ lösenfras"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Att ta bort en lösenfras utan bekräftelse av en annan lösenfras kan förhindra upplåsning eller nyckelhantering, om andra lösenfraser glöms bort eller går förlorade."
 ],
 "Passphrase from any other key slot": [
  null,
  "Lösenfrasen från vilket annat nyckelfack som helst"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Ta bort lösenfrasen i nyckelfack $0?"
 ],
 "Remove $0?": [
  null,
  "Ta bort $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Borttagning kan förhindra att $0 låses upp."
 ],
 "Remove Tang keyserver?": [
  null,
  "Ta bort Tang-nyckelserver?"
 ],
 "Remove key in slot $0?": [
  null,
  "Ta bort nyckel i nyckelfack $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Användaren som för närvarande är inloggad har inte tillstånd att se information om nycklar."
 ],
 "No keys added": [
  null,
  "Inga nycklar tillagda"
 ],
 "Slot $0": [
  null,
  "Plats $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Att redigera en nyckel kräver ett fritt fack"
 ],
 "The last key slot can not be removed": [
  null,
  "Det sista nyckelfacket kan inte tas bort"
 ],
 "Keyserver": [
  null,
  "Nyckelserver"
 ],
 "Unknown type": [
  null,
  "Okänd typ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nyckelfack med okända typer kan inte redigeras här"
 ],
 "Keys": [
  null,
  "Nycklar"
 ],
 "$0 slot remains": [
  null,
  "$0 fack återstår",
  "$0 fack återstår"
 ],
 "No available slots": [
  null,
  "Inga tillgängliga fack"
 ],
 "No free key slots": [
  null,
  "Inga fria nyckelfack"
 ],
 "Locked data": [
  null,
  "Låst data"
 ],
 "lock": [
  null,
  "lås"
 ],
 "Lock $0?": [
  null,
  "Lås $0?"
 ],
 "Address cannot be empty": [
  null,
  "Adressen kan inte vara tom"
 ],
 "Address is not a valid URL": [
  null,
  "Adressen är inte en giltig URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Kontrollera nyckelhash med Tang-server."
 ],
 "How to check": [
  null,
  "Hur man kontrollerar"
 ],
 "In a terminal, run: ": [
  null,
  "I en terminal, kör: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Framgångsrikt kopierat till urklipp!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Kontrollera att SHA-256- eller SHA-1-hash från kommandot matchar den här dialogrutan."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs undervolym $0 av $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Monteringspunkten kan inte vara tom"
 ],
 "Mount point is already used for $0": [
  null,
  "Monteringspunkten är redan i användning för $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Filsystem är redan monterade under denna monteringspunkt."
 ],
 "Please unmount them first.": [
  null,
  "Vänligen avmontera dem först."
 ],
 "read only": [
  null,
  "läs endast"
 ],
 "never mount at boot": [
  null,
  "Montera aldrig vid uppstart"
 ],
 "after network": [
  null,
  "efter nätverk"
 ],
 "ignore failure": [
  null,
  "ignorera fel"
 ],
 "stop boot on failure": [
  null,
  "Stoppa uppstart vid misslyckande"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Filsystemet har ingen tilldelad monteringspunkt."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Filsystemet har ingen permanent monteringspunkt."
 ],
 "The filesystem is not mounted.": [
  null,
  "Filsystemet är inte monterat."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Filsystemet kommer att låsas upp och monteras vid nästa uppstart. Detta kan kräva att du matar in en lösenfras."
 ],
 "(no assigned mount point)": [
  null,
  "(ingen tilldelad monteringspunkt)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer att monteras på $1 vid nästa uppstart."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montera automatiskt på $0 vid start"
 ],
 "Mount on $0 now": [
  null,
  "Montera på $0 nu"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Filsystemet är för närvarande inte monterat men kommer att monteras vid nästa uppstart."
 ],
 "Do not mount automatically on boot": [
  null,
  "Montera inte automatiskt vid start"
 ],
 "Mount now": [
  null,
  "Montera nu"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat men kommer inte att monteras efter nästa uppstart."
 ],
 "Mount also automatically on boot": [
  null,
  "Montera också automatiskt vid start"
 ],
 "Unmount now": [
  null,
  "Avmontera nu"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer inte att monteras efter nästa uppstart."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Filsystemet är konfigurerat att monteras automatiskt vid uppstart men dess krypteringsbehållare kommer inte att låsas upp vid den tidpunkten."
 ],
 "Unlock automatically on boot": [
  null,
  "Lås upp automatiskt vid start"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Felaktig monteringsinformation"
 ],
 "$0 filesystem": [
  null,
  "$0 filsystem"
 ],
 "Filesystem name": [
  null,
  "Filsystemsnamn"
 ],
 "Filesystem is locked": [
  null,
  "Filsystem är låst"
 ],
 "Mounts before services start": [
  null,
  "Monteras innan tjänster startar"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Lämplig för kritiska monteringar, såsom /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Uppstart misslyckas om filsystemet inte monteras, vilket förhindrar fjärråtkomst"
 ],
 "Mounts in parallel with services": [
  null,
  "Monteras parallellt med tjänster"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Uppstarten lyckas fortfarande när filsystemet inte monteras"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monteras parallellt med tjänster, men efter nätverk är tillgängligt"
 ],
 "Does not mount during boot": [
  null,
  "Monterar inte vid uppstart"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Användbart för monteringar som är valfria eller behöver interaktion (som lösenfraser)"
 ],
 "At boot": [
  null,
  "Vid start"
 ],
 "Mount before services start": [
  null,
  "Montera innan tjänster startar"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montera utan att vänta, ignorera fel"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montera efter att nätverket blir tillgängligt, ignorera fel"
 ],
 "Do not mount": [
  null,
  "Montera inte"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Den här enheten kan inte användas för installationsmålet."
 ],
 "Mount filesystem": [
  null,
  "Montera filsystem"
 ],
 "Unmount filesystem $0": [
  null,
  "Avmontera filsystem $0"
 ],
 "Mount configuration": [
  null,
  "Inställningar för monteringspunkter"
 ],
 "Swap": [
  null,
  "Växlingsutrymme"
 ],
 "Used": [
  null,
  "Använt"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Lås upp krypterad Stratis pool"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Ange lösenordsfrasen för poolen på dessa blockenheter:"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "stopped": [
  null,
  "stoppad"
 ],
 "Block devices": [
  null,
  "Blockenheter"
 ],
 "No block devices found": [
  null,
  "Ingen blockenhet hittades"
 ],
 "Stratis block devices": [
  null,
  "Stratis blockenheter"
 ],
 "Stratis block device": [
  null,
  "Stratis blockenhet"
 ],
 "data": [
  null,
  "data"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Vänligen ange en befintligt lösenfras för poolen."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Om nyckelservern på $0 inte kan nås kan du ange en befintlig lösenfras."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Om ingen av nyckelservrarna är nåbara kan du ange en befintlig lösenfras."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Om ingen av de icke-interaktiva upplåsningsmetoderna fungerar kan du ange en befintlig lösenfras."
 ],
 "Pool passphrase": [
  null,
  "Pool lösenfras"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Nyckelservern på $0 måste vara nåbar."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Åtminstone en nyckelserver måste vara nåbar."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Åtminstone minst en av de icke-interaktiva upplåsningsmetoderna måste fungera."
 ],
 "Create filesystem": [
  null,
  "Skapa filsystem"
 ],
 "Stratis filesystem": [
  null,
  "Stratis filsystem"
 ],
 "Set initial size": [
  null,
  "Ställ in initial storlek"
 ],
 "Limit size": [
  null,
  "Begränsa storlek"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Om du tar bort en Stratis-pool raderas all data som den innehåller."
 ],
 "Rename Stratis pool": [
  null,
  "Byt namn på Stratis pool"
 ],
 "Add block devices": [
  null,
  "Lägg till blockenheter"
 ],
 "Tier": [
  null,
  "Nivå"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Att lägga till blockenheter kräver att poolen låses upp."
 ],
 "Encrypted Stratis pool": [
  null,
  "Krypterad Stratis-pool"
 ],
 "Delete pool": [
  null,
  "Ta bort pool"
 ],
 "Encryption tokens": [
  null,
  "Krypteringstokens"
 ],
 "Stratis filesystems": [
  null,
  "Stratis filsystem"
 ],
 "Create new filesystem": [
  null,
  "Skapa nytt filsystem"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Den här poolen använder inte allt utrymme på sina blockenheter."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Vissa blockenheter i denna pool har vuxit i storlek efter att poolen skapades. Poolen kan säkert växa för att använda det nyligen tillgängliga utrymmet."
 ],
 "Grow the pool to take all space": [
  null,
  "Växa poolen så att den tar all plats"
 ],
 "This pool is in a degraded state.": [
  null,
  "Denna pool är i ett degraderat tillstånd."
 ],
 "No filesystems": [
  null,
  "Inga filsystem"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis filsystem pool"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Denna lösenfras är det enda sättet att låsa upp pool och kan inte tas bort."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Denna nyckelserver är det enda sättet att låsa upp pool och kan inte tas bort."
 ],
 "Add passphrase": [
  null,
  "Lägg till lösenfras"
 ],
 "Add keyserver": [
  null,
  "Lägg till nyckelserver"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "Den sista token kan inte tas bort"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Inget mer utrymme för lösenfraser eller nyckelservrar."
 ],
 "Confirm": [
  null,
  "Bekräfta"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Att lägga till en lösenfras kräver att poolen låses upp."
 ],
 "Remove passphrase?": [
  null,
  "Ta bort lösenfras?"
 ],
 "Add Tang keyserver": [
  null,
  "Lägg till Tang-nyckelserver"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Att lägga till en nyckelserver kräver upplåsning av poolen."
 ],
 "Remove Clevis token?": [
  null,
  "Ta bort Clevis-token?"
 ],
 "Metadata format": [
  null,
  "Metadata format"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Pooler med metadataformat V1 är begränsade till högst en lösenfras och högst en nyckelserver."
 ],
 "Overprovisioning": [
  null,
  "Överprovisionering"
 ],
 "Allow overprovisioning": [
  null,
  "Tillåt överprovisionering"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Storlekarna på virtuella filsystem är större än poolen. Överprovisionering kan inte inaktiveras."
 ],
 "Allocated": [
  null,
  "Tilldelad"
 ],
 "Name can not be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "A pool with this name exists already.": [
  null,
  "En pool med detta namn finns redan."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Ett filsystem med detta namn finns redan i denna pool."
 ],
 "Create Stratis pool": [
  null,
  "Skapa Stratis lagringspool"
 ],
 "No block devices are available.": [
  null,
  "Inga block enheter är tillgängliga."
 ],
 "At least one block device is needed.": [
  null,
  "Åtminstone en blockenhet behövs."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Kryptera data med en lösenfras"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Kryptera data med en Tang-nyckelserver"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Skapa en ögonblicksbild av filsystem $0"
 ],
 "Create snapshot and mount": [
  null,
  "Skapa en ögonblicksbild och montera"
 ],
 "Create snapshot only": [
  null,
  "Skapa en ögonblicksbild endast"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Att ta bort ett filsystem kommer att ta bort all data i det."
 ],
 "Snapshot": [
  null,
  "Ögonblicksbild"
 ],
 "Rename filesystem": [
  null,
  "Byt namn på filsystem"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Ställ in gräns för storlek på virtuellt filsystem"
 ],
 "Limit virtual filesystem size": [
  null,
  "Begränsa det virtuella filsystemets storlek"
 ],
 "Virtual size limit": [
  null,
  "Virtuell storleksbegränsning"
 ],
 "Virtual size": [
  null,
  "Virtuell storlek"
 ],
 "Create RAID device": [
  null,
  "Skapa en RAID-enhet"
 ],
 "RAID level": [
  null,
  "RAID-nivå"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Strimlor)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Spegel)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (dedikerad paritet)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuerad paritet)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel distribuerad paritet)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Strimlor av speglar)"
 ],
 "Chunk size": [
  null,
  "Styckesstorlek"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Åtminstone $0 disk behövs.",
  "Åtminstone $0 diskar behövs."
 ],
 "MDRAID disk": [
  null,
  "MDRAID-disk"
 ],
 "In sync": [
  null,
  "I synk"
 ],
 "Spare": [
  null,
  "Reserv"
 ],
 "Recovering": [
  null,
  "Återställer"
 ],
 "Write-mostly": [
  null,
  "Skriv huvudsakligen"
 ],
 "Blocked": [
  null,
  "Blockerat"
 ],
 "Unknown ($0)": [
  null,
  "Okänt ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID-enheten måste vara igång"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID-enhet återställs"
 ],
 "Need a spare disk": [
  null,
  "Behöver en reservdisk"
 ],
 "Last disk can not be removed": [
  null,
  "Den senaste disken kan inte tas bort"
 ],
 "MDRAID device": [
  null,
  "MDRAID-enhet"
 ],
 "Confirm stopping of $0": [
  null,
  "Bekräfta stoppandet av $0"
 ],
 "Stop device": [
  null,
  "Stoppa enhet"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Om du raderar raderas all data på en MDRAID-enhet."
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID-enhet måste vara igång"
 ],
 "Add disk": [
  null,
  "Lägg till disk"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 diskar"
 ],
 "$0 chunk size": [
  null,
  "$0 styckesstorlek"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID-enheten är i ett degraderat tillstånd"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Denna MDRAID-enhet har ingen bitmap för skrivavsikt. En sådan bitmap kan minska synkronisering tiderna avsevärt."
 ],
 "Add a bitmap": [
  null,
  "Lägg till en bitmap"
 ],
 "No disks found": [
  null,
  "Inga diskar hittades"
 ],
 "MDRAID disks": [
  null,
  "MDRAID diskar"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Radering raderar all data på en VDO-enhet."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Skapandet av denna VDO-enhet avslutade inte och enheten kan inte användas."
 ],
 "Remove device": [
  null,
  "Ta bort enhet"
 ],
 "Grow to take all space": [
  null,
  "Utöka till att ta allt utrymme"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Denna VDO-enhet använder inte alla sina underliggande enheter."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Endast $0 av $1 används."
 ],
 "Grow logical size of $0": [
  null,
  "Utöka den logiska storleken av $0"
 ],
 "Physical": [
  null,
  "Fysiskt"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 extra använt av $2 ($3)"
 ],
 "Logical": [
  null,
  "Logisk"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 använt av $1 ($2 sparat)"
 ],
 "Index memory": [
  null,
  "Indexminne"
 ],
 "SMART self-test of $target": [
  null,
  "SMART-självtest av $target"
 ],
 "Ejecting $target": [
  null,
  "Matar ut $target"
 ],
 "Unlocking $target": [
  null,
  "Lås upp $target"
 ],
 "Locking $target": [
  null,
  "Låser $target"
 ],
 "Modifying $target": [
  null,
  "Modifiera $target"
 ],
 "Resizing $target": [
  null,
  "Ändrar storlek på $target"
 ],
 "Starting swapspace $target": [
  null,
  "Starta växlingsutrymmet $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Stoppar växlingsutrymmet $target"
 ],
 "Mounting $target": [
  null,
  "Monterar $target"
 ],
 "Unmounting $target": [
  null,
  "Avmonterar $target"
 ],
 "Checking $target": [
  null,
  "Kontrollerar $target"
 ],
 "Repairing $target": [
  null,
  "Reparerar $target"
 ],
 "Erasing $target": [
  null,
  "Raderar $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Skapar ett filsystem på $target"
 ],
 "Setting up loop device $target": [
  null,
  "Sätter upp vändslingeenheten $target"
 ],
 "Deleting $target": [
  null,
  "Tar bort $target"
 ],
 "Creating partition $target": [
  null,
  "Skapar en partition på $target"
 ],
 "Cleaning up for $target": [
  null,
  "Rensar upp för $target"
 ],
 "Securely erasing $target": [
  null,
  "Raderar säkert $target"
 ],
 "Very securely erasing $target": [
  null,
  "Raderar mycket säkert $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Stoppar MDRAID-enhet $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Startar MDRAID-enhet $target"
 ],
 "Marking $target as faulty": [
  null,
  "Markerar $target som felaktig"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Tar bort $target från MDRAID-enheten"
 ],
 "Creating MDRAID device $target": [
  null,
  "Skapar MDRAID-enhet $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Kontrollerar MDRAID-enhet $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontrollera och reparera MDRAID-enhet $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Återställer MDRAID-enhet $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synkroniserar MDRAID-enheten $target"
 ],
 "Activating $target": [
  null,
  "Aktivera $target"
 ],
 "Deactivating $target": [
  null,
  "Avaktiverar $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Skapar en ögonblicksbild av $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Skapar LVM2 volymgrupp $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Tar bort LVM2 volymgruppen $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Lägger till fysisk volym till $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Tar bort den fysiska volymen från $target"
 ],
 "Emptying $target": [
  null,
  "Tömmer $target"
 ],
 "Creating logical volume $target": [
  null,
  "Skapar en logisk volym på $target"
 ],
 "Renaming $target": [
  null,
  "Byter namn på $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Åtgärden ”$operation” på $target"
 ],
 "unknown target": [
  null,
  "okänt mål"
 ],
 "Jobs": [
  null,
  "Jobb"
 ],
 "Reading": [
  null,
  "Läser"
 ],
 "Writing": [
  null,
  "Skriver"
 ],
 "Install Stratis support": [
  null,
  "Installera Stratis stöd"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paketet $0 måste installeras för att skapa Stratis-pooler."
 ],
 "Install NFS support": [
  null,
  "Installera stöd för NFS"
 ],
 "Create MDRAID device": [
  null,
  "Skapa en MDRAID-enhet"
 ],
 "Create LVM2 volume group": [
  null,
  "Skapa LVM2 volymgrupp"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ändra iSCSI-initierarnamn"
 ],
 "Add iSCSI portal": [
  null,
  "Lägg till iSCSI-portal"
 ],
 "Local storage": [
  null,
  "Lokal lagring"
 ],
 "Networked storage": [
  null,
  "Nätverkslagring"
 ],
 "Create storage device": [
  null,
  "Skapa lagringsenhet"
 ],
 "No storage found": [
  null,
  "Ingen lagring hittades"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradressen får inte vara tom."
 ],
 "Next": [
  null,
  "Nästa"
 ],
 "Invalid username or password": [
  null,
  "Felaktigt användarnamn eller lösenord"
 ],
 "Unknown host name": [
  null,
  "Okänt värdnamn"
 ],
 "Unable to reach server": [
  null,
  "Kan inte nå servern"
 ],
 "Available targets on $0": [
  null,
  "Tillgängliga mål på $0"
 ],
 "Authentication required": [
  null,
  "Autentisering krävs"
 ],
 "iSCSI portal": [
  null,
  "iSCSI-portal"
 ],
 "iSCSI drives": [
  null,
  "iSCSI-diskar"
 ],
 "No drives found": [
  null,
  "Inga diskar funna"
 ],
 "Target": [
  null,
  "Mål"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-underlagsenheter kan inte göras mindre"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockenheter kan inte göras mindre"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Okända data får inte göras mindre här."
 ],
 "Unlock before resizing": [
  null,
  "Lås upp innan du ändrar storlek"
 ],
 "$0 can not be resized here": [
  null,
  "$0 kan inte storleksändras"
 ],
 "$0 can not be resized": [
  null,
  "$0 kan inte storleksändras"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 kan inte göras mindre"
 ],
 "$0 can not be made larger": [
  null,
  "$0 kan inte göras större"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Storleken på fysiska volymer kan inte ändras här"
 ],
 "Swap can not be resized here": [
  null,
  "Det går inte att ändra storlek på swap här"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Okända data får inte göras mindre här"
 ],
 "Activate before resizing": [
  null,
  "Aktivera innan du ändrar storlek"
 ],
 "Grow logical volume": [
  null,
  "Utöka en logisk volym"
 ],
 "Grow partition": [
  null,
  "Väx partition"
 ],
 "grow": [
  null,
  "väx"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exakt $0 fysiska volymer måste väljas"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Ändra storlek på ett krypterat filsystem kräver upplåsning av disken. Ange en aktuell disklösenfras."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exakt $0 fysiska volymer måste väljas, en för varje remsa av den logiska volymen."
 ],
 "Shrink logical volume": [
  null,
  "Krymp en logisk volym"
 ],
 "shrink": [
  null,
  "krymp"
 ],
 "Unformatted data": [
  null,
  "Oformaterad data"
 ],
 "Block device": [
  null,
  "Blockenhet"
 ],
 "Device number": [
  null,
  "Enhetsnummer"
 ],
 "Create partition on $0": [
  null,
  "Skapa partition på $0"
 ],
 "Format $0": [
  null,
  "Formatera $0"
 ],
 "No filesystem": [
  null,
  "Inget filsystem"
 ],
 "(recommended)": [
  null,
  "(rekommenderad)"
 ],
 "No encryption": [
  null,
  "Ingen kryptering"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Återanvänd befintlig kryptering ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Återanvänd befintlig kryptering"
 ],
 "format": [
  null,
  "formatera"
 ],
 "Format and mount": [
  null,
  "Formatera och montera"
 ],
 "Format only": [
  null,
  "Formatera endast"
 ],
 "Format": [
  null,
  "Formatera"
 ],
 "Create and start": [
  null,
  "Skapa och starta"
 ],
 "Format and start": [
  null,
  "Formatera och starta"
 ],
 "Store passphrase": [
  null,
  "Lagra lösenfrasen"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Disken måste låsas upp innan formatering. Ange en befintlig lösenfras."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatering raderar all data på en lagringsenhet."
 ],
 "Unrecognized data": [
  null,
  "Okända data"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Lagring kan inte hanteras på detta system."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
