cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "ຄີທີ່ປ່ຽນແປງມັກຈະເກີດຈາກການຕິດຕັ້ງລະບົບປະຕິບັດການໃໝ່. ຢ່າງໃດກໍຕາມ, ການປ່ຽນແປງທີ່ບໍ່ຄາດຄິດອາດໝາຍເຖິງການພະຍາຍາມແຊກແຊງການເຊື່ອມຕໍ່ຂອງທ່ານຈາກບຸກຄົນທີສາມ."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "ເພື່ອໃຫ້ແນ່ໃຈວ່າການເຊື່ອມຕໍ່ຂອງທ່ານບໍ່ຖືກດັກຟັງໂດຍບຸກຄົນທີສາມ, ກະລຸນາກວດສອບລາຍນິ້ວມືຂອງຄີໂຮສຕ໌:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ."
 ],
 "User name": [
  null,
  "ຊື່ຜູ້ໃຊ້"
 ],
 "Password": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "Log in": [
  null,
  "ເຂົ້າສູ່ລະບົບ"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Comment": [
  null,
  "ຄຳຄິດເຫັນ"
 ],
 "Type": [
  null,
  "ປະເພດ"
 ],
 "Fingerprint": [
  null,
  "ລາຍນິ້ວມື"
 ],
 "Copy": [
  null,
  "ກັອບປີ້"
 ],
 "Copied": [
  null,
  "ກັອບປີ້ແລ້ວ"
 ],
 "Change password": [
  null,
  "ປ່ຽນລະຫັດຜ່ານ"
 ],
 "Password changed successfully": [
  null,
  "ປ່ຽນລະຫັດຜ່ານສຳເລັດແລ້ວ"
 ],
 "New password": [
  null,
  "ລະຫັດຜ່ານໃໝ່"
 ],
 "Confirm password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານ"
 ],
 "Password tip": [
  null,
  "ຄຳແນະນຳລະຫັດຜ່ານ"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "ຄຳແນະນຳ: ຕັ້ງລະຫັດຜ່ານຂອງຄີໃຫ້ກົງກັບລະຫັດຜ່ານເຂົ້າລະບົບຂອງທ່ານ ເພື່ອຢືນຢັນຕົວຕົນກັບລະບົບອື່ນໂດຍອັດຕະໂນມັດ."
 ],
 "Unlock key $0": [
  null,
  "ປົດລັອກຄີ $0"
 ],
 "Unlock": [
  null,
  "ປົດລັອກ"
 ],
 "Add key": [
  null,
  "ເພີ່ມຄີ"
 ],
 "SSH keys": [
  null,
  "ຄີ SSH"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "ໃຊ້ຄີຕໍ່ໄປນີ້ເພື່ອຢືນຢັນຕົວຕົນກັບລະບົບອື່ນ"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Toggle": [
  null,
  "ເປີດ-ປິດ"
 ],
 "Details": [
  null,
  "ລາຍລະອຽດ"
 ],
 "Public key": [
  null,
  "ຄີສາທາລະນະ (Public key)"
 ],
 "Use key": [
  null,
  "ໃຊ້ຄີ"
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Hosts": [
  null,
  "ບັນດາໂຮສຕ໌"
 ],
 "Connection error": [
  null,
  "ຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່"
 ],
 "Edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Remove": [
  null,
  "ລຶບອອກ"
 ],
 "Add new host": [
  null,
  "ເພີ່ມໂຮສຕ໌ໃໝ່"
 ],
 "Host": [
  null,
  "ໂຮສຕ໌ (Host)"
 ],
 "Stop editing hosts": [
  null,
  "ຢຸດການແກ້ໄຂໂຮສຕ໌"
 ],
 "Edit hosts": [
  null,
  "ແກ້ໄຂບັນດາໂຮສຕ໌"
 ],
 "active": [
  null,
  "ກຳລັງເຮັດວຽກ"
 ],
 "Active pages": [
  null,
  "ໜ້າທີ່ກຳລັງໃຊ້ງານ"
 ],
 "Page name": [
  null,
  "ຊື່ໜ້າ"
 ],
 "There are currently no active pages": [
  null,
  "ປັດຈຸບັນບໍ່ມີໜ້າໃດທີ່ກຳລັງເຮັດວຽກຢູ່"
 ],
 "Close selected pages": [
  null,
  "ປິດໜ້າທີ່ເລືອກ"
 ],
 "$0 documentation": [
  null,
  "ເອກະສານ $0"
 ],
 "About Web Console": [
  null,
  "ກ່ຽວກັບ Web Console"
 ],
 "Style": [
  null,
  "ຮູບແບບ"
 ],
 "Default": [
  null,
  "ຄ່າເລີ່ມຕົ້ນ"
 ],
 "Light": [
  null,
  "ສະຫວ່າງ"
 ],
 "Dark": [
  null,
  "ມືດ"
 ],
 "Display language": [
  null,
  "ພາສາທີ່ສະແດງ"
 ],
 "Log out": [
  null,
  "ອອກຈາກລະບົບ"
 ],
 "Ooops!": [
  null,
  "ຂໍອະໄພ!"
 ],
 "Help": [
  null,
  "ຊ່ວຍເຫຼືອ"
 ],
 "Session": [
  null,
  "ວາລະການໃຊ້ງານ"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "ໄດ້ຮັບອະນຸຍາດພາຍໃຕ້ GNU LGPL ເວີຊັນ 2.1"
 ],
 "Web Console": [
  null,
  "Web Console"
 ],
 "Web console logo": [
  null,
  "ໂລໂກ້ Web console"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit ແມ່ນສ່ວນຕິດຕໍ່ການບໍລິຫານເຊີເວີ Linux ແບບໂຕ້ຕອບ."
 ],
 "Project website": [
  null,
  "ເວັບໄຊໂຄງການ"
 ],
 "Loading packages...": [
  null,
  "ກຳລັງໂຫຼດແພັກເກດ..."
 ],
 "Choose the language to be used in the application": [
  null,
  "ເລືອກພາສາທີ່ຈະໃຊ້ໃນແອັບພລິເຄຊັນ"
 ],
 "Filter menu items": [
  null,
  "ກັ່ນຕອງລາຍການເມນູ"
 ],
 "No languages match": [
  null,
  "ບໍ່ມີພາສາທີ່ກົງກັນ"
 ],
 "Select": [
  null,
  "ເລືອກ"
 ],
 "Unexpected error": [
  null,
  "ເກີດຂໍ້ຜິດພາດທີ່ບໍ່ຄາດຄິດ"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit ເກີດຂໍ້ຜິດພາດພາຍໃນທີ່ບໍ່ຄາດຄິດ."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "ໃນບຣາວເຊີສ່ວນໃຫຍ່"
 ],
 "System": [
  null,
  "ລະບົບ"
 ],
 "Search": [
  null,
  "ຄົ້ນຫາ"
 ],
 "No results found": [
  null,
  "ບໍ່ພົບຜົນລັບ"
 ],
 "Clear search": [
  null,
  "ລຶບການຄົ້ນຫາ"
 ],
 "Contains:": [
  null,
  "ປະກອບມີ:"
 ],
 "Apps": [
  null,
  "ແອັບ"
 ],
 "Tools": [
  null,
  "ເຄື່ອງມື"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "ເວີຊັນຂອງ Cockpit ທີ່ເຂົ້າກັນໄດ້ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນ $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "ບໍ່ສາມາດຕິດຕໍ່ຫາໂຮສຕ໌ $0 ທີ່ລະບຸໄດ້. ກວດສອບໃຫ້ແນ່ໃຈວ່າມີ ssh ເຮັດວຽກຢູ່ພອດ $1, ຫຼື ລະບຸພອດອື່ນໃນທີ່ຢູ່."
 ],
 "Connect to $0?": [
  null,
  "ເຊື່ອມຕໍ່ຫາ $0 ບໍ່?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "ໂຮສຕ໌ທີ່ເຊື່ອມຕໍ່ກັນສາມາດຄວບຄຸມກັນໄດ້ຢ່າງສົມບູນ. ກະລຸນາເຊື່ອມຕໍ່ສະເພາະເຄື່ອງທີ່ທ່ານເຊື່ອຖືເທົ່ານັ້ນ."
 ],
 "Read more": [
  null,
  "ອ່ານເພີ່ມເຕີມ"
 ],
 "You will be reminded once per session.": [
  null,
  "ທ່ານຈະຖືກເຕືອນໜຶ່ງຄັ້ງຕໍ່ວາລະການໃຊ້ງານ."
 ],
 "Connect": [
  null,
  "ເຊື່ອມຕໍ່"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "ທີ່ຢູ່ IP ຫຼື ຊື່ໂຮສຕ໌ບໍ່ສາມາດມີຊ່ອງຫວ່າງໄດ້."
 ],
 "This machine has already been added.": [
  null,
  "ເຄື່ອງນີ້ຖືກເພີ່ມເຂົ້າໄປແລ້ວ."
 ],
 "Failed to add machine: $0": [
  null,
  "ບໍ່ສາມາດເພີ່ມເຄື່ອງ: $0"
 ],
 "Edit host": [
  null,
  "ແກ້ໄຂໂຮສຕ໌"
 ],
 "Set": [
  null,
  "ຕັ້ງຄ່າ"
 ],
 "Add": [
  null,
  "ເພີ່ມ"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "ສາມາດເປັນຊື່ໂຮສຕ໌, ທີ່ຢູ່ IP, ຊື່ຫຼິ້ນ ຫຼື ssh:// URI"
 ],
 "When empty, connect with the current user": [
  null,
  "ຖ້າຫວ່າງເປົ່າ, ຈະເຊື່ອມຕໍ່ດ້ວຍຜູ້ໃຊ້ປັດຈຸບັນ"
 ],
 "Color": [
  null,
  "ສີ"
 ],
 "Failed to edit machine: $0": [
  null,
  "ບໍ່ສາມາດແກ້ໄຂເຄື່ອງໄດ້: $0"
 ],
 "Could not contact $0": [
  null,
  "ບໍ່ສາມາດຕິດຕໍ່ $0"
 ],
 "Update": [
  null,
  "ອັບເດດ"
 ],
 "Unable to contact $0.": [
  null,
  "ບໍ່ສາມາດຕິດຕໍ່ຫາ $0 ໄດ້."
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd ກຳລັງຣັນຢູ່ເທິງພອດອື່ນບໍ່?"
 ],
 "Port": [
  null,
  "ພອດ (Port)"
 ],
 "$0 key changed": [
  null,
  "ຄີ $0 ປ່ຽນແປງແລ້ວ"
 ],
 "New host: $0": [
  null,
  "ໂຮສຕ໌ໃໝ່: $0"
 ],
 "Trust and add host": [
  null,
  "ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ເພື່ອການກວດສອບລາຍນິ້ວມື, ໃຫ້ຮັນຄຳສັ່ງຕໍ່ໄປນີ້ໃນ $0 ໃນຂະນະທີ່ຢູ່ໜ້າເຄື່ອງ ຫຼື ຜ່ານເຄືອຂ່າຍທີ່ໜ້າເຊື່ອຖື:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "ຖ້າລາຍນິ້ວມືກົງກັນ, ກົດ 'ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌'. ຖ້າບໍ່ດັ່ງນັ້ນ, ຫ້າມເຊື່ອມຕໍ່ ແລະ ຕິດຕໍ່ຜູ້ດູແລລະບົບຂອງເຈົ້າ."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "ລາຍນິ້ວມືທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ. ຖ້າທ່ານໃຫ້ຄົນອື່ນກວດສອບໃຫ້, ເຂົາເຈົ້າສາມາດສົ່ງຜົນການກວດສອບໃຫ້ທ່ານດ້ວຍວິທີໃດກໍໄດ້."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "ທ່ານກຳລັງເຊື່ອມຕໍ່ຫາ $0 ເປັນຄັ້ງທຳອິດ."
 ],
 "Verify fingerprint": [
  null,
  "ກວດສອບລາຍນິ້ວມື"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "ຣັນຄຳສັ່ງນີ້ຜ່ານເຄືອຂ່າຍທີ່ເຊື່ອຖືໄດ້ ຫຼື ຣັນຢູ່ເຄື່ອງປາຍທາງໂດຍກົງ:"
 ],
 "The fingerprint should match:": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ຄວນຈະກົງກັບ:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "ໜ້າເວັບທີ່ເປັນອັນຕະລາຍໃນເຄື່ອງຣີໂມດອາດສົ່ງຜົນກະທົບຕໍ່ໂຮສຕ໌ອື່ນໆທີ່ເຊື່ອມຕໍ່ຢູ່"
 ],
 "The password can not be empty": [
  null,
  "ລະຫັດຜ່ານບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key password can not be empty": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key passwords do not match": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ກົງກັນ"
 ],
 "The new key password can not be empty": [
  null,
  "ລະຫັດຜ່ານໃໝ່ຂອງຄີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "Log in to $0": [
  null,
  "ເຂົ້າສູ່ລະບົບ $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ໄດ້. ໂຮສຕ໌ບໍ່ຍອມຮັບການເຂົ້າລະບົບດ້ວຍລະຫັດຜ່ານ ຫຼື ຄີ SSH ໃດໆຂອງທ່ານ."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ດ້ວຍການຢືນຢັນຄີ SSH ໄດ້. ກະລຸນາລະບຸລະຫັດຜ່ານ. ທ່ານອາດຈະຕ້ອງການຕັ້ງຄ່າຄີ SSH ເພື່ອເຂົ້າສູ່ລະບົບໂດຍອັດຕະໂນມັດ."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ແມ່ນຖືກປ້ອງກັນດ້ວຍລະຫັດຜ່ານ, ແລະ ໂຮສຕ໌ບໍ່ອະນຸຍາດໃຫ້ເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານ. ກະລຸນາລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "ທ່ານອາດຈະຕ້ອງການປ່ຽນລະຫັດຜ່ານຂອງຄີເພື່ອເຂົ້າສູ່ລະບົບໂດຍອັດຕະໂນມັດ."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ຖືກປ້ອງກັນໄວ້. ທ່ານສາມາດເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານຂອງທ່ານ ຫຼື ລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ສ້າງ SSH ຄີໃໝ່ ແລະ ອະນຸຍາດມັນ"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "SSH ຄີໃໝ່ຢູ່ $0 ຈະຖືກສ້າງຂຶ້ນສຳລັບ $1 ຢູ່ $2 ແລະ ມັນຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Key password": [
  null,
  "ລະຫັດຜ່ານຄີ"
 ],
 "Confirm key password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານຂອງຄີ"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "ເພື່ອອະນຸຍາດໃຫ້ເຂົ້າສູ່ລະບົບ $0 ໃນນາມ $1 ໂດຍບໍ່ມີລະຫັດຜ່ານໃນອະນາຄົດ, ໃຫ້ໃຊ້ລະຫັດຜ່ານການເຂົ້າສູ່ລະບົບຂອງ $2 ເທິງ $3 ເປັນລະຫັດຜ່ານຄີ, ຫຼື ປະວ່າງລະຫັດຜ່ານຄີໄວ້."
 ],
 "Change the password of $0": [
  null,
  "ປ່ຽນລະຫັດຜ່ານຂອງ $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "ໂດຍການປ່ຽນລະຫັດຜ່ານຂອງ SSH ຄີ $0 ໃຫ້ເປັນລະຫັດຜ່ານດຽວກັບ $1 ຢູ່ $2, ຄີຈະຖືກໃຊ້ງານອັດຕະໂນມັດ ແລະ ທ່ານສາມາດເຂົ້າລະບົບ $3 ໄດ້ໂດຍບໍ່ຕ້ອງໃຊ້ລະຫັດຜ່ານໃນອະນາຄົດ."
 ],
 "New key password": [
  null,
  "ລະຫັດຜ່ານຄີ (key) ໃໝ່"
 ],
 "Confirm new key password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານໃໝ່ຂອງຄີ"
 ],
 "Authorize SSH key": [
  null,
  "ອະນຸຍາດ SSH ຄີ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "ຄີ SSH $0 ຂອງ $1 ຢູ່ $2 ຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "ນີ້ຈະຊ່ວຍໃຫ້ທ່ານສາມາດເຂົ້າສູ່ລະບົບໂດຍບໍ່ຕ້ອງໃຊ້ລະຫັດຜ່ານໃນອະນາຄົດ."
 ],
 "Authentication": [
  null,
  "ການຢືນຢັນຕົວຕົນ"
 ],
 "SSH key": [
  null,
  "ຄີ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "ຄີ SSH $0 ຈະສາມາດໃຊ້ໄດ້ຕະຫຼອດວາລະການໃຊ້ງານທີ່ເຫຼືອ ແລະ ຈະສາມາດໃຊ້ເຂົ້າສູ່ລະບົບໂຮສຕ໌ອື່ນໆໄດ້ຄືກັນ."
 ],
 "Automatic login": [
  null,
  "ເຂົ້າລະບົບອັດຕະໂນມັດ"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "ທ່ານຖືກອອກຈາກລະບົບເນື່ອງຈາກບໍ່ມີການເຄື່ອນໄຫວ."
 ],
 "Connection failed": [
  null,
  "ການເຊື່ອມຕໍ່ຫຼົ້ມເຫຼວ"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "ເກີດຂໍ້ຜິດພາດທີ່ບໍ່ຄາດຄິດໃນຂະນະທີ່ເຊື່ອມຕໍ່ຫາເຄື່ອງ."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "ຂໍ້ຄວາມທີ່ກ່ຽວຂ້ອງກັບຄວາມຜິດພາດອາດພົບໄດ້ໃນ journal:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "ຜູ້ໃຊ້ Safari ຈຳເປັນຕ້ອງນຳເຂົ້າ ແລະ ໃຫ້ຄວາມເຊື່ອຖືໃບຢັ້ງຢືນຂອງ self-signing CA:"
 ],
 "Reconnect": [
  null,
  "ເຊື່ອມຕໍ່ຄືນໃໝ່"
 ],
 "Disconnected": [
  null,
  "ຕັດການເຊື່ອມຕໍ່ແລ້ວ"
 ],
 "The machine is rebooting": [
  null,
  "ເຄື່ອງກຳລັງບູດໃໝ່"
 ],
 "Connecting to the machine": [
  null,
  "ກຳລັງເຊື່ອມຕໍ່ຫາເຄື່ອງ"
 ],
 "Not connected to host": [
  null,
  "ບໍ່ໄດ້ເຊື່ອມຕໍ່ກັບໂຮສຕ໌"
 ],
 "Cannot connect to an unknown host": [
  null,
  "ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບໂຮສຕ໌ທີ່ບໍ່ຮູ້ຈັກໄດ້"
 ],
 "Session is about to expire": [
  null,
  "ວາລະການໃຊ້ງານກຳລັງຈະໝົດອາຍຸ"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "ທ່ານຈະຖືກອອກຈາກລະບົບພາຍໃນ $0 ວິນາທີ."
 ],
 "Continue session": [
  null,
  "ສືບຕໍ່ເຊດຊັນ (session)"
 ],
 "Skip to content": [
  null,
  "ຂ້າມໄປຫາເນື້ອໃນ"
 ],
 "Skip main navigation": [
  null,
  "ຂ້າມການນຳທາງຫຼັກ"
 ],
 "Permission denied": [
  null,
  "ການອະນຸຍາດຖືກປະຕິເສດ"
 ],
 "Clear input value": [
  null,
  "ລຶບຄ່າທີ່ປ້ອນເຂົ້າ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "ຮູບແບບວັນທີ ແລະ ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid time format": [
  null,
  "ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid date format": [
  null,
  "ຮູບແບບວັນທີບໍ່ຖືກຕ້ອງ"
 ],
 "Cannot schedule event in the past": [
  null,
  "ບໍ່ສາມາດຕັ້ງເວລາໃນອະດີດໄດ້"
 ],
 "No delay": [
  null,
  "ບໍ່ມີການຊັກຊ້າ"
 ],
 "1 minute": [
  null,
  "1 ນາທີ"
 ],
 "5 minutes": [
  null,
  "5 ນາທີ"
 ],
 "20 minutes": [
  null,
  "20 ນາທີ"
 ],
 "40 minutes": [
  null,
  "40 ນາທີ"
 ],
 "60 minutes": [
  null,
  "60 ນາທີ"
 ],
 "Specific time": [
  null,
  "ເວລາສະເພາະ"
 ],
 "Shut down": [
  null,
  "ປິດເຄື່ອງ"
 ],
 "Reboot": [
  null,
  "ບູດເຄື່ອງໃໝ່"
 ],
 "Message to logged in users": [
  null,
  "ຂໍ້ຄວາມເຖິງຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບຢູ່"
 ],
 "Delay": [
  null,
  "ການໜ່ວງເວລາ"
 ],
 "Pick date": [
  null,
  "ເລືອກວັນທີ"
 ],
 "Toggle date picker": [
  null,
  "ເປີດ-ປິດ ຕົວເລືອກວັນທີ"
 ],
 "Synchronized": [
  null,
  "ຊິງໂຄຣໄນຊ໌ແລ້ວ"
 ],
 "Synchronized with $0": [
  null,
  "ຊິງໂຄຣໄນຊ໌ກັບ $0 ແລ້ວ"
 ],
 "Synchronizing": [
  null,
  "ກຳລັງຊິງໂຄຣໄນຊ໌"
 ],
 "Trying to synchronize with $0": [
  null,
  "ກຳລັງພະຍາຍາມຊິງໂຄຣໄນຊ໌ກັບ $0"
 ],
 "Not synchronized": [
  null,
  "ບໍ່ໄດ້ຊິງໂຄຣໄນຊ໌"
 ],
 "Log messages": [
  null,
  "ຂໍ້ຄວາມລັອກ"
 ],
 "NTP server": [
  null,
  "ເຊີບເວີ NTP"
 ],
 "Manually": [
  null,
  "ດ້ວຍຕົນເອງ"
 ],
 "Automatically using NTP": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍ NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ເພີ່ມເຕີມ"
 ],
 "Automatically using specific NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ທີ່ລະບຸ"
 ],
 "Time zone": [
  null,
  "ເຂດເວລາ"
 ],
 "Set time": [
  null,
  "ຕັ້ງເວລາ"
 ],
 "Invalid timezone": [
  null,
  "ເຂດເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Need at least one NTP server": [
  null,
  "ຕ້ອງການເຊີບເວີ NTP ຢ່າງໜ້ອຍໜຶ່ງຕົວ"
 ],
 "Change system time": [
  null,
  "ປ່ຽນເວລາຂອງລະບົບ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Path to file": [
  null,
  "ເສັ້ນທາງໄປຫາໄຟລ໌"
 ],
 "No such file or directory": [
  null,
  "ບໍ່ມີໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີນີ້"
 ],
 "Create $0": [
  null,
  "ສ້າງ $0"
 ],
 "Ok": [
  null,
  "ຕົກລົງ"
 ],
 "Learn more": [
  null,
  "ຮຽນຮູ້ເພີ່ມເຕີມ"
 ],
 "You now have administrative access.": [
  null,
  "ດຽວນີ້ທ່ານມີສິດເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບແລ້ວ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ບໍ່ມີວິທີການເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ກະລຸນາຢືນຢັນຕົວຕົນເພື່ອເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ"
 ],
 "Switch to administrative access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "Authenticate": [
  null,
  "ຢືນຢັນຕົວຕົນ"
 ],
 "Administrative access": [
  null,
  "ສິດການບໍລິຫານ"
 ],
 "Problem becoming administrator": [
  null,
  "ມີບັນຫາໃນການກາຍເປັນຜູ້ດູແລລະບົບ"
 ],
 "Method": [
  null,
  "ວິທີການ"
 ],
 "Limit access": [
  null,
  "ຈຳກັດການເຂົ້າເຖິງ"
 ],
 "Switch to limited access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "ໂໝດການເຂົ້າເຖິງແບບຈຳກັດຈະຈຳກັດສິດຜູ້ດູແລລະບົບ. ບາງສ່ວນຂອງເວັບຄອນໂຊນຈະມີຟັງຊັນການເຮັດວຽກທີ່ຫຼຸດລົງ."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ບຣາວເຊີຂອງທ່ານຈະຈົດຈຳລະດັບການເຂົ້າເຖິງຂອງທ່ານໄວ້."
 ],
 "Limited access": [
  null,
  "ການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Turn on administrative access": [
  null,
  "ເປີດການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "$0 year": [
  null,
  "$0 ປີ"
 ],
 "$0 month": [
  null,
  "$0 ເດືອນ"
 ],
 "$0 week": [
  null,
  "$0 ອາທິດ"
 ],
 "$0 day": [
  null,
  "$0 ມື້"
 ],
 "$0 hour": [
  null,
  "$0 ຊົ່ວໂມງ"
 ],
 "$0 minute": [
  null,
  "$0 ນາທີ"
 ],
 "Go to now": [
  null,
  "ໄປທີ່ປັດຈຸບັນ"
 ],
 "1 hour": [
  null,
  "1 ຊົ່ວໂມງ"
 ],
 "6 hours": [
  null,
  "6 ຊົ່ວໂມງ"
 ],
 "1 day": [
  null,
  "1 ມື້"
 ],
 "1 week": [
  null,
  "1 ອາທິດ"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານ $0 ໃນ firewalld ໄດ້"
 ],
 "Visit firewall": [
  null,
  "ໄປທີ່ໄຟວໍ"
 ],
 "Zone": [
  null,
  "ໂຊນ"
 ],
 "Add $0": [
  null,
  "ເພີ່ມ $0"
 ],
 "less than a minute ago": [
  null,
  "ບໍ່ຮອດໜຶ່ງນາທີກ່ອນ"
 ],
 "in less than a minute": [
  null,
  "ພາຍໃນບໍ່ຮອດໜຶ່ງນາທີ"
 ],
 "Password is too weak": [
  null,
  "ລະຫັດຜ່ານອ່ອນເກີນໄປ"
 ],
 "Excellent password": [
  null,
  "ລະຫັດຜ່ານດີເລີດ"
 ],
 "Password is not acceptable": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Strong password": [
  null,
  "ລະຫັດຜ່ານທີ່ແຂງແຮງ"
 ],
 "Acceptable password": [
  null,
  "ລະຫັດຜ່ານທີ່ຍອມຮັບໄດ້"
 ],
 "Weak password": [
  null,
  "ລະຫັດຜ່ານທີ່ບໍ່ປອດໄພ"
 ],
 "Show password": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Hide password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "password quality": [
  null,
  "ຄຸນນະພາບລະຫັດຜ່ານ"
 ],
 "Show confirmation password": [
  null,
  "ສະແດງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Hide confirmation password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Additional packages:": [
  null,
  "ແພັກເກດເພີ່ມເຕີມ:"
 ],
 "Removals:": [
  null,
  "ການລຶບອອກ:"
 ],
 "Total size: $0": [
  null,
  "ຂະໜາດທັງໝົດ: $0"
 ],
 "Install software": [
  null,
  "ຕິດຕັ້ງຊອບແວ"
 ],
 "$0 will be installed.": [
  null,
  "$0 ຈະຖືກຕິດຕັ້ງ."
 ],
 "Install": [
  null,
  "ຕິດຕັ້ງ"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ກຳລັງລໍຖ້າໃຫ້ການຈັດການຊອບແວອື່ນໆເຮັດວຽກໃຫ້ສຳເລັດ"
 ],
 "Checking installed software": [
  null,
  "ກຳລັງກວດສອບຊອບແວທີ່ຕິດຕັ້ງແລ້ວ"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ບໍ່ມີໃຫ້ໃຊ້ຈາກຄັງຊອບແວໃດໆ."
 ],
 "Downloading $0": [
  null,
  "ກຳລັງດາວໂຫຼດ $0"
 ],
 "Removing $0": [
  null,
  "ກຳລັງລຶບ $0 ອອກ"
 ],
 "Installing $0": [
  null,
  "ກຳລັງຕິດຕັ້ງ $0"
 ],
 "Unknown host: $0": [
  null,
  "ບໍ່ຮູ້ຈັກໂຮສຕ໌: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ດ້ວຍການຢືນຢັນຄີ SSH ໄດ້. ກະລຸນາລະບຸລະຫັດຜ່ານ."
 ],
 "SSH key login": [
  null,
  "ການເຂົ້າສູ່ລະບົບດ້ວຍຄີ SSH"
 ],
 "[no data]": [
  null,
  "[ບໍ່ມີຂໍ້ມູນ]"
 ],
 "[binary data]": [
  null,
  "[ຂໍ້ມູນໄບນາຣີ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ຂັດຂ້ອງ"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ລາຍງານລະຫັດຄວາມຜິດພາດ $0"
 ],
 "show less": [
  null,
  "ສະແດງໜ້ອຍລົງ"
 ],
 "show more": [
  null,
  "ສະແດງເພີ່ມເຕີມ"
 ],
 "Row expansion": [
  null,
  "ການຂະຫຍາຍແຖວ"
 ],
 "Row select": [
  null,
  "ເລືອກແຖວ"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ວາງ (Paste)"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ເກີດຄວາມຜິດພາດໃນການວາງ"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "ບຣາວເຊີຂອງທ່ານບໍ່ອະນຸຍາດໃຫ້ວາງຂໍ້ມູນຈາກເມນູຄລິກຂວາ. ທ່ານສາມາດໃຊ້ Shift+Insert ແທນ."
 ],
 "Error during initialization": [
  null,
  "ເກີດຂໍ້ຜິດພາດລະຫວ່າງການເລີ່ມຕົ້ນ"
 ],
 "Failed": [
  null,
  "ຫຼົ້ມເຫຼວ"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "ພິມເພື່ອທອງ"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "ບໍ່ພົບຜົນລັບທີ່ກົງກັນ"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "ກັອບປີ້ໄວ້ໃນຄລິບບອດ"
 ],
 "Automation script": [
  null,
  "ສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ສ້າງໄຟລ໌ວຽກໃໝ່ດ້ວຍເນື້ອຫານີ້."
 ],
 "Ansible roles documentation": [
  null,
  "ເອກະສານ Ansible roles"
 ],
 "Shell script": [
  null,
  "ສະຄຣິບເຊວ"
 ],
 "No system modifications": [
  null,
  "ບໍ່ມີການແກ້ໄຂລະບົບ"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເບິ່ງການປ່ຽນແປງລະບົບ"
 ],
 "Loading system modifications...": [
  null,
  "ກຳລັງໂຫຼດການປ່ຽນແປງຂອງລະບົບ..."
 ],
 "View automation script": [
  null,
  "ເບິ່ງສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Occurrences": [
  null,
  "ຈຳນວນການເກີດຂຶ້ນ"
 ],
 "View all logs": [
  null,
  "ເບິ່ງບັນທຶກທັງໝົດ"
 ],
 "Other": [
  null,
  "ອື່ນໆ"
 ],
 "Unknown": [
  null,
  "ບໍ່ຮູ້ຈັກ"
 ],
 "Desktop": [
  null,
  "ເດດທອບ"
 ],
 "Low profile desktop": [
  null,
  "Low profile desktop"
 ],
 "Pizza box": [
  null,
  "ພິດຊ່າບັອກ (Pizza box)"
 ],
 "Mini tower": [
  null,
  "ມິນິທາວເວີ (Mini tower)"
 ],
 "Tower": [
  null,
  "ທາວເວີ (Tower)"
 ],
 "Portable": [
  null,
  "ພົກພາໄດ້"
 ],
 "Laptop": [
  null,
  "ແລັບທອບ"
 ],
 "Notebook": [
  null,
  "ໂນ້ດບຸກ"
 ],
 "Handheld": [
  null,
  "ອຸປະກອນພົກພາ"
 ],
 "Docking station": [
  null,
  "ດັອກກິງສະເຕຊັນ"
 ],
 "All-in-one": [
  null,
  "ທັງໝົດໃນອັນດຽວ"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "ຄອມພິວເຕີແບບປະຢັດພື້ນທີ່"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Main server chassis"
 ],
 "Expansion chassis": [
  null,
  "Expansion chassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus expansion chassis"
 ],
 "Peripheral chassis": [
  null,
  "ໂຄງເຄື່ອງອຸປະກອນຕໍ່ພ່ວງ"
 ],
 "RAID chassis": [
  null,
  "ໂຄງເຄື່ອງ RAID"
 ],
 "Rack mount chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຕິດຕັ້ງໃນແຣັກ"
 ],
 "Sealed-case PC": [
  null,
  "ພີຊີແບບກ່ອງປິດ (Sealed-case PC)"
 ],
 "Multi-system chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຫຼາຍລະບົບ"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade enclosure"
 ],
 "Tablet": [
  null,
  "ແທັບເລັດ"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "ຖອດອອກໄດ້"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ຄອມພິວເຕີຝັງຕົວ"
 ],
 "Mini PC": [
  null,
  "ມິນິພີຊີ (Mini PC)"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "ບໍ່ມີຢູ່"
 ],
 "Present": [
  null,
  "ມີຢູ່"
 ],
 "Old password not accepted": [
  null,
  "ລະຫັດຜ່ານເກົ່າບໍ່ຖືກຍອມຮັບ"
 ],
 "Failed to change password": [
  null,
  "ບໍ່ສາມາດປ່ຽນລະຫັດຜ່ານໄດ້"
 ],
 "New password was not accepted": [
  null,
  "ລະຫັດຜ່ານໃໝ່ບໍ່ຖືກຍອມຮັບ"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ການຖາມຜ່ານ ssh-keygen ໝົດເວລາ"
 ],
 "Not a valid private key": [
  null,
  "ບໍ່ແມ່ນໄພຣເວດຄີ (private key) ທີ່ຖືກຕ້ອງ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ການຖາມຜ່ານ ssh-add ໝົດເວລາ"
 ],
 "Invalid file permissions": [
  null,
  "ການອະນຸຍາດໄຟລ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Password not accepted": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Select an option": [
  null,
  "ເລືອກຕົວເລືອກ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 ຖືກຢຸດດ້ວຍສັນຍານ $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 ອອກດ້ວຍລະຫັດ $1"
 ],
 "$0 failed": [
  null,
  "$0 ຫຼົ້ມເຫຼວ"
 ],
 "Your session has been terminated.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານຖືກສິ້ນສຸດແລ້ວ."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານໝົດອາຍຸແລ້ວ. ກະລຸນາເຂົ້າສູ່ລະບົບໃໝ່."
 ],
 "Not permitted to perform this action.": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຮັດການນີ້."
 ],
 "Login failed": [
  null,
  "ເຂົ້າສູ່ລະບົບບໍ່ສຳເລັດ"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "ເຊີເວີປະຕິເສດການຢືນຢັນຕົວຕົນດ້ວຍທຸກວິທີທີ່ຮອງຮັບ."
 ],
 "Untrusted host": [
  null,
  "ໂຮສຕ໌ທີ່ບໍ່ໜ້າເຊື່ອຖື"
 ],
 "Host key is incorrect": [
  null,
  "ຄີຂອງໂຮສຕ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Internal error": [
  null,
  "ຂໍ້ຜິດພາດພາຍໃນ"
 ],
 "Connection has timed out.": [
  null,
  "ການເຊື່ອມຕໍ່ໝົດເວລາ."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນລະບົບ."
 ],
 "Cannot forward login credentials": [
  null,
  "ບໍ່ສາມາດສົ່ງຕໍ່ຂໍ້ມູນການເຂົ້າລະບົບໄດ້"
 ],
 "Server has closed the connection.": [
  null,
  "ເຊີເວີໄດ້ປິດການເຊື່ອມຕໍ່ແລ້ວ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ບໍ່ເຂົ້າກັນໄດ້ກັບຊອບແວໃນລະບົບ."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ບໍ່ສາມາດຕິດຕໍ່ກັບໂຮສຕ໌ທີ່ລະບຸໄດ້."
 ],
 "Too much data": [
  null,
  "ຂໍ້ມູນຫຼາຍເກີນໄປ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console ສຳລັບ Linux ເຊີເວີ"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ແມ່ນລະບົບຈັດການເຊີເວີທີ່ຊ່ວຍໃຫ້ການບໍລິຫານເຊີເວີ Linux ຂອງທ່ານຜ່ານເວັບບຣາວເຊີເປັນເລື່ອງງ່າຍ. ທ່ານສາມາດສະຫຼັບການເຮັດວຽກລະຫວ່າງເທີມິນໍ ແລະ ເຄື່ອງມືເວັບໄດ້ຢ່າງສະດວກ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ແມ່ນເໝາະສົມສຳລັບຜູ້ດູແລລະບົບໃໝ່, ຊ່ວຍໃຫ້ດຳເນີນວຽກງ່າຍໆ ເຊັ່ນ ການຈັດການບ່ອນເກັບຂໍ້ມູນ, ກວດສອບລັອກ ແລະ ການຈັດການບໍລິການຕ່າງໆ."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "ເມື່ອຕິດຕັ້ງ Cockpit ແລ້ວ, ໃຫ້ເປີດໃຊ້ງານດ້ວຍຄຳສັ່ງ \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ການຕັ້ງຄ່າ NetworkManager ແລະ Firewalld ຂອງ Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການເຄືອຂ່າຍ ເຊັ່ນ bonds, bridges, teams, VLANs ແລະ ໄຟວໍ (firewalls) ໂດຍໃຊ້ NetworkManager ແລະ Firewalld."
 ],
 "Manage storage": [
  null,
  "ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນພາຍໃນເຄື່ອງ ເຊັ່ນ ລະບົບໄຟລ໌, LVM2 volume groups, ແລະ ການຕິດຕັ້ງ NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "ເກັບກຳ ແລະ ລວມແພັກເກດຂໍ້ມູນການວິເຄາະ ແລະ ການຊ່ວຍເຫຼືອ"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ສ້າງໄຟລ໌ເກັບຂໍ້ມູນການຕັ້ງຄ່າ ແລະ ຂໍ້ມູນການວິເຄາະຈາກລະບົບທີ່ກຳລັງເຮັດວຽກຢູ່. ຂໍ້ມູນເຫຼົ່ານີ້ອາດຖືກເກັບໄວ້ໃນເຄື່ອງ ຫຼື ສ່ວນກາງເພື່ອຈຸດປະສົງໃນການບັນທຶກ ຫຼື ຕິດຕາມ, ຫຼື ສົ່ງໃຫ້ຝ່າຍຊ່ວຍເຫຼືອທາງເຕັກນິກ, ນັກພັດທະນາ ຫຼື ຜູ້ດູແລລະບົບເພື່ອຊ່ວຍໃນການແກ້ໄຂບັນຫາ ແລະ ດີບັກ (debug)."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "ການຕັ້ງຄ່າ ແລະ ການແກ້ໄຂບັນຫາ Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່ານະໂຍບາຍ SELinux ແລະ ສາມາດຊ່ວຍໃນການເຂົ້າໃຈ ແລະ ແກ້ໄຂການລະເມີດນະໂຍບາຍໄດ້."
 ],
 "Collect kernel crash dumps": [
  null,
  "ເກັບກຳຂໍ້ມູນ kernel crash dumps"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່າລະບົບເພື່ອບັນທຶກ kernel crash dumps. ມັນຮອງຮັບເປົ້າໝາຍການເກັບແບບ \"local\" (ດິດ), \"ssh\", ແລະ \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ການບໍລິຫານດ້ວຍ Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "ຕ້ອງມີການຢືນຢັນຕົວຕົນເພື່ອດຳເນີນການວຽກທີ່ມີສິດພິເສດດ້ວຍ Cockpit Web Console"
 ]
});
