cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "kk",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
