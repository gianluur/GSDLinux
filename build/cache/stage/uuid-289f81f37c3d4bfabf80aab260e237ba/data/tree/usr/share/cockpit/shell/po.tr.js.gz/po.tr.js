cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "User name": [
  null,
  "Kullanıcı adı"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Comment": [
  null,
  "Yorum"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Fingerprint": [
  null,
  "Parmak izi"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Change password": [
  null,
  "Parolayı değiştir"
 ],
 "Password changed successfully": [
  null,
  "Parola başarılı olarak değiştirildi"
 ],
 "New password": [
  null,
  "Yeni parola"
 ],
 "Confirm password": [
  null,
  "Parolayı onayla"
 ],
 "Password tip": [
  null,
  "Parola ipucu"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "İpucu: Diğer sistemlerde otomatik olarak kimlik doğrulaması yapmak için anahtar parolanızın oturum açma parolanızla eşleşmesini sağlayın."
 ],
 "Unlock key $0": [
  null,
  "$0 anahtarı kilidini aç"
 ],
 "Unlock": [
  null,
  "Kilidi aç"
 ],
 "Add private SSH key": [
  null,
  "Özel SSH anahtarı ekle"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "SSH keys": [
  null,
  "SSH anahtarları"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Diğer sistemlerde kimlik doğrulamak için aşağıdaki anahtarları kullan"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Toggle": [
  null,
  "Değiştir"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Public key": [
  null,
  "Ortak anahtar"
 ],
 "Use key": [
  null,
  "Anahtar kullan"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Hosts": [
  null,
  "Anamakineler"
 ],
 "Connection error": [
  null,
  "Bağlantı hatası"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Add new host": [
  null,
  "Yeni anamakine ekle"
 ],
 "Host": [
  null,
  "Anamakine"
 ],
 "Stop editing hosts": [
  null,
  "Anamakineleri düzenlemeyi durdur"
 ],
 "Edit hosts": [
  null,
  "Anamakineleri düzenle"
 ],
 "active": [
  null,
  "etkin"
 ],
 "Active pages": [
  null,
  "Etkin sayfalar"
 ],
 "Page name": [
  null,
  "Sayfa adı"
 ],
 "There are currently no active pages": [
  null,
  "Şu anda etkin sayfalar yok"
 ],
 "Close selected pages": [
  null,
  "Seçilen sayfaları kapat"
 ],
 "$0 documentation": [
  null,
  "$0 belgeleleri"
 ],
 "About Web Console": [
  null,
  "Web Konsolu Hakkında"
 ],
 "Style": [
  null,
  "Stil"
 ],
 "Default": [
  null,
  "Varsayılan"
 ],
 "Light": [
  null,
  "Açık"
 ],
 "Dark": [
  null,
  "Koyu"
 ],
 "Display language": [
  null,
  "Görüntüleme dili"
 ],
 "Log out": [
  null,
  "Oturumu kapat"
 ],
 "Ooops!": [
  null,
  "Eyvah!"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Session": [
  null,
  "Oturum"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "GNU LGPL sürüm 2.1 altında lisanslıdır"
 ],
 "Web Console": [
  null,
  "Web Konsolu"
 ],
 "Web console logo": [
  null,
  "Web konsol logosu"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit, etkileşimli bir Linux sunucu yönetim arayüzüdür."
 ],
 "Project website": [
  null,
  "Proje web sitesi"
 ],
 "Loading packages...": [
  null,
  "Paketler yükleniyor..."
 ],
 "Choose the language to be used in the application": [
  null,
  "Uygulamada kullanılacak dili seçin"
 ],
 "Filter menu items": [
  null,
  "Menü öğelerini süz"
 ],
 "No languages match": [
  null,
  "Eşleşen diller yok"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "Unexpected error": [
  null,
  "Beklenmeyen hata"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit'te beklenmeyen bir iç hata oldu."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "çoğu tarayıcıda"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Search": [
  null,
  "Ara"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "Clear search": [
  null,
  "Aramayı temizle"
 ],
 "Contains:": [
  null,
  "İçerdikleri:"
 ],
 "Apps": [
  null,
  "Uygulamalar"
 ],
 "Tools": [
  null,
  "Araçlar"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Verilen $0 anamakinesiyle iletişim kurulamıyor. SSH hizmetinin $1 nolu bağlantı noktasında çalıştığından emin olun veya adreste başka bir bağlantı noktası belirtin."
 ],
 "Connect to $0?": [
  null,
  "$0 cihazına bağlansın mı?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Bağlı anamakineler birbirlerini tamamen denetleyebilir. Buna, sisteminize zarar verebilecek veya verileri çalabilecek programların çalıştırılması da dahildir. Yalnızca güvenilir makinelere bağlanın."
 ],
 "Read more": [
  null,
  "Devamını oku"
 ],
 "You will be reminded once per session.": [
  null,
  "Her oturumda size bir kez hatırlatılacaktır."
 ],
 "Connect": [
  null,
  "Bağlan"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP adresi veya anamakine adı boşluk karakteri içeremez."
 ],
 "This machine has already been added.": [
  null,
  "Bu makine zaten eklenmiş."
 ],
 "Failed to add machine: $0": [
  null,
  "Makine ekleme başarısız oldu: $0"
 ],
 "Edit host": [
  null,
  "Anamakineyi düzenle"
 ],
 "Set": [
  null,
  "Ayarla"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Bir anamakine adı, IP adresi, kod adı veya ssh:// URI olabilir"
 ],
 "When empty, connect with the current user": [
  null,
  "Boş olduğunda, şu anki kullanıcıyla bağlan"
 ],
 "Color": [
  null,
  "Renk"
 ],
 "Failed to edit machine: $0": [
  null,
  "Şu makineyi düzenleme başarısız oldu: $0"
 ],
 "Could not contact $0": [
  null,
  "$0 ile iletişim kurulamadı"
 ],
 "Update": [
  null,
  "Güncelle"
 ],
 "Unable to contact $0.": [
  null,
  "$0 ile bağlantı kurulamıyor."
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd farklı bir bağlantı noktasında mı çalışıyor?"
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "New host: $0": [
  null,
  "Yeni anamakine: $0"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Uzak bir makinedeki kötü amaçlı sayfalar bağlı diğer anamakineleri etkileyebilir"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "The new key password can not be empty": [
  null,
  "Yeni anahtar parolası boş olamaz"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 üzerinde oturum açılamıyor. Lütfen parolayı girin. Otomatik oturum açma için SSH anahtarlarınızı ayarlamak isteyebilirsiniz."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Otomatik oturum açmak için anahtarın parolasını değiştirmek isteyebilirsiniz."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Gelecekte $0 üzerinde parola olmadan $1 olarak oturum açmaya izin vermek için anahtar parolası olarak $3 üzerinde $2 kullanıcısının oturum açma parolasını kullanın veya anahtar parolasını boş bırakın."
 ],
 "Change the password of $0": [
  null,
  "$0 parolasını değiştir"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "$0 SSH anahtarının parolasını $2 üzerindeki $1 kullanıcısının oturum açma parolasıyla değiştirdiğinizde, anahtar otomatik olarak kullanılabilir hale getirilecek ve gelecekte parola olmadan $3 üzerinde oturum açabileceksiniz."
 ],
 "New key password": [
  null,
  "Yeni anahtar parolası"
 ],
 "Confirm new key password": [
  null,
  "Yeni anahtar parolasını onayla"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Bu, gelecekte parola olmadan oturum açmanıza izin verecek."
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "Automatic login": [
  null,
  "Otomatik oturum açma"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Etkinlik olmamasından dolayı oturumunuz kapatıldı."
 ],
 "Connection failed": [
  null,
  "Bağlantı başarısız oldu"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Makineye bağlanırken beklenmeyen bir hata oldu."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Hatayla ilgili iletiler günlükte bulunabilir:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari kullanıcılarının kendi kendine imzalanan CA sertifikasını içe aktarması ve ona güvenmesi gerekir:"
 ],
 "Reconnect": [
  null,
  "Yeniden bağlan"
 ],
 "Disconnected": [
  null,
  "Bağlantı kesildi"
 ],
 "The machine is rebooting": [
  null,
  "Makine yeniden başlatılıyor"
 ],
 "Connecting to the machine": [
  null,
  "Makineye bağlanılıyor"
 ],
 "Not connected to host": [
  null,
  "Anamakineye bağlı değil"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Bilinmeyen bir anamakineye bağlanılamıyor"
 ],
 "Session is about to expire": [
  null,
  "Oturumun süresi dolmak üzere"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "$0 saniye içinde oturumunuz kapatılacak."
 ],
 "Continue session": [
  null,
  "Oturuma devam et"
 ],
 "Skip to content": [
  null,
  "İçeriğe atla"
 ],
 "Skip main navigation": [
  null,
  "Ana gezinmeyi atla"
 ],
 "Permission denied": [
  null,
  "İzin reddedildi"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Yönetimsel erişim elde etmek için hiçbir yöntem mevcut değil (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit $0 hata kodunu bildirdi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Error during initialization": [
  null,
  "Başlatma sırasında hata"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Home": [
  null,
  "Giriş"
 ],
 "Downloads": [
  null,
  "İndirmeler"
 ],
 "Not a directory": [
  null,
  "Dizin değil"
 ],
 "All files": [
  null,
  "Tüm dosyalar"
 ],
 "Recent": [
  null,
  "En son"
 ],
 "No recent directories": [
  null,
  "Son dizinler yok"
 ],
 "No recent files": [
  null,
  "Son dosyalar yok"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "File chooser actions": [
  null,
  "Dosya seçici eylemleri"
 ],
 "Open in file browser": [
  null,
  "Dosya tarayıcısında aç"
 ],
 "Hide hidden files": [
  null,
  "Gizli dosyaları gizle"
 ],
 "Show hidden files": [
  null,
  "Gizli dosyaları göster"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Clear filters": [
  null,
  "Süzgeçleri temizle"
 ],
 "Directory is empty": [
  null,
  "Dizin boş"
 ],
 "Directory has no sub-directories": [
  null,
  "Dizin, alt dizinlere sahip değil"
 ],
 "This directory contains only hidden files": [
  null,
  "Bu dizin yalnızca gizli dosyaları içerir"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "Folder": [
  null,
  "Klasör"
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ]
});
