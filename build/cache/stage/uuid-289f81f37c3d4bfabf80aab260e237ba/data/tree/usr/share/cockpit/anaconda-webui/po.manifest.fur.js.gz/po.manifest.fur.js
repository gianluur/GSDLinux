cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fur",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
