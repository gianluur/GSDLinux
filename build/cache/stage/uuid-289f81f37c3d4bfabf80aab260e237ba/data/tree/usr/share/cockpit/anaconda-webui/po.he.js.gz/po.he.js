cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "התקנת $0"
 ],
 "$0 installer": [
  null,
  "תוכנית ההתקנה של $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 תימחק"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "מערכת הקבצים ‚$0’ לא יכולה להיות על התקן בלוק מוצפן"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "‚$0’ חייב להיות על התקן שמפורמט ל־‚$1’"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  "על אודות"
 ],
 "Account": [
  null,
  "חשבון"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Add mount": [
  null,
  "הוספת עיגון"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "כל השינויים שבוצעו בעורך אמצעי האחסון יחולו מיידית."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "כל ההתקנים שמשתמשים במילת הצופן הזאת ישוחררו"
 ],
 "Anaconda Web UI": [
  null,
  "מנשק דפדפן Anaconda"
 ],
 "Anaconda project page": [
  null,
  "דף מיזם Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "החלת הקצאת נקודת עיגון והתקנה"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "הקצאת מחיצות לנקודות עגינה. שימושי לפריסות מותאמות אישית שהוגדרו מראש."
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "מקום פנוי זמין: $0. דרישות ההתקנה: $1."
 ],
 "Back": [
  null,
  "חזרה"
 ],
 "Base environment": [
  null,
  "סביבת יסוד"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "תוך בחירה בהמשך שימוש בתוכנה זו, ברורות לך ומקובלות עליך הסכנות שכרוכות בתוכנה שטרם יצאה לאור, אותה ייעדת לשימוש למטרות בדיקות ופיתוח ולקחת על עצמך אחריות לדווח על תקלות או בעיות שצצות כדי לשפר את המערכת הזאת."
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Change": [
  null,
  "שינוי"
 ],
 "Change destination": [
  null,
  "החלפת יעד"
 ],
 "Change hostname": [
  null,
  "החלפת שם מארח"
 ],
 "Change system keyboard layout": [
  null,
  ""
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "שינויים שבוצעו כאן ישפיעו על המערכת ישירות. אי אפשר לסגת."
 ],
 "Checking storage configuration": [
  null,
  "הגדרות האחסון נבדקות"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "האחסון של Cockpit לא סיפק מילת צופן לשחרור ההתקן המוצפן."
 ],
 "Completed": [
  null,
  "הושלם"
 ],
 "Configure NTP servers": [
  null,
  "הגדרת שרתי NTP"
 ],
 "Configure storage": [
  null,
  "הגדרת אחסון"
 ],
 "Configure storage again": [
  null,
  "הגדרת האחסון שוב"
 ],
 "Confirm passphrase": [
  null,
  "אישור מילת צופן"
 ],
 "Continue": [
  null,
  "המשך"
 ],
 "Continue installation": [
  null,
  "להמשיך להתקין"
 ],
 "Continue with installation": [
  null,
  "להמשיך בהתקנה"
 ],
 "Create Account": [
  null,
  "יצירת חשבון"
 ],
 "Create account": [
  null,
  "יצירת חשבון"
 ],
 "Currently installed: $0": [
  null,
  "מותקן כרגע: $0"
 ],
 "Custom": [
  null,
  "מותאם אישית"
 ],
 "Date": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "מחיקה של מחיצות מסוימות עלולה לפגום בעלייה של $0:‏ $1"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Destination": [
  null,
  "יעד"
 ],
 "Detected valid storage layout:": [
  null,
  "זוהתה פריסת אחסון תקפה:"
 ],
 "Device": [
  null,
  "התקן"
 ],
 "Duplicate device.": [
  null,
  "התקן כפול."
 ],
 "Duplicate mount point.": [
  null,
  "נקודת עגינה כפולה."
 ],
 "Enable root account": [
  null,
  "הפעלת חשבון root"
 ],
 "Encrypt my data": [
  null,
  "הצפנת הנתונים שלי"
 ],
 "Encrypted": [
  null,
  "מוצפן"
 ],
 "Encryption": [
  null,
  "הצפנה"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "מחיקת הנתונים והתקנה"
 ],
 "Error details": [
  null,
  "פרטי השגיאה"
 ],
 "Exit to live desktop": [
  null,
  "יציאה לשולחן העבודה החי"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "לינוקס פדורה דורש לפחות $0 של מקום פנוי בכונן."
 ],
 "Finalization": [
  null,
  "סיום"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "סיום: הגדרת המערכת הושלמה. סיום ההתקנה עשוי לארוך מספר רגעים."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "שם מלא"
 ],
 "Full name cannot contain colon characters": [
  null,
  "השם המלא לא יכול להכיל את התו נקודתיים"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "הסתרת סיסמה שאושרה"
 ],
 "Hide passphrase": [
  null,
  "הסתרת מילת צופן"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Hostname": [
  null,
  "שם מארח"
 ],
 "How would you like to install?": [
  null,
  "איך להתקין?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "ברור לי שחלק מהנתונים הקיימים יימחקו"
 ],
 "I understand that some partitions will be modified": [
  null,
  "ברור לי שחלק מהמחיצות ישתנו"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "אם יישאר ריק, שם המארח יהיה ארעי ויוגדר על ידי פרטים מהרשת."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "אם בחרת להגדיר מחיצות צריך גם:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "נא לצאת מהתוכנית אם לא הבנת או קיבלת את הסיכונים."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "בתהליך"
 ],
 "Initializing...": [
  null,
  "מופעל…"
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Installation failed": [
  null,
  "ההתקנה נכשלה"
 ],
 "Installation method": [
  null,
  "שיטת התקנה"
 ],
 "Installation of the system failed: $0": [
  null,
  "התקנת המערכת נכשלה: $0"
 ],
 "Installation type": [
  null,
  "סוג התקנה"
 ],
 "Installing": [
  null,
  "התקנה מתבצעת"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "לשמור על פריסת הכונן הנוכחית ולהשתמש במקום הפנוי כדי לאפשר עלייה בררנית עם מערכת הפעלה אחרת."
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  "שפה"
 ],
 "Launch storage editor": [
  null,
  "הפעלת עורך אחסון"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "מיקום"
 ],
 "Locked devices": [
  null,
  "התקנים נעולים"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "הגדרות כונן ידניות"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "הגדרות כונן ידניות: מיפוי נקודות עיגון"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "יכול להכיל אותיות, מספרים ומינוסים."
 ],
 "Medium": [
  null,
  "בינונית"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "חוסר התאמה בין בחירת הפרמוט המחודש של התקן ההורה והתקן הצאצא."
 ],
 "Mount point": [
  null,
  "נקודת עיגון"
 ],
 "Mount point assignment": [
  null,
  "הקצאה של נקודות עיגון"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "חייב להיות לפחות $0 תווים"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "Name": [
  null,
  "שם"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "רשת"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "הרשת לא זמינה. יש להגדיר את הרשת מהתפריט בסרגל העליון כדי לדווח על התקלה הזאת."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "הרשת לא זמינה. יש להגדיר את הרשת כדי לדווח על התקלה הזאת."
 ],
 "Next": [
  null,
  "הבא"
 ],
 "No devices": [
  null,
  "אין התקנים"
 ],
 "No disks available": [
  null,
  "אין כוננים זמינים"
 ],
 "No disks selected": [
  null,
  "לא נבחרו כוננים"
 ],
 "No results found": [
  null,
  "אין תוצאות"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  "אין די מקום פנוי בכוננים שנבחרו."
 ],
 "Not enough space on selected disks.": [
  null,
  "אין די מקום בכוננים שנבחרו."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "לתשומת ליבך: זוהי תוכנה שטרם שוחררה ומיועדת למטרות פיתוח ובדיקה בלבד. אין להשתמש בתוכנה זו לעבודות חשובות או בסביבות ייצור."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "מערכת הפעלה"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Partitions (advanced)": [
  null,
  "מחיצות (מתקדם)"
 ],
 "Passphrase": [
  null,
  "מילת צופן"
 ],
 "Passphrase did not match any locked device": [
  null,
  "מילת הצופן לא מתאימה לאף התקן נעול"
 ],
 "Passphrases must match": [
  null,
  "מילות הצופן חייבות להיות תואמות"
 ],
 "Pending": [
  null,
  "בהמתנה"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "נא להצמיד את קוב היומן ‎$0 לדיווח."
 ],
 "Pool": [
  null,
  "בריכה"
 ],
 "Powered by Anaconda": [
  null,
  "מופעל על גבי אנקונדה"
 ],
 "Pre-release": [
  null,
  "קדם־שחרור"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "המשך בהתקנה"
 ],
 "Quit": [
  null,
  "י_ציאה"
 ],
 "Quit installer?": [
  null,
  "לצאת מתוכנית ההתקנה?"
 ],
 "Reading information about the OS failed.": [
  null,
  "קריאת המידע על מערכת ההפעלה נכשלה."
 ],
 "Reading information about the computer failed.": [
  null,
  "קריאת המידע על המחשב נכשלה."
 ],
 "Reading installer configuration failed.": [
  null,
  "קריאת הגדרות תוכנית ההתקנה נכשלה."
 ],
 "Reading installer version information failed.": [
  null,
  "קריאת פרטי גרסה תוכנית ההתקנה נכשלה."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "שם מארח אמיתי יכול להכיל רק תווים, ספרות, מינוסים (לא בהתחלה או בסוף) ונקודות"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "שם המארח האמיתי חייב להיות באורך 64 תווים או פחות"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Reboot system?": [
  null,
  "להפעיל את המערכת מחדש?"
 ],
 "Reclaim additional space": [
  null,
  "השבת נפח נוסף"
 ],
 "Reclaim space": [
  null,
  "השבת נפח"
 ],
 "Reclaim space (required)": [
  null,
  "השבת נפח (חובה)"
 ],
 "Recommended": [
  null,
  "מומלץ"
 ],
 "Recommended partitions:": [
  null,
  "מחיצות מומלצות:"
 ],
 "Reformat": [
  null,
  "פרמוט מחדש"
 ],
 "Reinstall Fedora": [
  null,
  "התקנת פדורה מחדש"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "להסיר את כל המחיצות בהתקנים הנבחרים, כולל מערכות הפעלה קיימות."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "להסיר או לשנות מערכות קבצים קיימות כדי לפנות מקום להתקנה."
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "החלפת ההתקנה הנוכחית אבל לשמור את הקבצים שבתיקיית הבית (home)."
 ],
 "Report Issue": [
  null,
  "דיווח על תקלה"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "דיווח על תקלה"
 ],
 "Required": [
  null,
  "חובה"
 ],
 "Requirements": [
  null,
  "דרישות"
 ],
 "Rescan devices": [
  null,
  "סריקת התקנים מחדש"
 ],
 "Rescanning of the disks failed.": [
  null,
  "סריקת הכוננים מחדש נכשלה."
 ],
 "Resize": [
  null,
  "שינוי גודל"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "הגודל של המחיצות הבאות ישתנה מ־$0:‏ $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "חזרה להתקנה"
 ],
 "Return to storage editor": [
  null,
  "חזרה לעורך האחסון"
 ],
 "Review and install": [
  null,
  "סקירה והתקנה"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  "סיסמת מנהל המערכת (root) הוגדרה."
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "אפשר לסרוק את קוד ה־QR עם הטלפון שלך או לבקר באתר:"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "אפשר להגן על הנתונים שלך עם הצפנה מבוססת כונן. חל רק על מחיצות חדשות"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Select a device": [
  null,
  "נא לבחור התקן"
 ],
 "Select destination": [
  null,
  "בחירת יעד"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "לא ניתן לפרמט מחדש את תצורת הכונן הנבחרת ‚$0’."
 ],
 "Send us feedback on your installation": [
  null,
  "שליחת משוב על ההתקנה שלך"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "הגדרת שם מארח משלך"
 ],
 "Show confirmed password": [
  null,
  "הצגת סיסמה שאושרה"
 ],
 "Show passphrase": [
  null,
  "הצגת מילת צופן"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Software installation": [
  null,
  "התקנת תוכנות"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "התקנת תוכנות: הגדרת האחסון הושלמה. התוכנות מותקנות כעת במכשיר שלך."
 ],
 "Software selection": [
  null,
  "בחירת תכנה"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "חלק מהמחיצות הנחוצות חסרות: $0"
 ],
 "Space": [
  null,
  "מקום"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Storage configuration": [
  null,
  "הגדרות אחסון"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "הגדרות אחסון: האחסון מוגדר כרגע."
 ],
 "Storage editor": [
  null,
  "עורך האחסון"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "האחסון מבוסס על ההגדרות מ‚שינוי אחסון’."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "תוסף האחסון נכשל"
 ],
 "Storage requirements not met": [
  null,
  "דרישות האחסון לא מתקיימות"
 ],
 "Strong": [
  null,
  "חזק"
 ],
 "Successfully installed": [
  null,
  "ההתקנה הצליחה"
 ],
 "Successfully unlocked $0.": [
  null,
  "השחרור של $0 הצליח."
 ],
 "System": [
  null,
  "מערכת"
 ],
 "System configuration": [
  null,
  "הגדרות מערכת"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "הגדרות מערכת: התקנת התוכנות הושלמה. המערכת מוגדרת כעת."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "תוכנית ההתקנה לא תוכל להמשיך עקב תקלה משמעותית."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "תוכנית ההתקנה לא תוכל להמשיך עקב שגיאה משמעותית: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "מילת הצופן שסיפקת מכילה תווים מחוץ לטווח ה־ASCII. יתכן שלא תהיה לך אפשרות להחליף בין פריסות מקלדת בזמן ההקלדה."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "אי אפשר להגיש את שם המשתמש הזה"
 ],
 "This is unstable, pre-release software": [
  null,
  "זו תוכנה בלתי יציבה, לפני יציאה לאור"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "פעולה זו עלולה לארוך זמן מה"
 ],
 "This will take a few moments": [
  null,
  "הפעולה הזאת יכולה לארוך מספר רגעים"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "כדי להתחיל להשתמש ב־$0, יש להפעיל את המערכת מחדש."
 ],
 "To continue, select the devices to install to.": [
  null,
  "כדי להמשיך, נא לבחור את ההתקן להתקנה אליו."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "כדי להשתמש באפשרות הזאת, יש לשנות גודל או להסיר מחיצות קיימות כדי לפנות לפחות $0."
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "לא ניתן לתזמן את המחיקה של $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "לא ניתן תזמן את שינוי הגודל של $0"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Unlock encrypted devices": [
  null,
  "שחרור התקנים מוצפנים"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "Use configured storage": [
  null,
  "להשתמש באחסון המוגדר"
 ],
 "Use entire disk": [
  null,
  "להשתמש בכונן כולו"
 ],
 "User creation": [
  null,
  "יצירה של משתמשים"
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "שם משתמש יכול להכיל רק: אותיות מ־a עד z, ספרות מ־0 עד 9, מינוס $0, נקודה $1, קו תחתי $2"
 ],
 "User name must not be a reserved word": [
  null,
  "שם המשתמש לא יכול להיות מילה שמורה"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "שמות המשתמשים חייבים להיות קצרים מ־33 תווים"
 ],
 "Weak": [
  null,
  "חלש"
 ],
 "Welcome": [
  null,
  "ברוך בואך"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "ברוך בואך. עכשיו נתקין את $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "אי אפשר לשנות גודל של מחיצות Windows עם הצפנת BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "אפשר לפנות מספיק מקום כאן ולאפשר להתקנה לטפל בשאר או להגדיר מחיצות ידנית."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "התהליך שעברת לא יישמר."
 ],
 "completed step": [
  null,
  "שלב שהושלם"
 ],
 "current step": [
  null,
  "שלב נוכחי"
 ],
 "delete": [
  null,
  "מחיקה"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "encrypt": [
  null,
  "הצפנה"
 ],
 "encrypted": [
  null,
  "מוצפן"
 ],
 "format as $0": [
  null,
  "פרמוט ל־$0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "pending step": [
  null,
  "שלב בהמתנה"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "הגודל השתנה מ־$0"
 ],
 "shrink": [
  null,
  "כיווץ"
 ],
 "shrink to $0": [
  null,
  "כיווץ לכדי $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "ביטול"
 ]
});
