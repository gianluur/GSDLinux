cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "hr",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  ""
 ],
 "$0 ($1)": [
  null,
  ""
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  "",
  ""
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  ""
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  ""
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  ""
 ],
 "Applying changes...": [
  null,
  ""
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  ""
 ],
 "Back": [
  null,
  "Natrag"
 ],
 "Base environment": [
  null,
  "Osnovno okruženje"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Nastavkom korištenja ovog softvera, shvaćate i prihvaćate rizike povezane s predizdanjem softvera, slažete se s korištenjem ovog softvera samo u razvojne svrhe i testiranje, voljni ste prijaviti bilo kakvu grešku kako bi nam olakšali poboljšanje ovog uratka."
 ],
 "Change system keyboard layout": [
  null,
  ""
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  ""
 ],
 "Clear search": [
  null,
  ""
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Zatvori"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  ""
 ],
 "Completed": [
  null,
  "Završeno"
 ],
 "Configure NTP servers": [
  null,
  "Podesi NTP poslužitelje"
 ],
 "Continue": [
  null,
  "Nastavi"
 ],
 "Date": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  ""
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Detected valid storage layout:": [
  null,
  ""
 ],
 "Device": [
  null,
  "Uređaj"
 ],
 "Encryption": [
  null,
  "Šifriranje"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Exit to live desktop": [
  null,
  ""
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  ""
 ],
 "Finalization": [
  null,
  "Finalizacija"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizacija: podešavanje sustava je završeno. Finalizacija instalacije može potrajati nekoliko trenutaka."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Puno ime"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Puno ime ne može sadržavati dvotočke"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "I understand that all existing data will be erased": [
  null,
  "",
  "",
  ""
 ],
 "I understand that some existing data will be erased": [
  null,
  ""
 ],
 "I understand that some partitions will be modified": [
  null,
  ""
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  ""
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  ""
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ako ne shvaćate ili ne prihvaćate rizike, tada zatvorite ovaj program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "U tijeku"
 ],
 "Install": [
  null,
  "Instaliraj"
 ],
 "Installation failed": [
  null,
  "Instalacija neuspjela"
 ],
 "Installing": [
  null,
  "Instalacija"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  ""
 ],
 "Keyboard": [
  null,
  "Tipkovnica"
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  "Jezik"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Lokacija"
 ],
 "Make current": [
  null,
  ""
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "Medium": [
  null,
  ""
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  ""
 ],
 "Mount point": [
  null,
  "Točka montiranja"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "Name": [
  null,
  "Naziv"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Mreža"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  ""
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  ""
 ],
 "Next": [
  null,
  ""
 ],
 "No disks selected": [
  null,
  "Nema odabranih diskova"
 ],
 "No results found": [
  null,
  "Nema pronađenih rezultata"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Napomena: ovo predizdanje softvera namijenjeno je za razvoj i testiranje. Ne koristite ovaj softver za bilo kakav kritičan rad ili za proizvodno okruženje."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Options": [
  null,
  "Mogućnosti"
 ],
 "Partitions (advanced)": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  "Lozinka"
 ],
 "Passphrase did not match any locked device": [
  null,
  ""
 ],
 "Pending": [
  null,
  "Čekanje"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  ""
 ],
 "Pool": [
  null,
  "Skup"
 ],
 "Powered by Anaconda": [
  null,
  ""
 ],
 "Pre-release": [
  null,
  "Predizdanje"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Quit": [
  null,
  "Zatvori"
 ],
 "Reading information about the computer failed.": [
  null,
  ""
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Ponovno pokreni"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Recommended": [
  null,
  ""
 ],
 "Recommended partitions:": [
  null,
  ""
 ],
 "Reformat": [
  null,
  "Ponovno formatiraj"
 ],
 "Remove": [
  null,
  "Ukloni"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  ""
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  ""
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  ""
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Review and install": [
  null,
  "Pregledajte i instalirajte"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  "Korijenska lozinka je postavljena."
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  ""
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  ""
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  ""
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Share disk with other operating systems": [
  null,
  ""
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Size": [
  null,
  ""
 ],
 "Software installation": [
  null,
  "Instalacija softvera"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalacija softvera: Podešavanje uređaja pohrane je završena. Softver se trenutno instalira na vaš uređaj."
 ],
 "Software selection": [
  null,
  "Odabir softvera"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  ""
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage configuration": [
  null,
  "Podešavanje uređaja pohrane"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Podešavanje uređaja pohrane. Uređaj pohrane se trenutno podešava."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage requirements not met": [
  null,
  ""
 ],
 "Strong": [
  null,
  "Snažna"
 ],
 "Successfully installed": [
  null,
  ""
 ],
 "Successfully unlocked $0.": [
  null,
  ""
 ],
 "System configuration": [
  null,
  "Podešavanje sustava"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Podešavanje sustava: Instalacija softvera je završena. Sustav se trenutno podešava."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Lozinku koji ste upisali sadrži ne-ASCII znakove. Možda nećete moći prebacivati između rasporeda tipkovnica pri tipkanju."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This is unstable, pre-release software": [
  null,
  "Ovo je nestabilno, predizdanje softvera"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "Ovo može kratko potrajati"
 ],
 "Title": [
  null,
  ""
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  ""
 ],
 "Type": [
  null,
  "Vrsta"
 ],
 "Unable to schedule deletion of $0": [
  null,
  ""
 ],
 "Unable to schedule resizing of $0": [
  null,
  ""
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "User creation": [
  null,
  "Stvaranje korisnika"
 ],
 "User name": [
  null,
  "Korisničko ime"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  ""
 ],
 "Weak": [
  null,
  "Slaba"
 ],
 "Welcome": [
  null,
  "Dobrodošli"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  ""
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  ""
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  ""
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  ""
 ],
 "completed step": [
  null,
  "korak završen"
 ],
 "current step": [
  null,
  "trenutni korak"
 ],
 "edit": [
  null,
  ""
 ],
 "here": [
  null,
  ""
 ],
 "pending step": [
  null,
  "korak na čekanju"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink to $0": [
  null,
  ""
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  ""
 ]
});
