cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
