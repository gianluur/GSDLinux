cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "ຄີທີ່ປ່ຽນແປງມັກຈະເກີດຈາກການຕິດຕັ້ງລະບົບປະຕິບັດການໃໝ່. ຢ່າງໃດກໍຕາມ, ການປ່ຽນແປງທີ່ບໍ່ຄາດຄິດອາດໝາຍເຖິງການພະຍາຍາມແຊກແຊງການເຊື່ອມຕໍ່ຂອງທ່ານຈາກບຸກຄົນທີສາມ."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "ເພື່ອໃຫ້ແນ່ໃຈວ່າການເຊື່ອມຕໍ່ຂອງທ່ານບໍ່ຖືກດັກຟັງໂດຍບຸກຄົນທີສາມ, ກະລຸນາກວດສອບລາຍນິ້ວມືຂອງຄີໂຮສຕ໌:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ."
 ],
 "Password": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "Log in": [
  null,
  "ເຂົ້າສູ່ລະບົບ"
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Services": [
  null,
  "ບັນດາບໍລິການ"
 ],
 "Journal": [
  null,
  "ເຈີເນິລ"
 ],
 "Terminal": [
  null,
  "ເທີມີນໍ (Terminal)"
 ],
 "Hardware information": [
  null,
  "ຂໍ້ມູນຮາດແວ"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Type": [
  null,
  "ປະເພດ"
 ],
 "Copy": [
  null,
  "ກັອບປີ້"
 ],
 "Copied": [
  null,
  "ກັອບປີ້ແລ້ວ"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Details": [
  null,
  "ລາຍລະອຽດ"
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Remove": [
  null,
  "ລຶບອອກ"
 ],
 "active": [
  null,
  "ກຳລັງເຮັດວຽກ"
 ],
 "Default": [
  null,
  "ຄ່າເລີ່ມຕົ້ນ"
 ],
 "Light": [
  null,
  "ສະຫວ່າງ"
 ],
 "Dark": [
  null,
  "ມືດ"
 ],
 "Help": [
  null,
  "ຊ່ວຍເຫຼືອ"
 ],
 "Select": [
  null,
  "ເລືອກ"
 ],
 "System": [
  null,
  "ລະບົບ"
 ],
 "Search": [
  null,
  "ຄົ້ນຫາ"
 ],
 "No results found": [
  null,
  "ບໍ່ພົບຜົນລັບ"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "ເວີຊັນຂອງ Cockpit ທີ່ເຂົ້າກັນໄດ້ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນ $0."
 ],
 "Add": [
  null,
  "ເພີ່ມ"
 ],
 "$0 key changed": [
  null,
  "ຄີ $0 ປ່ຽນແປງແລ້ວ"
 ],
 "Trust and add host": [
  null,
  "ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ເພື່ອການກວດສອບລາຍນິ້ວມື, ໃຫ້ຮັນຄຳສັ່ງຕໍ່ໄປນີ້ໃນ $0 ໃນຂະນະທີ່ຢູ່ໜ້າເຄື່ອງ ຫຼື ຜ່ານເຄືອຂ່າຍທີ່ໜ້າເຊື່ອຖື:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "ຖ້າລາຍນິ້ວມືກົງກັນ, ກົດ 'ເຊື່ອຖື ແລະ ເພີ່ມໂຮສຕ໌'. ຖ້າບໍ່ດັ່ງນັ້ນ, ຫ້າມເຊື່ອມຕໍ່ ແລະ ຕິດຕໍ່ຜູ້ດູແລລະບົບຂອງເຈົ້າ."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "ລາຍນິ້ວມືທີ່ໄດ້ສາມາດແບ່ງປັນຜ່ານຊ່ອງທາງສາທາລະນະໄດ້, ລວມທັງອີເມລ. ຖ້າທ່ານໃຫ້ຄົນອື່ນກວດສອບໃຫ້, ເຂົາເຈົ້າສາມາດສົ່ງຜົນການກວດສອບໃຫ້ທ່ານດ້ວຍວິທີໃດກໍໄດ້."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "ທ່ານກຳລັງເຊື່ອມຕໍ່ຫາ $0 ເປັນຄັ້ງທຳອິດ."
 ],
 "Verify fingerprint": [
  null,
  "ກວດສອບລາຍນິ້ວມື"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "ຣັນຄຳສັ່ງນີ້ຜ່ານເຄືອຂ່າຍທີ່ເຊື່ອຖືໄດ້ ຫຼື ຣັນຢູ່ເຄື່ອງປາຍທາງໂດຍກົງ:"
 ],
 "The fingerprint should match:": [
  null,
  "ລາຍນິ້ວມື (Fingerprint) ຄວນຈະກົງກັບ:"
 ],
 "The password can not be empty": [
  null,
  "ລະຫັດຜ່ານບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key password can not be empty": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "The key passwords do not match": [
  null,
  "ລະຫັດຜ່ານຂອງຄີບໍ່ກົງກັນ"
 ],
 "Log in to $0": [
  null,
  "ເຂົ້າສູ່ລະບົບ $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ໄດ້. ໂຮສຕ໌ບໍ່ຍອມຮັບການເຂົ້າລະບົບດ້ວຍລະຫັດຜ່ານ ຫຼື ຄີ SSH ໃດໆຂອງທ່ານ."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ແມ່ນຖືກປ້ອງກັນດ້ວຍລະຫັດຜ່ານ, ແລະ ໂຮສຕ໌ບໍ່ອະນຸຍາດໃຫ້ເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານ. ກະລຸນາລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "ຄີ SSH ສຳລັບເຂົ້າສູ່ລະບົບ $0 ຖືກປ້ອງກັນໄວ້. ທ່ານສາມາດເຂົ້າສູ່ລະບົບດ້ວຍລະຫັດຜ່ານຂອງທ່ານ ຫຼື ລະບຸລະຫັດຜ່ານຂອງຄີຢູ່ $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ສ້າງ SSH ຄີໃໝ່ ແລະ ອະນຸຍາດມັນ"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "SSH ຄີໃໝ່ຢູ່ $0 ຈະຖືກສ້າງຂຶ້ນສຳລັບ $1 ຢູ່ $2 ແລະ ມັນຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Key password": [
  null,
  "ລະຫັດຜ່ານຄີ"
 ],
 "Confirm key password": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານຂອງຄີ"
 ],
 "Authorize SSH key": [
  null,
  "ອະນຸຍາດ SSH ຄີ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "ຄີ SSH $0 ຂອງ $1 ຢູ່ $2 ຈະຖືກເພີ່ມເຂົ້າໃນໄຟລ໌ $3 ຂອງ $4 ຢູ່ $5."
 ],
 "Authentication": [
  null,
  "ການຢືນຢັນຕົວຕົນ"
 ],
 "SSH key": [
  null,
  "ຄີ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "ຄີ SSH $0 ຈະສາມາດໃຊ້ໄດ້ຕະຫຼອດວາລະການໃຊ້ງານທີ່ເຫຼືອ ແລະ ຈະສາມາດໃຊ້ເຂົ້າສູ່ລະບົບໂຮສຕ໌ອື່ນໆໄດ້ຄືກັນ."
 ],
 "Permission denied": [
  null,
  "ການອະນຸຍາດຖືກປະຕິເສດ"
 ],
 "Clear input value": [
  null,
  "ລຶບຄ່າທີ່ປ້ອນເຂົ້າ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "ຮູບແບບວັນທີ ແລະ ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid time format": [
  null,
  "ຮູບແບບເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Invalid date format": [
  null,
  "ຮູບແບບວັນທີບໍ່ຖືກຕ້ອງ"
 ],
 "Cannot schedule event in the past": [
  null,
  "ບໍ່ສາມາດຕັ້ງເວລາໃນອະດີດໄດ້"
 ],
 "No delay": [
  null,
  "ບໍ່ມີການຊັກຊ້າ"
 ],
 "1 minute": [
  null,
  "1 ນາທີ"
 ],
 "5 minutes": [
  null,
  "5 ນາທີ"
 ],
 "20 minutes": [
  null,
  "20 ນາທີ"
 ],
 "40 minutes": [
  null,
  "40 ນາທີ"
 ],
 "60 minutes": [
  null,
  "60 ນາທີ"
 ],
 "Specific time": [
  null,
  "ເວລາສະເພາະ"
 ],
 "Shut down": [
  null,
  "ປິດເຄື່ອງ"
 ],
 "Reboot": [
  null,
  "ບູດເຄື່ອງໃໝ່"
 ],
 "Message to logged in users": [
  null,
  "ຂໍ້ຄວາມເຖິງຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບຢູ່"
 ],
 "Delay": [
  null,
  "ການໜ່ວງເວລາ"
 ],
 "Pick date": [
  null,
  "ເລືອກວັນທີ"
 ],
 "Toggle date picker": [
  null,
  "ເປີດ-ປິດ ຕົວເລືອກວັນທີ"
 ],
 "Synchronized": [
  null,
  "ຊິງໂຄຣໄນຊ໌ແລ້ວ"
 ],
 "Synchronized with $0": [
  null,
  "ຊິງໂຄຣໄນຊ໌ກັບ $0 ແລ້ວ"
 ],
 "Synchronizing": [
  null,
  "ກຳລັງຊິງໂຄຣໄນຊ໌"
 ],
 "Trying to synchronize with $0": [
  null,
  "ກຳລັງພະຍາຍາມຊິງໂຄຣໄນຊ໌ກັບ $0"
 ],
 "Not synchronized": [
  null,
  "ບໍ່ໄດ້ຊິງໂຄຣໄນຊ໌"
 ],
 "Log messages": [
  null,
  "ຂໍ້ຄວາມລັອກ"
 ],
 "NTP server": [
  null,
  "ເຊີບເວີ NTP"
 ],
 "Manually": [
  null,
  "ດ້ວຍຕົນເອງ"
 ],
 "Automatically using NTP": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍ NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ເພີ່ມເຕີມ"
 ],
 "Automatically using specific NTP servers": [
  null,
  "ໃຊ້ອັດຕະໂນມັດໂດຍໃຊ້ເຊີເວີ NTP ທີ່ລະບຸ"
 ],
 "Time zone": [
  null,
  "ເຂດເວລາ"
 ],
 "Set time": [
  null,
  "ຕັ້ງເວລາ"
 ],
 "Invalid timezone": [
  null,
  "ເຂດເວລາບໍ່ຖືກຕ້ອງ"
 ],
 "Need at least one NTP server": [
  null,
  "ຕ້ອງການເຊີບເວີ NTP ຢ່າງໜ້ອຍໜຶ່ງຕົວ"
 ],
 "Change system time": [
  null,
  "ປ່ຽນເວລາຂອງລະບົບ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Path to file": [
  null,
  "ເສັ້ນທາງໄປຫາໄຟລ໌"
 ],
 "No such file or directory": [
  null,
  "ບໍ່ມີໄຟລ໌ ຫຼື ໄດເຣັກທໍຣີນີ້"
 ],
 "Create $0": [
  null,
  "ສ້າງ $0"
 ],
 "Ok": [
  null,
  "ຕົກລົງ"
 ],
 "Learn more": [
  null,
  "ຮຽນຮູ້ເພີ່ມເຕີມ"
 ],
 "You now have administrative access.": [
  null,
  "ດຽວນີ້ທ່ານມີສິດເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບແລ້ວ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ບໍ່ມີວິທີການເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ກະລຸນາຢືນຢັນຕົວຕົນເພື່ອເຂົ້າເຖິງສິດຜູ້ດູແລລະບົບ"
 ],
 "Switch to administrative access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "Authenticate": [
  null,
  "ຢືນຢັນຕົວຕົນ"
 ],
 "Administrative access": [
  null,
  "ສິດການບໍລິຫານ"
 ],
 "Problem becoming administrator": [
  null,
  "ມີບັນຫາໃນການກາຍເປັນຜູ້ດູແລລະບົບ"
 ],
 "Method": [
  null,
  "ວິທີການ"
 ],
 "Limit access": [
  null,
  "ຈຳກັດການເຂົ້າເຖິງ"
 ],
 "Switch to limited access": [
  null,
  "ປ່ຽນເປັນການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "ໂໝດການເຂົ້າເຖິງແບບຈຳກັດຈະຈຳກັດສິດຜູ້ດູແລລະບົບ. ບາງສ່ວນຂອງເວັບຄອນໂຊນຈະມີຟັງຊັນການເຮັດວຽກທີ່ຫຼຸດລົງ."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ບຣາວເຊີຂອງທ່ານຈະຈົດຈຳລະດັບການເຂົ້າເຖິງຂອງທ່ານໄວ້."
 ],
 "Limited access": [
  null,
  "ການເຂົ້າເຖິງແບບຈຳກັດ"
 ],
 "Turn on administrative access": [
  null,
  "ເປີດການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ"
 ],
 "$0 year": [
  null,
  "$0 ປີ"
 ],
 "$0 month": [
  null,
  "$0 ເດືອນ"
 ],
 "$0 week": [
  null,
  "$0 ອາທິດ"
 ],
 "$0 day": [
  null,
  "$0 ມື້"
 ],
 "$0 hour": [
  null,
  "$0 ຊົ່ວໂມງ"
 ],
 "$0 minute": [
  null,
  "$0 ນາທີ"
 ],
 "Go to now": [
  null,
  "ໄປທີ່ປັດຈຸບັນ"
 ],
 "1 hour": [
  null,
  "1 ຊົ່ວໂມງ"
 ],
 "6 hours": [
  null,
  "6 ຊົ່ວໂມງ"
 ],
 "1 day": [
  null,
  "1 ມື້"
 ],
 "1 week": [
  null,
  "1 ອາທິດ"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານ $0 ໃນ firewalld ໄດ້"
 ],
 "Visit firewall": [
  null,
  "ໄປທີ່ໄຟວໍ"
 ],
 "Zone": [
  null,
  "ໂຊນ"
 ],
 "Add $0": [
  null,
  "ເພີ່ມ $0"
 ],
 "less than a minute ago": [
  null,
  "ບໍ່ຮອດໜຶ່ງນາທີກ່ອນ"
 ],
 "in less than a minute": [
  null,
  "ພາຍໃນບໍ່ຮອດໜຶ່ງນາທີ"
 ],
 "Password is too weak": [
  null,
  "ລະຫັດຜ່ານອ່ອນເກີນໄປ"
 ],
 "Excellent password": [
  null,
  "ລະຫັດຜ່ານດີເລີດ"
 ],
 "Password is not acceptable": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Strong password": [
  null,
  "ລະຫັດຜ່ານທີ່ແຂງແຮງ"
 ],
 "Acceptable password": [
  null,
  "ລະຫັດຜ່ານທີ່ຍອມຮັບໄດ້"
 ],
 "Weak password": [
  null,
  "ລະຫັດຜ່ານທີ່ບໍ່ປອດໄພ"
 ],
 "Show password": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Hide password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "password quality": [
  null,
  "ຄຸນນະພາບລະຫັດຜ່ານ"
 ],
 "Show confirmation password": [
  null,
  "ສະແດງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Hide confirmation password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານຢືນຢັນ"
 ],
 "Additional packages:": [
  null,
  "ແພັກເກດເພີ່ມເຕີມ:"
 ],
 "Removals:": [
  null,
  "ການລຶບອອກ:"
 ],
 "Total size: $0": [
  null,
  "ຂະໜາດທັງໝົດ: $0"
 ],
 "Install software": [
  null,
  "ຕິດຕັ້ງຊອບແວ"
 ],
 "$0 will be installed.": [
  null,
  "$0 ຈະຖືກຕິດຕັ້ງ."
 ],
 "Install": [
  null,
  "ຕິດຕັ້ງ"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ກຳລັງລໍຖ້າໃຫ້ການຈັດການຊອບແວອື່ນໆເຮັດວຽກໃຫ້ສຳເລັດ"
 ],
 "Checking installed software": [
  null,
  "ກຳລັງກວດສອບຊອບແວທີ່ຕິດຕັ້ງແລ້ວ"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ບໍ່ມີໃຫ້ໃຊ້ຈາກຄັງຊອບແວໃດໆ."
 ],
 "Downloading $0": [
  null,
  "ກຳລັງດາວໂຫຼດ $0"
 ],
 "Removing $0": [
  null,
  "ກຳລັງລຶບ $0 ອອກ"
 ],
 "Installing $0": [
  null,
  "ກຳລັງຕິດຕັ້ງ $0"
 ],
 "Unknown host: $0": [
  null,
  "ບໍ່ຮູ້ຈັກໂຮສຕ໌: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "ບໍ່ສາມາດເຂົ້າສູ່ລະບົບ $0 ດ້ວຍການຢືນຢັນຄີ SSH ໄດ້. ກະລຸນາລະບຸລະຫັດຜ່ານ."
 ],
 "SSH key login": [
  null,
  "ການເຂົ້າສູ່ລະບົບດ້ວຍຄີ SSH"
 ],
 "[no data]": [
  null,
  "[ບໍ່ມີຂໍ້ມູນ]"
 ],
 "[binary data]": [
  null,
  "[ຂໍ້ມູນໄບນາຣີ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ຂັດຂ້ອງ"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ລາຍງານລະຫັດຄວາມຜິດພາດ $0"
 ],
 "show less": [
  null,
  "ສະແດງໜ້ອຍລົງ"
 ],
 "show more": [
  null,
  "ສະແດງເພີ່ມເຕີມ"
 ],
 "Row expansion": [
  null,
  "ການຂະຫຍາຍແຖວ"
 ],
 "Row select": [
  null,
  "ເລືອກແຖວ"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ວາງ (Paste)"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ເກີດຄວາມຜິດພາດໃນການວາງ"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "ບຣາວເຊີຂອງທ່ານບໍ່ອະນຸຍາດໃຫ້ວາງຂໍ້ມູນຈາກເມນູຄລິກຂວາ. ທ່ານສາມາດໃຊ້ Shift+Insert ແທນ."
 ],
 "Error during initialization": [
  null,
  "ເກີດຂໍ້ຜິດພາດລະຫວ່າງການເລີ່ມຕົ້ນ"
 ],
 "Failed": [
  null,
  "ຫຼົ້ມເຫຼວ"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "ພິມເພື່ອທອງ"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "ບໍ່ພົບຜົນລັບທີ່ກົງກັນ"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "ກັອບປີ້ໄວ້ໃນຄລິບບອດ"
 ],
 "Automation script": [
  null,
  "ສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ສ້າງໄຟລ໌ວຽກໃໝ່ດ້ວຍເນື້ອຫານີ້."
 ],
 "Ansible roles documentation": [
  null,
  "ເອກະສານ Ansible roles"
 ],
 "Shell script": [
  null,
  "ສະຄຣິບເຊວ"
 ],
 "No system modifications": [
  null,
  "ບໍ່ມີການແກ້ໄຂລະບົບ"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເບິ່ງການປ່ຽນແປງລະບົບ"
 ],
 "Loading system modifications...": [
  null,
  "ກຳລັງໂຫຼດການປ່ຽນແປງຂອງລະບົບ..."
 ],
 "View automation script": [
  null,
  "ເບິ່ງສະຄຣິບອັດຕະໂນມັດ"
 ],
 "Occurrences": [
  null,
  "ຈຳນວນການເກີດຂຶ້ນ"
 ],
 "View all logs": [
  null,
  "ເບິ່ງບັນທຶກທັງໝົດ"
 ],
 "Other": [
  null,
  "ອື່ນໆ"
 ],
 "Unknown": [
  null,
  "ບໍ່ຮູ້ຈັກ"
 ],
 "Desktop": [
  null,
  "ເດດທອບ"
 ],
 "Low profile desktop": [
  null,
  "Low profile desktop"
 ],
 "Pizza box": [
  null,
  "ພິດຊ່າບັອກ (Pizza box)"
 ],
 "Mini tower": [
  null,
  "ມິນິທາວເວີ (Mini tower)"
 ],
 "Tower": [
  null,
  "ທາວເວີ (Tower)"
 ],
 "Portable": [
  null,
  "ພົກພາໄດ້"
 ],
 "Laptop": [
  null,
  "ແລັບທອບ"
 ],
 "Notebook": [
  null,
  "ໂນ້ດບຸກ"
 ],
 "Handheld": [
  null,
  "ອຸປະກອນພົກພາ"
 ],
 "Docking station": [
  null,
  "ດັອກກິງສະເຕຊັນ"
 ],
 "All-in-one": [
  null,
  "ທັງໝົດໃນອັນດຽວ"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "ຄອມພິວເຕີແບບປະຢັດພື້ນທີ່"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Main server chassis"
 ],
 "Expansion chassis": [
  null,
  "Expansion chassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus expansion chassis"
 ],
 "Peripheral chassis": [
  null,
  "ໂຄງເຄື່ອງອຸປະກອນຕໍ່ພ່ວງ"
 ],
 "RAID chassis": [
  null,
  "ໂຄງເຄື່ອງ RAID"
 ],
 "Rack mount chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຕິດຕັ້ງໃນແຣັກ"
 ],
 "Sealed-case PC": [
  null,
  "ພີຊີແບບກ່ອງປິດ (Sealed-case PC)"
 ],
 "Multi-system chassis": [
  null,
  "ໂຄງເຄື່ອງແບບຫຼາຍລະບົບ"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade enclosure"
 ],
 "Tablet": [
  null,
  "ແທັບເລັດ"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "ຖອດອອກໄດ້"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ຄອມພິວເຕີຝັງຕົວ"
 ],
 "Mini PC": [
  null,
  "ມິນິພີຊີ (Mini PC)"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "ບໍ່ມີຢູ່"
 ],
 "Present": [
  null,
  "ມີຢູ່"
 ],
 "Old password not accepted": [
  null,
  "ລະຫັດຜ່ານເກົ່າບໍ່ຖືກຍອມຮັບ"
 ],
 "Failed to change password": [
  null,
  "ບໍ່ສາມາດປ່ຽນລະຫັດຜ່ານໄດ້"
 ],
 "New password was not accepted": [
  null,
  "ລະຫັດຜ່ານໃໝ່ບໍ່ຖືກຍອມຮັບ"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ການຖາມຜ່ານ ssh-keygen ໝົດເວລາ"
 ],
 "Not a valid private key": [
  null,
  "ບໍ່ແມ່ນໄພຣເວດຄີ (private key) ທີ່ຖືກຕ້ອງ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ການຖາມຜ່ານ ssh-add ໝົດເວລາ"
 ],
 "Invalid file permissions": [
  null,
  "ການອະນຸຍາດໄຟລ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Password not accepted": [
  null,
  "ລະຫັດຜ່ານບໍ່ຖືກຍອມຮັບ"
 ],
 "Select an option": [
  null,
  "ເລືອກຕົວເລືອກ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 ຖືກຢຸດດ້ວຍສັນຍານ $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 ອອກດ້ວຍລະຫັດ $1"
 ],
 "$0 failed": [
  null,
  "$0 ຫຼົ້ມເຫຼວ"
 ],
 "Your session has been terminated.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານຖືກສິ້ນສຸດແລ້ວ."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "ວາລະການໃຊ້ງານຂອງທ່ານໝົດອາຍຸແລ້ວ. ກະລຸນາເຂົ້າສູ່ລະບົບໃໝ່."
 ],
 "Not permitted to perform this action.": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ເຮັດການນີ້."
 ],
 "Login failed": [
  null,
  "ເຂົ້າສູ່ລະບົບບໍ່ສຳເລັດ"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "ເຊີເວີປະຕິເສດການຢືນຢັນຕົວຕົນດ້ວຍທຸກວິທີທີ່ຮອງຮັບ."
 ],
 "Untrusted host": [
  null,
  "ໂຮສຕ໌ທີ່ບໍ່ໜ້າເຊື່ອຖື"
 ],
 "Host key is incorrect": [
  null,
  "ຄີຂອງໂຮສຕ໌ບໍ່ຖືກຕ້ອງ"
 ],
 "Internal error": [
  null,
  "ຂໍ້ຜິດພາດພາຍໃນ"
 ],
 "Connection has timed out.": [
  null,
  "ການເຊື່ອມຕໍ່ໝົດເວລາ."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ບໍ່ໄດ້ຖືກຕິດຕັ້ງຢູ່ໃນລະບົບ."
 ],
 "Cannot forward login credentials": [
  null,
  "ບໍ່ສາມາດສົ່ງຕໍ່ຂໍ້ມູນການເຂົ້າລະບົບໄດ້"
 ],
 "Server has closed the connection.": [
  null,
  "ເຊີເວີໄດ້ປິດການເຊື່ອມຕໍ່ແລ້ວ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ບໍ່ເຂົ້າກັນໄດ້ກັບຊອບແວໃນລະບົບ."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ບໍ່ສາມາດຕິດຕໍ່ກັບໂຮສຕ໌ທີ່ລະບຸໄດ້."
 ],
 "Too much data": [
  null,
  "ຂໍ້ມູນຫຼາຍເກີນໄປ"
 ],
 "$0 is not a directory": [
  null,
  "$0 ບໍ່ແມ່ນໄດເຣັກທໍຣີ"
 ],
 "$0 does not exist": [
  null,
  "$0 ບໍ່ມີຢູ່"
 ],
 "Font size": [
  null,
  "ຂະໜາດຕົວອັກສອນ"
 ],
 "Decrease by one": [
  null,
  "ຫຼຸດລົງເທື່ອລະໜຶ່ງ"
 ],
 "Increase by one": [
  null,
  "ເພີ່ມຂຶ້ນເທື່ອລະໜຶ່ງ"
 ],
 "Appearance": [
  null,
  "ຮູບລັກສະນະ"
 ],
 "Black": [
  null,
  "ສີດຳ"
 ],
 "White": [
  null,
  "ສີຂາວ"
 ],
 "Reset": [
  null,
  "ຣີເຊັດ (Reset)"
 ],
 "Unable to open directory": [
  null,
  "ບໍ່ສາມາດເປີດໂຟນເດີໄດ້"
 ],
 "Running process prevents directory change": [
  null,
  "ໂປຣເຊສທີ່ກຳລັງເຮັດວຽກຢູ່ຂັດຂວາງການປ່ຽນໄດເຣັກທໍຣີ"
 ],
 "Change directory": [
  null,
  "ປ່ຽນໄດເຣັກທໍຣີ"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "ການປ່ຽນໄດເຣັກທໍຣີຈະຢຸດຂະບວນການທີ່ກຳລັງເຮັດວຽກຢູ່ທັນທີ. ທ່ານສາມາດຢຸດຂະບວນການເອງໃນເທີມິນໍກ່ອນດຳເນີນການຕໍ່ໄດ້."
 ],
 "Terminal not available": [
  null,
  "ເທີມີນໍບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "This browser does not support WebGL2.": [
  null,
  "ບຣາວເຊີນີ້ບໍ່ຮອງຮັບ WebGL2."
 ],
 "unknown": [
  null,
  "ບໍ່ຮູ້ຈັກ"
 ],
 "Shutdown": [
  null,
  "ປິດລະບົບ"
 ],
 "running $0": [
  null,
  "ກຳລັງຮັນ $0"
 ],
 "Current boot": [
  null,
  "ການບູດປັດຈຸບັນ"
 ],
 "Previous boot": [
  null,
  "ການບູດຄັ້ງກ່ອນ"
 ],
 "Last 24 hours": [
  null,
  "24 ຊົ່ວໂມງທີ່ຜ່ານມາ"
 ],
 "Last 7 days": [
  null,
  "7 ມື້ທີ່ຜ່ານມາ"
 ],
 "Only emergency": [
  null,
  "ສະເພາະກໍລະນີສຸກເສີນ"
 ],
 "Alert and above": [
  null,
  "ແຈ້ງເຕືອນ ແລະ ສູງກວ່າ"
 ],
 "Critical and above": [
  null,
  "ວິກິດ ແລະ ສູງກວ່າ"
 ],
 "Error and above": [
  null,
  "ຂໍ້ຜິດພາດ ແລະ ສູງກວ່າ"
 ],
 "Warning and above": [
  null,
  "ຄຳເຕືອນ ແລະ ສູງກວ່າ"
 ],
 "Notice and above": [
  null,
  "ແຈ້ງເຕືອນຂຶ້ນໄປ"
 ],
 "Info and above": [
  null,
  "ຂໍ້ມູນ ແລະ ສູງກວ່າ"
 ],
 "Debug and above": [
  null,
  "ດີບັກ ແລະ ສູງກວ່າ"
 ],
 "Toggle filters": [
  null,
  "ເປີດ-ປິດ ຕົວທອງ"
 ],
 "Time": [
  null,
  "ເວລາ"
 ],
 "Priority": [
  null,
  "ບຸລິມະສິດ"
 ],
 "Identifier": [
  null,
  "ໂຕລະບຸຕົວຕົນ"
 ],
 "Filters": [
  null,
  "ໂຕກັ່ນຕອງ"
 ],
 "Pause": [
  null,
  "ພັກຊົ່ວຄາວ"
 ],
 "Resume": [
  null,
  "ເຮັດວຽກຕໍ່"
 ],
 "All": [
  null,
  "ທັງໝົດ"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "ການກຳນົດວັນທີຄວນຢູ່ໃນຮູບແບບ YYYY-MM-DD hh:mm:ss. ຫຼື ສາມາດໃຊ້ຄຳວ່າ 'yesterday', 'today', 'tomorrow' ໄດ້. 'now' ໝາຍເຖິງເວລາປັດຈຸບັນ. ສຸດທ້າຍ, ສາມາດກຳນົດເວລາສຳພັດໄດ້ໂດຍຂຶ້ນຕົ້ນດ້ວຍ '-' ຫຼື '+'"
 ],
 "Since": [
  null,
  "ຕັ້ງແຕ່"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "ເລີ່ມສະແດງລາຍການໃນ ຫຼື ໃໝ່ກວ່າວັນທີທີ່ລະບຸ."
 ],
 "Until": [
  null,
  "ຈົນຮອດ"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "ເລີ່ມສະແດງລາຍການໃນ ຫຼື ເກົ່າກວ່າວັນທີທີ່ລະບຸ."
 ],
 "Boot": [
  null,
  "ບູດ (Boot)"
 ],
 "Show messages from a specific boot.": [
  null,
  "ສະແດງຂໍ້ຄວາມຈາກການບູດເຄື່ອງຄັ້ງທີ່ລະບຸ."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "ນີ້ຈະເພີ່ມການກອງສຳລັບ '_BOOT_ID='. ຖ້າບໍ່ໄດ້ລະບຸ ຈະສະແດງບັນທຶກຂອງການບູດປັດຈຸບັນ. ຖ້າບໍ່ໃສ່ boot ID, ຄ່າບວກຈະຄົ້ນຫາການບູດເລີ່ມຈາກຕົ້ນຂອງ journal, ແລະ ຄ່າທີ່ນ້ອຍກວ່າ ຫຼື ເທົ່າກັບສູນຈະຄົ້ນຫາເລີ່ມຈາກທ້າຍຂອງ journal. ດັ່ງນັ້ນ, 1 ໝາຍເຖິງການບູດຄັ້ງທຳອິດ, 2 ຄັ້ງທີສອງ; ໃນຂະນະທີ່ -0 ແມ່ນການບູດຄັ້ງຫຼ້າສຸດ, -1 ແມ່ນຄັ້ງກ່ອນໜ້ານັ້ນ."
 ],
 "Unit": [
  null,
  "Unit"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "ສະແດງຂໍ້ຄວາມສຳລັບ unit ຂອງ systemd ທີ່ລະບຸ."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "ນີ້ຈະເພີ່ມການກອງສຳລັບ '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' ແລະ 'UNIT=' ເພື່ອຊອກຫາຂໍ້ຄວາມທັງໝົດຂອງ unit ທີ່ກຳນົດ. ສາມາດໃສ່ໄດ້ຫຼາຍ unit ໂດຍໃຊ້ຈຸດຂັ້ນ."
 ],
 "Free-form search": [
  null,
  "ຄົ້ນຫາແບບອິດສະຫຼະ"
 ],
 "Show messages containing given string.": [
  null,
  "ສະແດງຂໍ້ຄວາມທີ່ມີຂໍ້ຄວາມທີ່ກຳນົດໃຫ້."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ຂໍ້ຄວາມໃດໆໃນລັອກ (logs) ສາມາດຕອງໄດ້. ສາມາດໃຊ້ເປັນ regular expression ໄດ້. ຮອງຮັບການຕອງຕາມຟິວຂອງລັອກ ເຊັ່ນ FIELD=VALUE ໂດຍແຍກແຕ່ລະຄ່າດ້ວຍຍະຫວ່າງ."
 ],
 "journalctl manpage": [
  null,
  "ໜ້າຄູ່ມື journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "ຄັດລອກໄປທີ່ຄລິບບອດສຳເລັດແລ້ວ"
 ],
 "Create timer": [
  null,
  "ສ້າງ timer (ຕົວຕັ້ງເວລາ)"
 ],
 "Edit timer": [
  null,
  "ແກ້ໄຂໂຕຕັ້ງເວລາ"
 ],
 "Timer creation failed": [
  null,
  "ສ້າງຕົວຕັ້ງເວລາບໍ່ສຳເລັດ"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "ບໍ່ສາມາດດຶງຂໍ້ມູນເງື່ອນໄຂການເລີ່ມຕົ້ນຂອງໂຕຕັ້ງເວລາໄດ້"
 ],
 "Failed to get the timer command": [
  null,
  "ບໍ່ສາມາດດຶງຂໍ້ມູນຄຳສັ່ງຂອງໂຕຕັ້ງເວລາໄດ້"
 ],
 "This field cannot be empty": [
  null,
  "ຫ້ອງນີ້ບໍ່ສາມາດຫວ່າງເປົ່າໄດ້"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "ອະນຸຍາດສະເພາະຕົວອັກສອນ, ຕົວເລກ, : , _ , . , @ , - ເທົ່ານັ້ນ"
 ],
 "Description": [
  null,
  "ຄຳອະທິບາຍ"
 ],
 "Shell command": [
  null,
  "ຄຳສັ່ງເຊວ"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "ຄຳສັ່ງນີ້ຈະຖືກດຳເນີນການໂດຍ /bin/sh."
 ],
 "Trigger": [
  null,
  "ຕົວເປີດເຮັດວຽກ (Trigger)"
 ],
 "At specific time": [
  null,
  "ຕາມເວລາທີ່ກຳນົດ"
 ],
 "After system boot": [
  null,
  "ຫຼັງຈາກລະບົບເລີ່ມຂຶ້ນ"
 ],
 "Seconds": [
  null,
  "ວິນາທີ"
 ],
 "Minutes": [
  null,
  "ນາທີ"
 ],
 "Hours": [
  null,
  "ຊົ່ວໂມງ"
 ],
 "Weeks": [
  null,
  "ອາທິດ"
 ],
 "Delay must be a number": [
  null,
  "ການໜ່ວງເວລາຕ້ອງເປັນຕົວເລກ"
 ],
 "Repeat": [
  null,
  "ເຮັດຊ້ຳ"
 ],
 "Don't repeat": [
  null,
  "ບໍ່ຕ້ອງເຮັດຊໍ້າ"
 ],
 "Minutely": [
  null,
  "ທຸກໆນາທີ"
 ],
 "Hourly": [
  null,
  "ທຸກໆຊົ່ວໂມງ"
 ],
 "Daily": [
  null,
  "ປະຈຳວັນ"
 ],
 "Weekly": [
  null,
  "ລາຍອາທິດ"
 ],
 "Monthly": [
  null,
  "ລາຍເດືອນ"
 ],
 "Yearly": [
  null,
  "ລາຍປີ"
 ],
 "Run at": [
  null,
  "ຣັນ (Run) ທີ່"
 ],
 "At second": [
  null,
  "ທີ່ວິນາທີ"
 ],
 "At minute": [
  null,
  "ທີ່ນາທີ"
 ],
 "Run on": [
  null,
  "ຣັນໃນວັນທີ"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "ນາທີຕ້ອງເປັນຕົວເລກລະຫວ່າງ 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "ວິນາທີຕ້ອງເປັນຕົວເລກລະຫວ່າງ 0-59"
 ],
 "Repeat weekly": [
  null,
  "ເຮັດຊ້ຳທຸກອາທິດ"
 ],
 "Mondays": [
  null,
  "ວັນຈັນ"
 ],
 "Tuesdays": [
  null,
  "ວັນອັງຄານ"
 ],
 "Wednesdays": [
  null,
  "ວັນພຸດ"
 ],
 "Thursdays": [
  null,
  "ວັນພະຫັດ"
 ],
 "Fridays": [
  null,
  "ວັນສຸກ"
 ],
 "Saturdays": [
  null,
  "ວັນເສົາ"
 ],
 "Sundays": [
  null,
  "ວັນອາທິດ"
 ],
 "Repeat monthly": [
  null,
  "ເຮັດຊ້ຳທຸກເດືອນ"
 ],
 "1st": [
  null,
  "ທີ 1"
 ],
 "2nd": [
  null,
  "ທີ 2"
 ],
 "3rd": [
  null,
  "ທີ 3"
 ],
 "4th": [
  null,
  "ທີ 4"
 ],
 "5th": [
  null,
  "ທີ 5"
 ],
 "6th": [
  null,
  "ທີ 6"
 ],
 "7th": [
  null,
  "ທີ 7"
 ],
 "8th": [
  null,
  "ທີ 8"
 ],
 "9th": [
  null,
  "ທີ 9"
 ],
 "10th": [
  null,
  "ທີ 10"
 ],
 "11th": [
  null,
  "ທີ 11"
 ],
 "12th": [
  null,
  "ທີ 12"
 ],
 "13th": [
  null,
  "ທີ 13"
 ],
 "14th": [
  null,
  "ທີ 14"
 ],
 "15th": [
  null,
  "ທີ 15"
 ],
 "16th": [
  null,
  "ທີ 16"
 ],
 "17th": [
  null,
  "ທີ 17"
 ],
 "18th": [
  null,
  "ທີ 18"
 ],
 "19th": [
  null,
  "ທີ 19"
 ],
 "20th": [
  null,
  "ທີ 20"
 ],
 "21th": [
  null,
  "ທີ 21"
 ],
 "22th": [
  null,
  "ທີ 22"
 ],
 "23th": [
  null,
  "ທີ 23"
 ],
 "24th": [
  null,
  "ທີ 24"
 ],
 "25th": [
  null,
  "ທີ 25"
 ],
 "26th": [
  null,
  "ທີ 26"
 ],
 "27th": [
  null,
  "ທີ 27"
 ],
 "28th": [
  null,
  "ທີ 28"
 ],
 "29th": [
  null,
  "ທີ 29"
 ],
 "30th": [
  null,
  "ທີ 30"
 ],
 "31st": [
  null,
  "ທີ 31"
 ],
 "Save": [
  null,
  "ບັນທຶກ"
 ],
 "Unclean shutdown": [
  null,
  "ການປິດເຄື່ອງທີ່ບໍ່ສົມບູນ"
 ],
 "View logs": [
  null,
  "ເບິ່ງບັນທຶກ"
 ],
 "Dismiss": [
  null,
  "ຍົກເລີກ"
 ],
 "Scheduled poweroff at $0": [
  null,
  "ກຳນົດເວລາປິດເຄື່ອງທີ່ $0"
 ],
 "Cancel poweroff": [
  null,
  "ຍົກເລີກການປິດເຄື່ອງ"
 ],
 "Scheduled reboot at $0": [
  null,
  "ກຳນົດເວລາບູດເຄື່ອງໃໝ່ທີ່ $0"
 ],
 "Cancel reboot": [
  null,
  "ຍົກເລີກການເລີ່ມລະບົບໃໝ່"
 ],
 "edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "Set hostname": [
  null,
  "ຕັ້ງຊື່ໂຮສຕ໌"
 ],
 "Configuration": [
  null,
  "ການຕັ້ງຄ່າ"
 ],
 "Hostname": [
  null,
  "ຊື່ໂຮສຕ໌"
 ],
 "System time": [
  null,
  "ເວລາລະບົບ"
 ],
 "Domain": [
  null,
  "ໂດເມນ"
 ],
 "Performance profile": [
  null,
  "ໂປຣໄຟລ໌ປະສິດທິພາບ"
 ],
 "Secure shell keys": [
  null,
  "ຄີ Secure shell"
 ],
 "Show fingerprints": [
  null,
  "ສະແດງລາຍນິ້ວມື (Fingerprints)"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ບໍ່ສາມາດສະແດງລາຍຊື່ຄີ SSH ໂຮສຕ໌: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "ການໂຫຼດຄີ SSH ຫຼົ້ມເຫຼວ"
 ],
 "Error message": [
  null,
  "ຂໍ້ຄວາມຜິດພາດ"
 ],
 "Loading keys...": [
  null,
  "ກຳລັງໂຫຼດຄີ..."
 ],
 "No host keys found.": [
  null,
  "ບໍ່ພົບຄີຂອງໂຮສຕ໌."
 ],
 "Machine SSH key fingerprints": [
  null,
  "ລາຍນິ້ວມືຄີ SSH ຂອງເຄື່ອງ"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "ຊື່ໂຮສຕ໌ແທ້ຕ້ອງມີຄວາມຍາວ 64 ຕົວອັກສອນ ຫຼື ໜ້ອຍກວ່າ"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "ຊື່ໂຮສຕ໌ແທ້ສາມາດມີໄດ້ສະເພາະຕົວອັກສອນພິມນ້ອຍ, ຕົວເລກ, ຂີດຕໍ່, ແລະ ຈຸດ (ພ້ອມກັບຊັບໂດເມນທີ່ມີຂໍ້ມູນ)"
 ],
 "Change host name": [
  null,
  "ປ່ຽນຊື່ໂຮສຕ໌"
 ],
 "Pretty host name": [
  null,
  "ຊື່ໂຮສຕ໌ແບບສວຍງາມ"
 ],
 "Real host name": [
  null,
  "ຊື່ໂຮສຕ໌ແທ້"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "ຜູ້ໃຊ້ $0 ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ປ່ຽນແປງນະໂຍບາຍການເຂົ້າລະຫັດ"
 ],
 "Cryptographic policy": [
  null,
  "ນະໂຍບາຍການເຂົ້າລະຫັດ"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "ການຕັ້ງຄ່າທີ່ປອດໄພທີ່ແນະນຳສຳລັບຮູບແບບໄພຄຸກຄາມໃນປັດຈຸບັນ."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT ໂດຍອະນຸຍາດໃຫ້ມີການກວດສອບລາຍເຊັນ SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "ເພີ່ມຄວາມສາມາດໃນການເຮັດວຽກຮ່ວມກັນ ແຕ່ມີຄວາມສ່ຽງຕໍ່ການຖືກໂຈມຕີເພີ່ມຂຶ້ນ."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY ພ້ອມກັບຄວາມສາມາດໃນການເຮັດວຽກຮ່ວມກັບ Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "ໃຊ້ສະເພາະອັນກໍຣິທຶມທີ່ໄດ້ຮັບການອະນຸມັດ ແລະ ອະນຸຍາດ ເມື່ອບູດໃນໂໝດ FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS ພ້ອມກັບຂໍ້ຈຳກັດ Common Criteria ເພີ່ມເຕີມ."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "ປ້ອງກັນການໂຈມຕີທີ່ອາດເກີດຂຶ້ນໃນອະນາຄົດອັນໃກ້ນີ້ ໂດຍແລກກັບຄວາມສາມາດໃນການເຮັດວຽກຮ່ວມກັນ."
 ],
 "Custom cryptographic policy": [
  null,
  "ນະໂຍບາຍການເຂົ້າລະຫັດທີ່ກຳນົດເອງ"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Cryptographic Policies ແມ່ນສ່ວນປະກອບຂອງລະບົບທີ່ຕັ້ງຄ່າລະບົບການເຂົ້າລະຫັດຫຼັກ, ລວມທັງໂປຣໂຕຄໍ TLS, IPSec, SSH, DNSSec, ແລະ Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "ປ່ຽນນະໂຍບາຍການເຂົ້າລະຫັດ"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "ກຳລັງນຳໃຊ້ນະໂຍບາຍໃໝ່... ອາດໃຊ້ເວລາສອງສາມນາທີ."
 ],
 "Reapply and reboot": [
  null,
  "ນຳໃຊ້ຄືນໃໝ່ ແລະ ບູດເຄື່ອງ"
 ],
 "Apply and reboot": [
  null,
  "ນຳໃຊ້ ແລະ ເລີ່ມລະບົບໃໝ່"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS ບໍ່ໄດ້ຖືກເປີດໃຊ້ງານຢ່າງຖືກຕ້ອງ"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "ນະໂຍບາຍການເຂົ້າລະຫັດບໍ່ສອດຄ່ອງກັນ"
 ],
 "Review cryptographic policy": [
  null,
  "ກວດສອບນະໂຍບາຍການເຂົ້າລະຫັດລັບ (cryptographic policy)"
 ],
 "System information": [
  null,
  "ຂໍ້ມູນລະບົບ"
 ],
 "Model": [
  null,
  "ລຸ້ນ (Model)"
 ],
 "Asset tag": [
  null,
  "ໝາຍເລກຊັບສິນ"
 ],
 "Machine ID": [
  null,
  "Machine ID"
 ],
 "Up since": [
  null,
  "ເປີດໃຊ້ງານຕັ້ງແຕ່"
 ],
 "View hardware details": [
  null,
  "ເບິ່ງລາຍລະອຽດຮາດແວ"
 ],
 "Last successful login:": [
  null,
  "ເຂົ້າສູ່ລະບົບສຳເລັດຫຼ້າສຸດ:"
 ],
 "$0 failed login attempt": [
  null,
  "ການພະຍາຍາມເຂົ້າລະບົບຫຼົ້ມເຫຼວ $0 ຄັ້ງ"
 ],
 "View login history": [
  null,
  "ເບິ່ງປະຫວັດການເຂົ້າສູ່ລະບົບ"
 ],
 "recommended": [
  null,
  "ແນະນຳ"
 ],
 "inconsistent": [
  null,
  "ບໍ່ສອດຄ່ອງ"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "ການເຂົ້າຮ່ວມໂດເມນຕ້ອງມີການຕິດຕັ້ງ realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "ບໍ່ສາມາດເຂົ້າຮ່ວມໂດເມນໄດ້ ເພາະບໍ່ມີ realmd ໃນລະບົບນີ້"
 ],
 "Joining this domain is not supported": [
  null,
  "ການເຂົ້າຮ່ວມໂດເມນນີ້ບໍ່ຖືກຮອງຮັບ"
 ],
 "Login format": [
  null,
  "ຮູບແບບການເຂົ້າສູ່ລະບົບ"
 ],
 "Server software": [
  null,
  "ຊອບແວເຊີເວີ"
 ],
 "Client software": [
  null,
  "ຊອບແວຝັ່ງລູກຂ່າຍ"
 ],
 "Leave domain": [
  null,
  "ອອກຈາກໂດເມນ"
 ],
 "Leave $0": [
  null,
  "ອອກຈາກ $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "ຫຼັງຈາກອອກຈາກໂດເມນ, ສະເພາະຜູ້ໃຊ້ທີ່ມີຂໍ້ມູນບັນຊີພາຍໃນເຄື່ອງເທົ່ານັ້ນທີ່ຈະສາມາດເຂົ້າລະບົບໄດ້. ສິ່ງນີ້ອາດຈະສົ່ງຜົນກະທົບຕໍ່ບໍລິການອື່ນໆ ເຊັ່ນ: ການຕັ້ງຄ່າ DNS ແລະ ລາຍການ CA ທີ່ເຊື່ອຖືໄດ້ອາດຈະປ່ຽນແປງ."
 ],
 "Validating address": [
  null,
  "ກຳລັງກວດສອບຄວາມຖືກຕ້ອງຂອງທີ່ຢູ່"
 ],
 "Contacted domain": [
  null,
  "ໂດເມນທີ່ໄດ້ຕິດຕໍ່"
 ],
 "Domain could not be contacted": [
  null,
  "ບໍ່ສາມາດຕິດຕໍ່ໂດເມນໄດ້"
 ],
 "Domain is not supported": [
  null,
  "ໂດເມນບໍ່ຮອງຮັບ"
 ],
 "Domain address": [
  null,
  "ທີ່ຢູ່ໂດເມນ"
 ],
 "Domain administrator name": [
  null,
  "ຊື່ຜູ້ດູແລລະບົບໂດເມນ"
 ],
 "Domain administrator password": [
  null,
  "ລະຫັດຜ່ານຜູ້ດູແລລະບົບໂດເມນ"
 ],
 "Joining": [
  null,
  "ກຳລັງເຂົ້າຮ່ວມ"
 ],
 "Join": [
  null,
  "ເຂົ້າຮ່ວມ"
 ],
 "This may take a while": [
  null,
  "ນີ້ອາດຈະໃຊ້ເວລາໄລຍະໜຶ່ງ"
 ],
 "Not permitted to configure realms": [
  null,
  "ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ຕັ້ງຄ່າ realms"
 ],
 "Join domain": [
  null,
  "ເຂົ້າຮ່ວມໂດເມນ"
 ],
 "Install realmd support": [
  null,
  "ຕິດຕັ້ງການຮອງຮັບ realmd"
 ],
 "$0 disk is failing": [
  null,
  "ດິສກ໌ $0 ໜ່ວຍກຳລັງຈະເສຍ"
 ],
 "Connected to Insights": [
  null,
  "ເຊື່ອມຕໍ່ຫາ Insights ແລ້ວ"
 ],
 "Not connected to Insights": [
  null,
  "ບໍ່ໄດ້ເຊື່ອມຕໍ່ກັບ Insights"
 ],
 "Health": [
  null,
  "ສຸຂະພາບ"
 ],
 "of $0 CPU": [
  null,
  "ຈາກ $0 ຊີພີຢູ"
 ],
 "Usage": [
  null,
  "ການນຳໃຊ້"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "ໜ່ວຍຄວາມຈຳ"
 ],
 "View metrics and history": [
  null,
  "ເບິ່ງຕົວຊີ້ວັດ ແລະ ປະຫວັດ"
 ],
 "Tuned is not available": [
  null,
  "Tuned ບໍ່ພ້ອມໃຊ້ງານ"
 ],
 "Tuned is not running": [
  null,
  "Tuned ບໍ່ໄດ້ເຮັດວຽກຢູ່"
 ],
 "Tuned is off": [
  null,
  "Tuned ປິດຢູ່"
 ],
 "This system is using the recommended profile": [
  null,
  "ລະບົບນີ້ກຳລັງໃຊ້ໂປຣໄຟລ໌ທີ່ແນະນຳ"
 ],
 "This system is using a custom profile": [
  null,
  "ລະບົບນີ້ກຳລັງໃຊ້ໂປຣໄຟລ໌ທີ່ກຳນົດເອງ"
 ],
 "none": [
  null,
  "ບໍ່ມີ"
 ],
 "Communication with tuned has failed": [
  null,
  "ການຕິດຕໍ່ກັບ tuned ຫຼົ້ມເຫຼວ"
 ],
 "Failed to enable tuned": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານ tuned ໄດ້"
 ],
 "Failed to disable tuned": [
  null,
  "ບໍ່ສາມາດປິດການໃຊ້ງານ tuned ໄດ້"
 ],
 "Failed to disable tuned profile": [
  null,
  "ບໍ່ສາມາດປິດການໃຊ້ງານ tuned profile ໄດ້"
 ],
 "Failed to switch profile": [
  null,
  "ບໍ່ສາມາດສະຫຼັບໂປຣໄຟລ໌ໄດ້"
 ],
 "None": [
  null,
  "ບໍ່ມີ"
 ],
 "Disable tuned": [
  null,
  "ປິດການໃຊ້ງານ tuned"
 ],
 "Tuned has failed to start": [
  null,
  "ເລີ່ມ Tuned ບໍ່ສຳເລັດ"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned ແມ່ນບໍລິການທີ່ຕິດຕາມລະບົບຂອງທ່ານ ແລະ ປັບແຕ່ງປະສິດທິພາບພາຍໃຕ້ການເຮັດວຽກບາງຢ່າງ. ຫົວໃຈຂອງ Tuned ແມ່ນໂປຣໄຟລ໌ ເຊິ່ງຈະປັບລະບົບຂອງທ່ານໃຫ້ເໝາະສົມກັບການໃຊ້ງານທີ່ແຕກຕ່າງກັນ."
 ],
 "Change performance profile": [
  null,
  "ປ່ຽນໂປຣໄຟລ໌ປະສິດທິພາບ"
 ],
 "Change profile": [
  null,
  "ປ່ຽນໂປຣໄຟລ໌"
 ],
 "Edit /etc/motd": [
  null,
  "ແກ້ໄຂ /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "ບໍ່ສາມາດບັນທຶກການປ່ຽນແປງໃນ /etc/motd ໄດ້"
 ],
 "Save changes": [
  null,
  "ບັນທຶກການປ່ຽນແປງ"
 ],
 "Edit motd": [
  null,
  "ແກ້ໄຂ motd"
 ],
 "Stub": [
  null,
  "ສະຕັບ (Stub)"
 ],
 "Not found": [
  null,
  "ບໍ່ພົບ"
 ],
 "Bad setting": [
  null,
  "ການຕັ້ງຄ່າບໍ່ຖືກຕ້ອງ"
 ],
 "Error": [
  null,
  "ຂໍ້ຜິດພາດ"
 ],
 "Merged": [
  null,
  "ຮວມແລ້ວ"
 ],
 "Running": [
  null,
  "ກຳລັງເຮັດວຽກ"
 ],
 "Reloading": [
  null,
  "ກຳລັງໂຫລດໃໝ່"
 ],
 "Not running": [
  null,
  "ບໍ່ໄດ້ເຮັດວຽກ"
 ],
 "Failed to start": [
  null,
  "ເລີ່ມຕົ້ນບໍ່ສຳເລັດ"
 ],
 "Maintenance": [
  null,
  "ການບຳລຸງຮັກສາ"
 ],
 "Enabled": [
  null,
  "ເປີດໃຊ້ງານແລ້ວ"
 ],
 "Disabled": [
  null,
  "ປິດໃຊ້ງານແລ້ວ"
 ],
 "Linked": [
  null,
  "ເຊື່ອມຕໍ່ແລ້ວ"
 ],
 "Alias": [
  null,
  "ຊື່ຫຼິ້ນ"
 ],
 "Masked": [
  null,
  "ຖືກມາກສ໌ໄວ້"
 ],
 "Static": [
  null,
  "ສະແຕຕິກ (Static)"
 ],
 "Invalid": [
  null,
  "ບໍ່ຖືກຕ້ອງ"
 ],
 "Indirect": [
  null,
  "ທາງອ້ອມ"
 ],
 "Generated": [
  null,
  "ຖືກສ້າງຂຶ້ນແລ້ວ"
 ],
 "Transient": [
  null,
  "ຊົ່ວຄາວ (Transient)"
 ],
 "Bad": [
  null,
  "ບໍ່ດີ"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "ການສະໝັກຮັບສັນຍານ systemd ບໍ່ສຳເລັດ: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "ການເຊື່ອມຕໍ່ຫາ dbus ຫຼົ້ມເຫຼວ: $0"
 ],
 "Listing units failed: $0": [
  null,
  "ການສະແດງລາຍການຢູນິດຫຼົ້ມເຫຼວ: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 ບໍລິການຫຼົ້ມເຫຼວ"
 ],
 "Loading of units failed": [
  null,
  "ການໂຫຼດຢູນິດຫຼົ້ມເຫຼວ"
 ],
 "Loading...": [
  null,
  "ກຳລັງໂຫຼດ..."
 ],
 "Listing units": [
  null,
  "ກຳລັງສະແດງລາຍການຢູນິດ"
 ],
 "Filter by name or description": [
  null,
  "ກັ່ນຕອງຕາມຊື່ ຫຼື ຄຳອະທິບາຍ"
 ],
 "Active state": [
  null,
  "ສະຖານະການໃຊ້ງານ"
 ],
 "File state": [
  null,
  "ສະຖານະໄຟລ໌"
 ],
 "$0 filters applied": [
  null,
  "ນຳໃຊ້ຕົວຕອງ $0 ຢ່າງ"
 ],
 "User": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "ຜູ້ໃຊ້ $0 ບໍ່ໄດ້ຮັບອະນຸຍາດໃຫ້ປ່ຽນແປງການປ້ອງກັນຄວາມປອດໄພຂອງ CPU"
 ],
 "Mitigations": [
  null,
  "ການບັນເທົາຜົນກະທົບ"
 ],
 "Version": [
  null,
  "ເວີຊັນ"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "ເວີຊັນ BIOS"
 ],
 "BIOS date": [
  null,
  "ວັນທີ BIOS"
 ],
 "CPU security": [
  null,
  "ຄວາມປອດໄພຂອງ CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "ປິດການໃຊ້ງານ multithreading ພ້ອມກັນ"
 ],
 "Read more...": [
  null,
  "ອ່ານເພີ່ມເຕີມ..."
 ],
 "Save and reboot": [
  null,
  "ບັນທຶກ ແລະ ບູດເຄື່ອງໃໝ່"
 ],
 "CPU security toggles": [
  null,
  "ຕົວປ່ຽນຄວາມປອດໄພຂອງ CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "ວິທີແກ້ໄຂບັນຫາຜ່ານຊອບແວຊ່ວຍປ້ອງກັນບັນຫາຄວາມປອດໄພຂອງ CPU. ການປ້ອງກັນເຫຼົ່ານີ້ມີຜົນຂ້າງຄຽງຄືເຮັດໃຫ້ປະສິດທິພາບຫຼຸດລົງ. ປ່ຽນແປງການຕັ້ງຄ່າເຫຼົ່ານີ້ດ້ວຍຄວາມສ່ຽງຂອງທ່ານເອງ."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "ຄລາດ (Class)"
 ],
 "Vendor": [
  null,
  "ຜູ້ຜະລິດ (Vendor)"
 ],
 "Slot": [
  null,
  "ຊ່ອງ (Slot)"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "ເຕັກໂນໂລຊີໜ່ວຍຄວາມຈຳ"
 ],
 "Size": [
  null,
  "ຂະໜາດ"
 ],
 "State": [
  null,
  "ສະຖານະ"
 ],
 "Rank": [
  null,
  "ອັນດັບ"
 ],
 "Speed": [
  null,
  "ຄວາມໄວ"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "ການເບິ່ງຂໍ້ມູນໜ່ວຍຄວາມຈຳຕ້ອງມີການເຂົ້າເຖິງແບບຜູ້ດູແລລະບົບ."
 ],
 "Overview": [
  null,
  "ພາບລວມ"
 ],
 "Failed to fetch logs": [
  null,
  "ບໍ່ສາມາດດຶງຂໍ້ມູນລັອກໄດ້"
 ],
 "Clear all filters": [
  null,
  "ລຶບຕົວຕອງທັງໝົດ"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "ບໍ່ພົບລັອກ (logs) ໂດຍໃຊ້ຕົວຕອງທີ່ເລືອກໄວ້."
 ],
 "No logs found": [
  null,
  "ບໍ່ພົບບັນທຶກເຫດການ"
 ],
 "Load earlier entries": [
  null,
  "ໂຫຼດລາຍການກ່ອນໜ້ານີ້"
 ],
 "You may try to load older entries.": [
  null,
  "ທ່ານອາດຈະລອງໂຫຼດລາຍການທີ່ເກົ່າກວ່ານີ້."
 ],
 "Allow running (unmask)": [
  null,
  "ອະນຸຍາດໃຫ້ເຮັດວຽກ (unmask)"
 ],
 "Reload": [
  null,
  "ໂຫລດໃໝ່"
 ],
 "Restart": [
  null,
  "ເລີ່ມຕົ້ນໃໝ່ (Restart)"
 ],
 "Stop": [
  null,
  "ຢຸດ"
 ],
 "Start": [
  null,
  "ເລີ່ມ"
 ],
 "Delete": [
  null,
  "ລຶບ"
 ],
 "Clear 'Failed to start'": [
  null,
  "ລຶບສະຖານະ 'ເລີ່ມຕົ້ນຫຼົ້ມເຫຼວ'"
 ],
 "Mask service": [
  null,
  "ມາກສ໌ບໍລິການ"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "ການປິດກັ້ນ (Masking) ການບໍລິການຈະປ້ອງກັນບໍ່ໃຫ້ໜ່ວຍງານທີ່ຂຶ້ນກັບທັງໝົດເຮັດວຽກ. ນີ້ອາດສົ່ງຜົນກະທົບຫຼາຍກວ່າທີ່ຄາດໄວ້. ກະລຸນາຢືນຢັນວ່າທ່ານຕ້ອງການປິດກັ້ນໜ່ວຍງານນີ້."
 ],
 "Disallow running (mask)": [
  null,
  "ບໍ່ອະນຸຍາດໃຫ້ເຮັດວຽກ (ມາກສ໌)"
 ],
 "Unpin unit": [
  null,
  "ຍົກເລີກການປັກໝຸດ unit"
 ],
 "Pin unit": [
  null,
  "ປັກໝຸດໜ່ວຍງານ (Pin unit)"
 ],
 "Additional actions": [
  null,
  "ການດຳເນີນການເພີ່ມເຕີມ"
 ],
 "Note": [
  null,
  "ໝາຍເຫດ"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Unit ນີ້ບໍ່ໄດ້ຖືກອອກແບບມາໃຫ້ເປີດໃຊ້ງານໂດຍກົງ."
 ],
 "Forbidden from running": [
  null,
  "ຖືກຫ້າມບໍ່ໃຫ້ເຮັດວຽກ"
 ],
 "Start service": [
  null,
  "ເລີ່ມບໍລິການ"
 ],
 "Active since ": [
  null,
  "ໃຊ້ງານຕັ້ງແຕ່ "
 ],
 "Required by ": [
  null,
  "ຕ້ອງການໂດຍ "
 ],
 "Read-only": [
  null,
  "ອ່ານຢ່າງດຽວ"
 ],
 "Requires administration access to edit": [
  null,
  "ຕ້ອງການສິດຜູ້ດູແລລະບົບເພື່ອແກ້ໄຂ"
 ],
 "Automatically starts": [
  null,
  "ເລີ່ມຕົ້ນອັດຕະໂນມັດ"
 ],
 "Updating status...": [
  null,
  "ກຳລັງອັບເດດສະຖານະ..."
 ],
 "Stop and disable": [
  null,
  "ຢຸດ ແລະ ປິດໃຊ້ງານ"
 ],
 "Start and enable": [
  null,
  "ເລີ່ມ ແລະ ເປີດໃຊ້ງານ"
 ],
 "Failed to load unit": [
  null,
  "ບໍ່ສາມາດໂຫຼດຢູນິດໄດ້"
 ],
 "View all services": [
  null,
  "ເບິ່ງບໍລິການທັງໝົດ"
 ],
 "Triggers": [
  null,
  "ຕົວເປີດເຮັດວຽກ"
 ],
 "Triggered by": [
  null,
  "ຖືກເປີດເຮັດວຽກໂດຍ"
 ],
 "Requires": [
  null,
  "ຕ້ອງການ"
 ],
 "Requisite": [
  null,
  "ສິ່ງທີ່ຈຳເປັນ (Requisite)"
 ],
 "Wants": [
  null,
  "ຕ້ອງການ"
 ],
 "Binds to": [
  null,
  "ຜູກກັບ"
 ],
 "Part of": [
  null,
  "ເປັນສ່ວນໜຶ່ງຂອງ"
 ],
 "Required by": [
  null,
  "ຕ້ອງການໂດຍ"
 ],
 "Requisite of": [
  null,
  "ເປັນສິ່ງທີ່ຈຳເປັນຂອງ"
 ],
 "Wanted by": [
  null,
  "ຕ້ອງການໂດຍ"
 ],
 "Bound by": [
  null,
  "ຖືກຜູກໂດຍ"
 ],
 "Consists of": [
  null,
  "ປະກອບດ້ວຍ"
 ],
 "Conflicts": [
  null,
  "ຂັດແຍ້ງກັບ"
 ],
 "Conflicted by": [
  null,
  "ຂັດແຍ້ງໂດຍ"
 ],
 "Before": [
  null,
  "ກ່ອນ"
 ],
 "After": [
  null,
  "ຫຼັງຈາກ"
 ],
 "On failure": [
  null,
  "ເມື່ອເກີດຄວາມຜິດພາດ"
 ],
 "Propagates reload to": [
  null,
  "ສົ່ງຕໍ່ການໂຫຼດໃໝ່ໄປຍັງ"
 ],
 "Reload propagated from": [
  null,
  "ການໂຫລດໃໝ່ຖືກສົ່ງມາຈາກ"
 ],
 "Joins namespace of": [
  null,
  "ເຂົ້າຮ່ວມເນມສະເປສຂອງ"
 ],
 "Condition $0=$1 was not met": [
  null,
  "ບໍ່ກົງກັບເງື່ອນໄຂ $0=$1"
 ],
 "Deletion will remove the following files:": [
  null,
  "ການລຶບຈະນຳເອົາໄຟລ໌ຕໍ່ໄປນີ້ອອກ:"
 ],
 "Pinned unit": [
  null,
  "ໜ່ວຍງານທີ່ປັກໝຸດແລ້ວ"
 ],
 "Status": [
  null,
  "ສະຖານະ"
 ],
 "Path": [
  null,
  "ເສັ້ນທາງ (Path)"
 ],
 "Listen": [
  null,
  "Listen"
 ],
 "Container": [
  null,
  "ຄອນເທນເນີ (Container)"
 ],
 "View Podman container": [
  null,
  "ເບິ່ງຄອນເທນເນີ Podman"
 ],
 "Condition failed": [
  null,
  "ເງື່ອນໄຂຫຼົ້ມເຫຼວ"
 ],
 "Show more relationships": [
  null,
  "ສະແດງຄວາມສຳພັນເພີ່ມເຕີມ"
 ],
 "Show relationships": [
  null,
  "ສະແດງຄວາມສຳພັນ"
 ],
 "Confirm deletion of $0": [
  null,
  "ຢືນຢັນການລຶບ $0"
 ],
 "Timer deletion failed": [
  null,
  "ລຶບຕົວຕັ້ງເວລາບໍ່ສຳເລັດ"
 ],
 "Targets": [
  null,
  "ເປົ້າໝາຍ"
 ],
 "Sockets": [
  null,
  "ຊັອກເກັດ (Sockets)"
 ],
 "Timers": [
  null,
  "ຕົວຕັ້ງເວລາ"
 ],
 "Paths": [
  null,
  "ເສັ້ນທາງ (Paths)"
 ],
 "Go to $0": [
  null,
  "ໄປທີ່ $0"
 ],
 "Journal entry not found": [
  null,
  "ບໍ່ພົບລາຍການເຈີເນິລ"
 ],
 "Journal entry": [
  null,
  "ລາຍການເຈີເນິລ"
 ],
 "Entry at $0": [
  null,
  "ລາຍການທີ່ $0"
 ],
 "Logs": [
  null,
  "ບັນທຶກລັອກ"
 ],
 "Loading unit failed": [
  null,
  "ການໂຫຼດຢູນິດຫຼົ້ມເຫຼວ"
 ],
 "Service logs": [
  null,
  "ບັນທຶກເຫດການຂອງບໍລິການ"
 ],
 "No log entries": [
  null,
  "ບໍ່ມີລາຍການບັນທຶກເຫດການ"
 ],
 "Systemd units": [
  null,
  "Systemd units"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "ບໍ່ມີຜົນລັບທີ່ກົງກັບເງື່ອນໄຂການກັ່ນຕອງ. ກະລຸນາລ້າງຕົວຢຸດການກັ່ນຕອງທັງໝົດເພື່ອສະແດງຜົນລັບ."
 ],
 "Does not automatically start": [
  null,
  "ບໍ່ເລີ່ມຕົ້ນເຮັດວຽກອັດຕະໂນມັດ"
 ],
 "Cannot be enabled": [
  null,
  "ບໍ່ສາມາດເປີດໃຊ້ງານໄດ້"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web console ກຳລັງເຮັດວຽກໃນໂໝດການເຂົ້າເຖິງແບບຈຳກັດ."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console ສຳລັບ Linux ເຊີເວີ"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ແມ່ນລະບົບຈັດການເຊີເວີທີ່ຊ່ວຍໃຫ້ການບໍລິຫານເຊີເວີ Linux ຂອງທ່ານຜ່ານເວັບບຣາວເຊີເປັນເລື່ອງງ່າຍ. ທ່ານສາມາດສະຫຼັບການເຮັດວຽກລະຫວ່າງເທີມິນໍ ແລະ ເຄື່ອງມືເວັບໄດ້ຢ່າງສະດວກ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ແມ່ນເໝາະສົມສຳລັບຜູ້ດູແລລະບົບໃໝ່, ຊ່ວຍໃຫ້ດຳເນີນວຽກງ່າຍໆ ເຊັ່ນ ການຈັດການບ່ອນເກັບຂໍ້ມູນ, ກວດສອບລັອກ ແລະ ການຈັດການບໍລິການຕ່າງໆ."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "ເມື່ອຕິດຕັ້ງ Cockpit ແລ້ວ, ໃຫ້ເປີດໃຊ້ງານດ້ວຍຄຳສັ່ງ \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ການຕັ້ງຄ່າ NetworkManager ແລະ Firewalld ຂອງ Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການເຄືອຂ່າຍ ເຊັ່ນ bonds, bridges, teams, VLANs ແລະ ໄຟວໍ (firewalls) ໂດຍໃຊ້ NetworkManager ແລະ Firewalld."
 ],
 "Manage storage": [
  null,
  "ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຈັດການບ່ອນຈັດເກັບຂໍ້ມູນພາຍໃນເຄື່ອງ ເຊັ່ນ ລະບົບໄຟລ໌, LVM2 volume groups, ແລະ ການຕິດຕັ້ງ NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "ເກັບກຳ ແລະ ລວມແພັກເກດຂໍ້ມູນການວິເຄາະ ແລະ ການຊ່ວຍເຫຼືອ"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ສ້າງໄຟລ໌ເກັບຂໍ້ມູນການຕັ້ງຄ່າ ແລະ ຂໍ້ມູນການວິເຄາະຈາກລະບົບທີ່ກຳລັງເຮັດວຽກຢູ່. ຂໍ້ມູນເຫຼົ່ານີ້ອາດຖືກເກັບໄວ້ໃນເຄື່ອງ ຫຼື ສ່ວນກາງເພື່ອຈຸດປະສົງໃນການບັນທຶກ ຫຼື ຕິດຕາມ, ຫຼື ສົ່ງໃຫ້ຝ່າຍຊ່ວຍເຫຼືອທາງເຕັກນິກ, ນັກພັດທະນາ ຫຼື ຜູ້ດູແລລະບົບເພື່ອຊ່ວຍໃນການແກ້ໄຂບັນຫາ ແລະ ດີບັກ (debug)."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "ການຕັ້ງຄ່າ ແລະ ການແກ້ໄຂບັນຫາ Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່ານະໂຍບາຍ SELinux ແລະ ສາມາດຊ່ວຍໃນການເຂົ້າໃຈ ແລະ ແກ້ໄຂການລະເມີດນະໂຍບາຍໄດ້."
 ],
 "Collect kernel crash dumps": [
  null,
  "ເກັບກຳຂໍ້ມູນ kernel crash dumps"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ເຄື່ອງມືນີ້ໃຊ້ຕັ້ງຄ່າລະບົບເພື່ອບັນທຶກ kernel crash dumps. ມັນຮອງຮັບເປົ້າໝາຍການເກັບແບບ \"local\" (ດິດ), \"ssh\", ແລະ \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ການບໍລິຫານດ້ວຍ Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "ຕ້ອງມີການຢືນຢັນຕົວຕົນເພື່ອດຳເນີນການວຽກທີ່ມີສິດພິເສດດ້ວຍ Cockpit Web Console"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "ຈາກ $0 ຢູ່ $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "ຈາກ $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "ຢູ່ $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "ໂດເມນ"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "ເຂົ້າຮ່ວມໂດເມນ"
 ]
});
