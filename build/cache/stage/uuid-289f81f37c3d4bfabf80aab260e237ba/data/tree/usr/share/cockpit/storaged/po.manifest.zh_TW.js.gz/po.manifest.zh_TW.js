cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "網路"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "unmount": [
  null,
  "卸載"
 ],
 "mount": [
  null,
  "掛載"
 ],
 "format": [
  null,
  "格式化"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "檔案系統"
 ],
 "partition": [
  null,
  "分割區"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "磁碟區"
 ],
 "disk": [
  null,
  "磁碟"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "硬碟"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "加密"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "管理分割區"
 ],
 "Managing NFS mounts": [
  null,
  "管理 NFS 掛載"
 ],
 "Managing RAIDs": [
  null,
  "管理 RAID"
 ],
 "Managing LVMs": [
  null,
  "管理 LVM"
 ],
 "Managing physical drives": [
  null,
  "管理實體硬碟"
 ],
 "Managing VDOs": [
  null,
  "管理 VDO"
 ],
 "Using LUKS encryption": [
  null,
  "使用 LUKS 加密"
 ],
 "Using Tang server": [
  null,
  "使用 Tang 伺服器"
 ]
});
