cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
