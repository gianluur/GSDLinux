cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "unmount": [
  null,
  "unmount"
 ],
 "mount": [
  null,
  "mount"
 ],
 "format": [
  null,
  "format"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "sistem berkas"
 ],
 "partition": [
  null,
  "partisi"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volume"
 ],
 "disk": [
  null,
  "disk"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "drive"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "enkripsi"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Mengelola partisi"
 ],
 "Managing NFS mounts": [
  null,
  "Mengelola mount NFS"
 ],
 "Managing RAIDs": [
  null,
  "Mengelola RAID"
 ],
 "Managing LVMs": [
  null,
  "Mengelola LVM"
 ],
 "Managing physical drives": [
  null,
  "Mengelola drive fisik"
 ],
 "Managing VDOs": [
  null,
  "Mengelola VDO"
 ],
 "Using LUKS encryption": [
  null,
  "Menggunakan enkripsi LUKS"
 ],
 "Using Tang server": [
  null,
  "Menggunakan server Tang"
 ]
});
