cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Overview": [
  null,
  "ພາບລວມ"
 ],
 "user": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
