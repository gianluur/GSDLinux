cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-ის კონტეინერები"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "კონტეინერი"
 ],
 "image": [
  null,
  "გამოსახულება"
 ]
});
