cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ur",
  "language-direction": "rtl"
 },
 "Anaconda": [
  null,
  ""
 ]
});
