cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit 파일"
 ],
 "Home": [
  null,
  "홈"
 ],
 "Unable to create bookmark directory": [
  null,
  "즐겨찾기 디렉토리를 생성 할 수 없음"
 ],
 "Unable to save bookmark file": [
  null,
  "즐겨찾기 파일을 저장 할 수 없음"
 ],
 "Remove from bookmarks": [
  null,
  "즐겨찾기에서 제거"
 ],
 "Add to bookmarks": [
  null,
  "즐겨찾기에 추가"
 ],
 "Bookmarks": [
  null,
  "즐겨찾기"
 ],
 "Bookmarked": [
  null,
  "즐겨찾기 됨"
 ],
 "Not bookmarked": [
  null,
  "즐겨찾기 안 됨"
 ],
 "Filesystem": [
  null,
  "파일시스템"
 ],
 "Edit path": [
  null,
  "경로 편집"
 ],
 "Name": [
  null,
  "이름"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Largest size": [
  null,
  "최대 크기"
 ],
 "Smallest size": [
  null,
  "최소 크기"
 ],
 "Modified": [
  null,
  "수정됨"
 ],
 "First modified": [
  null,
  "처음 수정됨"
 ],
 "Last modified": [
  null,
  "마지막으로 수정됨"
 ],
 "Owner": [
  null,
  "소유자"
 ],
 "Owner ascending": [
  null,
  "소유자 오름차순"
 ],
 "Owner descending": [
  null,
  "소유자 내림차순"
 ],
 "Permissions": [
  null,
  "권한"
 ],
 "Most permissive": [
  null,
  "관대한 허용"
 ],
 "Least permissive": [
  null,
  "최소 허용"
 ],
 "Show keyboard shortcuts": [
  null,
  "키보드 단축키 표시"
 ],
 "Filter directory": [
  null,
  "필터 디렉토리"
 ],
 "Display as a list": [
  null,
  "목록으로 표시"
 ],
 "Display as a grid": [
  null,
  "그리드로 표시"
 ],
 "Sort": [
  null,
  "정렬"
 ],
 "Hide hidden items": [
  null,
  "숨겨진 항목 감추기"
 ],
 "Show hidden items": [
  null,
  "숨겨진 항목 표시"
 ],
 "$0 files": [
  null,
  "$0 파일"
 ],
 "Uploaded as $0, $1": [
  null,
  "$0, $1 로 올려짐"
 ],
 "Replace file $0?": [
  null,
  "파일 $0를 교체합니까?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "동일한 이름을 갖는 파일은 이미 \"$0\"에 존재합니다. 이 대체하기는 해당 내용을 덮어씁니다."
 ],
 "New file": [
  null,
  "신규 파일"
 ],
 "Original file on server": [
  null,
  "서버에서 원본 파일"
 ],
 "Apply this action to all conflicting files": [
  null,
  "모든 충돌하는 파일에 이와 같은 동작을 적용합니다"
 ],
 "Replace": [
  null,
  "교체"
 ],
 "Keep original": [
  null,
  "원본 유지"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Failed": [
  null,
  "실패함"
 ],
 "Upload error": [
  null,
  "올려주기 오류"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "올려진 파일을 최종 목적지에 이동 할 수 없음"
 ],
 "Cancelled": [
  null,
  "취소됨"
 ],
 "Cancelled upload of $0": [
  null,
  "$0 올려주기 취소됨"
 ],
 "File uploaded": [
  null,
  "파일 올려짐"
 ],
 "Files uploaded": [
  null,
  "파일 올려짐"
 ],
 "Change permissions": [
  null,
  "권한 변경"
 ],
 "Uploads": [
  null,
  "올려주기"
 ],
 "Cancel upload of $0": [
  null,
  "$0 올려주기 취소"
 ],
 "Upload $0% completed": [
  null,
  "올려주기 $0% c완료"
 ],
 "Upload": [
  null,
  "올려주기"
 ],
 "None": [
  null,
  "없음"
 ],
 "Execute-only": [
  null,
  "실행-전용"
 ],
 "Write-only": [
  null,
  "쓰기-전용"
 ],
 "Write and execute": [
  null,
  "쓰기 및 실행"
 ],
 "Read-only": [
  null,
  "읽기-전용"
 ],
 "Read and execute": [
  null,
  "읽기 및 실행"
 ],
 "Read and write": [
  null,
  "읽기 및 쓰기"
 ],
 "Read, write, and execute": [
  null,
  "읽기, 쓰기 및 실행"
 ],
 "Block device": [
  null,
  "블록 장치"
 ],
 "Character device": [
  null,
  "문자 장치"
 ],
 "Directory": [
  null,
  "디렉토리"
 ],
 "Named pipe": [
  null,
  "이름이 지정된 파이프"
 ],
 "Symbolic link": [
  null,
  "심볼릭 링크"
 ],
 "Regular file": [
  null,
  "일반 파일"
 ],
 "Socket": [
  null,
  "소켓"
 ],
 "Name cannot be empty": [
  null,
  "이름은 비워 둘 수 없습니다"
 ],
 "Name too long": [
  null,
  "이름이 너무 길어요"
 ],
 "Name cannot include a /": [
  null,
  "이름은 /를 포함 할 수 없습니다"
 ],
 "Filename is the same as original name": [
  null,
  "파일이름이 원래의 이름과 동일합니다"
 ],
 "Directory with the same name exists": [
  null,
  "동일한 이름을 갖는 디렉토리가 존재합니다"
 ],
 "File exists": [
  null,
  "파일이 존재합니다"
 ],
 "Pasting failed": [
  null,
  "붙여넣기 실패함"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" 존재하며, 붙여서 덮어쓰지 않습니다."
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Create directory": [
  null,
  "디렉토리 생성"
 ],
 "Create file": [
  null,
  "파일 생성"
 ],
 "Edit permissions": [
  null,
  "권한을 편집합니다"
 ],
 "Open in terminal": [
  null,
  "터미널에서 열기"
 ],
 "Open text file": [
  null,
  "텍스트 파일 열기"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Rename": [
  null,
  "이름변경"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Download": [
  null,
  "내려받기"
 ],
 "Create link": [
  null,
  "연결 생성"
 ],
 "Drop files to upload": [
  null,
  "올려지는 파일을 삭제합니다"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "다른 파일이 이미 진행 중이기 때문에 파일을 삭제 할 수 없습니다"
 ],
 "Close": [
  null,
  "종료"
 ],
 "Go up a directory": [
  null,
  "상위 디렉토리로 이동"
 ],
 "Go back": [
  null,
  "뒤로 이동"
 ],
 "Go forward": [
  null,
  "앞으로 가기"
 ],
 "Activate selected item, enter directory": [
  null,
  "선택된 항목을 활성화 하고, 디렉토리를 입력합니다"
 ],
 "Rename selected file or directory": [
  null,
  "선택된 파일 또는 디렉토리 이름변경"
 ],
 "Create new directory": [
  null,
  "신규 디렉토리 생성"
 ],
 "Copy selected file or directory": [
  null,
  "선택된 파일 또는 디렉토리를 복사"
 ],
 "Paste file or directory": [
  null,
  "파일 또는 디렉토리 붙여넣기"
 ],
 "Select all": [
  null,
  "모두 선택"
 ],
 "Save current file": [
  null,
  "현재 파일 저장"
 ],
 "Close editor": [
  null,
  "편집기 닫기"
 ],
 "Keyboard shortcuts": [
  null,
  "키보드 단축키"
 ],
 "Navigation": [
  null,
  "탐색"
 ],
 "Editing": [
  null,
  "편집하기"
 ],
 "Editor": [
  null,
  "편집기"
 ],
 "Force delete $0 items": [
  null,
  "$0 항목 삭제를 강제합니다"
 ],
 "Delete $0 items?": [
  null,
  "$0 항목을 삭제할까요?"
 ],
 "Force delete file $0?": [
  null,
  "파일 $0 삭제를 강제할까요?"
 ],
 "Delete file $0?": [
  null,
  "파일 $0를 삭제할까요?"
 ],
 "Force delete link $0?": [
  null,
  "링크 $0 삭제를 강제할까요?"
 ],
 "Delete link $0?": [
  null,
  "링크 $0를 삭제할까요?"
 ],
 "Force delete directory $0?": [
  null,
  "디렉토리 $0 삭제를 강제할까요?"
 ],
 "Delete directory $0?": [
  null,
  "디렉토리 $0를 삭제할까요?"
 ],
 "Force delete $0": [
  null,
  "$0를 삭제를 강제합니다"
 ],
 "Delete $0?": [
  null,
  "$0 삭제?"
 ],
 "No access": [
  null,
  "접근 불가"
 ],
 "Missing type": [
  null,
  "누락 유형"
 ],
 "Collapse": [
  null,
  "붕괴"
 ],
 "Show all files": [
  null,
  "모든 파일 표시"
 ],
 "$0 permissions": [
  null,
  "$0 권한"
 ],
 "Permissions for $0 files": [
  null,
  "$0 파일을 위한 권한"
 ],
 "Ownership": [
  null,
  "소유권"
 ],
 "Group": [
  null,
  "그룹"
 ],
 "Access": [
  null,
  "접근"
 ],
 "Owner access": [
  null,
  "소유자 접근"
 ],
 "Group access": [
  null,
  "그룹 접근"
 ],
 "Others access": [
  null,
  "기타 접근"
 ],
 "Security context": [
  null,
  "보안 문맥"
 ],
 "Set executable as program": [
  null,
  "실행 할 수 있는 프로그램 설정"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Change permissions for enclosed files": [
  null,
  "첨부된 파일을 위한 권한 변경"
 ],
 "(original owner)": [
  null,
  "(원소유자)"
 ],
 "keep original owners": [
  null,
  "원소유자 유지"
 ],
 "Paste as owner": [
  null,
  "소유자로 붙여넣기"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "붙여 넣기 중인 파일에 다른 소유자가 있습니다. 기본 값으로, 소유권은 대상 디렉토리와 일치하도록 변경됩니다."
 ],
 "New owner": [
  null,
  "새로운 소유자"
 ],
 "Overwrite": [
  null,
  "덮어쓰기"
 ],
 "New filename": [
  null,
  "신규 파일이름"
 ],
 "New name": [
  null,
  "새로운 이름"
 ],
 "Rename $0?": [
  null,
  "$0 이름변경?"
 ],
 "link to $0": [
  null,
  "$0 로 연결"
 ],
 "Create link to $0": [
  null,
  "$0로 연결 생성"
 ],
 "Target": [
  null,
  "대상"
 ],
 "Symlink name": [
  null,
  "심볼릭 링크 이름"
 ],
 "Type": [
  null,
  "유형"
 ],
 "Absolute vs. Relative": [
  null,
  "절대적인 대 상대적인"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "절대적인 심볼릭 링크는 시스템 파일처럼 움직이지 않는 파일이나 디렉토리를 참조 할 때 이상적입니다."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "상대적인 심볼릭 링크는 심볼릭 링크 및 대상 모두가 부모(상위) 디렉토리의 이름 변경하기나 이동처럼 동시에 움직일 때에 유용합니다."
 ],
 "Absolute": [
  null,
  "절대적인"
 ],
 "Relative": [
  null,
  "상대적인"
 ],
 "The file has been removed on disk": [
  null,
  "파일이 디스크에서 제거되었습니다"
 ],
 "The existing file changed unexpectedly": [
  null,
  "기존 파일이 예상치 못하게 변경되었습니다"
 ],
 "Edit $0": [
  null,
  "$0 편집"
 ],
 "View $0": [
  null,
  "$0 보기"
 ],
 "The file has changed on disk": [
  null,
  "파일이 디스크에서 변경되었습니다"
 ],
 "Reload": [
  null,
  "재적재"
 ],
 "Ignore": [
  null,
  "무시"
 ],
 "Save": [
  null,
  "저장"
 ],
 "Save changes?": [
  null,
  "변경을 저장할까요?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "파일은 열린 후에 삭제되고, 저장하면 이를 다시 생성합니다."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "파일이 열렸을 때와 현재 사이에서 디스크 부분이 변경되었습니다"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 는 변경이 저장되지 않았고 이는 만약 삭제되었다면 영구히 손실됩니다."
 ],
 "Discard": [
  null,
  "버림"
 ],
 "File name": [
  null,
  "파일 이름"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Cannot create file in current directory": [
  null,
  "현재 디렉토리에서 파일을 생성 할 수 없습니다"
 ],
 "Permission denied": [
  null,
  "권한이 거부되었습니다"
 ],
 "Directory name cannot be empty": [
  null,
  "디렉토리 이름은 비워 둘 수 없습니다"
 ],
 "Directory name too long": [
  null,
  "디렉토리 이름이 너무 길어요"
 ],
 "Directory name cannot include a /": [
  null,
  "디렉토리 이름은 /를 포함 할 수 없습니다"
 ],
 "Directory name": [
  null,
  "디렉토리 이름"
 ],
 "Directory owner": [
  null,
  "디렉토리 소유자"
 ],
 "No matching results": [
  null,
  "일치하는 결과를 찾을 수 없습니다"
 ],
 "Clear filter": [
  null,
  "필터 지우기"
 ],
 "Directory is empty": [
  null,
  "디렉토리가 비어 있습니다"
 ],
 "$0 item is hidden": [
  null,
  "$0 항목이 숨겨졌습니다"
 ],
 "Folder": [
  null,
  "폴더"
 ],
 "File": [
  null,
  "파일"
 ],
 "Others": [
  null,
  "기타"
 ],
 "$0 files selected": [
  null,
  "$0 파일을 선택함"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "디렉토리는 $0 디렉토리, $1 파일을 포함합니다"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "디렉토리는 $0 디렉토리, $1 파일, $2 숨김 파일을 포함합니다"
 ],
 "User": [
  null,
  "사용자"
 ]
});
