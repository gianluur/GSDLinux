cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "服務"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "network": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "介面"
 ],
 "bridge": [
  null,
  "橋接"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "bond"
 ],
 "team": [
  null,
  "team"
 ],
 "port": [
  null,
  "連接埠"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "防火牆"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "區域"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "管理網路 bond"
 ],
 "Managing networking teams": [
  null,
  "管理網路 team"
 ],
 "Managing networking bridges": [
  null,
  "管理網路橋接"
 ],
 "Managing VLANs": [
  null,
  "管理 VLAN"
 ],
 "Managing firewall": [
  null,
  "防火牆管理"
 ]
});
