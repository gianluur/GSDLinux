cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Accounts": [
  null,
  "Account"
 ],
 "user": [
  null,
  "utente"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "password"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nome utente"
 ],
 "login": [
  null,
  "accesso"
 ],
 "access": [
  null,
  "accesso"
 ],
 "roles": [
  null,
  "ruoli"
 ],
 "keys": [
  null,
  "chiavi"
 ],
 "Managing user accounts": [
  null,
  "Gestione degli account utente"
 ]
});
