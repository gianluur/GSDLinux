cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==0) ? 0 : (n==1) ? 1 : (n==2) ? 2 : (n==3) ? 3 :(n==6) ? 4 : 5),
  "language": "cy",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
