cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Unlock": [
  null,
  "Öffnen"
 ],
 "Add key": [
  null,
  "Schlüssel hinzufügen"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "Set": [
  null,
  "Einstellen"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "Trust and add host": [
  null,
  "Host vertrauen und hinzufügen"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Wenn der Fingerabdruck übereinstimmt, klicken Sie 'Vertrauen und Host hinzufügen'. Andernfalls lehnen Sie die Verbindung ab und kontaktieren Sie den Administrator."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Der resultierende Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden. Wenn Sie eine andere Person bitten, die Überprüfung für Sie vorzunehmen, kann diese die Ergebnisse mit einer beliebigen Methode übermitteln."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "Verify fingerprint": [
  null,
  "Fingerabdruck verifizieren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Führen Sie diesen Befehl über ein vertrauenswürdiges Netzwerk oder physisch auf dem entfernten Rechner aus:"
 ],
 "The fingerprint should match:": [
  null,
  "Der Fingerabdruck sollte übereinstimmen:"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "Permission denied": [
  null,
  "Erlaubnis verweigert"
 ],
 "Clear input value": [
  null,
  "Eingabewert löschen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit $0 zu synchronisieren"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "Create $0": [
  null,
  "$0 erstellen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Es stehen keine Methoden zur Verfügung, um Administratorrechte zu erlangen (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "less than a minute ago": [
  null,
  "vor weniger als einer Minute"
 ],
 "in less than a minute": [
  null,
  "in weniger als einer Minute"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Strong password": [
  null,
  "Starkes Passwort"
 ],
 "Acceptable password": [
  null,
  "Annehmbares Passwort"
 ],
 "Weak password": [
  null,
  "Schwaches Passwort"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Hide password": [
  null,
  "Passwort verbergen"
 ],
 "password quality": [
  null,
  "Passwortstärke"
 ],
 "Show confirmation password": [
  null,
  "Bestätigungspasswort anzeigen"
 ],
 "Hide confirmation password": [
  null,
  "Bestätigungspasswort ausblenden"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Removing $0": [
  null,
  "Entferne $0"
 ],
 "Installing $0": [
  null,
  "Installiere $0"
 ],
 "Unknown host: $0": [
  null,
  "Unbekannter Host: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort an."
 ],
 "SSH key login": [
  null,
  "SSH-Schlüssel-Anmeldung"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit hat Fehlercode gemeldet $0"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "Row expansion": [
  null,
  "Zeilenerweiterung"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Error during initialization": [
  null,
  "Fehler während der Initialisierung"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Home": [
  null,
  "Persönlicher Ordner"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Kein Verzeichnis"
 ],
 "All files": [
  null,
  "Alle Dateien"
 ],
 "Recent": [
  null,
  "Zuletzt verwendet"
 ],
 "No recent directories": [
  null,
  "Keine aktuellen Verzeichnisse"
 ],
 "No recent files": [
  null,
  "Keine aktuellen Dateien"
 ],
 "Type to filter": [
  null,
  "Zum Filtern tippen"
 ],
 "File chooser actions": [
  null,
  "Aktionen in der Dateiauswahl"
 ],
 "Open in file browser": [
  null,
  "Im Dateibrowser öffnen"
 ],
 "Hide hidden files": [
  null,
  "Versteckte Dateien ausblenden"
 ],
 "Show hidden files": [
  null,
  "Versteckte Dateien anzeigen"
 ],
 "Filesystem": [
  null,
  "Dateisystem"
 ],
 "Clear filters": [
  null,
  "Filter löschen"
 ],
 "Directory is empty": [
  null,
  "Verzeichnis ist leer"
 ],
 "Directory has no sub-directories": [
  null,
  "Verzeichnis hat keine Unterverzeichnisse"
 ],
 "This directory contains only hidden files": [
  null,
  "Dieses Verzeichnis enthält nur versteckte Dateien"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "Folder": [
  null,
  "Ordner"
 ],
 "File": [
  null,
  "Datei"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Embedded PC": [
  null,
  "Eingebetteter PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Select an option": [
  null,
  "Wählen Sie eine Option aus"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "View logs": [
  null,
  "Protokolle ansehen"
 ],
 "Dismiss": [
  null,
  "Abweisen"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "none": [
  null,
  "kein"
 ],
 "Not found": [
  null,
  "Nicht gefunden"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "Not running": [
  null,
  "Läuft nicht"
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "State": [
  null,
  "Status"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Confirm deletion of $0": [
  null,
  "Löschen von $0 bestätigen"
 ],
 "Username": [
  null,
  "Benutzername"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Started": [
  null,
  "Gestartet"
 ],
 "Delete group": [
  null,
  "Gruppe löschen"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Lock": [
  null,
  "Schließen"
 ],
 "Use $0": [
  null,
  "$0 verwenden"
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "Disconnect": [
  null,
  "Verbindung trennen"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "$0 disk is missing": [
  null,
  "$0 Festplatte fehlt",
  "$0 Festplatten fehlen"
 ],
 "Location": [
  null,
  "Ort"
 ],
 "Compression": [
  null,
  "Komprimierung"
 ],
 "Storage logs": [
  null,
  "Speicherprotokolle"
 ],
 "Name cannot be empty.": [
  null,
  "Name darf nicht leer sein."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Name darf nicht länger als 127 Zeichen sein."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Name darf nicht das Zeichen '$0' enthalten."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Name darf keine Leerzeichen enthalten."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Name darf nicht länger als $0 Zeichen sein"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Name darf nicht länger als $0 Bytes sein"
 ],
 "$name (from $host)": [
  null,
  "$name (von $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool für Thin Logical Volumes"
 ],
 "Thin logical volume": [
  null,
  "Dünnes logisches Volumen"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisches Volume (Momentaufnahme)"
 ],
 "Logical volume": [
  null,
  "Logischer Datenträger"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID-Gerät $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2-Volumengruppe $0"
 ],
 "VDO device $0": [
  null,
  "VDO-Gerät $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Verschlüsselter logischer Datenträger von $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Verschlüsselte Partition von $0"
 ],
 "Logical volume of $0": [
  null,
  "Logisches Volumen von $0"
 ],
 "Partition of $0": [
  null,
  "Partition von $0"
 ],
 "Encrypted $0": [
  null,
  "Verschlüsselt $0"
 ],
 "unpartitioned space on $0": [
  null,
  "nicht partitionierter Speicherplatz auf $0"
 ],
 "unmount": [
  null,
  "Aushängen"
 ],
 "mount": [
  null,
  "Einhängen"
 ],
 "remove from btrfs volume": [
  null,
  "aus btrfs-Volume entfernen"
 ],
 "stop": [
  null,
  "Stopp"
 ],
 "remove from MDRAID": [
  null,
  "aus MDRAID entfernen"
 ],
 "remove from LVM2": [
  null,
  "aus LVM2 entfernen"
 ],
 "btrfs device": [
  null,
  "btrfs-Gerät"
 ],
 "btrfs volume": [
  null,
  "btrfs-Volume"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Name darf nicht länger als 255 Zeichen sein."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Name darf nicht das Zeichen '/' enthalten."
 ],
 "Create and mount": [
  null,
  "Anlegen und Einhängen"
 ],
 "Create only": [
  null,
  "Nur anlegen"
 ],
 "Create subvolume": [
  null,
  "Untervolume erstellen"
 ],
 "Mount Point": [
  null,
  "Einhängepunkt"
 ],
 "delete": [
  null,
  "löschen"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Subvolume $0 endgültig löschen?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Das Löschen entfernt alle Daten auf diesem Untervolume und allen Abkömmlingen."
 ],
 "Edit mount point": [
  null,
  "Einhängepunkt bearbeiten"
 ],
 "Unmount": [
  null,
  "Aushängen"
 ],
 "Mount": [
  null,
  "Einhängen"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Mindestens ein Subvolume muss eingehängt werden"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Das zuletzt eingehängte Subvolume kann nicht gelöscht werden"
 ],
 "btrfs subvolume": [
  null,
  "btrfs-Subvolume"
 ],
 "Snapshot origin": [
  null,
  "Herkunft des Schnappschusses"
 ],
 "Mount point": [
  null,
  "Einhängepunkt"
 ],
 "No subvolumes": [
  null,
  "Keine Subvolumes"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs-Subvolumes"
 ],
 "Snapshots": [
  null,
  "Schnappschüsse"
 ],
 "No snapshots found": [
  null,
  "Keine Schnappschüsse gefunden"
 ],
 "snapshot": [
  null,
  "Schnappschuss"
 ],
 "$0 is in use": [
  null,
  "$0 verwendet"
 ],
 "Permanently delete $0?": [
  null,
  "$0 dauerhaft löschen?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Beim Löschen werden alle Daten auf dem btrfs-Volume gelöscht."
 ],
 "Delete filesystem": [
  null,
  "Dateisystem löschen"
 ],
 "Change label": [
  null,
  "Bezeichnung ändern"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Dateisystem ist schreibgeschützt eingehängt"
 ],
 "Label": [
  null,
  "Label"
 ],
 "Capacity": [
  null,
  "Kapazität"
 ],
 "btrfs devices": [
  null,
  "btrfs-Geräte"
 ],
 "No devices found": [
  null,
  "Keine Geräte gefunden"
 ],
 "btrfs filesystem": [
  null,
  "btrfs-Dateisystem"
 ],
 "Successful": [
  null,
  "Erfolgreich"
 ],
 "Aborted": [
  null,
  "Abgebrochen"
 ],
 "In progress": [
  null,
  "In Bearbeitung"
 ],
 "Interrupted": [
  null,
  "Unterbrochen"
 ],
 "Did not complete": [
  null,
  "Nicht abgeschlossen"
 ],
 "Failed (Unknown)": [
  null,
  "Fehlgeschlagen (unbekannt)"
 ],
 "Failed (Electrical)": [
  null,
  "Fehlgeschlagen (elektrisch)"
 ],
 "Failed (Servo)": [
  null,
  "Fehlgeschlagen (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Fehlgeschlagen (Lesen)"
 ],
 "Failed (Damaged)": [
  null,
  "Fehlgeschlagen (beschädigt)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Abbruch durch einen Reset auf Controller-Ebene"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Abbruch durch die Entfernung eines Namensraums aus dem Namensraum-Inventar"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Abbruch durch die Verarbeitung eines Format NVM Kommandos"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Während des Selbsttestvorgangs ist ein schwerwiegender Fehler aufgetreten"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Abgeschlossen mit einem fehlgeschlagenen Segment und das fehlgeschlagene Segment ist nicht bekannt"
 ],
 "Completed with one or more failed segments": [
  null,
  "Abgeschlossen mit einem oder mehreren fehlgeschlagenen Segmenten"
 ],
 "Aborted for unknown reason": [
  null,
  "Aus unbekanntem Grund abgebrochen"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Abbruch durch eine Bereinigungsaktion"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Die Kapazitätsreserven liegen unter dem Schwellenwert"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatur außerhalb der empfohlenen Schwellenwerte"
 ],
 "Degraded": [
  null,
  "Herabgestuft"
 ],
 "All media is in read-only mode": [
  null,
  "Alle Medien sind im Nur-Lese-Modus"
 ],
 "Volatile memory backup failed": [
  null,
  "Die Sicherung des flüchtigen Speichers ist fehlgeschlagen"
 ],
 "Persistent memory has become read-only": [
  null,
  "Persistenter Speicher ist schreibgeschützt geworden"
 ],
 "Run short test": [
  null,
  "Kurzen Test durchführen"
 ],
 "Run extended test": [
  null,
  "Erweiterten Test durchführen"
 ],
 "Abort test": [
  null,
  "Test abbrechen"
 ],
 "Disk is failing": [
  null,
  "Festplatte versagt"
 ],
 "Disk is OK": [
  null,
  "Datenträger ist OK"
 ],
 "Assessment": [
  null,
  "Bewertung"
 ],
 "Power on hours": [
  null,
  "Einschaltstunden"
 ],
 "$0 hours": [
  null,
  "$0 Stunden"
 ],
 "Self-test status": [
  null,
  "Selbsttest-Status"
 ],
 "Number of bad sectors": [
  null,
  "Anzahl der fehlerhaften Sektoren"
 ],
 "Attributes failing": [
  null,
  "Attribute fehlerhaft"
 ],
 "Media drive": [
  null,
  "Medienlaufwerk"
 ],
 "Solid State Drive": [
  null,
  "Festkörperlaufwerk"
 ],
 "Hard Disk Drive": [
  null,
  "Festplattenlaufwerk"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI-Laufwerk"
 ],
 "Drive": [
  null,
  "Speichergerät"
 ],
 "Device health (SMART)": [
  null,
  "Gerätegesundheit (SMART)"
 ],
 "Firmware version": [
  null,
  "Firmware-Version"
 ],
 "Serial number": [
  null,
  "Seriennummer"
 ],
 "World wide name": [
  null,
  "Weltweiter Name"
 ],
 "No media inserted": [
  null,
  "Keine Medien eingelegt"
 ],
 "Device file": [
  null,
  "Gerätedatei"
 ],
 "Multipathed devices": [
  null,
  "Multipath Geräte"
 ],
 "Free space": [
  null,
  "Freiraum"
 ],
 "Create partition": [
  null,
  "Partition erzeugen"
 ],
 "Extended partition": [
  null,
  "Erweiterte Partition"
 ],
 "$0 partitions": [
  null,
  "$0 Partitionen"
 ],
 "Partitions": [
  null,
  "Partitionen"
 ],
 "No partitions found": [
  null,
  "Keine Partitionen gefunden"
 ],
 "Unexpected partitions": [
  null,
  "Unterwartete Partitionen"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Partitionen werden auf diesem Blockgerät nicht unterstützt. Wenn es als Platte für eine Virtuelle Maschine verwendet wird, müssen die Partitionen vom Betriebssystem in der Virtuellen Maschine verwaltet werden."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Beim Löschen einer Partition werden alle darin enthaltenen Daten gelöscht."
 ],
 "No free space after this partition": [
  null,
  "Kein freier Speicherplatz nach dieser Partition"
 ],
 "EFI system partition": [
  null,
  "EFI-Systempartition"
 ],
 "BIOS boot partition": [
  null,
  "BIOS-Boot-Partition"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Shrink": [
  null,
  "Verkleinern"
 ],
 "Grow": [
  null,
  "Wachsen"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP-Boot-Partition"
 ],
 "Linux swap space": [
  null,
  "Linux-Auslagerungsspeicher"
 ],
 "Linux filesystem data": [
  null,
  "Linux-Dateisystemdaten"
 ],
 "Logical Volume Manager partition": [
  null,
  "Logische Datenträger Verwaltungs-Partition"
 ],
 "Custom": [
  null,
  "Benutzerdefiniert"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ muss genau zwei hexadezimale Zeichen enthalten (0 bis 9, A bis F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ kann nur die Zeichen 0 bis 9, A bis F und „-“ enthalten."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ muss der Form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN entsprechen."
 ],
 "Set partition type of $0": [
  null,
  "Partitionstyp von $0 festlegen"
 ],
 "Custom type": [
  null,
  "Benutzerdefinierter Typ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Eine Änderung des Partitionstyps kann dazu führen, dass das System nicht mehr gebootet werden kann."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Diese Partition ist nicht vollständig durch seinen Inhalt belegt."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Die Größe der Partition beträgt $0. Die Größe des Inhalts beträgt $1."
 ],
 "Shrink partition": [
  null,
  "Partition verkleinern"
 ],
 "Grow content": [
  null,
  "Inhalte erweitern"
 ],
 "initialize": [
  null,
  "initialisieren"
 ],
 "Initialize disk $0": [
  null,
  "Festplatte $0 initialisieren"
 ],
 "Partitioning": [
  null,
  "Partitionierung"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel mit allen Systemen und Geräten (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel mit modernen Systemen und Festplatten > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Keine Partitionierung"
 ],
 "Overwrite": [
  null,
  "Überschreiben"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Vorhandene Daten mit Nullen überschreiben (langsamer)"
 ],
 "Initialize": [
  null,
  "Initialisieren"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Beim Initialisieren werden alle Daten auf einem Datenträger gelöscht."
 ],
 "Device is read-only": [
  null,
  "Gerät ist schreibgeschützt"
 ],
 "Create partition table": [
  null,
  "Partitionstabelle anlegen"
 ],
 "Size must be a number": [
  null,
  "Die Größe muss eine Nummer sein"
 ],
 "Size cannot be zero": [
  null,
  "Größe darf nicht Null sein"
 ],
 "Size cannot be negative": [
  null,
  "Größe darf nicht negativ sein"
 ],
 "Size is too large": [
  null,
  "Größe zu groß"
 ],
 "Size must be at least $0": [
  null,
  "Größe muss mindestens sein $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "physisches Volumen der LVM2-Volumengruppe"
 ],
 "member of MDRAID device": [
  null,
  "Mitglied des MDRAID-Geräts"
 ],
 "backing device for VDO device": [
  null,
  "Sicherungsgerät für das VDO-Gerät"
 ],
 "member of Stratis pool": [
  null,
  "Mitglied im Stratis-Pool"
 ],
 "Filesystem outside the target": [
  null,
  "Dateisystem außerhalb des Ziels"
 ],
 "device of btrfs volume": [
  null,
  "Gerät des btrfs-Volumes"
 ],
 "This device is currently in use.": [
  null,
  "Dieses Gerät ist derzeit in Gebrauch."
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Use": [
  null,
  "Verwenden"
 ],
 "Services using the location": [
  null,
  "Dienste, die den Ort nutzen"
 ],
 "Processes using the location": [
  null,
  "Prozesse, die den Ort nutzen"
 ],
 "Currently in use": [
  null,
  "Aktuell verwendet"
 ],
 "(Not part of target)": [
  null,
  "(Nicht Teil des Ziels)"
 ],
 "These changes will be made:": [
  null,
  "Diese Änderungen werden vorgenommen:"
 ],
 "Action": [
  null,
  "Aktion"
 ],
 "Important data might be deleted:": [
  null,
  "Wichtige Daten werden möglicherweise gelöscht:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Zugehörige Prozesse und Dienste werden zwangsweise gestoppt."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Zugehörige Prozesse werden zwangsweise gestoppt."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Zugehörige Dienste werden zwangsweise gestoppt."
 ],
 "Checking filesystem usage": [
  null,
  "Dateisystembelegung wird überprüft"
 ],
 "$0 used, $1 total": [
  null,
  "$0 verwendet, $1 insgesamt"
 ],
 "Device contains unrecognized data": [
  null,
  "Gerät enthält nicht erkannte Daten"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Gesperrtes verschlüsseltes Gerät könnte Daten enthalten"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Ich bestätige, dass ich diese Daten für immer verlieren möchte"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Der Einhängepunkt $0 wird von diesen Prozessen verwendet:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Der Einhängepunkt $0 wird von diesen Diensten verwendet:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Die aufgelisteten Prozesse und Dienste werden zwangsweise gestoppt."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Die aufgelisteten Prozesse werden zwangsweise gestoppt."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Die aufgelisteten Dienste werden zwangsweise gestoppt."
 ],
 "Sorry": [
  null,
  "Entschuldigung"
 ],
 "Usage of $0": [
  null,
  "Nutzung von $0"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO Pool"
 ],
 "Data used": [
  null,
  "Verwendete Daten"
 ],
 "Metadata used": [
  null,
  "Verwendete Metadaten"
 ],
 "Use compression": [
  null,
  "Komprimierung verwenden"
 ],
 "Deduplication": [
  null,
  "Deduplizierung"
 ],
 "Use deduplication": [
  null,
  "Deduplizierung verwenden"
 ],
 "Rename volume group": [
  null,
  "Datenträgerverbund umbennen"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Diese Datenträgergruppe beinhaltet das root-Dateisystem. Eine Umbenennung erfordert möglicherweise weitere Änderungen der Bootloaderkonfiguration oder der Kernel-Kommandozeile."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Beim Löschen werden alle Daten auf einer Volumengruppe gelöscht."
 ],
 "Create snapshot": [
  null,
  "Snapshot erzeugen"
 ],
 "Add disks": [
  null,
  "Datenträger hinzufügen"
 ],
 "Disks": [
  null,
  "Datenträger"
 ],
 "No disks are available.": [
  null,
  "Es sind keine Festplatten verfügbar."
 ],
 "At least one disk is needed.": [
  null,
  "Mindestens ein Datenträger ist nötig."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Der Datenträgergruppe fehlen physikalische Datenträger"
 ],
 "No free space": [
  null,
  "Kein freier Platz"
 ],
 "LVM2 volume group": [
  null,
  "LVM2-Volumengruppe"
 ],
 "Add physical volume": [
  null,
  "Physikalisches Volume hinzufügen"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 logische Volumes"
 ],
 "Create new logical volume": [
  null,
  "Logischen Datenträger erstellen"
 ],
 "No logical volumes": [
  null,
  "Keine logischen Volumes"
 ],
 "Remove missing physical volumes?": [
  null,
  "Fehlende physische Volumes entfernen?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Dieser Datenträgergruppe fehlen einige physikalische Datenträger."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Eine Volume-Gruppe mit fehlenden physikalischen Volumes kann nicht umbenannt werden."
 ],
 "Physical volumes": [
  null,
  "Physikalische Volumen"
 ],
 "No physical volumes found": [
  null,
  "Keine physikalischen Volumes gefunden"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 physische Volumes"
 ],
 "Rename logical volume": [
  null,
  "Logischen Datenträger umbenennen"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Logisches Volume $0/$1 endgültig löschen?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Beim Löschen eines logischen Datenträgers werden alle darin enthaltenen Daten gelöscht."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Logisches Volume $0 konnte nicht repariert werden"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Für eine Reperatur steht nicht ausreichend Speicherplatz zur Verfügung. Es wird mindestens $0 auf physikalischen Datenträgern benötigt, die noch nicht für diesen logischen Datenträger verwendet werden."
 ],
 "An additional $0 must be selected": [
  null,
  "Eine zusätzliche $0 muss ausgewählt werden"
 ],
 "Repair logical volume $0": [
  null,
  "Logisches Volume $0 reparieren"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Wählen Sie die physischen Volumes aus, die für die Reparatur des logischen Volumes verwendet werden sollen. Es werden mindestens $0 benötigt."
 ],
 "Physical Volumes": [
  null,
  "Physikalische Volumes"
 ],
 "Repair": [
  null,
  "Reparieren"
 ],
 "deactivate": [
  null,
  "deaktivieren"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Logisches Volume $0/$1 deaktivieren?"
 ],
 "Deactivate": [
  null,
  "Deaktivieren"
 ],
 "Not enough space to grow": [
  null,
  "Nicht genug Platz für Vergrößerung"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 logisches Volume"
 ],
 "Striped (RAID 0)": [
  null,
  "Striped (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Gespiegelt (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Striped und Mirrored (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Dedizierte Parität (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Verteilte Parität (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Doppelte verteilte Parität (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dieses logische Volumen ist nicht vollständig durch seinen Inhalt belegt."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Die Größe des Volumens beträgt $0. Die Größe des Inhalts beträgt $1."
 ],
 "Shrink volume": [
  null,
  "Volumen verkleinern"
 ],
 "Layout": [
  null,
  "Layout"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Dieser logische Datenträger hat einige seiner physikalischen Datenträger verloren und kann nicht mehr verwendet werden. Sie müssen ihn löschen und zum Ersatz einen neuen erstellen."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Dieser logische Datenträger hat einige seiner physikalischen Datenträger aber bislang keine Daten verloren. Sie sollten ihn reparieren, um seine Redundanz wieder herzustellen."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Dieser logische Datenträger hat einige seiner physikalischen Datenträger aber bislang keine Daten verloren. Eine Reparatur sollte möglich sein."
 ],
 "Stripes": [
  null,
  "Stripes"
 ],
 "$0 synchronized": [
  null,
  "$0 synchronisiert"
 ],
 "Create volume group": [
  null,
  "Datenträgerverbund erstellen"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 physisches Volume"
 ],
 "Last cannot be removed": [
  null,
  "Letzteres kann nicht entfernt werden"
 ],
 "Not enough free space": [
  null,
  "Nicht genügend freier Platz"
 ],
 "Volume group": [
  null,
  "Datenträgerverbund"
 ],
 "Create thin volume": [
  null,
  "Thin Volume erstellen"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Dünn bereitgestellte LVM2 Datenträger"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Neuen dünn provisionierten logischen Datenträger erstellen"
 ],
 "Not enough space": [
  null,
  "Nicht genügend Platz"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool für dünn bereitgestellte LVM2 Datenträger"
 ],
 "Inactive logical volume": [
  null,
  "Inaktives logisches Volume"
 ],
 "Activate": [
  null,
  "Aktivieren"
 ],
 "Unsupported logical volume": [
  null,
  "Nicht unterstütztes logisches Volume"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNER FEHLER - Dieses logische Volume ist als aktiv markiert und sollte ein zugehöriges Blockgerät haben. Es konnte jedoch kein solches Blockgerät gefunden werden."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Die Installation von $0 würde $1 entfernen."
 ],
 "Installing packages": [
  null,
  "Pakete werden installiert"
 ],
 "Block device for filesystems": [
  null,
  "Gerät für Dateisysteme blockieren"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool für dünn bereitgestellte Datenträger"
 ],
 "Linear": [
  null,
  "Linear"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-Dateisystemvolumen (Komprimierung/Deduplizierung)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Die Daten werden auf den ausgewählten physischen Volumes ohne zusätzliche Redundanz oder Leistungssteigerung gespeichert."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Die Daten werden abwechselnd auf den ausgewählten physischen Volumes gespeichert, um die Leistung zu verbessern. Es müssen mindestens zwei Volumes ausgewählt werden."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Die Daten werden in zwei oder mehr Kopien auf den ausgewählten physischen Volumes gespeichert, um die Zuverlässigkeit zu erhöhen. Es müssen mindestens zwei Volumes ausgewählt werden."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Die Daten werden in zwei Kopien und auch abwechselnd auf den ausgewählten physischen Volumes gespeichert, um sowohl die Zuverlässigkeit als auch die Leistung zu verbessern. Es müssen mindestens vier Volumes ausgewählt werden."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Die Daten werden auf den ausgewählten physischen Volumes gespeichert, sodass einer von ihnen verloren gehen kann, ohne die Daten zu beeinträchtigen. Es müssen mindestens drei Volumes ausgewählt werden."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Die Daten werden auf den ausgewählten physischen Volumes gespeichert, sodass eines davon verloren gehen kann, ohne die Daten zu beeinträchtigen. Die Daten werden auch abwechselnd gespeichert, um die Leistung zu verbessern. Es müssen mindestens drei Volumes ausgewählt werden."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Die Daten werden auf den ausgewählten physischen Volumes gespeichert, sodass bis zu zwei von ihnen gleichzeitig verloren gehen können, ohne dass die Daten beeinträchtigt werden. Die Daten werden auch abwechselnd gespeichert, um die Leistung zu verbessern. Es müssen mindestens fünf Volumes ausgewählt werden."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Alle $0 ausgewählten physischen Volumes werden für das ausgewählte Layout benötigt."
 ],
 "Create logical volume": [
  null,
  "Logischen Datenträger erstellen"
 ],
 "Purpose": [
  null,
  "Verwendungszweck"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Das Paket $0 wird installiert, um VDO-Geräte zu erstellen."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 benötigt eine gerade Anzahl von physischen Volumes"
 ],
 "Logical size": [
  null,
  "Logische Größe"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Speicherplatz durch komprimieren der einzelnen Blöcke mit LZ4 spare"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Sparen Sie Platz, indem identische Datenblöcke nur einmal gespeichert werden"
 ],
 "Creating VDO device": [
  null,
  "VDO-Gerät wird erstellt"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Dieser NFS-Mount wird verwendet und nur die Optionen können geändert werden."
 ],
 "NFS mount": [
  null,
  "NFS-Mount"
 ],
 "New NFS mount": [
  null,
  "Neuer NFS-Mount"
 ],
 "Server address": [
  null,
  "Serveradresse"
 ],
 "Server cannot be empty.": [
  null,
  "Server darf nicht leer sein."
 ],
 "Path on server": [
  null,
  "Pfad auf dem Server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Pfad auf dem Server darf nicht leer sein."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Pfad auf dem Server muss mit \"/\" beginnen."
 ],
 "Local mount point": [
  null,
  "Lokaler Einhängepunkt"
 ],
 "Mount point cannot be empty.": [
  null,
  "Einhängepunkt darf nicht leer sein."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Einhängepunkt muss mit \"/\" beginnen."
 ],
 "Mount options": [
  null,
  "Einhängoptionen"
 ],
 "Mount at boot": [
  null,
  "beim Start einhängen"
 ],
 "Mount read only": [
  null,
  "Dateisystem als nur lesbar einhängen"
 ],
 "Custom mount options": [
  null,
  "Benutzerdefinierte Einhängeoptionen"
 ],
 "Unable to unmount filesystem": [
  null,
  "Das Aushängen des Dateisystems ist nicht möglich"
 ],
 "Stop and unmount": [
  null,
  "Anhalten und aushängen"
 ],
 "Unable to remove mount": [
  null,
  "Mount kann nicht entfernt werden"
 ],
 "Stop and remove": [
  null,
  "Anhalten und entfernen"
 ],
 "(not mounted)": [
  null,
  "(nicht eingehängt)"
 ],
 "Start multipath": [
  null,
  "Multipath starten"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Es gibt Geräte mit mehreren Pfaden im System, der Multipath-Dienst wird jedoch nicht ausgeführt."
 ],
 "Show all $0 rows": [
  null,
  "Alle $0 Zeilen anzeigen"
 ],
 "Category": [
  null,
  "Kategorie"
 ],
 "more info": [
  null,
  "weitere Informationen"
 ],
 "Encryption": [
  null,
  "Verschlüsselung"
 ],
 "encrypted": [
  null,
  "verschlüsselt"
 ],
 "Last modified: $0": [
  null,
  "Zuletzt geändert: $0"
 ],
 "Stored passphrase": [
  null,
  "Gespeichertes Passwort"
 ],
 "Encryption options": [
  null,
  "Verschlüsselungsoptionen"
 ],
 "Encryption type": [
  null,
  "Verschlüsselungstyp"
 ],
 "Cleartext device": [
  null,
  "Klartext-Gerät"
 ],
 "yes": [
  null,
  "Ja"
 ],
 "Disk passphrase": [
  null,
  "Disk-Passwort"
 ],
 "Passphrase cannot be empty": [
  null,
  "Passwort darf nicht leer sein"
 ],
 "Unlocking disk": [
  null,
  "Festplatte wird entsperrt"
 ],
 "Checking for $0 package": [
  null,
  "Prüfung auf Paket $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Das Paket $0 muss installiert sein."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Das Paket $0 ist in keinem Repositorium verfügbar."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Fehler bei der Installation von $0: dnf5daemon-server ist nicht installiert"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Unerwarteter PackageManager-Fehler bei der Installation von $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Prüfung auf NBDE Unterstützung in der initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Die initrd muss neu generiert werden."
 ],
 "Regenerating initrd": [
  null,
  "initrd wird neu generiert"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Hinzufügen von rd.neednet=1 zur kernel command line"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Hinzufügen von \"$0\" zu Dateisystemoptionen"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Hinzufügen von \"$0\" zu Verschlüsselungsoptionen"
 ],
 "Enabling $0": [
  null,
  "$0 wird aktiviert"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Netzwerkgebundene Festplattenverschlüsselung hinzufügen"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Das System unterstützt momentan nicht das Entsperren des root-Dateisystems mit einem Tang Schlüsselserver."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Das System unterstützt momentan nicht das Entsperren eines Dateisystems mit einem Tang Schlüsselserver während des Bootvorgangs."
 ],
 "These additional steps are necessary:": [
  null,
  "Diese zusätzlichen Schritte sind notwendig:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Das Speichern eines neuen Passworts erfordert das Entsperren der Festplatte. Bitte geben Sie ein aktuelles Disk-Passwort an."
 ],
 "Fix NBDE support": [
  null,
  "NBDE-Unterstützung beheben"
 ],
 "Adding key": [
  null,
  "Schlüssel wird hinzugefügt"
 ],
 "Key source": [
  null,
  "Schlüsselquelle"
 ],
 "Repeat passphrase": [
  null,
  "Passwort wiederholen"
 ],
 "Passphrase": [
  null,
  "Passphrase"
 ],
 "Tang keyserver": [
  null,
  "Tang Keyserver"
 ],
 "New passphrase": [
  null,
  "Neues Passwort"
 ],
 "Passphrases do not match": [
  null,
  "Passwörter stimmen nicht überein"
 ],
 "Keyserver address": [
  null,
  "Keyserver-Adresse"
 ],
 "Change passphrase": [
  null,
  "Passwort ändern"
 ],
 "Old passphrase": [
  null,
  "Altes Passwort"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang-Keyserver bearbeiten"
 ],
 "Verify key": [
  null,
  "Schlüssel überprüfen"
 ],
 "Trust key": [
  null,
  "Schlüssel vertrauen"
 ],
 "Passphrase can not be empty": [
  null,
  "Passwort darf nicht leer sein"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Das Entfernen des Passwortes verhindert möglicherweise das Entsperren $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bestätigen Sie die Entfernung mit einem alternativen Passwort"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Das Entfernen eines Passworts ohne Bestätigung mit einem anderen Passwort kann das Entsperren oder die Schlüsselverwaltung verhindern, wenn andere Passwörter vergessen oder verloren werden."
 ],
 "Passphrase from any other key slot": [
  null,
  "Passwort-Satz von irgendeinem anderen Schlüsselplatz"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Passwort von Schlüsselplatz $0 entfernen?"
 ],
 "Remove $0?": [
  null,
  "Löschen $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Das Entfernen kann das Entsperren verhindern. $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang-Schlüsselserver entfernen?"
 ],
 "Remove key in slot $0?": [
  null,
  "Schlüssel in Schlüsselplatz $0 entfernen?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Der aktuell angemeldete Benutzer kann keine Informationen zu Schlüsseln anzeigen."
 ],
 "No keys added": [
  null,
  "Keine Schlüssel hinzugefügt"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Das Bearbeiten eines Schlüssels erfordert einen freien Steckplatz"
 ],
 "The last key slot can not be removed": [
  null,
  "Der letzte Schlüsselschlitz kann nicht entfernt werden"
 ],
 "Keyserver": [
  null,
  "Schlüsselserver"
 ],
 "Unknown type": [
  null,
  "Unbekannter Typ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Schlüsselplätze mit unbekannten Typen können hier nicht bearbeitet werden"
 ],
 "Keys": [
  null,
  "Schlüssel"
 ],
 "$0 slot remains": [
  null,
  "$0 Slot übrig",
  "$0 Slots übrig"
 ],
 "No available slots": [
  null,
  "Keine verfügbaren Slots"
 ],
 "No free key slots": [
  null,
  "Keine freien Schlüsselplätze"
 ],
 "Locked data": [
  null,
  "Gesperrte Daten"
 ],
 "lock": [
  null,
  "sperren"
 ],
 "Lock $0?": [
  null,
  "$0 sperren?"
 ],
 "Address cannot be empty": [
  null,
  "Adresse darf nicht leer sein"
 ],
 "Address is not a valid URL": [
  null,
  "Adresse ist keine gültige URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Überprüfen Sie den Schlüsselhash mit dem Tang-Server."
 ],
 "How to check": [
  null,
  "Wie überprüfen"
 ],
 "In a terminal, run: ": [
  null,
  "Führen Sie in einem Terminal folgenden Befehl aus: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Erfolgreich in die Zwischenablage kopiert!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Überprüfen Sie, ob der SHA-256- oder SHA-1-Hash des Befehls mit diesem Dialogfeld übereinstimmt."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs-Subvolume $0 auf $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Einhängepunkt darf nicht leer sein"
 ],
 "Mount point is already used for $0": [
  null,
  "Einhängepunkt wird bereits von $0 verwendet"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Dateisysteme sind bereits unter diesem Einhängepunkt eingehängt."
 ],
 "Please unmount them first.": [
  null,
  "Bitte hängen Sie diese zuerst aus."
 ],
 "read only": [
  null,
  "nur lesbar"
 ],
 "never mount at boot": [
  null,
  "beim Booten nie einhängen"
 ],
 "after network": [
  null,
  "nach dem Netzwerk"
 ],
 "ignore failure": [
  null,
  "Ausfall ignorieren"
 ],
 "stop boot on failure": [
  null,
  "Bootvorgang bei Fehler stoppen"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Das Dateisystem hat keinen zugeordneten Einhängepunkt."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Das Dateisystem hat keinen permanenten Einhängepunkt."
 ],
 "The filesystem is not mounted.": [
  null,
  "Das Dateisystem ist nicht eingehängt."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Das Dateisystem wird beim nächsten Booten entsperrt und eingehängt. Dies kann die Eingabe eines Passworts erfordern."
 ],
 "(no assigned mount point)": [
  null,
  "(kein zugewiesener Einhängepunkt)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Das Dateisystem ist momentan als $0 eingehangen und wird beim nächsten Systemstart als $1 eingehangen."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Automatisch bei Start unter $0 einhängen"
 ],
 "Mount on $0 now": [
  null,
  "Jetzt unter $0 einhängen"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Das Dateisystem ist momentan als nicht eingehangen und wird beim nächsten Systemstart eingehangen."
 ],
 "Do not mount automatically on boot": [
  null,
  "Nicht beim Systemstart automatisch einhängen"
 ],
 "Mount now": [
  null,
  "Jetzt einbinden"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Das Dateisystem ist momentan eingehangen, wird aber bei nächsten Systemstart nicht eingehangen."
 ],
 "Mount also automatically on boot": [
  null,
  "Automatisch bei Start einhängen"
 ],
 "Unmount now": [
  null,
  "Jetzt aushängen"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Das Dateisystem ist momentan als $0 eingehangen und wird beim nächsten Systemstart nicht eingehangen."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Das Dateisystem ist so konfiguriert, dass es beim Booten automatisch eingehängt wird, aber sein Verschlüsselungscontainer wird zu diesem Zeitpunkt nicht entsperrt."
 ],
 "Unlock automatically on boot": [
  null,
  "Beim Booten automatisch entsperren"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inkonsistenter Dateisystem-Einhängepunkt"
 ],
 "$0 filesystem": [
  null,
  "$0-Dateisystem"
 ],
 "Filesystem name": [
  null,
  "Dateisystemname"
 ],
 "Filesystem is locked": [
  null,
  "Dateisystem ist gesperrt"
 ],
 "Mounts before services start": [
  null,
  "Hängt sich ein, bevor die Dienste starten"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Angemessen für wichtige mounts, wie /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Bootvorgang schlägt fehl, falls das Dateisystem nicht mountet, verhindert Fernzugriff"
 ],
 "Mounts in parallel with services": [
  null,
  "Hängt sich parallel zu den Diensten ein"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Bootvorgang ist erfolgreich, auch wenn das Dateisystem nicht eingehängt ist"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Hängt sich parallel zu den Diensten ein, aber erst wenn das Netzwerk zur Vefügung steht"
 ],
 "Does not mount during boot": [
  null,
  "Wird beim Systemstart nicht automatisch eingehängt"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Nützlich für Montierungen, die optional sind oder Interaktion erfordern (z. B. Passwörter)"
 ],
 "At boot": [
  null,
  "Beim Starten"
 ],
 "Mount before services start": [
  null,
  "Einhängen bevor die Dienste starten"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Einhängen ohne abzuwarten, Fehlermeldung ignorieren"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Einhängen nachdem das Netzwerk wieder zur Verfügung steht, Fehlermeldung ignorieren"
 ],
 "Do not mount": [
  null,
  "Nicht einhängen"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Dieses Gerät kann nicht für das Installationsziel verwendet werden."
 ],
 "Mount filesystem": [
  null,
  "Dateisystem einhängen"
 ],
 "Unmount filesystem $0": [
  null,
  "Dateisystem $0 aushängen"
 ],
 "Mount configuration": [
  null,
  "Einhängekonfiguration"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Benutzt"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Verschlüsselten Stratis-Pool freischalten"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Passwort für den Pool dieser Block-Geräte:"
 ],
 "Stratis pool": [
  null,
  "Stratis Pool"
 ],
 "stopped": [
  null,
  "gestoppt"
 ],
 "Block devices": [
  null,
  "Blockorientierte Geräte"
 ],
 "No block devices found": [
  null,
  "Keine Blockgeräte gefunden"
 ],
 "Stratis block devices": [
  null,
  "Stratis-Blockgeräte"
 ],
 "Stratis block device": [
  null,
  "Stratis-Blockgerät"
 ],
 "data": [
  null,
  "Daten"
 ],
 "cache": [
  null,
  "Cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Bitte geben Sie eine vorhandene Pool-Passphrase an."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Wenn der Schlüsselserver unter $0 nicht erreichbar ist, können Sie eine vorhandene Passphrase angeben."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Wenn keiner der Schlüsselserver erreichbar ist, können Sie eine vorhandene Passphrase angeben."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Wenn keine der nicht-interaktiven Entsperrmethoden funktioniert, können Sie eine vorhandene Passphrase eingeben."
 ],
 "Pool passphrase": [
  null,
  "Pool-Passwort"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Der Schlüsselserver unter $0 muss erreichbar sein."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Mindestens ein Schlüsselserver muss erreichbar sein."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Mindestens eine der nicht-interaktiven Entsperrmethoden muss funktionieren."
 ],
 "Create filesystem": [
  null,
  "Dateisystem erstellen"
 ],
 "Stratis filesystem": [
  null,
  "Stratis-Dateisystem"
 ],
 "Set initial size": [
  null,
  "Anfangsgröße festlegen"
 ],
 "Limit size": [
  null,
  "Größe begrenzen"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Das Löschen eines Stratis Pools entfernt alle sich darin befindlichen Daten."
 ],
 "Rename Stratis pool": [
  null,
  "Stratis Pool umbenennen"
 ],
 "Add block devices": [
  null,
  "Blockorientierte Geräte hinzufügen"
 ],
 "Tier": [
  null,
  "Ebene"
 ],
 "Data": [
  null,
  "Daten"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Das Hinzufügen von Blockgeräten erfordert das Entsperren des Pools."
 ],
 "Encrypted Stratis pool": [
  null,
  "Verschlüsselter Stratis-Pool"
 ],
 "Delete pool": [
  null,
  "Pool löschen"
 ],
 "Encryption tokens": [
  null,
  "Verschlüsselungstokens"
 ],
 "Stratis filesystems": [
  null,
  "Stratis-Dateisysteme"
 ],
 "Create new filesystem": [
  null,
  "Neues Dateisystem erstellen"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Dieser Pool nutzt nicht den gesamten Speicherplatz auf seinen Blockgeräten."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Einige Blockgeräte dieses Pools haben sich nach der Erstellung des Pools vergrößert. Der Pool kann sicher erweitert werden, um den neu verfügbaren Platz zu nutzen."
 ],
 "Grow the pool to take all space": [
  null,
  "Den Pool so vergrößern, dass er den gesamten Platz einnimmt"
 ],
 "This pool is in a degraded state.": [
  null,
  "Dieser Pool befindet sich in einem schlechten Zustand."
 ],
 "No filesystems": [
  null,
  "Keine Dateisysteme"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis Dateisystem-Pool"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Dieses Passwort ist die einzige Möglichkeit, den Pool zu entsperren und kann nicht entfernt werden."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Dieser Schlüsselserver ist die einzige Möglichkeit, den Pool zu entsperren und kann nicht entfernt werden."
 ],
 "Add passphrase": [
  null,
  "Passwort hinzufügen"
 ],
 "Add keyserver": [
  null,
  "Schlüsselserver hinzufügen"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis „$0“"
 ],
 "Last token can not be removed": [
  null,
  "Letztes Token kann nicht entfernt werden"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Kein Platz mehr für Passphrasen oder Schlüsselserver."
 ],
 "Confirm": [
  null,
  "Bestätigen"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Das Hinzufügen einer Passphrase erfordert das Entsperren des Pools."
 ],
 "Remove passphrase?": [
  null,
  "Passwort entfernen?"
 ],
 "Add Tang keyserver": [
  null,
  "Tang Keyserver hinzufügen"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Das Hinzufügen eines neuen Schlüsselservers erfordert das Entsperren des Bereichs."
 ],
 "Remove Clevis token?": [
  null,
  "Clevis-Token entfernen?"
 ],
 "Metadata format": [
  null,
  "Metadatenformat"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Pools mit dem Metadatenformat V1 sind auf maximal eine Passphrase und maximal einen Schlüsselserver beschränkt."
 ],
 "Overprovisioning": [
  null,
  "Überbereitstellung"
 ],
 "Allow overprovisioning": [
  null,
  "Überprovisionierung zulassen"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Die Größen der virtuellen Dateisysteme übersteigen die des Pools. Die Über-Provisionierung kann nicht deaktiviert werden."
 ],
 "Allocated": [
  null,
  "Zugewiesen"
 ],
 "Name can not be empty.": [
  null,
  "Name darf nicht leer sein."
 ],
 "A pool with this name exists already.": [
  null,
  "Ein Pool mit diesem Namen existiert bereits."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Ein Dateisystem mit diesem Namen existiert bereits in diesem Pool."
 ],
 "Create Stratis pool": [
  null,
  "Stratis Pool erstellen"
 ],
 "No block devices are available.": [
  null,
  "Es sind keine blockorientierten Geräte verfügbar."
 ],
 "At least one block device is needed.": [
  null,
  "Mindestens ein blockorientiertes Gerät ist erforderlich."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Verschlüsseln von Daten mit einem Passwort"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Daten mit einem Tang-Schlüsselserver verschlüsseln"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Einen Schnappschuss des Dateisystems $0 erstellen"
 ],
 "Create snapshot and mount": [
  null,
  "Snapshot erzeugen und einhängen"
 ],
 "Create snapshot only": [
  null,
  "Nur Snapshot erzeugen"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Beim Löschen eines Dateisystems werden alle darin enthaltenen Daten gelöscht."
 ],
 "Snapshot": [
  null,
  "Schnappschuss"
 ],
 "Rename filesystem": [
  null,
  "Dateisystem umbenennen"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Begrenzung der Größe des virtuellen Dateisystems festlegen"
 ],
 "Limit virtual filesystem size": [
  null,
  "Größe des virtuellen Dateisystems begrenzen"
 ],
 "Virtual size limit": [
  null,
  "Begrenzung der virtuellen Größe"
 ],
 "Virtual size": [
  null,
  "Virtuelle Größe"
 ],
 "Create RAID device": [
  null,
  "RAID-Gerät erzeugen"
 ],
 "RAID level": [
  null,
  "RAID Ebene"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (verteilt)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (gespiegelt)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (verteilte Daten & feste Parität)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (verteilte Daten & verteilte Parität)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (verteilte Daten & doppelt verteilte Parität)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (verteilt & gespiegelt)"
 ],
 "Chunk size": [
  null,
  "Datenblock Grösse"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Mindestens $0 Datenträger ist nötig.",
  "Mindestens $0 Datenträger sind nötig."
 ],
 "MDRAID disk": [
  null,
  "MDRAID-Festplatte"
 ],
 "In sync": [
  null,
  "Synchron"
 ],
 "Spare": [
  null,
  "Ersatz"
 ],
 "Recovering": [
  null,
  "Am Erholen"
 ],
 "Write-mostly": [
  null,
  "Hauptsächlich Schreiben"
 ],
 "Blocked": [
  null,
  "Gesperrt"
 ],
 "Unknown ($0)": [
  null,
  "Unbekannt ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Das MDRAID-Gerät muss in Betrieb sein"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID-Gerät wird wiederhergestellt"
 ],
 "Need a spare disk": [
  null,
  "Benötige eine Ersatzfestplatte"
 ],
 "Last disk can not be removed": [
  null,
  "Letzte Festplatte kann nicht entfernt werden"
 ],
 "MDRAID device": [
  null,
  "MDRAID-Gerät"
 ],
 "Confirm stopping of $0": [
  null,
  "Stoppen von $0 bestätigen"
 ],
 "Stop device": [
  null,
  "Gerät anhalten"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Beim Löschen werden alle Daten auf einem MDRAID-Gerät gelöscht."
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID-Gerät muss in Betrieb sein"
 ],
 "Add disk": [
  null,
  "Datenträger hinzufügen"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 Datenträger"
 ],
 "$0 chunk size": [
  null,
  "$0 Chunk Größe"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Das MDRAID-Gerät befindet sich in einem degradierten Zustand"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Dieses MDRAID-Gerät hat keine Bitmap für die Schreibberechtigung. Eine solche Bitmap kann die Synchronisierungszeiten erheblich reduzieren."
 ],
 "Add a bitmap": [
  null,
  "Bitmap hinzufügen"
 ],
 "No disks found": [
  null,
  "Keine Festplatten gefunden"
 ],
 "MDRAID disks": [
  null,
  "MDRAID-Festplatten"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Beim Löschen werden alle Daten auf einem VDO-Gerät gelöscht."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Die Erstellung dieses VDO-Geräts wurde nicht abgeschlossen und das Gerät kann nicht verwendet werden."
 ],
 "Remove device": [
  null,
  "Gerät entfernen"
 ],
 "Grow to take all space": [
  null,
  "Wachsen Sie, um den gesamten Raum einzunehmen"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Dieses VDO-Gerät verwendet nicht alle seine Hintergrundgeräte."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Nur $0 von $1 werden verwendet."
 ],
 "Grow logical size of $0": [
  null,
  "Vergrößern Sie die logische Größe von $0"
 ],
 "Physical": [
  null,
  "Physisch"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 Overhead verwendet von $2 ($3)"
 ],
 "Logical": [
  null,
  "Logisch"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 verwendet von $1 ($2 gespeichert)"
 ],
 "Index memory": [
  null,
  "Indexspeicher"
 ],
 "SMART self-test of $target": [
  null,
  "SMART-Selbsttest von $target"
 ],
 "Ejecting $target": [
  null,
  "$target wird ausgeworfen"
 ],
 "Unlocking $target": [
  null,
  "Entsperren $target"
 ],
 "Locking $target": [
  null,
  "Sperren $target"
 ],
 "Modifying $target": [
  null,
  "Ändern $target"
 ],
 "Resizing $target": [
  null,
  "Größenänderung von $target"
 ],
 "Starting swapspace $target": [
  null,
  "Auslagerungsbereich $target wird gestartet"
 ],
 "Stopping swapspace $target": [
  null,
  "Auslagerungsbereich $target wird angehalten"
 ],
 "Mounting $target": [
  null,
  "$target wird eingehängt"
 ],
 "Unmounting $target": [
  null,
  "$target wird ausgehängt"
 ],
 "Checking $target": [
  null,
  "$target wird überprüft"
 ],
 "Repairing $target": [
  null,
  "Reparieren $target"
 ],
 "Erasing $target": [
  null,
  "$target wird gelöscht"
 ],
 "Creating filesystem on $target": [
  null,
  "Dateisystem auf $target wird erzeugt"
 ],
 "Setting up loop device $target": [
  null,
  "Richte Loop Device $target ein"
 ],
 "Deleting $target": [
  null,
  "Lösche $target"
 ],
 "Creating partition $target": [
  null,
  "Erzeuge Partition $target"
 ],
 "Cleaning up for $target": [
  null,
  "$target wird aufgeräumt"
 ],
 "Securely erasing $target": [
  null,
  "$target wird sicher gelöscht"
 ],
 "Very securely erasing $target": [
  null,
  "$target wird sehr sicher gelöscht"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird gestoppt"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird gestartet"
 ],
 "Marking $target as faulty": [
  null,
  "$target als fehlerhaft markieren"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target wird aus MDRAID-Gerät entfernt"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird erstellt"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird überprüft"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird überprüft und repariert"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird wiederhergestellt"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID-Gerät $target wird synchronisiert"
 ],
 "Activating $target": [
  null,
  "Aktiviere $target"
 ],
 "Deactivating $target": [
  null,
  "Deaktiviere $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Erzeuge Snapshot von $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2-Volumengruppe $target erstellt"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2-Volumengruppe $target wird gelöscht"
 ],
 "Adding physical volume to $target": [
  null,
  "Füge physikalischen Datenträger zu $target hinzu"
 ],
 "Removing physical volume from $target": [
  null,
  "Entferne physikalischen Datenträger von $target"
 ],
 "Emptying $target": [
  null,
  "Leere $target"
 ],
 "Creating logical volume $target": [
  null,
  "Erzeuge logischen Datenträger $target"
 ],
 "Renaming $target": [
  null,
  "$target wird umbenannt"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operation '$operation' auf $target"
 ],
 "unknown target": [
  null,
  "Unbekanntes Ziel"
 ],
 "Jobs": [
  null,
  "Jobs"
 ],
 "Reading": [
  null,
  "Wird gelesen"
 ],
 "Writing": [
  null,
  "Schreiben"
 ],
 "Install Stratis support": [
  null,
  "Stratis-Unterstützung installieren"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Das $0 Paket muss installiert werden, um Stratis Pools erzeugen zu können."
 ],
 "Install NFS support": [
  null,
  "NFS-Unterstützung installieren"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID-Gerät erstellen"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2-Volumengruppe erstellen"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ändern Sie den Namen des iSCSI-Initiators"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI-Portal hinzufügen"
 ],
 "Local storage": [
  null,
  "Lokale Speicherung"
 ],
 "Networked storage": [
  null,
  "Vernetzte Speicherung"
 ],
 "Create storage device": [
  null,
  "Speichergerät erstellen"
 ],
 "No storage found": [
  null,
  "Kein Speicher gefunden"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradresse darf nicht leer sein."
 ],
 "Next": [
  null,
  "Weiter"
 ],
 "Invalid username or password": [
  null,
  "Benutzername oder Passwort ungültig"
 ],
 "Unknown host name": [
  null,
  "Unbekannter Host-Name"
 ],
 "Unable to reach server": [
  null,
  "Kann Server nicht erreichen"
 ],
 "Available targets on $0": [
  null,
  "Verfügbare Ziele am $0"
 ],
 "Authentication required": [
  null,
  "Authentifikation erforderlich"
 ],
 "iSCSI portal": [
  null,
  "iSCSI-Portal"
 ],
 "iSCSI drives": [
  null,
  "iSCSI-Laufwerke"
 ],
 "No drives found": [
  null,
  "Keine Laufwerke gefunden"
 ],
 "Target": [
  null,
  "Ziel"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-Sicherungsgeräte können nicht kleiner gemacht werden"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis-Blockgeräte können nicht kleiner gemacht werden"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nicht erkannte Daten können hier nicht verkleinert werden."
 ],
 "Unlock before resizing": [
  null,
  "Vor der Größenänderung entsperren"
 ],
 "$0 can not be resized here": [
  null,
  "$0 kann hier nicht in der Größe verändert werden"
 ],
 "$0 can not be resized": [
  null,
  "$0 kann nicht in der Größe verändert werden"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 kann nicht verkleinert werden"
 ],
 "$0 can not be made larger": [
  null,
  "$0 kann nicht vergrößer werden"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Die Größe physikalischer Volumes kann hier nicht geändert werden"
 ],
 "Swap can not be resized here": [
  null,
  "Größe der Auslagerung kann hier nicht geändert werden"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Nicht erkannte Daten können hier nicht verkleinert werden"
 ],
 "Activate before resizing": [
  null,
  "Vor der Größenänderung aktivieren"
 ],
 "Grow logical volume": [
  null,
  "Logisches Volumen erhöhen"
 ],
 "Grow partition": [
  null,
  "Partition erweitern"
 ],
 "grow": [
  null,
  "wachsen"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Es müssen genau $0 physische Volumes ausgewählt werden"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Die Größenänderung eines verschlüsselten Dateisystems benötigt das entsperren der Festplatte. Bitte geben sie das Passwort ein."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Es müssen genau $0 physische Datenträger ausgewählt werden, eines für jeden Stripe des logischen Datenträgers."
 ],
 "Shrink logical volume": [
  null,
  "Logisches Volumen verkleinern"
 ],
 "shrink": [
  null,
  "verkleinern"
 ],
 "Unformatted data": [
  null,
  "Unformatierte Daten"
 ],
 "Block device": [
  null,
  "Blockorientiertes Gerät"
 ],
 "Device number": [
  null,
  "Gerätenummer"
 ],
 "Create partition on $0": [
  null,
  "Partition auf $0 anlegen"
 ],
 "Format $0": [
  null,
  "$0 formatieren"
 ],
 "No filesystem": [
  null,
  "Kein Dateisystem"
 ],
 "(recommended)": [
  null,
  "(empfohlen)"
 ],
 "No encryption": [
  null,
  "Keine Verschlüsselung"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Vorhandene Verschlüsselung wiederverwenden ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Vorhandene Verschlüsselung wiederverwenden"
 ],
 "format": [
  null,
  "Formatieren"
 ],
 "Format and mount": [
  null,
  "Formatieren und einhängen"
 ],
 "Format only": [
  null,
  "Nur Formatieren"
 ],
 "Format": [
  null,
  "Formatieren"
 ],
 "Create and start": [
  null,
  "Erstellen und starten"
 ],
 "Format and start": [
  null,
  "Formatieren und starten"
 ],
 "Store passphrase": [
  null,
  "Passwort speichern"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Die Festplatte muss vor dem Formatieren entsperrt werden. Bitte geben Sie ein bestehendes Passwort an."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Beim Formatieren werden alle Daten auf einem Speichergerät gelöscht."
 ],
 "Unrecognized data": [
  null,
  "Unerkannte Daten"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Der Speicher kann auf diesem System nicht verwaltet werden."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Dieses Werkzeug konfiguriert das System zum Erzeugen von Kernel Crashdumps. Es unterstützt \"local\" (Festplatte), \"ssh\" und \"nfs\" als Schreibziele."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "format-bytes\u0004bytes": [
  null,
  "Bytes"
 ]
});
