cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Comment": [
  null,
  "הערה"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Fingerprint": [
  null,
  "טביעת אצבע"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Change password": [
  null,
  "החלפת סיסמה"
 ],
 "Password changed successfully": [
  null,
  "הסיסמה הוחלפה בהצלחה"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "Confirm password": [
  null,
  "אישור סיסמה"
 ],
 "Password tip": [
  null,
  "רמז לסיסמה"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "עצה: אפשר להגדיר את סיסמת המפתח שלך כמו סיסמת הכניסה שלך כדי להתאמת אוטומטית מול מערכות אחרות."
 ],
 "Unlock key $0": [
  null,
  "שחרור המפתח $0"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "SSH keys": [
  null,
  "מפתחות SSH"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "להשתמש במפתחות הבאים כדי להתאמת מול שרתים אחרים"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Toggle": [
  null,
  "בורר"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Public key": [
  null,
  "מפתח ציבורי"
 ],
 "Use key": [
  null,
  "להשתמש במפתח"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Hosts": [
  null,
  "מארחים"
 ],
 "Connection error": [
  null,
  "שגיאת התחברות"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Add new host": [
  null,
  "הוספת מארח חדש"
 ],
 "Host": [
  null,
  "מארח"
 ],
 "Stop editing hosts": [
  null,
  "הפסקת עריכת מארחים"
 ],
 "Edit hosts": [
  null,
  "עריכת מארחים"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "Active pages": [
  null,
  "עמודים פעילים"
 ],
 "Page name": [
  null,
  "שם העמוד"
 ],
 "There are currently no active pages": [
  null,
  "אין דפים פעילים כרגע"
 ],
 "Close selected pages": [
  null,
  "סגירת העמודים הנבחרים"
 ],
 "$0 documentation": [
  null,
  "התיעוד של $0"
 ],
 "About Web Console": [
  null,
  "על המסוף המקוון"
 ],
 "Style": [
  null,
  "סגנון"
 ],
 "Default": [
  null,
  "בררת מחדל"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Display language": [
  null,
  "שפת התצוגה"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Ooops!": [
  null,
  "אופס!"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Session": [
  null,
  "הפעלה"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "בכפוף לרישיון LGPL מבית GNU בגרסה 2.1"
 ],
 "Web Console": [
  null,
  "מסוף מקוון"
 ],
 "Web console logo": [
  null,
  "לוגו המסוף המקוון"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit הוא מנשק אינטראקטיבי לניהול שרתי לינוקס."
 ],
 "Project website": [
  null,
  "אתר המיזם"
 ],
 "Loading packages...": [
  null,
  "החבילות נטענות…"
 ],
 "Choose the language to be used in the application": [
  null,
  "נא לבחור את שפת היישום לשימוש"
 ],
 "Filter menu items": [
  null,
  "סינון פריטי תפריט"
 ],
 "No languages match": [
  null,
  "אין שפות תואמות"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "ב־Cockpit אירעה שגיאה בלתי צפויה."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "ברוב הדפדפנים"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "Clear search": [
  null,
  "ניקוי החיפוש"
 ],
 "Contains:": [
  null,
  "מכיל:"
 ],
 "Apps": [
  null,
  "יישומים"
 ],
 "Tools": [
  null,
  "כלים"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "לא ניתן ליצור קשר עם המארח שסופק $0. נא לוודא שיש לו ssh פעיל בפתחה $1 או לציין פתחה אחרת בכתובת."
 ],
 "Connect to $0?": [
  null,
  "להתחבר אל $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  ""
 ],
 "Read more": [
  null,
  "מידע נוסף"
 ],
 "Connect": [
  null,
  "התחברות"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "כתובת ה־IP או שם המארח לא יכולים להכיל רווח."
 ],
 "This machine has already been added.": [
  null,
  "מכונה זו כבר נוספה."
 ],
 "Failed to add machine: $0": [
  null,
  "הוספת המכונה נכשלה: $0"
 ],
 "Edit host": [
  null,
  "עריכת מארח"
 ],
 "Set": [
  null,
  "הגדרה"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "יכול להיות שם מארח, כתובת IP, שם כינוי או כתובת ssh://‎ מלאה"
 ],
 "When empty, connect with the current user": [
  null,
  "כאשר ריק, להתחבר עם המשתמש הנוכחי"
 ],
 "Color": [
  null,
  "צבע"
 ],
 "Failed to edit machine: $0": [
  null,
  "עריכת המכונה נכשלה: $0"
 ],
 "Could not contact $0": [
  null,
  "לא ניתן ליצור קשר עם $0"
 ],
 "Update": [
  null,
  "עדכון"
 ],
 "Unable to contact $0.": [
  null,
  "לא ניתן לצור קשר עם $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "האם sshd פועל על פתחה אחרת?"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "New host: $0": [
  null,
  "מארח חדש: $0"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "עמודים פוגעניים במכונה מרוחקת עלולים להשפיע על מארחים אחרים שמחוברים"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The new key password can not be empty": [
  null,
  "סיסמת המפתח החדשה לא יכולה להישאר ריקה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה. ייתכן שעידף לך להגדיר את מפתחות ה־SSH שלך לכניסה אוטומטית."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "יתכן שעדיף לך להחליף את הסיסמה של המפתח לטובת כניסה אוטומטית."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "כדי לאפשר כניסה אל $0 בתור $1 ללא סיסמה בעתיד, עליך להשתמש בסיסמת הכניסה של $2 על גבי $3 כסיסמת המפתח או להשאיר את סיסמת המפתח ריקה."
 ],
 "Change the password of $0": [
  null,
  "החלפת הסיסמה של $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "החלפת סיסמת מפתח ה־SSH‏ $0 לסיסמת הכניסה של $1 על גבי $2, תוביל לכך שהמפתח אוטומטית יהיה זמין ותהיה לך אפשרות להיכנס אל $3 ללא סיסמה בעתיד."
 ],
 "New key password": [
  null,
  "סיסמה חדשה למפתח"
 ],
 "Confirm new key password": [
  null,
  "אישור סיסמה חדשה למפתח"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "הגדרה זו תאפשר לך להיכנס ללא סיסמה בעתיד."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "Automatic login": [
  null,
  "כניסה אוטומטית"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "יצאת מהמערכת עקב חוסר פעילות."
 ],
 "Connection failed": [
  null,
  "ההתחברות נכשלה"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "הייתה שגיאה בלתי צפויה בעת ההתחברות למכונה."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "ניתן למצוא הודעות שקשורות בכשל בז׳ורנל:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "משתמשי Safari צריכים לייבא ולתת אמון באישור מרשות האישורים שנחתמה עצמית:"
 ],
 "Reconnect": [
  null,
  "התחברות מחדש"
 ],
 "Disconnected": [
  null,
  "מנותק"
 ],
 "The machine is rebooting": [
  null,
  "המכונה מופעלת מחדש"
 ],
 "Connecting to the machine": [
  null,
  "מתבצעת התחברות למכונה"
 ],
 "Not connected to host": [
  null,
  "לא מחובר למארח"
 ],
 "Cannot connect to an unknown host": [
  null,
  "לא ניתן להתחבר למארח לא ידוע"
 ],
 "Session is about to expire": [
  null,
  "תוקף ההפעלה עומד לפוג"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "המערכת תוציא אותך בעוד $0 שניות."
 ],
 "Continue session": [
  null,
  "להמשיך הפעלה"
 ],
 "Skip to content": [
  null,
  "דילוג לתוכן"
 ],
 "Skip main navigation": [
  null,
  "דילוג על הניווט הראשי"
 ],
 "Permission denied": [
  null,
  "ההרשאה נדחתה"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit דיווח את קוד השגיאה $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ]
});
