cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "el",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 σφάλμα",
  "$0 σφάλματα"
 ],
 "$0 installation": [
  null,
  "Εγκατάσταση του $0"
 ],
 "$0 installer": [
  null,
  "Βοηθός εγκατάστασης $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "Το $0 είναι ένα εκτεταμένο διαμέρισμα MBR που περιέχει λογικά διαμερίσματα. Η κατάργηση όλων των λογικών διαμερισμάτων θα διαγράψει αυτόματα και το εκτεταμένο διαμέρισμα."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Απαιτούνται $0, αλλά διατίθενται μόνο $1."
 ],
 "$0 warning": [
  null,
  "$0 προειδοποίηση",
  "$0 προειδοποιήσεις"
 ],
 "$0 will be deleted": [
  null,
  "Το λειτουργικό σύστημα «$0» θα διαγραφεί"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Το σύστημα αρχείων «$0» δεν μπορεί να βρίσκεται σε κρυπτογραφημένη συσκευή μπλοκ"
 ],
 "'$0' must be assigned to $1": [
  null,
  "Το «$0» πρέπει να ανατεθεί στο «$1»"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "Το «$0» πρέπει να βρίσκεται σε συσκευή με διαμόρφωση «$1»"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "Το «$0» πρέπει να βρίσκεται σε διαμέρισμα συστήματος EFI. Το επιλεγμένο διαμέρισμα χρησιμοποιεί το σύστημα αρχείων FAT, αλλά δεν έχει σημανθεί ως ESP. Ορίστε τον τύπο διαμερίσματος σε «Σύστημα EFI» και ενεργοποιήστε τη σημαία «esp»."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Βρέθηκε διαμέρισμα «$0» στη συσκευή MDRAID $1. Δεν υποστηρίζονται διαμερίσματα bootloader σε συσκευές MDRAID."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Ένας τυπικός λογαριασμός χρήστη με δικαιώματα διαχειριστή για την πραγματοποίηση αλλαγών σε επίπεδο συστήματος."
 ],
 "Abort installation": [
  null,
  "Ακύρωση εγκατάστασης"
 ],
 "About": [
  null,
  "Πληροφορίες"
 ],
 "Account": [
  null,
  "Λογαριασμός"
 ],
 "Actions": [
  null,
  "Ενέργειες"
 ],
 "Add another server...": [
  null,
  "Προσθήκη άλλου διακομιστή..."
 ],
 "Add mount": [
  null,
  "Προσθήκη προσάρτησης"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Πρόσθετα για το επιλεγμένο σας περιβάλλον"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Πρόσθετα που δεν αφορούν συγκεκριμένα το περιβάλλον σας"
 ],
 "Additional languages": [
  null,
  "Πρόσθετες γλώσσες"
 ],
 "Additional software for the selected environment": [
  null,
  "Πρόσθετο λογισμικό για το επιλεγμένο περιβάλλον"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Όλες οι αλλαγές, που πραγματοποιείτε στην επεξεργασία αποθηκευτικού χώρου, εφαρμόζονται αμέσως."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Θα ξεκλειδωθούν όλες οι συσκευές που χρησιμοποιούν αυτήν τη φράση πρόσβασης"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Σελίδα έργου Anacoda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Εφαρμογή εκχώρησης σημείου προσάρτησης και εγκατάσταση"
 ],
 "Applying changes...": [
  null,
  "Εφαρμογή αλλαγών..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Εκχώρηση διαμερισμάτων σε σημεία προσάρτησης. Χρήσιμο για προρυθμισμένες προσαρμοσμένες διατάξεις."
 ],
 "Automatic log file upload": [
  null,
  "Αυτόματη μεταφόρτωση αρχείου καταγραφής"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Αυτόματη ρύθμιση ημερομηνίας και ώρας, χρησιμοποιώντας διακομιστές ώρας"
 ],
 "Automatically set timezone": [
  null,
  "Αυτόματη ρύθμιση ζώνης ώρας"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Διαθέσιμος ελεύθερος χώρος: $0. Η εγκατάσταση απαιτεί: $1."
 ],
 "Back": [
  null,
  "Επιστροφή"
 ],
 "Base environment": [
  null,
  "Βασικό περιβάλλον"
 ],
 "Brief description of the issue": [
  null,
  "Σύντομη περιγραφή του προβλήματος"
 ],
 "Bug report details": [
  null,
  "Λεπτομέρειες αναφοράς σφάλματος"
 ],
 "Bugzilla API key": [
  null,
  "Κλειδί Bugzilla API"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Συνεχίζοντας με τη χρήση αυτού του λογισμικού, κατανοείτε και αποδέχεστε τους κινδύνους που σχετίζονται με το πρώιμο λογισμικό, ότι σκοπεύετε να το χρησιμοποιήσετε μόνο για σκοπούς δοκιμών και προγραμματισμού και ότι είστε πρόθυμοι να αναφέρετε τυχόν σφάλματα ή προβλήματα για τη βελτίωση αυτού του έργου."
 ],
 "Cancel": [
  null,
  "Ακύρωση"
 ],
 "Change": [
  null,
  "Αλλαγή"
 ],
 "Change destination": [
  null,
  "Αλλαγή προορισμού"
 ],
 "Change hostname": [
  null,
  "Αλλαγή ονόματος υπολογιστή"
 ],
 "Change partition layout": [
  null,
  "Αλλαγή διάταξης διαμερισμάτων"
 ],
 "Change system keyboard layout": [
  null,
  "Αλλαγή διάταξης πληκτρολογίου συστήματος"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Οι αλλαγές που πραγματοποιείτε εδώ θα επηρεάσουν άμεσα το σύστημα. Δεν θα είναι δυνατή η αναίρεσή τους."
 ],
 "Checking installation configuration...": [
  null,
  "Έλεγχος διαμόρφωσης εγκατάστασης..."
 ],
 "Checking storage configuration": [
  null,
  "Έλεγχος ρυθμίσεων αποθηκευτικού χώρου"
 ],
 "Clear search": [
  null,
  "Απαλοιφή αναζήτησης"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Κάντε ξανά κλικ στο «Επόμενο» για να συνεχίσετε παρά τις προειδοποιήσεις αυτές."
 ],
 "Close": [
  null,
  "Κλείσιμο"
 ],
 "Close storage editor": [
  null,
  "Κλείσιμο επεξεργασίας αποθηκευτικού χώρου"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Ο αποθηκευτικός χώρος Cockpit δεν παρείχε τη φράση πρόσβασης για το ξεκλείδωμα της κρυπτογραφημένης συσκευής."
 ],
 "Completed": [
  null,
  "Ολοκληρώθηκε"
 ],
 "Configuration is incomplete": [
  null,
  "Η διαμόρφωση δεν είναι ολοκληρωμένη"
 ],
 "Configure NTP servers": [
  null,
  "Ρύθμιση διακομιστών NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Ρύθμιση προσαρμοσμένων διακομιστών NTP"
 ],
 "Configure network": [
  null,
  "Ρύθμιση δικτύου"
 ],
 "Configure storage": [
  null,
  "Ρύθμιση αποθηκευτικού χώρου"
 ],
 "Configure storage again": [
  null,
  "Ρύθμιση αποθηκευτικού χώρου ξανά"
 ],
 "Confirm passphrase": [
  null,
  "Επιβεβαίωση φράσης πρόσβασης"
 ],
 "Continue": [
  null,
  "Συνέχεια"
 ],
 "Continue installation": [
  null,
  "Συνέχεια εγκατάστασης"
 ],
 "Continue installation?": [
  null,
  "Συνέχεια εγκατάστασης;"
 ],
 "Continue with installation": [
  null,
  "Συνέχεια με εγκατάσταση"
 ],
 "Correct these issues before continuing.": [
  null,
  "Διορθώστε αυτά τα ζητήματα πριν συνεχίσετε."
 ],
 "Create Account": [
  null,
  "Δημιουργία λογαριασμού"
 ],
 "Create account": [
  null,
  "Δημιουργία λογαριασμού"
 ],
 "Currently installed: $0": [
  null,
  "Τρέχουσα εγκατάσταση: $0"
 ],
 "Custom": [
  null,
  "Προσαρμοσμένο"
 ],
 "Date": [
  null,
  "Ημερομηνία"
 ],
 "Date and time": [
  null,
  "Ημερομηνία και ώρα"
 ],
 "Delete partition": [
  null,
  "Διαγραφή διαμερίσματος"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Η διαγραφή ορισμένων διαμερισμάτων ενδέχεται να εμποδίσει την εκκίνηση του «$0»: $1"
 ],
 "Description": [
  null,
  "Περιγραφή"
 ],
 "Destination": [
  null,
  "Προορισμός"
 ],
 "Destination is encrypted": [
  null,
  "Ο προορισμός είναι κρυπτογραφημένος"
 ],
 "Detailed description of the issue": [
  null,
  "Λεπτομερής περιγραφή του προβλήματος"
 ],
 "Detected valid storage layout:": [
  null,
  "Εντοπίστηκε έγκυρη διάταξη αποθηκευτικού χώρου:"
 ],
 "Device": [
  null,
  "Συσκευή"
 ],
 "Duplicate device.": [
  null,
  "Διπλότυπη συσκευή."
 ],
 "Duplicate mount point.": [
  null,
  "Διπλότυπο σημείο πρόσαρτησης."
 ],
 "Enable root account": [
  null,
  "Ενεργοποίηση λογαριασμού root"
 ],
 "Encrypt my data": [
  null,
  "Κρυπτογράφηση δεδομένων"
 ],
 "Encrypted": [
  null,
  "Κρυπτογραφημένο"
 ],
 "Encryption": [
  null,
  "Κρυπτογράφηση"
 ],
 "Enter PIN": [
  null,
  "Εισαγωγή PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Εισαγάγετε το PIN για να αποκτήσετε πρόσβαση στο πρόγραμμα εγκατάστασης"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Εισαγάγετε το κλειδί API σας για το Bugzilla ώστε να δημιουργήσετε μια αναφορά σφάλματος. Θα μπορέσετε να ελέγξετε και να επεξεργαστείτε τις λεπτομέρειες του σφάλματος στο επόμενο βήμα."
 ],
 "Environment": [
  null,
  "Περιβάλλον"
 ],
 "Erase data and install": [
  null,
  "Διαγραφή δεδομένων και εγκατάσταση"
 ],
 "Error details": [
  null,
  "Λεπτομέρειες σφάλματος"
 ],
 "Exit to live desktop": [
  null,
  "Έξοδος στην επιφάνεια εργασίας"
 ],
 "Extended partition": [
  null,
  "Εκτεταμένο διαμέρισμα"
 ],
 "Failed to report issue": [
  null,
  "Αποτυχία αναφοράς του προβλήματος"
 ],
 "Failed to save layouts": [
  null,
  "Αποτυχία αποθήκευσης διατάξεων"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Το Fedora Linux απαιτεί τουλάχιστον $0 χώρου στον δίσκο."
 ],
 "Finalization": [
  null,
  "Οριστικοποίηση"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Οριστικοποίηση: Η διαμόρφωση του συστήματος έχει ολοκληρωθεί. Η οριστικοποίηση της εγκατάστασης ενδέχεται να χρειαστεί λίγη ώρα."
 ],
 "Find layout": [
  null,
  "Εύρεση διάταξης"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Για περισσότερη ασφάλεια, αποφύγετε την απευθείας χρήση του λογαριασμού root. Αντ' αυτού, χρησιμοποιήστε τον παραπάνω τοπικό λογαριασμό για να διαχειριστείτε το σύστημα."
 ],
 "Full name": [
  null,
  "Ονοματεπώνυμο"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Το ονοματεπώνυμο δεν μπορεί να περιέχει χαρακτήρες άνω και κάτω τελείας"
 ],
 "Helper text": [
  null,
  "Κείμενο βοηθού"
 ],
 "Hide API key": [
  null,
  "Απόκρυψη κλειδιού API"
 ],
 "Hide PIN": [
  null,
  "Απόκρυψη PIN"
 ],
 "Hide confirmed password": [
  null,
  "Απόκρυψη επιβεβαιωμένου κωδικού πρόσβασης"
 ],
 "Hide passphrase": [
  null,
  "Απόκρυψη φράσης πρόσβασης"
 ],
 "Hide password": [
  null,
  "Απόκρυψη κωδικού πρόσβασης"
 ],
 "Hostname": [
  null,
  "Όνομα υπολογιστή"
 ],
 "How would you like to install?": [
  null,
  "Με ποιον τρόπο θέλετε να κάνετε την εγκατάσταση;"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Κατανοώ ότι όλα τα υπάρχοντα δεδομένα θα διαγραφούν",
  "Κατανοώ ότι όλα τα υπάρχοντα δεδομένα θα διαγραφούν από τους επιλεγμένους δίσκους"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Κατανοώ ότι ορισμένα από τα υπάρχοντα δεδομένα θα διαγραφούν"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Κατανοώ ότι ορισμένα από τα υπάρχοντα διαμέρισματα θα τροποποιηθούν"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Εάν το αφήσετε κενό, το όνομα υπολογιστή θα είναι προσωρινό και θα οριστεί με βάση τις πληροφορίες δικτύου."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Εάν δεν ισχύει καμία από τις παραπάνω επιλογές, χρησιμοποιήστε το εργαλείο επεξεργασίας αποθηκευτικού χώρου για να δημιουργήσετε μια προσαρμοσμένη διαμέριση πριν συνεχίσετε."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Εάν κάνετε ρύθμιση διαμερισμάτων, απαιτούνται τα εξής:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Εάν δεν συναινείτε με την αυτόματη μεταφόρτωση αρχείων καταγραφής, μπορείτε να $0. Η χειροκίνητη αναφορά σάς επιτρέπει να ελέγξετε και να επισυνάψετε επιλεκτικά τα αρχεία καταγραφής."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Εάν δεν κατανοείτε ή αποδέχεστε τους κινδύνους, τότε κλείστε αυτό το πρόγραμμα."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Εάν το πρόβλημά σας αντιστοιχεί σε κάποιο από τα παραπάνω σφάλματα, μπορείτε να το ανοίξετε και να προσθέσετε τις πληροφορίες σας αντί να δημιουργήσετε μια διπλότυπη αναφορά."
 ],
 "In progress": [
  null,
  "Σε εξέλιξη"
 ],
 "Initializing...": [
  null,
  "Αρχικοποίηση..."
 ],
 "Install": [
  null,
  "Εγκατάσταση"
 ],
 "Installation completed": [
  null,
  "Η εγκατάσταση ολοκληρώθηκε"
 ],
 "Installation failed": [
  null,
  "Αποτυχία εγκατάστασης"
 ],
 "Installation method": [
  null,
  "Μέθοδος εγκατάστασης"
 ],
 "Installation of the system failed": [
  null,
  "Η εγκατάσταση του συστήματος απέτυχε"
 ],
 "Installation of the system failed: $0": [
  null,
  "Αποτυχία εγκατάστασης συστήματος: $0"
 ],
 "Installation type": [
  null,
  "Τύπος εγκατάστασης"
 ],
 "Installing": [
  null,
  "Γίνεται εγκατάσταση"
 ],
 "Insufficient disk space": [
  null,
  "Ανεπαρκής χώρος στον δίσκο"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Μη έγκυρο PIN. Δοκιμάστε ξανά."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Εντοπίστηκε μη έγκυρη διαμόρφωση RAID. Εάν η συστοιχία RAID σας έχει δημιουργηθεί απευθείας πάνω σε δίσκους, θα πρέπει να δημιουργηθεί ένας πίνακας διαμερισμάτων στη συστοιχία. Εάν η συστοιχία RAID σας έχει δημιουργηθεί πάνω σε διαμερίσματα, θα πρέπει να περιέχει ένα ενιαίο σύστημα αρχείων ή μορφή (π.χ. LVM PV). Τυχόν υπάρχοντα διαμερίσματα σε αυτήν τη συστοιχία θα αγνοηθούν."
 ],
 "Invalid hostname": [
  null,
  "Μη έγκυρο όνομα υπολογιστή"
 ],
 "Jump to first incomplete step": [
  null,
  "Μετάβαση στο πρώτο μη ολοκληρωμένο βήμα"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Διατήρηση της τρέχουσας διάταξης δίσκου και χρήση του διαθέσιμου χώρου, για την παράλληλη εγκατάσταση με κάποιο άλλο λειτουργικό σύστημα."
 ],
 "Keyboard": [
  null,
  "Πληκτρολόγιο"
 ],
 "Keyboard layout during boot": [
  null,
  "Διάταξη πληκτρολογίου κατά την εκκίνηση"
 ],
 "Language": [
  null,
  "Γλώσσα"
 ],
 "Launch storage editor": [
  null,
  "Άνοιγμα επεξεργασίας χώρων αποθήκευσης"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Μάθετε περισσότερα για την περιορισμένη πρόσβαση στη διαμόρφωση"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Αφήστε κενά και τα δύο πεδία φράσης πρόσβασης για να χρησιμοποιήσετε έναν κενό κωδικό πρόσβασης."
 ],
 "Location": [
  null,
  "Τοποθεσία"
 ],
 "Locked devices": [
  null,
  "Κλειδωμένες συσκευές"
 ],
 "Log in": [
  null,
  "Σύνδεση"
 ],
 "Make current": [
  null,
  "Ορισμός ως τρέχον"
 ],
 "Manual disk configuration": [
  null,
  "Χειροκίνητη διαμόρφωση δίσκου"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Χειροκίνητη διαμόρφωση δίσκου: αντιστοίχιση σημείου προσάρτησης"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Μπορεί να περιέχει γράμματα, αριθμούς και παύλες."
 ],
 "May need more free space": [
  null,
  "Ενδέχεται να απαιτείται περισσότερος ελεύθερος χώρος"
 ],
 "Medium": [
  null,
  "Μέτριος"
 ],
 "Minimum of $0 required": [
  null,
  "Απαιτούνται τουλάχιστον $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Αναντιστοιχία επιλογής επαναδιαμόρφωσης μεταξύ της γονικής και της θυγατρικής συσκευής."
 ],
 "Mount point": [
  null,
  "Σημείο προσάρτησης"
 ],
 "Mount point assignment": [
  null,
  "Εκχώρηση σημείου προσάρτησης"
 ],
 "Move down": [
  null,
  "Μετακίνηση κάτω"
 ],
 "Move up": [
  null,
  "Μετακίνηση πάνω"
 ],
 "Must be at least $0 characters": [
  null,
  "Πρέπει να αποτελείται από τουλάχιστον $0 χαρακτήρες"
 ],
 "My issue is different, continue": [
  null,
  "Το πρόβλημά μου είναι διαφορετικό, συνέχεια"
 ],
 "NTP Servers": [
  null,
  "Διακομιστές NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Όνομα"
 ],
 "Needs at least $0": [
  null,
  "Απαιτεί τουλάχιστον $0"
 ],
 "Network": [
  null,
  "Δίκτυο"
 ],
 "Network Configuration": [
  null,
  "Διαμόρφωση δικτύου"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Κανένα διαθέσιμο δίκτυο. Ρυθμίστε το δίκτυο στο μενού της γραμμής στο επάνω μέρος για να αναφέρετε το πρόβλημα."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Κανένα διαθέσιμο δίκτυο. Ρυθμίστε το δίκτυο για να αναφέρετε το πρόβλημα."
 ],
 "Network plugin failed": [
  null,
  "Αποτυχία αρθρώματος δικτύου"
 ],
 "Next": [
  null,
  "Επόμενο"
 ],
 "No devices": [
  null,
  "Δεν υπάρχει καμία συσκευή"
 ],
 "No disks available": [
  null,
  "Δεν διατίθεται κανένας δίσκος"
 ],
 "No disks selected": [
  null,
  "Δεν έχει επιλεχθεί κανένας δίσκος"
 ],
 "No keyboard layouts selected": [
  null,
  "Δεν έχουν επιλεγεί διατάξεις πληκτρολογίου"
 ],
 "No layouts selected yet": [
  null,
  "Δεν έχουν επιλεγεί διατάξεις ακόμα"
 ],
 "No results found": [
  null,
  "Δεν βρέθηκαν αποτελέσματα"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Δεν είναι δυνατή η απόκτηση ενός έγκυρου σχήματος αντιστοίχισης πλήκτρων VConsole για τις επιλεγμένες διατάξεις πληκτρολογίου. Επιλέξτε άλλες διατάξεις πληκτρολογίου."
 ],
 "Not enough available free space": [
  null,
  "Μη επαρκής διαθέσιμος χώρος"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Δεν υπάρχει επαρκής ελεύθερος χώρος στους επιλεγμένους δίσκους."
 ],
 "Not enough space on selected disks.": [
  null,
  "Δεν υπάρχει επαρκής χώρος στους επιλεγμένους δίσκους."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Σημείωση: Αυτή η πρώιμη έκδοση του λογισμικού προορίζεται αποκλειστικά για σκοπούς δοκιμών και προγραμματισμού. ΜΗΝ χρησιμοποιήσετε αυτό το λογισμικό για σημαντικές εργασίες σε περιβάλλοντα παραγωγής."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Άνοιγμα φόρμας καταχώρησης σφαλμάτων Bugzilla"
 ],
 "Operating system": [
  null,
  "Λειτουργικό σύστημα"
 ],
 "Options": [
  null,
  "Επιλογές"
 ],
 "Other keyboards": [
  null,
  "Άλλα πληκτρολόγια"
 ],
 "Partitions (advanced)": [
  null,
  "Διαμερίσματα (σύνθετες επιλογές)"
 ],
 "Passphrase": [
  null,
  "Φράση πρόσβασης"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Η φράση πρόσβασης δεν ταίριαξε με καμία κλειδωμένη συσκευή"
 ],
 "Passphrases must match": [
  null,
  "Οι φράσεις πρόσβασης πρέπει να ταιριάζουν"
 ],
 "Pending": [
  null,
  "Σε εκκρεμότητα"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Επισυνάψτε το αρχείο καταγραφής $0 στο πρόβλημα."
 ],
 "Please enter a PIN": [
  null,
  "Εισαγάγετε ένα PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Επιλέξτε τουλάχιστον έναν δίσκο για να συνεχίσετε"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Βρέθηκαν πιθανώς διπλότυπα σφάλματα"
 ],
 "Powered by Anaconda": [
  null,
  "Με την υποστήριξη του Anaconda"
 ],
 "Pre-release": [
  null,
  "Πρώιμη έκδοση"
 ],
 "Prefer to report manually? $0": [
  null,
  "Προτιμάτε να κάνετε χειροκίνητα αναφορά; $0"
 ],
 "Proceed with installation": [
  null,
  "Συνέχεια με την εγκατάσταση"
 ],
 "Quit": [
  null,
  "Έξοδος"
 ],
 "Quit installer?": [
  null,
  "Έξοδος από τον βοηθό εγκατάστασης;"
 ],
 "Reading information about the OS failed.": [
  null,
  "Η ανάγνωση πληροφοριών σχετικά με το λειτουργικό σύστημα απέτυχε."
 ],
 "Reading information about the computer failed.": [
  null,
  "Η ανάγνωση πληροφοριών σχετικά με τον υπολογιστή απέτυχε."
 ],
 "Reading installer configuration failed.": [
  null,
  "Η ανάγνωση διαμόρφωσης του βοηθού εγκατάστασης απέτυχε."
 ],
 "Reading installer version information failed.": [
  null,
  "Η ανάγνωση πληροφοριών έκδοσης του βοηθού εγκατάστασης απέτυχε."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Το πραγματικό όνομα υπολογιστή μπορεί να περιέχει μόνο χαρακτήρες, ψηφία, παύλες (όχι στην αρχή ή στο τέλος) και τελείες"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Το πραγματικό όνομα υπολογιστή πρέπει να αποτελείται από 64 χαρακτήρες ή λιγότερους"
 ],
 "Reboot": [
  null,
  "Επανεκκίνηση"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Κάντε επανεκκίνηση στα Windows για να αλλάξετε το μέγεθος των διαμερισμάτων με κρυπτογράφηση BitLocker. Απελευθερώστε τουλάχιστον $0 χώρου για την εγκατάσταση."
 ],
 "Reboot system?": [
  null,
  "Επανεκκίνηση συστήματος;"
 ],
 "Reclaim additional space": [
  null,
  "Ανάκτηση πρόσθετου χώρου"
 ],
 "Reclaim space": [
  null,
  "Ανάκτηση χώρου"
 ],
 "Reclaim space (required)": [
  null,
  "Ανάκτηση χώρου (απαιτείται)"
 ],
 "Recommended": [
  null,
  "Προτείνεται"
 ],
 "Recommended partitions:": [
  null,
  "Προτεινόμενα διαμερίσματα:"
 ],
 "Reformat": [
  null,
  "Επαναδιαμόρφωση"
 ],
 "Reinstall Fedora": [
  null,
  "Επανεγκατάσταση του Fedora"
 ],
 "Remove": [
  null,
  "Αφαίρεση"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Κατάργηση όλων των διαμερισμάτων στις επιλεγμένες συσκευές, συμπεριλαμβανομένων των υπαρχόντων λειτουργικών συστημάτων."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Καταργήστε ή αλλάξτε το μέγεθος των υπαρχόντων συστήματων αρχείων για να απελευθερώσετε χώρο για την εγκατάσταση."
 ],
 "Remove server": [
  null,
  "Αφαίρεση διακομιστή"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Η κατάργηση ενός συστήματος αρχείων θα διαγράψει οριστικά όλα τα δεδομένα που περιέχονται σε αυτό. Η αλλαγή μεγέθους ενός διαμερίσματος μπορεί να απελευθερώσει μη χρησιμοποιούμενο χώρο, αλλά δεν είναι ακίνδυνη. Φροντίστε να δημιουργήσετε αντίγραφα ασφαλείας όλων των σημαντικών δεδομένων σας πριν από την ανάκτηση χώρου."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Αντικατάσταση της τρέχουσας εγκατάστασης, αλλά διατήρηση των αρχείων του προσωπικού φακέλου (/home)."
 ],
 "Report Issue": [
  null,
  "Αναφορά προβλήματος"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Αναφέρετε ένα ζήτημα ή στείλτε σχόλια ανοίγοντας τη φόρμα καταχώρησης σφαλμάτων του Bugzilla, $0."
 ],
 "Report issue": [
  null,
  "Αναφορά προβλήματος"
 ],
 "Reporting issue...": [
  null,
  "Αναφορά προβλήματος..."
 ],
 "Required": [
  null,
  "Απαιτείται"
 ],
 "Requirements": [
  null,
  "Απαιτήσεις"
 ],
 "Rescan devices": [
  null,
  "Νέα σάρωση συσκευών"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Η επανασάρωση των δίσκων απέτυχε."
 ],
 "Resize": [
  null,
  "Αλλαγή μεγέθους"
 ],
 "Resize partition": [
  null,
  "Αλλαγή μεγέθους διαμερίσματος"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Αλλαγή μεγέθους των εξής διαμερισμάτων από το $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Περιορισμός πρόσβασης στην αναφορά"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Περιορίζει την αναφορά στην ομάδα «$0». $1"
 ],
 "Return to installation": [
  null,
  "Επιστροφή στην εγκατάσταση"
 ],
 "Return to storage editor": [
  null,
  "Επιστροφή στην επεξεργασία χώρων αποθήκευσης"
 ],
 "Review and install": [
  null,
  "Έλεγχος και εγκατάσταση"
 ],
 "Root account has been configured": [
  null,
  "Έχει ρυθμιστεί λογαριασμός root"
 ],
 "Root account is enabled": [
  null,
  "Ο λογαριασμός root έχει ενεργοποιηθεί"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Ο λογαριασμός root έχει ενεργοποιηθεί, αλλά δεν έχει ρυθμιστεί κανένας λογαριασμός χρήστη"
 ],
 "Root password has been set.": [
  null,
  "Ο κωδικός πρόσβασης root έχει οριστεί."
 ],
 "Save": [
  null,
  "Αποθήκευση"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Σαρώστε τον κωδικό QR με το τηλέφωνό σας ή επισκεφθείτε το:"
 ],
 "Search for a language": [
  null,
  "Αναζήτηση γλώσσας"
 ],
 "Search for additional software": [
  null,
  "Αναζήτηση για πρόσθετο λογισμικό"
 ],
 "Search for an environment": [
  null,
  "Αναζήτηση για περιβάλλον"
 ],
 "Search keyboard layout": [
  null,
  "Αναζήτηση διάταξης πληκτρολογίου"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Ασφαλίστε τα δεδομένα σας με κρυπτογράφηση σε επίπεδο δίσκου. Ισχύει μόνο για νέα διαμερίσματα"
 ],
 "Select": [
  null,
  "Επιλογή"
 ],
 "Select a device": [
  null,
  "Επιλέξτε μια συσκευή"
 ],
 "Select city": [
  null,
  "Επιλογή πόλης"
 ],
 "Select destination": [
  null,
  "Επιλέξτε προορισμό"
 ],
 "Select region": [
  null,
  "Επιλογή περιοχής"
 ],
 "Selected (top = current)": [
  null,
  "Επιλεγμένο (κορυφαίο = τρέχον)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Δεν είναι δυνατή η επαναδιαμόρφωση της μορφής «$0» της επιλεγμένης συσκευής."
 ],
 "Send us feedback on your installation": [
  null,
  "Στείλτε μας σχόλια για την εγκατάστασή σας"
 ],
 "Server": [
  null,
  "Διακομιστής"
 ],
 "Server is not reachable": [
  null,
  "Δεν είναι δυνατή η επικοινωνία με τον διακομιστή"
 ],
 "Set custom hostname": [
  null,
  "Ορισμός προσαρμοσμένου ονόματος υπολογιστή"
 ],
 "Share disk with other operating systems": [
  null,
  "Κοινή χρήση του δίσκου με άλλα λειτουργικά συστήματα"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Κοινή χρήση του δίσκου με άλλα λειτουργικά συστήματα: $0"
 ],
 "Show AM/PM": [
  null,
  "Εμφάνιση ΠΜ/ΜΜ"
 ],
 "Show API key": [
  null,
  "Εμφάνιση κλειδιού API"
 ],
 "Show PIN": [
  null,
  "Εμφάνιση PIN"
 ],
 "Show confirmed password": [
  null,
  "Εμφάνιση επιβεβαιωμένου κωδικού πρόσβασης"
 ],
 "Show passphrase": [
  null,
  "Εμφάνιση φράσης πρόσβασης"
 ],
 "Show password": [
  null,
  "Εμφάνιση κωδικού πρόσβασης"
 ],
 "Size": [
  null,
  "Μέγεθος"
 ],
 "Software installation": [
  null,
  "Εγκατάσταση λογισμικού"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Εγκατάσταση λογισμικού: η διαμόρφωση του αποθηκευτικού χώρου έχει ολοκληρωθεί. Γίνεται τώρα εγκατάσταση του λογισμικού στη συσκευή σας."
 ],
 "Software selection": [
  null,
  "Επιλογή λογισμικού"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Πρέπει να ολοκληρώσετε ορισμένα βήματα της εγκατάστασης πριν μπορέσετε να συνεχίσετε."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Απουσιάζουν ορισμένα απαραίτητα διαμερίσματα: $0"
 ],
 "Space": [
  null,
  "Χώρος"
 ],
 "Stacktrace": [
  null,
  "Ιχνηλάτηση στοίβας"
 ],
 "Storage": [
  null,
  "Αποθηκευτικός χώρος"
 ],
 "Storage configuration": [
  null,
  "Διαμόρφωση χώρου"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Διαμόρφωση χώρου: αυτήν τη στιγμή γίνεται διαμόρφωση του αποθηκευτικού χώρου."
 ],
 "Storage editor": [
  null,
  "Επεξεργασία αποθηκευτικού χώρου"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Ο αποθηκευτικός χώρος βασίζεται στη διαμόρφωση από το μενού «Τροποποίηση χώρου»."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Η διάταξη του αποθηκευτικού χώρου καθορίζεται από το αρχείο kickstart. Μπορείτε να ελέγξετε την προγραμματισμένη διάταξη διαμέρισης στο βήμα της σύνοψης."
 ],
 "Storage plugin failed": [
  null,
  "Αποτυχία αρθρώματος αποθηκευτικού χώρου"
 ],
 "Storage requirements not met": [
  null,
  "Δεν πληρούνται οι απαιτήσεις αποθηκευτικού χώρου"
 ],
 "Strong": [
  null,
  "Ισχυρός"
 ],
 "Successfully installed": [
  null,
  "Επιτυχής εγκατάσταση"
 ],
 "Successfully unlocked $0.": [
  null,
  "Το $0 ξεκλειδώθηκε επιτυχώς."
 ],
 "Suggested keyboards": [
  null,
  "Προτεινόμενα πληκτρολόγια"
 ],
 "Suggested languages": [
  null,
  "Προτεινόμενες γλώσσες"
 ],
 "System": [
  null,
  "Σύστημα"
 ],
 "System configuration": [
  null,
  "Διαμόρφωση συστήματος"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Διαμόρφωση συστήματος: η εγκατάσταση του λογισμικού έχει ολοκληρωθεί. Γίνεται τώρα διαμόρφωση του συστήματος."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Η εγκατάσταση Anaconda διακόπηκε απροσδόκητα."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Τα παρακάτω ανοικτά σφάλματα ενδέχεται να σχετίζονται με το πρόβλημά σας. Ελέγξτε τα πριν δημιουργήσετε μια νέα αναφορά."
 ],
 "The following user will be created:": [
  null,
  "Θα δημιουργηθεί ο παρακάτω χρήστης:",
  "Θα δημιουργηθούν οι παρακάτω χρήστες:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Η εγκατάσταση απαιτεί $0 χώρου στον δίσκο, αλλά η χωρητικότητα των επιλεγμένων δίσκων είναι μόνο $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Ο βοηθός εγκατάστασης δεν μπορεί να συνεχίσει λόγω ενός κρίσιμου σφάλματος."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Ο βοηθός εγκατάστασης δεν μπορεί να συνεχίσει λόγω ενός κρίσιμου σφάλματος: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Η διάταξη πληκτρολογίου άλλαξε αφού ορίστηκε φράση πρόσβασης για την κρυπτογράφηση του δίσκου. Εισαγάγετε ξανά τη φράση πρόσβασης."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Η φράση πρόσβασης που πληκτρολογήσατε περιέχει χαρακτήρες που δεν είναι ASCII. Ενδέχεται να μην μπορείτε να κάνετε εναλλαγή μεταξύ διατάξεων πληκτρολογίου κατά την πληκτρολόγησή της."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Η τρέχουσα επιλογή προεπιλεγμένης διάταξης πληκτρολογίου δεν υποστηρίζει χαρακτήρες ASCII. Επιλέξτε μια διάταξη με υποστήριξη ASCII ως την προεπιλεγμένη."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Το εργαλείο επεξεργασίας αποθηκευτικού χώρου σάς επιτρέπει να αλλάξετε το μέγεθος, να διαγράψετε και να δημιουργήσετε διαμερίσματα. Μπορεί να χρησιμοποιηθεί για τη ρύθμιση του LVM και πολλά άλλα. Πρόκειται για ένα βοηθητικό εργαλείο με σύνθετες λειτουργίες και δεν προορίζεται για τυπικές εγκαταστάσεις."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Αυτά τα αρχεία καταγραφής ενδέχεται να περιέχουν ευαίσθητες πληροφορίες, όπως διευθύνσεις IP, ονόματα χρηστών ή άλλες λεπτομέρειες συστήματος."
 ],
 "This hostname can't be submitted": [
  null,
  "Δεν είναι δυνατή η υποβολή αυτού του ονόματος υπολογιστή"
 ],
 "This is unstable, pre-release software": [
  null,
  "Αυτό το λογισμικό πρώιμης έκδοσης είναι ασταθές"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Αυτή η διάταξη θα χρησιμοποιείται για το ξεκλείδωμα του συστήματός σας κατά την εκκίνηση"
 ],
 "This may take a moment": [
  null,
  "Αυτό μπορεί να διαρκέσει λίγη ώρα"
 ],
 "This will take a few moments": [
  null,
  "Αυτό θα διαρκέσει λίγα λεπτά"
 ],
 "Time": [
  null,
  "Ώρα"
 ],
 "Timezone": [
  null,
  "Ζώνη ώρας"
 ],
 "Title": [
  null,
  "Τίτλος"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Για να ξεκινήσετε τη χρήση του $0, επανεκκινήστε το σύστημά σας."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Για να συνεχίσετε, επιλέξτε τις συσκευές όπου θα γίνει η εγκατάσταση."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Για να χρησιμοποιήσετε αυτήν την επιλογή, αλλάξτε το μέγεθος ή καταργήστε υπάρχοντα διαμερίσματα για να ελευθερώσετε τουλάχιστον $0."
 ],
 "Type": [
  null,
  "Τύπος"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Δεν είναι δυνατός ο προγραμματισμός της διαγραφής του $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Δεν είναι δυνατός ο προγραμματισμός της αλλαγής μεγέθους του $0"
 ],
 "Undo last action": [
  null,
  "Αναίρεση τελευταίας ενέργειας"
 ],
 "Unlock": [
  null,
  "Ξεκλείδωμα"
 ],
 "Unlock encrypted devices": [
  null,
  "Ξεκλείδωμα κρυπτογραφημένων συσκευών"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Ξεκλειδώστε τα κρυπτογραφημένα διαμερίσματα για να διατηρήσετε τα υπάρχοντα δεδομένα και να δείτε περισσότερες μεθόδους εγκατάστασης."
 ],
 "Use configured storage": [
  null,
  "Χρήση του διαμορφωμένου αποθηκευτικού χώρου"
 ],
 "Use entire disk": [
  null,
  "Χρήση ολόκληρου του δίσκου"
 ],
 "Use free space": [
  null,
  "Χρήση του ελεύθερου χώρου"
 ],
 "Use local account": [
  null,
  "Χρήση τοπικού λογαριασμού"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Χρήση της συσκευής RAID για αυτόματη κατάτμηση"
 ],
 "User creation": [
  null,
  "Δημιουργία χρήστη"
 ],
 "User name": [
  null,
  "Όνομα χρήστη"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Το όνομα χρήστη μπορεί να περιέχει μόνο: γράμματα από a έως z, ψηφία 0-9, παύλες «$0», τελείες «$1», κάτω παύλες «$2»"
 ],
 "User name must not be a reserved word": [
  null,
  "Το όνομα χρήστη δεν πρέπει να είναι δεσμευμένη λέξη"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Τα ονόματα χρηστών πρέπει να περιέχουν λιγότερους από 33 χαρακτήρες"
 ],
 "Validating...": [
  null,
  "Επικύρωση..."
 ],
 "Weak": [
  null,
  "Αδύναμος"
 ],
 "Welcome": [
  null,
  "Καλώς ορίσατε"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Καλώς ήρθατε στο Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Καλώς ορίσατε. Ας εγκαταστήσουμε το $0 τώρα."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Όταν υποβάλετε αυτήν την αναφορά σφάλματος, θα μεταφορτωθούν αυτόματα τα εξής αρχεία καταγραφής: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Δεν είναι δυνατή η αλλαγή μεγέθους για διαμερίσματα των Windows με κρυπτογράφηση BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  "Μπορείτε τώρα να κλείσετε αυτό το παράθυρο προγράμματος περιήγησης."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Μπορείτε είτε να ελευθερώσετε επαρκή χώρο εδώ και να αφήσετε τον βοηθό εγκατάστασης να αναλάβει τα υπόλοιπα, είτε να ορίσετε τα διαμερίσματα χειροκίνητα."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Μπορείτε να δημιουργήσετε το κλειδί API για τον λογαριασμό Bugzilla σας $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Πρέπει να ενεργοποιήσετε τον λογαριασμό root ή να δημιουργήσετε έναν τοπικό λογαριασμό για να συνεχίσετε."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Πρέπει να διαθέτετε σύνδεση σε ένα δίκτυο για να ενεργοποιήσετε την αυτόματη ημερομηνία και ώρα."
 ],
 "Your progress will not be saved.": [
  null,
  "Η πρόοδός σας δεν θα αποθηκευτεί."
 ],
 "completed step": [
  null,
  "ολοκληρωμένο βήμα"
 ],
 "current step": [
  null,
  "τρέχον βήμα"
 ],
 "delete": [
  null,
  "διαγραφή"
 ],
 "edit": [
  null,
  "επεξεργασία"
 ],
 "encrypt": [
  null,
  "κρυπτογράφηση"
 ],
 "encrypted": [
  null,
  "κρυπτογραφημένο"
 ],
 "extended partition": [
  null,
  "εκτεταμένο διαμέρισμα"
 ],
 "format as $0": [
  null,
  "διαμόρφωση ως $0"
 ],
 "here": [
  null,
  "εδώ"
 ],
 "incomplete": [
  null,
  "μη ολοκληρωμένο"
 ],
 "mount": [
  null,
  "προσάρτηση"
 ],
 "pending step": [
  null,
  "εκκρεμές βήμα"
 ],
 "report the issue manually": [
  null,
  "αναφέρετε χειροκίνητα το πρόβλημα"
 ],
 "resized from $0": [
  null,
  "αλλαγή μεγέθους από $0"
 ],
 "shrink": [
  null,
  "συρρίκνωση"
 ],
 "shrink to $0": [
  null,
  "συρρίκνωση σε $0"
 ],
 "transient, will use DHCP": [
  null,
  "μεταβατικό, θα χρησιμοποιεί DHCP"
 ],
 "undo": [
  null,
  "αναίρεση"
 ]
});
