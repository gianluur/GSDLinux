cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "User name": [
  null,
  "Nome do usuário"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Comment": [
  null,
  "Comentário"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Fingerprint": [
  null,
  "Digital"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Change password": [
  null,
  "Alterar Senha"
 ],
 "Password changed successfully": [
  null,
  "Senha alterada com êxito"
 ],
 "New password": [
  null,
  "Nova Senha"
 ],
 "Confirm password": [
  null,
  "Confirme a senha"
 ],
 "Password tip": [
  null,
  "Dica da senha"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Dica: faça a sua senha de chave corresponder à sua senha de login para autenticar automaticamente contra outros sistemas."
 ],
 "Unlock key $0": [
  null,
  "Desbloquear chave $0"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Add private SSH key": [
  null,
  "Adicionar chave privada SSH"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "SSH keys": [
  null,
  "Chave SSH"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Usar as seguintes chaves para se autenticar em outros sistemas"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Toggle": [
  null,
  "Alternar"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Public key": [
  null,
  "Chave Pública"
 ],
 "Use key": [
  null,
  "Usar chave"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "Connection error": [
  null,
  "Erro de Conexão"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Add new host": [
  null,
  "Adicionar novo host"
 ],
 "Host": [
  null,
  "Máquina"
 ],
 "Stop editing hosts": [
  null,
  "Parar edição de hosts"
 ],
 "Edit hosts": [
  null,
  "Editar hosts"
 ],
 "active": [
  null,
  "ativo"
 ],
 "Active pages": [
  null,
  "Páginas ativas"
 ],
 "Page name": [
  null,
  "Nome da página"
 ],
 "There are currently no active pages": [
  null,
  "Atualmente não há páginas ativas"
 ],
 "Close selected pages": [
  null,
  "Fechar Páginas Selecionadas"
 ],
 "$0 documentation": [
  null,
  "Documentação de $0"
 ],
 "About Web Console": [
  null,
  "Sobre o console web"
 ],
 "Style": [
  null,
  "Estilo"
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Display language": [
  null,
  "Idioma de exibição"
 ],
 "Log out": [
  null,
  "Log out"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Session": [
  null,
  "Sessão"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licenciada sob GNU LGPL versão 2.1"
 ],
 "Web Console": [
  null,
  "Console web"
 ],
 "Web console logo": [
  null,
  "Logo do console web"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit é uma interface interativa de administração de servidor Linux."
 ],
 "Project website": [
  null,
  "Site do projeto"
 ],
 "Loading packages...": [
  null,
  "Carregando pacotes..."
 ],
 "Choose the language to be used in the application": [
  null,
  "Escolha o idioma a ser usado no aplicativo"
 ],
 "Filter menu items": [
  null,
  "Filtrar itens de menu"
 ],
 "No languages match": [
  null,
  "Nenhuma correspondência de idioma"
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "Unexpected error": [
  null,
  "Erro inesperado"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit teve um erro interno inesperado."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "na maioria dos browsers"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "Clear search": [
  null,
  "Limpar pesquisa"
 ],
 "Contains:": [
  null,
  "Contém:"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Tools": [
  null,
  "Ferramentas"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Não foi possível entrar em contato com o host $0. Certifique-se de que o ssh esteja rodando na porta $1 ou especifique outra porta no endereço."
 ],
 "Connect to $0?": [
  null,
  "Conectar à $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Os hosts conectados podem controlar totalmente uns aos outros. Isso inclui a execução de programas que podem danificar seu sistema ou roubar dados. Conecte-se apenas a computadores confiáveis."
 ],
 "Read more": [
  null,
  "Leia mais"
 ],
 "You will be reminded once per session.": [
  null,
  "Você receberá um lembrete uma vez por sessão."
 ],
 "Connect": [
  null,
  "Conectar"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "O endereço IP ou nome do host não podem conter espaços."
 ],
 "This machine has already been added.": [
  null,
  "Esta máquina já foi adicionada."
 ],
 "Failed to add machine: $0": [
  null,
  "Falha ao adicionar a máquina: $0"
 ],
 "Edit host": [
  null,
  "Editar host"
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Pode ser um nome de host, endereço IP, nome de alias ou URI ssh://"
 ],
 "When empty, connect with the current user": [
  null,
  "Quando vazio, conecta com o usuário atual"
 ],
 "Color": [
  null,
  "Cor"
 ],
 "Failed to edit machine: $0": [
  null,
  "Falha ao editar a máquina: $0"
 ],
 "Could not contact $0": [
  null,
  "Não foi possível contatar $0"
 ],
 "Update": [
  null,
  "Atualizar"
 ],
 "Unable to contact $0.": [
  null,
  "Incapaz de contatar $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "O sshd está sendo executado em uma porta diferente?"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "New host: $0": [
  null,
  "Novo host: $0"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Você está se conectando com $0 pela primeira vez."
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Execute este comando por meio de uma rede confiável ou fisicamente na máquina remota:"
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Páginas maliciosas em uma máquina remota podem afetar outros hosts conectados"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The new key password can not be empty": [
  null,
  "A nova senha da chave não pode estar vazia"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Não foi possível efetuar login em $0. O host não aceita login por senha nem por nenhuma de suas chaves SSH."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Não foi possível efetuar login em $0 usando autenticação por chave SSH. Forneça a senha. Você pode configurar suas chaves SSH para login automático."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida por senha, e o host não permite login com senha. Por favor, forneça a senha da chave no endereço $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Você pode querer alterar a senha da chave para fazer login automático."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida. Você pode acessar usando sua senha de login ou fornecendo a senha da chave no endereço $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "Key password": [
  null,
  "Senha da chave"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Para permitir o login em $0 como $1 sem senha no futuro, use a senha de login de $2 em $3 como a senha principal ou deixe a senha principal em branco."
 ],
 "Change the password of $0": [
  null,
  "Altere a senha de $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Ao alterar a senha da chave SSH $0 para a senha de login de $1 em $2, a chave será automaticamente disponibilizada e você poderá fazer login em $3 sem senha no futuro."
 ],
 "New key password": [
  null,
  "Nova senha de senha"
 ],
 "Confirm new key password": [
  null,
  "Confirme a nova senha da chave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "A chave SSH $0 de $1 em $2 serão adicionadas ao arquivo $3 de $4 em $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Isso permitirá que você faça login sem senha no futuro."
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "A chave SSH $0 ficará disponível durante o restante da sessão e também poderá ser usada para fazer login em outros hosts."
 ],
 "Automatic login": [
  null,
  "Login automático"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "A sessão foi encerrada devido a inatividade."
 ],
 "Connection failed": [
  null,
  "Conexão falhou"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Ocorreu um erro inesperado enquanto conectava-se à máquina."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Mensagens relacionadas à falha podem ser encontradas no diário:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Os usuários do Safari precisam importar e confiar no certificado da Autoridade Certificadora (CA) autoassinada:"
 ],
 "Reconnect": [
  null,
  "Reconectar"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "The machine is rebooting": [
  null,
  "A máquina esta reiniciando"
 ],
 "Connecting to the machine": [
  null,
  "Conectando a máquina"
 ],
 "Not connected to host": [
  null,
  "Não conectado ao host"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Não é possível conectar a um host desconhecido"
 ],
 "Session is about to expire": [
  null,
  "A sessão está prestes a expirar"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "A sessão será encerrada em $0 segundos."
 ],
 "Continue session": [
  null,
  "Continuar sessão"
 ],
 "Skip to content": [
  null,
  "Pular para conteúdo"
 ],
 "Skip main navigation": [
  null,
  "Pular navegação principal"
 ],
 "Permission denied": [
  null,
  "Permissão negada"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Pick date": [
  null,
  "Selecionar data"
 ],
 "Toggle date picker": [
  null,
  "Alternar o seletor de data"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "You now have administrative access.": [
  null,
  "Agora você tem acesso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Não existem métodos disponíveis para obter acesso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentique-se para obter acesso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Trocar para acesso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema ao se tornar administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Switch to limited access": [
  null,
  "Trocar para acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "O modo de acesso limitado restringe os privilégios administrativos. Algumas partes do console web terão funcionalidade reduzida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Seu navegador irá memorizar seu nível de acesso entre as sessões."
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar acesso administrativo"
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitar firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Strong password": [
  null,
  "Senha forte"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Weak password": [
  null,
  "Senha fraca"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "Show confirmation password": [
  null,
  "Mostrar a senha de confirmação"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando a conclusão de outras operações de gerenciamento de software"
 ],
 "Checking installed software": [
  null,
  "Verificando software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Não foi possível efetuar login em $0 usando autenticação por chave SSH. Por favor, forneça a senha."
 ],
 "SSH key login": [
  null,
  "Login com chave SSH"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportou código de erro $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "Row expansion": [
  null,
  "Expansão de linha"
 ],
 "Row select": [
  null,
  "Seleção de linha"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Erro de colagem"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Seu navegador não permite colar texto pelo menu de contexto. Você pode usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Erro durante inicialização"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Home": [
  null,
  "Pasta pessoal"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Não é um diretório"
 ],
 "All files": [
  null,
  "Todos os arquivos"
 ],
 "Recent": [
  null,
  "Recentes"
 ],
 "No recent directories": [
  null,
  "Nenhum diretório recente"
 ],
 "No recent files": [
  null,
  "Nenhum arquivo recente"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "File chooser actions": [
  null,
  "Ações do seletor de arquivos"
 ],
 "Open in file browser": [
  null,
  "Abrir no navegador de arquivos"
 ],
 "Hide hidden files": [
  null,
  "Ocultar arquivos ocultos"
 ],
 "Show hidden files": [
  null,
  "Mostrar arquivos ocultos"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Clear filters": [
  null,
  "Limpar filtros"
 ],
 "Directory is empty": [
  null,
  "O diretório está vazio"
 ],
 "Directory has no sub-directories": [
  null,
  "O diretório não tem subdiretórios"
 ],
 "This directory contains only hidden files": [
  null,
  "Este diretório contém apenas arquivos ocultos"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "Folder": [
  null,
  "Pasta"
 ],
 "File": [
  null,
  "Arquivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "O usuário conectado não tem permissão para visualizar as modificações do sistema"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "View automation script": [
  null,
  "Ver script de automação"
 ],
 "Occurrences": [
  null,
  "Ocorrências"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Select an option": [
  null,
  "Selecione uma opção"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Not permitted to perform this action.": [
  null,
  "Não autorizado a executar esta ação."
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Host key is incorrect": [
  null,
  "Chave de host incorreta"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuração e resolução de problemas do Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ]
});
