cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 instalação"
 ],
 "$0 installer": [
  null,
  "$0 instalador"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 é uma partição estendida MBR que contém partições lógicas. Ao remover todas as partições lógicas, a partição estendida será também removida automaticamente."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "São necessários $0, mas apenas $1 estão disponíveis."
 ],
 "$0 warning": [
  null,
  "$0 aviso",
  "$0 avisos"
 ],
 "$0 will be deleted": [
  null,
  "$0 será apagado"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "O sistema de ficheiros '$0' não pode estar num dispositivo de bloco encriptado"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' tem de estar num dispositivo formatado para $1"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Partição '$0' no dispositivo MDRAID '$1' encontrada. Partições do carregador de arranque em dispositivos MDRAID não são suportadas."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Uma conta de utilizador padrão com acesso de administrador para efetuar alterações a nível do sistema."
 ],
 "About": [
  null,
  "Acerca"
 ],
 "Account": [
  null,
  "Conta"
 ],
 "Actions": [
  null,
  "Ação"
 ],
 "Add another server...": [
  null,
  "Adicionar outro servidor..."
 ],
 "Add mount": [
  null,
  "Adicionar ponto de montagem"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Complementos para o ambiente selecionado"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Complementos não específicos para o seu ambiente"
 ],
 "Additional languages": [
  null,
  "Idiomas adicionais"
 ],
 "Additional software for the selected environment": [
  null,
  "Software adicional para o ambiente selecionado"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Todas as alterações feitas no editor de armazenamento entram em vigor imediatamente."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Todos os dispositivos que usam esta frase-passe serão desbloqueados"
 ],
 "Anaconda Web UI": [
  null,
  "Interface web do Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Página do projeto Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aplicar a atribuição do ponto de montagem e instalar"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Atribuir partições a pontos de montagem. Útil para esquemas personalizados pré-configurados."
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Definir automaticamente a data e a hora, utilizando servidores de tempo"
 ],
 "Automatically set timezone": [
  null,
  "Definir automaticamente o fuso horário"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Espaço livre disponível: $0. A instalação requer: $1."
 ],
 "Back": [
  null,
  "Voltar"
 ],
 "Base environment": [
  null,
  "Ambiente base"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Ao continuar a utilizar este software, compreende e aceita os riscos associados a software de pré-lançamento, que o utilizará apenas para fins de teste e desenvolvimento e que está disposto a relatar quaisquer erros ou problemas para melhorar este trabalho."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change": [
  null,
  "Alteração"
 ],
 "Change destination": [
  null,
  "Mudar destino"
 ],
 "Change hostname": [
  null,
  "Alterar o nome de anfitrião"
 ],
 "Change partition layout": [
  null,
  "Alterar o esquema de partições"
 ],
 "Change system keyboard layout": [
  null,
  "Alterar o esquema de teclado do sistema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "As alterações feitas aqui afetarão imediatamente o sistema. Não é possivel anular a operacão."
 ],
 "Checking storage configuration": [
  null,
  "A verificar a configuração do armazenamento"
 ],
 "Clear search": [
  null,
  "Limpar pesquisa"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Clique em \"Seguinte\" novamente para continuar, apesar destes avisos."
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Close storage editor": [
  null,
  "Fechar o editor de armazenamento"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "O armazenamento do Cockpit não forneceu a frase-passe para desbloquear o dispositivo cifrado."
 ],
 "Completed": [
  null,
  "Concluído"
 ],
 "Configure NTP servers": [
  null,
  "Configurar servidores NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurar servidores NTP personalizados"
 ],
 "Configure storage": [
  null,
  "Configurar o armazenamento"
 ],
 "Configure storage again": [
  null,
  "Configurar o armazenamento novamente"
 ],
 "Confirm passphrase": [
  null,
  "Confirmar frase-passe"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Continue installation": [
  null,
  "Continuar a instalação"
 ],
 "Continue with installation": [
  null,
  "Continuar com a instalação"
 ],
 "Create Account": [
  null,
  "Criar Conta"
 ],
 "Create account": [
  null,
  "Criar conta"
 ],
 "Currently installed: $0": [
  null,
  "Instalação atual: $0"
 ],
 "Custom": [
  null,
  "Personalizar"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data e hora"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "A eliminação de certas partições pode impedir que $0 arranque: $1"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Destination": [
  null,
  "Destino"
 ],
 "Destination is encrypted": [
  null,
  "O destino está encriptado"
 ],
 "Detected valid storage layout:": [
  null,
  "Esquema de armazenamento válido detetado:"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Duplicate device.": [
  null,
  "Dispositivo duplicado."
 ],
 "Duplicate mount point.": [
  null,
  "Ponto de montagem duplicado."
 ],
 "Enable root account": [
  null,
  "Ativar conta root"
 ],
 "Encrypt my data": [
  null,
  "Encriptar os meus dados"
 ],
 "Encrypted": [
  null,
  "Encriptado"
 ],
 "Encryption": [
  null,
  "Encriptação"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Apagar dados e instalar"
 ],
 "Error details": [
  null,
  "Detalhes do erro"
 ],
 "Exit to live desktop": [
  null,
  "Sair para a área de trabalho"
 ],
 "Extended partition": [
  null,
  "Partição estendida"
 ],
 "Failed to save layouts": [
  null,
  "Falha ao guardar disposições"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "O Fedora linux requer pelo menos $0 de espaço em disco."
 ],
 "Finalization": [
  null,
  "Finalização"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "A finalizar: A configuração do sistema está concluída. A finalização da instalação pode demorar alguns momentos."
 ],
 "Find layout": [
  null,
  "Encontrar esquema"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Para uma melhor segurança, não utilize diretamente a conta root. Use antes a conta local acima para administrar o sistema."
 ],
 "Full name": [
  null,
  "Nome completo"
 ],
 "Full name cannot contain colon characters": [
  null,
  "O nome completo não pode conter caracteres de dois pontos"
 ],
 "Helper text": [
  null,
  "Texto de ajuda"
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Ocultar a palavra-passe confirmada"
 ],
 "Hide passphrase": [
  null,
  "Ocultar frase-passe"
 ],
 "Hide password": [
  null,
  "Ocultar palavra-passe"
 ],
 "Hostname": [
  null,
  "Nome de anfitrião"
 ],
 "How would you like to install?": [
  null,
  "Como gostaria de instalar?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Eu compreendo que alguns dados existentes serão apagados"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Eu compreendo que algumas partições serão modificadas"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Se vazio, o nome de anfitrião será transitório e definido pelas informações da rede."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Se estiver a configurar as partições, o seguinte é necessário:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Se não compreende ou aceita os riscos, por favor, saia deste programa."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Em curso"
 ],
 "Initializing...": [
  null,
  "A instalar..."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Installation failed": [
  null,
  "Falha ao instalar"
 ],
 "Installation method": [
  null,
  "Método de instalação"
 ],
 "Installation of the system failed": [
  null,
  "Falha ao instalar o sistema"
 ],
 "Installation of the system failed: $0": [
  null,
  "Falha ao instalar o sistema: $0"
 ],
 "Installation type": [
  null,
  "Tipo de instalação"
 ],
 "Installing": [
  null,
  "A instalar"
 ],
 "Insufficient disk space": [
  null,
  "Não há espaço suficiente no disco"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Configuração de RAID inválida detetada. Se o array RAID for criado diretamente sobre discos, deverá ser criada uma tabela de partições no array. Se o array RAID for criado sobre partições, deve conter um único sistema de ficheiros ou formato (por exemplo, LVM PV). Quaisquer partições existentes neste array serão ignoradas."
 ],
 "Invalid hostname": [
  null,
  "Nome de anfitrião inválido"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Manter o esquema de disco atual e usar o espaço disponível para fazer dual-boot com outro sistema operativo."
 ],
 "Keyboard": [
  null,
  "Teclado"
 ],
 "Keyboard layout during boot": [
  null,
  "Esquema de teclado durante o arranque"
 ],
 "Language": [
  null,
  "Idioma"
 ],
 "Launch storage editor": [
  null,
  "Iniciar editor de armazenamento"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Localização"
 ],
 "Locked devices": [
  null,
  "Dispositivos bloqueados"
 ],
 "Make current": [
  null,
  "Tornar atual"
 ],
 "Manual disk configuration": [
  null,
  "Configuração manual do disco"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuração manual do disco: Mapeamento dos pontos de montagem"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Pode conter letras, números e traços."
 ],
 "May need more free space": [
  null,
  "Pode ser necessário mais espaço livre"
 ],
 "Medium": [
  null,
  "Média"
 ],
 "Minimum of $0 required": [
  null,
  "É necessário um mínimo de $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Incompatibilidade entre a seleção de formatação do dispositivo principal e do dispositivo secundário."
 ],
 "Mount point": [
  null,
  "Ponto de Montagem"
 ],
 "Mount point assignment": [
  null,
  "Atribuição do ponto de montagem"
 ],
 "Move down": [
  null,
  "Mover para baixo"
 ],
 "Move up": [
  null,
  "Mover para cima"
 ],
 "Must be at least $0 characters": [
  null,
  "Deve ter pelo menos $0 caracteres"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Servidores NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Needs at least $0": [
  null,
  "Requer pelo menos $0"
 ],
 "Network": [
  null,
  "Rede"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rede indisponível. Configure a rede no menu da barra superior para reportar o problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rede indisponível. Configure a rede para reportar o problema."
 ],
 "Next": [
  null,
  "Seguinte"
 ],
 "No devices": [
  null,
  "Sem dispositivos"
 ],
 "No disks available": [
  null,
  "Sem disco disponível"
 ],
 "No disks selected": [
  null,
  "Nenhum disco selecionado"
 ],
 "No layouts selected yet": [
  null,
  "Ainda não foram selecionados esquemas"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Não é possível obter um mapa de teclas VConsole válido para o(s) esquema(s) de teclado selecionado(s). Selecione um esquema de teclado diferente."
 ],
 "Not enough available free space": [
  null,
  "Espaço livre insuficiente"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Não há espaço livre suficiente nos discos selecionados."
 ],
 "Not enough space on selected disks.": [
  null,
  "Não há espaço suficiente nos discos selecionados."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Aviso: Este é um software de pré-lançamento destinado apenas para fins de desenvolvimento e teste. NÃO utilize este software para trabalhos críticos ou em ambientes de produção."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Sistema operativo"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other keyboards": [
  null,
  "Outros teclados"
 ],
 "Partitions (advanced)": [
  null,
  "Partições (avançado)"
 ],
 "Passphrase": [
  null,
  "Frase-passe"
 ],
 "Passphrase did not match any locked device": [
  null,
  "A frase-passe não correspondeu a nenhum dispositivo bloqueado"
 ],
 "Passphrases must match": [
  null,
  "As frases-passe têm de coincidir"
 ],
 "Pending": [
  null,
  "Pendente"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Por favor adicione o ficheiro de registo $0 ao problema."
 ],
 "Please select at least one disk to continue": [
  null,
  "Por favor, selecione pelo menos um disco para continuar"
 ],
 "Pool": [
  null,
  "Conjunto"
 ],
 "Powered by Anaconda": [
  null,
  "Desenvolvido por Anaconda"
 ],
 "Pre-release": [
  null,
  "Pré-lançamento"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Prosseguir com a instalação"
 ],
 "Quit": [
  null,
  "Sair"
 ],
 "Quit installer?": [
  null,
  "Sair do instalador?"
 ],
 "Reading information about the OS failed.": [
  null,
  "A leitura da informação sobre o sistema operativo falhou."
 ],
 "Reading information about the computer failed.": [
  null,
  "A leitura das informações sobre o computador falhou."
 ],
 "Reading installer configuration failed.": [
  null,
  "A leitura da configuração do instalador falhou."
 ],
 "Reading installer version information failed.": [
  null,
  "Falha ao ler as informações da versão do instalador."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "O nome de anfitrião só pode conter letras, dígitos, traços (não no início ou no fim) e pontos"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "O nome de anfitrião deve ter 64 ou menos caracteres"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reinicie no Windows para redimensionar as partições encriptadas com BitLocker. Liberte pelo menos $0 de espaço livre para a instalação."
 ],
 "Reboot system?": [
  null,
  "Reiniciar sistema?"
 ],
 "Reclaim additional space": [
  null,
  "Requerer espaço adicional"
 ],
 "Reclaim space": [
  null,
  "Requerer espaço"
 ],
 "Reclaim space (required)": [
  null,
  "Requerer espaço (obrigatório)"
 ],
 "Recommended": [
  null,
  "Recomendado"
 ],
 "Recommended partitions:": [
  null,
  "Partições recomendadas:"
 ],
 "Reformat": [
  null,
  "Reformatar"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstalar o Fedora"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Remove todas as partições no dispositivo selecionado, incluindo sistemas operativos existentes."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Remova ou redimensione os sistemas de arquivos existentes para libertar espaço para instalação."
 ],
 "Remove server": [
  null,
  "Remover servidor"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Remover um sistema de ficheiros irá apagar permanentemente todos os dados que ele contém. Redimensionar uma partição pode libertar espaço não utilizado, mas não é isento de riscos. Certifique-se de ter cópias de segurança de tudo o que for importante antes de recuperar espaço."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Substituir a instalação atual, porém manter arquivos na home."
 ],
 "Report Issue": [
  null,
  "Reportar Problema"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Reportar problema"
 ],
 "Required": [
  null,
  "Obrigatório"
 ],
 "Requirements": [
  null,
  "Requisitos"
 ],
 "Rescan devices": [
  null,
  "Atualizar a lista de dispositivos"
 ],
 "Rescanning of the disks failed.": [
  null,
  "A análise dos discos falhou."
 ],
 "Resize": [
  null,
  "Redimensionar"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Redimensionar a seguinte partição de $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Voltar para a instalação"
 ],
 "Return to storage editor": [
  null,
  "Voltar ao editor de armazenamento"
 ],
 "Review and install": [
  null,
  "Rever e instalar"
 ],
 "Root account is enabled": [
  null,
  "A conta root está ativada"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "A conta root está ativada, mas nenhuma conta de utilizador foi configurada"
 ],
 "Root password has been set.": [
  null,
  "A palavra-passe de \"root\" foi definida."
 ],
 "Save": [
  null,
  "Gravar"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Digitalize o código QR com o seu telemóvel ou visite:"
 ],
 "Search for a language": [
  null,
  "Procurar um idioma"
 ],
 "Search for additional software": [
  null,
  "Procurar software adicional"
 ],
 "Search for an environment": [
  null,
  "Procurar um ambiente"
 ],
 "Search keyboard layout": [
  null,
  "Esquema do teclado de pesquisa"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Proteja os seus dados utilizando cifra de disco. Aplica-se apenas a novas partições"
 ],
 "Select": [
  null,
  "Selecionar"
 ],
 "Select a device": [
  null,
  "Selecione um dispositivo"
 ],
 "Select city": [
  null,
  "Selecionar cidade"
 ],
 "Select destination": [
  null,
  "Selecionar destino"
 ],
 "Select region": [
  null,
  "Selecionar região"
 ],
 "Selected (top = current)": [
  null,
  "Selecionado (topo = atual)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "O formato do dispositivo selecionado '$0' não pode ser reformatado."
 ],
 "Send us feedback on your installation": [
  null,
  "Envie-nos comentários sobre a sua instalação"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server is not reachable": [
  null,
  "Não é possível aceder ao servidor"
 ],
 "Set custom hostname": [
  null,
  "Definir nome de anfitrião personalizado"
 ],
 "Share disk with other operating systems": [
  null,
  "Partilhar o disco com outros sistemas operativos"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Partilhar o disco com outros sistemas operativos: $0"
 ],
 "Show AM/PM": [
  null,
  "Mostrar AM/PM"
 ],
 "Show confirmed password": [
  null,
  "Mostrar palavra-passe confirmada"
 ],
 "Show passphrase": [
  null,
  "Mostrar frase-passe"
 ],
 "Show password": [
  null,
  "Exibir palavra-passe"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Software installation": [
  null,
  "Instalação de software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalação do software: A configuração do armazenamento está completa. O software está agora a ser instalado no seu dispositivo."
 ],
 "Software selection": [
  null,
  "Seleção de software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Algumas partições necessárias estão faltando: $0"
 ],
 "Space": [
  null,
  "Espaço"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Storage configuration": [
  null,
  "Configuração de armazenamento"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuração de armazenamento: O armazenamento está a ser configurado."
 ],
 "Storage editor": [
  null,
  "Editor de armazenamento"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "O armazenamento é baseado na configuração de 'Modificar armazenamento'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Falha no módulo de extensão de armazenamento"
 ],
 "Storage requirements not met": [
  null,
  "Requisitos de armazenamento não compatível"
 ],
 "Strong": [
  null,
  "Forte"
 ],
 "Successfully installed": [
  null,
  "Instalado com sucesso"
 ],
 "Successfully unlocked $0.": [
  null,
  "Desbloqueio bem sucedido $0."
 ],
 "Suggested keyboards": [
  null,
  "Teclados sugeridos"
 ],
 "Suggested languages": [
  null,
  "Idiomas sugeridos"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Configuração de sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuração do sistema: Instalação de aplicativo finalizada. O sistema será configurado agora."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "A instalação necessita de $0 de espaço em disco; no entanto, a capacidade dos discos selecionados é apenas de $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "A instalação não pode continuar devido a um erro crítico."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "A instalação não pode continuar devido a um erro crítico: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "A frase-passe que forneceu contém caracteres não ASCII. Pode não ser possível alternar entre os esquemas de teclado ao digitá-la."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "O esquema de teclado padrão selecionado não suporta caracteres ASCII. Escolha um esquema compatível com ASCII como padrão."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "O editor de armazenamento permite redimensionar, eliminar e criar partições. Pode configurar LVM e muito mais. Destina-se a ser utilizado como uma ferramenta avançada e não é recomendado para ser usado numa instalação típica."
 ],
 "This hostname can't be submitted": [
  null,
  "Este nome de anfitrião não pode ser submetido"
 ],
 "This is unstable, pre-release software": [
  null,
  "Este é um software instável de pré-lançamento"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Este esquema será utilizado para desbloquear o seu sistema durante o arranque"
 ],
 "This may take a moment": [
  null,
  "Pode demorar um pouco"
 ],
 "This will take a few moments": [
  null,
  "Isto vai demorar alguns momentos"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Timezone": [
  null,
  "Fuso horário"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Para começar a utilizar $0, reinicie o seu sistema."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Para continuar, selecione os dispositivos para instalar."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Para usar esta opção, libere pelo menos $0 redimensionando ou removendo partições existentes."
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Incapaz de agendar a exclusão de $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Incapaz de agendar redimensionamento de $0"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Unlock encrypted devices": [
  null,
  "Desbloquear dispositivos cifrados"
 ],
 "Use configured storage": [
  null,
  "Usar o armazenamento configurado"
 ],
 "Use entire disk": [
  null,
  "Utilizar o disco inteiro"
 ],
 "Use free space": [
  null,
  "Utilizar espaço livre"
 ],
 "Use local account": [
  null,
  "Utilizar conta local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Utilizar o dispositivo RAID para partição automática"
 ],
 "User creation": [
  null,
  "Criação de utilizador"
 ],
 "User name": [
  null,
  "Nome de usuário"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Nome de usuário poderá conter: letras de A a Z, dígitos de 0 a 9, espaço $0, ponto $1, underline $2"
 ],
 "User name must not be a reserved word": [
  null,
  "O nome de utilizador não pode ser uma palavra reservada"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "O nome dos utilizadores deve ser menor que 33 caracteres"
 ],
 "Weak": [
  null,
  "Fraco"
 ],
 "Welcome": [
  null,
  "Bem-vindo"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Bem-vindo ao Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Bem-vindo. Vamos já instalar o $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Partições Windows criptografados com BitLocker não podem ser redimensionadas"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Pode liberar espaço suficiente aqui e deixar o instalador tratar do resto ou configurar as partições manualmente."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Tem de ativar a conta de root ou criar uma conta de utilizador local para continuar."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Tem de estar ligado a uma rede para ativar a definição automática de data e hora."
 ],
 "Your progress will not be saved.": [
  null,
  "Seu progresso não vai ser salvo."
 ],
 "completed step": [
  null,
  "passo concluído"
 ],
 "current step": [
  null,
  "passo atual"
 ],
 "delete": [
  null,
  "eliminar"
 ],
 "edit": [
  null,
  "editar"
 ],
 "encrypt": [
  null,
  "cifrar"
 ],
 "encrypted": [
  null,
  "cifrado"
 ],
 "extended partition": [
  null,
  "partição estendida"
 ],
 "format as $0": [
  null,
  "formatar como $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "montar"
 ],
 "pending step": [
  null,
  "etapa pendente"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "redimensionado de $0"
 ],
 "shrink": [
  null,
  "reduzir"
 ],
 "shrink to $0": [
  null,
  "diminuir para $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "desfazer"
 ]
});
