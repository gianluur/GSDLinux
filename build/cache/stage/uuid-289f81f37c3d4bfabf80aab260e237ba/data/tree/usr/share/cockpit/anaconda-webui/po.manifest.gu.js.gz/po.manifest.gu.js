cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "gu",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
