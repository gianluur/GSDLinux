cockpit.locale({
 "": {
  "plural-forms": ((n) => (n % 10 == 1 && (n % 100 < 11 || n % 100 > 19)) ? 0 : ((n % 10 >= 2 && n % 10 <= 9 && (n % 100 < 11 || n % 100 > 19)) ? 1 : 2)),
  "language": "lt",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "„Anaconda“"
 ]
});
