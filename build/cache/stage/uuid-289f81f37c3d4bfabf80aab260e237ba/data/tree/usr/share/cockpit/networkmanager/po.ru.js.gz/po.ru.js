cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Firewall": [
  null,
  "Межсетевой экран"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Public key": [
  null,
  "Открытый ключ"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "Connect": [
  null,
  "Подключиться"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "$0 key changed": [
  null,
  "Изменён $0 ключ"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "Disconnected": [
  null,
  "Отключено"
 ],
 "Permission denied": [
  null,
  "Отказано в доступе"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Create $0": [
  null,
  "Создать $0"
 ],
 "Ok": [
  null,
  "ОК"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "You now have administrative access.": [
  null,
  "Получены права администратора."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Нет доступных методов получения административного доступа (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Пройдите проверку подлинности для получения прав администратора"
 ],
 "Switch to administrative access": [
  null,
  "Переключиться на доступ с правами администратора"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Problem becoming administrator": [
  null,
  "При получении прав администратора возникли проблемы"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Ограничить доступ"
 ],
 "Switch to limited access": [
  null,
  "Переключится на ограниченный доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "В ограниченном режиме доступа ограничиваются полномочия администратора. В некоторых разделах веб-консоли будет урезаны функциональные возможности."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Браузер запоминает уровень доступа от сеанса к сеансу."
 ],
 "Limited access": [
  null,
  "Ограниченный доступ"
 ],
 "Turn on administrative access": [
  null,
  "Включить доступ с правами администратора"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "less than a minute ago": [
  null,
  "менее минуты назад"
 ],
 "in less than a minute": [
  null,
  "менее минуты"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного ПО"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Unknown host: $0": [
  null,
  "Неизвестный хост: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль."
 ],
 "SSH key login": [
  null,
  "Вход с помощью SSH-ключа"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit передал код ошибки $0"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Ошибка при инициализации"
 ],
 "Failed": [
  null,
  "Ошибка"
 ],
 "Home": [
  null,
  "Домашний каталог"
 ],
 "Downloads": [
  null,
  "Загрузки"
 ],
 "Not a directory": [
  null,
  "Не является каталогом"
 ],
 "All files": [
  null,
  "Все файлы"
 ],
 "Recent": [
  null,
  "Недавние"
 ],
 "No recent directories": [
  null,
  "Нет недавних каталогов"
 ],
 "No recent files": [
  null,
  "Нет недавних файлов"
 ],
 "Type to filter": [
  null,
  "Введите условия фильтра"
 ],
 "File chooser actions": [
  null,
  "Действия выбора файлов"
 ],
 "Open in file browser": [
  null,
  "Открыть в файловом менеджере"
 ],
 "Hide hidden files": [
  null,
  "Скрыть скрытые файлы"
 ],
 "Show hidden files": [
  null,
  "Показывать скрытые файлы"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Clear filters": [
  null,
  "Очистить фильтры"
 ],
 "Directory is empty": [
  null,
  "Каталог пуст"
 ],
 "Directory has no sub-directories": [
  null,
  "Каталог не содержит подкаталогов"
 ],
 "This directory contains only hidden files": [
  null,
  "Этот каталог содержит только скрытые файлы"
 ],
 "No matching results": [
  null,
  "Нет подходящих результатов"
 ],
 "Folder": [
  null,
  "Папка"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Select an option": [
  null,
  "Выбор опции"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Generated": [
  null,
  "Сгенерирован"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Status": [
  null,
  "Статус"
 ],
 "Delete $0": [
  null,
  "Удалить $0"
 ],
 "Group": [
  null,
  "Группа"
 ],
 "Actions": [
  null,
  "Действия"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Not available": [
  null,
  "Недоступно"
 ],
 "Ignore": [
  null,
  "Игнорировать"
 ],
 "Permanent": [
  null,
  "Постоянный"
 ],
 "Preserve": [
  null,
  "Сохранять"
 ],
 "Random": [
  null,
  "Случайный"
 ],
 "Stable": [
  null,
  "Стабильный"
 ],
 "Use $0": [
  null,
  "Исп. $0"
 ],
 "Failed to save settings": [
  null,
  "Не удалось сохранить параметры"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Создание этой $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Create it": [
  null,
  "Создать"
 ],
 "Invalid prefix $0": [
  null,
  "Недопустимый префикс $0"
 ],
 "Invalid metric $0": [
  null,
  "Недопустимая метрика $0"
 ],
 "Invalid address $0": [
  null,
  "Недопустимый адрес $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Недопустимый префикс или сетевая маска $0"
 ],
 "Testing connection": [
  null,
  "Проверка подключения"
 ],
 "Restoring connection": [
  null,
  "Восстановление подключения"
 ],
 "Troubleshoot…": [
  null,
  "Устранить неполадки…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager не работает"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager не установлен"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Для сетевых устройств и графиков необходим NetworkManager"
 ],
 "Enable service": [
  null,
  "Включить службу"
 ],
 "Network interface '$0' not found": [
  null,
  "Сетевой интерфейс «$0» не найден"
 ],
 "Return to overview page": [
  null,
  "Вернуться на страницу обзора"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "У вас нет прав на изменение брандмауэра."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Нет прав для отключения межсетевого экрана"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Нет прав для включения межсетевого экрана"
 ],
 "Disable the firewall": [
  null,
  "Отключить межсетевой экран"
 ],
 "Enable the firewall": [
  null,
  "Включить межсетевой экран"
 ],
 "Edit service $0": [
  null,
  "Изменить службу $0"
 ],
 "Remove service $0": [
  null,
  "Удалить службу $0"
 ],
 "Included Services": [
  null,
  "Включённые службы"
 ],
 "Additional port": [
  null,
  "Дополнительный порт"
 ],
 "Remove additional port": [
  null,
  "Удалить дополнительный порт"
 ],
 "Remove zone $0": [
  null,
  "Удалить зону $0"
 ],
 "Add services to zone $0": [
  null,
  "Добавить службы в зону $0"
 ],
 "Add services": [
  null,
  "Добавить службы"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "Зона $0"
 ],
 "Interface": [
  null,
  "Интерфейс",
  "Интерфейсы",
  "Интерфейсы"
 ],
 "Allowed addresses": [
  null,
  "Разрешённые адреса"
 ],
 "Entire subnet": [
  null,
  "Адрес всей подсети"
 ],
 "There are no active services in this zone": [
  null,
  "В этой зоне нет активных служб"
 ],
 "Filter services": [
  null,
  "Фильтровать службы"
 ],
 "Failed to edit service": [
  null,
  "Не удалось изменить службу"
 ],
 "Failed to add port": [
  null,
  "Не удалось добавить порт"
 ],
 "Failed to add service": [
  null,
  "Не удалось добавить службу"
 ],
 "Unknown service name": [
  null,
  "Неизвестное название службы"
 ],
 "Invalid port number": [
  null,
  "Недопустимый номер порта"
 ],
 "Invalid range": [
  null,
  "Недопустимый диапазон"
 ],
 "Range must be strictly ordered": [
  null,
  "Диапазон должен быть строго упорядочен"
 ],
 "Edit service": [
  null,
  "Изменить службу"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Изменение пользовательской службы в зоне $0"
 ],
 "Add ports": [
  null,
  "Добавить порты"
 ],
 "Add ports to $0 zone": [
  null,
  "Добавить порты в зону $0"
 ],
 "Add services to $0 zone": [
  null,
  "Добавить сервисы в зону $0"
 ],
 "Custom ports": [
  null,
  "Настраиваемые порты"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Пример: 22, ssh, 8080, 5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Допустимы порты, диапазоны и службы с запятыми в качестве разделителей"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Пример: 88, 2019, nfs, rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Если оставить поле пустым, ИД будет сгенерирован на основе связанных служб и номеров порта"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Добавление пользовательских портов приведёт к перезагрузке firewalld. При этом будет утеряна любая конфигурация среды выполнения!"
 ],
 "Failed to add zone": [
  null,
  "Не удалось добавить зону"
 ],
 "Add zone": [
  null,
  "Добавить зону"
 ],
 "Trust level": [
  null,
  "Уровень доверия"
 ],
 "Sorted from least to most trusted": [
  null,
  "Отсортировано от наименее доверенных к наиболее доверенным"
 ],
 "Custom zones": [
  null,
  "Настраиваемые зоны"
 ],
 "No description available": [
  null,
  "Описание отсутствует"
 ],
 "Included services": [
  null,
  "Включённые службы"
 ],
 "The cockpit service is automatically included": [
  null,
  "Служба cockpit автоматически входит в состав"
 ],
 "Interfaces": [
  null,
  "Интерфейсы"
 ],
 "Range": [
  null,
  "Диапазон"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-адрес с префиксом маршрутизации. Несколько значений нужно разделять запятой. Например: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Эта зона содержит службу cockpit. Убедитесь, что эта зона не относится к текущему соединению веб-консоли."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Удаление зоны приведет к удалению всех служб в ней."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Удаление службы cockpit может привести к недоступности веб-консоли. Убедитесь, что эта зона не относится к вашему текущему подключению к веб-консоли."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Удалить службу $0 из зоны $1"
 ],
 "Firewall is not available": [
  null,
  "Межсетевой экран недоступен"
 ],
 "Please install the $0 package": [
  null,
  "Установите пакет $0"
 ],
 "Add a new zone": [
  null,
  "Добавить новую зону"
 ],
 "Add new zone": [
  null,
  "Добавить новую зону"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Входящие запросы заблокированы по умолчанию. Исходящие запросы не заблокированы."
 ],
 "Connected": [
  null,
  "Подключено"
 ],
 "Wireless": [
  null,
  "Беспроводное"
 ],
 "Wired": [
  null,
  "Проводное"
 ],
 "No networks found": [
  null,
  "Сети не найдены"
 ],
 "No interface selected": [
  null,
  "Интерфейс не выбран"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "Выберите сетевой интерфейс для настройки подключения."
 ],
 "SSID can not be empty": [
  null,
  "SSID не может быть пустым"
 ],
 "Password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "Failed to connect": [
  null,
  "Не удалось подключиться"
 ],
 "Check your password.": [
  null,
  "Проверьте ваш пароль."
 ],
 "Connect to hidden network": [
  null,
  "Подключиться к скрытой сети"
 ],
 "Connect to $0": [
  null,
  "Подключиться к $0"
 ],
 "Network name": [
  null,
  "Имя сети"
 ],
 "Security": [
  null,
  "Безопасность"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 (личный)"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Удаление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Включение $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Switch on $0": [
  null,
  "Включить $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Отключение $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Switch off $0": [
  null,
  "Отключить $0"
 ],
 "Bond": [
  null,
  "Объединение"
 ],
 "Team": [
  null,
  "Сопряжение"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Мост"
 ],
 "Unknown \"$0\"": [
  null,
  "Неизвестно «$0»"
 ],
 "Carrier": [
  null,
  "Несущая частота"
 ],
 "Yes": [
  null,
  "Да"
 ],
 "No": [
  null,
  "Нет"
 ],
 "Inactive": [
  null,
  "Неактивно"
 ],
 "Unknown configuration": [
  null,
  "Неизвестная конфигурация"
 ],
 "Additional address $val": [
  null,
  "Дополнительный адрес $val"
 ],
 "Address $val": [
  null,
  "Адрес $val"
 ],
 "Gateway $gateway": [
  null,
  "Шлюз $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Дополнительный DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Дополнительные домены поиска DNS $val"
 ],
 "DNS search domains $val": [
  null,
  "Домены поиска DNS $val"
 ],
 "General": [
  null,
  "Общее"
 ],
 "Connect automatically": [
  null,
  "Подключаться автоматически"
 ],
 "Automatic": [
  null,
  "Автоматически"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Мониторинг ARP"
 ],
 "Broken configuration": [
  null,
  "Неверная конфигурация"
 ],
 "Team port": [
  null,
  "Порт сопряжения"
 ],
 "Spanning tree protocol": [
  null,
  "Протокол связующего дерева"
 ],
 "Priority $priority": [
  null,
  "Приоритет $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Задержка смены состояний $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Время приветствия $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Максимальное время жизни сообщения $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Стоимость пути $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Режим NAT loopback"
 ],
 "Bridge port": [
  null,
  "Порт моста"
 ],
 "Parent $parent": [
  null,
  "Родительский элемент $parent"
 ],
 "ID $id": [
  null,
  "ИД $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Пароль сети не сохранён. Забудьте сеть и подключитесь заново."
 ],
 "Failed to connect to $0": [
  null,
  "Не удалось подключиться к $0"
 ],
 "secured": [
  null,
  "защищённая"
 ],
 "open": [
  null,
  "открытая"
 ],
 "Last connected: $0": [
  null,
  "Последнее подключение: $0"
 ],
 "Signal strength": [
  null,
  "Уровень сигнала"
 ],
 "Not permitted to disconnect network": [
  null,
  "Не разрешено отключать сеть"
 ],
 "Disconnect": [
  null,
  "Отключиться"
 ],
 "Not permitted to connect to network": [
  null,
  "Не разрешено подключаться к сети"
 ],
 "Forget": [
  null,
  "Забыть"
 ],
 "$0 hidden network": [
  null,
  "$0 скрытая сеть",
  "$0 скрытые сети",
  "$0 скрытых сетей"
 ],
 "Filter": [
  null,
  "Фильтр"
 ],
 "Refresh": [
  null,
  "Обновить"
 ],
 "Available networks": [
  null,
  "Доступные сети"
 ],
 "Network": [
  null,
  "Сеть"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Signal": [
  null,
  "Сигнал"
 ],
 "Rate": [
  null,
  "Скорость"
 ],
 "Primary action": [
  null,
  "Основное действие"
 ],
 "Secondary actions": [
  null,
  "Дополнительные действия"
 ],
 "Not permitted to configure network devices": [
  null,
  "Не допускается настройка сетевых устройств"
 ],
 "Enable or disable the device": [
  null,
  "Включение или отключение устройства"
 ],
 "This device cannot be managed here.": [
  null,
  "Этим устройством невозможно управлять здесь."
 ],
 "Connection will be lost": [
  null,
  "Подключение будет прервано"
 ],
 "Keep connection": [
  null,
  "Сохранить подключение"
 ],
 "Invalid IP address: $0": [
  null,
  "Недопустимый IP-адрес: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Недопустимый адрес назначения: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Недопустимый адрес шлюза: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Недопустимый адрес DNS: $0"
 ],
 "Preparing": [
  null,
  "Подготовка"
 ],
 "Configuring": [
  null,
  "Настройка"
 ],
 "Authenticating": [
  null,
  "Проверка подлинности"
 ],
 "Configuring IP": [
  null,
  "Настройка IP-адреса"
 ],
 "Checking IP": [
  null,
  "Проверка IP-адреса"
 ],
 "Waiting": [
  null,
  "Ожидание"
 ],
 "Active": [
  null,
  "Активно"
 ],
 "Deactivating": [
  null,
  "Отключение"
 ],
 "Adhoc": [
  null,
  "Прямое соединение"
 ],
 "Infra": [
  null,
  "Инфраструктура"
 ],
 "AP": [
  null,
  "ТД"
 ],
 "Mesh": [
  null,
  "Ячеистая сеть"
 ],
 "No carrier": [
  null,
  "Нет несущей частоты"
 ],
 "Part of $0": [
  null,
  "Часть $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Изменение параметров приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Change the settings": [
  null,
  "Изменить параметры"
 ],
 "Add bridge": [
  null,
  "Добавить Bridge"
 ],
 "Edit bridge settings": [
  null,
  "Изменить параметры моста"
 ],
 "Ports": [
  null,
  "Порты"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Протокол связующего дерева (STP)"
 ],
 "STP priority": [
  null,
  "Приоритет"
 ],
 "STP forward delay": [
  null,
  "Задержка смены состояний"
 ],
 "STP hello time": [
  null,
  "Время приветствия"
 ],
 "STP maximum message age": [
  null,
  "Максимальное время жизни сообщения"
 ],
 "Round robin": [
  null,
  "Циклический перебор"
 ],
 "Active backup": [
  null,
  "Активное резервирование"
 ],
 "Load balancing": [
  null,
  "Балансировка нагрузки"
 ],
 "Broadcast": [
  null,
  "Трансляция"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Пассивно"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Добавить Team"
 ],
 "Edit team settings": [
  null,
  "Изменить параметры команды"
 ],
 "Runner": [
  null,
  "Средство запуска"
 ],
 "Balancer": [
  null,
  "Подсистема балансировки"
 ],
 "Primary": [
  null,
  "Первичный интерфейс"
 ],
 "Link watch": [
  null,
  "Просмотр ссылок"
 ],
 "Link up delay": [
  null,
  "Задержка установки соединения"
 ],
 "Link down delay": [
  null,
  "Задержка разрыва соединения"
 ],
 "Ping interval": [
  null,
  "Интервал команды ping"
 ],
 "Ping target": [
  null,
  "Цель команды ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Автоматически (только DHCP)"
 ],
 "Link local": [
  null,
  "Локальный адрес канала"
 ],
 "Manual": [
  null,
  "Вручную"
 ],
 "Shared": [
  null,
  "Общий"
 ],
 "Prefix length or netmask": [
  null,
  "Длина префикса или маска сети"
 ],
 "Prefix length": [
  null,
  "Длина префикса"
 ],
 "IPv4 settings": [
  null,
  "Параметры IPv4"
 ],
 "IPv6 settings": [
  null,
  "Параметры IPv6"
 ],
 "Addresses": [
  null,
  "Адреса"
 ],
 "Select method": [
  null,
  "Выбор метода"
 ],
 "Add address": [
  null,
  "Добавить адрес"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "Remove item": [
  null,
  "Удалить элемент"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Добавить сервер DNS"
 ],
 "DNS search domains": [
  null,
  "Домены поиска DNS"
 ],
 "Add search domain": [
  null,
  "Добавить домен поиска"
 ],
 "Search domain": [
  null,
  "Домен поиска"
 ],
 "Routes": [
  null,
  "Маршруты"
 ],
 "Add route": [
  null,
  "Добавить маршрут"
 ],
 "Metric": [
  null,
  "Метрика"
 ],
 "Enter a valid MAC address": [
  null,
  "Введите допустимый MAC-адрес"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 сеть",
  "$0 сети",
  "$0 сетей"
 ],
 "Add VPN": [
  null,
  "Добавить VPN"
 ],
 "Add bond": [
  null,
  "Добавить Bond"
 ],
 "Add VLAN": [
  null,
  "Добавить VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Изменить правила и зоны"
 ],
 "$0 active zone": [
  null,
  "$0 активная зона",
  "$0 активных зоны",
  "$0 активных зон"
 ],
 "Managed interfaces": [
  null,
  "Управляемые интерфейсы"
 ],
 "IP address": [
  null,
  "IP-адрес"
 ],
 "Sending": [
  null,
  "Передача"
 ],
 "Receiving": [
  null,
  "Приём"
 ],
 "Unmanaged interfaces": [
  null,
  "Неуправляемые интерфейсы"
 ],
 "Network logs": [
  null,
  "Сетевые журналы"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Адреса имеют некорректный формат"
 ],
 "Invalid IP address '$0'": [
  null,
  "Недопустимый IP-адрес '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Пакет wireguard-tools не установлен"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "У узла #$0 некорректная конечная точка. Он должен быть указан как хост:порт, например 1.2.3.4:51820, [2001:db8::1]:51820 или example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "У узла #$0 некорректный порт конечной точки. Порт должен быть числом."
 ],
 "Listen port must be a number": [
  null,
  "Порт прослушивания должен быть числом"
 ],
 "Add WireGuard VPN": [
  null,
  "Добавить WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Изменить WireGuard VPN"
 ],
 "Private key": [
  null,
  "Закрытый ключ"
 ],
 "Paste existing key": [
  null,
  "Вставить существующий ключ"
 ],
 "Regenerate": [
  null,
  "Создать повторно"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Открытый ключ будет сгенерирован после ввода действительного закрытого ключа"
 ],
 "Listen port": [
  null,
  "Порт прослушивания"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Будет установлено значение «Автоматически»"
 ],
 "IP addresses": [
  null,
  "IP-адреса"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Можно указать несколько адресов, используя запятые или пробелы в качестве разделителей."
 ],
 "Peers": [
  null,
  "Узлы"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Узлы — это другие компьютеры, которые подключаются к этому. Открытые ключи от других компьютеров будут передаваться друг другу."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Конечная точка, выступающая в роли «сервера», должна быть указана как хост:порт, в противном случае можно оставить пустым."
 ],
 "Add peer": [
  null,
  "Добавить узел"
 ],
 "Endpoint": [
  null,
  "Конечная точка"
 ],
 "Allowed IPs": [
  null,
  "Разрешённые IP-адреса"
 ],
 "No peers added.": [
  null,
  "Нет добавленных узлов."
 ],
 "Edit VLAN settings": [
  null,
  "Изменить параметры VLAN"
 ],
 "Parent": [
  null,
  "Родительский элемент"
 ],
 "VLAN ID": [
  null,
  "Идентификатор VLAN"
 ],
 "Transmitting": [
  null,
  "Передача"
 ],
 "MTU must be a positive number": [
  null,
  "Значение MTU должно быть положительным числом"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Установлено на"
 ],
 "Team port settings": [
  null,
  "Параметры порта сопряжения"
 ],
 "Sticky": [
  null,
  "Закреплено"
 ],
 "LACP key": [
  null,
  "Ключ LACP"
 ],
 "Bridge port settings": [
  null,
  "Параметры порта моста"
 ],
 "Path cost": [
  null,
  "Стоимость пути"
 ],
 "Hair pin mode": [
  null,
  "Режим NAT loopback"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Адаптивная балансировка нагрузки передачи"
 ],
 "Adaptive load balancing": [
  null,
  "Адаптивная балансировка нагрузки"
 ],
 "MII (recommended)": [
  null,
  "MII (рекомендуется)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Изменить параметры привязки"
 ],
 "Network bond": [
  null,
  "Сетевое объединение"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Сетевое объединение сливает несколько сетевых интерфейсов в один логический интерфейс с увеличенной пропускной способностью или с избыточностью."
 ],
 "Link monitoring": [
  null,
  "Мониторинг ссылок"
 ],
 "Monitoring interval": [
  null,
  "Интервал мониторинга"
 ],
 "Monitoring targets": [
  null,
  "Цели мониторинга"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Удаление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Remove $0": [
  null,
  "Удалить $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Добавление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "No interfaces available": [
  null,
  "Нет доступных интерфейсов"
 ],
 "Add member": [
  null,
  "Добавить участника"
 ],
 "Interface members": [
  null,
  "Члены интерфейса"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск. Он поддерживает следующие цели дампа: «local» (диск), «ssh» и «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ]
});
