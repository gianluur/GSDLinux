cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "Force delete": [
  null,
  "Suppression forcée"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Must be a valid IP address": [
  null,
  "Doit être une adresse IP valide"
 ],
 "1 to 65535": [
  null,
  "1 à 65535"
 ],
 "Container port must not be empty": [
  null,
  "Le port du conteneur ne doit pas être vide"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "IP address help": [
  null,
  "Aide adresse IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Si l’IP hôte est définie sur 0.0.0.0 ou non définie, le port sera relié à toutes les IP de l’hôte."
 ],
 "Host port": [
  null,
  "Port hôte"
 ],
 "Host port help": [
  null,
  "Aide port hôte"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Si le port de l’hôte n’est pas défini, le port du conteneur sera assigné au hasard sur l’hôte."
 ],
 "Container port": [
  null,
  "Port du conteneur"
 ],
 "Protocol": [
  null,
  "Protocole"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Retirer l’élément"
 ],
 "Image name is required": [
  null,
  "Le nom de l'image est obligatoire"
 ],
 "Image name is not unique": [
  null,
  "Le nom de l'image n'est pas unique"
 ],
 "Failed to commit container $0": [
  null,
  "Échec de la validation du conteneur $0"
 ],
 "New image name": [
  null,
  "Nom de la nouvelle image"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Author": [
  null,
  "Auteur"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exemple, votre nom <yourname@example.com>"
 ],
 "Command": [
  null,
  "Commande"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Pause container when creating image": [
  null,
  "Mettre le conteneur en pause lors de la création de l’image"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Le format Docker est utile pour partager l'image avec Docker ou Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Utiliser l'ancien format Docker"
 ],
 "Commit container": [
  null,
  "Valider conteneur"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Créer une nouvelle image basée sur l'état actuel du conteneur $0."
 ],
 "Commit": [
  null,
  "Valider"
 ],
 "Force commit": [
  null,
  "Validation forcée"
 ],
 "Failed to force remove container $0": [
  null,
  "Échec de la suppression forcée du conteneur $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "La suppression d'un conteneur en cours d'exécution efface toutes les données qu'il contient."
 ],
 "Failed to stop container $0": [
  null,
  "Échec de l’arrêt du conteneur $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Échec de l’arrêt du quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Échec du démarrage du quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Échec du démarrage du conteneur $0"
 ],
 "Failed to resume container $0": [
  null,
  "Échec de la reprise conteneur $0"
 ],
 "Failed to pause container $0": [
  null,
  "Échec de la mise en pause du conteneur $0"
 ],
 "Failed to restart container $0": [
  null,
  "Échec du redémarrage du conteneur $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Échec du redémarrage du quadlet $0"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Restart": [
  null,
  "Redémarrer"
 ],
 "Force stop": [
  null,
  "Arrêt forcé"
 ],
 "Force restart": [
  null,
  "Redémarrage forcé"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Resume": [
  null,
  "Reprendre"
 ],
 "Checkpoint": [
  null,
  "Point de contrôle"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Restore": [
  null,
  "Restaurer"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Healthy": [
  null,
  "Fonctions intactes"
 ],
 "Unhealthy": [
  null,
  "Non acceptable"
 ],
 "Checking health": [
  null,
  "Contrôle de fonctionnement"
 ],
 "Prune unused containers": [
  null,
  "Supprimer les conteneurs inutilisés"
 ],
 "Terminal not available": [
  null,
  "Terminal non disponible"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Ce navigateur ne prend pas en charge WebGL2."
 ],
 "View $0 logs": [
  null,
  "Voir les journaux $0"
 ],
 "not available": [
  null,
  "non disponible"
 ],
 "n/a": [
  null,
  "n. d."
 ],
 "$0% of $1 limit": [
  null,
  "$0 % de la limite de $1"
 ],
 "service": [
  null,
  "service"
 ],
 "system": [
  null,
  "système"
 ],
 "user:": [
  null,
  "utilisateur :"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Integration": [
  null,
  "Intégration"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Health check": [
  null,
  "Bilan de fonctionnement"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "Click to see published ports": [
  null,
  "Cliquez pour voir les ports publiés"
 ],
 "ports": [
  null,
  "ports"
 ],
 "Click to see volumes": [
  null,
  "Cliquez pour voir les volumes"
 ],
 "volumes": [
  null,
  "volumes"
 ],
 "Container": [
  null,
  "Conteneur"
 ],
 "Owner": [
  null,
  "Propriétaire"
 ],
 "State": [
  null,
  "État"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "No containers": [
  null,
  "Aucun conteneur"
 ],
 "No containers in this pod": [
  null,
  "Aucun conteneur dans ce pod"
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "No containers that match the current filter": [
  null,
  "Aucun conteneur ne correspond au filtre actuel"
 ],
 "No running containers": [
  null,
  "Aucun conteneur en cours d’exécution"
 ],
 "Show": [
  null,
  "Afficher"
 ],
 "All": [
  null,
  "Tout"
 ],
 "Only running": [
  null,
  "En cours d’exécution seulement"
 ],
 "Create pod": [
  null,
  "Créer un pod"
 ],
 "Create container": [
  null,
  "Créer un conteneur"
 ],
 "Containers": [
  null,
  "Conteneurs"
 ],
 "Create container in pod": [
  null,
  "Créer un conteneur dans un pod"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Échec de la restauration du conteneur $0"
 ],
 "Restore container $0": [
  null,
  "Restaurer le conteneur $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Conserver tous les fichiers de points de contrôle temporaires"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurer avec les connexions TCP établies"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorer l'adresse IP si définie statiquement"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorer l'adresse MAC si définie statiquement"
 ],
 "Pod failed to be created": [
  null,
  "Échec de la création du pod"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caractères non valides. Le nom ne peut contenir que des lettres, des chiffres et certains signes de ponctuation (_ . -)."
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Pod name": [
  null,
  "Nom du pod"
 ],
 "System": [
  null,
  "Système"
 ],
 "User:": [
  null,
  "Utilisateur :"
 ],
 "No ports exposed": [
  null,
  "Aucuns ports exposés"
 ],
 "Port mapping": [
  null,
  "Mappage de port"
 ],
 "Add port mapping": [
  null,
  "Ajouter un mappage de port"
 ],
 "No volumes specified": [
  null,
  "Aucuns volumes spécifiés"
 ],
 "Volumes": [
  null,
  "Volumes"
 ],
 "Add volume": [
  null,
  "Ajouter volume"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Type to filter…": [
  null,
  "Entrez pour filtrer…"
 ],
 "Container path must not be empty": [
  null,
  "Le chemin d'accès au conteneur ne doit pas être vide"
 ],
 "Host path": [
  null,
  "Chemin vers l’hôte"
 ],
 "Container path": [
  null,
  "Chemin du conteneur"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Writable": [
  null,
  "Accessible en écriture"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Pas de label"
 ],
 "Shared": [
  null,
  "Partagé"
 ],
 "Private": [
  null,
  "Privé"
 ],
 "Read-write access": [
  null,
  "Accès en lecture-écriture"
 ],
 "Read-only access": [
  null,
  "Accès en lecture seule"
 ],
 "Show less": [
  null,
  "Afficher moins de détails"
 ],
 "Show more": [
  null,
  "Montrer plus"
 ],
 "Loading details...": [
  null,
  "Chargement des détails..."
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Environment variables": [
  null,
  "Variables d’environnement"
 ],
 "Failed to download image $0:$1": [
  null,
  "Échec du téléchargement de l’image $0 : $1"
 ],
 "Error message": [
  null,
  "Message d’erreur"
 ],
 "unused": [
  null,
  "non utilisé"
 ],
 "$0 container": [
  null,
  "$0 conteneur",
  "$0 conteneurs"
 ],
 "History": [
  null,
  "Historique"
 ],
 "Image": [
  null,
  "Image"
 ],
 "Created": [
  null,
  "Créé"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Espace disque"
 ],
 "Used by": [
  null,
  "Utilisé par"
 ],
 "No images": [
  null,
  "Aucune image"
 ],
 "No images that match the current filter": [
  null,
  "Aucune image ne correspond au filtre actuel"
 ],
 "Hide intermediate images": [
  null,
  "Masquer les images intermédiaires"
 ],
 "Show intermediate images": [
  null,
  "Afficher les images intermédiaires"
 ],
 "Images": [
  null,
  "Images"
 ],
 "$0 image total, $1": [
  null,
  "$0 image total, $1",
  "$0 images total, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 image non utilisée, $1",
  "$0 images non utilisées, $1"
 ],
 "Hide images": [
  null,
  "Cacher les images"
 ],
 "Show images": [
  null,
  "Afficher les images"
 ],
 "Pulling": [
  null,
  "Téléchargement"
 ],
 "Download new image": [
  null,
  "Télécharger la nouvelle image"
 ],
 "Pull all images": [
  null,
  "Télécharger toutes les images"
 ],
 "Prune unused images": [
  null,
  "Suppression d’images non utilisées"
 ],
 "Pull": [
  null,
  "Télécharger"
 ],
 "Up since:": [
  null,
  "S'exécute depuis :"
 ],
 "Exited": [
  null,
  "Quittés"
 ],
 "systemd service": [
  null,
  "service systemd"
 ],
 "View $0": [
  null,
  "Voir $0"
 ],
 "Gateway": [
  null,
  "Passerelle"
 ],
 "MAC address": [
  null,
  "Adresse MAC"
 ],
 "Latest checkpoint": [
  null,
  "Dernier point de contrôle"
 ],
 "No containers are using this image": [
  null,
  "Aucun conteneur n’utilise cette image"
 ],
 "Running": [
  null,
  "En fonctionnement"
 ],
 "Loading logs...": [
  null,
  "Chargement des logs..."
 ],
 "Delete unused system images:": [
  null,
  "Supprimer les images système non utilisées :"
 ],
 "Delete unused images of user $0:": [
  null,
  "Supprimer les images inutilisées de l'utilisateur $0 :"
 ],
 "Failed to prune unused images": [
  null,
  "Échec de la suppression des images non utilisées"
 ],
 "Pruning images": [
  null,
  "Suppression de certaines images"
 ],
 "Prune": [
  null,
  "Suppression de certaines images"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Échec de la création du point de contrôle du conteneur $0"
 ],
 "Checkpoint container $0": [
  null,
  "Point de contrôle du conteneur $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Conserver actif après la création du point de contrôle sur le disque"
 ],
 "Support preserving established TCP connections": [
  null,
  "Prendre en charge le maintien des connexions TCP établies"
 ],
 "Failed to search for new images": [
  null,
  "Échec de la recherche de nouvelles images"
 ],
 "Failed to search for images: $0": [
  null,
  "Échec de la recherche de l'image : $0"
 ],
 "Failed to search for images.": [
  null,
  "Échec de la recherche d'images."
 ],
 "Search for an image": [
  null,
  "Chercher une image"
 ],
 "Search for": [
  null,
  "Rechercher"
 ],
 "Search by name or description": [
  null,
  "Rechercher par nom ou description"
 ],
 "in": [
  null,
  "dans"
 ],
 "All registries": [
  null,
  "Tous les registres"
 ],
 "Searching...": [
  null,
  "Recherche en cours..."
 ],
 "No images found": [
  null,
  "Aucune image trouvée"
 ],
 "Start typing to look for images.": [
  null,
  "Commencez à saisir les données pour rechercher des images."
 ],
 "No results for $0": [
  null,
  "Aucun résultat pour $0"
 ],
 "Retry another term.": [
  null,
  "Nouvelle tentative sur autre term."
 ],
 "Download": [
  null,
  "Télécharger"
 ],
 "No action": [
  null,
  "Pas d'action"
 ],
 "Container failed to be started": [
  null,
  "Le conteneur n’a pas pu être démarré"
 ],
 "Failed to clean up container": [
  null,
  "Échec du nettoyage du conteneur"
 ],
 "Container failed to be created": [
  null,
  "Le conteneur n’a pas pu être créé"
 ],
 "downloading": [
  null,
  "En cours de téléchargement"
 ],
 "Failed to run container $0": [
  null,
  "Échec du démarrage du conteneur $0"
 ],
 "Failed to create container $0": [
  null,
  "Échec de la création du conteneur $0"
 ],
 "Failed to pull image $0": [
  null,
  "Échec du téléchargement de l'image $0"
 ],
 "Local images": [
  null,
  "Aucune image"
 ],
 "Name already in use": [
  null,
  "Nom déjà utilisé"
 ],
 "Search by registry": [
  null,
  "Recherche par registre"
 ],
 "Local": [
  null,
  "Local"
 ],
 "Container name": [
  null,
  "Nom du conteneur"
 ],
 "Owner help": [
  null,
  "Aide au propriétaire"
 ],
 "Ideal for running services": [
  null,
  "Idéal pour le fonctionnement des services"
 ],
 "Resource limits can be set": [
  null,
  "Des limites de ressources peuvent être fixées"
 ],
 "Checkpoint and restore support": [
  null,
  "Prise en charge des points de contrôle et des restaurations"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Les ports inférieurs à 1024 peuvent être mappés"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "Ideal for development": [
  null,
  "Idéal pour le développement"
 ],
 "Restricted by user account permissions": [
  null,
  "Limité par les autorisations du compte de l'utilisateur"
 ],
 "Image selection help": [
  null,
  "Aide à la sélection d'images"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "Example: $0": [
  null,
  "Exemple : $0"
 ],
 "Searching: $0": [
  null,
  "Recherche en cours : $0"
 ],
 "Search string or container location": [
  null,
  "Chaîne de recherche ou emplacement du conteneur"
 ],
 "Pull latest image": [
  null,
  "Télécharger la dernière image"
 ],
 "Entrypoint": [
  null,
  "Point d’entrée"
 ],
 "With terminal": [
  null,
  "Avec le terminal"
 ],
 "Memory limit": [
  null,
  "Limite mémoire"
 ],
 "Decrease memory": [
  null,
  "Diminution de la mémoire"
 ],
 "Increase memory": [
  null,
  "Augmenter la mémoire"
 ],
 "Memory unit": [
  null,
  "Unité de mémoire"
 ],
 "KB": [
  null,
  "Ko"
 ],
 "MB": [
  null,
  "Mo"
 ],
 "GB": [
  null,
  "Go"
 ],
 "CPU shares": [
  null,
  "Parts de CPU"
 ],
 "CPU Shares help": [
  null,
  "Assistance CPU Shares"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU Shares déterminent la priorité des conteneurs en cours d'exécution. La priorité par défaut est de 1024. Un nombre plus élevé donne la priorité à ce conteneur. Un nombre inférieur diminue la priorité."
 ],
 "Decrease CPU shares": [
  null,
  "Diminution des parts de CPU"
 ],
 "Increase CPU shares": [
  null,
  "Augmenter les parts de CPU"
 ],
 "Restart policy": [
  null,
  "Redémarrer la stratégie"
 ],
 "Restart policy help": [
  null,
  "Assistance pour la politique de redémarrage"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Politique de redémarrage à suivre lorsque les conteneurs se terminent. L'utilisation de linger pour le démarrage automatique des conteneurs peut ne pas fonctionner dans certaines circonstances, comme lorsque ecryptfs, systemd-homed, NFS ou 2FA sont utilisés sur un compte utilisateur."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Politique de redémarrage à suivre lors de la sortie des conteneurs."
 ],
 "No": [
  null,
  "Non"
 ],
 "On failure": [
  null,
  "En cas d’échec"
 ],
 "Always": [
  null,
  "Toujours"
 ],
 "Maximum retries": [
  null,
  "Nombre max de nouvellles tentatives"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuer le nombre maximum de tentatives"
 ],
 "Increase maximum retries": [
  null,
  "Augmenter le nombre maximum de tentatives"
 ],
 "No environment variables specified": [
  null,
  "Aucune variables d’environnement spécifiée"
 ],
 "Add variable": [
  null,
  "Ajouter une variable"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Collez une ou plusieurs lignes de paires clé=valeur dans n'importe quel champ pour une importation en masse"
 ],
 "Interval": [
  null,
  "Intervalle"
 ],
 "Health check interval help": [
  null,
  "Aide à l'intervalle entre les bilans de fonctionnement"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervalle à partir duquel le contrôle de fonctionnement est exécuté."
 ],
 "Decrease interval": [
  null,
  "Diminution de l'intervalle"
 ],
 "Increase interval": [
  null,
  "Augmenter l'intervalle"
 ],
 "seconds": [
  null,
  "secondes"
 ],
 "Timeout": [
  null,
  "Délai d'attente"
 ],
 "Health check timeout help": [
  null,
  "Aide sur le délai d'exécution du bilan de fonctionnement"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Le temps maximum autorisé pour compléter le contrôle de fonctionnement avant qu'un intervalle soit considéré comme ayant échoué."
 ],
 "Decrease timeout": [
  null,
  "Diminuer le délai d'attente"
 ],
 "Increase timeout": [
  null,
  "Augmenter le délai d'attente"
 ],
 "Start period": [
  null,
  "Période de démarrage"
 ],
 "Health check start period help": [
  null,
  "Aide pour la période de démarrage du bilan de fonctionnement"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Le temps d'initialisation nécessaire à l'amorçage d'un conteneur."
 ],
 "Decrease start period": [
  null,
  "Diminution de la période de démarrage"
 ],
 "Increase start period": [
  null,
  "Augmenter la période de démarrage"
 ],
 "Retries": [
  null,
  "Tentatives"
 ],
 "Health check retries help": [
  null,
  "Aide pour les tentatives de bilans de fonctionnement"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Le nombre de tentatives autorisées avant qu'un contrôle de fonctionnement ne soit considéré non acceptable."
 ],
 "Decrease retries": [
  null,
  "Diminuer les tentatives"
 ],
 "Increase retries": [
  null,
  "Augmenter les tentatives"
 ],
 "When unhealthy": [
  null,
  "En cas d'insalubrité"
 ],
 "Health failure check action help": [
  null,
  "Aide à l’action pour les bilans de fonctionnement"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Action à entreprendre lorsque le conteneur passe à un état insalubre."
 ],
 "Create container in $0": [
  null,
  "Créer un conteneur dans $0"
 ],
 "Create and run": [
  null,
  "Créer et démarrer"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Version": [
  null,
  "Version"
 ],
 "Links": [
  null,
  "Liens"
 ],
 "Documentation": [
  null,
  "Documentation"
 ],
 "Tags": [
  null,
  "Étiquettes"
 ],
 "Created by": [
  null,
  "Créé par"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Comments": [
  null,
  "Commentaires"
 ],
 "Unable to load image history": [
  null,
  "Impossible de charger l'historique des images"
 ],
 "Key must not be empty": [
  null,
  "La clé ne doit pas être vide"
 ],
 "Key must not begin with a digit": [
  null,
  "La clé ne doit pas commencer par un chiffre"
 ],
 "Key contains invalid characters": [
  null,
  "La clé contient des caractères invalides"
 ],
 "Key": [
  null,
  "Clé"
 ],
 "Value": [
  null,
  "Valeur"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "Podman service failed": [
  null,
  "Échec du service Podman"
 ],
 "Troubleshoot": [
  null,
  "Dépannage"
 ],
 "Failed to force remove image $0": [
  null,
  "Échec de la suppression forcée de l’image $0"
 ],
 "intermediate image": [
  null,
  "image intermédiaire"
 ],
 "Failed to remove image $0": [
  null,
  "Échec de la suppression de l’image $0"
 ],
 "intermediate": [
  null,
  "intermédiaire"
 ],
 "Delete $0 image?": [
  null,
  "Supprimer l'image $0 ?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Plusieurs tags existent pour cette image. Sélectionnez les images marquées à supprimer."
 ],
 "Delete image": [
  null,
  "Supprimer l'image"
 ],
 "Delete tagged images": [
  null,
  "Supprimer les images taguées"
 ],
 "Container is not running": [
  null,
  "Le conteneur n’est pas en cours d’exécution"
 ],
 "Error occurred while connecting console": [
  null,
  "Une erreur s’est produite lors de la connexion à la console"
 ],
 "Force delete pod $0?": [
  null,
  "Forcer la suppression du pod $0 ?"
 ],
 "Delete pod $0?": [
  null,
  "Supprimer le pod $0 ?"
 ],
 "An error occurred": [
  null,
  "Une erreur s’est produite"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Le pod vide $0 sera définitivement supprimé."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "La suppression de ce pod entraînera celle des conteneurs suivants :"
 ],
 "Failed to start pod $0": [
  null,
  "Échec du démarrage du pod $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Échec de l’arrêt du pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Échec du redémarrage du pod $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Échec de la reprise pod $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Échec de la mise en pause du pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Échec de la suppression des conteneurs inutilisés"
 ],
 "Removes selected non-running containers": [
  null,
  "Supprime les conteneurs inactifs sélectionnés"
 ],
 "Pruning containers": [
  null,
  "Suppression de conteneurs"
 ],
 "Container name is required.": [
  null,
  "Le nom du conteneur est obligatoire."
 ],
 "Failed to rename container $0": [
  null,
  "Échec du renommage du conteneur $0"
 ],
 "New container name": [
  null,
  "Nouveau nom du conteneur"
 ],
 "Rename container $0": [
  null,
  "Renommer le conteneur $0"
 ],
 "Paused": [
  null,
  "En pause"
 ],
 "Stopped": [
  null,
  "Arrêté"
 ],
 "Removing": [
  null,
  "En cours de suppression"
 ],
 "Configured": [
  null,
  "Configuré"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "$0 second": [
  null,
  "$0 seconde",
  "$0 secondes"
 ],
 "Status": [
  null,
  "Statut"
 ],
 "Failing streak": [
  null,
  "Une série d'échecs"
 ],
 "Failed to run health check on container $0": [
  null,
  "Échec de l'exécution du contrôle de fonctionnement du conteneur $0"
 ],
 "Run health check": [
  null,
  "Exécuter le bilan de fonctionnement"
 ],
 "Last 5 runs": [
  null,
  "Les 5 dernières exécutions"
 ],
 "Started at": [
  null,
  "Commencé à"
 ],
 "Passed health run": [
  null,
  "Bilan de fonctionnement réussi"
 ],
 "Failed health run": [
  null,
  "Échec de l’exécution du bilan de fonctionnement"
 ],
 "Failed to remove container $0": [
  null,
  "Échec de la suppression du conteneur $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Supprimer un conteneur va effacer toutes les données qu’il contient."
 ]
});
