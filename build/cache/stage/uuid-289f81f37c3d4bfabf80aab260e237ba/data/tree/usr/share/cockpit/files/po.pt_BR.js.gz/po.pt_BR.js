cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "Início"
 ],
 "Unable to create bookmark directory": [
  null,
  "Não é possível criar o diretório de marcadores"
 ],
 "Unable to save bookmark file": [
  null,
  "Não é possível salvar o arquivo de marcadores"
 ],
 "Remove from bookmarks": [
  null,
  "Remover dos marcadores"
 ],
 "Add to bookmarks": [
  null,
  "Adicionar aos marcadores"
 ],
 "Bookmarks": [
  null,
  "Favoritos"
 ],
 "Bookmarked": [
  null,
  "Favoritos"
 ],
 "Not bookmarked": [
  null,
  "Não salvo nos favoritos"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Edit path": [
  null,
  "Editar caminho"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Largest size": [
  null,
  "Maior tamanho"
 ],
 "Smallest size": [
  null,
  "Menor tamanho"
 ],
 "Modified": [
  null,
  "Modificado"
 ],
 "First modified": [
  null,
  "Primeira modificação"
 ],
 "Last modified": [
  null,
  "Última modificação"
 ],
 "Owner": [
  null,
  "Proprietário"
 ],
 "Owner ascending": [
  null,
  "Proprietário ascendente"
 ],
 "Owner descending": [
  null,
  "Proprietário descendente"
 ],
 "Permissions": [
  null,
  "Permissões"
 ],
 "Most permissive": [
  null,
  "Mais permissivo"
 ],
 "Least permissive": [
  null,
  "Menos permissivo"
 ],
 "Show keyboard shortcuts": [
  null,
  "Mostrar atalhos de teclado"
 ],
 "Filter directory": [
  null,
  "Filtrar diretório"
 ],
 "Display as a list": [
  null,
  "Mostrar como uma lista"
 ],
 "Display as a grid": [
  null,
  "Mostrar como uma grade"
 ],
 "Sort": [
  null,
  "Ordenar"
 ],
 "Hide hidden items": [
  null,
  "Ocultar itens ocultos"
 ],
 "Show hidden items": [
  null,
  "Mostrar itens ocultos"
 ],
 "$0 files": [
  null,
  "$0 arquivos"
 ],
 "Uploaded as $0, $1": [
  null,
  "Enviado como $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Substituir arquivo $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Um arquivo com o mesmo nome já existe em \"$0\". Substituí-lo irá sobrescrever seu conteúdo."
 ],
 "New file": [
  null,
  "Novo arquivo"
 ],
 "Original file on server": [
  null,
  "Arquivo original no servidor"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Aplicar esta ação a todos os arquivos em conflito"
 ],
 "Replace": [
  null,
  "Substituir"
 ],
 "Keep original": [
  null,
  "Manter original"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Upload error": [
  null,
  "Erro de upload"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Não é possível mover o arquivo enviado para o destino final"
 ],
 "Cancelled": [
  null,
  "Cancelado"
 ],
 "Cancelled upload of $0": [
  null,
  "Upload de $0 cancelado"
 ],
 "File uploaded": [
  null,
  "Arquivo enviado"
 ],
 "Files uploaded": [
  null,
  "Arquivos enviados"
 ],
 "Change permissions": [
  null,
  "Alterar permissões"
 ],
 "Uploads": [
  null,
  "Transferências"
 ],
 "Cancel upload of $0": [
  null,
  "Cancelar o upload de $0"
 ],
 "Upload $0% completed": [
  null,
  "Upload $0% concluído"
 ],
 "Upload": [
  null,
  "Enviar"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Execute-only": [
  null,
  "Executar somente"
 ],
 "Write-only": [
  null,
  "Somente escrever"
 ],
 "Write and execute": [
  null,
  "Escrever e executar"
 ],
 "Read-only": [
  null,
  "Somente leitura"
 ],
 "Read and execute": [
  null,
  "Ler e executar"
 ],
 "Read and write": [
  null,
  "Ler e escrever"
 ],
 "Read, write, and execute": [
  null,
  "Ler, escrever e executar"
 ],
 "Block device": [
  null,
  "dispositivo de bloco"
 ],
 "Character device": [
  null,
  "Dispositivo de caractere"
 ],
 "Directory": [
  null,
  "Diretório"
 ],
 "Named pipe": [
  null,
  "pipe nomeado"
 ],
 "Symbolic link": [
  null,
  "Link simbólico"
 ],
 "Regular file": [
  null,
  "Arquivo regular"
 ],
 "Socket": [
  null,
  "socket"
 ],
 "Name cannot be empty": [
  null,
  "O nome não pode estar vazio"
 ],
 "Name too long": [
  null,
  "Nome muito longo"
 ],
 "Name cannot include a /": [
  null,
  "O nome não pode incluir um /"
 ],
 "Filename is the same as original name": [
  null,
  "O nome do arquivo é o mesmo que o nome original"
 ],
 "Directory with the same name exists": [
  null,
  "Um diretório com o mesmo nome já existe"
 ],
 "File exists": [
  null,
  "Arquivo existe"
 ],
 "Pasting failed": [
  null,
  "Falha ao colar"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" existe, não será sobrescrito com colar."
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Create directory": [
  null,
  "Criar diretório"
 ],
 "Create file": [
  null,
  "Criar arquivo"
 ],
 "Edit permissions": [
  null,
  "Editar permissões"
 ],
 "Open in terminal": [
  null,
  "Abrir no terminal"
 ],
 "Open text file": [
  null,
  "Abrir arquivo de texto"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Download": [
  null,
  "Baixar"
 ],
 "Create link": [
  null,
  "Criar link"
 ],
 "Drop files to upload": [
  null,
  "Solte arquivos para enviar"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Não é possível soltar arquivos, outro upload já está em andamento"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Go up a directory": [
  null,
  "Subir um diretório"
 ],
 "Go back": [
  null,
  "Retornar"
 ],
 "Go forward": [
  null,
  "Avançar"
 ],
 "Activate selected item, enter directory": [
  null,
  "Ativar item selecionado, entrar no diretório"
 ],
 "Rename selected file or directory": [
  null,
  "Renomear arquivo ou diretório selecionado"
 ],
 "Create new directory": [
  null,
  "Criar novo diretório"
 ],
 "Copy selected file or directory": [
  null,
  "Copiar arquivo ou diretório selecionado"
 ],
 "Paste file or directory": [
  null,
  "Colar arquivo ou diretório"
 ],
 "Select all": [
  null,
  "Selecionar todos"
 ],
 "Save current file": [
  null,
  "Salvar arquivo atual"
 ],
 "Close editor": [
  null,
  "Fechar editor"
 ],
 "Keyboard shortcuts": [
  null,
  "Atalhos do teclado"
 ],
 "Navigation": [
  null,
  "Navegação"
 ],
 "Editing": [
  null,
  "Editando"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Forçar a exclusão de $0 itens"
 ],
 "Delete $0 items?": [
  null,
  "Excluir $0 itens?"
 ],
 "Force delete file $0?": [
  null,
  "Forçar a exclusão do arquivo $0?"
 ],
 "Delete file $0?": [
  null,
  "Excluir o arquivo $0?"
 ],
 "Force delete link $0?": [
  null,
  "Forçar a exclusão do link de $0?"
 ],
 "Delete link $0?": [
  null,
  "Excluir o link $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Forçar a exclusão do diretório $0?"
 ],
 "Delete directory $0?": [
  null,
  "Excluir o diretório $0?"
 ],
 "Force delete $0": [
  null,
  "Forçar a exclusão de $0"
 ],
 "Delete $0?": [
  null,
  "Excluir $0?"
 ],
 "No access": [
  null,
  "Sem acesso"
 ],
 "Missing type": [
  null,
  "Tipo ausente"
 ],
 "Collapse": [
  null,
  "Recolher"
 ],
 "Show all files": [
  null,
  "Mostrar todos os arquivos"
 ],
 "$0 permissions": [
  null,
  "Permissões de $0"
 ],
 "Permissions for $0 files": [
  null,
  "Permissões para $0 arquivos"
 ],
 "Ownership": [
  null,
  "Propriedade"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Access": [
  null,
  "Acesso"
 ],
 "Owner access": [
  null,
  "Acesso do proprietário"
 ],
 "Group access": [
  null,
  "Acesso do grupo"
 ],
 "Others access": [
  null,
  "Acesso de outros"
 ],
 "Security context": [
  null,
  "Contexto de segurança"
 ],
 "Set executable as program": [
  null,
  "Definir executável como programa"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change permissions for enclosed files": [
  null,
  "Alterar permissões para os arquivos incluídos"
 ],
 "(original owner)": [
  null,
  "(proprietário original)"
 ],
 "keep original owners": [
  null,
  "manter proprietários originais"
 ],
 "Paste as owner": [
  null,
  "Colar como proprietário"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Os arquivos que estão sendo colados têm um proprietário diferente. Por padrão, a propriedade será alterada para corresponder ao diretório de destino."
 ],
 "New owner": [
  null,
  "Novo proprietário"
 ],
 "Overwrite": [
  null,
  "Sobrescrever"
 ],
 "New filename": [
  null,
  "Novo nome de arquivo"
 ],
 "New name": [
  null,
  "Novo nome"
 ],
 "Rename $0?": [
  null,
  "Renomear $0?"
 ],
 "link to $0": [
  null,
  "link para $0"
 ],
 "Create link to $0": [
  null,
  "Criar link para $0"
 ],
 "Target": [
  null,
  "Destino"
 ],
 "Symlink name": [
  null,
  "Nome do link simbólico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Absolute vs. Relative": [
  null,
  "Absoluto vs. Relativo"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Link simbólicos absolutos são ideais para fazer referência a arquivos ou diretórios que não serão movidos, tal como arquivos do sistema."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Links relativos são úteis quando tanto um link simbólico quanto o destino se movem ao mesmo tempo, tal como ao renomear ou mover um diretório pai."
 ],
 "Absolute": [
  null,
  "Absoluto"
 ],
 "Relative": [
  null,
  "Relativo"
 ],
 "The file has been removed on disk": [
  null,
  "O arquivo foi removido do disco"
 ],
 "The existing file changed unexpectedly": [
  null,
  "O arquivo existente mudou inesperadamente"
 ],
 "Edit $0": [
  null,
  "Editar $0"
 ],
 "View $0": [
  null,
  "Ver $0"
 ],
 "The file has changed on disk": [
  null,
  "O arquivo foi alterado no disco"
 ],
 "Reload": [
  null,
  "Recarregar"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save changes?": [
  null,
  "Salvar alterações?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "O arquivo foi excluído após ele ser aberto. Ao salvá-lo, ele será criado."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "O arquivo foi alterado no disco entre o momento em que foi aberto e agora"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 tem alterações não salvas que serão perdidas permanentemente se descartadas."
 ],
 "Discard": [
  null,
  "Descartar"
 ],
 "File name": [
  null,
  "Nome do arquivo"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Cannot create file in current directory": [
  null,
  "Não é possível criar arquivo no diretório atual"
 ],
 "Permission denied": [
  null,
  "Permissão negada"
 ],
 "Directory name cannot be empty": [
  null,
  "O nome do diretório não pode estar vazio"
 ],
 "Directory name too long": [
  null,
  "Nome do diretório longo demais"
 ],
 "Directory name cannot include a /": [
  null,
  "O nome do diretório não pode incluir uma /"
 ],
 "Directory name": [
  null,
  "Nome do diretório"
 ],
 "Directory owner": [
  null,
  "Proprietário do diretório"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "Clear filter": [
  null,
  "Limpar filtro"
 ],
 "Directory is empty": [
  null,
  "O diretório está vazio"
 ],
 "$0 item is hidden": [
  null,
  "$0 item está oculto",
  "$0 itens estão ocultos"
 ],
 "Folder": [
  null,
  "Pasta"
 ],
 "File": [
  null,
  "Arquivo"
 ],
 "Others": [
  null,
  "Outros"
 ],
 "$0 files selected": [
  null,
  "$0 arquivos selecionados"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "O diretório contém $0 diretórios, $1 arquivos"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "O diretório contém $0 diretórios, $1 arquivos, $2 ocultos"
 ],
 "User": [
  null,
  "Usuário"
 ]
});
