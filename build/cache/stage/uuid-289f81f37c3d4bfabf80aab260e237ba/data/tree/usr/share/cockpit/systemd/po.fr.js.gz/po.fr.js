cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Journal": [
  null,
  "Journal"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Informations sur le matériel"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "active": [
  null,
  "actif"
 ],
 "Default": [
  null,
  "Par défaut"
 ],
 "Light": [
  null,
  "Clair"
 ],
 "Dark": [
  null,
  "Sombre"
 ],
 "Help": [
  null,
  "Aide"
 ],
 "Select": [
  null,
  "Sélectionner"
 ],
 "System": [
  null,
  "Système"
 ],
 "Search": [
  null,
  "Recherche"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "Permission denied": [
  null,
  "Permission refusée"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "You now have administrative access.": [
  null,
  "Vous avez l’accès administrateur."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Aucun moyen d'obtenir un accès d'administration n'est disponible (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Veuillez vous authentifier pour obtenir un accès administrateur"
 ],
 "Switch to administrative access": [
  null,
  "Passer à l’accès administrateur"
 ],
 "Authenticate": [
  null,
  "S’authentifier"
 ],
 "Administrative access": [
  null,
  "Accès administrateur"
 ],
 "Problem becoming administrator": [
  null,
  "Problème pour devenir administrateur"
 ],
 "Method": [
  null,
  "Méthode"
 ],
 "Limit access": [
  null,
  "Limiter l’accès"
 ],
 "Switch to limited access": [
  null,
  "Passer en accès limité"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Le mode accès limité restreint les privilèges d’administration. Certaines parties de la console web auront des fonctionnalités réduites."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Votre navigateur se souviendra de votre niveau d’accès d’une session à l’autre."
 ],
 "Limited access": [
  null,
  "Accès limité"
 ],
 "Turn on administrative access": [
  null,
  "Activez l’accès administrateur"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "password quality": [
  null,
  "qualité du mot de passe"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun dépôt."
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a signalé le code d’erreur $0"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Error during initialization": [
  null,
  "Erreur pendant l’initialisation"
 ],
 "Failed": [
  null,
  "Échec"
 ],
 "Home": [
  null,
  "Répertoire personnel"
 ],
 "Downloads": [
  null,
  "Téléchargements"
 ],
 "Not a directory": [
  null,
  "Pas un répertoire"
 ],
 "All files": [
  null,
  "Tous les fichiers"
 ],
 "Recent": [
  null,
  "Récent"
 ],
 "No recent directories": [
  null,
  "Aucun répertoire récent"
 ],
 "No recent files": [
  null,
  "Aucun fichier récent"
 ],
 "Type to filter": [
  null,
  "Tapez pour filtrer"
 ],
 "File chooser actions": [
  null,
  "Actions du sélecteur de fichiers"
 ],
 "Open in file browser": [
  null,
  "Ouvrir dans le navigateur de fichiers"
 ],
 "Hide hidden files": [
  null,
  "Masquer les fichiers cachés"
 ],
 "Show hidden files": [
  null,
  "Afficher les fichiers cachés"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Clear filters": [
  null,
  "Effacer les filtres"
 ],
 "Directory is empty": [
  null,
  "Le répertoire est vide"
 ],
 "Directory has no sub-directories": [
  null,
  "Le répertoire n'a aucun sous-répertoire"
 ],
 "This directory contains only hidden files": [
  null,
  "Ce répertoire contient seulement des fichiers cachés"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "Folder": [
  null,
  "Dossier"
 ],
 "File": [
  null,
  "Fichier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "$0 is not a directory": [
  null,
  "$0 n'est pas un répertoire"
 ],
 "$0 does not exist": [
  null,
  "$0 n'existe pas"
 ],
 "Font size": [
  null,
  "Taille de police"
 ],
 "Decrease by one": [
  null,
  "Diminution par un"
 ],
 "Increase by one": [
  null,
  "Augmentation d’un"
 ],
 "Appearance": [
  null,
  "Apparence"
 ],
 "Black": [
  null,
  "Noir"
 ],
 "White": [
  null,
  "Blanc"
 ],
 "Reset": [
  null,
  "Réinitialiser"
 ],
 "Unable to open directory": [
  null,
  "Impossible d'ouvrir le répertoire"
 ],
 "Running process prevents directory change": [
  null,
  "Le processus en cours d'exécution bloque le changement de répertoire"
 ],
 "Change directory": [
  null,
  "Changer de répertoire"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Un changement de répertoire forcera l'arrêt du processus actuellement en cours d'exécution. Le processus peut également être arrêté manuellement à partir du terminal avant de continuer."
 ],
 "Terminal not available": [
  null,
  "Terminal non disponible"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Ce navigateur ne prend pas en charge WebGL2."
 ],
 "unknown": [
  null,
  "inconnu"
 ],
 "Shutdown": [
  null,
  "Éteindre"
 ],
 "running $0": [
  null,
  "$0 en cours d’exécution"
 ],
 "Current boot": [
  null,
  "Démarrage actuel"
 ],
 "Previous boot": [
  null,
  "Démarrage précédent"
 ],
 "Last 24 hours": [
  null,
  "Dernières 24 heures"
 ],
 "Last 7 days": [
  null,
  "Les 7 derniers jours"
 ],
 "Only emergency": [
  null,
  "Urgences uniquement"
 ],
 "Alert and above": [
  null,
  "Alerte et au-dessus"
 ],
 "Critical and above": [
  null,
  "Critique et au-dessus"
 ],
 "Error and above": [
  null,
  "Erreur et au-dessus"
 ],
 "Warning and above": [
  null,
  "Avertissement et au-dessus"
 ],
 "Notice and above": [
  null,
  "Notification et au-dessus"
 ],
 "Info and above": [
  null,
  "Info et au-dessus"
 ],
 "Debug and above": [
  null,
  "Débogage et au-dessus"
 ],
 "Toggle filters": [
  null,
  "Basculer les filtres"
 ],
 "Time": [
  null,
  "Temps"
 ],
 "Priority": [
  null,
  "Priorité"
 ],
 "Identifier": [
  null,
  "Identifiant"
 ],
 "Filters": [
  null,
  "Filtres"
 ],
 "Pause": [
  null,
  "Suspendre"
 ],
 "Resume": [
  null,
  "Reprendre"
 ],
 "All": [
  null,
  "Tout"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Les spécifications de date doivent être au format AAAA-MM-JJ hh:mm:ss. Alternativement, les chaînes « hier », « aujourd’hui », « demain » sont bien comprises. « maintenant » fait référence à l’heure actuellement. Enfin, des temps relatifs peuvent être spécifiés, précédés de « - » ou « + »"
 ],
 "Since": [
  null,
  "Depuis"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Commencez à afficher les entrées à la date spécifiée ou plus récente que celle-ci."
 ],
 "Until": [
  null,
  "Jusqu’à"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Commencez à afficher les entrées au plus tard à la date spécifiée."
 ],
 "Boot": [
  null,
  "Démarrage"
 ],
 "Show messages from a specific boot.": [
  null,
  "Afficher les messages d’un démarrage spécifique."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Cela ajoutera une correspondance pour « _BOOT_ID= ». S’ils ne sont pas spécifiés, les journaux du démarrage en cours seront affichés. Si l’ID de démarrage est omis, un décalage positif recherchera les amorçages à partir du début du journal, et un décalage égal ou inférieur à zéro recherchera les démarrages à partir de la fin du journal. Ainsi, « 1 » indique le premier amorçage trouvé dans le journal dans l’ordre chronologique, « 2 » le second et ainsi de suite ; tandis que « -0 » est le dernier démarrage, « -1 » le démarrage l’avant-dernier, et ainsi de suite."
 ],
 "Unit": [
  null,
  "Unité"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Afficher les messages de l’unité systemd spécifiée."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Cela ajoutera une correspondance pour « _SYSTEMD_UNIT= », « COREDUMP_UNIT= » et « UNIT= » pour trouver tous les messages possibles pour l’unité donnée. Peut contenir plus d’unités séparées par une virgule."
 ],
 "Free-form search": [
  null,
  "Recherche en forme libre"
 ],
 "Show messages containing given string.": [
  null,
  "Afficher les messages contenant une chaîne donnée."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Toute chaîne de texte dans les messages des journaux peut être filtrée. La chaîne peut également être sous la forme d’une expression régulière. Supporte également le filtrage par les champs du journal des messages. Il s’agit de valeurs séparées par des espaces, sous la forme FIELD=VALUE, où valeur peut être une liste de valeurs possibles séparées par des virgules."
 ],
 "journalctl manpage": [
  null,
  "page man de journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copié avec succès dans le presse-papiers"
 ],
 "Create timer": [
  null,
  "Créer Timer"
 ],
 "Edit timer": [
  null,
  "Modifier le minuteur"
 ],
 "Timer creation failed": [
  null,
  "Échec création minuteur"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Échec de l’obtention des conditions de démarrage du minuteur"
 ],
 "Failed to get the timer command": [
  null,
  "Échec de l’obtention de la commande du minuteur"
 ],
 "This field cannot be empty": [
  null,
  "Ce champ ne peut pas être vide"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Seuls les caractères alphabétiques, les nombres,:, _,. , @ , - sont autorisés"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Shell command": [
  null,
  "Commande shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Cette commande sera exécutée par /bin/sh."
 ],
 "Trigger": [
  null,
  "Déclencheur"
 ],
 "At specific time": [
  null,
  "À un moment précis"
 ],
 "After system boot": [
  null,
  "Après le démarrage du système"
 ],
 "Seconds": [
  null,
  "Secondes"
 ],
 "Minutes": [
  null,
  "Minutes"
 ],
 "Hours": [
  null,
  "Heures"
 ],
 "Weeks": [
  null,
  "Semaines"
 ],
 "Delay must be a number": [
  null,
  "Le retard doit correspondre à un nombre"
 ],
 "Repeat": [
  null,
  "Répéter"
 ],
 "Don't repeat": [
  null,
  "Ne pas répéter"
 ],
 "Minutely": [
  null,
  "Minutieusement"
 ],
 "Hourly": [
  null,
  "Toutes les heures"
 ],
 "Daily": [
  null,
  "Tous les jours"
 ],
 "Weekly": [
  null,
  "Hebdomadaire"
 ],
 "Monthly": [
  null,
  "Mensuel"
 ],
 "Yearly": [
  null,
  "Annuel"
 ],
 "Run at": [
  null,
  "Exécuter à"
 ],
 "At second": [
  null,
  "À la seconde"
 ],
 "At minute": [
  null,
  "À la minute"
 ],
 "Run on": [
  null,
  "Exécuter sur"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minute doit correspondre à un nombre entre 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Seconde doit correspondre à un nombre entre 0-59"
 ],
 "Repeat weekly": [
  null,
  "Répéter chaque semaine"
 ],
 "Mondays": [
  null,
  "lundis"
 ],
 "Tuesdays": [
  null,
  "Mardis"
 ],
 "Wednesdays": [
  null,
  "Mercredis"
 ],
 "Thursdays": [
  null,
  "Jeudis"
 ],
 "Fridays": [
  null,
  "Vendredis"
 ],
 "Saturdays": [
  null,
  "Samedis"
 ],
 "Sundays": [
  null,
  "Dimanches"
 ],
 "Repeat monthly": [
  null,
  "Répéter chaque mois"
 ],
 "1st": [
  null,
  "1er"
 ],
 "2nd": [
  null,
  "2ème"
 ],
 "3rd": [
  null,
  "3ème"
 ],
 "4th": [
  null,
  "4ème"
 ],
 "5th": [
  null,
  "5ème"
 ],
 "6th": [
  null,
  "6ème"
 ],
 "7th": [
  null,
  "7ème"
 ],
 "8th": [
  null,
  "8ème"
 ],
 "9th": [
  null,
  "9ème"
 ],
 "10th": [
  null,
  "10ème"
 ],
 "11th": [
  null,
  "11ème"
 ],
 "12th": [
  null,
  "12ème"
 ],
 "13th": [
  null,
  "13ème"
 ],
 "14th": [
  null,
  "14ème"
 ],
 "15th": [
  null,
  "15ème"
 ],
 "16th": [
  null,
  "16ème"
 ],
 "17th": [
  null,
  "17ème"
 ],
 "18th": [
  null,
  "18ème"
 ],
 "19th": [
  null,
  "19ème"
 ],
 "20th": [
  null,
  "20ème"
 ],
 "21th": [
  null,
  "21e"
 ],
 "22th": [
  null,
  "22e"
 ],
 "23th": [
  null,
  "23e"
 ],
 "24th": [
  null,
  "24ème"
 ],
 "25th": [
  null,
  "25ème"
 ],
 "26th": [
  null,
  "26ème"
 ],
 "27th": [
  null,
  "27ème"
 ],
 "28th": [
  null,
  "28ème"
 ],
 "29th": [
  null,
  "29ème"
 ],
 "30th": [
  null,
  "30ème"
 ],
 "31st": [
  null,
  "31ème"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Unclean shutdown": [
  null,
  "Arrêt non propre"
 ],
 "View logs": [
  null,
  "Voir les journaux"
 ],
 "Dismiss": [
  null,
  "Ignorer"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Mise hors tension programmée à $0"
 ],
 "Cancel poweroff": [
  null,
  "Annuler la mise hors tension"
 ],
 "Scheduled reboot at $0": [
  null,
  "Redémarrage programmé à $0"
 ],
 "Cancel reboot": [
  null,
  "Annuler le redémarrage"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "Set hostname": [
  null,
  "Définir le nom d’hôte"
 ],
 "Configuration": [
  null,
  "Configuration"
 ],
 "Hostname": [
  null,
  "Nom d’hôte"
 ],
 "System time": [
  null,
  "Heure système"
 ],
 "Domain": [
  null,
  "Domaine"
 ],
 "Performance profile": [
  null,
  "Profil de performance"
 ],
 "Secure shell keys": [
  null,
  "Clés Secure Shell"
 ],
 "Show fingerprints": [
  null,
  "Afficher les empreintes"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "échec de listage des clés de l’hôte SSH : $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Le chargement des clés SSH a échoué"
 ],
 "Error message": [
  null,
  "Message d’erreur"
 ],
 "Loading keys...": [
  null,
  "Chargement des clés..."
 ],
 "No host keys found.": [
  null,
  "Aucune clé d’hôte trouvée."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Empreintes des clés SSH de la machine"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Le nom d’hôte réel doit comporter 64 caractères ou moins"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Le nom d’hôte réel ne peut contenir que des caractères minuscules, des chiffres, des tirets et des points (avec des sous-domaines remplis)"
 ],
 "Change host name": [
  null,
  "Modifier le nom d’hôte"
 ],
 "Pretty host name": [
  null,
  "Nom d’hôte convivial"
 ],
 "Real host name": [
  null,
  "Nom d’hôte réel"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "L’utilisateur $0 n’est pas autorisé à modifier les stratégies de chiffrement"
 ],
 "Cryptographic policy": [
  null,
  "Politique de cryptographie"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Recommandé, paramètres de sécurité pour les modèles actuels de menace."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAUT avec vérification de la signature SHA-1 autorisée."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Une meilleure interopérabilité au prix d’une surface d’attaque accrue."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY avec interopérabilité Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "N’utiliser que des algorithmes approuvés et autorisés lors du démarrage en mode FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS avec des restrictions supplémentaires liées aux critères communs."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protège contre les attaques anticipées à court terme au détriment de l’interopérabilité."
 ],
 "Custom cryptographic policy": [
  null,
  "Politique de cryptographie personnalisée"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Les « Stratégies de chiffrement » sont un composant système qui configure les sous-systèmes de cryptographie. Il couvre les protocoles TLS, IPSec, SSH, DNSSec, et Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Changer de politique de cryptographie"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Application de la nouvelle stratégie… Cette opération peut prendre plusieurs minutes."
 ],
 "Reapply and reboot": [
  null,
  "Appliquer à nouveau et redémarrer"
 ],
 "Apply and reboot": [
  null,
  "Appliquer et redémarrer"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS n’est pas correctement activé"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "La politique de cryptographie est incohérente"
 ],
 "Review cryptographic policy": [
  null,
  "Examiner la politique de cryptographie"
 ],
 "System information": [
  null,
  "Informations sur le système"
 ],
 "Model": [
  null,
  "Modèle"
 ],
 "Asset tag": [
  null,
  "Étiquette d’inventaire"
 ],
 "Machine ID": [
  null,
  "ID machine"
 ],
 "Up since": [
  null,
  "Allumé depuis"
 ],
 "View hardware details": [
  null,
  "Voir les détails du matériel"
 ],
 "Last successful login:": [
  null,
  "Dernière connexion réussie :"
 ],
 "$0 failed login attempt": [
  null,
  "$0 échec de la tentative de connexion",
  "$0 échec des tentatives de connexion"
 ],
 "View login history": [
  null,
  "Afficher l’historique des connexions"
 ],
 "recommended": [
  null,
  "conseillé"
 ],
 "inconsistent": [
  null,
  "Incohérent"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Rejoindre un domaine nécessite l’installation de realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Impossible de joindre un domaine, car realmd n’est pas disponible sur votre système"
 ],
 "Joining this domain is not supported": [
  null,
  "Rejoindre ce domaine n’est pas pris en charge"
 ],
 "Login format": [
  null,
  "Format de connexion"
 ],
 "Server software": [
  null,
  "Logiciels du serveur"
 ],
 "Client software": [
  null,
  "Logiciel client"
 ],
 "Leave domain": [
  null,
  "Quitter le domaine"
 ],
 "Leave $0": [
  null,
  "Laissez $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Une fois le domaine quitté, seuls les utilisateurs disposant d’identifiants locaux pourront se connecter à cette machine. Cela peut également affecter d’autres services tels que les paramètres de résolution DNS. La liste des autorités de certification approuvées peut, en outre, changer."
 ],
 "Validating address": [
  null,
  "Validation de l’adresse"
 ],
 "Contacted domain": [
  null,
  "Domaine contacté"
 ],
 "Domain could not be contacted": [
  null,
  "Le domaine n’a pas pu être contacté"
 ],
 "Domain is not supported": [
  null,
  "Le domaine n’est pas pris en charge"
 ],
 "Domain address": [
  null,
  "Adresse de domaine"
 ],
 "Domain administrator name": [
  null,
  "Nom de l’administrateur du domaine"
 ],
 "Domain administrator password": [
  null,
  "Mot de passe administrateur du domaine"
 ],
 "Joining": [
  null,
  "Rejoindre"
 ],
 "Join": [
  null,
  "Joindre"
 ],
 "This may take a while": [
  null,
  "Cela peut prendre un peu de temps"
 ],
 "Not permitted to configure realms": [
  null,
  "Non autorisé à configurer les domaines"
 ],
 "Join domain": [
  null,
  "Joindre un domaine"
 ],
 "Install realmd support": [
  null,
  "Installer le support realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disque est défaillant",
  "$0 disques sont défaillants"
 ],
 "Connected to Insights": [
  null,
  "Connecté à Insights"
 ],
 "Not connected to Insights": [
  null,
  "Non connecté à Insights"
 ],
 "Health": [
  null,
  "Santé"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 CPUs"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "View metrics and history": [
  null,
  "Voir les métriques et l’historique"
 ],
 "Tuned is not available": [
  null,
  "Tuned n’est pas disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned n'est pas en cours d'exécution"
 ],
 "Tuned is off": [
  null,
  "Tuned est désactivé"
 ],
 "This system is using the recommended profile": [
  null,
  "Ce système utilise le profil recommandé"
 ],
 "This system is using a custom profile": [
  null,
  "Ce système utilise un profil personnalisé"
 ],
 "none": [
  null,
  "aucun"
 ],
 "Communication with tuned has failed": [
  null,
  "La communication avec tuned a échoué"
 ],
 "Failed to enable tuned": [
  null,
  "Échec de l’activation de « tuned »"
 ],
 "Failed to disable tuned": [
  null,
  "Échec de la désactivation de « tuned »"
 ],
 "Failed to disable tuned profile": [
  null,
  "Échec de la désactivation du profil « tuned »"
 ],
 "Failed to switch profile": [
  null,
  "Échec du changement de profil"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "Disable tuned": [
  null,
  "Désactiver tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned n’a pas pu démarrer"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned est un service qui surveille votre système et optimise les performances sous certaines charges de travail. Le cœur de Tuned est constitué de profils, qui permettent de régler votre système pour différents cas d’utilisation."
 ],
 "Change performance profile": [
  null,
  "Modifier le profil de performance"
 ],
 "Change profile": [
  null,
  "Modifier le profil"
 ],
 "Edit /etc/motd": [
  null,
  "Editer /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Impossible d’enregistrer les modifications dans /etc/motd"
 ],
 "Save changes": [
  null,
  "Enregistrer les modifications"
 ],
 "Edit motd": [
  null,
  "Modifier motd"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Not found": [
  null,
  "Non trouvé"
 ],
 "Bad setting": [
  null,
  "Mauvais réglage"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Merged": [
  null,
  "Fusionné"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "Reloading": [
  null,
  "Rechargement"
 ],
 "Not running": [
  null,
  "Pas en cours d’exécution"
 ],
 "Failed to start": [
  null,
  "Échec du démarrage"
 ],
 "Maintenance": [
  null,
  "Maintenance"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Linked": [
  null,
  "Lié"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Masqué"
 ],
 "Static": [
  null,
  "Statique"
 ],
 "Invalid": [
  null,
  "Invalide"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Generated": [
  null,
  "Généré"
 ],
 "Transient": [
  null,
  "Transitoire"
 ],
 "Bad": [
  null,
  "Érroné"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "L’abonnement aux signaux de systemd a échoué : $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "La connexion à dbus a échoué : $0"
 ],
 "Listing units failed: $0": [
  null,
  "L’énumération des unités a échoué : $0"
 ],
 "$0 service has failed": [
  null,
  "$0 service a échoué",
  "$0 services ont échoué"
 ],
 "Loading of units failed": [
  null,
  "Le chargement des unités a échoué"
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Listing units": [
  null,
  "Lister les unités"
 ],
 "Filter by name or description": [
  null,
  "Filtrer par nom ou description"
 ],
 "Active state": [
  null,
  "État actif"
 ],
 "File state": [
  null,
  "État du fichier"
 ],
 "$0 filters applied": [
  null,
  "$0 filtres appliqués"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "L’utilisateur $0 n’est pas autorisé à changer les mitigations de sécurité pour le CPU"
 ],
 "Mitigations": [
  null,
  "Mitigations"
 ],
 "Version": [
  null,
  "Version"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Version du BIOS"
 ],
 "BIOS date": [
  null,
  "Date du BIOS"
 ],
 "CPU security": [
  null,
  "Sécurité du CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Désactiver le multithreading simultané"
 ],
 "Read more...": [
  null,
  "En savoir plus..."
 ],
 "Save and reboot": [
  null,
  "Enregistrer et redémarrer"
 ],
 "CPU security toggles": [
  null,
  "Paramètres de sécurité du CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Les contournements logiciels aident à éviter les problèmes de sécurité du processeur. Ces mitigations on pour effet de bord de réduire les performances. Modifiez ces paramètres à vos risques et périls."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Vendor": [
  null,
  "Fournisseur"
 ],
 "Slot": [
  null,
  "Emplacement"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Technologie de mémoire"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "State": [
  null,
  "État"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Speed": [
  null,
  "Vitesse"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "La visualisation des informations sur la mémoire nécessite un accès administratif."
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "Failed to fetch logs": [
  null,
  "Echec de la récupération des journaux"
 ],
 "Clear all filters": [
  null,
  "Supprimer tous les filtres"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Impossible de trouver des journaux en utilisant la combinaison actuelle de filtres."
 ],
 "No logs found": [
  null,
  "Aucun journal trouvé"
 ],
 "Load earlier entries": [
  null,
  "Charger les entrées précédentes"
 ],
 "You may try to load older entries.": [
  null,
  "Vous pouvez essayer de charger des entrées plus anciennes."
 ],
 "Allow running (unmask)": [
  null,
  "Autoriser l’exécution (unmask)"
 ],
 "Reload": [
  null,
  "Recharger"
 ],
 "Restart": [
  null,
  "Redémarrer"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Clear 'Failed to start'": [
  null,
  "Effacer « Échec du démarrage »"
 ],
 "Mask service": [
  null,
  "Service Masque"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Le service Masque empêche toutes les unités dépendantes d’être exécutées. Cela peut avoir un plus gros impact que prévu. Veuillez confirmer que vous souhaitez masquer cette unité."
 ],
 "Disallow running (mask)": [
  null,
  "Empêcher l’exécution (mask)"
 ],
 "Unpin unit": [
  null,
  "Débrocher l'unité"
 ],
 "Pin unit": [
  null,
  "Unité Pin"
 ],
 "Additional actions": [
  null,
  "Actions supplémenaires"
 ],
 "Note": [
  null,
  "Note"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Cette unité n’est pas conçue pour être activée explicitement."
 ],
 "Forbidden from running": [
  null,
  "Non autorisé à exécuter"
 ],
 "Start service": [
  null,
  "Démarrer le service"
 ],
 "Active since ": [
  null,
  "Actif depuis. "
 ],
 "Required by ": [
  null,
  "Requis par "
 ],
 "Read-only": [
  null,
  "Lecture seule"
 ],
 "Requires administration access to edit": [
  null,
  "Nécessite un accès administrateur pour pouvoir modifier"
 ],
 "Automatically starts": [
  null,
  "Démarre automatiquement"
 ],
 "Updating status...": [
  null,
  "Mise à jour du l'état..."
 ],
 "Stop and disable": [
  null,
  "Arrêter et désactiver"
 ],
 "Start and enable": [
  null,
  "Démarrer et activer"
 ],
 "Failed to load unit": [
  null,
  "Échec du chargement de l'unité"
 ],
 "View all services": [
  null,
  "Voir tous les services"
 ],
 "Triggers": [
  null,
  "Déclencheurs"
 ],
 "Triggered by": [
  null,
  "Déclenché par"
 ],
 "Requires": [
  null,
  "Nécessite"
 ],
 "Requisite": [
  null,
  "Conditions requises"
 ],
 "Wants": [
  null,
  "Recherches"
 ],
 "Binds to": [
  null,
  "Liaison vers"
 ],
 "Part of": [
  null,
  "Partie de"
 ],
 "Required by": [
  null,
  "Requis par"
 ],
 "Requisite of": [
  null,
  "Requis par"
 ],
 "Wanted by": [
  null,
  "Recherché par"
 ],
 "Bound by": [
  null,
  "Liés par"
 ],
 "Consists of": [
  null,
  "Comprend"
 ],
 "Conflicts": [
  null,
  "Conflits"
 ],
 "Conflicted by": [
  null,
  "Conflit avec"
 ],
 "Before": [
  null,
  "Avant"
 ],
 "After": [
  null,
  "Après"
 ],
 "On failure": [
  null,
  "En cas d’échec"
 ],
 "Propagates reload to": [
  null,
  "Recharger Propagation jusqu’à"
 ],
 "Reload propagated from": [
  null,
  "Recharger Propagation à partir de"
 ],
 "Joins namespace of": [
  null,
  "Rejoint l’espace de noms de"
 ],
 "Condition $0=$1 was not met": [
  null,
  "La condition $0 = $1 n’a pas été remplie"
 ],
 "Deletion will remove the following files:": [
  null,
  "La suppression supprimera les fichiers suivants :"
 ],
 "Pinned unit": [
  null,
  "Unité épinglée"
 ],
 "Status": [
  null,
  "État"
 ],
 "Path": [
  null,
  "Chemin"
 ],
 "Listen": [
  null,
  "Écouter"
 ],
 "Container": [
  null,
  "Conteneur"
 ],
 "View Podman container": [
  null,
  "Voir le conteneur Podman"
 ],
 "Condition failed": [
  null,
  "Condition non remplie"
 ],
 "Show more relationships": [
  null,
  "Afficher plus de relations"
 ],
 "Show relationships": [
  null,
  "Afficher les relations"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Timer deletion failed": [
  null,
  "La suppression de la minuterie a échoué"
 ],
 "Targets": [
  null,
  "Cibles"
 ],
 "Sockets": [
  null,
  "Prises"
 ],
 "Timers": [
  null,
  "Minuteurs"
 ],
 "Paths": [
  null,
  "Chemins"
 ],
 "Go to $0": [
  null,
  "Aller à $0"
 ],
 "Journal entry not found": [
  null,
  "Entrée de journal non trouvée"
 ],
 "Journal entry": [
  null,
  "Entrée de journal"
 ],
 "Entry at $0": [
  null,
  "Entrée à $0"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "Loading unit failed": [
  null,
  "Échec du chargement de l'unité"
 ],
 "Service logs": [
  null,
  "Journaux de service"
 ],
 "No log entries": [
  null,
  "Aucune entrée de journal"
 ],
 "Systemd units": [
  null,
  "Unités Systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Aucun résultat correspondant aux critères de filtrage n’a été trouvé. Effacez tous les filtres pour afficher les résultats."
 ],
 "Does not automatically start": [
  null,
  "Ne démarre pas automatiquement"
 ],
 "Cannot be enabled": [
  null,
  "Ne peut pas être activé"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La console Web est exécutée en mode accès limité."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "de $0 sur $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "de $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "sur $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domaine"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Rejoignez un domaine"
 ]
});
