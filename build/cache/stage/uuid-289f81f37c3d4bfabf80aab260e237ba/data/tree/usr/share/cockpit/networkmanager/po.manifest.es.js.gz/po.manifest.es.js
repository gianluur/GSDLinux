cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servicios"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "network": [
  null,
  "red"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interfaz"
 ],
 "bridge": [
  null,
  "puente"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "agregación de enlaces"
 ],
 "team": [
  null,
  "equipo"
 ],
 "port": [
  null,
  "puerto"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "cortafuegos"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zona"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Gestión de agregaciones de enlaces de red"
 ],
 "Managing networking teams": [
  null,
  "Gestión de agregaciones de interfaces de red"
 ],
 "Managing networking bridges": [
  null,
  "Gestión de puentes de red"
 ],
 "Managing VLANs": [
  null,
  "Gestión de VLANs"
 ],
 "Managing firewall": [
  null,
  "Gestión del cortafuegos"
 ]
});
