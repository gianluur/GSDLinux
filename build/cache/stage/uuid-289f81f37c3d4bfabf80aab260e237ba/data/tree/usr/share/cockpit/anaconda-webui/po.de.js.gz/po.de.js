cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 Fehler",
  "$0 Fehler"
 ],
 "$0 installation": [
  null,
  "$0 Installation"
 ],
 "$0 installer": [
  null,
  "$0 Installationsprogramm"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 ist eine erweiterte MBR-Partition, die logische Partitionen enthält. Wenn Sie alle logischen Partitionen entfernen, wird automatisch auch die erweiterte Partition entfernt."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 ist erforderlich, aber nur $1 ist verfügbar."
 ],
 "$0 warning": [
  null,
  "$0 Warnung",
  "$0 Warnungen"
 ],
 "$0 will be deleted": [
  null,
  "$0 wird gelöscht"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Das Dateisystem ‚$0‘ darf nicht auf einem verschlüsselten Blockgerät liegen"
 ],
 "'$0' must be assigned to $1": [
  null,
  "‚$0‘ muss $1 zugewiesen sein"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' muss auf einem mit '$1' formatierten Gerät sein"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' muss sich auf einer EFI-Systempartition befinden. Die ausgewählte Partition verwendet ein FAT-Dateisystem, ist jedoch nicht als ESP gekennzeichnet. Setzen Sie den Partitionstyp auf EFI-System und aktivieren Sie das esp-Flag."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Partition ,$0' auf MDRAID-Gerät $1 gefunden. Bootloader-Partitionen auf MDRAID-Geräten werden nicht unterstützt."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Ein Standardbenutzerkonto mit Administratorrechten zum Vornehmen systemweiter Änderungen."
 ],
 "Abort installation": [
  null,
  "Installation abbrechen"
 ],
 "About": [
  null,
  "Über"
 ],
 "Account": [
  null,
  "Konto"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "Add another server...": [
  null,
  "Einen weiteren Server hinzufügen..."
 ],
 "Add mount": [
  null,
  "Einhängepunkt hinzufügen"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Add-ons für Ihre ausgewählte Umgebung"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Add-ons, die nicht spezifisch für Ihre Umgebung sind"
 ],
 "Additional languages": [
  null,
  "Zusätzliche Sprachen"
 ],
 "Additional software for the selected environment": [
  null,
  "Zusätzliche Software für die ausgewählte Umgebung"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Alle Änderungen, welche im Speicher-Editor vorgenommen werden, werden umgehend angewendet."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Alle Geräte, welche diese Passphrase benutzen, werden entsperrt"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Anaconda-Projektseite"
 ],
 "Apply mount point assignment and install": [
  null,
  "Einhängepunkt-Zuweisungen anwenden und installieren"
 ],
 "Applying changes...": [
  null,
  "Änderungen werden angewendet..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Partitionen zu Einhängepunkten zuordnen. Nützlich für vorkonfigurierte, benutzerdefinierte Layouts."
 ],
 "Automatic log file upload": [
  null,
  "Automatisches Hochladen der Protokolldatei"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Datum und Uhrzeit automatisch über Zeitserver festlegen"
 ],
 "Automatically set timezone": [
  null,
  "Zeitzone automatisch festlegen"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Verfügbarer freier Speicher: $0. Die Installation benötigt: $1."
 ],
 "Back": [
  null,
  "Zurück"
 ],
 "Base environment": [
  null,
  "Basisumgebung"
 ],
 "Brief description of the issue": [
  null,
  "Kurzbeschreibung des Problems"
 ],
 "Bug report details": [
  null,
  "Details zum Fehlerbericht"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla-API-Schlüssel"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Wenn Sie fortfahren, verstehen und akzeptieren Sie die mit vorveröffentlichter Software verbundenen Risiken, die Sie nur für Test- und Entwicklungszwecke verwenden möchten und bereit sind, Fehler oder Probleme zu melden, um diese Arbeit zu verbessern."
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change destination": [
  null,
  "Ziel ändern"
 ],
 "Change hostname": [
  null,
  "Name des Rechners ändern"
 ],
 "Change partition layout": [
  null,
  "Partitionslayout ändern"
 ],
 "Change system keyboard layout": [
  null,
  "Systemtastaturbelegung ändern"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Hier gemachte Änderungen wirken sofort auf das System. Es gibt kein 'rückgängig machen'."
 ],
 "Checking installation configuration...": [
  null,
  "Konfiguration der Installation wird überprüft ..."
 ],
 "Checking storage configuration": [
  null,
  "Überprüfung der Konfiguration der Speichermedien"
 ],
 "Clear search": [
  null,
  "Suche löschen"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Klicken Sie erneut auf ‚Weiter‘, um trotz dieser Warnungen fortzufahren."
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Close storage editor": [
  null,
  "Speicher-Editor schließen"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Der Cockpit-Speicher hat keine Passphrase bereitgestellt, um das verschlüsselte Gerät zu entsperren."
 ],
 "Completed": [
  null,
  "Fertig"
 ],
 "Configuration is incomplete": [
  null,
  "Konfiguration ist unvollständig"
 ],
 "Configure NTP servers": [
  null,
  "NTP-Server konfigurieren"
 ],
 "Configure custom NTP servers": [
  null,
  "Benutzerdefinierte NTP-Server konfigurieren"
 ],
 "Configure network": [
  null,
  "Netzwerk konfigurieren"
 ],
 "Configure storage": [
  null,
  "Speicher konfigurieren"
 ],
 "Configure storage again": [
  null,
  "Speicher erneut konfigurieren"
 ],
 "Confirm passphrase": [
  null,
  "Passphrase bestätigen"
 ],
 "Continue": [
  null,
  "Weiter"
 ],
 "Continue installation": [
  null,
  "Installation fortsetzen"
 ],
 "Continue installation?": [
  null,
  "Installation fortsetzen?"
 ],
 "Continue with installation": [
  null,
  "Installation fortsetzen"
 ],
 "Correct these issues before continuing.": [
  null,
  "Beheben Sie diese Probleme, bevor Sie fortfahren."
 ],
 "Create Account": [
  null,
  "Konto erstellen"
 ],
 "Create account": [
  null,
  "Konto erstellen"
 ],
 "Currently installed: $0": [
  null,
  "Derzeit installiert: $0"
 ],
 "Custom": [
  null,
  "Benutzerdefiniert"
 ],
 "Date": [
  null,
  "Datum"
 ],
 "Date and time": [
  null,
  "Datum und Zeit"
 ],
 "Delete partition": [
  null,
  "Partition löschen"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Das entfernen bestimmter Partitionen könnte $0 davon abhalten zu starten: $1"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Destination": [
  null,
  "Ziel"
 ],
 "Destination is encrypted": [
  null,
  "Ziel ist verschlüsselt"
 ],
 "Detailed description of the issue": [
  null,
  "Ausführliche Beschreibung des Problems"
 ],
 "Detected valid storage layout:": [
  null,
  "Valide Speicher-Anordnung erkannt:"
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Duplicate device.": [
  null,
  "Doppeltes Gerät."
 ],
 "Duplicate mount point.": [
  null,
  "Einhängepunkt duplizieren."
 ],
 "Enable root account": [
  null,
  "Root-Benutzerkonto aktivieren"
 ],
 "Encrypt my data": [
  null,
  "Meine Daten verschlüsseln"
 ],
 "Encrypted": [
  null,
  "Verschlüsselt"
 ],
 "Encryption": [
  null,
  "Verschlüsselung"
 ],
 "Enter PIN": [
  null,
  "PIN eingeben"
 ],
 "Enter PIN to access the installer": [
  null,
  "PIN eingeben, um auf das Installationsprogramm zuzugreifen"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Geben Sie Ihren Bugzilla-API-Schlüssel ein, um einen Fehlerbericht zu erstellen. Im nächsten Schritt können Sie die Fehlerdetails einsehen und bearbeiten."
 ],
 "Environment": [
  null,
  "Umgebung"
 ],
 "Erase data and install": [
  null,
  "Speichermedien löschen und installieren"
 ],
 "Error details": [
  null,
  "Fehlerdetails"
 ],
 "Exit to live desktop": [
  null,
  "Zum Live-Desktop zurückkehren"
 ],
 "Extended partition": [
  null,
  "Erweiterte Partition"
 ],
 "Failed to report issue": [
  null,
  "Problem konnte nicht gemeldet werden"
 ],
 "Failed to save layouts": [
  null,
  "Layouts konnten nicht gespeichert werden"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux benötigt mindestens $0 an Festplattenspeicher."
 ],
 "Finalization": [
  null,
  "Abschluss"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Vervollständigen: Die Systemkonfiguration ist abgeschlossen. Das Abschließen der Installation kann einen Moment dauern."
 ],
 "Find layout": [
  null,
  "Layout finden"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Vermeiden Sie aus Sicherheitsgründen die direkte Verwendung des Root-Kontos. Verwenden Sie stattdessen das oben genannte lokale Konto, um das System zu verwalten."
 ],
 "Full name": [
  null,
  "Vollständiger Name"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Der vollständige Name darf keine Doppelpunkte enthalten"
 ],
 "Helper text": [
  null,
  "Hilfetext"
 ],
 "Hide API key": [
  null,
  "API-Schlüssel ausblenden"
 ],
 "Hide PIN": [
  null,
  "PIN ausblenden"
 ],
 "Hide confirmed password": [
  null,
  "Bestätigtes Passwort verstecken"
 ],
 "Hide passphrase": [
  null,
  "Passphrase verstecken"
 ],
 "Hide password": [
  null,
  "Passwort verstecken"
 ],
 "Hostname": [
  null,
  "Rechnername"
 ],
 "How would you like to install?": [
  null,
  "Wie möchten Sie installieren?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Ich verstehe, dass alle existierenden Daten von dem ausgewählten Datenträger gelöscht werden.",
  "Ich verstehe, dass alle existierenden Daten von den ausgewählten Datenträgern gelöscht werden."
 ],
 "I understand that some existing data will be erased": [
  null,
  "Ich verstehe, dass einige bestehende Daten gelöscht werden"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Ich verstehe, dass manche Partitionen verändert werden"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Falls nicht angegeben, wird der Rechnername vorübergehend durch Netzwerkinformationen festgelegt."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Falls keine der oben genannten Optionen zutrifft, verwenden Sie den Speicher-Editor, um eine benutzerdefinierte Partitionierung zu erstellen, bevor Sie fortfahren."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Wenn Sie Partitionen konfigurieren, sind Folgende erforderlich:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Wenn Sie der automatischen Protokolldatei-Hochladung nicht zustimmen, können Sie stattdessen $0 eingeben. Die manuelle Berichterstellung ermöglicht es Ihnen, Protokolldateien selbst zu überprüfen und gezielt anzuhängen."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Falls Sie die Risiken nicht verstehen oder akzeptieren, verlassen Sie bitte dieses Programm."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Falls Ihr Problem einem der oben genannten Fehler entspricht, können Sie diesen öffnen und Ihre Informationen dort hinzufügen, anstatt ein Duplikat zu erstellen."
 ],
 "In progress": [
  null,
  "In Arbeit"
 ],
 "Initializing...": [
  null,
  "Initialisierung ..."
 ],
 "Install": [
  null,
  "Installieren"
 ],
 "Installation failed": [
  null,
  "Installation fehlgeschlagen"
 ],
 "Installation method": [
  null,
  "Installationsmethode"
 ],
 "Installation of the system failed": [
  null,
  "Installation des Systems fehlgeschlagen"
 ],
 "Installation of the system failed: $0": [
  null,
  "Installation des Systems fehlgeschlagen: $0"
 ],
 "Installation type": [
  null,
  "Installationstyp"
 ],
 "Installing": [
  null,
  "Installation wird ausgeführt"
 ],
 "Insufficient disk space": [
  null,
  "Unzureichender Festplattenplatz"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Ungültige PIN. Bitte erneut versuchen."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Ungültige RAID-Konfiguration erkannt. Wenn Ihr RAID-Array direkt auf‐ denF estplatten erstellt wurde, muss eine Partitionstabelle auf dem Array angelegt werden. Wenn Ihr RAID-Array auf Partitionen basiert, muss es ein einzelnes Dateisystem oder Format (z. B. LVM PV) enthalten. Vorhandene Partitionen auf diesem Array werden ignoriert."
 ],
 "Invalid hostname": [
  null,
  "Ungültiger Hostname"
 ],
 "Jump to first incomplete step": [
  null,
  "Zum ersten unvollständigen Schritt springen"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Die aktuelle Datenträgeranordnung beibehalten und den verfügbaren Platz nutzen, um ein Dual-Boot mit einem anderen Betriebssystem durchzuführen."
 ],
 "Keyboard": [
  null,
  "Tastatur"
 ],
 "Keyboard layout during boot": [
  null,
  "Tastaturbelegung beim Booten"
 ],
 "Language": [
  null,
  "Sprache"
 ],
 "Launch storage editor": [
  null,
  "Speicher-Editor starten"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Erfahren Sie mehr"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Beide Passphrasenfelder leer lassen, um ein leeres Passwort zu verwenden."
 ],
 "Location": [
  null,
  "Ort"
 ],
 "Locked devices": [
  null,
  "Gesperrte Geräte"
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Make current": [
  null,
  "Aktuell machen"
 ],
 "Manual disk configuration": [
  null,
  "Manuelle Datenträgerkonfiguration"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manuelle Datenträgerkonfiguration: Zuordnung der Einhängepunkte"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Kann Buchstaben, Zahlen und Bindestriche enthalten."
 ],
 "May need more free space": [
  null,
  "Möglicherweise wird mehr freier Speicherplatz benötigt"
 ],
 "Medium": [
  null,
  "Mittel"
 ],
 "Minimum of $0 required": [
  null,
  "Mindestens $0 erforderlich"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Unstimmigkeit zwischen übergeordnetem Gerät und der Auswahl der Neuformatierung des untergeordneten Geräts."
 ],
 "Mount point": [
  null,
  "Einhängepunkt"
 ],
 "Mount point assignment": [
  null,
  "Zuweisung des Einhängepunkts"
 ],
 "Move down": [
  null,
  "Nach unten verschieben"
 ],
 "Move up": [
  null,
  "Nach oben verschieben"
 ],
 "Must be at least $0 characters": [
  null,
  "Muss aus mindestens $0 Zeichen bestehen"
 ],
 "My issue is different, continue": [
  null,
  "Mein Problem ist ein anderes, fortfahren"
 ],
 "NTP Servers": [
  null,
  "NTP-Server"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Needs at least $0": [
  null,
  "Benötigt mindestens $0"
 ],
 "Network": [
  null,
  "Netzwerk"
 ],
 "Network Configuration": [
  null,
  "Netzwerkkonfiguration"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Netzwerk nicht verfügbar. Konfigurieren Sie das Netzwerk im oberen Menü, um das Problem zu melden."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Netzwerk nicht verfügbar. Konfigurieren Sie das Netzwerk, um das Problem zu melden."
 ],
 "Network plugin failed": [
  null,
  "Netzwerk-Plugin fehlgeschlagen"
 ],
 "Next": [
  null,
  "Nächste"
 ],
 "No devices": [
  null,
  "Keine Geräte"
 ],
 "No disks available": [
  null,
  "Keine Datenträger verfügbar"
 ],
 "No disks selected": [
  null,
  "Keine Medien ausgewählt"
 ],
 "No keyboard layouts selected": [
  null,
  "Keine Tastaturbelegungen ausgewählt"
 ],
 "No layouts selected yet": [
  null,
  "Noch keine Belegungen ausgewählt"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Für das/die ausgewählte(n) Tastaturlayout(s) konnte keine gültige VConsole-Tastaturbelegung abgerufen werden. Bitte wählen Sie ein anderes Tastaturlayout aus."
 ],
 "Not enough available free space": [
  null,
  "Nicht genügend freier Speicherplatz verfügbar"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Nicht genügend freier Speicherplatz auf dem gewählten Datenträger."
 ],
 "Not enough space on selected disks.": [
  null,
  "Nicht genügend Speicherplatz auf dem gewählten Datenträger."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Achtung: Dies ist eine Vorabversion zu Entwicklungs- und Testzwecken. Bitte NICHT benutzen für Produktivumgebungen und wichtige Arbeiten."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Bugzilla-Fehlermeldungsformular öffnen"
 ],
 "Operating system": [
  null,
  "Betriebssystem"
 ],
 "Options": [
  null,
  "Optionen"
 ],
 "Other keyboards": [
  null,
  "Andere Tastaturen"
 ],
 "Partitions (advanced)": [
  null,
  "Partitionen (fortgeschritten)"
 ],
 "Passphrase": [
  null,
  "Passphrase"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Passphrase stimmte bei keinem gesperrten Gerät überein"
 ],
 "Passphrases must match": [
  null,
  "Passphrasen müssen übereinstimmen"
 ],
 "Pending": [
  null,
  "Ausstehend"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Bitte hängen Sie Logdatei $0 an das Problem an."
 ],
 "Please enter a PIN": [
  null,
  "Bitte eine PIN eingeben"
 ],
 "Please select at least one disk to continue": [
  null,
  "Bitte wählen Sie mindestens einen Datenträger aus, um fortzufahren"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Potenzielle doppelte Fehler gefunden"
 ],
 "Powered by Anaconda": [
  null,
  "Powered by Anaconda"
 ],
 "Pre-release": [
  null,
  "Vorabversion"
 ],
 "Prefer to report manually? $0": [
  null,
  "Sie möchten lieber manuell berichten? $0"
 ],
 "Proceed with installation": [
  null,
  "Installation fortsetzen"
 ],
 "Quit": [
  null,
  "Beenden"
 ],
 "Quit installer?": [
  null,
  "Installationsprogramm beenden?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Einlesen der Informationen zum Betriebssystem fehlgeschlagen."
 ],
 "Reading information about the computer failed.": [
  null,
  "Einlesen der Informationen zum Computer fehlgeschlagen."
 ],
 "Reading installer configuration failed.": [
  null,
  "Einlesen der Konfiguration des Installationsprogramms fehlgeschlagen."
 ],
 "Reading installer version information failed.": [
  null,
  "Einlesen der Versionsinformationen des Installationsprogramms fehlgeschlagen."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Der tatsächliche Rechnername darf nur Buchstaben, Zahlen, Bindestriche (nicht mit einem Bindestrich beginnend oder endend) und Punkte enthalten"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Der tatsächliche Rechnername darf maximal 64 Zeichen lang sein"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Starten Sie Windows, um mit BitLocker verschlüsselte Partitionen zu verändern. Stellen Sie mindestens $0 freien Speicherplatz für die Installation bereit."
 ],
 "Reboot system?": [
  null,
  "System neustarten?"
 ],
 "Reclaim additional space": [
  null,
  "Zusätzlichen Speicherplatz zurückgewinnen"
 ],
 "Reclaim space": [
  null,
  "Speicherplatz zurückgewinnen"
 ],
 "Reclaim space (required)": [
  null,
  "Speicherplatz zurückgewinnen (notwendig)"
 ],
 "Recommended": [
  null,
  "Empfohlen"
 ],
 "Recommended partitions:": [
  null,
  "Empfohlene Partitionen:"
 ],
 "Reformat": [
  null,
  "Neu formatieren"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora neu installieren"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Alle Partitionen auf den ausgewählten Geräten entfernen, einschließlich vorhandener Betriebssysteme."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Existierende Dateisysteme entfernen oder deren Größe ändern, um Platz für die Installation zu schaffen."
 ],
 "Remove server": [
  null,
  "Server entfernen"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Das Entfernen eines Dateisystems führt zur dauerhaften Löschung aller darin enthaltenen Daten. Durch das Ändern der Größe einer Partition kann ungenutzter Speicherplatz freigegeben werden, dies ist jedoch nicht risikofrei. Stellen Sie sicher, dass Sie von allen wichtigen Daten Sicherungskopien erstellt haben, bevor Sie Speicherplatz freigeben."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Aktuelle Installation ersetzen, aber Dateien im Benutzerordner behalten."
 ],
 "Report Issue": [
  null,
  "Fehler melden"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Melden Sie ein Problem oder geben Sie Feedback, indem Sie das Bugzilla-Fehlermeldungsformular öffnen $0."
 ],
 "Report issue": [
  null,
  "Fehler melden"
 ],
 "Reporting issue...": [
  null,
  "Problem melden..."
 ],
 "Required": [
  null,
  "Erforderlich"
 ],
 "Requirements": [
  null,
  "Voraussetzungen"
 ],
 "Rescan devices": [
  null,
  "Geräte erneut einlesen"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Erneutes Scannen der Datenträger ist fehlgeschlagen."
 ],
 "Resize": [
  null,
  "Größe ändern"
 ],
 "Resize partition": [
  null,
  "Partition vergrößern"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Größe der folgenden Partitionen von $0 ändern: $1"
 ],
 "Restrict access to the report": [
  null,
  "Beschränken Sie den Zugriff auf den Bericht"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Beschränkt den Bericht auf die Gruppe $0.$1"
 ],
 "Return to installation": [
  null,
  "Zur Installation zurückkehren"
 ],
 "Return to storage editor": [
  null,
  "Zum Speicher-Editor zurückkehren"
 ],
 "Review and install": [
  null,
  "Überprüfen und Installation starten"
 ],
 "Root account has been configured": [
  null,
  "Root-Konto wurde konfiguriert"
 ],
 "Root account is enabled": [
  null,
  "Root-Konto ist aktiviert"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root-Konto ist aktiviert, aber es wurde kein Benutzerkonto konfiguriert"
 ],
 "Root password has been set.": [
  null,
  "Root-Passwort wurde gesetzt."
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scannen Sie den QR-Code mit Ihrem Handy oder besuchen Sie:"
 ],
 "Search for a language": [
  null,
  "Nach einer Sprache suchen"
 ],
 "Search for additional software": [
  null,
  "Nach zusätzlicher Software suchen"
 ],
 "Search for an environment": [
  null,
  "Nach einer Umgebung suchen"
 ],
 "Search keyboard layout": [
  null,
  "Tastaturbelegung ändern"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Sichern Sie Ihre Daten durch festplattenbasierte Verschlüsselung. Gilt nur für neue Partitionen"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "Select a device": [
  null,
  "Gewähltes Speichermedium"
 ],
 "Select city": [
  null,
  "Stadt auswählen"
 ],
 "Select destination": [
  null,
  "Ziel auswählen"
 ],
 "Select region": [
  null,
  "Region auswählen"
 ],
 "Selected (top = current)": [
  null,
  "Ausgewählt (oben = aktuell)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Format '$0' des ausgewählten Geräts kann nicht neu formatiert werden."
 ],
 "Send us feedback on your installation": [
  null,
  "Senden Sie uns Feedback zu Ihrer Installation"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server ist nicht erreichbar"
 ],
 "Set custom hostname": [
  null,
  "Eigenen Rechnername festlegen"
 ],
 "Share disk with other operating systems": [
  null,
  "Datenträger mit anderen Betriebssystemen teilen"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Datenträger mit anderen Betriebssystemen teilen: $0"
 ],
 "Show AM/PM": [
  null,
  "AM/PM anzeigen"
 ],
 "Show API key": [
  null,
  "API-Schlüssel anzeigen"
 ],
 "Show PIN": [
  null,
  "PIN anzeigen"
 ],
 "Show confirmed password": [
  null,
  "Zeige bestätigtes Passwort"
 ],
 "Show passphrase": [
  null,
  "Passphrase anzeigen"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Software installation": [
  null,
  "Software Installation"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Softwareinstallation: Speicherkonfiguration abgeschlossen. Die Software wird nun auf Ihrem Gerät installiert."
 ],
 "Software selection": [
  null,
  "Softwareauswahl"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Es müssen noch einige Installationsschritte abgeschlossen werden, bevor Sie fortfahren können."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Einige benötigte Partitionen fehlen: $0"
 ],
 "Space": [
  null,
  "Platz"
 ],
 "Stacktrace": [
  null,
  "Stapelzurückverfolgung"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Storage configuration": [
  null,
  "Speicher Konfiguration"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Speicherkonfiguration: Der Speicher wird derzeit konfiguriert."
 ],
 "Storage editor": [
  null,
  "Speicher-Editor"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Speicherkonfiguration basiert auf der Konfiguration aus 'Speicher bearbeiten'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Das Speicherlayout wird durch die Kickstart-Datei definiert. Das geplante Partitionierungslayout kann im Zusammenfassungsschritt eingesehen werden."
 ],
 "Storage plugin failed": [
  null,
  "Speicher-Plugin fehlgeschlagen"
 ],
 "Storage requirements not met": [
  null,
  "Speicheranforderungen nicht erfüllt"
 ],
 "Strong": [
  null,
  "Stark"
 ],
 "Successfully installed": [
  null,
  "Erfolgreich installiert"
 ],
 "Successfully unlocked $0.": [
  null,
  "Erfolgreich $0 entsperrt."
 ],
 "Suggested keyboards": [
  null,
  "Vorgeschlagene Tastaturen"
 ],
 "Suggested languages": [
  null,
  "Vorgeschlagene Sprachen"
 ],
 "System": [
  null,
  "System"
 ],
 "System configuration": [
  null,
  "Systemkonfiguration"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Systemkonfiguration: Softwareinstallation abgeschlossen. Das System wird nun konfiguriert."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Die Installation von Anaconda wurde unerwartet gestoppt."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Die folgenden offenen Fehler könnten mit Ihrem Problem zusammenhängen. Bitte sehen Sie sich diese an, bevor Sie einen neuen Bericht erstellen."
 ],
 "The following user will be created:": [
  null,
  "Der Folgender Benutzer wird erstellt:",
  "Die Folgenden Benutzer werden erstellt:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Die Installation benötigt $0 Speicherplatz; die Kapazität der ausgewählten Datenträger beträgt jedoch nur $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Die Installation kann durch einen kritischen Fehler nicht fortgesetzt werden."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Die Installation kann durch einen kritischen Fehler nicht fortgesetzt werden: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Die eingegebene Passphrase enthält Nicht-ASCII-Zeichen. Eventuell ist es nicht möglich das Tastaturlayout während der Eingabe anzupassen."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Die ausgewählte Standardtastaturbelegung unterstützt keine ASCII-Zeichen. Bitte wählen Sie eine ASCII-fähige Belegung als Standard aus."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Der Speichereditor ermöglicht das Ändern der Größe, das Löschen und Erstellen von Partitionen. Er kann LVM einrichten und vieles mehr. Er ist als fortgeschrittenes Hilfsprogramm gedacht und nicht für den Einsatz in einer typischen Installation vorgesehen."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Protokolle können sensible Informationen wie IP-Adressen,Benutzernamen oder andere Systemdetails enthalten."
 ],
 "This hostname can't be submitted": [
  null,
  "Dieser Rechnername kann nicht übermittelt werden"
 ],
 "This is unstable, pre-release software": [
  null,
  "Dies ist eine Vorabversion, die instabil sein kann"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Dieses Layout wird zum Entsperren Ihres Systems beim Hochfahren verwendet"
 ],
 "This may take a moment": [
  null,
  "Dies kann einen Moment dauern"
 ],
 "This will take a few moments": [
  null,
  "Dies wird einige Momente dauern"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Timezone": [
  null,
  "Zeitzone"
 ],
 "Title": [
  null,
  "Titel"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Starten Sie das System neu, um mit der Nutzung von $0 zu beginnen."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Um fortzufahren, wählen die Speichermedien für die Installation aus."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Um diese Option zu benutzen, entfernen Sie bestehende Partitionen oder ändern ihre Größe, um mindestens $0 freizugeben."
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Löschung von $0 kann nicht geplant werden"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Größenänderung von $0 kann nicht geplant werden"
 ],
 "Undo last action": [
  null,
  "Letzte Aktion rückgängig machen"
 ],
 "Unlock": [
  null,
  "Entsperren"
 ],
 "Unlock encrypted devices": [
  null,
  "Entsperren des verschlüsselten Speichermediums"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Entsperren Sie verschlüsselte Partitionen, um vorhandene Daten zu behalten und weitere Installationsmethoden anzuzeigen."
 ],
 "Use configured storage": [
  null,
  "Konfigurierten Speicher nutzen"
 ],
 "Use entire disk": [
  null,
  "Gesamten Datenträger verwenden"
 ],
 "Use free space": [
  null,
  "Freien Speicherplatz nutzen"
 ],
 "Use local account": [
  null,
  "Lokales Konto verwenden"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "RAID-Gerät für die automatische Partitionierung verwenden"
 ],
 "User creation": [
  null,
  "Benutzererstellung"
 ],
 "User name": [
  null,
  "Benutzername"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Der Benutzername darf nur Buchstaben von a-z, Zahlen, Bindestriche $0, Punkte $1 und Unterstriche $2 enthalten"
 ],
 "User name must not be a reserved word": [
  null,
  "Der Benutzername darf kein reserviertes Wort sein"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Der Benutzername muss kürzer als 33 Zeichen sein"
 ],
 "Validating...": [
  null,
  "Validierung..."
 ],
 "Weak": [
  null,
  "Schwach"
 ],
 "Welcome": [
  null,
  "Willkommen"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Willkommen bei Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Willkommen. Lassen Sie uns nun $0 installieren."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Wenn Sie diesen Fehlerbericht einreichen, werden die folgenden Protokolldateien automatisch hochgeladen: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Die Größe von Windows-Partitionen mit BitLocker-Verschlüsselung kann nicht geändert werden"
 ],
 "You can close this browser window now.": [
  null,
  "Sie können dieses Browserfenster jetzt schließen."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Sie können hier entweder genügend Platz freimachen und den Rest vom Installationsprogramm erledigen lassen oder manuell Partitionen einrichten."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Sie können den API-Schlüssel für Ihr Bugzilla-Konto für $0 generieren."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Sie müssen das root-Konto aktivieren oder ein lokales Benutzerkonto erstellen, um fortzufahren."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Sie müssen mit einem Netzwerk verbunden sein, um die automatische Einstellung von Datum und Uhrzeit aktivieren zu können."
 ],
 "Your progress will not be saved.": [
  null,
  "Ihr Fortschritt wird nicht gespeichert."
 ],
 "completed step": [
  null,
  "Fertiger Schritt"
 ],
 "current step": [
  null,
  "Aktueller Schritt"
 ],
 "delete": [
  null,
  "löschen"
 ],
 "edit": [
  null,
  "editieren"
 ],
 "encrypt": [
  null,
  "verschlüsseln"
 ],
 "encrypted": [
  null,
  "verschlüsselt"
 ],
 "extended partition": [
  null,
  "erweiterte Partition"
 ],
 "format as $0": [
  null,
  "formatieren als $0"
 ],
 "here": [
  null,
  "hier"
 ],
 "incomplete": [
  null,
  "unvollständig"
 ],
 "mount": [
  null,
  "einhängen"
 ],
 "pending step": [
  null,
  "anstehender Schritt"
 ],
 "report the issue manually": [
  null,
  "Melden Sie das Problem manuell"
 ],
 "resized from $0": [
  null,
  "Größe geändert von $0"
 ],
 "shrink": [
  null,
  "verkleinern"
 ],
 "shrink to $0": [
  null,
  "auf $0 verkleinern"
 ],
 "transient, will use DHCP": [
  null,
  "Es wird vorübergehend DHCP verwendet"
 ],
 "undo": [
  null,
  "rückgängig machen"
 ]
});
