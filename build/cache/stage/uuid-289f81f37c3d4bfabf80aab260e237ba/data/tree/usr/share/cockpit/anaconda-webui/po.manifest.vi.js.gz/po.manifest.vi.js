cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "vi",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Trình cài đặt Anaconda"
 ]
});
