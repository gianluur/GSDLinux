cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
