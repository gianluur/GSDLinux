cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "th",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "ข้อผิดพลาด $0 รายการ"
 ],
 "$0 installation": [
  null,
  "การติดตั้ง $0"
 ],
 "$0 installer": [
  null,
  "โปรแกรมติดตั้ง $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 คือพาร์ทิชันขยายแบบ MBR ที่มีพาร์ทิชันย่อยอยู่ข้างใน การลบพาร์ทิชันย่อยทั้งหมดจะทำให้พาร์ทิชันขยายนี้ถูกลบออกไปโดยอัตโนมัติเช่นกัน"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "จำเป็นต้องใช้ $0 แต่มีเหลืออยู่เพียง $1 เท่านั้น"
 ],
 "$0 warning": [
  null,
  "คำเตือน $0 รายการ"
 ],
 "$0 will be deleted": [
  null,
  "$0 จะถูกลบ"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "ระบบไฟล์ '$0' ไม่สามารถอยู่บนอุปกรณ์บล็อกที่เข้ารหัสลับได้"
 ],
 "'$0' must be assigned to $1": [
  null,
  "ต้องกำหนด '$0' ให้กับ $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' จะต้องอยู่บนอุปกรณ์ที่ถูกฟอร์แมตเป็น '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' จะต้องอยู่บนพาร์ทิชันระบบ EFI พาร์ทิชันที่เลือกใช้ระบบไฟล์ FAT แต่ไม่ได้ถูกทำเครื่องหมายว่าเป็น ESP โปรดตั้งค่าชนิดพาร์ทิชันเป็น EFI System และเปิดใช้งานแฟล็ก esp"
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "พบพาร์ทิชัน '$0' บนอุปกรณ์ MDRAID $1 แต่ระบบไม่รองรับพาร์ทิชันบูตโหลดเดอร์บนอุปกรณ์ MDRAID"
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "บัญชีผู้ใช้มาตรฐานที่มีสิทธิ์ผู้ดูแลระบบสำหรับการเปลี่ยนแปลงทั่วทั้งระบบ"
 ],
 "Abort installation": [
  null,
  "ยกเลิกการติดตั้ง"
 ],
 "About": [
  null,
  "เกี่ยวกับ"
 ],
 "Account": [
  null,
  "บัญชี"
 ],
 "Actions": [
  null,
  "การดำเนินการ"
 ],
 "Add another server...": [
  null,
  "เพิ่มเซิร์ฟเวอร์อื่น..."
 ],
 "Add mount": [
  null,
  "เพิ่มการเมานต์"
 ],
 "Add-ons for your chosen environment": [
  null,
  "ส่วนเสริมสำหรับสภาพแวดล้อมที่คุณเลือก"
 ],
 "Add-ons not specific to your environment": [
  null,
  "ส่วนเสริมที่ไม่เฉพาะเจาะจงกับสภาพแวดล้อมของคุณ"
 ],
 "Additional languages": [
  null,
  "ภาษาเพิ่มเติม"
 ],
 "Additional software for the selected environment": [
  null,
  "ซอฟต์แวร์เพิ่มเติมสำหรับสภาพแวดล้อมที่เลือก"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "การเปลี่ยนแปลงทั้งหมดที่ทำในตัวแก้ไขพื้นที่จัดเก็บข้อมูลจะมีผลทันที"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "อุปกรณ์ทั้งหมดที่ใช้วลีรหัสผ่านนี้จะถูกปลดล็อก"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "หน้าโครงการ Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "เริ่มใช้การกำหนดจุดเมานต์และติดตั้ง"
 ],
 "Applying changes...": [
  null,
  "กำลังเริ่มใช้การเปลี่ยนแปลง..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "กำหนดพาร์ทิชันให้กับจุดเมานต์ มีประโยชน์สำหรับโครงสร้างที่ปรับแต่งไว้ล่วงหน้า"
 ],
 "Automatic log file upload": [
  null,
  "การอัปโหลดไฟล์ปูมอัตโนมัติ"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "ตั้งวันที่และเวลาโดยอัตโนมัติ โดยใช้เซิร์ฟเวอร์เวลา"
 ],
 "Automatically set timezone": [
  null,
  "ตั้งค่าเขตเวลาโดยอัตโนมัติ"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "พื้นที่ว่างที่ใช้งานได้: $0 จำเป็นต้องใช้สำหรับการติดตั้ง: $1"
 ],
 "Back": [
  null,
  "ย้อนกลับ"
 ],
 "Base environment": [
  null,
  "สภาพแวดล้อมพื้นฐาน"
 ],
 "Brief description of the issue": [
  null,
  "คำอธิบายปัญหาโดยย่อ"
 ],
 "Bug report details": [
  null,
  "รายละเอียดรายงานบั๊ก"
 ],
 "Bugzilla API key": [
  null,
  "คีย์ API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "การใช้งานซอฟต์แวร์นี้ต่อไปถือว่าคุณเข้าใจและยอมรับความเสี่ยงต่าง ๆ ที่เกี่ยวข้องกับซอฟต์แวร์รุ่นก่อนเผยแพร่จริง โดยคุณมีจุดประสงค์ที่จะใช้งานซอฟต์แวร์นี้เพื่อการทดสอบและการพัฒนาเท่านั้น และยินดีที่จะรายงานบั๊กหรือปัญหาต่าง ๆ เพื่อช่วยปรับปรุงผลงานชิ้นนี้ให้ดีขึ้น"
 ],
 "Cancel": [
  null,
  "ยกเลิก"
 ],
 "Change": [
  null,
  "เปลี่ยน"
 ],
 "Change destination": [
  null,
  "เปลี่ยนปลายทาง"
 ],
 "Change hostname": [
  null,
  "เปลี่ยนชื่อโฮสต์"
 ],
 "Change partition layout": [
  null,
  "เปลี่ยนโครงสร้างพาร์ทิชัน"
 ],
 "Change system keyboard layout": [
  null,
  "เปลี่ยนรูปแบบแป้นพิมพ์ของระบบ"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "การเปลี่ยนแปลงใด ๆ ที่ทำในส่วนนี้จะมีผลต่อระบบทันที และไม่สามารถยกเลิกได้"
 ],
 "Checking installation configuration...": [
  null,
  "กำลังตรวจสอบการกำหนดค่าการติดตั้ง..."
 ],
 "Checking storage configuration": [
  null,
  "กำลังตรวจสอบการกำหนดค่าพื้นที่จัดเก็บข้อมูล"
 ],
 "Clear search": [
  null,
  "ล้างการค้นหา"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "คลิก 'ถัดไป' อีกครั้งเพื่อดำเนินการต่อแม้จะมีคำเตือนเหล่านี้"
 ],
 "Close": [
  null,
  "ปิด"
 ],
 "Close storage editor": [
  null,
  "ปิดตัวแก้ไขพื้นที่จัดเก็บข้อมูล"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "ระบบจัดเก็บข้อมูลของ Cockpit ไม่ได้ให้วลีรหัสผ่านสำหรับปลดล็อกอุปกรณ์ที่เข้ารหัสลับไว้"
 ],
 "Completed": [
  null,
  "สมบูรณ์"
 ],
 "Configuration is incomplete": [
  null,
  "การกำหนดค่าไม่สมบูรณ์"
 ],
 "Configure NTP servers": [
  null,
  "กำหนดค่าเซิร์ฟเวอร์ NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "กำหนดค่าเซิร์ฟเวอร์ NTP แบบกำหนดเอง"
 ],
 "Configure network": [
  null,
  "กำหนดค่าเครือข่าย"
 ],
 "Configure storage": [
  null,
  "กำหนดค่าพื้นที่จัดเก็บข้อมูล"
 ],
 "Configure storage again": [
  null,
  "กำหนดค่าพื้นที่จัดเก็บข้อมูลอีกครั้ง"
 ],
 "Confirm passphrase": [
  null,
  "ยืนยันวลีรหัสผ่าน"
 ],
 "Continue": [
  null,
  "ดำเนินการต่อไป"
 ],
 "Continue installation": [
  null,
  "ติดตั้งต่อไป"
 ],
 "Continue installation?": [
  null,
  "ติดตั้งต่อไปหรือไม่?"
 ],
 "Continue with installation": [
  null,
  "ติดตั้งต่อไป"
 ],
 "Correct these issues before continuing.": [
  null,
  "แก้ไขปัญหาเหล่านี้ก่อนดำเนินการต่อ"
 ],
 "Create Account": [
  null,
  "สร้างบัญชี"
 ],
 "Create account": [
  null,
  "สร้างบัญชี"
 ],
 "Currently installed: $0": [
  null,
  "ติดตั้งอยู่: $0"
 ],
 "Custom": [
  null,
  "กำหนดเอง"
 ],
 "Date": [
  null,
  "วันที่"
 ],
 "Date and time": [
  null,
  "วันที่และเวลา"
 ],
 "Delete partition": [
  null,
  "ลบพาร์ทิชัน"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "การลบบางพาร์ทิชันอาจทำให้ $0 ไม่สามารถบูตได้: $1"
 ],
 "Description": [
  null,
  "คำอธิบาย"
 ],
 "Destination": [
  null,
  "ปลายทาง"
 ],
 "Destination is encrypted": [
  null,
  "ปลายทางถูกเข้ารหัสลับไว้"
 ],
 "Detailed description of the issue": [
  null,
  "คำอธิบายปัญหาอย่างละเอียด"
 ],
 "Detected valid storage layout:": [
  null,
  "ตรวจพบโครงสร้างการจัดเก็บข้อมูลที่ถูกต้อง:"
 ],
 "Device": [
  null,
  "อุปกรณ์"
 ],
 "Duplicate device.": [
  null,
  "อุปกรณ์ซ้ำกัน"
 ],
 "Duplicate mount point.": [
  null,
  "จุดเมานต์ซ้ำกัน"
 ],
 "Enable root account": [
  null,
  "เปิดใช้งานบัญชี root"
 ],
 "Encrypt my data": [
  null,
  "เข้ารหัสข้อมูลของฉัน"
 ],
 "Encrypted": [
  null,
  "เข้ารหัสลับแล้ว"
 ],
 "Encryption": [
  null,
  "การเข้ารหัสลับ"
 ],
 "Enter PIN": [
  null,
  "ป้อน PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "ป้อน PIN เพื่อเข้าถึงโปรแกรมติดตั้ง"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "ป้อนคีย์ API ของ Bugzilla เพื่อสร้างรายงานบั๊ก คุณจะสามารถตรวจสอบและแก้ไขรายละเอียดของบั๊กนั้นได้ในขั้นตอนถัดไป"
 ],
 "Environment": [
  null,
  "สภาพแวดล้อม"
 ],
 "Erase data and install": [
  null,
  "ลบข้อมูลและติดตั้ง"
 ],
 "Error details": [
  null,
  "รายละเอียดข้อผิดพลาด"
 ],
 "Exit to live desktop": [
  null,
  "กลับสู่เดสก์ท็อปหลัก"
 ],
 "Extended partition": [
  null,
  "พาร์ทิชันแบบขยาย"
 ],
 "Failed to report issue": [
  null,
  "รายงานปัญหาไม่สำเร็จ"
 ],
 "Failed to save layouts": [
  null,
  "บันทึกโครงสร้างไม่สำเร็จ"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux ต้องการพื้นที่ว่างบนดิสก์อย่างน้อย $0"
 ],
 "Finalization": [
  null,
  "ขั้นตอนสุดท้าย"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "ขั้นตอนสุดท้าย: การกำหนดค่าระบบเสร็จสมบูรณ์แล้ว การดำเนินการขั้นตอนสุดท้ายของการติดตั้งอาจใช้เวลาสักครู่"
 ],
 "Find layout": [
  null,
  "ค้นหาผังแป้นพิมพ์"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "เพื่อความปลอดภัยที่ดียิ่งขึ้น ควรหลีกเลี่ยงการใช้บัญชี root โดยตรง แต่ให้ใช้บัญชีท้องถิ่นด้านบนในการจัดการระบบแทน"
 ],
 "Full name": [
  null,
  "ชื่อเต็ม"
 ],
 "Full name cannot contain colon characters": [
  null,
  "ชื่อเต็มไม่สามารถมีเครื่องหมายทวิภาคได้"
 ],
 "Helper text": [
  null,
  "ข้อความช่วยเหลือ"
 ],
 "Hide API key": [
  null,
  "ซ่อนคีย์ API"
 ],
 "Hide PIN": [
  null,
  "ซ่อน PIN"
 ],
 "Hide confirmed password": [
  null,
  "ซ่อนรหัสผ่านที่ยืนยัน"
 ],
 "Hide passphrase": [
  null,
  "ซ่อนวลีรหัสผ่าน"
 ],
 "Hide password": [
  null,
  "ซ่อนรหัสผ่าน"
 ],
 "Hostname": [
  null,
  "ชื่อโฮสต์"
 ],
 "How would you like to install?": [
  null,
  "คุณต้องการติดตั้งอย่างไร?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "ฉันเข้าใจว่าข้อมูลที่มีอยู่ทั้งหมดจะถูกลบออกจากดิสก์ที่เลือก"
 ],
 "I understand that some existing data will be erased": [
  null,
  "ฉันเข้าใจว่าข้อมูลที่มีอยู่บางส่วนจะถูกลบออก"
 ],
 "I understand that some partitions will be modified": [
  null,
  "ฉันเข้าใจว่าพาร์ทิชันบางส่วนจะถูกแก้ไข"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "ถ้าเว้นว่างไว้ ชื่อโฮสต์จะเป็นแบบชั่วคราวและจะถูกตั้งค่าโดยข้อมูลจากเครือข่าย"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "ถ้าไม่มีตัวเลือกใดด้านบนที่สามารถใช้ได้ ให้ใช้ตัวแก้ไขพื้นที่จัดเก็บข้อมูลเพื่อสร้างการแบ่งพาร์ทิชันแบบกำหนดเองก่อนดำเนินการต่อ"
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "ถ้าคุณกำลังกำหนดค่าพาร์ทิชัน จำเป็นต้องมีสิ่งต่อไปนี้:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "ถ้าคุณไม่ยินยอมที่จะอัปโหลดไฟล์ปูมโดยอัตโนมัติ คุณสามารถ $0 แทนได้ การรายงานด้วยตนเองจะช่วยให้คุณสามารถตรวจสอบและเลือกแนบไฟล์ปูมได้ด้วยตัวเอง"
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "ถ้าคุณไม่เข้าใจหรือยอมรับความเสี่ยง โปรดออกจากโปรแกรมนี้"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "ถ้าปัญหาของคุณตรงกับบั๊กใดบั๊กหนึ่งข้างต้น คุณสามารถเปิดรายงานนั้นแล้วเพิ่มข้อมูลของคุณเข้าไปได้เลย แทนที่จะสร้างรายงานซ้ำซ้อน"
 ],
 "In progress": [
  null,
  "กำลังดำเนินการ"
 ],
 "Initializing...": [
  null,
  "กำลังเริ่มต้น..."
 ],
 "Install": [
  null,
  "ติดตั้ง"
 ],
 "Installation failed": [
  null,
  "การติดตั้งล้มเหลว"
 ],
 "Installation method": [
  null,
  "วิธีการติดตั้ง"
 ],
 "Installation of the system failed": [
  null,
  "การติดตั้งระบบล้มเหลว"
 ],
 "Installation of the system failed: $0": [
  null,
  "การติดตั้งระบบล้มเหลว: $0"
 ],
 "Installation type": [
  null,
  "ประเภทการติดตั้ง"
 ],
 "Installing": [
  null,
  "กำลังติดตั้ง"
 ],
 "Insufficient disk space": [
  null,
  "พื้นที่ดิสก์ไม่เพียงพอ"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "PIN ไม่ถูกต้อง โปรดลองอีกครั้ง"
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "ตรวจพบการกำหนดค่า RAID ไม่ถูกต้อง ถ้าสร้างอาร์เรย์ RAID ของคุณทับบนดิสก์โดยตรง จะต้องสร้างตารางพาร์ทิชันบนอาร์เรย์นั้น ถ้าสร้างอาร์เรย์ RAID ของคุณทับบนพาร์ทิชัน อาร์เรย์นั้นจะต้องมีระบบไฟล์หรือรูปแบบเดี่ยว (เช่น LVM PV) พาร์ทิชันที่มีอยู่แล้วทั้งหมดบนอาร์เรย์นี้จะถูกละเว้น"
 ],
 "Invalid hostname": [
  null,
  "ชื่อโฮสต์ไม่ถูกต้อง"
 ],
 "Jump to first incomplete step": [
  null,
  "ข้ามไปยังขั้นตอนแรกที่ไม่เสร็จสมบูรณ์"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "คงโครงสร้างดิสก์ปัจจุบันเอาไว้ และใช้พื้นที่ว่างที่เหลืออยู่ เพื่อติดตั้งระบบปฏิบัติการอื่นร่วมกัน"
 ],
 "Keyboard": [
  null,
  "แป้นพิมพ์"
 ],
 "Keyboard layout during boot": [
  null,
  "ผังแป้นพิมพ์ระหว่างการบูต"
 ],
 "Language": [
  null,
  "ภาษา"
 ],
 "Launch storage editor": [
  null,
  "เปิดเครื่องมือแก้ไขพื้นที่จัดเก็บข้อมูล"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "เรียนรู้เพิ่มเติมเกี่ยวกับการจำกัดสิทธิ์เข้าถึงในการกำหนดค่า"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "ปล่อยให้ช่องวลีรหัสผ่านทั้งสองช่องว่างไว้ ถ้าต้องการใช้รหัสผ่านแบบว่าง"
 ],
 "Location": [
  null,
  "ตำแหน่ง"
 ],
 "Locked devices": [
  null,
  "อุปกรณ์ที่ถูกล็อก"
 ],
 "Log in": [
  null,
  "เข้าสู่ระบบ"
 ],
 "Make current": [
  null,
  "ทำให้เป็นปัจจุบัน"
 ],
 "Manual disk configuration": [
  null,
  "การกำหนดค่าดิสก์ด้วยตนเอง"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "การกำหนดค่าดิสก์ด้วยตนเอง: การจับคู่จุดเมานต์"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "อาจประกอบด้วยตัวอักษร ตัวเลข และเครื่องหมายขีดกลาง"
 ],
 "May need more free space": [
  null,
  "อาจต้องการพื้นที่ว่างเพิ่มขึ้น"
 ],
 "Medium": [
  null,
  "ปานกลาง"
 ],
 "Minimum of $0 required": [
  null,
  "ต้องการขั้นต่ำ $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "การเลือกรูปแบบการฟอร์แมตระหว่างอุปกรณ์หลักและอุปกรณ์รองไม่ตรงกัน"
 ],
 "Mount point": [
  null,
  "จุดเมานต์"
 ],
 "Mount point assignment": [
  null,
  "การกำหนดจุดเมานต์"
 ],
 "Move down": [
  null,
  "เลื่อนลง"
 ],
 "Move up": [
  null,
  "เลื่อนขึ้น"
 ],
 "Must be at least $0 characters": [
  null,
  "ต้องยาวอย่างน้อย $0 ตัวอักษร"
 ],
 "My issue is different, continue": [
  null,
  "ปัญหาของฉันไม่เหมือนกัน ดำเนินการต่อ"
 ],
 "NTP Servers": [
  null,
  "เซิร์ฟเวอร์ NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "ชื่อ"
 ],
 "Needs at least $0": [
  null,
  "ต้องการอย่างน้อย $0"
 ],
 "Network": [
  null,
  "เครือข่าย"
 ],
 "Network Configuration": [
  null,
  "การกำหนดค่าเครือข่าย"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "ไม่สามารถใช้งานเครือข่ายได้ โปรดกำหนดค่าเครือข่ายที่เมนูแถบด้านบนเพื่อรายงานปัญหา"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "ไม่สามารถใช้งานเครือข่ายได้ โปรดกำหนดค่าเครือข่ายเพื่อรายงานปัญหา"
 ],
 "Network plugin failed": [
  null,
  "ปลั๊กอินเครือข่ายล้มเหลว"
 ],
 "Next": [
  null,
  "ถัดไป"
 ],
 "No devices": [
  null,
  "ไม่มีอุปกรณ์"
 ],
 "No disks available": [
  null,
  "ไม่มีดิสก์ที่ใช้ได้"
 ],
 "No disks selected": [
  null,
  "ไม่ได้เลือกดิสก์"
 ],
 "No keyboard layouts selected": [
  null,
  "ไม่ได้เลือกผังแป้นพิมพ์"
 ],
 "No layouts selected yet": [
  null,
  "ยังไม่ได้เลือกผังแป้นพิมพ์"
 ],
 "No results found": [
  null,
  "ไม่พบผลลัพธ์"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "ไม่พบตารางปุ่มพิมพ์ VConsole ที่ใช้ได้สำหรับผังแป้นพิมพ์ที่เลือก โปรดเลือกผังแป้นพิมพ์อื่น"
 ],
 "Not enough available free space": [
  null,
  "พื้นที่ว่างไม่เพียงพอ"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "พื้นที่ว่างไม่เพียงพอบนดิสก์ที่เลือก"
 ],
 "Not enough space on selected disks.": [
  null,
  "พื้นที่ว่างไม่เพียงพอบนดิสก์ที่เลือก"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "ประกาศ: นี่คือซอฟต์แวร์รุ่นก่อนเผยแพร่ ซึ่งมีวัตถุประสงค์เพื่อใช้ในการพัฒนาและทดสอบเท่านั้น ห้ามใช้ซอฟต์แวร์นี้กับการทำงานที่สำคัญหรือในสภาพแวดล้อมที่ใช้งานจริง"
 ],
 "Open Bugzilla bug entry form": [
  null,
  "เปิดแบบฟอร์มบันทึกข้อมูลบั๊กของ Bugzilla"
 ],
 "Operating system": [
  null,
  "ระบบปฏิบัติการ"
 ],
 "Options": [
  null,
  "ตัวเลือก"
 ],
 "Other keyboards": [
  null,
  "แป้นพิมพ์อื่น ๆ"
 ],
 "Partitions (advanced)": [
  null,
  "พาร์ทิชัน (ขั้นสูง)"
 ],
 "Passphrase": [
  null,
  "วลีรหัสผ่าน"
 ],
 "Passphrase did not match any locked device": [
  null,
  "วลีรหัสผ่านไม่ตรงกับอุปกรณ์ใดที่ล็อกอยู่"
 ],
 "Passphrases must match": [
  null,
  "วลีรหัสผ่านต้องตรงกัน"
 ],
 "Pending": [
  null,
  "รอค้างอยู่"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "โปรดแนบไฟล์ปูม $0 เข้ากับปัญหานี้ด้วย"
 ],
 "Please enter a PIN": [
  null,
  "โปรดป้อน PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "โปรดเลือกดิสก์อย่างน้อยหนึ่งอันเพื่อดำเนินการต่อ"
 ],
 "Pool": [
  null,
  "พูล"
 ],
 "Potential duplicate bugs found": [
  null,
  "พบบั๊กที่อาจจะซ้ำกัน"
 ],
 "Powered by Anaconda": [
  null,
  "ขับเคลื่อนโดย Anaconda"
 ],
 "Pre-release": [
  null,
  "ก่อนเผยแพร่"
 ],
 "Prefer to report manually? $0": [
  null,
  "ต้องการรายงานด้วยตนเองหรือไม่? $0"
 ],
 "Proceed with installation": [
  null,
  "ดำเนินการติดตั้งต่อไป"
 ],
 "Quit": [
  null,
  "ออก"
 ],
 "Quit installer?": [
  null,
  "ออกจากตัวติดตั้งหรือไม่?"
 ],
 "Reading information about the OS failed.": [
  null,
  "การอ่านข้อมูลเกี่ยวกับระบบปฏิบัติการล้มเหลว"
 ],
 "Reading information about the computer failed.": [
  null,
  "การอ่านข้อมูลเกี่ยวกับคอมพิวเตอร์ล้มเหลว"
 ],
 "Reading installer configuration failed.": [
  null,
  "การอ่านการกำหนดค่าโปรแกรมติดตั้งล้มเหลว"
 ],
 "Reading installer version information failed.": [
  null,
  "การอ่านข้อมูลรุ่นของโปรแกรมติดตั้งล้มเหลว"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "ชื่อโฮสต์จริงสามารถประกอบด้วยตัวอักษร ตัวเลข เครื่องหมายขีดกลาง (ต้องไม่ขึ้นต้นหรือลงท้ายด้วยเครื่องหมายนี้) และจุด เท่านั้น"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "ชื่อโฮสต์จริงต้องยาวไม่เกิน 64 ตัวอักษร"
 ],
 "Reboot": [
  null,
  "รีบูต"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "ให้รีบูตเข้าสู่ Windows เพื่อปรับขนาดพาร์ทิชันที่เข้ารหัสลับด้วย BitLocker โดยให้เหลือพื้นที่ว่างอย่างน้อย $0 สำหรับการติดตั้ง"
 ],
 "Reboot system?": [
  null,
  "รีบูตระบบหรือไม่?"
 ],
 "Reclaim additional space": [
  null,
  "กู้คืนพื้นที่เพิ่มเติม"
 ],
 "Reclaim space": [
  null,
  "กู้คืนพื้นที่"
 ],
 "Reclaim space (required)": [
  null,
  "กู้คืนพื้นที่ (ต้องการ)"
 ],
 "Recommended": [
  null,
  "แนะนำ"
 ],
 "Recommended partitions:": [
  null,
  "พาร์ทิชันที่แนะนำ:"
 ],
 "Reformat": [
  null,
  "ฟอร์แมตใหม่"
 ],
 "Reinstall Fedora": [
  null,
  "ติดตั้ง Fedora ใหม่"
 ],
 "Remove": [
  null,
  "ลบ"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "ลบพาร์ทิชันทั้งหมดบนอุปกรณ์ที่เลือก รวมถึงระบบปฏิบัติการที่มีอยู่ด้วย"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "ลบหรือปรับขนาดระบบไฟล์ที่มีอยู่เดิม เพื่อเพิ่มพื้นที่ว่างสำหรับการติดตั้ง"
 ],
 "Remove server": [
  null,
  "ลบเซิร์ฟเวอร์"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "การลบระบบไฟล์จะเป็นการลบข้อมูลทั้งหมดที่อยู่ภายในนั้นอย่างถาวร การปรับขนาดพาร์ทิชันสามารถช่วยเพิ่มพื้นที่ว่างที่ไม่ได้ใช้ได้ แต่ก็ไม่ใช่ว่าจะไม่มีความเสี่ยง โปรดตรวจสอบให้แน่ใจว่าคุณได้สำรองข้อมูลสำคัญทั้งหมดไว้แล้ว ก่อนที่จะเริ่มกู้คืนพื้นที่"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "แทนที่ระบบปัจจุบัน แต่เก็บไฟล์ต่าง ๆ ในโฟลเดอร์บ้านไว้"
 ],
 "Report Issue": [
  null,
  "รายงานปัญหา"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "รายงานปัญหาหรือให้คำติชมโดยการเปิดแบบฟอร์มบันทึกข้อมูลบั๊กของ Bugzilla $0"
 ],
 "Report issue": [
  null,
  "รายงานปัญหา"
 ],
 "Reporting issue...": [
  null,
  "กำลังรายงานปัญหา..."
 ],
 "Required": [
  null,
  "ต้องการ"
 ],
 "Requirements": [
  null,
  "ความต้องการ"
 ],
 "Rescan devices": [
  null,
  "สแกนอุปกรณ์ใหม่"
 ],
 "Rescanning of the disks failed.": [
  null,
  "การสแกนดิสก์ใหม่ล้มเหลว"
 ],
 "Resize": [
  null,
  "ปรับขนาด"
 ],
 "Resize partition": [
  null,
  "ปรับขนาดพาร์ทิชัน"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "ปรับขนาดพาร์ทิชันต่อไปนี้จาก $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "จำกัดการเข้าถึงรายงาน"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "จำกัดรายงานไว้เฉพาะกลุ่ม $0 $1"
 ],
 "Return to installation": [
  null,
  "กลับสู่การติดตั้ง"
 ],
 "Return to storage editor": [
  null,
  "กลับสู่ตัวแก้ไขพื้นที่จัดเก็บข้อมูล"
 ],
 "Review and install": [
  null,
  "ตรวจสอบและติดตั้ง"
 ],
 "Root account has been configured": [
  null,
  "กำหนดค่าบัญชี Root เรียบร้อยแล้ว"
 ],
 "Root account is enabled": [
  null,
  "เปิดใช้งานบัญชี Root แล้ว"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "เปิดใช้งานบัญชี Root แล้ว แต่ไม่ได้กำหนดค่าบัญชีผู้ใช้"
 ],
 "Root password has been set.": [
  null,
  "ตั้งค่ารหัสผ่าน Root แล้ว"
 ],
 "Save": [
  null,
  "บันทึก"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "สแกนคิวอาร์โค้ดด้วยโทรศัพท์ของคุณ หรือไปที่:"
 ],
 "Search for a language": [
  null,
  "ค้นหาภาษา"
 ],
 "Search for additional software": [
  null,
  "ค้นหาซอฟต์แวร์เพิ่มเติม"
 ],
 "Search for an environment": [
  null,
  "ค้นหาสภาพแวดล้อม"
 ],
 "Search keyboard layout": [
  null,
  "ค้นหาผังแป้นพิมพ์"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "ปกป้องข้อมูลของคุณโดยใช้การเข้ารหัสบนดิสก์ ใช้ได้เฉพาะกับพาร์ติชั่นใหม่เท่านั้น"
 ],
 "Select": [
  null,
  "เลือก"
 ],
 "Select a device": [
  null,
  "เลือกอุปกรณ์"
 ],
 "Select city": [
  null,
  "เลือกเมือง"
 ],
 "Select destination": [
  null,
  "เลือกปลายทาง"
 ],
 "Select region": [
  null,
  "เลือกภูมิภาค"
 ],
 "Selected (top = current)": [
  null,
  "เลือกแล้ว (ด้านบน = ปัจจุบัน)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "รูปแบบ '$0' ของอุปกรณ์ที่เลือกไม่สามารถฟอร์แมตใหม่ได้"
 ],
 "Send us feedback on your installation": [
  null,
  "ส่งคำติชมเกี่ยวกับการติดตั้งของคุณให้เรา"
 ],
 "Server": [
  null,
  "เซิร์ฟเวอร์"
 ],
 "Server is not reachable": [
  null,
  "เซิร์ฟเวอร์ติดต่อไม่ได้"
 ],
 "Set custom hostname": [
  null,
  "ตั้งค่าชื่อโฮสต์แบบกำหนดเอง"
 ],
 "Share disk with other operating systems": [
  null,
  "ใช้ดิสก์ร่วมกับระบบปฏิบัติการอื่น ๆ"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "ใช้ดิสก์ร่วมกับระบบปฏิบัติการอื่น ๆ: $0"
 ],
 "Show AM/PM": [
  null,
  "แสดง AM/PM"
 ],
 "Show API key": [
  null,
  "แสดงคีย์ API"
 ],
 "Show PIN": [
  null,
  "แสดง PIN"
 ],
 "Show confirmed password": [
  null,
  "แสดงรหัสผ่านที่ยืนยัน"
 ],
 "Show passphrase": [
  null,
  "แสดงวลีรหัสผ่าน"
 ],
 "Show password": [
  null,
  "แสดงรหัสผ่าน"
 ],
 "Size": [
  null,
  "ขนาด"
 ],
 "Software installation": [
  null,
  "การติดตั้งซอฟต์แวร์"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "การติดตั้งซอฟต์แวร์: การกำหนดค่าพื้นที่จัดเก็บข้อมูลเสร็จสมบูรณ์แล้ว ขณะนี้กำลังติดตั้งซอฟต์แวร์ลงในอุปกรณ์ของคุณ"
 ],
 "Software selection": [
  null,
  "การเลือกซอฟต์แวร์"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "ขั้นตอนการติดตั้งบางขั้นตอนต้องทำให้เสร็จก่อนที่คุณจะสามารถดำเนินการต่อไปได้"
 ],
 "Some required partitions are missing: $0": [
  null,
  "บางพาร์ทิชันที่ต้องการหายไป: $0"
 ],
 "Space": [
  null,
  "พื้นที่"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "พื้นที่จัดเก็บข้อมูล"
 ],
 "Storage configuration": [
  null,
  "การกำหนดค่าพื้นที่จัดเก็บข้อมูล"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "การกำหนดค่าพื้นที่จัดเก็บข้อมูล: ขณะนี้กำลังกำหนดค่าพื้นที่จัดเก็บข้อมูล"
 ],
 "Storage editor": [
  null,
  "ตัวแก้ไขพื้นที่จัดเก็บข้อมูล"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "พื้นที่จัดเก็บข้อมูลจะขึ้นอยู่กับการกำหนดค่าจาก 'แก้ไขพื้นที่จัดเก็บข้อมูล'"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "โครงสร้างการจัดเก็บข้อมูลถูกกำหนดโดยไฟล์ Kickstart คุณสามารถตรวจสอบโครงสร้างการแบ่งพาร์ทิชันที่วางแผนไว้ได้ในขั้นตอนสรุป"
 ],
 "Storage plugin failed": [
  null,
  "ปลั๊กอินพื้นที่จัดเก็บข้อมูลล้มเหลว"
 ],
 "Storage requirements not met": [
  null,
  "พื้นที่เก็บข้อมูลไม่ตรงตามข้อกำหนด"
 ],
 "Strong": [
  null,
  "ปลอดภัยมาก"
 ],
 "Successfully installed": [
  null,
  "ติดตั้งสำเร็จ"
 ],
 "Successfully unlocked $0.": [
  null,
  "ปลดล็อก $0 สำเร็จแล้ว"
 ],
 "Suggested keyboards": [
  null,
  "แป้นพิมพ์ที่แนะนำ"
 ],
 "Suggested languages": [
  null,
  "ภาษาที่แนะนำ"
 ],
 "System": [
  null,
  "ระบบ"
 ],
 "System configuration": [
  null,
  "การกำหนดค่าระบบ"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "การกำหนดค่าระบบ: การติดตั้งซอฟต์แวร์เสร็จสมบูรณ์ ขณะนี้ระบบกำลังอยู่ระหว่างกำหนดค่า"
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "การติดตั้ง Anaconda สิ้นสุดลงอย่างไม่คาดคิด"
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "บั๊กที่ยังแก้ไม่เสร็จต่อไปนี้ อาจจะเกี่ยวข้องกับปัญหาของคุณ โปรดตรวจสอบดูก่อนที่จะสร้างรายงานใหม่"
 ],
 "The following user will be created:": [
  null,
  "ผู้ใช้ต่อไปจะถูกสร้าง:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "การติดตั้งจำเป็นต้องใช้พื้นที่ดิสก์ $0 แต่ความจุของดิสก์ที่เลือกมีเพียง $1 เท่านั้น"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "โปรแกรมติดตั้งไม่สามารถดำเนินการต่อได้เนื่องจากเกิดข้อผิดพลาดร้ายแรง"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "โปรแกรมติดตั้งไม่สามารถดำเนินการต่อได้เนื่องจากเกิดข้อผิดพลาดร้ายแรง: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "วลีรหัสผ่านที่คุณระบุมีอักขระที่ไม่ใช่มาตรฐาน ASCII คุณอาจจะไม่สามารถเปลี่ยนผังแป้นพิมพ์ในขณะพิมพ์ได้"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "ผังแป้นพิมพ์เริ่มต้นที่เลือกไม่รองรับอักขระ ASCII โปรดเลือกผังที่รองรับ ASCII เป็นค่าเริ่มต้น"
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "ตัวแก้ไขพื้นที่จัดเก็บข้อมูลช่วยให้คุณสามารถปรับขนาด ลบ และสร้างพาร์ทิชันได้ อีกทั้งยังสามารถตั้งค่า LVM และฟังก์ชันอื่น ๆ ได้อีกมากมาย เครื่องมือนี้ถูกออกแบบมาเพื่อใช้เป็นโปรแกรมอรรถประโยชน์ขั้นสูง และไม่ได้มีไว้สำหรับการใช้งานในการติดตั้งทั่วไป"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "ไฟล์ปูมเหล่านี้อาจมีข้อมูลอ่อนไหว เช่น ที่อยู่ไอพี ชื่อผู้ใช้ หรือรายละเอียดอื่น ๆ ของระบบ"
 ],
 "This hostname can't be submitted": [
  null,
  "ไม่สามารถส่งชื่อโฮสต์นี้ได้"
 ],
 "This is unstable, pre-release software": [
  null,
  "นี่คือซอฟต์แวร์รุ่นก่อนเผยแพร่ที่ไม่เสถียร"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "โครงสร้างนี้จะถูกใช้สำหรับการปลดล็อกระบบของคุณในตอนบูตเครื่อง"
 ],
 "This may take a moment": [
  null,
  "ขั้นตอนนี้อาจจะใช้เวลาสักครู่"
 ],
 "This will take a few moments": [
  null,
  "ขั้นตอนนี้อาจจะใช้เวลาสักครู่"
 ],
 "Time": [
  null,
  "เวลา"
 ],
 "Timezone": [
  null,
  "เขตเวลา"
 ],
 "Title": [
  null,
  "ชื่อเรื่อง"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "ถ้าต้องการเริ่มใช้งาน $0 ให้รีบูตระบบของคุณ"
 ],
 "To continue, select the devices to install to.": [
  null,
  "เพื่อดำเนินการต่อ โปรดเลือกอุปกรณ์ที่ต้องการติดตั้ง"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "ถ้าต้องการใช้ตัวเลือกนี้ ให้ปรับขนาดหรือลบพาร์ทิชันที่มีอยู่เพื่อคืนพื้นที่ว่างอย่างน้อย $0."
 ],
 "Type": [
  null,
  "ชนิด"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "ไม่สามารถกำหนดเวลาลบ $0 ได้"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "ไม่สามารถกำหนดเวลาปรับขนาด $0 ได้"
 ],
 "Undo last action": [
  null,
  "ยกเลิกการกระทำล่าสุด"
 ],
 "Unlock": [
  null,
  "ปลดล็อก"
 ],
 "Unlock encrypted devices": [
  null,
  "ปลดล็อกอุปกรณ์ที่เข้ารหัสลับ"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "ปลดล็อกพาร์ทิชันที่เข้ารหัสลับไว้เพื่อรักษาข้อมูลเดิม และแสดงวิธีการติดตั้งเพิ่มเติม"
 ],
 "Use configured storage": [
  null,
  "ใช้พื้นที่จัดเก็บข้อมูลที่กำหนดค่าแล้ว"
 ],
 "Use entire disk": [
  null,
  "ใช้ทั้งดิสก์"
 ],
 "Use free space": [
  null,
  "ใช้พื้นที่ว่าง"
 ],
 "Use local account": [
  null,
  "ใช้บัญชีภายในเครื่อง"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "ใช้อุปกรณ์ RAID สำหรับการแบ่งพาร์ทิชันแบบอัตโนมัติ"
 ],
 "User creation": [
  null,
  "การสร้างผู้ใช้"
 ],
 "User name": [
  null,
  "ชื่อผู้ใช้"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "ชื่อผู้ใช้มีได้เพียง: ตัวอักษร a-z, ตัวเลข 0-9, เครื่องหมายขีด $0, เครื่องหมายจุด $1, เครื่องหมายขีดล่าง $2"
 ],
 "User name must not be a reserved word": [
  null,
  "ชื่อผู้ใช้ต้องไม่ใช่คำสงวน"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "ชื่อผู้ใช้ต้องสั้นกว่า 33 ตัวอักษร"
 ],
 "Validating...": [
  null,
  "กำลังตรวจสอบ..."
 ],
 "Weak": [
  null,
  "ไม่ปลอดภัย"
 ],
 "Welcome": [
  null,
  "ยินดีต้อนรับ"
 ],
 "Welcome to Fedora Linux": [
  null,
  "ยินดีต้อนรับสู่ Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "ยินดีต้อนรับ มาติดตั้ง $0 กันตอนนี้เลย"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "เมื่อคุณส่งรายงานบั๊กนี้ ไฟล์ปูมต่อไปนี้จะถูกอัปโหลดโดยอัตโนมัติ: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "พาร์ทิชัน Windows ที่มีการเข้ารหัสลับ BitLocker ไม่สามารถปรับขนาดได้"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "คุณสามารถคืนพื้นที่ว่างตรงนี้ให้เพียงพอ แล้วปล่อยให้โปรแกรมติดตั้งจัดการส่วนที่เหลือ หรือจะตั้งค่าพาร์ติชันด้วยตนเองก็ได้"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "คุณสามารถสร้างคีย์ API สำหรับบัญชี Bugzilla ของคุณได้ $0"
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "คุณต้องเปิดใช้งานบัญชี root หรือสร้างบัญชีผู้ใช้ภายในเครื่องเพื่อดำเนินการต่อ"
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "คุณต้องเชื่อมต่อกับเครือข่ายเพื่อเปิดใช้งานวันที่และเวลาแบบอัตโนมัติ"
 ],
 "Your progress will not be saved.": [
  null,
  "ความคืบหน้าของคุณจะไม่ถูกบันทึกไว้"
 ],
 "completed step": [
  null,
  "ขั้นตอนที่เสร็จสมบูรณ์แล้ว"
 ],
 "current step": [
  null,
  "ขั้นตอนปัจจุบัน"
 ],
 "delete": [
  null,
  "ลบ"
 ],
 "edit": [
  null,
  "แก้ไข"
 ],
 "encrypt": [
  null,
  "เข้ารหัสลับ"
 ],
 "encrypted": [
  null,
  "เข้ารหัสลับแล้ว"
 ],
 "extended partition": [
  null,
  "พาร์ทิชันแบบขยาย"
 ],
 "format as $0": [
  null,
  "จัดรูปแบบเป็น $0"
 ],
 "here": [
  null,
  "ที่นี่"
 ],
 "incomplete": [
  null,
  "ไม่สมบูรณ์"
 ],
 "mount": [
  null,
  "เมานต์"
 ],
 "pending step": [
  null,
  "ขั้นตอนที่รอดำเนินการ"
 ],
 "report the issue manually": [
  null,
  "รายงานปัญหาด้วยตนเอง"
 ],
 "resized from $0": [
  null,
  "ปรับขนาดจาก $0 แล้ว"
 ],
 "shrink": [
  null,
  "ย่อ"
 ],
 "shrink to $0": [
  null,
  "ย่อเป็น $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "เลิกทำ"
 ]
});
