cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "kab",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
