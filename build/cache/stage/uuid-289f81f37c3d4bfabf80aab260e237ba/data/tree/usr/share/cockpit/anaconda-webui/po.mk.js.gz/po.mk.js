cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 || n%10==1 ? 0 : 1),
  "language": "mk",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0$1"
 ],
 "$0 ($1)": [
  null,
  "$0($1)"
 ],
 "$0 error": [
  null,
  "$0 грешка",
  "$0 грешки"
 ],
 "$0 installation": [
  null,
  "$0инсталација"
 ],
 "$0 installer": [
  null,
  "$0инсталер"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 е MBR проширена партиција која содржи логички партиции. Отстранувањето на сите логички партиции автоматски ќе ја отстрани и проширената партиција."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 е потребно, но достапно е само $1."
 ],
 "$0 warning": [
  null,
  "$0 предупредување",
  "$0 предупредувања"
 ],
 "$0 will be deleted": [
  null,
  "$0 ќе биде избришано"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Фајл системот '$0' не може да биде на енкриптиран блок уред"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' мора да биде доделен на '$1'"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' мора да биде на уред форматиран како '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' мора да е на EFI системска партиција. Селектираната партиција го користи FAT фајл системот, но не е маркирана како ESP. Подесете го типот на партицијата на EFI System и вклучете го esp знаменцето."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Пронајдена е партиција '$0' на MDRAID уредот $1. Партиции за bootloader на MDRAID уреди не се поддржани."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Стандардна корисничка сметка со администраторски пристап за правење промени на ниво на систем."
 ],
 "About": [
  null,
  "За програмата"
 ],
 "Account": [
  null,
  "Сметка"
 ],
 "Actions": [
  null,
  "Акции"
 ],
 "Add another server...": [
  null,
  "Додај друг сервер..."
 ],
 "Add mount": [
  null,
  "Додај точка за монтирање"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Додатоци за вашата избрана околина"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Додатоци што не се специфични за вашата околина"
 ],
 "Additional languages": [
  null,
  "Дополнителни јазици"
 ],
 "Additional software for the selected environment": [
  null,
  "Дополнителен софтвер за избраната околина"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Сите промени направени во уредувачот за складиште стапуваат на сила веднаш."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Сите уреди што ја користат оваа лозинка ќе бидат отклучени"
 ],
 "Anaconda Web UI": [
  null,
  "Веб-интерфејс на Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Страница на проектот Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Примени го доделувањето точки за монтирање и инсталирај"
 ],
 "Applying changes...": [
  null,
  "Се применуваат промените..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Доделете партиции на точки за монтирање. Корисно за претходно конфигурирани прилагодени распореди."
 ],
 "Automatic log file upload": [
  null,
  "Автоматско прикачување на лог-датотеки"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Автоматски постави датум и време користејќи временски сервери"
 ],
 "Automatically set timezone": [
  null,
  "Автоматски постави временска зона"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Достапен слободен простор: $0. Инсталацијата бара: $1."
 ],
 "Back": [
  null,
  "Назад"
 ],
 "Base environment": [
  null,
  "Основна околина"
 ],
 "Brief description of the issue": [
  null,
  "Краток опис на проблемот"
 ],
 "Bug report details": [
  null,
  "Детали за пријава на грешка"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API клуч"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Со продолжување на користењето на овој софтвер, разбирате и ги прифаќате ризиците поврзани со пред-издаден софтвер, дека имате намера да го користите само за тестирање и развој и сте подготвени да пријавувате грешки или проблеми со цел да се подобри овој производ."
 ],
 "Cancel": [
  null,
  "Откажи"
 ],
 "Change": [
  null,
  "Промени"
 ],
 "Change destination": [
  null,
  "Промени дестинација"
 ],
 "Change hostname": [
  null,
  "Промени име на компјутерот"
 ],
 "Change partition layout": [
  null,
  "Промени распоред на партиции"
 ],
 "Change system keyboard layout": [
  null,
  "Промени распоред на системската тастатура"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Промените направени тука веднаш ќе влијаат на системот. Нема 'врати'."
 ],
 "Checking installation configuration...": [
  null,
  "Се проверува конфигурацијата за инсталација..."
 ],
 "Checking storage configuration": [
  null,
  "Се проверува конфигурацијата на складиштето"
 ],
 "Clear search": [
  null,
  "Исчисти пребарување"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Кликнете повторно на 'Следно' за да продолжите и покрај овие предупредувања."
 ],
 "Close": [
  null,
  "Затвори"
 ],
 "Close storage editor": [
  null,
  "Затвори уредувач на складиште"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit складиштето не ја обезбеди лозинката за отклучување на шифрираниот уред."
 ],
 "Completed": [
  null,
  "Завршено"
 ],
 "Configuration is incomplete": [
  null,
  "Конфигурацијата е е завршена"
 ],
 "Configure NTP servers": [
  null,
  "Конфигурирај NTP сервери"
 ],
 "Configure custom NTP servers": [
  null,
  "Конфигурирај прилагодени NTP сервери"
 ],
 "Configure network": [
  null,
  "Конфигурирај мрежа"
 ],
 "Configure storage": [
  null,
  "Конфигурирај складиште"
 ],
 "Configure storage again": [
  null,
  "Повторно конфигурирај складиште"
 ],
 "Confirm passphrase": [
  null,
  "Потврди лозинка"
 ],
 "Continue": [
  null,
  "Продолжи"
 ],
 "Continue installation": [
  null,
  "Продолжи со инсталацијата"
 ],
 "Continue with installation": [
  null,
  "Продолжи со инсталацијата"
 ],
 "Correct these issues before continuing.": [
  null,
  "Поправете ги овие проблеми пред да продолжите."
 ],
 "Create Account": [
  null,
  "Создај сметка"
 ],
 "Create account": [
  null,
  "Создај сметка"
 ],
 "Currently installed: $0": [
  null,
  "Моментално инсталирано: $0"
 ],
 "Custom": [
  null,
  "Сопствено"
 ],
 "Date": [
  null,
  "Датум"
 ],
 "Date and time": [
  null,
  "Датум и време"
 ],
 "Delete partition": [
  null,
  "Избриши партиција"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Бришењето на одредени партиции може да спречи $0 да се подигне: $1"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Destination": [
  null,
  "Одредиште"
 ],
 "Destination is encrypted": [
  null,
  "Дестинацијата е шифрирана"
 ],
 "Detailed description of the issue": [
  null,
  "Детален опис на проблемот"
 ],
 "Detected valid storage layout:": [
  null,
  "Откриен е важечки распоред на складиште:"
 ],
 "Device": [
  null,
  "Уред"
 ],
 "Duplicate device.": [
  null,
  "Дупликат уред."
 ],
 "Duplicate mount point.": [
  null,
  "Дупликат точка за монтирање."
 ],
 "Enable root account": [
  null,
  "Овозможи root сметка"
 ],
 "Encrypt my data": [
  null,
  "Шифрирај ги моите податоци"
 ],
 "Encrypted": [
  null,
  "Шифрирано"
 ],
 "Encryption": [
  null,
  "Шифрирање"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Внесете го вашиот Bugzilla API клуч за да создадете пријава за грешка. Во следниот чекор ќе можете да ги прегледате и уредите деталите за грешката."
 ],
 "Environment": [
  null,
  "Околина"
 ],
 "Erase data and install": [
  null,
  "Избриши податоци и инсталирај"
 ],
 "Error details": [
  null,
  "Детали за грешката"
 ],
 "Exit to live desktop": [
  null,
  "Излези во живата работна околина"
 ],
 "Extended partition": [
  null,
  "Проширена партиција"
 ],
 "Failed to report issue": [
  null,
  "Не успеа пријавувањето на проблемот"
 ],
 "Failed to save layouts": [
  null,
  "Не успеа зачувувањето на распоредите"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux бара најмалку $0 простор на дискот."
 ],
 "Finalization": [
  null,
  "Финализирање"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Финализирање: Конфигурацијата на системот е завршена. Финализирањето на инсталацијата може да потрае неколку моменти."
 ],
 "Find layout": [
  null,
  "Најди распоред"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "За подобра безбедност, избегнувајте директно користење на root сметката. Наместо тоа, користете ја локалната сметка погоре за управување со системот."
 ],
 "Full name": [
  null,
  "Целосно име"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Целосното име не може да содржи двоточки"
 ],
 "Helper text": [
  null,
  "Помошен текст"
 ],
 "Hide API key": [
  null,
  "Скриј API клуч"
 ],
 "Hide confirmed password": [
  null,
  "Скриј потврдена лозинка"
 ],
 "Hide passphrase": [
  null,
  "Скриј лозинка"
 ],
 "Hide password": [
  null,
  "Скриј лозинка"
 ],
 "Hostname": [
  null,
  "Име на компјутерот"
 ],
 "How would you like to install?": [
  null,
  "Како сакате да инсталирате?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Разбирам дека сите постоечки податоци ќе бидат избришани",
  "Разбирам дека сите постоечки податоци ќе бидат избришани од одбраните дискови"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Разбирам дека некои постојни податоци ќе бидат избришани"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Разбирам дека некои партиции ќе бидат изменети"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Ако е празно, името на компјутерот ќе биде привремено и поставено според мрежните информации."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Ако конфигурирате партиции, потребно е следново:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Ако не се согласувате со автоматско прикачување датотеки со дневник, можете наместо тоа да $0. Рачното пријавување ви овозможува самостојно да ги прегледате и селективно да ги прикачите датотеките со дневник."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ако не ги разбирате или не ги прифаќате ризиците, излезете од оваа програма."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Во тек"
 ],
 "Initializing...": [
  null,
  "Се иницијализира..."
 ],
 "Install": [
  null,
  "Инсталирај"
 ],
 "Installation failed": [
  null,
  "Инсталацијата не успеа"
 ],
 "Installation method": [
  null,
  "Начин на инсталација"
 ],
 "Installation of the system failed": [
  null,
  "Инсталацијата на системот не успеа"
 ],
 "Installation of the system failed: $0": [
  null,
  "Инсталацијата на системот не успеа: $0"
 ],
 "Installation type": [
  null,
  "Тип на инсталација"
 ],
 "Installing": [
  null,
  "Се инсталира"
 ],
 "Insufficient disk space": [
  null,
  "Недоволен простор на дискот"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Откриена е неважечка RAID конфигурација. Ако вашата RAID низа е создадена директно врз дискови, на низата мора да се создаде табела на партиции. Ако вашата RAID низа е создадена врз партиции, таа мора да содржи еден датотечен систем или формат (на пр., LVM PV). Сите постојни партиции на оваа низа ќе бидат игнорирани."
 ],
 "Invalid hostname": [
  null,
  "Неважечко име на копмјутерот"
 ],
 "Jump to first incomplete step": [
  null,
  "Одете на првиот не завршен чекор"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Задржи го тековниот распоред на дискот и користи го достапниот простор за двојно подигнување со друг оперативен систем."
 ],
 "Keyboard": [
  null,
  "Тастатура"
 ],
 "Keyboard layout during boot": [
  null,
  "Распоред на тастатура при подигнување"
 ],
 "Language": [
  null,
  "Јазик"
 ],
 "Launch storage editor": [
  null,
  "Стартувај уредувач на складиште"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Дознајте повеќе за ограничениот пристап во конфигурацијата"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Оставете ги двете полиња за пасворд празни за да користите празна лозинка."
 ],
 "Location": [
  null,
  "Локација"
 ],
 "Locked devices": [
  null,
  "Заклучени уреди"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  "Постави како тековно"
 ],
 "Manual disk configuration": [
  null,
  "Рачна конфигурација на диск"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Рачна конфигурација на диск: мапирање точки за монтирање"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Може да содржи букви, бројки и цртички."
 ],
 "May need more free space": [
  null,
  "Можеби е потребен повеќе слободен простор"
 ],
 "Medium": [
  null,
  "Средно"
 ],
 "Minimum of $0 required": [
  null,
  "Потребни се најмалку $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Несовпаѓање меѓу изборот за преформатирање на родителскиот и подредениот уред."
 ],
 "Mount point": [
  null,
  "Точка за монтирање"
 ],
 "Mount point assignment": [
  null,
  "Доделување точка за монтирање"
 ],
 "Move down": [
  null,
  "Премести надолу"
 ],
 "Move up": [
  null,
  "Премести нагоре"
 ],
 "Must be at least $0 characters": [
  null,
  "Мора да има најмалку $0 знаци"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP сервери"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Име"
 ],
 "Needs at least $0": [
  null,
  "Потребни се најмалку $0"
 ],
 "Network": [
  null,
  "Мрежа"
 ],
 "Network Configuration": [
  null,
  "Мрежна конфигурација"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Мрежата не е достапна. Конфигурирајте ја мрежата во менито на горната лента за да го пријавите проблемот."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Мрежата не е достапна. Конфигурирајте ја мрежата за да го пријавите проблемот."
 ],
 "Network plugin failed": [
  null,
  "Мрежниот приклучок не успеа"
 ],
 "Next": [
  null,
  "Следно"
 ],
 "No devices": [
  null,
  "Нема уреди"
 ],
 "No disks available": [
  null,
  "Нема достапни дискови"
 ],
 "No disks selected": [
  null,
  "Нема избрани дискови"
 ],
 "No layouts selected yet": [
  null,
  "Сè уште нема избрани распореди"
 ],
 "No results found": [
  null,
  "Не се пронајдени резултати"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Не може да се добие важечка VConsole мапа на тастатура за избраниот распоред или распореди. Изберете друг распоред на тастатура."
 ],
 "Not enough available free space": [
  null,
  "Нема доволно достапен слободен простор"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Нема доволно слободен простор на избраните дискови."
 ],
 "Not enough space on selected disks.": [
  null,
  "Нема доволно простор на избраните дискови."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Напомена: Ова е софтвер пред издание наменет само за развој и тестирање. НЕ го користете овој софтвер за критична работа или за продукциски околини."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Отвори формулар за внесување грешка во Bugzilla"
 ],
 "Operating system": [
  null,
  "Оперативен систем"
 ],
 "Options": [
  null,
  "Опции"
 ],
 "Other keyboards": [
  null,
  "Други тастатури"
 ],
 "Partitions (advanced)": [
  null,
  "Партиции (напредно)"
 ],
 "Passphrase": [
  null,
  "Лозинка"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Лозинката не одговара на ниту еден заклучен уред"
 ],
 "Passphrases must match": [
  null,
  "Лозинките мора да се совпаѓаат"
 ],
 "Pending": [
  null,
  "На чекање"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Прикачете ја датотеката со дневник $0 кон проблемот."
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "Изберете најмалку еден диск за да продолжите"
 ],
 "Pool": [
  null,
  "Пул"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Овозможено од Anaconda"
 ],
 "Pre-release": [
  null,
  "Пред издание"
 ],
 "Prefer to report manually? $0": [
  null,
  "Претпочитате рачно пријавување? $0"
 ],
 "Proceed with installation": [
  null,
  "Продолжи со инсталацијата"
 ],
 "Quit": [
  null,
  "Напушти"
 ],
 "Quit installer?": [
  null,
  "Да се напушти инсталаторот?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Не успеа читањето информации за оперативниот систем."
 ],
 "Reading information about the computer failed.": [
  null,
  "Не успеа читањето информации за компјутерот."
 ],
 "Reading installer configuration failed.": [
  null,
  "Не успеа читањето на конфигурацијата на инсталаторот."
 ],
 "Reading installer version information failed.": [
  null,
  "Не успеа читањето информации за верзијата на инсталаторот."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Вистинското име на компјутерот може да содржи само букви, цифри, цртички (не на почеток или крај) и точки"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Вистинското име на компјутерот мора да има 64 знаци или помалку"
 ],
 "Reboot": [
  null,
  "Рестартирај"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Рестартирајте во Windows за да ја промените големината на партициите шифрирани со BitLocker. Ослободете најмалку $0 слободен простор за инсталацијата."
 ],
 "Reboot system?": [
  null,
  "Да се рестартира системот?"
 ],
 "Reclaim additional space": [
  null,
  "Ослободи дополнителен простор"
 ],
 "Reclaim space": [
  null,
  "Ослободи простор"
 ],
 "Reclaim space (required)": [
  null,
  "Ослободи простор (потребно)"
 ],
 "Recommended": [
  null,
  "Препорачано"
 ],
 "Recommended partitions:": [
  null,
  "Препорачани партиции:"
 ],
 "Reformat": [
  null,
  "Преформатирај"
 ],
 "Reinstall Fedora": [
  null,
  "Преинсталирај Fedora"
 ],
 "Remove": [
  null,
  "Отстрани"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Отстрани ги сите партиции на избраните уреди, вклучувајќи ги и постојните оперативни системи."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Отстранете или променете ја големината на постојните датотечни системи за да ослободите простор за инсталацијата."
 ],
 "Remove server": [
  null,
  "Отстрани сервер"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Отстранувањето на датотечен систем трајно ќе ги избрише сите податоци што ги содржи. Промената на големината на партиција може да ослободи неискористен простор, но не е без ризик. Осигурете се дека имате резервни копии од сè што е важно пред да ослободувате простор."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Замени ја тековната инсталација, но задржи ги датотеките во home."
 ],
 "Report Issue": [
  null,
  "Пријави проблем"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Пријавете проблем или испратете повратни информации со отворање на формуларот за внесување грешка во Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Пријави проблем"
 ],
 "Reporting issue...": [
  null,
  "Се пријавува проблем..."
 ],
 "Required": [
  null,
  "Потребно"
 ],
 "Requirements": [
  null,
  "Барања"
 ],
 "Rescan devices": [
  null,
  "Повторно скенирај уреди"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Повторното скенирање на дисковите не успеа."
 ],
 "Resize": [
  null,
  "Промени големина"
 ],
 "Resize partition": [
  null,
  "Промени големина на партиција"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Се менува големината на следните партиции од $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Ограничи пристап до извештајот"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Го ограничува извештајот на групата $0. $1"
 ],
 "Return to installation": [
  null,
  "Врати се на инсталацијата"
 ],
 "Return to storage editor": [
  null,
  "Врати се во уредувачот на складиште"
 ],
 "Review and install": [
  null,
  "Прегледај и инсталирај"
 ],
 "Root account is enabled": [
  null,
  "Root сметката е овозможена"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root сметката е овозможена, но нема конфигурирана корисничка сметка"
 ],
 "Root password has been set.": [
  null,
  "Root лозинката е поставена."
 ],
 "Save": [
  null,
  "Зачувај"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Скенирајте го QR кодот со телефонот или посетете:"
 ],
 "Search for a language": [
  null,
  "Пребарај јазик"
 ],
 "Search for additional software": [
  null,
  "Пребарај дополнителен софтвер"
 ],
 "Search for an environment": [
  null,
  "Пребарај околина"
 ],
 "Search keyboard layout": [
  null,
  "Пребарај распоред на тастатура"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Заштитете ги податоците со шифрирање базирано на диск. Важи само за нови партиции"
 ],
 "Select": [
  null,
  "Избери"
 ],
 "Select a device": [
  null,
  "Избери уред"
 ],
 "Select city": [
  null,
  "Избери град"
 ],
 "Select destination": [
  null,
  "Избери дестинација"
 ],
 "Select region": [
  null,
  "Избери регион"
 ],
 "Selected (top = current)": [
  null,
  "Избрано (горе = тековно)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Форматот '$0' на избраниот уред не може да се преформатира."
 ],
 "Send us feedback on your installation": [
  null,
  "Испратете ни повратни информации за вашата инсталација"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server is not reachable": [
  null,
  "Серверот не е достапен"
 ],
 "Set custom hostname": [
  null,
  "Постави прилагодено име на компјутерот"
 ],
 "Share disk with other operating systems": [
  null,
  "Сподели диск со други оперативни системи"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Сподели диск со други оперативни системи: $0"
 ],
 "Show AM/PM": [
  null,
  "Прикажи AM/PM"
 ],
 "Show API key": [
  null,
  "Прикажи API клуч"
 ],
 "Show confirmed password": [
  null,
  "Прикажи потврдена лозинка"
 ],
 "Show passphrase": [
  null,
  "Прикажи лозинка"
 ],
 "Show password": [
  null,
  "Прикажи лозинка"
 ],
 "Size": [
  null,
  "Големина"
 ],
 "Software installation": [
  null,
  "Инсталација на софтвер"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Инсталација на софтвер: Конфигурацијата на складиштето е завршена. Софтверот сега се инсталира на вашиот уред."
 ],
 "Software selection": [
  null,
  "Избор на софтвер"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Некои чекори од инсталација мора да бидат завршени пред да можете да продолжите."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Недостасуваат некои потребни партиции: $0"
 ],
 "Space": [
  null,
  "Простор"
 ],
 "Stacktrace": [
  null,
  "Трага на стекот"
 ],
 "Storage": [
  null,
  "Складиште"
 ],
 "Storage configuration": [
  null,
  "Конфигурација на складиште"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Конфигурација на складиште: складиштето моментално се конфигурира."
 ],
 "Storage editor": [
  null,
  "Уредувач на складиште"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Складиштето се базира на конфигурацијата од 'Измени складиште'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Распоредот на складиштето е дефиниран со kickstart датотеката. Планираниот распоред на партиционирање може да се прегледа во чекорот за резиме."
 ],
 "Storage plugin failed": [
  null,
  "Приклучокот за складиште не успеа"
 ],
 "Storage requirements not met": [
  null,
  "Барањата за складиште не се исполнети"
 ],
 "Strong": [
  null,
  "Силна"
 ],
 "Successfully installed": [
  null,
  "Успешно инсталирано"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 е успешно отклучено."
 ],
 "Suggested keyboards": [
  null,
  "Предложени тастатури"
 ],
 "Suggested languages": [
  null,
  "Предложени јазици"
 ],
 "System": [
  null,
  "Систем"
 ],
 "System configuration": [
  null,
  "Конфигурација на системот"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Конфигурација на системот: Инсталацијата на софтверот е завршена. Системот сега се конфигурира."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Инсталацијата на Anaconda неочекувано запре."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Следниот корисник ќе биде креиран:",
  "Следните корисници ќе бидат креирани:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Инсталацијата бара $0 простор на дискот; сепак, капацитетот на избраните дискови е само $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Инсталаторот не може да продолжи поради критична грешка."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Инсталаторот не може да продолжи поради критична грешка: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Лозинката што ја внесовте содржи не-ASCII знаци. Можеби нема да можете да менувате распоред на тастатура додека ја внесувате."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Избраниот стандарден распоред на тастатура не поддржува ASCII знаци. Изберете распоред што поддржува ASCII како стандарден."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Уредувачот на складиште ви овозможува да менувате големина, бришете и создавате партиции. Може да постави LVM и многу повеќе. Наменет е како напредна алатка и не е предвиден за користење во типична инсталација."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Овие датотеки со дневник може да содржат чувствителни информации како IP адреси, кориснички имиња или други системски детали."
 ],
 "This hostname can't be submitted": [
  null,
  "Ова име на компјутерот не може да се поднесе"
 ],
 "This is unstable, pre-release software": [
  null,
  "Ова е нестабилен софтвер пред издание"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Овој распоред ќе се користи за отклучување на системот при подигнување"
 ],
 "This may take a moment": [
  null,
  "Ова може да потрае момент"
 ],
 "This will take a few moments": [
  null,
  "Ова ќе потрае неколку моменти"
 ],
 "Time": [
  null,
  "Време"
 ],
 "Timezone": [
  null,
  "Временска зона"
 ],
 "Title": [
  null,
  "Наслов"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "За да започнете да го користите $0, рестартирајте го системот."
 ],
 "To continue, select the devices to install to.": [
  null,
  "За да продолжите, изберете ги уредите на кои ќе се инсталира."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "За да ја користите оваа опција, променете ја големината или отстранете постојни партиции за да ослободите најмалку $0."
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Не може да се закаже бришење на $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Не може да се закаже промена на големината на $0"
 ],
 "Undo last action": [
  null,
  "Поништи предходна акција"
 ],
 "Unlock": [
  null,
  "Отклучи"
 ],
 "Unlock encrypted devices": [
  null,
  "Отклучи шифрирани уреди"
 ],
 "Use configured storage": [
  null,
  "Користи конфигурирано складиште"
 ],
 "Use entire disk": [
  null,
  "Користи го целиот диск"
 ],
 "Use free space": [
  null,
  "Користи слободен простор"
 ],
 "Use local account": [
  null,
  "Користи локална сметка"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Користи го RAID уредот за автоматско партиционирање"
 ],
 "User creation": [
  null,
  "Создавање корисник"
 ],
 "User name": [
  null,
  "Корисничко име"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Корисничкото име може да содржи само: букви од a-z, цифри 0-9, цртичка $0, точка $1, долна црта $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Корисничкото име не смее да биде резервиран збор"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Корисничките имиња мора да бидат пократки од 33 знаци"
 ],
 "Validating...": [
  null,
  "Се проверува..."
 ],
 "Weak": [
  null,
  "Слаба"
 ],
 "Welcome": [
  null,
  "Добредојдовте"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Добредојдовте во Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Добредојдовте. Да го инсталираме $0 сега."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Кога ќе ја поднесете оваа пријава за грешка, следните датотеки со дневник ќе се прикачат автоматски: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Windows партициите со BitLocker шифрирање не може да се менуваат по големина"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Можете да ослободите доволно простор тука и да му дозволите на инсталаторот да се погрижи за останатото, или рачно да поставите партиции."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Можете да го генерирате API клучот за вашата Bugzilla сметка $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Мора да ја овозможите root сметката или да создадете локална корисничка сметка за да продолжите."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Мора да бидете поврзани на мрежа за да овозможите автоматски датум и време."
 ],
 "Your progress will not be saved.": [
  null,
  "Вашиот напредок нема да биде зачуван."
 ],
 "completed step": [
  null,
  "завршен чекор"
 ],
 "current step": [
  null,
  "тековен чекор"
 ],
 "delete": [
  null,
  "избриши"
 ],
 "edit": [
  null,
  "уреди"
 ],
 "encrypt": [
  null,
  "шифрирај"
 ],
 "encrypted": [
  null,
  "шифрирано"
 ],
 "extended partition": [
  null,
  "проширена партиција"
 ],
 "format as $0": [
  null,
  "форматирај како $0"
 ],
 "here": [
  null,
  "тука"
 ],
 "incomplete": [
  null,
  "незавршено"
 ],
 "mount": [
  null,
  "монтирај"
 ],
 "pending step": [
  null,
  "чекор на чекање"
 ],
 "report the issue manually": [
  null,
  "пријавете го проблемот рачно"
 ],
 "resized from $0": [
  null,
  "со променета големина од $0"
 ],
 "shrink": [
  null,
  "намали"
 ],
 "shrink to $0": [
  null,
  "намали на $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "врати"
 ]
});
