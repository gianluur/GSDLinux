cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit ファイル"
 ],
 "Home": [
  null,
  "ホーム"
 ],
 "Unable to create bookmark directory": [
  null,
  "ブックマークディレクトリーを作成できません"
 ],
 "Unable to save bookmark file": [
  null,
  "ブックマークファイルを保存できません"
 ],
 "Remove from bookmarks": [
  null,
  "ブックマークから削除"
 ],
 "Add to bookmarks": [
  null,
  "ブックマークに追加"
 ],
 "Bookmarks": [
  null,
  "ブックマーク"
 ],
 "Filesystem": [
  null,
  "ファイルシステム"
 ],
 "Edit path": [
  null,
  "パスの編集"
 ],
 "Name": [
  null,
  "名前"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Largest size": [
  null,
  "最大サイズ"
 ],
 "Smallest size": [
  null,
  "最小サイズ"
 ],
 "Modified": [
  null,
  "変更"
 ],
 "First modified": [
  null,
  "最初に変更"
 ],
 "Last modified": [
  null,
  "最後に変更"
 ],
 "Owner": [
  null,
  "所有者"
 ],
 "Owner ascending": [
  null,
  "所有者昇順"
 ],
 "Owner descending": [
  null,
  "所有者降順"
 ],
 "Permissions": [
  null,
  "パーミッション"
 ],
 "Most permissive": [
  null,
  "最も許容度が高い"
 ],
 "Least permissive": [
  null,
  "最も許容度が低い"
 ],
 "Show keyboard shortcuts": [
  null,
  "キーボードショートカットの表示"
 ],
 "Filter directory": [
  null,
  "ディレクトリーの絞り込み"
 ],
 "Display as a list": [
  null,
  "リスト形式で表示"
 ],
 "Display as a grid": [
  null,
  "グリッド形式で表示"
 ],
 "Sort": [
  null,
  "ソート"
 ],
 "Hide hidden items": [
  null,
  "非表示の項目を非表示にする"
 ],
 "Show hidden items": [
  null,
  "非表示の項目を表示する"
 ],
 "$0 files": [
  null,
  "$0 個のファイル"
 ],
 "Uploaded as $0, $1": [
  null,
  "$0、$1 としてアップロードしました"
 ],
 "Replace file $0?": [
  null,
  "ファイル $0 を置き換えますか?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "\"$0\" に同じ名前のファイルがすでに存在します。このファイルを置き換えると内容が上書きされます。"
 ],
 "New file": [
  null,
  "新しいファイル"
 ],
 "Original file on server": [
  null,
  "サーバー上の元のファイル"
 ],
 "Apply this action to all conflicting files": [
  null,
  "このアクションをすべての競合ファイルに適用する"
 ],
 "Replace": [
  null,
  "置き換え"
 ],
 "Keep original": [
  null,
  "元のものを維持"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Upload error": [
  null,
  "アップロードエラー"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "アップロードしたファイルを最終移動先に移動できません"
 ],
 "Cancelled": [
  null,
  "キャンセル済み"
 ],
 "Cancelled upload of $0": [
  null,
  "$0 のアップロードをキャンセルしました"
 ],
 "File uploaded": [
  null,
  "ファイルをアップロードしました"
 ],
 "Files uploaded": [
  null,
  "アップロードされたファイル"
 ],
 "Change permissions": [
  null,
  "パーミッションの変更"
 ],
 "Uploads": [
  null,
  "アップロード"
 ],
 "Cancel upload of $0": [
  null,
  "$0 のアップロードをキャンセルする"
 ],
 "Upload $0% completed": [
  null,
  "アップロード $0% 完了"
 ],
 "Upload": [
  null,
  "アップロード"
 ],
 "None": [
  null,
  "なし"
 ],
 "Execute-only": [
  null,
  "実行のみ"
 ],
 "Write-only": [
  null,
  "書き込み専用"
 ],
 "Write and execute": [
  null,
  "書き込みおよび実行"
 ],
 "Read-only": [
  null,
  "読み取り専用"
 ],
 "Read and execute": [
  null,
  "読み取りおよび実行"
 ],
 "Read and write": [
  null,
  "読み取りおよび書き込み"
 ],
 "Read, write, and execute": [
  null,
  "読み取り、書き込み、および実行"
 ],
 "Block device": [
  null,
  "ブロックデバイス"
 ],
 "Character device": [
  null,
  "キャラクターデバイス"
 ],
 "Directory": [
  null,
  "フォルダー"
 ],
 "Named pipe": [
  null,
  "名前付きパイプ"
 ],
 "Symbolic link": [
  null,
  "シンボリックリンク"
 ],
 "Regular file": [
  null,
  "通常ファイル"
 ],
 "Socket": [
  null,
  "ソケット"
 ],
 "Name cannot be empty": [
  null,
  "名前は空欄にできません"
 ],
 "Name too long": [
  null,
  "名前が長すぎます"
 ],
 "Name cannot include a /": [
  null,
  "名前に / を含めることはできません"
 ],
 "Filename is the same as original name": [
  null,
  "ファイル名が元の名前と同じです"
 ],
 "Directory with the same name exists": [
  null,
  "同じ名前のディレクトリーが存在します"
 ],
 "File exists": [
  null,
  "ファイルが存在します"
 ],
 "Pasting failed": [
  null,
  "貼り付けに失敗しました"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" は存在するため、貼り付けで上書きされません。"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Create directory": [
  null,
  "ディレクトリーの作成"
 ],
 "Create file": [
  null,
  "ファイルの作成"
 ],
 "Edit permissions": [
  null,
  "編集パーミッション"
 ],
 "Open in terminal": [
  null,
  "ターミナルで開く"
 ],
 "Open text file": [
  null,
  "テキストファイルを開く"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Download": [
  null,
  "ダウンロード"
 ],
 "Create link": [
  null,
  "リンクの作成"
 ],
 "Drop files to upload": [
  null,
  "アップロードするファイルをドロップする"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "ファイルをドロップできません。別のアップロードがすでに進行中です"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Go up a directory": [
  null,
  "1 つ上のディレクトリーに移動する"
 ],
 "Go back": [
  null,
  "戻る"
 ],
 "Go forward": [
  null,
  "進む"
 ],
 "Activate selected item, enter directory": [
  null,
  "選択した項目をアクティブにしてディレクトリーに入る"
 ],
 "Rename selected file or directory": [
  null,
  "選択したファイルまたはディレクトリーの名前を変更する"
 ],
 "Create new directory": [
  null,
  "新しいディレクトリーの作成"
 ],
 "Copy selected file or directory": [
  null,
  "選択したファイルまたはディレクトリーをコピーする"
 ],
 "Paste file or directory": [
  null,
  "ファイルまたはディレクトリーを貼り付ける"
 ],
 "Select all": [
  null,
  "すべて選択"
 ],
 "Save current file": [
  null,
  ""
 ],
 "Close editor": [
  null,
  ""
 ],
 "Keyboard shortcuts": [
  null,
  "キーボードショートカット"
 ],
 "Navigation": [
  null,
  "ナビゲーション"
 ],
 "Editing": [
  null,
  "編集中"
 ],
 "Force delete $0 items": [
  null,
  "$0 個の項目を強制的に削除"
 ],
 "Delete $0 items?": [
  null,
  "$0 個の項目を削除しますか?"
 ],
 "Force delete file $0?": [
  null,
  "ファイル $0 を強制的に削除しますか?"
 ],
 "Delete file $0?": [
  null,
  "ファイル $0 を削除しますか?"
 ],
 "Force delete link $0?": [
  null,
  "リンク $0 を強制的に削除しますか?"
 ],
 "Delete link $0?": [
  null,
  "リンク $0 を削除しますか?"
 ],
 "Force delete directory $0?": [
  null,
  "ディレクトリー $0 を強制的に削除しますか?"
 ],
 "Delete directory $0?": [
  null,
  "ディレクトリー $0 を削除しますか?"
 ],
 "Force delete $0": [
  null,
  "$0 を強制的に削除"
 ],
 "Delete $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "No access": [
  null,
  "アクセスなし"
 ],
 "Missing type": [
  null,
  "存在しないタイプ"
 ],
 "Collapse": [
  null,
  "折りたたむ"
 ],
 "Show all files": [
  null,
  "すべてのファイルの表示"
 ],
 "$0 permissions": [
  null,
  "$0 個のパーミッション"
 ],
 "Permissions for $0 files": [
  null,
  "$0 ファイルのパーミッション"
 ],
 "Ownership": [
  null,
  "所有権"
 ],
 "Group": [
  null,
  "グループ"
 ],
 "Access": [
  null,
  "アクセス"
 ],
 "Owner access": [
  null,
  "所有者アクセス"
 ],
 "Group access": [
  null,
  "グループアクセス"
 ],
 "Others access": [
  null,
  "その他のユーザーのアクセス"
 ],
 "Security context": [
  null,
  "セキュリティーコンテキスト"
 ],
 "Set executable as program": [
  null,
  "実行可能ファイルをプログラムとして設定"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change permissions for enclosed files": [
  null,
  "含まれるファイルのパーミッションの変更"
 ],
 "(original owner)": [
  null,
  "(元の所有者)"
 ],
 "keep original owners": [
  null,
  "元の所有者を維持"
 ],
 "Paste as owner": [
  null,
  "所有者として貼り付け"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "貼り付けるファイルの所有者が異なります。デフォルトでは、貼り付け先のディレクトリーに合わせて所有権が変更されます。"
 ],
 "New owner": [
  null,
  "新しい所有者"
 ],
 "Overwrite": [
  null,
  "上書き"
 ],
 "New filename": [
  null,
  "新しいファイル名"
 ],
 "New name": [
  null,
  "新しい名前"
 ],
 "Rename $0?": [
  null,
  "$0 の名前を変更しますか?"
 ],
 "link to $0": [
  null,
  ""
 ],
 "Target": [
  null,
  ""
 ],
 "Symlink name": [
  null,
  ""
 ],
 "Type": [
  null,
  ""
 ],
 "Absolute vs. Relative": [
  null,
  "絶対パスと相対パス"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "絶対パスシンボリックリンクはシステムファイルなど移動しないファイルやディレクトリに適しています。"
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  ""
 ],
 "Absolute": [
  null,
  ""
 ],
 "Relative": [
  null,
  ""
 ],
 "The file has been removed on disk": [
  null,
  "ファイルがディスクから削除されました"
 ],
 "The existing file changed unexpectedly": [
  null,
  "既存のファイルが予期せず変更されました"
 ],
 "Edit $0": [
  null,
  "$0 の編集"
 ],
 "View $0": [
  null,
  "$0 の表示"
 ],
 "The file has changed on disk": [
  null,
  "ファイルがディスク上で変更されました"
 ],
 "Reload": [
  null,
  "再ロード"
 ],
 "Ignore": [
  null,
  "無視"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save changes?": [
  null,
  ""
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  ""
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  ""
 ],
 "Discard": [
  null,
  ""
 ],
 "File name": [
  null,
  "ファイル名"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Cannot create file in current directory": [
  null,
  "カレントディレクトリーにファイルを作成できません"
 ],
 "Permission denied": [
  null,
  "パーミッションが拒否されました"
 ],
 "Directory name cannot be empty": [
  null,
  "ディレクトリー名は空にできません"
 ],
 "Directory name too long": [
  null,
  "ディレクトリー名が長すぎます"
 ],
 "Directory name cannot include a /": [
  null,
  "ディレクトリー名に / を含めることはできません"
 ],
 "Directory name": [
  null,
  "ディレクトリー名"
 ],
 "Directory owner": [
  null,
  "ディレクトリー所有者"
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "Clear filter": [
  null,
  "フィルターを外す"
 ],
 "Directory is empty": [
  null,
  "ディレクトリーは空です"
 ],
 "$0 item is hidden": [
  null,
  "$0 個の項目が非表示"
 ],
 "Folder": [
  null,
  ""
 ],
 "Others": [
  null,
  "その他のユーザー"
 ],
 "$0 files selected": [
  null,
  "$0 個のファイルを選択中"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "ディレクトリーに $0 個のディレクトリー、$1 個のファイルが含まれています"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "ディレクトリーに $0 個のディレクトリー、$1 個のファイルが含まれ、$2 個が非表示です"
 ],
 "User": [
  null,
  "ユーザー"
 ]
});
