cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "unmount": [
  null,
  "Démonter"
 ],
 "mount": [
  null,
  "monter"
 ],
 "format": [
  null,
  "formater"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "système de fichiers"
 ],
 "partition": [
  null,
  "partition"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volume"
 ],
 "disk": [
  null,
  "disque"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "disque"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "chiffrement"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Gestion des partitions"
 ],
 "Managing NFS mounts": [
  null,
  "Gérer les montages NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestion des RAID"
 ],
 "Managing LVMs": [
  null,
  "Gestion des LVM"
 ],
 "Managing physical drives": [
  null,
  "Gestion des lecteurs physiques"
 ],
 "Managing VDOs": [
  null,
  "Gestion des ODV"
 ],
 "Using LUKS encryption": [
  null,
  "Utilisation du chiffrement LUKS"
 ],
 "Using Tang server": [
  null,
  "Utilisation du serveur Tang"
 ]
});
