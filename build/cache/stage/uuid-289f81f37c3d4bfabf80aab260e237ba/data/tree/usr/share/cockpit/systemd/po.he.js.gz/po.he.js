cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Journal": [
  null,
  "ז׳ורנל"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "Hardware information": [
  null,
  "פרטי חומרה"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "Default": [
  null,
  "בררת מחדל"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "Permission denied": [
  null,
  "ההרשאה נדחתה"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit דיווח את קוד השגיאה $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "$0 is not a directory": [
  null,
  "$0 אינה תיקייה"
 ],
 "$0 does not exist": [
  null,
  "$0 לא קיים"
 ],
 "Font size": [
  null,
  "גודל גופן"
 ],
 "Decrease by one": [
  null,
  "להקטין באחד"
 ],
 "Increase by one": [
  null,
  "להגדיל באחד"
 ],
 "Appearance": [
  null,
  "מראה"
 ],
 "Black": [
  null,
  "שחור"
 ],
 "White": [
  null,
  "לבן"
 ],
 "Reset": [
  null,
  "איפוס"
 ],
 "Unable to open directory": [
  null,
  "לא ניתן לפתוח תיקייה"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "Change directory": [
  null,
  "החלפת תיקייה"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  ""
 ],
 "unknown": [
  null,
  "לא ידוע"
 ],
 "Shutdown": [
  null,
  "כיבוי"
 ],
 "running $0": [
  null,
  "פועל $0"
 ],
 "Current boot": [
  null,
  "עלייה נוכחית"
 ],
 "Previous boot": [
  null,
  "עלייה קודמת"
 ],
 "Last 24 hours": [
  null,
  "24 השעות האחרונות"
 ],
 "Last 7 days": [
  null,
  "7 הימים האחרונים"
 ],
 "Only emergency": [
  null,
  "חירום בלבד"
 ],
 "Alert and above": [
  null,
  "אזעקה ומעלה"
 ],
 "Critical and above": [
  null,
  "חמור ומעלה"
 ],
 "Error and above": [
  null,
  "שגיאה ומעלה"
 ],
 "Warning and above": [
  null,
  "אזהרה ומעלה"
 ],
 "Notice and above": [
  null,
  "הודעה ומעלה"
 ],
 "Info and above": [
  null,
  "מידע ומעלה"
 ],
 "Debug and above": [
  null,
  "ניפוי שגיאות ומעלה"
 ],
 "Toggle filters": [
  null,
  "החלפת מצב מסננים"
 ],
 "Time": [
  null,
  "שעה"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Identifier": [
  null,
  "מזהה"
 ],
 "Filters": [
  null,
  "מסננים"
 ],
 "Pause": [
  null,
  "השהיה"
 ],
 "Resume": [
  null,
  "המשך"
 ],
 "All": [
  null,
  "הכול"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "הגדרות תאריכים אמורות להיות בתבנית YYYY-MM-DD hh:mm:ss. לחלופין אפשר להשתמש במחרוזות ‚yesterday’ (אתמול), ‚today’ (היום) ו־‚tomorrow’ (מחר). ‚now’ (עכשיו) מתייחס לשעה הנוכחית. בנוסף, אפשר לציין זמן יחסי עם קידומת של ‚-’ או ‚+’"
 ],
 "Since": [
  null,
  "מאז"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "להתחיל להציג רשומות בתאריך או לפני התאריך שצוין."
 ],
 "Until": [
  null,
  "עד"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "להתחיל להציג רשומות בתאריך או אחרי התאריך שצוין."
 ],
 "Boot": [
  null,
  "עלייה"
 ],
 "Show messages from a specific boot.": [
  null,
  "הצגת הודעות לעלייה מסוימת."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "הבחירה באפשרות הזאת תוסיף התאמה ל־‚_BOOT_ID=‎’. אם לא נבחרה האפשרות יופיעו רק שורות התיעוד של הטעינה הנוכחית. אם מזהה הטעינה הושמט, היסט חיובי יחפש את הטעינות מתחילת היומן והיסט שווה או קטן מאפס יחפש טעינות החל מסוף היומן. בהתאם לכך, 1 זאת הטעינה הראשונה שנמצאת ביומן בסדר כרונולוגי, 2 היא השנייה וכן הלאה, בעוד ‎-0 היא הטעינה האחרונה, ‎-1 היא הטעינה לפני האחרונה וכן הלאה."
 ],
 "Unit": [
  null,
  "יחידה"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "הצגת הודעות ליחידת ה־systemd שצוינה."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "פעולה זו תוסיף התאמה לביטויים ‚‎_SYSTEMD_UNIT=‎’,‏ ‚COREDUMP_UNIT=‎’ ו־‚UNIT=‎’ כדי למצוא את כל ההודעות האפשריות ליחידה מסוימת. יכולה להכיל יותר מיחידה אחת אם מפרידים ביניהן בפסיקים."
 ],
 "Free-form search": [
  null,
  "חיפוש חופשי"
 ],
 "Show messages containing given string.": [
  null,
  "הצגת הודעות שמכילות את המחרוזת שסופקה."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "אפשר לסנן כל מחרוזת טקסט בהודעות שביומנים. המחרוזת יכולה להיות גם בצורת ביטוי רגולרי. יש תמיכה גם בסינון לפי שדות ביומן ההודעות. כאן משתמשים בערכים מופרדים ברווחים בצורה שדה=ערך, כאשר הערך יכול להיות רשימה מופרדת בפסיקים של ערכים אפשריים."
 ],
 "journalctl manpage": [
  null,
  "מדריך השימוש ב־journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "ההעתקה ללוח הגזירים צלחה"
 ],
 "Create timer": [
  null,
  "יצירת מתזמן"
 ],
 "Timer creation failed": [
  null,
  "יצירת קוצב הזמן נכשלה"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "שדה זה לא יכול להישאר ריק"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "מותר רק אותיות באנגלית, מספרים, : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "הקפצה"
 ],
 "At specific time": [
  null,
  "במועד מסוים"
 ],
 "After system boot": [
  null,
  "לאחר עליית המערכת"
 ],
 "Seconds": [
  null,
  "שניות"
 ],
 "Minutes": [
  null,
  "דקות"
 ],
 "Hours": [
  null,
  "שעות"
 ],
 "Weeks": [
  null,
  "שבועות"
 ],
 "Delay must be a number": [
  null,
  "השהיה חייבת להיות מספר"
 ],
 "Repeat": [
  null,
  "לחזור"
 ],
 "Don't repeat": [
  null,
  "לא לחזור"
 ],
 "Minutely": [
  null,
  "ברמת דקות"
 ],
 "Hourly": [
  null,
  "שעתי"
 ],
 "Daily": [
  null,
  "יומי"
 ],
 "Weekly": [
  null,
  "שבועי"
 ],
 "Monthly": [
  null,
  "חודשי"
 ],
 "Yearly": [
  null,
  "שנתי"
 ],
 "Run at": [
  null,
  "להריץ בתזמון"
 ],
 "At second": [
  null,
  "בשנייה"
 ],
 "At minute": [
  null,
  "בדקה"
 ],
 "Run on": [
  null,
  "להריץ על"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "דקה חייבת להיות מספר בין 0 ל־59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "שנייה חייבת להיות מספר בין 0 ל־59"
 ],
 "Repeat weekly": [
  null,
  "לחזור באופן שבועי"
 ],
 "Mondays": [
  null,
  "ימי שני"
 ],
 "Tuesdays": [
  null,
  "ימי שלישי"
 ],
 "Wednesdays": [
  null,
  "ימי רביעי"
 ],
 "Thursdays": [
  null,
  "ימי חמישי"
 ],
 "Fridays": [
  null,
  "ימי שישי"
 ],
 "Saturdays": [
  null,
  "שבתות"
 ],
 "Sundays": [
  null,
  "ימי ראשון"
 ],
 "Repeat monthly": [
  null,
  "לחזור באופן חודשי"
 ],
 "1st": [
  null,
  "אחד"
 ],
 "2nd": [
  null,
  "שניים"
 ],
 "3rd": [
  null,
  "שלושה"
 ],
 "4th": [
  null,
  "ארבעה"
 ],
 "5th": [
  null,
  "חמישה"
 ],
 "6th": [
  null,
  "שישה"
 ],
 "7th": [
  null,
  "שבעה"
 ],
 "8th": [
  null,
  "שמונה"
 ],
 "9th": [
  null,
  "תשעה"
 ],
 "10th": [
  null,
  "עשירי"
 ],
 "11th": [
  null,
  "אחד עשר"
 ],
 "12th": [
  null,
  "שניים עשר"
 ],
 "13th": [
  null,
  "שלושה עשר"
 ],
 "14th": [
  null,
  "ארבעה עשר"
 ],
 "15th": [
  null,
  "חמישה עשר"
 ],
 "16th": [
  null,
  "שישה עשר"
 ],
 "17th": [
  null,
  "שבעה עשר"
 ],
 "18th": [
  null,
  "שמונה עשר"
 ],
 "19th": [
  null,
  "תשעה עשר"
 ],
 "20th": [
  null,
  "עשרים"
 ],
 "21th": [
  null,
  "עשרים ואחד"
 ],
 "22th": [
  null,
  "עשרים ושניים"
 ],
 "23th": [
  null,
  "עשרים ושלושה"
 ],
 "24th": [
  null,
  "עשרים וארבעה"
 ],
 "25th": [
  null,
  "עשרים וחמישה"
 ],
 "26th": [
  null,
  "עשרים ושישה"
 ],
 "27th": [
  null,
  "עשרים ושבעה"
 ],
 "28th": [
  null,
  "עשרים ושמונה"
 ],
 "29th": [
  null,
  "עשרים ותשעה"
 ],
 "30th": [
  null,
  "שלושים"
 ],
 "31st": [
  null,
  "שלושים ואחד"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Dismiss": [
  null,
  "התעלמות"
 ],
 "Scheduled poweroff at $0": [
  null,
  "תוזמן כיבוי ל־$0"
 ],
 "Cancel poweroff": [
  null,
  "ביטול כיבוי"
 ],
 "Scheduled reboot at $0": [
  null,
  "תוזמנה הפעלה מחדש ל־$0"
 ],
 "Cancel reboot": [
  null,
  "ביטול הפעלה מחדש"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "Set hostname": [
  null,
  "הגדרת שם מארח"
 ],
 "Configuration": [
  null,
  "הגדרות"
 ],
 "Hostname": [
  null,
  "שם מארח"
 ],
 "System time": [
  null,
  "שעון המערכת"
 ],
 "Domain": [
  null,
  "שם תחום"
 ],
 "Performance profile": [
  null,
  "פרופיל ביצועים"
 ],
 "Secure shell keys": [
  null,
  "מפתחות מעטפת מאובטחת"
 ],
 "Show fingerprints": [
  null,
  "הצגת טביעות אצבע"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "הצגת מפתחות ה־ssh של המארח נכשלה: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "טעינת מפתחות ה־SSH נכשלה"
 ],
 "Error message": [
  null,
  "הודעת שגיאה"
 ],
 "Loading keys...": [
  null,
  "המפתחות נטענים…"
 ],
 "No host keys found.": [
  null,
  "לא נמצאו מפתחות מארחים."
 ],
 "Machine SSH key fingerprints": [
  null,
  "טביעות אצבע מפתח SSH של מכונה"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "אורך שם התחום האמתי חייב להיות קצר מ־64 תווים"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "שם המארח האמתי יכול להכיל רק אותיות קטנות באנגלית, ספרות, מינוסים ונקודות (עם תת־שמות תחום מאוכלסים)"
 ],
 "Change host name": [
  null,
  "החלפת שם מארח"
 ],
 "Pretty host name": [
  null,
  "שם מארח יפה"
 ],
 "Real host name": [
  null,
  "שם המארח האמתי"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "המשתמש $0 אינו מורשה להחליף בין ערכות מדיניות קריפטוגרפיות"
 ],
 "Cryptographic policy": [
  null,
  "מדיניות קריפטוגרפית"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "מומלץ, הגדרות מאובטחות בהתאם לדגמי האיום הנוכחיים."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "מותר ברירת מחדל עם אימות חתימה SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "מרחב תמרון גדול יותר על חשבון חזית פגיעה יותר לתקיפות."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "מיושן עם תאימות מול Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "להשתמש רק באלגוריתמים מאושרים ומורשים בעת טעינה במצב FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS עם מגבלות קריטריונים משותפים נוספות."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "מגן מפני התקפות צפויות בעתיד הקרוב על חשבון מרחב תמרון."
 ],
 "Custom cryptographic policy": [
  null,
  "מדיניות קריפטוגרפית משלך"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "ערכות מדיניות קריפטוגרפיות הוא רכיב מערכת שמגדיר את המערכות הקריפטוגרפיות של הליבה וחולש על פני פרוטוקולי TLS,‏ IPSec,‏ SSH,‏ DNSSec ו־Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "החלפת מדיניות קריפטוגרפית"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "המדיניות החדשה חלה… עשוי לארוך מספר דקות."
 ],
 "Reapply and reboot": [
  null,
  "החלה חוזרת והפעלה מחדש"
 ],
 "Apply and reboot": [
  null,
  "החלה והפעלה מחדש"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS לא מופעל כראוי"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "המדיניות הקריפטוגרפית אינה אחידה"
 ],
 "System information": [
  null,
  "פרטי המערכת"
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Asset tag": [
  null,
  "תג נכס"
 ],
 "Machine ID": [
  null,
  "מזהה מכונה"
 ],
 "View hardware details": [
  null,
  "הצגת פרטי חומרה"
 ],
 "Last successful login:": [
  null,
  "כניסה אחרונה שהצליחה:"
 ],
 "$0 failed login attempt": [
  null,
  "ניסיון כניסה שנכשל",
  "שני ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו"
 ],
 "View login history": [
  null,
  "הצגת היסטוריית כניסות למערכת"
 ],
 "recommended": [
  null,
  "מומלץ"
 ],
 "inconsistent": [
  null,
  "חסר אחידות"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "הצטרפות לשם תחום דורש את התקנת realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "לא ניתן להצטרף לשם תחום כיוון ש־realmd לא זמין במערכת הזו"
 ],
 "Joining this domain is not supported": [
  null,
  "אין תמיכה בהצטרפות לשם התחום הזה"
 ],
 "Login format": [
  null,
  "תצורת כניסה"
 ],
 "Server software": [
  null,
  "התכנה בשרת"
 ],
 "Client software": [
  null,
  "תכנה מצד לקוח"
 ],
 "Leave domain": [
  null,
  "עזיבת שם התחום"
 ],
 "Leave $0": [
  null,
  "לעזוב את $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "לאחר עזיבת שם התחום, רק משתמשים עם פרטי גישה מקומיים יוכלו להיכנס למכונה הזאת. זה עשוי להשפיע על שירותים אחרים כגון פתרון בעזרת DNS ורשימת רשויות האישורים המהימנות עשויה להשתנות."
 ],
 "Validating address": [
  null,
  "הכתובת מתוקפת"
 ],
 "Contacted domain": [
  null,
  "שם תחום שנוצר אתו קשר"
 ],
 "Domain could not be contacted": [
  null,
  "לא ניתן ליצור קשר עם שם התחום"
 ],
 "Domain is not supported": [
  null,
  "שם התחום אינו נתמך"
 ],
 "Domain address": [
  null,
  "כתובת שם תחום"
 ],
 "Domain administrator name": [
  null,
  "שם מנהל שם תחום"
 ],
 "Domain administrator password": [
  null,
  "סיסמת מנהל שם תחום"
 ],
 "Joining": [
  null,
  "הצטרפות"
 ],
 "Join": [
  null,
  "הצטרפות"
 ],
 "This may take a while": [
  null,
  "פעולה זו עשויה לארוך זמן מה"
 ],
 "Not permitted to configure realms": [
  null,
  "המשתמש $0 אינו מורשה לשנות מתחמים"
 ],
 "Join domain": [
  null,
  "הצטרפות לשם תחום"
 ],
 "Install realmd support": [
  null,
  "התקנת תמיכה ב־realmd"
 ],
 "$0 disk is failing": [
  null,
  "כונן נכשל",
  "שני כוננים נכשלו",
  "$0 כוננים נכשלו",
  "$0 כוננים נכשלו"
 ],
 "Not connected to Insights": [
  null,
  "לא מחובר לתובנות"
 ],
 "Health": [
  null,
  "בריאות"
 ],
 "of $0 CPU": [
  null,
  "מתוך מעבד אחד",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "CPU": [
  null,
  "מעבד"
 ],
 "Memory": [
  null,
  "זיכרון"
 ],
 "View metrics and history": [
  null,
  "הצגת מדדים והיסטוריה"
 ],
 "Tuned is not available": [
  null,
  "Tuned אינו זמין"
 ],
 "Tuned is not running": [
  null,
  "Tuned אינו מופעל"
 ],
 "Tuned is off": [
  null,
  "Tuned כבוי"
 ],
 "This system is using the recommended profile": [
  null,
  "מערכת זו משתמשת בפרופיל המומלץ"
 ],
 "This system is using a custom profile": [
  null,
  "מערכת זו משתמשת בפרופיל מותאם אישית"
 ],
 "none": [
  null,
  "אין"
 ],
 "Communication with tuned has failed": [
  null,
  "התקשורת עם tuned נכשלה"
 ],
 "Failed to enable tuned": [
  null,
  "ההפעלה של tuned נכשלה"
 ],
 "Failed to disable tuned": [
  null,
  "ההשבתה של tuned נכשלה"
 ],
 "Failed to disable tuned profile": [
  null,
  "השבתת פרופיל ה־tuned נכשלה"
 ],
 "Failed to switch profile": [
  null,
  "החלפת פרופיל נכשלה"
 ],
 "None": [
  null,
  "אין"
 ],
 "Disable tuned": [
  null,
  "השבתת tuned"
 ],
 "Tuned has failed to start": [
  null,
  "ההפעלה של Tuned נכשלה"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned הוא שירות שעוקב אחר המערכת שלך וממטב את הביצועים תחת עומסים מסוימים. הליבה של Tuned הם פרופילים, שמכוונים את המערכת שלך למגוון מקרי בוחן."
 ],
 "Change performance profile": [
  null,
  "החלפת פרופיל ביצועים"
 ],
 "Change profile": [
  null,
  "החלפת פרופיל"
 ],
 "Edit /etc/motd": [
  null,
  "עריכת ‎/etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "שמירת השינויים ב־‎/etc/motd נכשלה"
 ],
 "Save changes": [
  null,
  "שמירת השינויים"
 ],
 "Edit motd": [
  null,
  "עריכת ההודעה היומית"
 ],
 "Stub": [
  null,
  "בדל (Stub)"
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Bad setting": [
  null,
  "הגדרה פסולה"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Merged": [
  null,
  "ממוזגת"
 ],
 "Running": [
  null,
  "פועל"
 ],
 "Reloading": [
  null,
  "מתבצע רענון"
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Failed to start": [
  null,
  "ההפעלה נכשלה"
 ],
 "Maintenance": [
  null,
  "תחזוקה"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Linked": [
  null,
  "מקושר"
 ],
 "Alias": [
  null,
  "כינוי"
 ],
 "Masked": [
  null,
  "ממוסך"
 ],
 "Static": [
  null,
  "סטטי"
 ],
 "Invalid": [
  null,
  "שגוי"
 ],
 "Indirect": [
  null,
  "עקיף"
 ],
 "Generated": [
  null,
  "נוצר"
 ],
 "Transient": [
  null,
  "זמני"
 ],
 "Bad": [
  null,
  "פסול"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "הרישום ל־signals (אותות) של systemd נכשל: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "החיבור ל־dbus נכשל: $0"
 ],
 "Listing units failed: $0": [
  null,
  "הצגת היחידות נכשלה: $0"
 ],
 "$0 service has failed": [
  null,
  "שירות אחד נכשל",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו"
 ],
 "Loading of units failed": [
  null,
  "טעינת היחידות נכשלה"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Listing units": [
  null,
  "היחידות מוצגות"
 ],
 "Filter by name or description": [
  null,
  "סינון לפי שם או תיאור"
 ],
 "Active state": [
  null,
  "מצב פעיל"
 ],
 "File state": [
  null,
  "מצב הקובץ"
 ],
 "$0 filters applied": [
  null,
  "$0 מסננים פעילים"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "המשתמש $0 אינו מורשה לשנות את אפחותי אבטחת המעבד"
 ],
 "Mitigations": [
  null,
  "אפחותים"
 ],
 "Version": [
  null,
  "גרסה"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "גרסת BIOS"
 ],
 "BIOS date": [
  null,
  "תאריך BIOS"
 ],
 "CPU security": [
  null,
  "אבטחת מעבד"
 ],
 "Disable simultaneous multithreading": [
  null,
  "השבתת ריבוי תהליכים מקבילי"
 ],
 "Read more...": [
  null,
  "מידע נוסף…"
 ],
 "Save and reboot": [
  null,
  "שמירה והפעלה מחדש"
 ],
 "CPU security toggles": [
  null,
  "מתגי אבטחת מעבד"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "מעקפי תכנה מסייעים למנוע תקלות אבטחה במעבד. לאפחותים אלו יש השפעות לוואי בדמות הפחתת ביצועים. שינוי ההגדרות האלו הוא על אחריותך בלבד."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "מחלקה"
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "Slot": [
  null,
  "משבצת"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Memory technology": [
  null,
  "טכנולוגיית זיכרון"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "State": [
  null,
  "מצב"
 ],
 "Rank": [
  null,
  "דירוג"
 ],
 "Speed": [
  null,
  "מהירות"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "צפייה בפרטי זיכרון דורשת גישה ניהולית."
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "Failed to fetch logs": [
  null,
  "משיכת יומנים נכשלה"
 ],
 "Clear all filters": [
  null,
  "ניקוי כל המסננים"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "לא ניתן למצוא יומנים עם שילוב המסננים הנוכחי."
 ],
 "No logs found": [
  null,
  "לא נמצאו יומנים"
 ],
 "Load earlier entries": [
  null,
  "טעינת רשומות קודמות"
 ],
 "You may try to load older entries.": [
  null,
  "כדאי לך לנסות לטעון רשומות ישנות יותר."
 ],
 "Allow running (unmask)": [
  null,
  "לאפשר הרצה (ביטול מיסוך)"
 ],
 "Reload": [
  null,
  "רענון"
 ],
 "Restart": [
  null,
  "הפעלה מחדש"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Clear 'Failed to start'": [
  null,
  "לנקות ‚התחלה נכשלה’"
 ],
 "Mask service": [
  null,
  "מיסוך שירות"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "מיסוך שירות מונע מכל היחידות התלויות לפעול. להגדרה זו עשויה להיות השפעה גדולה מהצפוי. נא לאשר שברצונך למסך את היחידה הזאת."
 ],
 "Disallow running (mask)": [
  null,
  "לא לאפשר הרצה (מיסוך)"
 ],
 "Unpin unit": [
  null,
  "שחרור היחידה"
 ],
 "Pin unit": [
  null,
  "נעיצת יחידה"
 ],
 "Additional actions": [
  null,
  "פעולות נוספות"
 ],
 "Note": [
  null,
  "הערה"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "יחידה זו לא תוכננה להפעלה באופן מפורש."
 ],
 "Forbidden from running": [
  null,
  "נאסר עליו לפעול"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Active since ": [
  null,
  "פעיל מאז "
 ],
 "Required by ": [
  null,
  "נדרש על ידי "
 ],
 "Read-only": [
  null,
  "קריאה בלבד"
 ],
 "Requires administration access to edit": [
  null,
  "נדרשת גישה ניהולית כדי לערוך"
 ],
 "Automatically starts": [
  null,
  "מתחיל אוטומטית"
 ],
 "Updating status...": [
  null,
  "המצב מתעדכן…"
 ],
 "Stop and disable": [
  null,
  "עצירה והשבתה"
 ],
 "Start and enable": [
  null,
  "התחלה והפעלה"
 ],
 "Failed to load unit": [
  null,
  "טעינת היחידה נכשלה"
 ],
 "View all services": [
  null,
  "הצגת כל השירותים"
 ],
 "Triggers": [
  null,
  "הקפצות"
 ],
 "Triggered by": [
  null,
  "מוקפץ על ידי"
 ],
 "Requires": [
  null,
  "דורש"
 ],
 "Requisite": [
  null,
  "הכרח"
 ],
 "Wants": [
  null,
  "דורש"
 ],
 "Binds to": [
  null,
  "מתאגד אל"
 ],
 "Part of": [
  null,
  "חלק מתוך"
 ],
 "Required by": [
  null,
  "נדרש על ידי"
 ],
 "Requisite of": [
  null,
  "הכרח של"
 ],
 "Wanted by": [
  null,
  "נדרש על ידי"
 ],
 "Bound by": [
  null,
  "מאוגד על ידי"
 ],
 "Consists of": [
  null,
  "מורכב מ־"
 ],
 "Conflicts": [
  null,
  "סותר"
 ],
 "Conflicted by": [
  null,
  "בסתירה עם"
 ],
 "Before": [
  null,
  "לפני"
 ],
 "After": [
  null,
  "אחרי"
 ],
 "On failure": [
  null,
  "בעת כשל"
 ],
 "Propagates reload to": [
  null,
  "מפיץ רענון אל"
 ],
 "Reload propagated from": [
  null,
  "הטעינה הופצה מהמקור"
 ],
 "Joins namespace of": [
  null,
  "מצטרף למרחב השם של"
 ],
 "Condition $0=$1 was not met": [
  null,
  "התנאי $0=$1 לא התקיים"
 ],
 "Deletion will remove the following files:": [
  null,
  "מחיקה תסיר את הקבצים הבאים:"
 ],
 "Pinned unit": [
  null,
  "יחידה נעוצה"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Path": [
  null,
  "נתיב"
 ],
 "Listen": [
  null,
  "האזנה"
 ],
 "Container": [
  null,
  "מכולה"
 ],
 "Condition failed": [
  null,
  "התנאי נכשל"
 ],
 "Show more relationships": [
  null,
  "הצגת קשרים נוספים"
 ],
 "Show relationships": [
  null,
  "הצגת קשרים"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Timer deletion failed": [
  null,
  "מחיקת קוצב הזמן נכשלה"
 ],
 "Targets": [
  null,
  "יעדים"
 ],
 "Sockets": [
  null,
  "שקעים"
 ],
 "Timers": [
  null,
  "מתזמנים"
 ],
 "Paths": [
  null,
  "נתיבים"
 ],
 "Go to $0": [
  null,
  "לעבור אל $0"
 ],
 "Journal entry not found": [
  null,
  "רשומת הז׳ורנל לא נמצאה"
 ],
 "Journal entry": [
  null,
  "רשומת ז׳ורנל"
 ],
 "Entry at $0": [
  null,
  "רשומה ב־$0"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "Loading unit failed": [
  null,
  "טעינת היחידה נכשלה"
 ],
 "Service logs": [
  null,
  "יומני שירות"
 ],
 "No log entries": [
  null,
  "אין רשומות ביומן"
 ],
 "Systemd units": [
  null,
  "יחידות Systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "לא נמצאו תוצאות לתנאי המסנן. יש לנקות את כל המסננים כדי להציג תוצאות."
 ],
 "Does not automatically start": [
  null,
  "לא מתחיל אוטומטית"
 ],
 "Cannot be enabled": [
  null,
  "לא ניתן להפעיל"
 ],
 "Web console is running in limited access mode.": [
  null,
  "המסוף המקוון מופעל במצב גישה מוגבלת."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "מ־$0 על גבי $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "מ־$0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "על גבי $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "שם תחום"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "הצטרפות לשם תחום"
 ]
});
