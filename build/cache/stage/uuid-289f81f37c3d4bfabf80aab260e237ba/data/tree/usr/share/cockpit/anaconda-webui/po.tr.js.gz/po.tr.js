cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 hata",
  "$0 hata"
 ],
 "$0 installation": [
  null,
  "$0 kurulumu"
 ],
 "$0 installer": [
  null,
  "$0 kurucusu"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0, mantıksal bölümler içeren genişletilmiş bir MBR bölümüdür. Tüm mantıksal bölümlerin kaldırılması, genişletilmiş bölümü de otomatik olarak kaldıracaktır."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 gerekli, ama yalnızca $1 var."
 ],
 "$0 warning": [
  null,
  "$0 uyarı",
  "$0 uyarı"
 ],
 "$0 will be deleted": [
  null,
  "$0 silinecek"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' dosya sistemi şifrelenmiş bir blok aygıtı üzerinde olamaz"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0', '$1' olarak atanmalıdır"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0', '$1' olarak biçimlendirilen bir aygıt üzerinde olmalıdır"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' bir EFI Sistem Bölümü üzerinde olmalıdır. Seçilen bölüm FAT dosya sistemini kullanıyor, ancak ESP olarak işaretlenmedi. Bölüm türünü EFI Sistem olarak ayarlayın ve esp bayrağını etkinleştirin."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "$1 cihazındaki '$0' bölüntüsü bulundu. MDRAID cihazlarındaki önyükleyici bölüntüleri desteklenmez."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Sistem genelinde değişiklikler yapmak için yönetici erişimine sahip olan standart bir kullanıcı hesabı."
 ],
 "Abort installation": [
  null,
  "Kurulumu iptal et"
 ],
 "About": [
  null,
  "Hakkında"
 ],
 "Account": [
  null,
  "Hesap"
 ],
 "Actions": [
  null,
  "Eylemler"
 ],
 "Add another server...": [
  null,
  "Başka bir sunucu ekle..."
 ],
 "Add mount": [
  null,
  "Bağlama noktası ekle"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Seçtiğiniz ortam için eklentiler"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Ortamınıza özgü olmayan eklentiler"
 ],
 "Additional languages": [
  null,
  "Ek diller"
 ],
 "Additional software for the selected environment": [
  null,
  "Seçilen ortam için ilave yazılımlar"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Depolama düzenleyicisinde yapılan tüm değişiklikler hemen geçerli olur."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Bu parolayı kullanan tüm aygıtların kilidi açılacak"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web Arayüzü"
 ],
 "Anaconda project page": [
  null,
  "Anaconda projesi sayfası"
 ],
 "Apply mount point assignment and install": [
  null,
  "Bağlama noktası atamasını uygula ve kur"
 ],
 "Applying changes...": [
  null,
  "Değişiklikler uygulanıyor..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Bölümleri bağlama noktalarına ata. Önceden yapılandırılan özel düzenler için kullanışlıdır."
 ],
 "Automatic log file upload": [
  null,
  "Otomatik günlük dosyası yüklemesi"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Zaman suncularını kullanarak tarih ve saati otomatik olarak ayarlayın"
 ],
 "Automatically set timezone": [
  null,
  "Zaman dilimini otomatik olarak ayarla"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Kullanılabilir boş alan: $0. Kurulum için gerekli olan: $1."
 ],
 "Back": [
  null,
  "Geri"
 ],
 "Base environment": [
  null,
  "Temel ortam"
 ],
 "Brief description of the issue": [
  null,
  "Sorunun kısa açıklaması"
 ],
 "Bug report details": [
  null,
  "Hata raporu ayrıntıları"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API anahtarı"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Bu yazılımı kullanmayı sürdürerek, sürüm öncesi yazılımla ilişkili riskleri anladığınızı, bunu yalnızca sınama ve geliştirme amacıyla kullanmayı planladığınızı ve bu çalışmayı iyileştirmek için tüm hata veya sorunları bildirmeye hazır olduğunuzu kabul edersiniz."
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change destination": [
  null,
  "Hedefi değiştir"
 ],
 "Change hostname": [
  null,
  "Ana makine adını değiştir"
 ],
 "Change partition layout": [
  null,
  "Bölüm düzenini değiştir"
 ],
 "Change system keyboard layout": [
  null,
  "Sistem klavye görünümünü değiştirin"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Burada yapılan değişiklikler sistemi hemen etkileyecektir. 'Geri al' seçeneği yoktur."
 ],
 "Checking installation configuration...": [
  null,
  "Kurulum yapılandırması denetleniyor..."
 ],
 "Checking storage configuration": [
  null,
  "Depolama yapılandırması denetleniyor"
 ],
 "Clear search": [
  null,
  "Aramayı temizle"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Bu uyarılara rağmen devam etmek için tekrar 'İleri' düğmesine tıklayın."
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Close storage editor": [
  null,
  "Depolama düzenleyicisini kapat"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit depolaması, şifrelenen aygıtın kilidini açmak için parola sağlamadı."
 ],
 "Completed": [
  null,
  "Tamamlandı"
 ],
 "Configuration is incomplete": [
  null,
  "Yapılandırma tamamlanmadı"
 ],
 "Configure NTP servers": [
  null,
  "NTP sunucularını yapılandır"
 ],
 "Configure custom NTP servers": [
  null,
  "Özel NTP sunucularını yapılandır"
 ],
 "Configure network": [
  null,
  "Ağı yapılandır"
 ],
 "Configure storage": [
  null,
  "Depolamayı yapılandır"
 ],
 "Configure storage again": [
  null,
  "Depolamayı tekrar yapılandır"
 ],
 "Confirm passphrase": [
  null,
  "Parolayı onayla"
 ],
 "Continue": [
  null,
  "Sürdür"
 ],
 "Continue installation": [
  null,
  "Kuruluma devam et"
 ],
 "Continue installation?": [
  null,
  "Kuruluma devam edilsin mi?"
 ],
 "Continue with installation": [
  null,
  "Kuruluma devam et"
 ],
 "Correct these issues before continuing.": [
  null,
  "Devam etmeden önce bu sorunları düzeltin."
 ],
 "Create Account": [
  null,
  "Hesap Oluştur"
 ],
 "Create account": [
  null,
  "Hesap oluştur"
 ],
 "Currently installed: $0": [
  null,
  "Şu anda kurulu: $0"
 ],
 "Custom": [
  null,
  "Özel"
 ],
 "Date": [
  null,
  "Tarih"
 ],
 "Date and time": [
  null,
  "Tarih ve saat"
 ],
 "Delete partition": [
  null,
  "Bölümü sil"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Belirli bölümlerin silinmesi $0 önyüklenmesini engelleyebilir: $1"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Destination": [
  null,
  "Hedef"
 ],
 "Destination is encrypted": [
  null,
  "Hedef şifreli"
 ],
 "Detailed description of the issue": [
  null,
  "Sorunun ayrıntılı açıklaması"
 ],
 "Detected valid storage layout:": [
  null,
  "Algılanan geçerli depolama düzeni:"
 ],
 "Device": [
  null,
  "Aygıt"
 ],
 "Duplicate device.": [
  null,
  "Yinelenen aygıt."
 ],
 "Duplicate mount point.": [
  null,
  "Yinelenen bağlama noktası."
 ],
 "Enable root account": [
  null,
  "Kök hesabını etkinleştir"
 ],
 "Encrypt my data": [
  null,
  "Verilerimi şifrele"
 ],
 "Encrypted": [
  null,
  "Şifrelendi"
 ],
 "Encryption": [
  null,
  "Şifreleme"
 ],
 "Enter PIN": [
  null,
  "PIN girin"
 ],
 "Enter PIN to access the installer": [
  null,
  "Kurucuya erişmek için PIN kodunu girin"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Sorun raporu oluşturabilmek için Bugzilla API anahtarınızı girin. Sonraki aşamada sorun raporunu gözden geçirip düzenleyebileceksin."
 ],
 "Environment": [
  null,
  "Ortam"
 ],
 "Erase data and install": [
  null,
  "Verileri sil ve kur"
 ],
 "Error details": [
  null,
  "Hata ayrıntıları"
 ],
 "Exit to live desktop": [
  null,
  "Canlı masaüstüne çık"
 ],
 "Extended partition": [
  null,
  "Genişletilmiş bölüm"
 ],
 "Failed to report issue": [
  null,
  "Sorun bildirimi başarısız oldu"
 ],
 "Failed to save layouts": [
  null,
  "Düzenler kaydedilemedi"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux en az $0 disk alanı gerektirir."
 ],
 "Finalization": [
  null,
  "Sonlandırma"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Sonlandırılıyor: Sistem yapılandırması tamamlandı. Kurulumun sonlandırılması birkaç dakika sürebilir."
 ],
 "Find layout": [
  null,
  "Düzen bul"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Daha iyi güvenlik için, root hesabını doğrudan kullanmaktan kaçının. Bunun yerine, sistemi yönetmek için yukarıdaki yerel hesabı kullanın."
 ],
 "Full name": [
  null,
  "Tam ad"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Tam ad iki nokta üst üste karakterini içeremez"
 ],
 "Helper text": [
  null,
  "Yardımcı metin"
 ],
 "Hide API key": [
  null,
  "API anahtarını gizle"
 ],
 "Hide PIN": [
  null,
  "PIN kodunu gizle"
 ],
 "Hide confirmed password": [
  null,
  "Onaylanan parolayı gizle"
 ],
 "Hide passphrase": [
  null,
  "Parolayı gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "Hostname": [
  null,
  "Ana makine adı"
 ],
 "How would you like to install?": [
  null,
  "Nasıl kurmak istersiniz?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Var olan tüm verilerin silineceğini anlıyorum",
  "Seçilen disklerden var olan tüm verilerin silineceğini anlıyorum"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Var olan bazı verilerin silineceğini anlıyorum"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Bazı bölümlerin değiştirileceğini anlıyorum"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Boşsa, ana makine adı geçici olacak ve ağ bilgileri tarafından ayarlanacaktır."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Yukarıdaki seçeneklerden hiçbiri uygun değilse, devam etmeden önce depolama düzenleyicisini kullanarak özel bir bölümlendirme oluşturun."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Bölümleri yapılandırıyorsanız şunlar gereklidir:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Otomatik günlük dosyası yüklemesine izin vermezseniz, bunun yerine $0 yapabilirsiniz. Elle bildirim, günlük dosyalarını kendiniz inceleyip seçerek eklemenizi sağlar."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Riskleri anlamadıysanız veya kabul etmiyorsanız, lütfen bu programdan çıkın."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Sorununuz yukarıdaki hatalardan biriyle eşleşiyorsa, yinelenen bir rapor oluşturmak yerine onu açıp bilgilerinizi oraya ekleyebilirsiniz."
 ],
 "In progress": [
  null,
  "Sürüyor"
 ],
 "Initializing...": [
  null,
  "Başlatılıyor..."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Installation completed": [
  null,
  "Kurulum tamamlandı"
 ],
 "Installation failed": [
  null,
  "Kurulum başarısız"
 ],
 "Installation method": [
  null,
  "Kurulum yöntemi"
 ],
 "Installation of the system failed": [
  null,
  "Sistemin kurulumu başarısız oldu"
 ],
 "Installation of the system failed: $0": [
  null,
  "Sistem kurulumu başarısız oldu: $0"
 ],
 "Installation type": [
  null,
  "Kurulum türü"
 ],
 "Installing": [
  null,
  "Kuruluyor"
 ],
 "Insufficient disk space": [
  null,
  "Yetersiz disk alanı"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Geçersiz PIN. Lütfen tekrar deneyin."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Geçersiz RAID konfigürasyonu tespit edildi. Eğer RAID diziniz doğrudan diskleriniz üzerine oluşturulduysa, dizide bir bölüntü tablosunun oluşturulması gerekmektedir. Eğer RAID diziniz bölüntülerin üzerine oluşturulmuşsa, tek bir dosya sistemi veya format içermelidir (örneğin LVM PV). Bu dizide var olan bölüntüler yok sayılacak."
 ],
 "Invalid hostname": [
  null,
  "Geçersiz ana makine adı"
 ],
 "Jump to first incomplete step": [
  null,
  "İlk tamamlanmamış adıma git"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Geçerli disk düzenini koru ve başka bir işletim sistemi ile çift önyükleme yapmak için kullanılabilir alanı kullan."
 ],
 "Keyboard": [
  null,
  "Klavye"
 ],
 "Keyboard layout during boot": [
  null,
  "Önyükleme sırasında klavye görünümü"
 ],
 "Language": [
  null,
  "Dil"
 ],
 "Launch storage editor": [
  null,
  "Depolama düzenleyicisini başlat"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Yapılandırmada kısıtlı erişim hakkında daha fazla bilgi edinin"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Boş bir parola kullanmak için her iki parola alanını da boş bırakın."
 ],
 "Location": [
  null,
  "Konum"
 ],
 "Locked devices": [
  null,
  "Kilitli aygıtlar"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Make current": [
  null,
  "Geçerli yap"
 ],
 "Manual disk configuration": [
  null,
  "Elle disk yapılandırması"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Elle disk yapılandırması: Bağlama noktası eşlemesi"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Harf, rakam ve tire işareti içerebilir."
 ],
 "May need more free space": [
  null,
  "Daha fazla boş alan gerekebilir"
 ],
 "Medium": [
  null,
  "Ortam"
 ],
 "Minimum of $0 required": [
  null,
  "$0'ın en azı gereklidir"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Üst aygıt ve alt aygıt yeniden biçimlendirme seçimi arasında uyumsuzluk."
 ],
 "Mount point": [
  null,
  "Bağlama noktası"
 ],
 "Mount point assignment": [
  null,
  "Bağlama noktası ataması"
 ],
 "Move down": [
  null,
  "Aşağı taşı"
 ],
 "Move up": [
  null,
  "Yukarı taşı"
 ],
 "Must be at least $0 characters": [
  null,
  "En az $0 karakter uzunluğunda olmalı"
 ],
 "My issue is different, continue": [
  null,
  "Benim sorunum farklı, devam et"
 ],
 "NTP Servers": [
  null,
  "NTP Sunucuları"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Needs at least $0": [
  null,
  "En az $0 gerekli"
 ],
 "Network": [
  null,
  "Ağ"
 ],
 "Network Configuration": [
  null,
  "Ağ Yapılandırması"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Ağ kullanılabilir değil. Sorunu bildirmek için üst çubuk menüsünden ağı yapılandırın."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Ağ kullanılabilir değil. Sorunu bildirmek için ağı yapılandırın."
 ],
 "Network plugin failed": [
  null,
  "Ağ eklentisi başarısız oldu"
 ],
 "Next": [
  null,
  "Sonraki"
 ],
 "No devices": [
  null,
  "Aygıt yok"
 ],
 "No disks available": [
  null,
  "Kullanılabilir disk yok"
 ],
 "No disks selected": [
  null,
  "Hiçbir disk seçilmedi"
 ],
 "No keyboard layouts selected": [
  null,
  "Klavye düzeni seçilmedi"
 ],
 "No layouts selected yet": [
  null,
  "Henüz düzen seçilmedi"
 ],
 "No results found": [
  null,
  "Sonuç bulunamadı"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Seçilen klavye düzen(ler)i için geçerli bir VConsole tuş eşlemi bulunamadı. Lütfen farklı bir klavye düzeni seçin."
 ],
 "Not enough available free space": [
  null,
  "Yeterli boş alan yok"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Seçilen disklerde yeterli boş alan yok."
 ],
 "Not enough space on selected disks.": [
  null,
  "Seçilen disklerde yeterli alan yok."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Uyarı: Bu, yalnızca geliştirme ve test amaçlı olan sürüm öncesi bir yazılımdır. Bu yazılımı herhangi bir önemli iş veya üretim ortamı için KULLANMAYIN."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Bugzilla sorun giriş formunu aç"
 ],
 "Operating system": [
  null,
  "İşletim sistemi"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Other keyboards": [
  null,
  "Diğer klavyeler"
 ],
 "Partitions (advanced)": [
  null,
  "Bölümler (gelişmiş)"
 ],
 "Passphrase": [
  null,
  "Parola"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Parola herhangi bir kilitli aygıtla eşleşmedi"
 ],
 "Passphrases must match": [
  null,
  "Parolalar eşleşmeli"
 ],
 "Pending": [
  null,
  "Bekliyor"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Lütfen $0 günlük dosyasını soruna ekleyin."
 ],
 "Please enter a PIN": [
  null,
  "Lütfen PIN kodu girin"
 ],
 "Please select at least one disk to continue": [
  null,
  "Devam etmek için en az bir disk seçin"
 ],
 "Pool": [
  null,
  "Havuz"
 ],
 "Potential duplicate bugs found": [
  null,
  "Olası yinelenen hatalar bulundu"
 ],
 "Powered by Anaconda": [
  null,
  "Anaconda tabanlıdır"
 ],
 "Pre-release": [
  null,
  "Ön sürüm"
 ],
 "Prefer to report manually? $0": [
  null,
  "Manuel olarak raporlamayı mı tercih ediyorsunuz? $0"
 ],
 "Proceed with installation": [
  null,
  "Kuruluma devam et"
 ],
 "Quit": [
  null,
  "Çık"
 ],
 "Quit installer?": [
  null,
  "Kurucudan çıkılsın mı?"
 ],
 "Reading information about the OS failed.": [
  null,
  "İşletim sistemi hakkında bilgilerin okunması başarısız oldu."
 ],
 "Reading information about the computer failed.": [
  null,
  "Bilgisayar hakkında bilgilerin okunması başarısız oldu."
 ],
 "Reading installer configuration failed.": [
  null,
  "Kurucu yapılandırmasının okunması başarısız oldu."
 ],
 "Reading installer version information failed.": [
  null,
  "Kurucu sürüm bilgilerinin okunması başarısız oldu."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Gerçek ana makine adı yalnızca karakter, rakam, tire işareti (bir karakterin başında veya sonunda değil) ve nokta içerebilir"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Gerçek ana makine adı 64 karakter veya daha az olmalıdır"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "BitLocker ile şifrelenen bölümleri yeniden boyutlandırmak için Windows'u yeniden başlatın. Kurulum için en az $0 boş alan oluşturun."
 ],
 "Reboot system?": [
  null,
  "Sistem yeniden başlatılsın mı?"
 ],
 "Reclaim additional space": [
  null,
  "Ek alan kazan"
 ],
 "Reclaim space": [
  null,
  "Alanı geri kazan"
 ],
 "Reclaim space (required)": [
  null,
  "Alanı geri kazan (gerekli)"
 ],
 "Recommended": [
  null,
  "Tavsiye edilir"
 ],
 "Recommended partitions:": [
  null,
  "Tavsiye edilen bölümler:"
 ],
 "Reformat": [
  null,
  "Yeniden biçimlendir"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora'yı Yeniden Kur"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Var olan işletim sistemleri de dahil olmak üzere seçilen aygıtlardaki tüm bölümleri kaldır."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Kurulum için yer açmak üzere var olan dosya sistemlerini kaldırın veya yeniden boyutlandırın."
 ],
 "Remove server": [
  null,
  "Sunucuyu kaldır"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Bir dosya sistemini silmek, içerdiği verileri kalıcı olarak siler. Bir bölüntüyü yeniden boyutlandırmak, kullanılmayan alanı geri kazandırabilir, ama risksiz değildir. Yeniden alan kazanmadan önce önemli olan herşeyin yedeğine sahip olduğunuzdan emin olun."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Geçerli kurulumu değiştir, ancak ev dizinindeki dosyaları sakla."
 ],
 "Report Issue": [
  null,
  "Sorunu Bildir"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "$0 Bugzilla hata giriş formunu açarak bir sorun bildirin veya geri bildirimde bulunun."
 ],
 "Report issue": [
  null,
  "Sorunu bildir"
 ],
 "Reporting issue...": [
  null,
  "Sorun bildiriliyor..."
 ],
 "Required": [
  null,
  "Gerekli"
 ],
 "Requirements": [
  null,
  "Gereksinimler"
 ],
 "Rescan devices": [
  null,
  "Aygıtları yeniden tara"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Disklerin yeniden taranması başarısız oldu."
 ],
 "Resize": [
  null,
  "Yeniden boyutlandır"
 ],
 "Resize partition": [
  null,
  "Bölümü yeniden boyutlandır"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Şu bölümler $0 boyutundan yeniden boyutlandırılıyor: $1"
 ],
 "Restrict access to the report": [
  null,
  "Rapora erişimi kısıtla"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Rapora erişimi $0 grubuyla kısıtlar. $1"
 ],
 "Return to installation": [
  null,
  "Kuruluma geri dön"
 ],
 "Return to storage editor": [
  null,
  "Depolama düzenleyicisine dön"
 ],
 "Review and install": [
  null,
  "Gözden geçir ve kur"
 ],
 "Root account has been configured": [
  null,
  "Kök hesabı yapılandırıldı"
 ],
 "Root account is enabled": [
  null,
  "Kök hesabı etkinleştirildi"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Kök hesabı etkinleştirilmiş, ama hiçbir kullanıcı hesabı yapılandırılmamış"
 ],
 "Root password has been set.": [
  null,
  "Kök parolası belirlendi."
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "QR kodunu telefonunuzla tarayın veya ziyaret edin:"
 ],
 "Search for a language": [
  null,
  "Bir dil arayın"
 ],
 "Search for additional software": [
  null,
  "İlave yazılım arayın"
 ],
 "Search for an environment": [
  null,
  "Bir ortam arayın"
 ],
 "Search keyboard layout": [
  null,
  "Bir klavye görünümü arayın"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Disk tabanlı şifreleme kullanarak verilerinizi güvende tutun. Yalnızca yeni bölümler için geçerlidir"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "Select a device": [
  null,
  "Bir aygıt seçin"
 ],
 "Select city": [
  null,
  "Şehir seç"
 ],
 "Select destination": [
  null,
  "Hedefi seç"
 ],
 "Select region": [
  null,
  "Bölge seç"
 ],
 "Selected (top = current)": [
  null,
  "Seçilen (en üst = geçerli)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Seçilen aygıtın biçimi '$0' yeniden biçimlendirilemiyor."
 ],
 "Send us feedback on your installation": [
  null,
  "Kurulumunuz hakkında bize geri bildirim gönderin"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Server is not reachable": [
  null,
  "Sunucuya erişilemiyor"
 ],
 "Set custom hostname": [
  null,
  "Özel ana makine adı ayarla"
 ],
 "Share disk with other operating systems": [
  null,
  "Diski diğer işletim sistemleriyle paylaşın"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Diski diğer işletim sistemleriyle paylaş: $0"
 ],
 "Show AM/PM": [
  null,
  "ÖÖ/ÖS'yi göster"
 ],
 "Show API key": [
  null,
  "API anahtarını göster"
 ],
 "Show PIN": [
  null,
  "PIN kodunu göster"
 ],
 "Show confirmed password": [
  null,
  "Onaylanan parolayı göster"
 ],
 "Show passphrase": [
  null,
  "Parolayı göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Software installation": [
  null,
  "Yazılım kurulumu"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Yazılım kurulumu: Depolama yapılandırması tamamlandı. Yazılım şimdi aygıtınıza kuruluyor."
 ],
 "Software selection": [
  null,
  "Yazılım seçimi"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Devam edebilmeniz için bazı kurulum adımlarının tamamlanması gerekiyor."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Bazı gerekli bölümler eksik: $0"
 ],
 "Space": [
  null,
  "Alan"
 ],
 "Stacktrace": [
  null,
  "Yığın izleme (Stacktrace)"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Storage configuration": [
  null,
  "Depolama yapılandırması"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Depolama yapılandırması: Depolama alanı şu anda yapılandırılıyor."
 ],
 "Storage editor": [
  null,
  "Depolama düzenleyicisi"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Depolama, 'Depolamayı değiştir' seçeneğindeki yapılandırmayı temel alır."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Depolama düzeni, kickstart dosyası tarafından belirlenir. Planlanan bölümlendirme düzeni, özet adımında incelenebilir."
 ],
 "Storage plugin failed": [
  null,
  "Depolama eklentisi başarısız oldu"
 ],
 "Storage requirements not met": [
  null,
  "Depolama gereksinimleri karşılanmadı"
 ],
 "Strong": [
  null,
  "Güçlü"
 ],
 "Successfully installed": [
  null,
  "Başarıyla kuruldu"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 kilidi başarıyla açıldı."
 ],
 "Suggested keyboards": [
  null,
  "Önerilen klavyeler"
 ],
 "Suggested languages": [
  null,
  "Önerilen diller"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System configuration": [
  null,
  "Sistem yapılandırması"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Sistem yapılandırması: Yazılım kurulumu tamamlandı. Sistem şimdi yapılandırılıyor."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda kurulumu beklenmedik bir şekilde durdu."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Aşağıdaki açık hata raporları sizin sorununuzla ilgili olabilir. Lütfen yeni bir rapor oluşturmadan önce bunları inceleyin."
 ],
 "The following user will be created:": [
  null,
  "Şu kullanıcı oluşturulacak:",
  "Şu kullanıcılar oluşturulacak:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Kurulum, $0 kadar disk alanına ihtayç duyar; lâkin, seçilen disklerin kapasitesi sadece $1 kadar."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Kurucu önemli bir hata nedeniyle devam edemiyor."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Kurucu kritik bir hata nedeniyle devam edemiyor.: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Disk şifreleme parolası ayarlandığından beri klavye düzeni değiştirildi. Lütfen parolayı yeniden girin."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Sağladığınız parola ASCII olmayan karakterler içeriyor. Bunları tuşlarken klavye düzenleri arasında geçiş yapamayabilirsiniz."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Seçilen öntanımlı klavye düzeni ASCII karakterlerini desteklemiyor. Lütfen öntanımlı olarak ASCII özellikli bir düzen seçin."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Depolama düzenleyicisi, bölüntü boyutlandırmanıza, silmenize ve oluşturmanıza olanak tanır. Gelişmiş bir araç olarak kullanılması gerekir ve tipik bir kurulumda kullanılması amaçlanmaz."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Bu günlük dosyaları IP adresleri, kullanıcı adları veya diğer sistem ayrıntıları gibi hassas bilgiler içerebilir."
 ],
 "This hostname can't be submitted": [
  null,
  "Bu ana makine adı kaydedilemiyor"
 ],
 "This is unstable, pre-release software": [
  null,
  "Bu kararlı olmayan, sürüm öncesi yazılımdır"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Bu görünüm, sisteminizi önyüklemede açmada kullanılacak"
 ],
 "This may take a moment": [
  null,
  "Bu biraz zaman alabilir"
 ],
 "This will take a few moments": [
  null,
  "Bu biraz zaman alacak"
 ],
 "Time": [
  null,
  "Saat"
 ],
 "Timezone": [
  null,
  "Saat dilimi"
 ],
 "Title": [
  null,
  "Başık"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0 kullanmaya başlamak için sisteminizi yeniden başlatın."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Devam etmek için kurulum yapılacak aygıtları seçin."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Bu seçeneği kullanmak için var olan bölümleri yeniden boyutlandırarak veya kaldırarak en az $0 yer açın."
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0 silinmesi zamanlanamadı"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0 yeniden boyutlandırılması zamanlanamadı"
 ],
 "Undo last action": [
  null,
  "Son eylemi geri al"
 ],
 "Unlock": [
  null,
  "Kilidini aç"
 ],
 "Unlock encrypted devices": [
  null,
  "Şifrelenen aygıtların kilidini aç"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Var olan verileri korumak ve daha fazla kurulum yöntemi göstermek için şifreli bölümlerin kilidini açın."
 ],
 "Use configured storage": [
  null,
  "Yapılandırılan depolamayı kullan"
 ],
 "Use entire disk": [
  null,
  "Tüm diski kullan"
 ],
 "Use free space": [
  null,
  "Serbest alan kullanın"
 ],
 "Use local account": [
  null,
  "Yerel hesabı kullan"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Otomatik bölüntüleme için RAID cihazını kullanın"
 ],
 "User creation": [
  null,
  "Kullanıcı oluşturma"
 ],
 "User name": [
  null,
  "Kullanıcı adı"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Kullanıcı adı yalnızca şunları içerebilir: a-z arası harfler, 0-9 arası rakamlar, eksi işareti $0, nokta işareti $1, alt çizgi işareti $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Kullanıcı adı ayrılmış bir sözcük olmamalıdır"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Kullanıc adları 33 karakterden kısa olmalıdır"
 ],
 "Validating...": [
  null,
  "Doğrulanıyor..."
 ],
 "Weak": [
  null,
  "Zayıf"
 ],
 "Welcome": [
  null,
  "Hoş Geldiniz"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Fedora Linux'e Hoş Geldiniz"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Hoş geldiniz. Haydi $0 kuralım."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Bu hata raporunu gönderdiğinde, bu dosyalar otomatik olarak yüklenecektir: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker ile şifrelenen Windows bölümleri yeniden boyutlandırılamıyor"
 ],
 "You can close this browser window now.": [
  null,
  "Bu tarayıcı penceresini şimdi kapatabilirsiniz."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Burada yeterince yer ayırıp geri kalanını kurucuya bırakabilir veya bölümleri elle ayarlayabilirsiniz."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Bugzilla hesabın ile API anahtarı olulturabilirsin: $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Devam etmek için root hesabını etkinleştirmeniz veya yerel bir kullanıcı hesabı oluşturmanız gerekir."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Otomatik tarih ve saat özelliğini etkinleştirmek için bir ağa bağlı olmanız gerekir."
 ],
 "Your progress will not be saved.": [
  null,
  "İlerlemeniz kaydedilmeyecek."
 ],
 "completed step": [
  null,
  "tamamlanan adım"
 ],
 "current step": [
  null,
  "geçerli adım"
 ],
 "delete": [
  null,
  "sil"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "encrypt": [
  null,
  "şifrele"
 ],
 "encrypted": [
  null,
  "şifrelendi"
 ],
 "extended partition": [
  null,
  "genişletilmiş bölüm"
 ],
 "format as $0": [
  null,
  "$0 olarak biçimlendir"
 ],
 "here": [
  null,
  "burada"
 ],
 "incomplete": [
  null,
  "tamamlanmadı"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "pending step": [
  null,
  "bekleyen adım"
 ],
 "report the issue manually": [
  null,
  "hatayı manuel olarak bildir"
 ],
 "resized from $0": [
  null,
  "yeniden boyutlandırıldı (önceki $0)"
 ],
 "shrink": [
  null,
  "küçült"
 ],
 "shrink to $0": [
  null,
  "$0 olacak şekilde küçült"
 ],
 "transient, will use DHCP": [
  null,
  "geçici, DHCP kullanılacak"
 ],
 "undo": [
  null,
  "geri al"
 ]
});
