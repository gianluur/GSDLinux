cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "unmount": [
  null,
  "smonta"
 ],
 "mount": [
  null,
  "mount"
 ],
 "format": [
  null,
  "formatta"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "filesystem"
 ],
 "partition": [
  null,
  "partizione"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volume"
 ],
 "disk": [
  null,
  "disco"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "disco"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "crittografia"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Gestione delle partizioni"
 ],
 "Managing NFS mounts": [
  null,
  "Gestione dei montaggi NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestione RAID"
 ],
 "Managing LVMs": [
  null,
  "Gestione dei LVM"
 ],
 "Managing physical drives": [
  null,
  "Gestione dei drive fisici"
 ],
 "Managing VDOs": [
  null,
  "Gestione VDO"
 ],
 "Using LUKS encryption": [
  null,
  "Utilizzo crittografia LUKS"
 ],
 "Using Tang server": [
  null,
  "Utilizzo server Tang"
 ]
});
