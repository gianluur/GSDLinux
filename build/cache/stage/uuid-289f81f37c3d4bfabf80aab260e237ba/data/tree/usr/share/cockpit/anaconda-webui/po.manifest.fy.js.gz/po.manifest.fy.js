cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fy",
  "language-direction": "ltr"
 }
});
