cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nb",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
