cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Accounts": [
  null,
  "用户账户"
 ],
 "user": [
  null,
  "用户"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "密码"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "用户名"
 ],
 "login": [
  null,
  "登录"
 ],
 "access": [
  null,
  "访问"
 ],
 "roles": [
  null,
  "角色"
 ],
 "keys": [
  null,
  "密钥"
 ],
 "Managing user accounts": [
  null,
  "管理用户帐户"
 ]
});
