cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "服务"
 ],
 "Terminal": [
  null,
  "终端"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "time": [
  null,
  "时间"
 ],
 "date": [
  null,
  "日期"
 ],
 "restart": [
  null,
  "重启"
 ],
 "shut": [
  null,
  "关闭"
 ],
 "domain": [
  null,
  "域"
 ],
 "machine": [
  null,
  "机器"
 ],
 "operating system": [
  null,
  "操作系统"
 ],
 "os": [
  null,
  "操作系统"
 ],
 "asset tag": [
  null,
  "资产标签"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "电源"
 ],
 "version": [
  null,
  "版本"
 ],
 "host": [
  null,
  "主机"
 ],
 "hardware": [
  null,
  "硬件"
 ],
 "mitigation": [
  null,
  "缓解方案"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "内存"
 ],
 "cpu": [
  null,
  "中央处理器"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "序列"
 ],
 "graphs": [
  null,
  "图表"
 ],
 "metrics": [
  null,
  "指标"
 ],
 "history": [
  null,
  "历史"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "磁盘"
 ],
 "network": [
  null,
  "网络"
 ],
 "cgroups": [
  null,
  "用户组"
 ],
 "performance": [
  null,
  "性能"
 ],
 "Configuring system settings": [
  null,
  "配置系统设置"
 ],
 "service": [
  null,
  "服务"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "目标"
 ],
 "socket": [
  null,
  "套接口"
 ],
 "timer": [
  null,
  "计时器"
 ],
 "path": [
  null,
  "路径"
 ],
 "unit": [
  null,
  "单元"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "引导"
 ],
 "mask": [
  null,
  "屏蔽"
 ],
 "unmask": [
  null,
  "取消屏蔽"
 ],
 "enable": [
  null,
  "启用"
 ],
 "disable": [
  null,
  "禁用"
 ],
 "Managing services": [
  null,
  "管理服务"
 ],
 "journal": [
  null,
  "日志"
 ],
 "warning": [
  null,
  "警告"
 ],
 "error": [
  null,
  "错误"
 ],
 "debug": [
  null,
  "故障调试"
 ],
 "crash": [
  null,
  "崩溃"
 ],
 "coredump": [
  null,
  "核心转储"
 ],
 "Reviewing logs": [
  null,
  "回顾日志"
 ],
 "console": [
  null,
  "控制台"
 ],
 "command": [
  null,
  "命令"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
