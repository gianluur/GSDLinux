cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Journal": [
  null,
  "ჟურნალი"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "Hardware information": [
  null,
  "ინფორმაცია აპარატურის შესახებ"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "Default": [
  null,
  "ნაგულისხმები"
 ],
 "Light": [
  null,
  "ღია"
 ],
 "Dark": [
  null,
  "ბლენი"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "Search": [
  null,
  "ძებნა"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "Trust and add host": [
  null,
  "ჰოსტის ნდობა და დამატება"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"ჰოსტის ნდობა და დამატებას\", ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "მიღებული ანაბეჭდის გაზიარება, ელფოსტის ჩათვლით, უსაფრთხოა. თუ თქვენ სხვას სთხოვთ, თქვენი სახელით გადაამოწმოს, მათ, შედეგების გამოგზავნა ნებისმიერი მეთოდით შეუძლიათ."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "Verify fingerprint": [
  null,
  "ანაბეჭდის გადამოწმება"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "გაუშვით ეს ბრძანება სანდო ქსელით ან ფიზიკურად, დაშორებულ მანქანაზე:"
 ],
 "The fingerprint should match:": [
  null,
  "ანაბეჭდების უნდა ემთხვეოდეს:"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "Permission denied": [
  null,
  "წვდომა აკრძალულია"
 ],
 "Clear input value": [
  null,
  "შეყვანილი მნიშვნელობის გასუფთავება"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "Create $0": [
  null,
  "$0-ის შექმნა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ადმინისტრატორის წვდომის მიღების მეთოდები (sudo -A, pkexec) ხელმისაწვდომი არაა."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Unknown host: $0": [
  null,
  "უცნობი ჰოსტი: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი."
 ],
 "SSH key login": [
  null,
  "SSH გასაღებით შესვლა"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit-ის შეცდომის კოდი $0"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Error during initialization": [
  null,
  "შეცდომა ინიციალიზაციის მიმდინარეობისას"
 ],
 "Failed": [
  null,
  "ჩავარდა"
 ],
 "Home": [
  null,
  "საწყისი"
 ],
 "Downloads": [
  null,
  "გადმოწერები"
 ],
 "Not a directory": [
  null,
  "საქაღალდე არაა"
 ],
 "All files": [
  null,
  "ყველა ფაილი"
 ],
 "Recent": [
  null,
  "უახლესი"
 ],
 "No recent directories": [
  null,
  "უახლესი საქაღალდეების გარეშე"
 ],
 "No recent files": [
  null,
  "უახლესი ფაილების გარეშე"
 ],
 "Type to filter": [
  null,
  "გასაფილტრად აკრიფეთ"
 ],
 "File chooser actions": [
  null,
  "ფაილის ამრჩევის ქმედებები"
 ],
 "Open in file browser": [
  null,
  "გახსნა ფაილების ბრაუზერში"
 ],
 "Hide hidden files": [
  null,
  "დამალული ფაილების დამალვა"
 ],
 "Show hidden files": [
  null,
  "დამალული ფაილების ჩვენება"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Clear filters": [
  null,
  "ფილტრების გასუფთავება"
 ],
 "Directory is empty": [
  null,
  "საქაღალდე ცარიელია"
 ],
 "Directory has no sub-directories": [
  null,
  "საქაღალდეს ქვესაქაღალდეები არ აქვს"
 ],
 "This directory contains only hidden files": [
  null,
  "ეს საქაღალდე, მხოლოდ, დამალულ ფაილებს შეიცავს"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "Folder": [
  null,
  "საქაღალდე"
 ],
 "File": [
  null,
  "ფაილი"
 ],
 "Copy to clipboard": [
  null,
  "ბუფერში კოპირება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Select an option": [
  null,
  "აირჩიეთ პარამეტრი"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "$0 is not a directory": [
  null,
  "$0 საქაღალდე არაა"
 ],
 "$0 does not exist": [
  null,
  "$0 არ არსებობს"
 ],
 "Font size": [
  null,
  "ფონტის ზომა"
 ],
 "Decrease by one": [
  null,
  "ერთით შემცირება"
 ],
 "Increase by one": [
  null,
  "ერთით გაზრდა"
 ],
 "Appearance": [
  null,
  "გარეგნობა"
 ],
 "Black": [
  null,
  "შავი"
 ],
 "White": [
  null,
  "თეთრი"
 ],
 "Reset": [
  null,
  "საწყის მნიშვნელობებზე დაბრუნება"
 ],
 "Unable to open directory": [
  null,
  "საქაღალდის გახსნა შეუძლებელია"
 ],
 "Running process prevents directory change": [
  null,
  "გაშვებული პროცესი ხელს უშლის საქაღალდის შეცვლას"
 ],
 "Change directory": [
  null,
  "საქაღალდის შეცვლა"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "საქაღალდის შეცვლა ამჟამად გაშვებულ პროცესს ნაძალადევად დაასრულებს. პროცესი, შეგიძლიათ, ხელით, ტერმინალიდანაც მოკლათ."
 ],
 "Terminal not available": [
  null,
  "ტერმინალი ხელმისაწვდომი არაა"
 ],
 "This browser does not support WebGL2.": [
  null,
  "ამ ბრაუზერს WebGL2-ის მხარდაჭერა არ აქვს."
 ],
 "unknown": [
  null,
  "უცნობი"
 ],
 "Shutdown": [
  null,
  "გამორთვა"
 ],
 "running $0": [
  null,
  "$0-ის გაშვება"
 ],
 "Current boot": [
  null,
  "მიმდინარე ჩატვირთვა"
 ],
 "Previous boot": [
  null,
  "წინა ჩატვირთვა"
 ],
 "Last 24 hours": [
  null,
  "ბოლო 24 საათი"
 ],
 "Last 7 days": [
  null,
  "ბოლო 7 დღე"
 ],
 "Only emergency": [
  null,
  "მხოლოდ გადაუდებელ შემთხვევაში"
 ],
 "Alert and above": [
  null,
  "გაფრთხილება და უარესები"
 ],
 "Critical and above": [
  null,
  "კრიტიკული და ზემოთ"
 ],
 "Error and above": [
  null,
  "შეცდომა და ზემოთ"
 ],
 "Warning and above": [
  null,
  "წინასწარი გაფრთხილებები და ზემოთ"
 ],
 "Notice and above": [
  null,
  "გაფრთხილება და ზემოთ"
 ],
 "Info and above": [
  null,
  "ინფორმაცია და ზემოთ"
 ],
 "Debug and above": [
  null,
  "გამართვა და ზემოთ"
 ],
 "Toggle filters": [
  null,
  "ფილტრების ჩართ/გამორთ"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Identifier": [
  null,
  "იდენტიფიკატორი"
 ],
 "Filters": [
  null,
  "ფილტრები"
 ],
 "Pause": [
  null,
  "პაუზა"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "თარიღის სპეციფიკაციები უნდა იყოს YYYY-MM-DD ფორმატის სთ:მთ:წ.წ. ალტერნატიულად გაგებულია სტრიქონები 'yesterday'(გუშინ), 'today'(დღეს, 'tomorrow'(ხვალ). 'now' (ახლა) ეხება მიმდინარე დროს. და ბოლოს, შედარებითი დრო შეიძლება იყოს მითითებული, პრეფიქსით '-' ან '+'"
 ],
 "Since": [
  null,
  "საწყისი დრო"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "მხოლოდ მითითებული თარიღის შემდეგი შეტყობინებების ჩვენება."
 ],
 "Until": [
  null,
  "დასასრულის დრო"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "მხოლოდ მითითებულ თარიღზე ძველი შეტყობინებების ჩვენება."
 ],
 "Boot": [
  null,
  "ჩატვირთვა"
 ],
 "Show messages from a specific boot.": [
  null,
  "შეტყობინებების მითითებული ჩატვირთვიდან ჩვენება."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "დაამატებს თანხვედრას '_BOOT_IID='-თვის. თუ მითითებული არაა, გამოყენებყლი იქნება მიმდინარე ჩატვრთვა. თუ ჩატვირთვის ID გამოტოვებულია, გამოყენებული იქნება დადებითი წანაცვლება ჟურნალის დასაწყისიდან და გამოტანილი იქნება პირველი რამდენიმე ჩანაწერი. ამიტომ, 1 ნიშნავს პირველ ჩატვირთვას, 2 მეორეს და ა.შ. მაგრამ -0 ბოლო ჩატვირთვაა, -1 ბოლოს წინა და ა.შ."
 ],
 "Unit": [
  null,
  "ერთეული"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "system-ის მითითებული სერვისის შეტყობინებების ჩვენება."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "დაამატებს თანხვედრას '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' და 'UNIT='-თან მითითებული ერთეულის ჟურნალის შეტყობინებებში საძებნად. შეიძლება შეიცავდეს მეტ ერთეულსაც, გამოყოფილს მძიმეებით."
 ],
 "Free-form search": [
  null,
  "ძებნის თავისუფალი ფორმა"
 ],
 "Show messages containing given string.": [
  null,
  "იმ შეტყობინებების ჩვენება, რომლებიც მითითებულ სტრიქონს შეიცავენ."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ჟურნალის შეტყობინებებში შესაძლებელია ნებისმიერი სტრიქონის გაფიტვრა. სტრიქონი ასევე შეიძლება მოიძებნოს რეგულარული გამოსახულებებითაც. ასევე არსებობს ჟურნალის ველების მიხედვით გაფილტვრის მხარდაჭერა. წარმოადგენენ ჰარეთი გაყოფილ მნისვნელობებს FIELD=VALUE ფორმაში, სადაც მნიშვნელობები შეიძლება წარმოადგენდეს მძიმით გამოყოფილ შესაძლო მნიშვნელობების სიას."
 ],
 "journalctl manpage": [
  null,
  "journalctl-ის მინი-დოკუმენტაცია"
 ],
 "Successfully copied to clipboard": [
  null,
  "წარმატებით დაკოპირდა ბუფერში"
 ],
 "Create timer": [
  null,
  "ტაიმერის შექმნა"
 ],
 "Edit timer": [
  null,
  "ტაიმერის ჩასწორება"
 ],
 "Timer creation failed": [
  null,
  "ტაიმერის შექმნის შეცდომა"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "ტაიმერისთვის გაშვების პირობების მიღება ჩავარდა"
 ],
 "Failed to get the timer command": [
  null,
  "ტაიმერის ბრძანების მიღება ჩავარდა"
 ],
 "This field cannot be empty": [
  null,
  "ველი არ შეიძლება ცარიელი იყოს"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "დაშვებულია მხოლოდ ლათინური ანბანი, ციფრები, :, _ და @"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Shell command": [
  null,
  "გარსის ბრძანება"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "ეს ბრძანება შესრულდება პროგრამით /bin/sh."
 ],
 "Trigger": [
  null,
  "ტრიგერი"
 ],
 "At specific time": [
  null,
  "მითითებულ დროს"
 ],
 "After system boot": [
  null,
  "სისტემის ჩატვირთვის შემდეგ"
 ],
 "Seconds": [
  null,
  "წამი"
 ],
 "Minutes": [
  null,
  "წუთი"
 ],
 "Hours": [
  null,
  "საათი"
 ],
 "Weeks": [
  null,
  "კვირა"
 ],
 "Delay must be a number": [
  null,
  "დაყოვნება რიცხვი უნდა იყოს"
 ],
 "Repeat": [
  null,
  "გამეორება"
 ],
 "Don't repeat": [
  null,
  "არ გაიმეორო"
 ],
 "Minutely": [
  null,
  "წთ"
 ],
 "Hourly": [
  null,
  "საათობრივ"
 ],
 "Daily": [
  null,
  "დღიურად"
 ],
 "Weekly": [
  null,
  "კვირაში ერთხელ"
 ],
 "Monthly": [
  null,
  "თვეში ერთხელ"
 ],
 "Yearly": [
  null,
  "წლიურად"
 ],
 "Run at": [
  null,
  "გაშვების დრო"
 ],
 "At second": [
  null,
  "წმ"
 ],
 "At minute": [
  null,
  "1 წთ"
 ],
 "Run on": [
  null,
  "გასაშვები პლატფორმა"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "წუთი უნდა იყოს რიცხვი შუალედში 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "წამი უნდა იყოს რიცხვი შუალედში 0-59"
 ],
 "Repeat weekly": [
  null,
  "კვირაში ერთხელ გამეორება"
 ],
 "Mondays": [
  null,
  "ორშაბათობით"
 ],
 "Tuesdays": [
  null,
  "სამშაბათობით"
 ],
 "Wednesdays": [
  null,
  "ოთხშაბათობით"
 ],
 "Thursdays": [
  null,
  "ხუთშაბათობით"
 ],
 "Fridays": [
  null,
  "კვირაობით"
 ],
 "Saturdays": [
  null,
  "შაბათობით"
 ],
 "Sundays": [
  null,
  "კვირაობით"
 ],
 "Repeat monthly": [
  null,
  "თვეში ერთხელ გამეორება"
 ],
 "1st": [
  null,
  "პირველი"
 ],
 "2nd": [
  null,
  "მეორე"
 ],
 "3rd": [
  null,
  "მესამე"
 ],
 "4th": [
  null,
  "მეოთხე"
 ],
 "5th": [
  null,
  "მეხუთე"
 ],
 "6th": [
  null,
  "მეექვსე"
 ],
 "7th": [
  null,
  "მეშვიდე"
 ],
 "8th": [
  null,
  "მერვე"
 ],
 "9th": [
  null,
  "მეცხრე"
 ],
 "10th": [
  null,
  "მეათე"
 ],
 "11th": [
  null,
  "მეთერთმეტე"
 ],
 "12th": [
  null,
  "მეთორმეტე"
 ],
 "13th": [
  null,
  "13-ე"
 ],
 "14th": [
  null,
  "14-ე"
 ],
 "15th": [
  null,
  "15-ე"
 ],
 "16th": [
  null,
  "16-ე"
 ],
 "17th": [
  null,
  "17-ე"
 ],
 "18th": [
  null,
  "18-ე"
 ],
 "19th": [
  null,
  "19-ე"
 ],
 "20th": [
  null,
  "20-ე"
 ],
 "21th": [
  null,
  "21-ე"
 ],
 "22th": [
  null,
  "22-ე"
 ],
 "23th": [
  null,
  "23-ე"
 ],
 "24th": [
  null,
  "24-ე"
 ],
 "25th": [
  null,
  "25-ე"
 ],
 "26th": [
  null,
  "26-ე"
 ],
 "27th": [
  null,
  "27-ე"
 ],
 "28th": [
  null,
  "28-ე"
 ],
 "29th": [
  null,
  "29-ე"
 ],
 "30th": [
  null,
  "30-ე"
 ],
 "31st": [
  null,
  "31-ე"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Unclean shutdown": [
  null,
  "არასუფთა გამორთვა"
 ],
 "View logs": [
  null,
  "ჟურნალის ნახვა"
 ],
 "Dismiss": [
  null,
  "მოცილება"
 ],
 "Scheduled poweroff at $0": [
  null,
  "გათიშვის დროა $0"
 ],
 "Cancel poweroff": [
  null,
  "გამორთვის გაუქმება"
 ],
 "Scheduled reboot at $0": [
  null,
  "გადატვირთვის დროა $0"
 ],
 "Cancel reboot": [
  null,
  "გადატვირთვის გაუქმება"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "Set hostname": [
  null,
  "ჰოსტის სახელის დაყენება"
 ],
 "Configuration": [
  null,
  "მორგება"
 ],
 "Hostname": [
  null,
  "ჰოსტის სახელი"
 ],
 "System time": [
  null,
  "სისტემური დრო"
 ],
 "Domain": [
  null,
  "დომენი"
 ],
 "Performance profile": [
  null,
  "წარმადობის პროფილი"
 ],
 "Secure shell keys": [
  null,
  "SSH-ის გასაღებები"
 ],
 "Show fingerprints": [
  null,
  "ანაბეჭდების ჩვენება"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh-ის ჰოსტის გასაღებების სიის გამოტანის შეცდომა: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH გასაღებების ჩატვირთვის შეცდომა"
 ],
 "Error message": [
  null,
  "შეცდომის შეტყობინება"
 ],
 "Loading keys...": [
  null,
  "გასაღებების ჩატვირთვა..."
 ],
 "No host keys found.": [
  null,
  "ჰოსტის გასაღებები ნაპოვნი არაა."
 ],
 "Machine SSH key fingerprints": [
  null,
  "მანქანის SSH გასაღების ანაბეჭდები"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "ჯოსტის რეალური სახელი 64 სიმბოლოზე დიდი არ უნდა იყოს"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "ჰოსტის რეალური სახელი შეიძლება მხოლოდ შეიცავდეს პატარა სიმბოლოებს, ციფრებს, ტირეებს და ჰარეებს"
 ],
 "Change host name": [
  null,
  "ჰოსტის სახელის შეცვლა"
 ],
 "Pretty host name": [
  null,
  "ჰოსტის ლამაზი სახელი"
 ],
 "Real host name": [
  null,
  "ჰოსტის რეალური სახელი"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "მომხმარებელს '$0' კრიპტოგრაფიის პოლიტიკის შეცვლის უფლება არ აქვს"
 ],
 "Cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკა"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "რეკომენდებული, დაცული პარამეტრები მიმდინარე დაცვის მოდელისთვის."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT-ი SHA-1 ხელმოწერის გადამოწმებით დაშვებულია."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "მაღალი ურთიერთკავშირი შეტევის გაზრდილი ზედაპირის ხარჯზე."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY-ი Active Directory-სთან სამუშაოდ."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS რეჟიმში ჩატვირთვისას მხოლოდ დადასტურებული ალგორითმების გამოყენება."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS დამატებითი საერთო პირობის შეზღუდვებით."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "იცავს მოსალოდნელი უახლოესი მომავალი თავდასხმებისგან თავსებადობის ხარჯზე."
 ],
 "Custom cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკის მორგება"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "კრიპტოგრაფიის წესები წარმოადგენს სისტემურ კომპონენტს, რომელიც ძირითადი კრიპტოგრაფიული ქვესისტემების, TLS/IPSec/SSH/DNNSEC და kerberos-ის კონფიგურაციას უზრუნველყოფს."
 ],
 "Change cryptographic policy": [
  null,
  "კრიპტოგრაფიული პოლიტიკის შეცვლა"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "ახალი წესების გადატარება... შეიძლება რამდენიმე წუთი დასჭირდეს."
 ],
 "Reapply and reboot": [
  null,
  "თავიდან გადატარება და გადატვირთვა"
 ],
 "Apply and reboot": [
  null,
  "გადატარება და გადატვირთვა"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS-ი სწორად არაა ჩართული"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "კრიპტოგრაფიის პოლიტიკა არამდგრადია"
 ],
 "Review cryptographic policy": [
  null,
  "კრიპტოგრაფიის პოლიტიკის გადახედვა"
 ],
 "System information": [
  null,
  "ინფორმაცია სისტემის შესახებ"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "Machine ID": [
  null,
  "მანქანის ID"
 ],
 "Up since": [
  null,
  "აქტიურია საიდან"
 ],
 "View hardware details": [
  null,
  "აპარატურის დეტალების ნახვა"
 ],
 "Last successful login:": [
  null,
  "ბოლო წარმატებული შესვლა:"
 ],
 "$0 failed login attempt": [
  null,
  "შესვლის $0 წარუმატებელი მცდელობა",
  "შესვლის $0 ცალი წარუმატებელი მცდელობა"
 ],
 "View login history": [
  null,
  "შესვლების ისტორიის ნახვა"
 ],
 "recommended": [
  null,
  "რეკომენდებულია"
 ],
 "inconsistent": [
  null,
  "არამდგრადი"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "დომენში შესასვლელად საჭიროა realmd-ის დაყენება"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "ამ სისტემაზე realmd-ს არარსებობის გამო დომენში ჩართვა შეუძლებელია"
 ],
 "Joining this domain is not supported": [
  null,
  "დომენში შესვლის მხარდაჭერა არ არსებობს"
 ],
 "Login format": [
  null,
  "შესვლის ფორმატი"
 ],
 "Server software": [
  null,
  "სერვერული პროგრამები"
 ],
 "Client software": [
  null,
  "კლიენტი პროგრამა"
 ],
 "Leave domain": [
  null,
  "დომენიდან გასვლა"
 ],
 "Leave $0": [
  null,
  "$0-დან გასვლა"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "დომენიდან გამოსვლის შემდეგ ამ მანქანაზე შესვლა შეეძლებათ მხოლოდ ლოკალური ანგარიშების მქონე მომხმარებლებს. ასევე შეიძლება შეფერხებით იმუშაოს სხვა ისეთმა სერვისებმა, როგორიცაა მაგალითად DNS და შეიცვლება სანდო CA-ები."
 ],
 "Validating address": [
  null,
  "მისამართის დადასტურება"
 ],
 "Contacted domain": [
  null,
  "დომენთან კავშირი წარმატებულია"
 ],
 "Domain could not be contacted": [
  null,
  "დომენთან კავშირის შეცდომა"
 ],
 "Domain is not supported": [
  null,
  "დომენის მხარდაჭერა არ არსებობს"
 ],
 "Domain address": [
  null,
  "დომენის მისამართი"
 ],
 "Domain administrator name": [
  null,
  "დომენის ადმინისტრატორის სახელი"
 ],
 "Domain administrator password": [
  null,
  "დომენის ადმინისტრატორის პაროლი"
 ],
 "Joining": [
  null,
  "შეერთება"
 ],
 "Join": [
  null,
  "შეერთება"
 ],
 "This may take a while": [
  null,
  "საკმაო დრო დასჭირდება"
 ],
 "Not permitted to configure realms": [
  null,
  "realm-ების მორგების წვდომა აკრძალულია"
 ],
 "Join domain": [
  null,
  "დომენზე დაერთება"
 ],
 "Install realmd support": [
  null,
  "Realmd-ის მხარდაჭერის დაყენება"
 ],
 "$0 disk is failing": [
  null,
  "$0 დისკი კვდება",
  "$0 დისკი კვდება"
 ],
 "Connected to Insights": [
  null,
  "მიერთებულია Insights-ისთან"
 ],
 "Not connected to Insights": [
  null,
  "არაა მიერთებული Insights-თან"
 ],
 "Health": [
  null,
  "ჯანმრთელობა"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU-დან",
  "$0 ცალი CPU-დან"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "View metrics and history": [
  null,
  "გრაფიკებისა და ისტორიის ნახვა"
 ],
 "Tuned is not available": [
  null,
  "Tuned-ი ხელმიუწვდომელია"
 ],
 "Tuned is not running": [
  null,
  "Tuned-ი გაშვებული არაა"
 ],
 "Tuned is off": [
  null,
  "Tuned გამორთულია"
 ],
 "This system is using the recommended profile": [
  null,
  "ეს სისტემა რეკომენდებულ პროფილს იყენებს"
 ],
 "This system is using a custom profile": [
  null,
  "ეს სისტემა მორგებულ პროფილს იყენებს"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned-თან კავშირის შეცდომა"
 ],
 "Failed to enable tuned": [
  null,
  "tuned-ის ჩართვის შეცდომა"
 ],
 "Failed to disable tuned": [
  null,
  "tuned-ის გამორთვის შეცდომა"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned-ის პროფილის გამორთვის შეცდომა"
 ],
 "Failed to switch profile": [
  null,
  "პროფილის გადართვის შეცდომა"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Disable tuned": [
  null,
  "tuned-ის გამორთვა"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned-ის გაშვების შეცდომა"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned წარმოადგენს სერვისს, რომელიც უთვალთვალებს თქვენს სისტემას და აოპტიმიზირებს მას ზოგიერთიდატვირთვისთვის. Tuned-ის ბირთვის წარმოადგენს მისი პროფილები, რომლებიც სისტემას სხვადასხვა დატვირთვას ავტომატურად მოარგებს."
 ],
 "Change performance profile": [
  null,
  "წარმადობის პროფილის შეცვლა"
 ],
 "Change profile": [
  null,
  "პროფილის შეცვლა"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd-ის ჩასწორება"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd-ში ცვლილებების შეტანის შეცდომა"
 ],
 "Save changes": [
  null,
  "ცვლილებების შენახვა"
 ],
 "Edit motd": [
  null,
  "motd ფაილის ჩასწორება"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Bad setting": [
  null,
  "ცუდი პარამეტრი"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Merged": [
  null,
  "შერწყმული"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "Reloading": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Failed to start": [
  null,
  "გაშვების შეცდომა"
 ],
 "Maintenance": [
  null,
  "სარემონტო"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Linked": [
  null,
  "მიბმული"
 ],
 "Alias": [
  null,
  "მეტსახელი"
 ],
 "Masked": [
  null,
  "შენიღბული"
 ],
 "Static": [
  null,
  "სტატიკური"
 ],
 "Invalid": [
  null,
  "არასწორი"
 ],
 "Indirect": [
  null,
  "არაპირდაპირი"
 ],
 "Generated": [
  null,
  "გენერირებული"
 ],
 "Transient": [
  null,
  "შუალედური"
 ],
 "Bad": [
  null,
  "ცუდი"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd-ის სიგნალების გამოწერის შეცდომა: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus-თან დაკავშირების შეცდომა: $0"
 ],
 "Listing units failed: $0": [
  null,
  "სერვისების სიის გამოტანის შეცდომა: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 სერვისის შეცდომა",
  "$0 ცალი სერვისის შეცდომა"
 ],
 "Loading of units failed": [
  null,
  "სერვისების ჩატვირთვის შეცდომა"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Listing units": [
  null,
  "სერვისების სია"
 ],
 "Filter by name or description": [
  null,
  "სახელით ან აღწერით გაფილტვრა"
 ],
 "Active state": [
  null,
  "აქტიური მდგომარეობა"
 ],
 "File state": [
  null,
  "ფაილის მდგომარეობა"
 ],
 "$0 filters applied": [
  null,
  "გადატარებულია $0 ფილტრი"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "მომხმარებელს '$0' არ აქვს უფლება შეცვალოს პროცესორის უსაფრთხოების პროგრამული გადაწყვეტილების პარამეტრები"
 ],
 "Mitigations": [
  null,
  "დაცვის გეგმები"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS-ის ვერსია"
 ],
 "BIOS date": [
  null,
  "BIOS-ის თარიღი"
 ],
 "CPU security": [
  null,
  "CPU უსაფრთხოება"
 ],
 "Disable simultaneous multithreading": [
  null,
  "მრავალნაკადიანობის გამორთვა"
 ],
 "Read more...": [
  null,
  "მეტის წაკითხვა..."
 ],
 "Save and reboot": [
  null,
  "შენახვა და გადატვირთვა"
 ],
 "CPU security toggles": [
  null,
  "CPU-ის უსაფრთხოების გადამრთველები"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "პროცესორის შეცდომების პროგრამულ გასწორებას შეუძლია თავიდან აგარიდოთ მასთან დაკავშირებული პრობლემები. მაგრამ ამ პაჩებს აქვთ გვერდითი ეფექტი - ისინი აგდებენ წარმადობას. ამ პარამეტრის ცვლილების შედეგებზე პასუხს თქვენ აგებთ."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "კლასი"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "Slot": [
  null,
  "სლოტი"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "მეხსიერების ტექნოლოგია"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Rank": [
  null,
  "რანგი"
 ],
 "Speed": [
  null,
  "სიჩქარე"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "მეხსიერების ინფორმაციის ნახვას ადმინისტრირების წვდომა სჭირდება."
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "Failed to fetch logs": [
  null,
  "ჟურნალის გამოთხოვნის შეცდომა"
 ],
 "Clear all filters": [
  null,
  "ყველა ფილტრის გასუფთავება"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "მიმდინარე ფილტრების კომბინაციის ჟურნალში ჩანაწერების მოძებნა შეუძლებელია."
 ],
 "No logs found": [
  null,
  "ჟურნალი ცარიელია"
 ],
 "Load earlier entries": [
  null,
  "ადრინდელი ელემენტების ჩატვირთვა"
 ],
 "You may try to load older entries.": [
  null,
  "სცადეთ ჩატვირთოთ ძველი ელემენტები."
 ],
 "Allow running (unmask)": [
  null,
  "გაშვების ნების დართვა (ნიღბის მოხსნა)"
 ],
 "Reload": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Restart": [
  null,
  "გადატვირთვა"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Clear 'Failed to start'": [
  null,
  "'გაშვების შეცდომა'-ის გასუფთავება"
 ],
 "Mask service": [
  null,
  "სერვისის დამალვა"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "სერვისის შენიღბვა კრძალავს მასზე დამოკიდებული ყველა სერვისის გაშვებას. ამას იმაზე მეტი ეფექტი შეიძლება ჰქონეს, ვიდრე თქვენ გგონიათ. გთხოვთ დაადასტუროთ, რომ გნებავთ ამის გაკეთება."
 ],
 "Disallow running (mask)": [
  null,
  "გაშვების აკრძალვა (შენიღბვა)"
 ],
 "Unpin unit": [
  null,
  "ერთეულის ჩამოხსნა"
 ],
 "Pin unit": [
  null,
  "მიჭიკარტება"
 ],
 "Additional actions": [
  null,
  "დამატებითი ქმედებები"
 ],
 "Note": [
  null,
  "არცერთი"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "ერთეული პირდაპირი ჩართვისთვის განკუთვნილი არაა."
 ],
 "Forbidden from running": [
  null,
  "გაშვება აკრძალულია"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Active since ": [
  null,
  "აქტიურია "
 ],
 "Required by ": [
  null,
  "სჭირდება "
 ],
 "Read-only": [
  null,
  "მხოლოდ-წასაკითხად"
 ],
 "Requires administration access to edit": [
  null,
  "ჩასასწორებლად საჭიროა ადმინისტრატორის წვდომა"
 ],
 "Automatically starts": [
  null,
  "ავტომატურად გაეშვება"
 ],
 "Updating status...": [
  null,
  "სტატუსის განახლება..."
 ],
 "Stop and disable": [
  null,
  "გაჩერება და გამორთვა"
 ],
 "Start and enable": [
  null,
  "ჩართვა და გაშვება"
 ],
 "Failed to load unit": [
  null,
  "ერთეულის ჩატვირთვის შეცდომა"
 ],
 "View all services": [
  null,
  "ყველა სერვისის ნახვა"
 ],
 "Triggers": [
  null,
  "ტრიგერები"
 ],
 "Triggered by": [
  null,
  "დამტრიგერებელი"
 ],
 "Requires": [
  null,
  "სჭირდება"
 ],
 "Requisite": [
  null,
  "მოთხოვნა"
 ],
 "Wants": [
  null,
  "უნდა"
 ],
 "Binds to": [
  null,
  "ებმება"
 ],
 "Part of": [
  null,
  "წარმოადგენს ნაწილს"
 ],
 "Required by": [
  null,
  "სჭირდება"
 ],
 "Requisite of": [
  null,
  "ვის საჭიროებასა წარმოადგენს"
 ],
 "Wanted by": [
  null,
  "სჭირდება"
 ],
 "Bound by": [
  null,
  "მიბმულია"
 ],
 "Consists of": [
  null,
  "შედგება"
 ],
 "Conflicts": [
  null,
  "კონფლიქტები"
 ],
 "Conflicted by": [
  null,
  "კონფლიქტშია"
 ],
 "Before": [
  null,
  "წინ"
 ],
 "After": [
  null,
  "შემდეგ"
 ],
 "On failure": [
  null,
  "შეცდომის შემთხვევაში"
 ],
 "Propagates reload to": [
  null,
  "გადატვირთვა გავრცელდება"
 ],
 "Reload propagated from": [
  null,
  "გადატვირთვის წყარო"
 ],
 "Joins namespace of": [
  null,
  "ზონაში შეერთება"
 ],
 "Condition $0=$1 was not met": [
  null,
  "პირობა $0=$1 არ შესრულდა"
 ],
 "Deletion will remove the following files:": [
  null,
  "ასევე წაიშლება შემდეგი ფაილები:"
 ],
 "Pinned unit": [
  null,
  "მიჭიკარტებული"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Path": [
  null,
  "ბილიკი"
 ],
 "Listen": [
  null,
  "მოსმენა"
 ],
 "Container": [
  null,
  "კონტეინერი"
 ],
 "View Podman container": [
  null,
  "Podman-ის კონტეინერის ნახვა"
 ],
 "Condition failed": [
  null,
  "პირობის შეცდომა"
 ],
 "Show more relationships": [
  null,
  "მეტი ნათესაობის ჩვენება"
 ],
 "Show relationships": [
  null,
  "ურთიერთობების ჩვენება"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Timer deletion failed": [
  null,
  "ტაიმერის წაშლის შეცდომა"
 ],
 "Targets": [
  null,
  "სამიზნეები"
 ],
 "Sockets": [
  null,
  "სოკეტები"
 ],
 "Timers": [
  null,
  "ტაიმერები"
 ],
 "Paths": [
  null,
  "ბილიკი"
 ],
 "Go to $0": [
  null,
  "$0-ზე გადასვლა"
 ],
 "Journal entry not found": [
  null,
  "ჟურნალის ერთეული ნაპოვნი არაა"
 ],
 "Journal entry": [
  null,
  "ჟურნალის ელემენტი"
 ],
 "Entry at $0": [
  null,
  "$0-ში ჩაწერა"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Loading unit failed": [
  null,
  "სერვისების ჩატვირთვის შეცდომა"
 ],
 "Service logs": [
  null,
  "სერვერის ჟურნალი"
 ],
 "No log entries": [
  null,
  "ჟურნალის ცარიელია"
 ],
 "Systemd units": [
  null,
  "Systemd unit-ები"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "თქვენს ფილტრს შედეგები არ აქვს. შედეგების საჩვენებლად გაასუფთავეთ ფილტრები."
 ],
 "Does not automatically start": [
  null,
  "არ გაეშვება ავტომატურად"
 ],
 "Cannot be enabled": [
  null,
  "ვერ ჩაირთვება"
 ],
 "Web console is running in limited access mode.": [
  null,
  "ვებ კონსოლი გაშვებულია შეზღუდული წვდომის რეჟიმში."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ. დამპის მხარდაჭერილი სამიზნეებია: \"local\" (დისკი), \"ssh\" და \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$0-დან $1-ზე"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0-დან"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0-ზე"
 ],
 "dialog-title\u0004Domain": [
  null,
  "დომენი"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "დომენში შესვლა"
 ]
});
