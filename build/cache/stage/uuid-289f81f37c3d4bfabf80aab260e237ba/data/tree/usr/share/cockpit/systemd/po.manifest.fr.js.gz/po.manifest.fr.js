cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Services"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "time": [
  null,
  "heure"
 ],
 "date": [
  null,
  "date"
 ],
 "restart": [
  null,
  "redémarrer"
 ],
 "shut": [
  null,
  "fermer"
 ],
 "domain": [
  null,
  "domaine"
 ],
 "machine": [
  null,
  "machine"
 ],
 "operating system": [
  null,
  "système d’exploitation"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "Étiquette d’actif"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "puissance"
 ],
 "version": [
  null,
  "version"
 ],
 "host": [
  null,
  "hôte"
 ],
 "hardware": [
  null,
  "matériel"
 ],
 "mitigation": [
  null,
  "mitigation"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "mémoire"
 ],
 "cpu": [
  null,
  "processeur"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "série"
 ],
 "graphs": [
  null,
  "graphiques"
 ],
 "metrics": [
  null,
  "métriques"
 ],
 "history": [
  null,
  "historique"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "disques"
 ],
 "network": [
  null,
  "réseau"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "performance"
 ],
 "Configuring system settings": [
  null,
  "Modification des paramètres système"
 ],
 "service": [
  null,
  "service"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cible"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "minuteur"
 ],
 "path": [
  null,
  "chemin"
 ],
 "unit": [
  null,
  "unité"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "boot"
 ],
 "mask": [
  null,
  "masque"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "activer"
 ],
 "disable": [
  null,
  "désactiver"
 ],
 "Managing services": [
  null,
  "Gestion des services"
 ],
 "journal": [
  null,
  "journal"
 ],
 "warning": [
  null,
  "avertissement"
 ],
 "error": [
  null,
  "erreur"
 ],
 "debug": [
  null,
  "déboguer"
 ],
 "crash": [
  null,
  "plantage"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "Révision des journaux"
 ],
 "console": [
  null,
  "console"
 ],
 "command": [
  null,
  "commande"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
