cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "th",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
