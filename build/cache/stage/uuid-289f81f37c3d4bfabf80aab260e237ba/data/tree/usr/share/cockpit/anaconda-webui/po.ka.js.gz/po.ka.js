cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 შეცდომა"
 ],
 "$0 installation": [
  null,
  "$0-ის დაყენება"
 ],
 "$0 installer": [
  null,
  "$0-ის დაყენების პროგრამა"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 წარმოადგენს MBR გაფართოებულ დანაყოფს, რომელიც ლოგიკურ დანაყოფებს შეიცავს. ყველა ლოგიკური დანაყოფის წაშლა გაფართოებულ დანაყოფს ავტომატურად წაშლის."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "საჭიროა $0, მაგრამ ხელმისაწვდომია მხოლოდ $1."
 ],
 "$0 warning": [
  null,
  "$0 გაფრთხილება"
 ],
 "$0 will be deleted": [
  null,
  "$0 წაიშლება"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "ფაილური სისტემა '$0' დაშიფრულ ბლოკურ მოწყობილობაზე ვერ იქნება"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0 უნდა იყოს მინიჭებული $1-ზე"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' '$1'-ით დაფორმატებულ მოწყობილობაზე უნდა იყოს"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' EFI-ის სისტემური დანაყოფი უნდა იყო. მონიშნული დანაყოფი იყენებს ფაილურ სისტემას FAT, მაგრამ ის მონიშნული არაა, როგორც ESP. დააყენეთ დანაყოფის ტიპი EFI-ის სისტემურ დანაყოფზე და ჩართეთ ალამი esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "'$0' დანაყოფი აღმოჩენილია MDRAID მოწყობილობაზე $1. ჩამტვირთავი დანაყოფები MDRAID მოწყობილობაზე ჯერ მხარდაჭერილი არაა."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "სტანდარტული მომხმარებლის ანგარიშის ადმინისტრატორის წვდომი მთელ სისტემაში ცვლილებების შესატანად."
 ],
 "Abort installation": [
  null,
  "დაყენების შეწყვეტა"
 ],
 "About": [
  null,
  "შესახებ"
 ],
 "Account": [
  null,
  "ანგარიში"
 ],
 "Actions": [
  null,
  "ქმედებები"
 ],
 "Add another server...": [
  null,
  "კიდევ ერთი სერვერის დამატება..."
 ],
 "Add mount": [
  null,
  "მიმაგრების დამატება"
 ],
 "Add-ons for your chosen environment": [
  null,
  "დამატებები თქვენი არჩეული გარემოსთვის"
 ],
 "Add-ons not specific to your environment": [
  null,
  "დამატებები, რომლებიც თქვენი გარემოსთვის არაა შექმნილი"
 ],
 "Additional languages": [
  null,
  "დამატებითი ენები"
 ],
 "Additional software for the selected environment": [
  null,
  "დამატებითი პროგრამები არჩეული გარემოსთვის"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "საცავის რედაქტორში შეტანილი ცვლილებები ძალაში დაუყოვნებლივ შევა."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "ყველა მოწყობილობა, რომელიც ამ საკვანძო ფრაზას იყენებს, განიბლოკება"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda-ის ვებ-ინტერფეისი"
 ],
 "Anaconda project page": [
  null,
  "Anaconda-ის პროექტის გვერდი"
 ],
 "Apply mount point assignment and install": [
  null,
  "მიმაგრების წერტილების გადატარება და დაყენება"
 ],
 "Applying changes...": [
  null,
  "ცვლილებების გადატარება..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "მიანიჭეთ დანაყოფები მიმაგრების წერტილებს. სასარგებლოა წინასწარ მორგებული განლაგებებებისთვის."
 ],
 "Automatic log file upload": [
  null,
  "ჟურნალის ფაილის ავტომატური ატვირთვა"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "დროისა და თარიღის ავტომატური დაყენება დროის სერვერის გამოყენებით"
 ],
 "Automatically set timezone": [
  null,
  "დროის სარტყლის ავტომატური დაყენება"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "ხელმისაწვდომია თავისუფალი ადგილი: $0. დაყენებას სჭირდება: $1."
 ],
 "Back": [
  null,
  "უკან"
 ],
 "Base environment": [
  null,
  "საბაზო გარემო"
 ],
 "Brief description of the issue": [
  null,
  "პრობლემის მოკლე აღწერა"
 ],
 "Bug report details": [
  null,
  "შეცდომის ანგარიშის დეტალები"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla-ის API-ის გასაღები"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "ამ პროგრამის გამოყენებით თქვენ ადასტურებთ, რომ გესმით ეს და იღებთ სატესტო პროგრამებთან დაკავშირებულ რისკებს. რომ თქვენ აპირებთ გამოიყენოთ ეს მხოლოდ ტესტირებისთვის და მზად ხართ, გამოგვიგზავნოთ ანგარიში ნებისმიერი შეცდომის შესახებ."
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change destination": [
  null,
  "სამიზნის შეცვლა"
 ],
 "Change hostname": [
  null,
  "ჰოსტის სახელის დაყენება"
 ],
 "Change partition layout": [
  null,
  "დანაყოფების განლაგების შეცვლა"
 ],
 "Change system keyboard layout": [
  null,
  "სისტემის კლავიატურის განლაგების შეცვლა"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "აქ განხორციელებული ცვლილებები სისტემას დაუყოვნებლივ ეხება. ქმედებები შეუქცევადია."
 ],
 "Checking installation configuration...": [
  null,
  "დაყენების კონფიგურაციის შემოწმება..."
 ],
 "Checking storage configuration": [
  null,
  "საცავის კონფიგურაციის შემოწმება"
 ],
 "Clear search": [
  null,
  "ძებნის გასუფთავება"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "გაფრთხილებების მიუხედავად გასაგრძელებლად დააწკაპუნეთ ღილაკზე 'შემდეგი'."
 ],
 "Close": [
  null,
  "დაკეტვა"
 ],
 "Close storage editor": [
  null,
  "საცავის რედაქტორის დახურვა"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit-ის საცავის დამატებამ დაშიფრული მოწყობილობის განბლოკისთვის საკვანძო ფრაზა არ მოგვაწოდა."
 ],
 "Completed": [
  null,
  "დასრულებულია"
 ],
 "Configuration is incomplete": [
  null,
  "კონფიგურაცია არასრულია"
 ],
 "Configure NTP servers": [
  null,
  "NTP სერვერების მორგება"
 ],
 "Configure custom NTP servers": [
  null,
  "მომხმარებლის NTP სერვერების მორგება"
 ],
 "Configure network": [
  null,
  "ქსელის მორგება"
 ],
 "Configure storage": [
  null,
  "საცავის მორგება"
 ],
 "Configure storage again": [
  null,
  "საცავის თავიდან მორგება"
 ],
 "Confirm passphrase": [
  null,
  "დაადასტურეთ საკვანძო ფრაზა"
 ],
 "Continue": [
  null,
  "გაგრძელება"
 ],
 "Continue installation": [
  null,
  "დაყენებს გაგრძელება"
 ],
 "Continue installation?": [
  null,
  "გაგრძელდეს დაყენება?"
 ],
 "Continue with installation": [
  null,
  "დაყენების გაგრძელება"
 ],
 "Correct these issues before continuing.": [
  null,
  "გაგრძელებამდე მოაგვარეთ ეს პრობლემები."
 ],
 "Create Account": [
  null,
  "ანგარიშის შექმნა"
 ],
 "Create account": [
  null,
  "ანგარიშის შექმნა"
 ],
 "Currently installed: $0": [
  null,
  "ამჟამად დაყენებულია: $0"
 ],
 "Custom": [
  null,
  "ხელით"
 ],
 "Date": [
  null,
  "თარიღი"
 ],
 "Date and time": [
  null,
  "თარიღი და დრო"
 ],
 "Delete partition": [
  null,
  "განაყოფის წაშლა"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "ზოგიერთი დანაყოფის წაშლამ, შეიძლება, $0-ს ჩატვირთვას ხელი შეუშალოს: $1"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Destination": [
  null,
  "სამიზნე"
 ],
 "Destination is encrypted": [
  null,
  "სამიზნე დაშიფრულია"
 ],
 "Detailed description of the issue": [
  null,
  "პრობლემის დეტალური აღწერა"
 ],
 "Detected valid storage layout:": [
  null,
  "აღმოჩენილია სწორი საცავის განლაგება:"
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Duplicate device.": [
  null,
  "დუბლირებული მოწყობილობა."
 ],
 "Duplicate mount point.": [
  null,
  "მიმაგრების წერტილი დუბლირებულია."
 ],
 "Enable root account": [
  null,
  "Root-ის ანგარიშის ჩართვა"
 ],
 "Encrypt my data": [
  null,
  "ჩემი მონაცემების დაშიფვრა"
 ],
 "Encrypted": [
  null,
  "დაშიფრულია"
 ],
 "Encryption": [
  null,
  "დაშიფვრა"
 ],
 "Enter PIN": [
  null,
  "შეიყვანეთ PIN-კოდი"
 ],
 "Enter PIN to access the installer": [
  null,
  "დაყენების პროგრამასთან წვდომისთვის შეიყვანეთ PIN-კოდი"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "შეიყვანეთ თქვენი Bugzilla-ის API-ის გასაღები შეცდომის ანგარიშის შესაქმნელად. შეცდომის დეტალების გადახედვას და ჩასწორებას შემდეგ საფეხურზე შეძლებთ."
 ],
 "Environment": [
  null,
  "გარემო"
 ],
 "Erase data and install": [
  null,
  "მონაცემების წაშლა და დაყენება"
 ],
 "Error details": [
  null,
  "შეცდომის დეტალები"
 ],
 "Exit to live desktop": [
  null,
  "გასვლა ცოცხალ სამუშაო მაგიდაზე"
 ],
 "Extended partition": [
  null,
  "გაფართოებული განაყოფი"
 ],
 "Failed to report issue": [
  null,
  "პრობლემის ანგარიშის გადაცემა ჩავარდა"
 ],
 "Failed to save layouts": [
  null,
  "განლაგებების შენახვის შეცდომა"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux-ს დისკზე მინიმუმ $0 ადგილი სჭირდება."
 ],
 "Finalization": [
  null,
  "დასრულება"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "დასრულება: სისტემის მორგება დასრულდა. დაყენების დასრულებას შეიძლება გარკვეული დრო დასჭირდეს."
 ],
 "Find layout": [
  null,
  "განლაგების მოძებნა"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "უსაფრთხოებისთვის ნუ გამოიყენებთ root ანგარიშს პირდაპირ. სისტემის სამართავად გამოიყენეთ ლოკალური ანგარიში, რომელიც ზემოთ წერია."
 ],
 "Full name": [
  null,
  "სრული სახელი"
 ],
 "Full name cannot contain colon characters": [
  null,
  "სრული სახელი არ შეიძლება ორწერტილს შეიცავდეს"
 ],
 "Helper text": [
  null,
  "დამხმარე ტექსტი"
 ],
 "Hide API key": [
  null,
  "API-ის გასაღების დამალვა"
 ],
 "Hide PIN": [
  null,
  "PIN-კოდის დამალვა"
 ],
 "Hide confirmed password": [
  null,
  "დადასტურებული პაროლის დამალვა"
 ],
 "Hide passphrase": [
  null,
  "საკვანძო ფრაზის დამალვა"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "Hostname": [
  null,
  "ჰოსტის სახელი"
 ],
 "How would you like to install?": [
  null,
  "როგორ გნებავთ, დააყენოთ?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "მე მესმის, რომ არსებული მონაცემები მთლიანად წაიშლება"
 ],
 "I understand that some existing data will be erased": [
  null,
  "მე მესმის, რომ არსებული მონაცემების ნაწილი წაიშლება"
 ],
 "I understand that some partitions will be modified": [
  null,
  "მე მესმის, რომ ზოგიერთი დანაყოფი შეიცვლება"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "თუ ცარიელია, ჰოსტის სახელი ცვლადი იქნება და დაყენდება ქსელის ინფორმაციის მიერ."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "თუ ზემორე არჩევნებიდან არცერთი გერგებათ, გამოიყენეთ საცავის რედაქტორი სასურველი დანაყოფების განლაგების შესაქმნელად."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "თუ ირგებთ დანაყოფებს, აუცილებელია შემდეგი:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "თუ თქვენ არ გნებავთ ჟურნალის ფაილის ავტომატური ატვირთვა, შეგიძლიათ $0. ხელით მოწერა საშუალებას გაძლევთ, გადახედოთ მას და ჟურნალის ფაილი თვითონ მიამაგროთ."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "თუ არ გესმით, რაზეა ლაპარაკი, ან არ გსურთ გარისკვა, მაშინ გთხოვთ, გამოხვიდეთ ამ პროგრამიდან \"მინდა გასვლა\"-ზე დაწოლით, რის შედეგადაც თქვენი სისტემა გადაიტვირთება."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "თუ თქვენი პრობლემა ემთხვევა რომელიმე ზემორე შეცდომას, თქვენ შეგიძლიათ, დუბლირებული ანგარიშის შექმნის მაგიერ, გახსნათ ის და დაამატოთ თქვენი ინფორმაცია იქ."
 ],
 "In progress": [
  null,
  "მიმდინარეობს"
 ],
 "Initializing...": [
  null,
  "ინიციალიზაცია..."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Installation completed": [
  null,
  "დაყენება დასრულდა"
 ],
 "Installation failed": [
  null,
  "დაყენების შეცდომა"
 ],
 "Installation method": [
  null,
  "დაყენების მეთოდი"
 ],
 "Installation of the system failed": [
  null,
  "სისტემის დაყენება ჩავარდა"
 ],
 "Installation of the system failed: $0": [
  null,
  "სისტემის დაყენება ჩავარდა: $0"
 ],
 "Installation type": [
  null,
  "დაყენების ტიპი"
 ],
 "Installing": [
  null,
  "დაყენება"
 ],
 "Insufficient disk space": [
  null,
  "დისკზე ადგილი საკმარისი არაა"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "არასწორი PIN-კოდი. კიდევ სცადეთ."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "აღმოჩენილია RAID-ის არასწორი კონფიგურაცია. თუ თქვენი RAID მასივი პირდაპირ დისკებზეა შექმნილი, მასზე ჯერ დანაყოფების ცხვილი უნდა შექმნათ. თუ თქვენი RAID მასივი შექმნილია დანაყოფებით, ის უნდა შეიცავდეს ერთ ფაილურ სისტემას ან ფორმატს (მაგ: LVM PV). ამ მასივზე ნებისმიერი არსებული ფაილური სისტემა გამოტოვებული იქნება."
 ],
 "Invalid hostname": [
  null,
  "ჰოსტის არასწორი სახელი"
 ],
 "Jump to first incomplete step": [
  null,
  "გადასვლა პირველ დაუსრულებელ ნაბიჯზე"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "დისკის მიმდინარე განლაგების შენარჩუნება სხვა ოს-თან ერთად ორმაგი ჩატვირთვისთვის."
 ],
 "Keyboard": [
  null,
  "კლავიატურა"
 ],
 "Keyboard layout during boot": [
  null,
  "კლავიატურის განლაგება ჩატვირთვისას"
 ],
 "Language": [
  null,
  "ენა"
 ],
 "Launch storage editor": [
  null,
  "საცავის რედაქტორის გაშვება"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "გაიგეთ მეტი კონფიგურაციაში შეზღუდული წვდომის შესახებ"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "ცარიელი პაროლის გამოსაყენებლად ორივე საკვანძო ფრაზის ველი ცარიელი დატოვეთ."
 ],
 "Location": [
  null,
  "მდებარეობა"
 ],
 "Locked devices": [
  null,
  "დაბლოკილი მოწყობილობები"
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Make current": [
  null,
  "მიმდინარედ დაყენება"
 ],
 "Manual disk configuration": [
  null,
  "დისკის ხელით მორგება"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "დისკის ხელით მორგება: მიმაგრების წერტილის მიბმა"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "შეიძლება შეიცავდეს ლათინურ სიმბოლოებს, ციფრებს და ტირეებს."
 ],
 "May need more free space": [
  null,
  "შეიძლება, მეტი თავისუფალი ადგილი დაგჭირდეთ"
 ],
 "Medium": [
  null,
  "მატარებელი"
 ],
 "Minimum of $0 required": [
  null,
  "საჭიროა მინიმუმ $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "მშობელი მოწყობილობისა და შვილი მოწყობილობის თავიდან დაფორმატების არჩევანი არ ემთხვევა."
 ],
 "Mount point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "Mount point assignment": [
  null,
  "მიმაგრების წერტილის მინიჭება"
 ],
 "Move down": [
  null,
  "ჩამოტანა"
 ],
 "Move up": [
  null,
  "ატანა"
 ],
 "Must be at least $0 characters": [
  null,
  "უნდა შეიცავდეს $0 სიმბოლოს მაინც"
 ],
 "My issue is different, continue": [
  null,
  "მე სხვა პრობლემა მაქვს. გააგრძელე"
 ],
 "NTP Servers": [
  null,
  "NTP სერვერები"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Needs at least $0": [
  null,
  "საჭიროა სულ ცოტა $0"
 ],
 "Network": [
  null,
  "ქსელი"
 ],
 "Network Configuration": [
  null,
  "ქსელის კონფიგურაცია"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "ქსელი ხელმისაწვდომი არაა. ანგარიშის გადასაცემად ქსელის მორგება ზედა მენიუში შეგიძლიათ."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "ქსელი ხელმისაწვდომი არაა. ანგარიშის გადასაცემად, ჯერ ქსელი მოირგეთ."
 ],
 "Network plugin failed": [
  null,
  "ქსელის დამატება ჩავარდა"
 ],
 "Next": [
  null,
  "შემდეგი"
 ],
 "No devices": [
  null,
  "მოწყობილობების გარეშე"
 ],
 "No disks available": [
  null,
  "დისკები ხელმისაწვდომი არაა"
 ],
 "No disks selected": [
  null,
  "არცერთი დისკი მონიშნული არაა"
 ],
 "No keyboard layouts selected": [
  null,
  "კლავიატურის განლაგებები არჩეული არაა"
 ],
 "No layouts selected yet": [
  null,
  "ჯერ განლაგება არჩეული არაა"
 ],
 "No results found": [
  null,
  "შედეგების გარეშე"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "არჩეული კლავიატურის განლაგებ(ებ)-ისთვის სწორი VConsole-ის კლავიატურის ასახვის მიღება შეუძლებელია. აირჩიეთ სხვა კლავიატურის განლაგება."
 ],
 "Not enough available free space": [
  null,
  "ხელმისაწვდომი თავისუფალი ადგილი საკმარისი არაა"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "მონიშნულ დისკებზე საკმარისი თავისუფალი ადგილი არაა."
 ],
 "Not enough space on selected disks.": [
  null,
  "მონიშნულ დისკებზე საკმარისი ადგილი არაა."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "შენიშვნა: ეს სატესტო პროგრამაა, რომელიც მხოლოდ ტესტირებისთვისაა განკუთვნილი. *არ* გამოიყენოთ ეს პროგრამა კრიტიკულ ან საწარმოო გარემოში."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Bugzilla-ის შეცდომის შეყვანის ფორმის გახსნა"
 ],
 "Operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "Options": [
  null,
  "მორგება"
 ],
 "Other keyboards": [
  null,
  "სხვა კლავიატურები"
 ],
 "Partitions (advanced)": [
  null,
  "დანაყოფები (დამატებით)"
 ],
 "Passphrase": [
  null,
  "საკვანძო ფრაზა"
 ],
 "Passphrase did not match any locked device": [
  null,
  "საკვანძო ფრაზა არც ერთ დაბლოკილ მოწყობილობას არ ემთხვევა"
 ],
 "Passphrases must match": [
  null,
  "საკვანძო ფრაზები არ ემთხვევა"
 ],
 "Pending": [
  null,
  "დარჩენილი"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "პრობლემას ჟურნალის ფაილი, $0 მიამაგრეთ."
 ],
 "Please enter a PIN": [
  null,
  "შეიყვანეთ PIN-კოდი"
 ],
 "Please select at least one disk to continue": [
  null,
  "გასაგრძელებლად აირჩიეთ მინიმუმ ერთი დისკი"
 ],
 "Pool": [
  null,
  "პული"
 ],
 "Potential duplicate bugs found": [
  null,
  "აღმოჩენილია პოტენციურად გამეორებული შეცდომა"
 ],
 "Powered by Anaconda": [
  null,
  "დაფუძნებულია Anaconda-ზე"
 ],
 "Pre-release": [
  null,
  "პრე-რელიზი"
 ],
 "Prefer to report manually? $0": [
  null,
  "გირჩევნიათ, ანგარიში ხელით გამოაგზავნოთ? $0"
 ],
 "Proceed with installation": [
  null,
  "დაყენების გაგრძელება"
 ],
 "Quit": [
  null,
  "გასვლა"
 ],
 "Quit installer?": [
  null,
  "შევწყვიტო დაყენება?"
 ],
 "Reading information about the OS failed.": [
  null,
  "ოპერაციული სისტემის შესახებ ინფორმაციის წაკითხვის ჩავარდა."
 ],
 "Reading information about the computer failed.": [
  null,
  "კომპიუტერის შესახებ ინფორმაციის წაკითხვის შეცდომა."
 ],
 "Reading installer configuration failed.": [
  null,
  "დაყენების პროგრამის კონფგიგურაციის წაკითხვის შეცდომა."
 ],
 "Reading installer version information failed.": [
  null,
  "დაყენების პროგრამის ვერსიის წაკითხვის შეცდომა."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "რეალური ჰოსტის სახელები, მხოლოდ ლათინურ სიმბოლოებს, ციფრებს ტირეებს (არა პირველ და ბოლო სიმბოლოდ) და წერტილებს შეიძლება, შეიცადეს"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "ჰოსტის რეალური სახელი 64 სიმბოლოზე დიდი არ უნდა იყოს"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "გადაიტვირთეთ Windows-ში BitLocker-ით დაშიფრული დანაყოფების ზომის შესაცვლელად. დარწმუნდით, რომ დასაყენებლად ხელმისაწვდომია, სულ ცოტა, $0 თავისუფალი ადგილი."
 ],
 "Reboot system?": [
  null,
  "გადავტვირთო სისტემა?"
 ],
 "Reclaim additional space": [
  null,
  "დამატებითი ადგილის გამოთხოვა"
 ],
 "Reclaim space": [
  null,
  "ადგილის გამოთხოვა"
 ],
 "Reclaim space (required)": [
  null,
  "ადგილის გამოთხოვა (აუცილებელია)"
 ],
 "Recommended": [
  null,
  "რეკომენდებულია"
 ],
 "Recommended partitions:": [
  null,
  "რეკომენდებული დანაყოფები:"
 ],
 "Reformat": [
  null,
  "გადაფორმატება"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora-ის თავიდან დაყენება"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "მონიშნული დისკებიდან ყველა დანაყოფის, არსებული ოპერაციული სისტემების ჩათვლით, წაშლა."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "წაშალეთ ან შეუცვალეთ ზომა არსებულ ფაილურ სისტემებს დასაყენებელი ადგილის გასათავისუფლებლად."
 ],
 "Remove server": [
  null,
  "სერვერის წაშლა"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "ფაილური სისტემის წაშლა გამოიწვევს მონაცემების, რომელსაც ის შეიცავს, სამუდამოდ წაშლას. დანაყოფის ზომის შეცვლამ, შეიძლება, ადგილი გამოათავისუფლოს, მაგრამ რისკისგან თავისუფალი არც ეს პროცედურაა. ადგილის გამოთავისუფლებამდე დარწმუნდით, რომ ყველაფერი აუცილებელი დამარქაფებული გაქვთ."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "ამჟამად დაყენებული სისტემის ჩანაცვლება /home საქაღალდეში ფაილების შენარჩუნებით."
 ],
 "Report Issue": [
  null,
  "პრობლემის ანგარიში"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "მოგვწერეთ პრობლემაზე, ან მოიწერეთ უკუკავშირი Bugzilla-ის შეცდომის ჩანაწერის ფორმის $0 გახსნით."
 ],
 "Report issue": [
  null,
  "პრობლემის ანგარიში"
 ],
 "Reporting issue...": [
  null,
  "პრობლემის ანგარიში..."
 ],
 "Required": [
  null,
  "აუცილებელია"
 ],
 "Requirements": [
  null,
  "მოთხოვნები"
 ],
 "Rescan devices": [
  null,
  "მოწყობილობების თავიდან სკანირება"
 ],
 "Rescanning of the disks failed.": [
  null,
  "დისკების თავიდან სკანირების შეცდომა."
 ],
 "Resize": [
  null,
  "ზომის შეცვლა"
 ],
 "Resize partition": [
  null,
  "განაყოფის ზომის შეცვლა"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "ზომის შეცვლა შემდეგი დანაყოფებისთვის $0-დან: $1"
 ],
 "Restrict access to the report": [
  null,
  "ანგარიშთან წვდომის შეზღუდვა"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "შეზღუდავს ანგარიშის ნახვას ჯგუფზე $0. $1"
 ],
 "Return to installation": [
  null,
  "დაყენებაზე დაბრუნება"
 ],
 "Return to storage editor": [
  null,
  "დაბრუნება საცავის რედაქტორზე"
 ],
 "Review and install": [
  null,
  "გადახედვა და დაყენება"
 ],
 "Root account has been configured": [
  null,
  "Root ანგარიში მორგებული არაა"
 ],
 "Root account is enabled": [
  null,
  "Root ანგარიში ჩართულია"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root ანგარიში ჩართულია, მაგრამ მომხმარებლის ანგარიშები არ შეიქმნება"
 ],
 "Root password has been set.": [
  null,
  "Root-ის პაროლი დაყენებულია."
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "დაასკანერეთ QR კოდი თქვენი ტელეფონით ან ეწვიეთ:"
 ],
 "Search for a language": [
  null,
  "ენის ძებნა"
 ],
 "Search for additional software": [
  null,
  "დამატებითი პროგრამების ძებნა"
 ],
 "Search for an environment": [
  null,
  "გარემოს ძებნა"
 ],
 "Search keyboard layout": [
  null,
  "კლავიატურის განლაგების მოძებნა"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "დაიცავით თქვენი მონაცემები დისკის დაშიფვრით. ეხება, მხოლოდ, ახალ დანაყოფებს"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "Select a device": [
  null,
  "აირჩიეთ მოწყობილობა"
 ],
 "Select city": [
  null,
  "აირჩიეთ ქალაქი"
 ],
 "Select destination": [
  null,
  "აირჩიეთ სამიზნე"
 ],
 "Select region": [
  null,
  "აირჩიეთ რეგიონი"
 ],
 "Selected (top = current)": [
  null,
  "მონიშნულია (ზედა = მიმდინარეს)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "მონიშნული მოწყობილობის ფორმატი '$0' არ შეიძლება, თავიდან დაფორმატდეს."
 ],
 "Send us feedback on your installation": [
  null,
  "გამოგვიგზავნეთ თქვენი აზრი დაყენების შესახებ"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Server is not reachable": [
  null,
  "სერვერი ხელმისაწვდომი არაა"
 ],
 "Set custom hostname": [
  null,
  "ჰოსტის სახელის დაყენება"
 ],
 "Share disk with other operating systems": [
  null,
  "დისკის გაზიარება სხვა ოპერაციულ სისტემებთან"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "დისკის გაზიარება სხვა ოპერაციულ სისტემებთან: $0"
 ],
 "Show AM/PM": [
  null,
  "AM/PM-ის ჩვენება"
 ],
 "Show API key": [
  null,
  "API-ის გასაღების ჩვენება"
 ],
 "Show PIN": [
  null,
  "PIN-კოდის ჩვენება"
 ],
 "Show confirmed password": [
  null,
  "დადასტურებული პაროლის ჩვენება"
 ],
 "Show passphrase": [
  null,
  "საკვანძო ფრაზის ჩვენება"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Software installation": [
  null,
  "პროგრამების დაყენება"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "პროგრამების დაყენება. საცავის მორგება დასრულდა. მიმდინარეობს პროგრამების დაყენება."
 ],
 "Software selection": [
  null,
  "პროგრამული უზრუნველყოფის არჩევა"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "გაგრძელებამდე ჯერ კიდევ საჭიროა რამდენიმე დაყენების ნაბიჯის დასრულება."
 ],
 "Some required partitions are missing: $0": [
  null,
  "ვერ ვიპოვე ზოგიერთი აუცილებელი დანაყოფი: $0"
 ],
 "Space": [
  null,
  "ადგილი"
 ],
 "Stacktrace": [
  null,
  "სტეკის ტრეისი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Storage configuration": [
  null,
  "საცავის მორგება"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "საცავის კონფიგურაცია: მიმდინარეობს საცავის კონფიგურაცია."
 ],
 "Storage editor": [
  null,
  "საცავის რედაქტორი"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "საცავი ეყრდნობა კონფიგურაციას, რომელიც მივიღეთ ფანჯრიდან 'საცავის ჩასწორება'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "საცავის განლაგება აღწერილია ფაილში kickstart. დაგეგმილი დაყოფის განლაგების გადახედვა შეჯამების ნაბიჯზე შეგეძლებათ."
 ],
 "Storage plugin failed": [
  null,
  "საცავის დამატება ჩავარდა"
 ],
 "Storage requirements not met": [
  null,
  "საცავის მოთხოვნები დაყენებული არაა"
 ],
 "Strong": [
  null,
  "ძლიერი"
 ],
 "Successfully installed": [
  null,
  "დაყენება წარმატებულია"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 წარმატებით განიბლოკა."
 ],
 "Suggested keyboards": [
  null,
  "მინიშნებული კლავიატურები"
 ],
 "Suggested languages": [
  null,
  "მინიშნებული ენები"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "System configuration": [
  null,
  "სისტემის მორგება"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "სისტემის მორგება. პროგრამების დაყენება დასრულდა. მიმდინარეობს სისტემის მორგება."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda-ით დაყენება მოულოდნელად შეწყდა."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "შეიძლება, ეს ღია შეცდომები თქვენს პრობლემას ემთხვევა. ახალი ანგარიშის შექმნამდე გადახედეთ მათ."
 ],
 "The following user will be created:": [
  null,
  "შეიქმნება შემდეგი მომხმარებელი:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "დაყენებას დისკზე $0 ადგილი სჭირდება, მაგრამ დისკის მოცულობა, მხოლოდ, $1-ს შეადგენს."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "დაყენების გაგრძელება შეუძლებელია კრიტიკული შეცდომის გამო."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "დაყენების გაგრძელება შეუძლებელია კრიტიკული შეცდომის გამო: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "დისკის დაშიფვრის საკვანძო ფრაზის დაყენების შემდეგ კლავიატურის განლაგება შეიცვალა. შეიყვანეთ საკვანძო ფრაზა კიდევ ერთხელ."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "საკვანძო ფრაზა, რომელიც შეიყვანეთ, სპეციალურ სიმბოლოებს შეიცავს. მისით აკრეფისას შეიძლება კლავიატურის განლაგებებს შორის გადართვა ვერ შეძლოთ."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "არჩეულ ნაგულისხმევ განლაგებას ASCII სიმბოლოების მხარდაჭერა არ აქვს. აირჩიეთ ნაგულისხმევად ASCII-ის მქონე განლაგება."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "საცავის რედაქტორი გაძლევთ საშუალებას შეუცვალოთ ზომა, წაშალოთ ან შექმნათ დანაყოფები. მას შეუძლია, LVM ააწყოს და კიდევ ბევრი რამ. განკუთვნილია, იყოს როგორც დამატებითი ხელსაწყო და, ჩვეულებრივ, არ უნდა იყოს გამოყენებული ყოველდღიური საჭიროებებისთვის."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "ჟურნალის ფაილები, შეიძლება, შეიცავდეს ინფორმაციას, როგორიცაა IP მისამართები, მომხმარებლის სახელები, ან სხვა დეტალები სისტემის შესახებ."
 ],
 "This hostname can't be submitted": [
  null,
  "ამ ჰოსტის სახელის გამოყენება შეუძლებელია"
 ],
 "This is unstable, pre-release software": [
  null,
  "ეს არასტაბილური, სატესტო პროგრამული უზრუნველყოფაა"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "ეს განლაგება გამოყენებული იქნება თქვენი სისტემის განბლოკვისთვის სისტემის ჩატვირთვისას"
 ],
 "This may take a moment": [
  null,
  "ამას შეიძლება რაღაც დრო დასჭირდეს"
 ],
 "This will take a few moments": [
  null,
  "ამას, შეიძლება, რაღაც დრო დასჭირდეს"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Timezone": [
  null,
  "დროის სარტყელი"
 ],
 "Title": [
  null,
  "სათაური"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0-ის გამოყენების დასაწყებად გადატვირთეთ თქვენი სისტემა."
 ],
 "To continue, select the devices to install to.": [
  null,
  "გასაგრძელებლად აირჩიეთ მოწყობილობა, რომელზეც დაყენება გნებავთ."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "ამ პარამეტრის გამოსაყენებლად არსებული დანაყოფების ზომა შეცვალეთ ან წაშალეთ ისინი, სანამ თავისუფალი ადგილი $0 მაინც არ იქნება."
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0-ის წაშლის რიგში ჩაყენება შეუძლებელია"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0-ის ზომის შეცვლის რიგში ჩაყენება შეუძლებელია"
 ],
 "Undo last action": [
  null,
  "ბოლო ქმედების გაუქმება"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Unlock encrypted devices": [
  null,
  "დაშიფრული მოწყობილობების განბლოკვა"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "განბლოკეთ დაშიფრული დანაყოფები, რომ შეინარჩუნოთ არსებული მონაცემები და გაჩვენოთ მეტი დაყენების მეთოდი."
 ],
 "Use configured storage": [
  null,
  "მორგებული საცავის გამოყენება"
 ],
 "Use entire disk": [
  null,
  "მთელი დისკის გამოყენება"
 ],
 "Use free space": [
  null,
  "თავისუფალი ადგილის გამოყენება"
 ],
 "Use local account": [
  null,
  "ლოკალური ანგარიშის გამოყენება"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "RAID მოწყობილობის გამოყენება ავტომატური დაყოფისთვის"
 ],
 "User creation": [
  null,
  "მომხმარებლის შექმნა"
 ],
 "User name": [
  null,
  "მომხმარებლის სახელი"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "მომხმარებლების სახელი შეიძლება, მხოლოდ, შეიცავდეს: სიმბოლოებს a-დან z-დე, ციფრებს 0-9, ტირეს $0, წერტილს $1 და ქვედატირეს $2"
 ],
 "User name must not be a reserved word": [
  null,
  "მომხმარებლის სახელი დაცული სიტყვა ვერ იქნება"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "მომხმარებლის სახელის სიგრძე 33 სიმბოლოზე ნაკლები უნდა იყოს"
 ],
 "Validating...": [
  null,
  "გადამოწმება..."
 ],
 "Weak": [
  null,
  "სუსტი"
 ],
 "Welcome": [
  null,
  "კეთილი იყოს თქვენი მობრძანება"
 ],
 "Welcome to Fedora Linux": [
  null,
  "მოგესალმებათ Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "მოგესალმებით. მოდით, $0 დავაყენოთ."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "როცა ამ ანგარიშს გააგზავნით, ავტომატურად მოხდება შემდეგი ჟურნალის ფაილების ატვირთვა: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker-ის დაშიფვრის მქონე Windows-ის დანაყოფის ზომის შეცვლა შეუძლებელია"
 ],
 "You can close this browser window now.": [
  null,
  "ეს ბრაუზერის ფანჯარა ახლა შეგიძლიათ, დახუროთ."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "აქ შეგიძლიათ, გაათავისუფლოთ საკმარისი ადგილი და მისცეთ უფლება დაყენების პროგრამას, დანარჩენი თვითონ ქნას, ან დანაყოფები ხელით მოირგეთ."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "შეგიძლიათ, დააგენერიროთ API-ის გასაღები თქვენი Bugzilla-ის ანგარიშისთვის $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "გასაგრძელებლად უნდა ჩართოთ root-ის ანგარიში, ან შექმნათ ლოკალური მომხმარებლის ანგარიში."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "ავტომატური დროისა და თარიღისთვის ინტერნეტთან უნდა ბრძანდებოდეთ მიერთებული."
 ],
 "Your progress will not be saved.": [
  null,
  "თქვენი მიმდინარეობა შენახული არ იქნება."
 ],
 "completed step": [
  null,
  "ნაბიჯი დასრულდა"
 ],
 "current step": [
  null,
  "მიმდინარე ბიჯი"
 ],
 "delete": [
  null,
  "წაშლა"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "encrypt": [
  null,
  "დაშიფრვა"
 ],
 "encrypted": [
  null,
  "დაშიფრულია"
 ],
 "extended partition": [
  null,
  "გაფართოებული განაყოფი"
 ],
 "format as $0": [
  null,
  "დაფორმატება, როგორც $0"
 ],
 "here": [
  null,
  "აქ"
 ],
 "incomplete": [
  null,
  "დაუსრულებელია"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "pending step": [
  null,
  "დარჩენილი ბიჯები"
 ],
 "report the issue manually": [
  null,
  "შეცდომის ანგარიშის ხელით გაგზავნა"
 ],
 "resized from $0": [
  null,
  "ზომა შეცვლილია $0-დან"
 ],
 "shrink": [
  null,
  "შემცირება"
 ],
 "shrink to $0": [
  null,
  "$0-მდე შემცირება"
 ],
 "transient, will use DHCP": [
  null,
  "დროებითი. გამოყენებული იქნება DHCP"
 ],
 "undo": [
  null,
  "გაუქმება"
 ]
});
