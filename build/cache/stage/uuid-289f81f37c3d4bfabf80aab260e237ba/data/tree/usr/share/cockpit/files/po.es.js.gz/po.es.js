cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "Inicio"
 ],
 "Unable to create bookmark directory": [
  null,
  "No es posible crear el marcador de directorio"
 ],
 "Unable to save bookmark file": [
  null,
  "No es posible guardar el archivo de marcador"
 ],
 "Remove from bookmarks": [
  null,
  "Quitar de marcadores"
 ],
 "Add to bookmarks": [
  null,
  "Agregar a marcadores"
 ],
 "Bookmarks": [
  null,
  "Marcadores"
 ],
 "Bookmarked": [
  null,
  "Marcados"
 ],
 "Not bookmarked": [
  null,
  "No marcado"
 ],
 "Filesystem": [
  null,
  "Sistema de archivos"
 ],
 "Edit path": [
  null,
  "Editar ruta"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Largest size": [
  null,
  "Tamaño más grande"
 ],
 "Smallest size": [
  null,
  "Tamaño más pequeño"
 ],
 "Modified": [
  null,
  "Modificado"
 ],
 "First modified": [
  null,
  "Modificado por primera vez"
 ],
 "Last modified": [
  null,
  "Última modificación"
 ],
 "Owner": [
  null,
  "Propietario"
 ],
 "Owner ascending": [
  null,
  "Propetario ascendente"
 ],
 "Owner descending": [
  null,
  "Propetario descendiente"
 ],
 "Permissions": [
  null,
  "Permisos"
 ],
 "Most permissive": [
  null,
  "Más permisivo"
 ],
 "Least permissive": [
  null,
  "Menos permisivo"
 ],
 "Show keyboard shortcuts": [
  null,
  "Mostrar atajos de teclado"
 ],
 "Filter directory": [
  null,
  "Filtrar directorio"
 ],
 "Display as a list": [
  null,
  "Mostrar como una lista"
 ],
 "Display as a grid": [
  null,
  "Mostrar como una cuadrícula"
 ],
 "Sort": [
  null,
  "Ordenar"
 ],
 "Hide hidden items": [
  null,
  "Ocultar elementos ocultos"
 ],
 "Show hidden items": [
  null,
  "Mostrar elementos ocultos"
 ],
 "$0 files": [
  null,
  "$0 archivos"
 ],
 "Uploaded as $0, $1": [
  null,
  "Subido como $0, $1"
 ],
 "Replace file $0?": [
  null,
  "¿Reemplazar archivo $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Un archivo con el mismo nombre ya existe en \"$0\". Reemplazar sobreescribirá su contenido."
 ],
 "New file": [
  null,
  "Nuevo archivo"
 ],
 "Original file on server": [
  null,
  "Archivo original en el servidor"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Aplicar esta acción para todos los conflictos"
 ],
 "Replace": [
  null,
  "Reemplazar"
 ],
 "Keep original": [
  null,
  "Mantener original"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Failed": [
  null,
  "Falló"
 ],
 "Upload error": [
  null,
  "Error de subida"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "No se puede mover el archivo subido a su destino final"
 ],
 "Cancelled": [
  null,
  "Cancelado"
 ],
 "Cancelled upload of $0": [
  null,
  "Subida de $0 cancelada"
 ],
 "File uploaded": [
  null,
  "Archivo subido"
 ],
 "Files uploaded": [
  null,
  "Archivos subidos"
 ],
 "Change permissions": [
  null,
  "Modificar permisos"
 ],
 "Uploads": [
  null,
  "Subidas"
 ],
 "Cancel upload of $0": [
  null,
  "Cancelar la subida de $0"
 ],
 "Upload $0% completed": [
  null,
  "Carga del $0% completado"
 ],
 "Upload": [
  null,
  "Subir"
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "Execute-only": [
  null,
  "Ejecutar solamente"
 ],
 "Write-only": [
  null,
  "Solo escritura"
 ],
 "Write and execute": [
  null,
  "Escritura y ejecución"
 ],
 "Read-only": [
  null,
  "Solo lectura"
 ],
 "Read and execute": [
  null,
  "Lectura y ejecución"
 ],
 "Read and write": [
  null,
  "Lectura y escritura"
 ],
 "Read, write, and execute": [
  null,
  "Lectura, escritura y ejecución"
 ],
 "Block device": [
  null,
  "Dispositivo de bloque"
 ],
 "Character device": [
  null,
  "Dispositivo de carácter"
 ],
 "Directory": [
  null,
  "Directorio"
 ],
 "Named pipe": [
  null,
  "Conducto nombrado"
 ],
 "Symbolic link": [
  null,
  "Enlace simbólico"
 ],
 "Regular file": [
  null,
  "Archivo regular"
 ],
 "Socket": [
  null,
  "Zócalo"
 ],
 "Name cannot be empty": [
  null,
  "El nombre no puede estar vacío"
 ],
 "Name too long": [
  null,
  "El nombre es demasiado largo"
 ],
 "Name cannot include a /": [
  null,
  "El nombre no puede contener /"
 ],
 "Filename is the same as original name": [
  null,
  "El nombre de archivo es el mismo que el nombre original"
 ],
 "Directory with the same name exists": [
  null,
  "Ya existe un directorio con el mismo nombre"
 ],
 "File exists": [
  null,
  "El archivo existe"
 ],
 "Pasting failed": [
  null,
  "Falló el pegado"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" existe, no se permite pegar para sobreescribirlo."
 ],
 "Paste": [
  null,
  "Pegar"
 ],
 "Create directory": [
  null,
  "Crear directorio"
 ],
 "Create file": [
  null,
  "Crear archivo"
 ],
 "Edit permissions": [
  null,
  "Editar permisos"
 ],
 "Open in terminal": [
  null,
  "Abrir en terminal"
 ],
 "Open text file": [
  null,
  "Abrir archivo de texto"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Download": [
  null,
  "Descarga"
 ],
 "Create link": [
  null,
  "Crear enlace"
 ],
 "Drop files to upload": [
  null,
  "Suelta archivos para subir"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "No se pueden soltar archivos, ya hay una carga en progreso"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Go up a directory": [
  null,
  "Subir un directorio"
 ],
 "Go back": [
  null,
  "Regresar"
 ],
 "Go forward": [
  null,
  "Avanzar"
 ],
 "Activate selected item, enter directory": [
  null,
  "Activa el elemento seleccionado, entrar al directorio"
 ],
 "Rename selected file or directory": [
  null,
  "Renombrar archivo o directorio seleccionado"
 ],
 "Create new directory": [
  null,
  "Crear nuevo directorio"
 ],
 "Copy selected file or directory": [
  null,
  "Copiar archivo o directorio seleccionado"
 ],
 "Paste file or directory": [
  null,
  "Pegar archivo o directorio"
 ],
 "Select all": [
  null,
  "Seleccionar todo"
 ],
 "Save current file": [
  null,
  "Guardar archivo actual"
 ],
 "Close editor": [
  null,
  "Cerrar editor"
 ],
 "Keyboard shortcuts": [
  null,
  "Atajos de teclado"
 ],
 "Navigation": [
  null,
  "Navegación"
 ],
 "Editing": [
  null,
  "Modificando"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Borrado forzado $0 elementos"
 ],
 "Delete $0 items?": [
  null,
  "¿Eliminar $0 elementos?"
 ],
 "Force delete file $0?": [
  null,
  "¿Borrado forzoso de archivo $0?"
 ],
 "Delete file $0?": [
  null,
  "¿Eliminar archivo $0?"
 ],
 "Force delete link $0?": [
  null,
  "¿Borrado forzoso de enlace $0?"
 ],
 "Delete link $0?": [
  null,
  "¿Eliminar enlace $0?"
 ],
 "Force delete directory $0?": [
  null,
  "¿Borrado forsozo de directorio $0?"
 ],
 "Delete directory $0?": [
  null,
  "¿Eliminar directorio $0?"
 ],
 "Force delete $0": [
  null,
  "Forzar borrado $0"
 ],
 "Delete $0?": [
  null,
  "¿Eliminar $0?"
 ],
 "No access": [
  null,
  "No hay acceso"
 ],
 "Missing type": [
  null,
  "Tipo faltante"
 ],
 "Collapse": [
  null,
  "Colapsar"
 ],
 "Show all files": [
  null,
  "Mostrar todos los archivos"
 ],
 "$0 permissions": [
  null,
  "$0 permisos"
 ],
 "Permissions for $0 files": [
  null,
  "Permisos para $0 archivos"
 ],
 "Ownership": [
  null,
  "Propiedad"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Access": [
  null,
  "Acceso"
 ],
 "Owner access": [
  null,
  "Acceso de propietario"
 ],
 "Group access": [
  null,
  "Acceso de grupo"
 ],
 "Others access": [
  null,
  "Otros accesos"
 ],
 "Security context": [
  null,
  "Contexto de seguridad"
 ],
 "Set executable as program": [
  null,
  "Establecer como programa ejecutable"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change permissions for enclosed files": [
  null,
  "Modificar permisos para los archivos incluidos"
 ],
 "(original owner)": [
  null,
  "(propietario original)"
 ],
 "keep original owners": [
  null,
  "mantener propietarios originales"
 ],
 "Paste as owner": [
  null,
  "Pegar como propietario"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Archivos siendo pegados tienen un propietario diferente. Por defecto, la propiedad será modificada para coincidir con el directorio del destino."
 ],
 "New owner": [
  null,
  "Nuevo propietario"
 ],
 "Overwrite": [
  null,
  "Sobrescribir"
 ],
 "New filename": [
  null,
  "Nuevo nombre de archivo"
 ],
 "New name": [
  null,
  "Nuevo nombre"
 ],
 "Rename $0?": [
  null,
  "¿Renombrar $0?"
 ],
 "link to $0": [
  null,
  "enlazar a $0"
 ],
 "Create link to $0": [
  null,
  "Crear enlace a $0"
 ],
 "Target": [
  null,
  "Destino"
 ],
 "Symlink name": [
  null,
  "Nombre de enlace simbólico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Absolute vs. Relative": [
  null,
  "Absoluto vs. Relativo"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Enlaces simbólicos absolutos son ideales cuando se refieren a archivos o directorios que no se muevan, tales como archivos del sistema."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Enlaces simbólicos relativos son útiles cuando ambos enlace y destino muevan a la vez, tales como cuando renombren o muevan un directorio antecesor."
 ],
 "Absolute": [
  null,
  "Absoluto"
 ],
 "Relative": [
  null,
  "Relativo"
 ],
 "The file has been removed on disk": [
  null,
  "El archivo ha sido eliminado del disco"
 ],
 "The existing file changed unexpectedly": [
  null,
  "El archivo existente cambió de manera inesperada"
 ],
 "Edit $0": [
  null,
  "Editar $0"
 ],
 "View $0": [
  null,
  "Ver $0"
 ],
 "The file has changed on disk": [
  null,
  "El archivo ha cambiado en el disco"
 ],
 "Reload": [
  null,
  "Recargar"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Save changes?": [
  null,
  "¿Guardo los cambios?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "El archivo fue borrado tras haber sido abierto, guardar lo recreará."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "El archivo ha cambiado en el disco entre cuando fue abierto y ahora"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 tiene cambios no guardados los cuales se perderán permanentemente si se descartan."
 ],
 "Discard": [
  null,
  "Descartar"
 ],
 "File name": [
  null,
  "Nombre de archivo"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Cannot create file in current directory": [
  null,
  "No se puede crear el archivo en el directorio actual"
 ],
 "Permission denied": [
  null,
  "Permiso denegado"
 ],
 "Directory name cannot be empty": [
  null,
  "El nombre del directorio no puede estar vacío"
 ],
 "Directory name too long": [
  null,
  "El nombre del directorio es demasiado largo"
 ],
 "Directory name cannot include a /": [
  null,
  "El nombre del directorio no puede incluir /"
 ],
 "Directory name": [
  null,
  "Nombre del directorio"
 ],
 "Directory owner": [
  null,
  "Propietario del directorio"
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "Clear filter": [
  null,
  "Borrar filtro"
 ],
 "Directory is empty": [
  null,
  "El directorio está vacio"
 ],
 "$0 item is hidden": [
  null,
  "$0 elemento está oculto",
  "$0 elementos están ocultos"
 ],
 "Folder": [
  null,
  "Carpeta"
 ],
 "File": [
  null,
  "Archivo"
 ],
 "Others": [
  null,
  "Otros"
 ],
 "$0 files selected": [
  null,
  "$0 archivos seleccionados"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "El directorio contiene $0 directorios, $1 archivos"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "El directorio contiene $0 directorios, $1 archivos, $2 ocultos"
 ],
 "User": [
  null,
  "Usuario"
 ]
});
