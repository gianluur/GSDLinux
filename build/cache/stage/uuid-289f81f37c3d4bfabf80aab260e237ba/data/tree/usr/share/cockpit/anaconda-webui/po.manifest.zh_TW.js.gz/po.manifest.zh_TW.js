cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
