cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Journal": [
  null,
  "Päiväkirja"
 ],
 "Terminal": [
  null,
  "Pääte"
 ],
 "Hardware information": [
  null,
  "Laitteistotiedot"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "Default": [
  null,
  "Oletus"
 ],
 "Light": [
  null,
  "Vaalea"
 ],
 "Dark": [
  null,
  "Tumma"
 ],
 "Help": [
  null,
  "Ohje"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "Search": [
  null,
  "Haku"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "Permission denied": [
  null,
  "Käyttö estetty"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Hallinnollisen pääsyn saamiseksi ei ole käytettävissä menetelmiä ('sudo -A', 'pkexec')."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit raportoi virhekoodin $0"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Error during initialization": [
  null,
  "Virhe alustuksen aikana"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Home": [
  null,
  "Koti"
 ],
 "Downloads": [
  null,
  "Lataukset"
 ],
 "Not a directory": [
  null,
  "Ei ole hakemisto"
 ],
 "All files": [
  null,
  "Kaikki tiedostot"
 ],
 "Recent": [
  null,
  "Viimeaikaiset"
 ],
 "No recent directories": [
  null,
  "Ei hiljattain käytettyjä hakemistoja"
 ],
 "No recent files": [
  null,
  "Ei hiljattain käytettyjä tiedostoja"
 ],
 "Type to filter": [
  null,
  "Kirjoita suodattaaksesi"
 ],
 "File chooser actions": [
  null,
  "Tiedostonvalitsimen toiminnot"
 ],
 "Open in file browser": [
  null,
  "Avaa tiedostoselaimessa"
 ],
 "Hide hidden files": [
  null,
  "Piilota piilotetut tiedostot"
 ],
 "Show hidden files": [
  null,
  "Näytä piilotetut tiedostot"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Clear filters": [
  null,
  "Tyhjennä suodattimet"
 ],
 "Directory is empty": [
  null,
  "Hakemisto on tyhjä"
 ],
 "Directory has no sub-directories": [
  null,
  "Hakemistossa ei ole alihakemistoja"
 ],
 "This directory contains only hidden files": [
  null,
  "Tämä hakemisto sisältää vain piilotiedostoja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "Folder": [
  null,
  "Kansio"
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "$0 is not a directory": [
  null,
  "$0 ei ole hakemisto"
 ],
 "$0 does not exist": [
  null,
  "$0 ei ole olemassa"
 ],
 "Font size": [
  null,
  "Kirjasinkoko"
 ],
 "Decrease by one": [
  null,
  "Vähennä yhdellä"
 ],
 "Increase by one": [
  null,
  "Lisää yhdellä"
 ],
 "Appearance": [
  null,
  "Ulkomuoto"
 ],
 "Black": [
  null,
  "Musta"
 ],
 "White": [
  null,
  "Valkoinen"
 ],
 "Reset": [
  null,
  "Nollaa"
 ],
 "Unable to open directory": [
  null,
  "Hakemistoa ei voi avata"
 ],
 "Running process prevents directory change": [
  null,
  "Prosessin suorittaminen estää hakemiston muuttamisen"
 ],
 "Change directory": [
  null,
  "Vaihda hakemistoa"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Hakemiston muuttaminen pysäyttää voimalla parhaillaan käynnissä olevan prosessin. Prosessi voidaan pysäyttää myös manuaalisesti terminaalissa ennen jatkamista."
 ],
 "Terminal not available": [
  null,
  "Pääte ei käytettävissä"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Tämä selain ei tue WebGL2:ta."
 ],
 "unknown": [
  null,
  "tuntematon"
 ],
 "Shutdown": [
  null,
  "Sammuta"
 ],
 "running $0": [
  null,
  "käyttöjärjestelmänä $0"
 ],
 "Current boot": [
  null,
  "Tämänhetkinen käynnistys"
 ],
 "Previous boot": [
  null,
  "Edellinen käynnistys"
 ],
 "Last 24 hours": [
  null,
  "Viimeiset 24 tuntia"
 ],
 "Last 7 days": [
  null,
  "Viimeiset 7 päivää"
 ],
 "Only emergency": [
  null,
  "Vain hätätilanne"
 ],
 "Alert and above": [
  null,
  "Varoitus ja yli"
 ],
 "Critical and above": [
  null,
  "Kriittinen ja yli"
 ],
 "Error and above": [
  null,
  "Virhe ja yli"
 ],
 "Warning and above": [
  null,
  "Varoitus ja yli"
 ],
 "Notice and above": [
  null,
  "Ilmoitus ja yli"
 ],
 "Info and above": [
  null,
  "Tiedot ja yli"
 ],
 "Debug and above": [
  null,
  "Virheenkorjaus ja yli"
 ],
 "Toggle filters": [
  null,
  "Vaihda suodattimet"
 ],
 "Time": [
  null,
  "Aika"
 ],
 "Priority": [
  null,
  "Prioriteetti"
 ],
 "Identifier": [
  null,
  "Tunniste"
 ],
 "Filters": [
  null,
  "Suotimet"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Resume": [
  null,
  "Palauta"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Päivämäärätietojen on oltava muodossa VVVV-KK-PP tt:mm:ss. Vaihtoehtoisesti merkkijonot 'yesterday', 'today', 'tomorrow' ymmärretään. 'now' viittaa nykyiseen aikaan. Lopuksi suhteelliset ajat voidaan määrittää etuliitteellä '-' tai '+'"
 ],
 "Since": [
  null,
  "Siitä asti kun"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Aloita merkintöjen näyttäminen määritetystä tai sitä myöhemmästä päivästä."
 ],
 "Until": [
  null,
  "Kunnes"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Aloita merkintöjen näyttäminen määritetystä tai sitä aiemmasta päivästä."
 ],
 "Boot": [
  null,
  "Käynnistys"
 ],
 "Show messages from a specific boot.": [
  null,
  "Näytä viestit tietystä käynnistyksestä."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Tämä lisää osuman '_BOOT_ID ='. Jos sitä ei ole määritetty, nykyisen käynnistyksen lokit näytetään. Jos käynnistystunnus jätetään pois, positiivinen siirtymä etsii käynnistykset päiväkirjan alusta alkaen ja yhtä suuri tai pienempi kuin nolla-siirtymä etsii käynnistykset päiväkirjan lopusta alkaen. Siten 1 tarkoittaa ensimmäistä löydettyä käynnistystä päiväkirjassa aikajärjestyksessä, 2 toista ja niin edelleen; kun -0 on viimeinen käynnistys, -1 käynnistys ennen viimeistä jne."
 ],
 "Unit": [
  null,
  "Yksikkö"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Näytä määritetyn järjestelmäyksikön viestit."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Tämä lisää osuman '_SYSTEMD_UNIT =', 'COREDUMP_UNIT =' ja 'UNIT =' löytääkseen kaikki mahdolliset viestit annetulle yksikölle. Voi sisältää enemmän yksiköitä pilkuilla erotettuna."
 ],
 "Free-form search": [
  null,
  "Vapaamuotoinen haku"
 ],
 "Show messages containing given string.": [
  null,
  "Näytä viestit, jotka sisältävät annetun merkkijonon."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Mikä tahansa tekstimerkkijono lokiviesteissä voidaan suodattaa. Merkkijono voi olla myös säännöllisen lausekkeen muodossa. Tukee myös suodatusta viestilokikenttien mukaan. Nämä ovat välilyönnillä erotettuja arvoja muodossa KENTTÄ=ARVO, jossa arvo voi olla pilkuilla erotettu luettelo mahdollisista arvoista."
 ],
 "journalctl manpage": [
  null,
  "journalctl:n man-sivu"
 ],
 "Successfully copied to clipboard": [
  null,
  "Kopioitu onnistuneesti leikepöydälle"
 ],
 "Create timer": [
  null,
  "Luo ajastin"
 ],
 "Edit timer": [
  null,
  "Muokkaa ajastinta"
 ],
 "Timer creation failed": [
  null,
  "Ajastimen luonti epäonnistui"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Käynnistysehtojen saaminen ajastimelle epäonnistui"
 ],
 "Failed to get the timer command": [
  null,
  "Ajastinkomennon saaminen epäonnistui"
 ],
 "This field cannot be empty": [
  null,
  "Tämä kenttä ei voi olla tyhjä"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Vain aakkoset, numerot, : , _ , . , @ , - ovat sallittuja"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Shell command": [
  null,
  "Shell-komento"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Tämä komento suorittaa /bin/sh."
 ],
 "Trigger": [
  null,
  "Laukaise"
 ],
 "At specific time": [
  null,
  "Tiettynä aikana"
 ],
 "After system boot": [
  null,
  "Järjestelmän käynnistyksen jälkeen"
 ],
 "Seconds": [
  null,
  "Sekunnit"
 ],
 "Minutes": [
  null,
  "Minuutit"
 ],
 "Hours": [
  null,
  "Tuntia"
 ],
 "Weeks": [
  null,
  "Viikot"
 ],
 "Delay must be a number": [
  null,
  "Viiveen tulee olla numero"
 ],
 "Repeat": [
  null,
  "Toista"
 ],
 "Don't repeat": [
  null,
  "Älä toista"
 ],
 "Minutely": [
  null,
  "Tarkasti"
 ],
 "Hourly": [
  null,
  "Joka tunti"
 ],
 "Daily": [
  null,
  "Joka päivä"
 ],
 "Weekly": [
  null,
  "Joka viikko"
 ],
 "Monthly": [
  null,
  "Joka kuukausi"
 ],
 "Yearly": [
  null,
  "Vuosittain"
 ],
 "Run at": [
  null,
  "Aja klo"
 ],
 "At second": [
  null,
  "Toiseksi"
 ],
 "At minute": [
  null,
  "Hetkessä"
 ],
 "Run on": [
  null,
  "Aja kohteessa"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuutit tulee olla esitetty numerovälillä 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekuntit tulee olla esitetty numerovälillä 0-59"
 ],
 "Repeat weekly": [
  null,
  "Toista joka viikko"
 ],
 "Mondays": [
  null,
  "Maanantai"
 ],
 "Tuesdays": [
  null,
  "Tiistai"
 ],
 "Wednesdays": [
  null,
  "Keskiviikko"
 ],
 "Thursdays": [
  null,
  "Torstai"
 ],
 "Fridays": [
  null,
  "Perjantai"
 ],
 "Saturdays": [
  null,
  "Lauantai"
 ],
 "Sundays": [
  null,
  "Sunnuntai"
 ],
 "Repeat monthly": [
  null,
  "Toista joka kuukausi"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Unclean shutdown": [
  null,
  "Epäpuhdas sammutus"
 ],
 "View logs": [
  null,
  "Katso lokit"
 ],
 "Dismiss": [
  null,
  "Hylkää"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Ajastettu sammutus $0"
 ],
 "Cancel poweroff": [
  null,
  "Peru sammutus"
 ],
 "Scheduled reboot at $0": [
  null,
  "Ajastettu sammutus kello $0"
 ],
 "Cancel reboot": [
  null,
  "Peru uudelleenkäynnistys"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "Set hostname": [
  null,
  "Määritä konenimi"
 ],
 "Configuration": [
  null,
  "Kokoonpano"
 ],
 "Hostname": [
  null,
  "Koneen nimi"
 ],
 "System time": [
  null,
  "Järjestelmän aika"
 ],
 "Domain": [
  null,
  "Toimialue"
 ],
 "Performance profile": [
  null,
  "Suorituskykyprofiili"
 ],
 "Secure shell keys": [
  null,
  "Secure shell -avaimet"
 ],
 "Show fingerprints": [
  null,
  "Näytä sormenjäljet"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh-koneavainten luettelointi epäonnistui: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH-avainten lataaminen epäonnistui"
 ],
 "Error message": [
  null,
  "Virheviesti"
 ],
 "Loading keys...": [
  null,
  "Ladataan avaimet..."
 ],
 "No host keys found.": [
  null,
  "Koneen avaimia ei löytynyt."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Koneen SSH-avaimen sormenjäljet"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Oikea konenimi saa sisältää enintään 64 merkkiä"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Oikea konenimi voi sisältää vain pieniä kirjaimia, numeroita, viivoja ja pisteitä (täytetyillä alitoimialueilla)"
 ],
 "Change host name": [
  null,
  "Vaihda konenimi"
 ],
 "Pretty host name": [
  null,
  "Tyylikäs konenimi"
 ],
 "Real host name": [
  null,
  "Oikea konenimi"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Käyttäjällä $0 ei ole oikeutta muokata kryptografisia käytäntöjä"
 ],
 "Cryptographic policy": [
  null,
  "Kryptografinen käytäntö"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Suositeltu, turvalliset asetukset nykyisiä uhkamalleja vastaan."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "OLETUS, SHA-1-allekirjoituksen vahvistus sallittu."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Parempi yhteentoimivuus lisääntyneen hyökkäysrajapinnan kustannuksella."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY Active Directoryn yhteentoimivuudella."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Käytä vain hyväksyttyjä ja sallittuja algoritmeja käynnistettäessä FIPS-tilassa."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS jossa muita yleisiä kriteerejä koskevia rajoituksia."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Suojaa ennakoiduilta lähiajan hyökkäyksiltä yhteentoimivuuden kustannuksella."
 ],
 "Custom cryptographic policy": [
  null,
  "Mukautettu kryptografinen käytäntö"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografiset käytännöt on järjestelmäkomponentti, joka määrittää keskeiset salausalijärjestelmät, jotka kattavat TLS-, IPSec-, SSH-, DNSSec- ja Kerberos-protokollat."
 ],
 "Change cryptographic policy": [
  null,
  "Muuta kryptografista käytäntöä"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Uuden käytännön soveltaminen; tämä saattaa kestää muutaman minuutin."
 ],
 "Reapply and reboot": [
  null,
  "Ota käyttöön uudelleen ja käynnistä uudelleen"
 ],
 "Apply and reboot": [
  null,
  "Käytä ja käynnistä uudelleen"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS ei ole otettu oikein käyttöön"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Kryptografinen käytäntö on epäjohdonmukainen"
 ],
 "Review cryptographic policy": [
  null,
  "Tarkastele kryptografista käytäntöä"
 ],
 "System information": [
  null,
  "Järjestelmätiedot"
 ],
 "Model": [
  null,
  "Malli"
 ],
 "Asset tag": [
  null,
  "Sisältötunniste"
 ],
 "Machine ID": [
  null,
  "Koneen ID"
 ],
 "Up since": [
  null,
  "Käynnissä lähtien"
 ],
 "View hardware details": [
  null,
  "Tarkastele laitteiston yksityiskohtia"
 ],
 "Last successful login:": [
  null,
  "Edellinen onnistunut kirjautuminen:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 epäonnistunut sisäänkirjautumisyritys",
  "$0 epäonnistutta sisäänkirjautumisyritystä"
 ],
 "View login history": [
  null,
  "Tarkastele kirjautumishistoriaa"
 ],
 "recommended": [
  null,
  "suositeltu"
 ],
 "inconsistent": [
  null,
  "epäkonsistentti"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Toimialueeseen liittyminen vaatii realmd:n asentamisen"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Toimialueeseen ei voi liittyä, koska realmd ei ole käytettävissä tässä järjestelmässä"
 ],
 "Joining this domain is not supported": [
  null,
  "Liittyminen tähän toimialueeseen ei ole tuettu"
 ],
 "Login format": [
  null,
  "Sisäänkirjautumisen muoto"
 ],
 "Server software": [
  null,
  "Palvelinohjelmisto"
 ],
 "Client software": [
  null,
  "Asiakasohjelmisto"
 ],
 "Leave domain": [
  null,
  "Jätä toimialue"
 ],
 "Leave $0": [
  null,
  "Poistu $0:sta"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Kun olet poistunut toimialueesta, vain käyttäjät, joilla on paikalliset kirjautumistiedot, voivat kirjautua tähän koneeseen. Tämä voi vaikuttaa myös muihin palveluihin, kuten DNS-ratkaisimen asetukset, ja luotettujen varmentajien CA-luettelo voi muuttua."
 ],
 "Validating address": [
  null,
  "Vahvistetaan osoite"
 ],
 "Contacted domain": [
  null,
  "Toimialue, johon otettiin yhteyttä"
 ],
 "Domain could not be contacted": [
  null,
  "Toimialueeseen ei saatu yhteyttä"
 ],
 "Domain is not supported": [
  null,
  "Toimialue ei ole tuettu"
 ],
 "Domain address": [
  null,
  "Toimialue-osoite"
 ],
 "Domain administrator name": [
  null,
  "Toimialueen ylläpitäjän nimi"
 ],
 "Domain administrator password": [
  null,
  "Toimialueen ylläpitäjän salasana"
 ],
 "Joining": [
  null,
  "Liitytään"
 ],
 "Join": [
  null,
  "Liity"
 ],
 "This may take a while": [
  null,
  "Tässä voi mennä hetki"
 ],
 "Not permitted to configure realms": [
  null,
  "Alueen määrittäminen ei ole sallittua"
 ],
 "Join domain": [
  null,
  "Liity toimialueeseen"
 ],
 "Install realmd support": [
  null,
  "Asenna realmd-tuki"
 ],
 "$0 disk is failing": [
  null,
  "$0 levy on vialla",
  "$0 levyä on vialla"
 ],
 "Connected to Insights": [
  null,
  "Yhdistetty Insights:een"
 ],
 "Not connected to Insights": [
  null,
  "Ei yhdistetty tilastoihin"
 ],
 "Health": [
  null,
  "Terveys"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU:sta",
  "$0 CPU:ista"
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "View metrics and history": [
  null,
  "Tarkastele tietoja ja historiaa"
 ],
 "Tuned is not available": [
  null,
  "Tuned ei ole saatavilla"
 ],
 "Tuned is not running": [
  null,
  "Tuned ei ole käynnissä"
 ],
 "Tuned is off": [
  null,
  "Tuned on pois päältä"
 ],
 "This system is using the recommended profile": [
  null,
  "Tämä järjestelmä käyttää suositeltua profiilia"
 ],
 "This system is using a custom profile": [
  null,
  "Tämä järjestelmä käyttää mukautettua profiilia"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "Communication with tuned has failed": [
  null,
  "Yhteydenpito tuned:n kanssa epäonnistui"
 ],
 "Failed to enable tuned": [
  null,
  "tuned:n käyttöönotto epäonnistui"
 ],
 "Failed to disable tuned": [
  null,
  "tuned:n käytöstä poistaminen epäonnistui"
 ],
 "Failed to disable tuned profile": [
  null,
  "muokatun profiilin käytöstä poistaminen epäonnistui"
 ],
 "Failed to switch profile": [
  null,
  "Profiilin vaihtaminen epäonnistui"
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "Disable tuned": [
  null,
  "Poista tuned käytöstä"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned:n käynnistys epäonnistui"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned on palvelu, joka valvoo järjestelmääsi ja optimoi suorituskyvyn tietyillä kuormituksilla. Tuned:n ytimessä on profiileja, jotka virittävät järjestelmän eri käyttötapauksiin."
 ],
 "Change performance profile": [
  null,
  "Vaihda suorituskyvyn profiili"
 ],
 "Change profile": [
  null,
  "Vaihda profiili"
 ],
 "Edit /etc/motd": [
  null,
  "Muokkaa /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Muutosten tallentaminen /etc/motd:een epäonnistui"
 ],
 "Save changes": [
  null,
  "Tallenna muutokset"
 ],
 "Edit motd": [
  null,
  "Muokkaa motd-tiedostoa"
 ],
 "Stub": [
  null,
  "Tynkä"
 ],
 "Not found": [
  null,
  "Ei löytynyt"
 ],
 "Bad setting": [
  null,
  "Huono asetus"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Merged": [
  null,
  "Yhdistetty"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "Reloading": [
  null,
  "Ladataan uudelleen"
 ],
 "Not running": [
  null,
  "Ei käynnissä"
 ],
 "Failed to start": [
  null,
  "Käynnistäminen epäonnistui"
 ],
 "Maintenance": [
  null,
  "Ylläpito"
 ],
 "Enabled": [
  null,
  "Käytössä"
 ],
 "Disabled": [
  null,
  "Ei käytössä"
 ],
 "Linked": [
  null,
  "Linkitetty"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Piilotettu"
 ],
 "Static": [
  null,
  "Staattinen"
 ],
 "Invalid": [
  null,
  "Virheellinen"
 ],
 "Indirect": [
  null,
  "Epäsuora"
 ],
 "Generated": [
  null,
  "Luotu"
 ],
 "Transient": [
  null,
  "Tilapäinen"
 ],
 "Bad": [
  null,
  "Huono"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Systemd-signaalien tilaaminen epäonnistui: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Yhteyden muodostaminen dbus-verkkoon epäonnistui: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Yksiköiden listaus epäonnistui: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 palvelu on epäonnistunut",
  "$0 palvelua on epäonnistunut"
 ],
 "Loading of units failed": [
  null,
  "Yksiköiden lataus epäonnistui"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Listing units": [
  null,
  "Listauksen yksiköt"
 ],
 "Filter by name or description": [
  null,
  "Suodata nimen tai kuvauksen mukaan"
 ],
 "Active state": [
  null,
  "Aktiivinen tila"
 ],
 "File state": [
  null,
  "Tiedoston tila"
 ],
 "$0 filters applied": [
  null,
  "$0 suodatinta toteutettu"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Käyttäjä $0 ei saa muuttaa suorittimen suojauksen lievennyksiä"
 ],
 "Mitigations": [
  null,
  "Lievennykset"
 ],
 "Version": [
  null,
  "Versio"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS-versio"
 ],
 "BIOS date": [
  null,
  "BIOS-päiväys"
 ],
 "CPU security": [
  null,
  "Suorittimen turvallisuus"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Poista samanaikainen monisäikeisyys käytöstä"
 ],
 "Read more...": [
  null,
  "Lue lisää..."
 ],
 "Save and reboot": [
  null,
  "Tallenna ja käynnistä uudelleen"
 ],
 "CPU security toggles": [
  null,
  "Suorittimen turvallisuusvalinnat"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Ohjelmistopohjaiset ratkaisut auttavat estämään suorittimen tietoturvaongelmia. Näillä lievennyksillä on sivuvaikutus suorituskyvyn heikentämisessä. Muuta näitä asetuksia omalla vastuullasi."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Luokka"
 ],
 "Vendor": [
  null,
  "Toimittaja"
 ],
 "Slot": [
  null,
  "Paikka"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "Memory technology": [
  null,
  "Muistitekniikka"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Rank": [
  null,
  "Sijoitus"
 ],
 "Speed": [
  null,
  "Nopeus"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Muistiin liittyvien tietojen katselu vaatii ylläpitäjän käyttöoikeudet."
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "Failed to fetch logs": [
  null,
  "Logien nouto epäonnistui"
 ],
 "Clear all filters": [
  null,
  "Tyhjennä kaikki suodattimet"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Lokeja ei löydy käyttämällä nykyistä suodatinten yhdistelmää."
 ],
 "No logs found": [
  null,
  "Ei löytynyt lokeja"
 ],
 "Load earlier entries": [
  null,
  "Lataa aiemmat merkinnät"
 ],
 "You may try to load older entries.": [
  null,
  "Voit yrittää ladata vanhempia merkintöjä."
 ],
 "Allow running (unmask)": [
  null,
  "Salli, että suoritetaan (paljastaa)"
 ],
 "Reload": [
  null,
  "Lataa uudelleen"
 ],
 "Restart": [
  null,
  "Käynnistä uudelleen"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Clear 'Failed to start'": [
  null,
  "Tyhjennä \"Aloitus epäonnistui\""
 ],
 "Mask service": [
  null,
  "Piilota palvelu"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Palvelun piilottaminen estää kaikkia riippuvaisia yksiköitä toimimasta. Tällä voi olla odotettua suurempi vaikutus. Vahvista, että haluat piilottaa tämän yksikön."
 ],
 "Disallow running (mask)": [
  null,
  "Estä suorittaminen (piilota)"
 ],
 "Unpin unit": [
  null,
  "Poista yksikön merkkaus"
 ],
 "Pin unit": [
  null,
  "Merkitse yksikkö"
 ],
 "Additional actions": [
  null,
  "Ylimääräiset toimet"
 ],
 "Note": [
  null,
  "Huomautus"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Tätä yksikköä ei ole suunniteltu nimenomaisesti käytettäväksi."
 ],
 "Forbidden from running": [
  null,
  "Kielletty suorittamasta"
 ],
 "Start service": [
  null,
  "Käynnistä palvelu"
 ],
 "Active since ": [
  null,
  "Aktiivinen lähtien "
 ],
 "Required by ": [
  null,
  "Tämän edellyttämänä "
 ],
 "Read-only": [
  null,
  "Vain luku"
 ],
 "Requires administration access to edit": [
  null,
  "Muokkaaminen edellyttää ylläpitäjän käyttöoikeuksia"
 ],
 "Automatically starts": [
  null,
  "Käynnistyy automaattisesti"
 ],
 "Updating status...": [
  null,
  "Päivitetään tilaa ..."
 ],
 "Stop and disable": [
  null,
  "Pysäytä ja poista käytöstä"
 ],
 "Start and enable": [
  null,
  "Käynnistä ja ota käyttöön"
 ],
 "Failed to load unit": [
  null,
  "Yksikön lataaminen epäonnistui"
 ],
 "View all services": [
  null,
  "Katso kaikki palvelut"
 ],
 "Triggers": [
  null,
  "Laukaisimet"
 ],
 "Triggered by": [
  null,
  "Tämän laukaisema"
 ],
 "Requires": [
  null,
  "Vaatii"
 ],
 "Requisite": [
  null,
  "Vaaditaan"
 ],
 "Wants": [
  null,
  "Haluaa"
 ],
 "Binds to": [
  null,
  "Sitoo tähän"
 ],
 "Part of": [
  null,
  "Osa tätä"
 ],
 "Required by": [
  null,
  "Tämän edellyttämänä"
 ],
 "Requisite of": [
  null,
  "Tämä vaaditaan"
 ],
 "Wanted by": [
  null,
  "Tämän haluama"
 ],
 "Bound by": [
  null,
  "Sillä sidottu"
 ],
 "Consists of": [
  null,
  "Näistä koostuu"
 ],
 "Conflicts": [
  null,
  "Ristiriidat"
 ],
 "Conflicted by": [
  null,
  "Näiden kanssa ristiriitainen"
 ],
 "Before": [
  null,
  "Ennen"
 ],
 "After": [
  null,
  "Jälkeen"
 ],
 "On failure": [
  null,
  "Epäonnistumisesta"
 ],
 "Propagates reload to": [
  null,
  "Laajentaa uudelleenlatausta kohteeseen"
 ],
 "Reload propagated from": [
  null,
  "Uudelleenlataus levitetty tältä"
 ],
 "Joins namespace of": [
  null,
  "Liittyy tämän nimitilaan"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Ehto $0=$1 ei toteutunut"
 ],
 "Deletion will remove the following files:": [
  null,
  "Poistaminen poistaa seuraavat tiedostot:"
 ],
 "Pinned unit": [
  null,
  "Merkitty yksikkö"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Path": [
  null,
  "Polku"
 ],
 "Listen": [
  null,
  "Kuuntele"
 ],
 "Container": [
  null,
  "Kontti"
 ],
 "View Podman container": [
  null,
  "Näytä Podman-kontti"
 ],
 "Condition failed": [
  null,
  "Ehto epäonnistui"
 ],
 "Show more relationships": [
  null,
  "Näytä lisää suhteita"
 ],
 "Show relationships": [
  null,
  "Näytä suhteet"
 ],
 "Confirm deletion of $0": [
  null,
  "Vahvista kohteen $0 poistaminen"
 ],
 "Timer deletion failed": [
  null,
  "Ajastimen poisto epäonnistui"
 ],
 "Targets": [
  null,
  "Kohteet"
 ],
 "Sockets": [
  null,
  "Pistokkeet"
 ],
 "Timers": [
  null,
  "Ajastimet"
 ],
 "Paths": [
  null,
  "Polut"
 ],
 "Go to $0": [
  null,
  "Mene kohteeseen $0"
 ],
 "Journal entry not found": [
  null,
  "Päiväkirjan tietuetta ei löytynyt"
 ],
 "Journal entry": [
  null,
  "Päiväkirjan tietue"
 ],
 "Entry at $0": [
  null,
  "Merkintä $0:lla"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "Loading unit failed": [
  null,
  "Yksiköiden lataus epäonnistui"
 ],
 "Service logs": [
  null,
  "Palvelulokit"
 ],
 "No log entries": [
  null,
  "Ei lokimerkintöjä"
 ],
 "Systemd units": [
  null,
  "Systemd-yksiköt"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Ei tuloksia, jotka vastaavat suodatinkriteerejä. Tyhjennä kaikki suodattimet nähdäksesi tulokset."
 ],
 "Does not automatically start": [
  null,
  "Ei käynnisty automaattisesti"
 ],
 "Cannot be enabled": [
  null,
  "Ei voida ottaa käyttöön"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Verkkokonsoli toimii rajoitetun pääsyn tilassa."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "sijainnista $0 päätteellä $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0:sta"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "päätteellä $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Toimialue"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Liity toimialueeseen"
 ]
});
