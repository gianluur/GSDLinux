cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Services": [
  null,
  "الخدمات"
 ],
 "Terminal": [
  null,
  "الطرفية"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "time": [
  null,
  "وقت"
 ],
 "date": [
  null,
  "التاريخ"
 ],
 "restart": [
  null,
  "أَعد التشغيل"
 ],
 "shut": [
  null,
  "أوقف"
 ],
 "domain": [
  null,
  "نِطاق"
 ],
 "machine": [
  null,
  "آلة"
 ],
 "operating system": [
  null,
  "نظام تشغيل"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "معرّف الأصل"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "طاقة"
 ],
 "version": [
  null,
  "الإِصدار"
 ],
 "host": [
  null,
  "مضيف"
 ],
 "hardware": [
  null,
  "العتاد المادي"
 ],
 "mitigation": [
  null,
  "التخفيف"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "ذاكرة"
 ],
 "cpu": [
  null,
  "وحدة معالجة مركزية"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "خافت"
 ],
 "serial": [
  null,
  "تسلسلي"
 ],
 "graphs": [
  null,
  "الرسوم البيانية"
 ],
 "metrics": [
  null,
  "المقاييس"
 ],
 "history": [
  null,
  "تاريخ"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "الأَقراص"
 ],
 "network": [
  null,
  "الشَبكة"
 ],
 "cgroups": [
  null,
  "مجموعات التحكم"
 ],
 "performance": [
  null,
  "الأداء"
 ],
 "Configuring system settings": [
  null,
  "تكوين إعدادات النظام"
 ],
 "service": [
  null,
  "الخدمة"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "هدف"
 ],
 "socket": [
  null,
  "مقبس الشبكة"
 ],
 "timer": [
  null,
  "مؤقِّت"
 ],
 "path": [
  null,
  "<path>"
 ],
 "unit": [
  null,
  "وحدة"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "إقلاع"
 ],
 "mask": [
  null,
  "قناع"
 ],
 "unmask": [
  null,
  "إزالة الإخفاء"
 ],
 "enable": [
  null,
  "ممكن"
 ],
 "disable": [
  null,
  "عطل"
 ],
 "Managing services": [
  null,
  "إدارة الخدمات"
 ],
 "journal": [
  null,
  "سجل اليوميات"
 ],
 "warning": [
  null,
  "تحذير"
 ],
 "error": [
  null,
  "خَطأ"
 ],
 "debug": [
  null,
  "التنقيح"
 ],
 "crash": [
  null,
  "تعطل"
 ],
 "coredump": [
  null,
  "تفريغ الذاكرة الأساسية"
 ],
 "Reviewing logs": [
  null,
  "مراجعة السجلات"
 ],
 "console": [
  null,
  "وحدة تحكم"
 ],
 "command": [
  null,
  "أَمر"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "الصدفة"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
