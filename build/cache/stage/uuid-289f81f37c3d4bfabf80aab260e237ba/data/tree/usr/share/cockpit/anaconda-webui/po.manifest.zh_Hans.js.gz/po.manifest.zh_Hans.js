cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_Hans",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
