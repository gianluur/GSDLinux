cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 || n%10==1 ? 0 : 1),
  "language": "mk",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Анаконда"
 ]
});
