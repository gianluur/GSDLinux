cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "서비스"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "network": [
  null,
  "네트워크"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "연결장치"
 ],
 "bridge": [
  null,
  "브릿지"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "본드"
 ],
 "team": [
  null,
  "팀"
 ],
 "port": [
  null,
  "포트"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "방화벽"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "영역"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "네트워킹 본드 관리"
 ],
 "Managing networking teams": [
  null,
  "네트워킹 팀 관리"
 ],
 "Managing networking bridges": [
  null,
  "네트워킹 브릿지 관리"
 ],
 "Managing VLANs": [
  null,
  "VLAN 관리"
 ],
 "Managing firewall": [
  null,
  "방화벽 관리"
 ]
});
