cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Unlock": [
  null,
  "Odomknúť"
 ],
 "Add key": [
  null,
  "Pridať kĺúč"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "Set": [
  null,
  "Nastaviť"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "Permission denied": [
  null,
  "Prístup odmietnutý"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "You now have administrative access.": [
  null,
  "Teraz máte prístup na úrovni správcu systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pre získanie prístupu na úrovni správcu sa prosím overte"
 ],
 "Switch to administrative access": [
  null,
  "Prepnúť na prístup pre správcu"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s prepínaním na správcu"
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Limit access": [
  null,
  "Obmedziť prístup"
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim obmedzeného prístupu obmedzuje oprávnenia pre správu. Niektoré časti webovej konzole budú poskytovať menej funkcií."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prehliadač si bude úroveň prístupu pamätať aj pre budúce spustenia."
 ],
 "Limited access": [
  null,
  "Obmedzený prístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnúť prístup na úrovni správcu"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásil chybový kód $0"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrujte písaním"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Súborový systém"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Súbor"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "View logs": [
  null,
  "Zobraziť záznamy udalostí"
 ],
 "Dismiss": [
  null,
  "Zahodiť"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "Not found": [
  null,
  "Nenájdené"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Running": [
  null,
  "Beží"
 ],
 "Not running": [
  null,
  "Nespustená"
 ],
 "Loading...": [
  null,
  "Načítavam..."
 ],
 "User": [
  null,
  "Používateľ"
 ],
 "Vendor": [
  null,
  "Výrobca"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte odstránenie $0"
 ],
 "Username": [
  null,
  "Meno používateľa"
 ],
 "Actions": [
  null,
  "Akcie"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Rename": [
  null,
  "Premenovať"
 ],
 "Started": [
  null,
  "Spustené"
 ],
 "Delete group": [
  null,
  "Odstrániť skupinu"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Lock": [
  null,
  "Zamknúť"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Disconnect": [
  null,
  "Odpojiť"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chýba",
  "$0 disky chýbajú",
  "$0 diskov chýba"
 ],
 "Location": [
  null,
  "Umiestnenie"
 ],
 "Compression": [
  null,
  "Kompresia"
 ],
 "Storage logs": [
  null,
  "Záznamy udalostí úložiska"
 ],
 "Name cannot be empty.": [
  null,
  "Názov je potrebné vyplniť."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Názov nemôže byť dlhší ako 127 znakov."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Názov nesmie obsahovať znak „$0\"."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Názov nesmie obsahovať prázdny znak."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Názov nemôže byť dlhší ako $0 znakov"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Názov nemôže byť dlhší ako $0 bytov"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool pre tenké logické zväzky"
 ],
 "Thin logical volume": [
  null,
  "Tenký logický zväzok"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logický zväzok (zachytený stav)"
 ],
 "Logical volume": [
  null,
  "Logický zväzok"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID zariadenie $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 skupina zväzkov $0"
 ],
 "VDO device $0": [
  null,
  "VDO zariadenie $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Šifrovaný logický zväzok na $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Šifrovaný oddiel na $0"
 ],
 "Logical volume of $0": [
  null,
  "Logický zväzok na $0"
 ],
 "Partition of $0": [
  null,
  "Oddiel na $0"
 ],
 "Encrypted $0": [
  null,
  "Šifrované $0"
 ],
 "unpartitioned space on $0": [
  null,
  "nerozdelené miesto na $0"
 ],
 "unmount": [
  null,
  "odpojiť"
 ],
 "mount": [
  null,
  "mount"
 ],
 "remove from btrfs volume": [
  null,
  "odobrať zo zväzku btrfs"
 ],
 "stop": [
  null,
  "zastaviť"
 ],
 "remove from MDRAID": [
  null,
  "odobrať z MDRAID"
 ],
 "remove from LVM2": [
  null,
  "odobrať z LVM2"
 ],
 "btrfs device": [
  null,
  "zariadenie btrfs"
 ],
 "btrfs volume": [
  null,
  "zväzok btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Názov nemôže byť dlhší ako 255 znakov."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Nazov nesmie obsahovať znak „/\"."
 ],
 "Create and mount": [
  null,
  "Vytvoriť a pripojiť"
 ],
 "Create only": [
  null,
  "Iba vytvoriť"
 ],
 "Create subvolume": [
  null,
  "Vytvoriť podzväzok (subvolume)"
 ],
 "Mount Point": [
  null,
  "Bod pripojenia"
 ],
 "delete": [
  null,
  "odstrániť"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Nenávratne odstrániť podzväzok $0?"
 ],
 "Edit mount point": [
  null,
  "Upraviť bod pripojenia"
 ],
 "Unmount": [
  null,
  "Odpojiť"
 ],
 "Mount": [
  null,
  "Bod pripojenia"
 ],
 "btrfs subvolume": [
  null,
  "podzväzok btrfs"
 ],
 "Snapshot origin": [
  null,
  "Pôvod snímku stavu"
 ],
 "Mount point": [
  null,
  "Bod pripojenia"
 ],
 "No subvolumes": [
  null,
  "Žiadne podzväzky"
 ],
 "btrfs subvolumes": [
  null,
  "podzväzky btrfs"
 ],
 "Snapshots": [
  null,
  "Snímky stavu"
 ],
 "No snapshots found": [
  null,
  "Nenašli sa žiadne snímky"
 ],
 "snapshot": [
  null,
  "snímka stavu"
 ],
 "$0 is in use": [
  null,
  "$0 sa používa"
 ],
 "Permanently delete $0?": [
  null,
  "Nenávratne odstrániť $0?"
 ],
 "Change label": [
  null,
  "Zmeniť štítok"
 ],
 "Label": [
  null,
  "Štítok"
 ],
 "Capacity": [
  null,
  "Kapacita"
 ],
 "btrfs devices": [
  null,
  "btrfs zariadenia"
 ],
 "No devices found": [
  null,
  "Žiadne zariadene nebolo nájdené"
 ],
 "btrfs filesystem": [
  null,
  "systém súborov btrfs"
 ],
 "Aborted": [
  null,
  "Prerušené"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Počas operácie samotestovania došlo k fatálnej chybe"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  "Prerušené z neznámeho dôvodu"
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "Degraded": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Run short test": [
  null,
  "Spustiť krátky test"
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Abort test": [
  null,
  "Prerušiť test"
 ],
 "Disk is failing": [
  null,
  "Disk zlyháva"
 ],
 "Disk is OK": [
  null,
  "Disk je OK"
 ],
 "Assessment": [
  null,
  "Posudok"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Media drive": [
  null,
  "Jednotka média"
 ],
 "Solid State Drive": [
  null,
  "Jednotka bez pohyblivých častí"
 ],
 "Hard Disk Drive": [
  null,
  "Jednotka pevného disku"
 ],
 "iSCSI Drive": [
  null,
  "Jednotka iSCSI"
 ],
 "Drive": [
  null,
  "Jednotka"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Firmware version": [
  null,
  "Verzia firmvéru"
 ],
 "Serial number": [
  null,
  "Sériové číslo"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "Nie je vložené žiadne médium"
 ],
 "Device file": [
  null,
  "Súbor zariadenia"
 ],
 "Multipathed devices": [
  null,
  "Zariadenie s viacerými cestami (multipath)"
 ],
 "Free space": [
  null,
  "Voľný priestor"
 ],
 "Create partition": [
  null,
  "Vytvoriť oddiel"
 ],
 "Extended partition": [
  null,
  "Rozšírený oddiel"
 ],
 "$0 partitions": [
  null,
  "$0 oddiel"
 ],
 "Partitions": [
  null,
  "Oddiely"
 ],
 "No partitions found": [
  null,
  "Nenašli sa žiadne oddiely"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Odstránením oddielu sa zmažú všetky dáta na ňom."
 ],
 "No free space after this partition": [
  null,
  "Za týmto oddielom už nie je žiadne voľné miesto"
 ],
 "EFI system partition": [
  null,
  "Systémový oddiel EFI"
 ],
 "BIOS boot partition": [
  null,
  "Spúšťací oddiel BIOSu"
 ],
 "Partition": [
  null,
  "Oddiel"
 ],
 "Shrink": [
  null,
  "Zmenšiť"
 ],
 "Grow": [
  null,
  "Zväčšiť"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Štartovací oddiel PReP architektúry PowerPC"
 ],
 "Linux swap space": [
  null,
  "Odkladací priestor pre Linux"
 ],
 "Linux filesystem data": [
  null,
  "Údaje linuxového systému súborov"
 ],
 "Logical Volume Manager partition": [
  null,
  "Oddiel správy logických zväzkov"
 ],
 "Custom": [
  null,
  "Vlastné"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ musí obsahovať presne dva znaky šestnástkovej sústavy (0 až 9, A až F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Typ môže obsahovať iba znaky 0 až 9, A až F a „-“ (mínus, spojovník)."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ musí mať podobu NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Nastaviť typ oddielu na $0"
 ],
 "Custom type": [
  null,
  "Používateľom definovaný typ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Zmena typov oddielov môže spôsobiť problémy pri štarte systému."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Tento oddiel nie je úplne využívaný obsahom, ktorý sa na ňom nachádza."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Veľkosť oddielu je $0. Veľkosť obsahu na ňom je $1."
 ],
 "Shrink partition": [
  null,
  "Zmenšiť oddiel"
 ],
 "Grow content": [
  null,
  "Zväčšiť obsah"
 ],
 "initialize": [
  null,
  "inicializovať"
 ],
 "Initialize disk $0": [
  null,
  "Inicializovať disk $0"
 ],
 "Partitioning": [
  null,
  "Vytváranie oddielov"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibilné so všetkými systémami a zariadeniami (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibilné s modernými systémami a pevnými diskami > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Žiaden oddiel"
 ],
 "Overwrite": [
  null,
  "Prepísať"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Prepísať existujúce dáta nulami (pomalšie)"
 ],
 "Initialize": [
  null,
  "Inicializovať"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inicializácia vymaže všetky údaje na disku."
 ],
 "Device is read-only": [
  null,
  "Zariadenie je len na čítanie"
 ],
 "Create partition table": [
  null,
  "Vytvoriť tabuľku oddielov"
 ],
 "Size must be a number": [
  null,
  "Veľkosť musí byť číslo"
 ],
 "Size cannot be zero": [
  null,
  "Veľkosť nemôže byť nulová"
 ],
 "Size cannot be negative": [
  null,
  "Veľkosť nemôže byť záporná"
 ],
 "Size is too large": [
  null,
  "Veľkosť je príliš veľká"
 ],
 "Size must be at least $0": [
  null,
  "Veľkosť musí byť aspoň $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fyzický zväzok LVM2 skupiny zväzkov (volume group)"
 ],
 "member of MDRAID device": [
  null,
  "člen zariadenia MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "zariadenie, na ktorom je zariadenie VDO založené"
 ],
 "member of Stratis pool": [
  null,
  "člen Stratis poolu"
 ],
 "Filesystem outside the target": [
  null,
  "Systém súborov mimo cieľa"
 ],
 "device of btrfs volume": [
  null,
  "zariadenie zväzku btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Toto zariadenie sa aktuálne používa."
 ],
 "Device": [
  null,
  "Zariadenie"
 ],
 "Use": [
  null,
  "Použiť"
 ],
 "Services using the location": [
  null,
  "Služby využívajúce toto umiestnenie"
 ],
 "Processes using the location": [
  null,
  "Procesy využívajúce toto umiestnenie"
 ],
 "Currently in use": [
  null,
  "Aktuálne využité"
 ],
 "(Not part of target)": [
  null,
  "(Nie je súčasťou cieľa)"
 ],
 "These changes will be made:": [
  null,
  "Vykonajú sa tieto zmeny:"
 ],
 "Action": [
  null,
  "Akcia"
 ],
 "Important data might be deleted:": [
  null,
  "Týmto môžete vymazať dôležité údaje:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Súvisiace procesy a služby budú násilne zastavené."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Súvisiace procesy budú násilne zastavené."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Súvisiace služby budú násilne zastavené."
 ],
 "Checking filesystem usage": [
  null,
  "Kontrolujem využitie systému súborov"
 ],
 "$0 used, $1 total": [
  null,
  "$0 použité, $1 celkom"
 ],
 "Device contains unrecognized data": [
  null,
  "Zariadenie obsahuje nerozpoznané dáta"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Uzamknuté zašifrované zariadenie môže obsahovať dáta"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Týmto potvrdzujem, že chcem bez možnosti odvolania tejto operácie odstrániť tieto dáta"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Bod pripojenia $0 je používaný nasledujúcimi procesmi:"
 ],
 "PID": [
  null,
  "Identifikátor procesu (PID)"
 ],
 "Command": [
  null,
  "Príkaz"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Bod pripojenia $0 je používaný nasledujúcimi službami:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Uvedené procesy a služby budú násilne ukončené."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Uvedené procesy budú násilne zastavené."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Uvedené služby budú násilne zastavené."
 ],
 "Sorry": [
  null,
  "Prepáčte"
 ],
 "Usage of $0": [
  null,
  "Využitie $0"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO pool"
 ],
 "Data used": [
  null,
  "Využitých dát"
 ],
 "Metadata used": [
  null,
  "Využité metadáta"
 ],
 "Use compression": [
  null,
  "Použiť kompresiu"
 ],
 "Deduplication": [
  null,
  "Deduplikácia"
 ],
 "Use deduplication": [
  null,
  "Použiť deduplikáciu"
 ],
 "Rename volume group": [
  null,
  "Premenovať skupinu zväzkov (volume group)"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Odstránením sa zmažú všetky údaje v skupine zväzkov (volume group)."
 ],
 "Create snapshot": [
  null,
  "Zachytiť stav"
 ],
 "Add disks": [
  null,
  "Pridať disky"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "No disks are available.": [
  null,
  "Nie sú k dispozícii žiadne disky."
 ],
 "At least one disk is needed.": [
  null,
  "Vyžaduje sa aspoň jeden disk."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Skupine zväzkov (volume group) chýbajú fyzické zväzky"
 ],
 "No free space": [
  null,
  "Žiadne voľné miesto"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 skupina zväzkov"
 ],
 "Add physical volume": [
  null,
  "Pridať fyzický zväzok"
 ],
 "LVM2 logical volumes": [
  null,
  "Logické zväzky LVM2"
 ],
 "Create new logical volume": [
  null,
  "Vytvoriť nový logický zväzok"
 ],
 "No logical volumes": [
  null,
  "Žiadne logické zväzky"
 ],
 "Remove missing physical volumes?": [
  null,
  "Odstrániť chýbajúce fyzické zväzky?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Tejto skupine zväzkov chýbajú niektoré fyzické zväzky."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Skupinu zväzkov (volume group), ktorej chýbajú fyzické zväzky, nie je možné premenovať."
 ],
 "Physical volumes": [
  null,
  "Fyzické zväzky"
 ],
 "No physical volumes found": [
  null,
  "Nenájdené žiadne fyzické zväzky"
 ],
 "LVM2 physical volumes": [
  null,
  "Fyzické zväzky LVM2"
 ],
 "Rename logical volume": [
  null,
  "Premenovať logický zväzok"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Nenávratne odstránť logický zväzok $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Odstránením logického zväzku sa zmažú všetky údaje v ňom."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Nepodarilo sa opraviť logický zväzok $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Pre opravu nie je k dispozícii dostatok voľného miesta. Na fyzických zväzkoch je potrebných aspoň $0, ktoré ešte nie sú využité týmto logickým zväzkom."
 ],
 "An additional $0 must be selected": [
  null,
  "Je potrebné vybrať ďalšie $0"
 ],
 "Repair logical volume $0": [
  null,
  "Opraviť logický zväzok $0"
 ],
 "Physical Volumes": [
  null,
  "Fyzické zväzky"
 ],
 "Repair": [
  null,
  "Opraviť"
 ],
 "deactivate": [
  null,
  "deaktivovať"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Deaktivovať logický zväzok $0/$1?"
 ],
 "Deactivate": [
  null,
  "Deaktivovať"
 ],
 "Not enough space to grow": [
  null,
  "Pre zväčšenie nie je dostatok miesta"
 ],
 "LVM2 logical volume": [
  null,
  "Logický zväzok LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Prúžkované (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Zrkadlenie (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Prúžkované a zrkadlené (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Vyhradená parita (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Distribuovaná parita (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dvojitá distribuovaná parita (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Tento logický zväzok nie je úplne využitý obsahom, ktorý sa na ňom nachádza."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Veľkosť zväzku je $0. Veľkosť obsahu je $1."
 ],
 "Shrink volume": [
  null,
  "Zmenšiť oddiel"
 ],
 "Layout": [
  null,
  "Rozvrhnutie"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Tento logický zväzok stratil všetky svoje fyzické zväzky a už ho nie je možné používať. Je potrebné ho vymazať a vytvoriť nový na jeho mieste."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Tento logický zväzok stratil niektoré svoje fyzické zväzky, ale zatiaľ nedošlo ku strate žiadnych dát. Mali by ste ho opraviť a obnoviť tak jeho pôvodnú redundanciu."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Tento logický zväzok stratil niektoré svoje fyzické zväzky, ale pravdepodobne ešte nedošlo ku strate dát. Mali by ste byť schopný ho opraviť."
 ],
 "Stripes": [
  null,
  "Prúžky"
 ],
 "$0 synchronized": [
  null,
  "$0 nesynchronizované"
 ],
 "Create volume group": [
  null,
  "Vytvoriť skupinu zväzkov (volume group)"
 ],
 "LVM2 physical volume": [
  null,
  "Fyzický zväzok LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Posledný zostávajúci nie je možné odobrať"
 ],
 "Not enough free space": [
  null,
  "Nedostatok voľného miesta"
 ],
 "Volume group": [
  null,
  "Skupina zväzkov"
 ],
 "Create thin volume": [
  null,
  "Vytvoriť tenko poskytovaný (thin provisioned) zväzok"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Tenko poskytované LVM2 logické zväzky"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Vytvoriť nový tenko poskytovaný logický zväzok (thin provisioning)"
 ],
 "Not enough space": [
  null,
  "Nedostatok miesta"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool pre tenko poskytované (thin provisioned) logické zväzky LVM2"
 ],
 "Inactive logical volume": [
  null,
  "Neaktívny logický zväzok"
 ],
 "Activate": [
  null,
  "Aktivovať"
 ],
 "Unsupported logical volume": [
  null,
  "Nepodporovaný logický zväzok"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNÁ CHYBA – Tento logický zväzok je označený ako aktívny a mal by mať priradené blokové zariadenie. Žiadne také blokové zariadenie sa však nenašlo."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Inštalácia $0 by odobrala $1."
 ],
 "Installing packages": [
  null,
  "Inštalujem balíčky"
 ],
 "Block device for filesystems": [
  null,
  "Blokové zariadenie pre súborové systémy"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool pre tenko poskytované (thin provisioned) zväzky"
 ],
 "Linear": [
  null,
  "Lineárny"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Zväzok systému súborov VDO (kompresia/deduplikácia)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch bez akejkoľvek dodatočnej odolnosti či zlepšení výkonu."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Pre zlepšenie výkonu budú údaje na vybraných fyzických zväzkoch uložené striedavo. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Pre zvýšenie spoľahlivosti budú údaje uložené ako dve či viacero kópií na vybraných fyzických zväzkoch. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Údaje budú uložené ako dve kópie a tiež striedavo na označených fyzických zväzkoch, čo zvýši spoľahlivosť aj výkon. Je potrebné vybrať aspoň dva zväzky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o jeden z nich prísť bez toho, aby došlo ku strate dát. Je potrebné vybrať aspoň tri zväzky."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o jeden z nich prísť bez toho, aby došlo ku strate dát. Dáta sú tiež ukladané striedavo, čo vedie k vyššiemu výkonu. Je potrebné vybrať aspoň tri zväzky."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Údaje budú na vybraných fyzických zväzkoch uložené tak, že bude možné o dva z nich prísť bez toho, aby došlo ku strate dát. Dáta sú tiež ukladané striedavo, čo vedie k vyššiemu výkonu. Je potrebné vybrať aspoň päť zväzkov."
 ],
 "Create logical volume": [
  null,
  "Vytvoriť logický zväzok"
 ],
 "Purpose": [
  null,
  "Účel"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Aby bolo možné vytvárať zariadenia VDO, nainštaluje sa balíček $0."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Pre RAID 10 je potrebný párny počet fyzických zväzkov"
 ],
 "Logical size": [
  null,
  "Logická veľkosť"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Šetriť priestor kompresiou jednotlivých blokov pomocou LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Šetriť priestor ukladaním rovnakých dátových blokov iba raz"
 ],
 "Creating VDO device": [
  null,
  "Vytváram VDO zariadenie"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Toto NFS pripojenie je používané a je možné meniť len jeho možnosti."
 ],
 "NFS mount": [
  null,
  "Pripojenie NFS"
 ],
 "New NFS mount": [
  null,
  "Nové NFS pripojenie"
 ],
 "Server address": [
  null,
  "Adresa server"
 ],
 "Server cannot be empty.": [
  null,
  "Server nemôže byť prázdny."
 ],
 "Path on server": [
  null,
  "Cesta na serveri"
 ],
 "Path on server cannot be empty.": [
  null,
  "Cestu na server je potrebné zadať."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Je potrebné, aby cesta na serveri začínala lomkou („/\")."
 ],
 "Local mount point": [
  null,
  "Lokálny bod pripojenia"
 ],
 "Mount point cannot be empty.": [
  null,
  "Je potrebné zadať bod pripojenia."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Bod pripojenia musí začínať lomkou („/\")."
 ],
 "Mount options": [
  null,
  "Možnosti pripojenia"
 ],
 "Mount at boot": [
  null,
  "Pripojiť pri štarte"
 ],
 "Mount read only": [
  null,
  "Pripojiť iba na čítanie"
 ],
 "Custom mount options": [
  null,
  "Používateľom definované možnosti pripojenia"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nepodarilo sa odpojiť systém súborov"
 ],
 "Stop and unmount": [
  null,
  "Zastaviť a odpojiť"
 ],
 "Unable to remove mount": [
  null,
  "Účet sa nepodarilo odstrániť"
 ],
 "Stop and remove": [
  null,
  "Zastaviť a odstrániť"
 ],
 "(not mounted)": [
  null,
  "(nepripojené)"
 ],
 "Start multipath": [
  null,
  "Spustiť multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "V systéme sú zariadenia s viacerými cestami, ale služba multipath nie je spustená."
 ],
 "Show all $0 rows": [
  null,
  "Zobraziť všetkých $0 riadkov"
 ],
 "Category": [
  null,
  "Kategória"
 ],
 "Encryption": [
  null,
  "Šifrovanie"
 ],
 "encrypted": [
  null,
  "šifrované"
 ],
 "Last modified: $0": [
  null,
  "Naposledy zmenené: $0"
 ],
 "Stored passphrase": [
  null,
  "Uložená heslová fráza"
 ],
 "Encryption options": [
  null,
  "Možnosti šifrovania"
 ],
 "Encryption type": [
  null,
  "Typ šifrovania"
 ],
 "Cleartext device": [
  null,
  "Znakové zariadenie"
 ],
 "yes": [
  null,
  "áno"
 ],
 "Disk passphrase": [
  null,
  "Heslová fráza k disku"
 ],
 "Passphrase cannot be empty": [
  null,
  "Heslová fráza nemôže byť prázdna"
 ],
 "Unlocking disk": [
  null,
  "Odomykám disk"
 ],
 "Checking for $0 package": [
  null,
  "Kontrolujem balíček $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Je potrebné nainštalovať balíček $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Balíček $0 nie je k dispozícii v žiadnom repozitári."
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Zisťujem prítomnosť podpory NBDE v initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Je potrebné znovu vytvoriť initrd."
 ],
 "Regenerating initrd": [
  null,
  "Znovuvytváram initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Pridávam rd.neednet=1 do parametrov pri zavádzaní jadra"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Pridávam „$0\" do možností pre systém súborov"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Pridávam „$0\" do možností pre šifrovanie"
 ],
 "Enabling $0": [
  null,
  "Povoľujem $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Pridať šifrovanie diskov viazané na sieť"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Systém aktuálne nepodporuje odomykanie koreňového systému súborov pomocou Tang servera s kľúčmi."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Systém v tejto chvíli nepodporuje odomykanie systému súborov pomocou Tang servera s kľúčmi v priebehu štartu systému."
 ],
 "These additional steps are necessary:": [
  null,
  "Sú potrebné tieto ďalšie kroky:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uloženie novej heslovej frázy vyžaduje odomknutie disku. Zadajte súčasnú heslovú frázu k disku."
 ],
 "Fix NBDE support": [
  null,
  "Opraviť podporu pre NBDE"
 ],
 "Adding key": [
  null,
  "Pridávam kľúč"
 ],
 "Key source": [
  null,
  "Zdroj pre kľúč"
 ],
 "Repeat passphrase": [
  null,
  "Zopakujte heslovú frázu"
 ],
 "Passphrase": [
  null,
  "Heslová fráza"
 ],
 "Tang keyserver": [
  null,
  "Tang server s kľúčami"
 ],
 "New passphrase": [
  null,
  "Nová heslová fráza"
 ],
 "Passphrases do not match": [
  null,
  "Heslové frázy sa líšia"
 ],
 "Keyserver address": [
  null,
  "Adresa servera s kľúčmi"
 ],
 "Change passphrase": [
  null,
  "Zmeniť heslovú frázu"
 ],
 "Old passphrase": [
  null,
  "Pôvodná heslová fráza"
 ],
 "Edit Tang keyserver": [
  null,
  "Upraviť Tang server s kľúčami"
 ],
 "Verify key": [
  null,
  "Overiť kľúč"
 ],
 "Trust key": [
  null,
  "Dôveryhodný kľúč"
 ],
 "Passphrase can not be empty": [
  null,
  "Heslová fráza nemôže byť prázdna"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Zmazanie heslovej fráze môže brániť odomknutiu $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potvrdiť odstránenie pomocou alternatívnej heslovej fráze"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Odstránenie heslovej fráze bez potvrdenia inej heslovej fráze môže zabrániť v odomknutí alebo správe kľúčov pri strate alebo zabudnutí zostávajúcich heslových fráz."
 ],
 "Passphrase from any other key slot": [
  null,
  "Heslová fráza z ľubovoľného iného slotu s kľúčom"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Odobrať heslovú frázu v slote pre kľúč $0?"
 ],
 "Remove $0?": [
  null,
  "Odobrať $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Odstrániť Tang server s kľúčami?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Prihlásený užívateľ nie je oprávnený zobrazovať informácie o kľúčoch."
 ],
 "No keys added": [
  null,
  "Žiadne pridané kľúče"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Úprava kľúča vyžaduje voľný slot"
 ],
 "The last key slot can not be removed": [
  null,
  "Posledný slot kľúča nemôže byť odobraný"
 ],
 "Keyserver": [
  null,
  "Server s kľúčami"
 ],
 "Unknown type": [
  null,
  "Neznámy typ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sloty kľúčov s neznámym typom tu nie je možné upraviť"
 ],
 "Keys": [
  null,
  "Kľúče"
 ],
 "$0 slot remains": [
  null,
  "$0 slot ostáva",
  "$0 sloty ostávajú",
  "$0 slotov ostáva"
 ],
 "No available slots": [
  null,
  "Nie sú dostupné žiadne sloty"
 ],
 "No free key slots": [
  null,
  "Žiadne volné sloty pre kľúče"
 ],
 "Locked data": [
  null,
  "Uzamknuté dáta"
 ],
 "Address cannot be empty": [
  null,
  "Adresa nemôže byť prázdna"
 ],
 "Address is not a valid URL": [
  null,
  "Adresa nie je platné URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Skontrolovať odtlačok kľúča voči Tang serveru."
 ],
 "How to check": [
  null,
  "Ako skontrolovať"
 ],
 "In a terminal, run: ": [
  null,
  "V terminále spustite: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Úspešne skopírované do schránky!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Skontrolujte, či sa SHA-256 alebo SHA-1 odtlačok z príkazu zhoduje s týmto dialógovým oknom."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "podzväzok btrfs $0 z $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Je potrebné zadať bod pripojenia"
 ],
 "Mount point is already used for $0": [
  null,
  "Bod pripojenia sa už používa pre $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "V tomto bode pripojenia už sú pripojené systémy súborov."
 ],
 "Please unmount them first.": [
  null,
  "Prosím, najprv ich odpojte."
 ],
 "read only": [
  null,
  "iba na čítanie"
 ],
 "never mount at boot": [
  null,
  "nikdy nepripájať pri štarte systému"
 ],
 "after network": [
  null,
  "po sieti"
 ],
 "ignore failure": [
  null,
  "ignorovať neúspech"
 ],
 "stop boot on failure": [
  null,
  "pri chybe zastaviť štart systému"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Systém súborov nemá priradený bod pripojenia."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Systém súborov nemá trvalý bod pripojenia."
 ],
 "The filesystem is not mounted.": [
  null,
  "Systém súborov nie je pripojený."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Systém súborov bude odomknutý pri ďalšom štarte systému. Toto môže vyžadovať zadanie heslovej fráze."
 ],
 "(no assigned mount point)": [
  null,
  "(nepriradený žiaden bod pripojenia)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Systém súborov je teraz pripojený do $0, ale pri ďalšom štarte systému bude pripojený do $1."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Pri štarte systému automaticky pripojiť na $0"
 ],
 "Mount on $0 now": [
  null,
  "Pripojiť na $0 teraz"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Systém súborov nie je pripojený, ale pri ďalšom štarte systéme už bude."
 ],
 "Do not mount automatically on boot": [
  null,
  "Nepripájať automaticky pri štarte systému"
 ],
 "Mount now": [
  null,
  "Pripojiť teraz"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Systém súborov je teraz pripojený, ale pri ďalšom štarte systému už nebude."
 ],
 "Mount also automatically on boot": [
  null,
  "Pripájať tiež automaticky pri štarte systému"
 ],
 "Unmount now": [
  null,
  "Odpojiť teraz"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Systém súborov je teraz pripojený do $0, ale pri ďalšom štarte systému už nebude pripojený vôbec."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Systém súborov je nastavený tak, aby bol automaticky pripájaný pri štarte systému, ale šifrovaný kontajner, v ktorom sa nachádza, nebude v tom čase odomknutý."
 ],
 "Unlock automatically on boot": [
  null,
  "Automaticky odomknúť pri štarte systému"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Nekonzistentný bod pripojenia systému súborov"
 ],
 "$0 filesystem": [
  null,
  "systém súborov $0"
 ],
 "Filesystem name": [
  null,
  "Názov systému súborov"
 ],
 "Filesystem is locked": [
  null,
  "Systém súborov je zamknutý"
 ],
 "Mounts before services start": [
  null,
  "Pripojenia pred spustením služieb"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Vhodné pre kriticky dôležité body pripojenia, ako napríklad /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Ak systém súborov nebude pripojený, spustenie operačného systému skončí s chybou a vzdialený prístup tak nebude fungovať"
 ],
 "Mounts in parallel with services": [
  null,
  "Bude pripojené súbežne so službami"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Operačný systém sa podarí spustiť, aj keď systém súborov nebude pripojený"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Bude sa pripájať súbežne so službami, ale až po tom, ako bude dostupná sieť"
 ],
 "Does not mount during boot": [
  null,
  "Nepripája sa pri štarte systému"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Užitočné pre body pripojenia, ktoré sú voliteľné alebo vyžadujú interakciu (ako napr. heslovú frázu)"
 ],
 "At boot": [
  null,
  "Pri štarte systému"
 ],
 "Mount before services start": [
  null,
  "Pripojiť pred spustením služieb"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Pripojiť bez čakania, ignorovať neúspech"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Pripojiť, keď bude sieť k dispozícii, ignorovať neúspech"
 ],
 "Do not mount": [
  null,
  "Nepripájať"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Toto zariadenie nie je možné použiť ako cieľ inštalácie."
 ],
 "Mount filesystem": [
  null,
  "pojiť súborový systém"
 ],
 "Unmount filesystem $0": [
  null,
  "Odpojiť systém súborov $0"
 ],
 "Mount configuration": [
  null,
  "Nastavenie pripojenia (mount)"
 ],
 "Swap": [
  null,
  "Odkladanie (swap)"
 ],
 "Used": [
  null,
  "Využité"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odomknúť šifrovaný Stratis pool"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Zadajte heslovú frázu pre pool na týchto blokových zariadeniach:"
 ],
 "Stratis pool": [
  null,
  "Stratis pool"
 ],
 "stopped": [
  null,
  "zastavené"
 ],
 "Block devices": [
  null,
  "Blokové zariadenia"
 ],
 "No block devices found": [
  null,
  "Nenájdené žiadne blokové zariadenie"
 ],
 "Stratis block devices": [
  null,
  "Blokové zariadenia Stratis"
 ],
 "Stratis block device": [
  null,
  "Blokové zariadenie Stratis"
 ],
 "data": [
  null,
  "údaje"
 ],
 "cache": [
  null,
  "medzipamäť (cache)"
 ],
 "Pool passphrase": [
  null,
  "Heslová fráza k poolu"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  ""
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  ""
 ],
 "Create filesystem": [
  null,
  "Vytvoriť systém súborov"
 ],
 "Stratis filesystem": [
  null,
  "Systém súborov Stratis"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Odstránením Stratis poolu sa vymažú všetky údaje v ňom."
 ],
 "Rename Stratis pool": [
  null,
  "Premenovať Stratis pool"
 ],
 "Add block devices": [
  null,
  "Pridať blokové zariadenie"
 ],
 "Tier": [
  null,
  "Vrstva (tier)"
 ],
 "Data": [
  null,
  "Údaje"
 ],
 "Cache": [
  null,
  "Vyrovnávacia pamäť"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  ""
 ],
 "Encrypted Stratis pool": [
  null,
  "Šifrovaný Stratis pool"
 ],
 "Delete pool": [
  null,
  "Odstrániť pool"
 ],
 "Stratis filesystems": [
  null,
  "Systémy súborov Stratis"
 ],
 "Create new filesystem": [
  null,
  "Vytvoriť nový systém súborov"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Tento pool nevyužíva zo svojich podkladových zariadení všetok priestor."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Veľkosť niektorých blokových zariadení bola pre vytvorenie poolu zväčšená. Pool je možné bezpečne zväčšiť a využiť tak novo dostupné miesto."
 ],
 "Grow the pool to take all space": [
  null,
  "Zväčšiť pool tak, aby využiť celý dostupný priestor"
 ],
 "This pool is in a degraded state.": [
  null,
  "Tento pool sa nachádza v degradovanom stave."
 ],
 "No filesystems": [
  null,
  "Systém súborov"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool súborových systémov Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Táto heslová fráza je jediným spôsobom, ako fond odomknúť a preto ho nie je možné odobrať."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tento server s kľúčmi je jediný spôsob ako pool odomknúť a nie je ho preto možné odobrať."
 ],
 "Add passphrase": [
  null,
  "Pridať heslovú frázu"
 ],
 "Add keyserver": [
  null,
  "Pridať server s kľúčmi"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  ""
 ],
 "Confirm": [
  null,
  "Potvrdiť"
 ],
 "Remove passphrase?": [
  null,
  "Odobrať heslovú frázu?"
 ],
 "Add Tang keyserver": [
  null,
  "Pridať Tang server s kľúčmi"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  ""
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Name can not be empty.": [
  null,
  "Názov je potrebné vyplniť."
 ],
 "A pool with this name exists already.": [
  null,
  "Pool s takým názvom už existuje."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Systém súborov s týmto názvom už v tomto poole existuje."
 ],
 "Create Stratis pool": [
  null,
  "Vytvoriť Stratis pool"
 ],
 "No block devices are available.": [
  null,
  "Nie sú dostupné žiadne blokové zariadenia."
 ],
 "At least one block device is needed.": [
  null,
  "Vyžaduje sa aspoň jedno blokové zariadenie."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Šifrovať údaje pomocou heslovej fráze"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Šifrovať údaje pomocou Tang servera s kľúčmi"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Vytvoriť snímku stavu súborového systému $0"
 ],
 "Create snapshot and mount": [
  null,
  "Vytvoriť snímku (snapshot) a pripojiť ju"
 ],
 "Create snapshot only": [
  null,
  "Iba vytvoriť snímku"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Odstránením systému súborov sa odstránia všetky údaje v ňom."
 ],
 "Snapshot": [
  null,
  "Zachytený stav"
 ],
 "Rename filesystem": [
  null,
  "Premenovať systém súborov"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Create RAID device": [
  null,
  "Vytvoriť RAID zariadenie"
 ],
 "RAID level": [
  null,
  "RAID level"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (prekladanie)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (zrkadlenie)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (vyhradená parita)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuovaná parita)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dvojitá distribuovaná parita)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (prekladanie zrkadiel)"
 ],
 "Chunk size": [
  null,
  "Veľkosť bloku"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Vyžaduje sa aspoň $0 disk.",
  "Vyžadujú sa aspoň $0 disky.",
  "Vyžaduje sa aspoň $0 diskov."
 ],
 "MDRAID disk": [
  null,
  "Disk MDRAID"
 ],
 "In sync": [
  null,
  "Synchronizované"
 ],
 "Spare": [
  null,
  "Náhradný"
 ],
 "Recovering": [
  null,
  "Zotavuje sa"
 ],
 "Write-mostly": [
  null,
  "Prevažne zápis"
 ],
 "Blocked": [
  null,
  "Blokované"
 ],
 "Unknown ($0)": [
  null,
  "Neznáme ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Je potrebné, aby bolo zariadenie MDRAID spustené"
 ],
 "MDRAID device is recovering": [
  null,
  "Zariadenie MDRAID sa zotavuje"
 ],
 "Need a spare disk": [
  null,
  "Potrebujete rezervný disk"
 ],
 "Last disk can not be removed": [
  null,
  "Posledný disk nie je možné odstrániť"
 ],
 "MDRAID device": [
  null,
  "Zariadenie MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Potvrďte zastavenie $0"
 ],
 "Stop device": [
  null,
  "Zastaviť zariadenie"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Odstránením sa zmažú všetky údaje na zariadení MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Je potrebné, aby zariadenie MDRAID bolo spustené"
 ],
 "Add disk": [
  null,
  "Pridať disk"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 Disky"
 ],
 "$0 chunk size": [
  null,
  "$0 Veľkosť bloku"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Zariadenie MDRAID je v degradovanom stave"
 ],
 "Add a bitmap": [
  null,
  "Pridať bitovú mapu"
 ],
 "No disks found": [
  null,
  "Neboli nájdené žiadne disky"
 ],
 "MDRAID disks": [
  null,
  "Disky MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Odstránením sa zmažú všetky údaje na zariadení VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Vytváranie tohoto VDO zariadenia nedokončilo a toto zariadenie nemôže byť použité."
 ],
 "Remove device": [
  null,
  "Odstrániť zariadenie"
 ],
 "Grow to take all space": [
  null,
  "Zväčšiť a využiť celý dostupný priestor"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Toto zariadenie VDI nepožíva zo svojho podkladového zariadenia všetko."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Využíva sa len $0 z $1."
 ],
 "Grow logical size of $0": [
  null,
  "Zväčšiť logickú veľkosť $0"
 ],
 "Physical": [
  null,
  "Fyzické"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dáta + $1 réžie využitéj z $2 ($3)"
 ],
 "Logical": [
  null,
  "Logický"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 použité z $1 ($2 ušetrené)"
 ],
 "Index memory": [
  null,
  "Pamäť indexu"
 ],
 "SMART self-test of $target": [
  null,
  "SMART samotest $target"
 ],
 "Ejecting $target": [
  null,
  "Vysúvam $target"
 ],
 "Unlocking $target": [
  null,
  "Odomykám $target"
 ],
 "Locking $target": [
  null,
  "Zamykám $target"
 ],
 "Modifying $target": [
  null,
  "Upravujem $target"
 ],
 "Resizing $target": [
  null,
  "Mením veľkosť $target"
 ],
 "Starting swapspace $target": [
  null,
  "Spúšťam odkladací (swap) priestor $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Zastavujem odkladací (swap) priestor $target"
 ],
 "Mounting $target": [
  null,
  "Pripájam $target"
 ],
 "Unmounting $target": [
  null,
  "Odpájam $target"
 ],
 "Checking $target": [
  null,
  "Overujem $target"
 ],
 "Repairing $target": [
  null,
  "Opravujem $target"
 ],
 "Erasing $target": [
  null,
  "Mažem $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Vytváram systém súborov na $target"
 ],
 "Setting up loop device $target": [
  null,
  "Nastavujem zariadenie spätnej slučky $target"
 ],
 "Deleting $target": [
  null,
  "Odstraňujem $target"
 ],
 "Creating partition $target": [
  null,
  "Vytváram oddiel $target"
 ],
 "Cleaning up for $target": [
  null,
  "Čistím pre $target"
 ],
 "Securely erasing $target": [
  null,
  "Bezpečne mažem $target"
 ],
 "Very securely erasing $target": [
  null,
  "Naozaj bezpečne mažem $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Zastavujem zariadenie MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Spúšťam zariadenie MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Označujem $target ako chybný"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Odstraňujem $target zo zariadenia MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Vytváram MDRAID zariadenie $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Overujem zariadenie MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Kontrolujem a opravujem MDRAID zariadenie $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Zotavuje sa zariadenie MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronizujem zariadenie MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Aktivujem $target"
 ],
 "Deactivating $target": [
  null,
  "Deaktivujem $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Vytváram snímku stavu $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Vytváram LVM2 skupinu zväzkov $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Odstraňujem LVM2 skupinu zväzkov $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Pridávam fyzický zväzok do $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Odstraňujem fyzický zväzok z $target"
 ],
 "Emptying $target": [
  null,
  "Vyprázdňujem $target"
 ],
 "Creating logical volume $target": [
  null,
  "Vytváram logický zväzok $target"
 ],
 "Renaming $target": [
  null,
  "Premenovávam $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operácia '$operation' na $target"
 ],
 "unknown target": [
  null,
  "neznámy cieľ"
 ],
 "Jobs": [
  null,
  "Úlohy"
 ],
 "Reading": [
  null,
  "Čítanie"
 ],
 "Writing": [
  null,
  "Zápis"
 ],
 "Install Stratis support": [
  null,
  "Nainštalovať podporu pre Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Na vytvorenie Stratis poolu je potrebné, aby bol nainštalovaný balíček $0."
 ],
 "Install NFS support": [
  null,
  "Nainštalovať podporu pre NFS"
 ],
 "Create MDRAID device": [
  null,
  "Vytvoriť zariadenie MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Vytvoriť LVM2 skupinu zväzkov (volume group)"
 ],
 "Change iSCSI initiator name": [
  null,
  "Zmeniť názov iSCSI iniciátoru"
 ],
 "Add iSCSI portal": [
  null,
  "Pridať iSCSI portál"
 ],
 "Local storage": [
  null,
  "Lokálne úložisko"
 ],
 "Networked storage": [
  null,
  "Sieťové úložisko"
 ],
 "Create storage device": [
  null,
  "Vytvoriť zariadenie úložiska"
 ],
 "No storage found": [
  null,
  "Nenašlo sa žiadne úložisko"
 ],
 "Server address cannot be empty.": [
  null,
  "Adresa server nemôže byť prázdna."
 ],
 "Next": [
  null,
  "Ďalej"
 ],
 "Invalid username or password": [
  null,
  "Neplatné meno používateľa alebo heslo"
 ],
 "Unknown host name": [
  null,
  "Neznámy názov stroja"
 ],
 "Unable to reach server": [
  null,
  "So serverom sa nepodarilo spojiť"
 ],
 "Available targets on $0": [
  null,
  "Dostupné ciele na $0"
 ],
 "Authentication required": [
  null,
  "Vyžaduje sa overenie"
 ],
 "iSCSI portal": [
  null,
  "Portál iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Jednotky iSCSI"
 ],
 "No drives found": [
  null,
  "Neboli nájdené žiadne jednotky"
 ],
 "Target": [
  null,
  "Cieľ"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Zariadenia, ktoré sú podkladom pre VDO, nie je možné zmenšovať"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Blokové zariadenia Stratis nie je možné zmenšovať"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nerozpoznané dáta tu nie je možné zmenšiť."
 ],
 "Unlock before resizing": [
  null,
  "Odomknúť pred zmenou veľkosti"
 ],
 "$0 can not be resized here": [
  null,
  "$0 tu nie je možné zmeniť veľkosť"
 ],
 "$0 can not be resized": [
  null,
  "Pre $0 nie je možné zmeniť veľkosť"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 nie je možné zmenšiť"
 ],
 "$0 can not be made larger": [
  null,
  "$0 nie je možné zväčšiť"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Tu nie je možné meniť veľkosti fyzických zväzkov"
 ],
 "Swap can not be resized here": [
  null,
  "Veľkosť odkladacieho oddielu (swap) tu nie je možné meniť"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Nerozpoznané dáta tu nie je možné zmenšiť"
 ],
 "Activate before resizing": [
  null,
  "Aktivujte pred zmenou veľkosti"
 ],
 "Grow logical volume": [
  null,
  "Zväčšiť logický zväzok"
 ],
 "Grow partition": [
  null,
  "Zväčšiť oddiel"
 ],
 "grow": [
  null,
  "zväčšiť"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Je potrebných vybrať presne $0 fyzických zväzkov"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zmena veľkosti šifrovaného systému súborov vyžaduje jeho odomknutie. Zadajte heslovú frázu."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Je potrebné vybrať presne $0 fyzických zväzkov – jeden pre každý z prúžkov (stripe) logického zväzku."
 ],
 "Shrink logical volume": [
  null,
  "Zmenšiť logický zväzok"
 ],
 "shrink": [
  null,
  "zmenšiť"
 ],
 "Unformatted data": [
  null,
  "Neformátované dáta"
 ],
 "Block device": [
  null,
  "Blokové zariadenie"
 ],
 "Device number": [
  null,
  "Číslo zariadenia"
 ],
 "Create partition on $0": [
  null,
  "Vytvoriť oddiel na $0"
 ],
 "Format $0": [
  null,
  "Formátovať $0"
 ],
 "No filesystem": [
  null,
  "Bez systému súborov"
 ],
 "(recommended)": [
  null,
  "(odporúčaný)"
 ],
 "No encryption": [
  null,
  "Bez šifrovania"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Použiť existujúce šifrovanie ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Použiť existujúce šifrovanie"
 ],
 "format": [
  null,
  "Formátovať"
 ],
 "Format and mount": [
  null,
  "Naformátovať a pripojiť"
 ],
 "Format only": [
  null,
  "Iba naformátovať"
 ],
 "Format": [
  null,
  "Formátovať"
 ],
 "Create and start": [
  null,
  "Vytvoriť a spustiť"
 ],
 "Format and start": [
  null,
  "Naformátovať a spustiť"
 ],
 "Store passphrase": [
  null,
  "Uložiť heslovú frázu"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formátovanie vymaže všetky údaje na úložnom zariadení."
 ],
 "Unrecognized data": [
  null,
  "Nerozpoznané dáta"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Úložisko nie je možné na tomto systéme spravovať."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bajty"
 ]
});
