cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_Hant",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman 容器"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "容器"
 ],
 "image": [
  null,
  "映像檔"
 ]
});
