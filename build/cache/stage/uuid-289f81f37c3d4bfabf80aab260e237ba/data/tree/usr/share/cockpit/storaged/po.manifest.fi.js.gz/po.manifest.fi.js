cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "unmount": [
  null,
  "irrota"
 ],
 "mount": [
  null,
  "liitos"
 ],
 "format": [
  null,
  "alusta"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "tiedostojärjestelmä"
 ],
 "partition": [
  null,
  "osio"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "taltio"
 ],
 "disk": [
  null,
  "levy"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "asema"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "salaus"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Osioiden hallinta"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-liitosten hallinta"
 ],
 "Managing RAIDs": [
  null,
  "RAIDien hallinta"
 ],
 "Managing LVMs": [
  null,
  "LVM:ien hallinta"
 ],
 "Managing physical drives": [
  null,
  "Fyysisten asemien hallinta"
 ],
 "Managing VDOs": [
  null,
  "VDO:iden hallinta"
 ],
 "Using LUKS encryption": [
  null,
  "Käytetään LUKS-salausta"
 ],
 "Using Tang server": [
  null,
  "Käytetään Tang-palvelinta"
 ]
});
