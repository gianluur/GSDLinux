cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "bg",
  "language-direction": "ltr"
 }
});
