cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servizi"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "network": [
  null,
  "rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interfaccia"
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "bond"
 ],
 "team": [
  null,
  "team"
 ],
 "port": [
  null,
  "porta"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zona"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Gestendo bond di rete"
 ],
 "Managing networking teams": [
  null,
  "Gestendo team della rete"
 ],
 "Managing networking bridges": [
  null,
  "Gestendo ponti della rete"
 ],
 "Managing VLANs": [
  null,
  "Gestione VLAN"
 ],
 "Managing firewall": [
  null,
  "Gestione del firewall"
 ]
});
