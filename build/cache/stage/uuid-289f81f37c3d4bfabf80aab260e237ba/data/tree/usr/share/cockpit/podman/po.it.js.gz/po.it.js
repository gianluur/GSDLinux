cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Eliminare $0?"
 ],
 "Force delete": [
  null,
  "Forza eliminazione"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Must be a valid IP address": [
  null,
  "Deve essere un indirizzo IP valido"
 ],
 "1 to 65535": [
  null,
  "Da 1 a 65535"
 ],
 "Container port must not be empty": [
  null,
  "La porta del container non deve essere vuota"
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "IP address help": [
  null,
  "Aiuto per l'indirizzo IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Se l'IP dell'host è impostato su 0.0.0.0 o non è impostato affatto, la porta verrà vincolata a tutti gli IP dell'host."
 ],
 "Host port": [
  null,
  "Porta host"
 ],
 "Host port help": [
  null,
  "Aiuto per la porta host"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Se la porta host non è impostata, alla porta del container verrà assegnata casualmente una porta sull'host."
 ],
 "Container port": [
  null,
  "Porta container"
 ],
 "Protocol": [
  null,
  "Protocollo"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Rimuovi elemento"
 ],
 "Image name is required": [
  null,
  "Il nome dell'immagine è obbligatorio"
 ],
 "Image name is not unique": [
  null,
  "Il nome dell'immagine non è univoco"
 ],
 "Failed to commit container $0": [
  null,
  "Commit del container $0 non riuscito"
 ],
 "New image name": [
  null,
  "Nuovo nome immagine"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Author": [
  null,
  "Autore"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Esempio, Il Tuo Nome <tuonome@example.com>"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Pause container when creating image": [
  null,
  "Metti in pausa il container durante la creazione dell'immagine"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Il formato Docker è utile quando si condivide l'immagine con Docker o Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Usa formato Docker legacy"
 ],
 "Commit container": [
  null,
  "Esegui commit del container"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crea una nuova immagine basata sullo stato corrente del container $0."
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Force commit": [
  null,
  "Forza commit"
 ],
 "Failed to force remove container $0": [
  null,
  "Rimozione forzata del container $0 non riuscita"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "L'eliminazione di un container in esecuzione cancellerà tutti i dati al suo interno."
 ],
 "Failed to stop container $0": [
  null,
  "Arresto del container $0 non riuscito"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Arresto del quadlet $0 non riuscito"
 ],
 "Failed to start quadlet $0": [
  null,
  "Avvio del quadlet $0 non riuscito"
 ],
 "Failed to start container $0": [
  null,
  "Avvio del container $0 non riuscito"
 ],
 "Failed to resume container $0": [
  null,
  "Ripresa del container $0 non riuscita"
 ],
 "Failed to pause container $0": [
  null,
  "Messa in pausa del container $0 non riuscita"
 ],
 "Failed to restart container $0": [
  null,
  "Riavvio del container $0 non riuscito"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Riavvio del quadlet $0 non riuscito"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Stop": [
  null,
  "Arresta"
 ],
 "Restart": [
  null,
  "Riavvia"
 ],
 "Force stop": [
  null,
  "Forza arresto"
 ],
 "Force restart": [
  null,
  "Forza riavvio"
 ],
 "Pause": [
  null,
  "Metti in pausa"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Checkpoint": [
  null,
  "Checkpoint"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Restore": [
  null,
  "Ripristina"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Healthy": [
  null,
  "Integro"
 ],
 "Unhealthy": [
  null,
  "Non integro"
 ],
 "Checking health": [
  null,
  "Controllo dello stato di salute"
 ],
 "Prune unused containers": [
  null,
  "Elimina container non utilizzati"
 ],
 "Terminal not available": [
  null,
  "Terminale non disponibile"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Questo browser non supporta WebGL2."
 ],
 "View $0 logs": [
  null,
  "Visualizza $0 log"
 ],
 "not available": [
  null,
  "non disponibile"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "$0% of $1 limit": [
  null,
  "$0% del limite di $1"
 ],
 "service": [
  null,
  "servizio"
 ],
 "system": [
  null,
  "sistema"
 ],
 "user:": [
  null,
  "utente:"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Integration": [
  null,
  "Integrazione"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Health check": [
  null,
  "Controllo di salute"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Click to see published ports": [
  null,
  "Fai clic per vedere le porte pubblicate"
 ],
 "ports": [
  null,
  "porte"
 ],
 "Click to see volumes": [
  null,
  "Fai clic per vedere i volumi"
 ],
 "volumes": [
  null,
  "volumi"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Owner": [
  null,
  "Proprietario"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "No containers": [
  null,
  "Nessun container"
 ],
 "No containers in this pod": [
  null,
  "Nessun container in questo pod"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "No containers that match the current filter": [
  null,
  "Nessun container corrisponde al filtro corrente"
 ],
 "No running containers": [
  null,
  "Nessun container in esecuzione"
 ],
 "Show": [
  null,
  "Mostra"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "Only running": [
  null,
  "Solo in esecuzione"
 ],
 "Create pod": [
  null,
  "Crea pod"
 ],
 "Create container": [
  null,
  "Crea container"
 ],
 "Containers": [
  null,
  "Container"
 ],
 "Create container in pod": [
  null,
  "Crea container nel pod"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Ripristino del container $0 non riuscito"
 ],
 "Restore container $0": [
  null,
  "Ripristina container $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Conserva tutti i file di checkpoint temporanei"
 ],
 "Restore with established TCP connections": [
  null,
  "Ripristina con connessioni TCP stabilite"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignora indirizzo IP se impostato staticamente"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignora indirizzo MAC se impostato staticamente"
 ],
 "Pod failed to be created": [
  null,
  "Creazione del pod non riuscita"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caratteri non validi. Il nome può contenere solo lettere, numeri e alcuni segni di punteggiatura (_ . -)."
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Pod name": [
  null,
  "Nome pod"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "User:": [
  null,
  "Utente:"
 ],
 "No ports exposed": [
  null,
  "Nessuna porta esposta"
 ],
 "Port mapping": [
  null,
  "Mappatura porta"
 ],
 "Add port mapping": [
  null,
  "Aggiungi mappatura porta"
 ],
 "No volumes specified": [
  null,
  "Nessun volume specificato"
 ],
 "Volumes": [
  null,
  "Volumi"
 ],
 "Add volume": [
  null,
  "Aggiungi volume"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Type to filter…": [
  null,
  "Digita per filtrare…"
 ],
 "Container path must not be empty": [
  null,
  "Il percorso del container non deve essere vuoto"
 ],
 "Host path": [
  null,
  "Percorso host"
 ],
 "Container path": [
  null,
  "Percorso container"
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Writable": [
  null,
  "Scrivibile"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Nessuna etichetta"
 ],
 "Shared": [
  null,
  "Condiviso"
 ],
 "Private": [
  null,
  "Privato"
 ],
 "Read-write access": [
  null,
  "Accesso in lettura-scrittura"
 ],
 "Read-only access": [
  null,
  "Accesso in sola lettura"
 ],
 "Show less": [
  null,
  "Mostra meno"
 ],
 "Show more": [
  null,
  "Mostra di più"
 ],
 "Loading details...": [
  null,
  "Caricamento dettagli in corso..."
 ],
 "Ports": [
  null,
  "Porte"
 ],
 "Environment variables": [
  null,
  "Variabili d'ambiente"
 ],
 "Failed to download image $0:$1": [
  null,
  "Scaricamento dell'immagine $0:$1 non riuscito"
 ],
 "Error message": [
  null,
  "Messaggio di errore"
 ],
 "unused": [
  null,
  "non utilizzato"
 ],
 "$0 container": [
  null,
  "$0 container",
  "$0 container"
 ],
 "History": [
  null,
  "Cronologia"
 ],
 "Image": [
  null,
  "Immagine"
 ],
 "Created": [
  null,
  "Creato"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Spazio su disco"
 ],
 "Used by": [
  null,
  "Utilizzato da"
 ],
 "No images": [
  null,
  "Nessuna immagine"
 ],
 "No images that match the current filter": [
  null,
  "Nessuna immagine corrisponde al filtro corrente"
 ],
 "Hide intermediate images": [
  null,
  "Nascondi immagini intermedie"
 ],
 "Show intermediate images": [
  null,
  "Mostra immagini intermedie"
 ],
 "Images": [
  null,
  "Immagini"
 ],
 "$0 image total, $1": [
  null,
  "$0 immagine totale, $1",
  "$0 immagini totali, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 immagine non utilizzata, $1",
  "$0 immagini non utilizzate, $1"
 ],
 "Hide images": [
  null,
  "Nascondi immagini"
 ],
 "Show images": [
  null,
  "Mostra immagini"
 ],
 "Pulling": [
  null,
  "Pull in corso"
 ],
 "Download new image": [
  null,
  "Scarica nuova immagine"
 ],
 "Pull all images": [
  null,
  "Fai il pull di tutte le immagini"
 ],
 "Prune unused images": [
  null,
  "Elimina immagini non utilizzate"
 ],
 "Pull": [
  null,
  "Pull"
 ],
 "Up since:": [
  null,
  "Attivo da:"
 ],
 "Exited": [
  null,
  "Terminato"
 ],
 "systemd service": [
  null,
  "servizio systemd"
 ],
 "View $0": [
  null,
  "Visualizza $0"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "MAC address": [
  null,
  "Indirizzo MAC"
 ],
 "Latest checkpoint": [
  null,
  "Ultimo checkpoint"
 ],
 "No containers are using this image": [
  null,
  "Nessun container sta usando questa immagine"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "Loading logs...": [
  null,
  "Caricamento log in corso..."
 ],
 "Delete unused system images:": [
  null,
  "Elimina immagini di sistema non utilizzate:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Elimina immagini non utilizzate dell'utente $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Eliminazione delle immagini non utilizzate non riuscita"
 ],
 "Pruning images": [
  null,
  "Eliminazione immagini in corso"
 ],
 "Prune": [
  null,
  "Elimina"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Checkpoint del container $0 non riuscito"
 ],
 "Checkpoint container $0": [
  null,
  "Esegui checkpoint del container $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Lascia in esecuzione dopo aver scritto il checkpoint su disco"
 ],
 "Support preserving established TCP connections": [
  null,
  "Supporta la conservazione delle connessioni TCP stabilite"
 ],
 "Failed to search for new images": [
  null,
  "Ricerca di nuove immagini non riuscita"
 ],
 "Failed to search for images: $0": [
  null,
  "Ricerca immagini non riuscita: $0"
 ],
 "Failed to search for images.": [
  null,
  "Ricerca immagini non riuscita."
 ],
 "Search for an image": [
  null,
  "Cerca un'immagine"
 ],
 "Search for": [
  null,
  "Cerca"
 ],
 "Search by name or description": [
  null,
  "Cerca per nome o descrizione"
 ],
 "in": [
  null,
  "in"
 ],
 "All registries": [
  null,
  "Tutti i registri"
 ],
 "Searching...": [
  null,
  "Ricerca in corso..."
 ],
 "No images found": [
  null,
  "Nessuna immagine trovata"
 ],
 "Start typing to look for images.": [
  null,
  "Inizia a digitare per cercare immagini."
 ],
 "No results for $0": [
  null,
  "Nessun risultato per $0"
 ],
 "Retry another term.": [
  null,
  "Riprova con un altro termine."
 ],
 "Download": [
  null,
  "Scarica"
 ],
 "No action": [
  null,
  "Nessuna azione"
 ],
 "Container failed to be started": [
  null,
  "Avvio del container non riuscito"
 ],
 "Failed to clean up container": [
  null,
  "Pulizia del container non riuscita"
 ],
 "Container failed to be created": [
  null,
  "Creazione del container non riuscita"
 ],
 "downloading": [
  null,
  "scaricamento in corso"
 ],
 "Failed to run container $0": [
  null,
  "Esecuzione del container $0 non riuscita"
 ],
 "Failed to create container $0": [
  null,
  "Creazione del container $0 non riuscita"
 ],
 "Failed to pull image $0": [
  null,
  "Pull dell'immagine $0 non riuscito"
 ],
 "Local images": [
  null,
  "Immagini locali"
 ],
 "Name already in use": [
  null,
  "Nome già in uso"
 ],
 "Search by registry": [
  null,
  "Cerca per registro"
 ],
 "Local": [
  null,
  "Locale"
 ],
 "Container name": [
  null,
  "Nome container"
 ],
 "Owner help": [
  null,
  "Guida proprietario"
 ],
 "Ideal for running services": [
  null,
  "Ideale per l'esecuzione di servizi"
 ],
 "Resource limits can be set": [
  null,
  "È possibile impostare limiti di risorse"
 ],
 "Checkpoint and restore support": [
  null,
  "Supporto per checkpoint e ripristino"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Le porte inferiori a 1024 possono essere mappate"
 ],
 "User": [
  null,
  "Utente"
 ],
 "Ideal for development": [
  null,
  "Ideale per lo sviluppo"
 ],
 "Restricted by user account permissions": [
  null,
  "Limitato dai permessi dell'account utente"
 ],
 "Image selection help": [
  null,
  "Guida selezione immagine"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:porta]/[utente]/container[:tag]"
 ],
 "Example: $0": [
  null,
  "Esempio: $0"
 ],
 "Searching: $0": [
  null,
  "Ricerca: $0"
 ],
 "Search string or container location": [
  null,
  "Stringa di ricerca o posizione del container"
 ],
 "Pull latest image": [
  null,
  "Fai il pull dell'immagine più recente"
 ],
 "Entrypoint": [
  null,
  "Punto d'ingresso"
 ],
 "With terminal": [
  null,
  "Con terminale"
 ],
 "Memory limit": [
  null,
  "Limite memoria"
 ],
 "Decrease memory": [
  null,
  "Diminuisci memoria"
 ],
 "Increase memory": [
  null,
  "Aumenta memoria"
 ],
 "Memory unit": [
  null,
  "Unità di memoria"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Quote CPU"
 ],
 "CPU Shares help": [
  null,
  "Guida per le quote CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Le quote CPU determinano la priorità dei container in esecuzione. La priorità predefinita è 1024. Un numero più alto dà priorità a questo container. Un numero più basso ne diminuisce la priorità."
 ],
 "Decrease CPU shares": [
  null,
  "Diminuisci quote CPU"
 ],
 "Increase CPU shares": [
  null,
  "Aumenta quote CPU"
 ],
 "Restart policy": [
  null,
  "Politica di riavvio"
 ],
 "Restart policy help": [
  null,
  "Guida politica di riavvio"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Politica di riavvio da seguire quando i container terminano. L'uso del linger per l'avvio automatico dei container potrebbe non funzionare in alcune circostanze, ad esempio quando si utilizzano ecryptfs, systemd-homed, NFS o 2FA su un account utente."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Politica di riavvio da seguire quando i container terminano."
 ],
 "No": [
  null,
  "No"
 ],
 "On failure": [
  null,
  "In caso di fallimento"
 ],
 "Always": [
  null,
  "Sempre"
 ],
 "Maximum retries": [
  null,
  "Tentativi massimi"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuisci tentativi massimi"
 ],
 "Increase maximum retries": [
  null,
  "Aumenta tentativi massimi"
 ],
 "No environment variables specified": [
  null,
  "Nessuna variabile d'ambiente specificata"
 ],
 "Add variable": [
  null,
  "Aggiungi variabile"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Incolla una o più righe di coppie chiave=valore in qualsiasi campo per l'importazione massiva"
 ],
 "Interval": [
  null,
  "Intervallo"
 ],
 "Health check interval help": [
  null,
  "Guida per l'intervallo del controllo di salute"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervallo di esecuzione del controllo di salute."
 ],
 "Decrease interval": [
  null,
  "Diminuisci intervallo"
 ],
 "Increase interval": [
  null,
  "Aumenta intervallo"
 ],
 "seconds": [
  null,
  "secondi"
 ],
 "Timeout": [
  null,
  "Tempo scaduto"
 ],
 "Health check timeout help": [
  null,
  "Guida per il timeout del controllo di salute"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Il tempo massimo consentito per completare il controllo di salute prima che un intervallo sia considerato fallito."
 ],
 "Decrease timeout": [
  null,
  "Diminuisci timeout"
 ],
 "Increase timeout": [
  null,
  "Aumenta timeout"
 ],
 "Start period": [
  null,
  "Periodo di avvio"
 ],
 "Health check start period help": [
  null,
  "Guida per il periodo di avvio del controllo di salute"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Il tempo di inizializzazione necessario a un container per avviarsi."
 ],
 "Decrease start period": [
  null,
  "Diminuisci periodo di avvio"
 ],
 "Increase start period": [
  null,
  "Aumenta periodo di avvio"
 ],
 "Retries": [
  null,
  "Tentativi"
 ],
 "Health check retries help": [
  null,
  "Guida per i tentativi del controllo di salute"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Il numero di tentativi consentiti prima che un controllo di salute sia considerato non integro."
 ],
 "Decrease retries": [
  null,
  "Diminuisci tentativi"
 ],
 "Increase retries": [
  null,
  "Aumenta tentativi"
 ],
 "When unhealthy": [
  null,
  "Quando non integro"
 ],
 "Health failure check action help": [
  null,
  "Guida per l'azione di controllo del fallimento di salute"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Azione da intraprendere quando il container passa a uno stato non integro."
 ],
 "Create container in $0": [
  null,
  "Crea container in $0"
 ],
 "Create and run": [
  null,
  "Crea ed esegui"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "Links": [
  null,
  "Link"
 ],
 "Documentation": [
  null,
  "Documentazione"
 ],
 "Tags": [
  null,
  "Tag"
 ],
 "Created by": [
  null,
  "Creato da"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Comments": [
  null,
  "Commenti"
 ],
 "Unable to load image history": [
  null,
  "Impossibile caricare la cronologia dell'immagine"
 ],
 "Key must not be empty": [
  null,
  "La chiave non deve essere vuota"
 ],
 "Key must not begin with a digit": [
  null,
  "La chiave non deve iniziare con una cifra"
 ],
 "Key contains invalid characters": [
  null,
  "La chiave contiene caratteri non validi"
 ],
 "Key": [
  null,
  "Chiave"
 ],
 "Value": [
  null,
  "Valore"
 ],
 "user": [
  null,
  "utente"
 ],
 "Podman service failed": [
  null,
  "Servizio Podman non riuscito"
 ],
 "Troubleshoot": [
  null,
  "Risoluzione problemi"
 ],
 "Failed to force remove image $0": [
  null,
  "Rimozione forzata dell'immagine $0 non riuscita"
 ],
 "intermediate image": [
  null,
  "immagine intermedia"
 ],
 "Failed to remove image $0": [
  null,
  "Rimozione dell'immagine $0 non riuscita"
 ],
 "intermediate": [
  null,
  "intermedio"
 ],
 "Delete $0 image?": [
  null,
  "Eliminare l'immagine $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Esistono più tag per questa immagine. Seleziona le immagini con tag da eliminare."
 ],
 "Delete image": [
  null,
  "Elimina immagine"
 ],
 "Delete tagged images": [
  null,
  "Elimina immagini con tag"
 ],
 "Container is not running": [
  null,
  "Il container non è in esecuzione"
 ],
 "Error occurred while connecting console": [
  null,
  "Errore durante la connessione alla console"
 ],
 "Force delete pod $0?": [
  null,
  "Forzare l'eliminazione del pod $0?"
 ],
 "Delete pod $0?": [
  null,
  "Eliminare il pod $0?"
 ],
 "An error occurred": [
  null,
  "Si è verificato un errore"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Il pod vuoto $0 sarà rimosso permanentemente."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "L'eliminazione di questo pod rimuoverà i seguenti container:"
 ],
 "Failed to start pod $0": [
  null,
  "Avvio del pod $0 non riuscito"
 ],
 "Failed to stop pod $0": [
  null,
  "Arresto del pod $0 non riuscito"
 ],
 "Failed to restart pod $0": [
  null,
  "Riavvio del pod $0 non riuscito"
 ],
 "Failed to resume pod $0": [
  null,
  "Ripresa del pod $0 non riuscita"
 ],
 "Failed to pause pod $0": [
  null,
  "Messa in pausa del pod $0 non riuscita"
 ],
 "Failed to prune unused containers": [
  null,
  "Eliminazione dei container non utilizzati non riuscita"
 ],
 "Removes selected non-running containers": [
  null,
  "Rimuove i container selezionati non in esecuzione"
 ],
 "Pruning containers": [
  null,
  "Eliminazione container in corso"
 ],
 "Container name is required.": [
  null,
  "Il nome del container è obbligatorio."
 ],
 "Failed to rename container $0": [
  null,
  "Ridenominazione del container $0 non riuscita"
 ],
 "New container name": [
  null,
  "Nuovo nome container"
 ],
 "Rename container $0": [
  null,
  "Rinomina container $0"
 ],
 "Paused": [
  null,
  "In pausa"
 ],
 "Stopped": [
  null,
  "Arrestato"
 ],
 "Removing": [
  null,
  "Rimozione in corso"
 ],
 "Configured": [
  null,
  "Configurato"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "$0 second": [
  null,
  "$0 secondo",
  "$0 secondi"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Failing streak": [
  null,
  "Serie di fallimenti"
 ],
 "Failed to run health check on container $0": [
  null,
  "Esecuzione del controllo di salute sul container $0 non riuscita"
 ],
 "Run health check": [
  null,
  "Esegui controllo di salute"
 ],
 "Last 5 runs": [
  null,
  "Ultime 5 esecuzioni"
 ],
 "Started at": [
  null,
  "Avviato alle"
 ],
 "Passed health run": [
  null,
  "Esecuzione controllo di salute superata"
 ],
 "Failed health run": [
  null,
  "Esecuzione controllo di salute fallita"
 ],
 "Failed to remove container $0": [
  null,
  "Rimozione del container $0 non riuscita"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "L'eliminazione di un container cancellerà tutti i dati al suo interno."
 ]
});
