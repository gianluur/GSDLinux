cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "or",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
