cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "user": [
  null,
  "användare"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
