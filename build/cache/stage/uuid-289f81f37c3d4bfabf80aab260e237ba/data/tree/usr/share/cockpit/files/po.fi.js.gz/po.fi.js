cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit-tiedostot"
 ],
 "Home": [
  null,
  "Koti"
 ],
 "Unable to create bookmark directory": [
  null,
  "Kirjanmerkkihakemistoa ei voi luoda"
 ],
 "Unable to save bookmark file": [
  null,
  "Kirjanmerkkitiedostoa ei voi tallentaa"
 ],
 "Remove from bookmarks": [
  null,
  "Poista kirjanmerkeistä"
 ],
 "Add to bookmarks": [
  null,
  "Lisää kirjanmerkkeihin"
 ],
 "Bookmarks": [
  null,
  "Kirjanmerkit"
 ],
 "Bookmarked": [
  null,
  "Merkitty kirjanmerkiksi"
 ],
 "Not bookmarked": [
  null,
  "Ei kirjanmerkkeihin lisätty"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Edit path": [
  null,
  "Muokkaa polkua"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Largest size": [
  null,
  "Suurin koko"
 ],
 "Smallest size": [
  null,
  "Pienin koko"
 ],
 "Modified": [
  null,
  "Muokattu"
 ],
 "First modified": [
  null,
  "Ensin muokattu"
 ],
 "Last modified": [
  null,
  "Viimeksi muokattu"
 ],
 "Owner": [
  null,
  "Omistaja"
 ],
 "Owner ascending": [
  null,
  "Omistaja nouseva"
 ],
 "Owner descending": [
  null,
  "Omistaja laskeva"
 ],
 "Permissions": [
  null,
  "Käyttöoikeudet"
 ],
 "Most permissive": [
  null,
  "Eniten salliva"
 ],
 "Least permissive": [
  null,
  "Vähiten salliva"
 ],
 "Show keyboard shortcuts": [
  null,
  "Näytä pikanäppäimet"
 ],
 "Filter directory": [
  null,
  "Suodata hakemisto"
 ],
 "Display as a list": [
  null,
  "Näytä luettelona"
 ],
 "Display as a grid": [
  null,
  "Näytä ruudukkona"
 ],
 "Sort": [
  null,
  "Järjestele"
 ],
 "Hide hidden items": [
  null,
  "Piilota piilotetut kohteet"
 ],
 "Show hidden items": [
  null,
  "Näytä piilotetut kohteet"
 ],
 "$0 files": [
  null,
  "$0 tiedostoa"
 ],
 "Uploaded as $0, $1": [
  null,
  "Ladattu ulospäin $0:na, $1"
 ],
 "Replace file $0?": [
  null,
  "Vaihdetaanko tiedosto $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Samanniminen tiedosto on jo olemassa \"$0\":ssa. Sen vaihtaminen korvaa sen sisällön."
 ],
 "New file": [
  null,
  "Uusi tiedosto"
 ],
 "Original file on server": [
  null,
  "Alkuperäinen tiedosto palvelimella"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Käytä tätä toimintoa kaikkiin ristiriitaisiin tiedostoihin"
 ],
 "Replace": [
  null,
  "Vaihda"
 ],
 "Keep original": [
  null,
  "Säilytä alkuperäinen"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Upload error": [
  null,
  "Lataus ulospäin -virhe"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Ulospäinladattua tiedostoa ei voida siirtää lopulliseen määränpäähän"
 ],
 "Cancelled": [
  null,
  "Peruttu"
 ],
 "Cancelled upload of $0": [
  null,
  "$0:n lataus ulospäin peruttu"
 ],
 "File uploaded": [
  null,
  "Tiedosto ladattu ulospäin"
 ],
 "Files uploaded": [
  null,
  "Tiedostot ladattu ulospäin"
 ],
 "Change permissions": [
  null,
  "Muuta käyttöoikeuksia"
 ],
 "Uploads": [
  null,
  "Lataukset ulospäin"
 ],
 "Cancel upload of $0": [
  null,
  "Peru $0:n lataus ulospäin"
 ],
 "Upload $0% completed": [
  null,
  "Lataus ulospäin $0 % valmis"
 ],
 "Upload": [
  null,
  "Lataa ulospäin"
 ],
 "None": [
  null,
  "Ei mitään"
 ],
 "Execute-only": [
  null,
  "Vain suoritettavaksi"
 ],
 "Write-only": [
  null,
  "Vain kirjoitus"
 ],
 "Write and execute": [
  null,
  "Kirjoitus ja suoritus"
 ],
 "Read-only": [
  null,
  "Vain luku"
 ],
 "Read and execute": [
  null,
  "Luku ja suoritus"
 ],
 "Read and write": [
  null,
  "Luku ja kirjoitus"
 ],
 "Read, write, and execute": [
  null,
  "Luku, kirjoitus ja suoritus"
 ],
 "Block device": [
  null,
  "Lohkolaite"
 ],
 "Character device": [
  null,
  "Merkkilaite"
 ],
 "Directory": [
  null,
  "Hakemisto"
 ],
 "Named pipe": [
  null,
  "Nimetty putki"
 ],
 "Symbolic link": [
  null,
  "Symbolinen linkki"
 ],
 "Regular file": [
  null,
  "Säännöllinen tiedosto"
 ],
 "Socket": [
  null,
  "Pistoke"
 ],
 "Name cannot be empty": [
  null,
  "Nimi ei voi olla tyhjä"
 ],
 "Name too long": [
  null,
  "Nimi liian pitkä"
 ],
 "Name cannot include a /": [
  null,
  "Nimessä ei saa olla \"/\""
 ],
 "Filename is the same as original name": [
  null,
  "Tiedostonimi on sama kuin alkuperäinen nimi"
 ],
 "Directory with the same name exists": [
  null,
  "Samanniminen hakemisto on olemassa"
 ],
 "File exists": [
  null,
  "Tiedosto on olemassa"
 ],
 "Pasting failed": [
  null,
  "Liittäminen epäonnistui"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" on olemassa, eikä sitä korvata liittämällä."
 ],
 "Paste": [
  null,
  "Liitä"
 ],
 "Create directory": [
  null,
  "Luo hakemisto"
 ],
 "Create file": [
  null,
  "Luo tiedosto"
 ],
 "Edit permissions": [
  null,
  "Muokkaa käyttöoikeuksia"
 ],
 "Open in terminal": [
  null,
  "Avaa päätteessä"
 ],
 "Open text file": [
  null,
  "Avaa tekstitiedosto"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Download": [
  null,
  "Lataus"
 ],
 "Create link": [
  null,
  "Luo linkki"
 ],
 "Drop files to upload": [
  null,
  "Pudota ulospäinladattavat tiedostot"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Tiedostoja ei voi pudottaa, toinen lataus ulospäin on jo meneillään"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Go up a directory": [
  null,
  "Siirry yksi hakemisto ylös"
 ],
 "Go back": [
  null,
  "Siirry taaksepäin"
 ],
 "Go forward": [
  null,
  "Siirry eteenpäin"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktivoi valittu kohde, siirry hakemistoon"
 ],
 "Rename selected file or directory": [
  null,
  "Nimeä valittu tiedosto tai hakemisto uudelleen"
 ],
 "Create new directory": [
  null,
  "Luo uusi hakemisto"
 ],
 "Copy selected file or directory": [
  null,
  "Kopioi valittu tiedosto tai kansio"
 ],
 "Paste file or directory": [
  null,
  "Liitä tiedosto tai hakemisto"
 ],
 "Select all": [
  null,
  "Valitse kaikki"
 ],
 "Save current file": [
  null,
  "Tallenna nykyinen tiedosto"
 ],
 "Close editor": [
  null,
  "Sulje editori"
 ],
 "Keyboard shortcuts": [
  null,
  "Pikanäppäimet"
 ],
 "Navigation": [
  null,
  "Navigointi"
 ],
 "Editing": [
  null,
  "Muokataan"
 ],
 "Editor": [
  null,
  "Muokkain"
 ],
 "Force delete $0 items": [
  null,
  "Pakota $0:n kohteiden poisto"
 ],
 "Delete $0 items?": [
  null,
  "Poistetaanko $0 kohdetta?"
 ],
 "Force delete file $0?": [
  null,
  "Pakottaako tiedoston $0 poisto?"
 ],
 "Delete file $0?": [
  null,
  "Poistetaanko tiedosto $0?"
 ],
 "Force delete link $0?": [
  null,
  "Pakottaako linkin $0 poisto?"
 ],
 "Delete link $0?": [
  null,
  "Poistetaanko linkki $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Pakottaako hakemiston $0 poisto?"
 ],
 "Delete directory $0?": [
  null,
  "Poistetaanko hakemisto $0?"
 ],
 "Force delete $0": [
  null,
  "Pakota $0:n poisto"
 ],
 "Delete $0?": [
  null,
  "Poistetaanko $0?"
 ],
 "No access": [
  null,
  "Ei pääsyä"
 ],
 "Missing type": [
  null,
  "Puuttuva tyyppi"
 ],
 "Collapse": [
  null,
  "Romahda"
 ],
 "Show all files": [
  null,
  "Näytä kaikki tiedostot"
 ],
 "$0 permissions": [
  null,
  "$0 käyttöoikeudet"
 ],
 "Permissions for $0 files": [
  null,
  "Käyttöoikeudet $0 tiedostoille"
 ],
 "Ownership": [
  null,
  "Omistajuus"
 ],
 "Group": [
  null,
  "Ryhmä"
 ],
 "Access": [
  null,
  "Pääsy"
 ],
 "Owner access": [
  null,
  "Omistajan pääsy"
 ],
 "Group access": [
  null,
  "Ryhmään pääsy"
 ],
 "Others access": [
  null,
  "Muiden pääsy"
 ],
 "Security context": [
  null,
  "Turvakonteksti"
 ],
 "Set executable as program": [
  null,
  "Määritä suoritettava ohjelmaksi"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change permissions for enclosed files": [
  null,
  "Muuta suljettujen tiedostojen käyttöoikeuksia"
 ],
 "(original owner)": [
  null,
  "(alkuperäinen omistaja)"
 ],
 "keep original owners": [
  null,
  "säilytä alkuperäiset omistajat"
 ],
 "Paste as owner": [
  null,
  "Liitä omistajana"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Liitettävällä tiedostolla on eri omistaja. Oletusarvoisesti omistajuus muutetaan vastaamaan kohdehakemistoa."
 ],
 "New owner": [
  null,
  "Uusi omistaja"
 ],
 "Overwrite": [
  null,
  "Korvaa"
 ],
 "New filename": [
  null,
  "Uusi tiedostonimi"
 ],
 "New name": [
  null,
  "Uusi nimi"
 ],
 "Rename $0?": [
  null,
  "Nimetäänkö $0 uudelleen?"
 ],
 "link to $0": [
  null,
  "linkki $0:iin"
 ],
 "Create link to $0": [
  null,
  "Luo linkki $0:iin"
 ],
 "Target": [
  null,
  "Kohde"
 ],
 "Symlink name": [
  null,
  "Symbolisen linkin nimi"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Absolute vs. Relative": [
  null,
  "Absoluuttinen vs. suhteellinen"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Absoluuttiset symbolilinkit ovat ihanteellisia, kun viitataan tiedostoihin tai hakemistoihin, jotka eivät liiku, kuten järjestelmätiedostot."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Suhteelliset symbolilinkit ovat hyödyllisiä silloin, kun sekä symbolilinkki että kohde voivat liikkua samanaikaisesti, esimerkiksi kun nimetään uudelleen tai siirretään ylähakemistoa."
 ],
 "Absolute": [
  null,
  "Absoluuttinen"
 ],
 "Relative": [
  null,
  "Suhteellinen"
 ],
 "The file has been removed on disk": [
  null,
  "Tiedosto on poistettu levyltä"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Olemassa oleva tiedosto muuttui odottamatta"
 ],
 "Edit $0": [
  null,
  "Muokkaa $0"
 ],
 "View $0": [
  null,
  "Näytä $0"
 ],
 "The file has changed on disk": [
  null,
  "Tiedosto on muuttunut levyllä"
 ],
 "Reload": [
  null,
  "Lataa uudelleen"
 ],
 "Ignore": [
  null,
  "Ohita"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Save changes?": [
  null,
  "Tallennetaanko muutokset?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Tiedosto poistettiin avaamisen jälkeen, tallentaminen luo sen uudelleen."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Tiedosto on muuttunut levyllä sen avaamisen ja nykyhetken välillä"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0:ssa on tallentamattomia muutoksia, jotka menetetään pysyvästi, jos se hylätään."
 ],
 "Discard": [
  null,
  "Hylkää"
 ],
 "File name": [
  null,
  "Tiedostonimi"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Cannot create file in current directory": [
  null,
  "Nykyiseen hakemistoon ei voi luoda tiedostoa"
 ],
 "Permission denied": [
  null,
  "Käyttö estetty"
 ],
 "Directory name cannot be empty": [
  null,
  "Hakemiston nimi ei voi olla tyhjä"
 ],
 "Directory name too long": [
  null,
  "Hakemiston nimi liian pitkä"
 ],
 "Directory name cannot include a /": [
  null,
  "Hakemiston nimessä ei voi olla \"/\""
 ],
 "Directory name": [
  null,
  "Hakemiston nimi"
 ],
 "Directory owner": [
  null,
  "Hakemiston omistaja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "Clear filter": [
  null,
  "Tyhjennä suodatin"
 ],
 "Directory is empty": [
  null,
  "Hakemisto on tyhjä"
 ],
 "$0 item is hidden": [
  null,
  "$0 kohde on piilotettu",
  "$0 kohdetta on piilotettu"
 ],
 "Folder": [
  null,
  "Kansio"
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Others": [
  null,
  "Muut"
 ],
 "$0 files selected": [
  null,
  "$0 tiedostoa valittu"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Hakemisto sisältää $0 hakemistoa, $1 tiedostoa"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Hakemisto sisältää $0 hakemistoa, $1 tiedostoa, $2 piilotettua"
 ],
 "User": [
  null,
  "Käyttäjä"
 ]
});
