cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 kesalahan"
 ],
 "$0 installation": [
  null,
  "Instalasi $0"
 ],
 "$0 installer": [
  null,
  "Pemasang $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 adalah partisi MBR yang diperluas yang berisi partisi logis. Menghapus semua partisi logis juga akan secara otomatis menghapus partisi yang diperluas."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Dibutuhkan $0, tetapi hanya tersedia $1."
 ],
 "$0 warning": [
  null,
  "$0 peringatan"
 ],
 "$0 will be deleted": [
  null,
  "$0 akan dihapus"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Sistem berkas '$0' tidak dapat berada di perangkat blok yang dienkripsi"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' harus di alokasikan ke $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' harus berada pada peranti yang diformat ke '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' harus berada pada Partisi Sistem EFI. Partisi yang dipilih menggunakan sistem file FAT, tetapi tidak ditandai sebagai ESP. Atur tipe partisi ke Sistem EFI dan aktifkan penanda esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Partisi '$0' pada perangkat MDRAID $1 ditemukan. Partisi bootloader pada perangkat MDRAID tidak didukung."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Akun pengguna standar dengan akses admin untuk melakukan perubahan sistem secara menyeluruh."
 ],
 "Abort installation": [
  null,
  "Batalkan instalasi"
 ],
 "About": [
  null,
  "Ihwal"
 ],
 "Account": [
  null,
  "Akun"
 ],
 "Actions": [
  null,
  "Aksi"
 ],
 "Add another server...": [
  null,
  "Tambahkan server lain..."
 ],
 "Add mount": [
  null,
  "Tambah kait"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Perangkat lunak tambahan bagi lingkungan yang dipilih"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Add-on yang tidak spesifik untuk lingkungan Anda"
 ],
 "Additional languages": [
  null,
  "Bahasa tambahan"
 ],
 "Additional software for the selected environment": [
  null,
  "Perangkat lunak tambahan untuk lingkungan yang dipilih"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Semua perubahan yang dibuat dalam editor penyimpanan, langsung berlaku."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Semua perangkat yang memakai frasa sandi ini akan dibuka kuncinya"
 ],
 "Anaconda Web UI": [
  null,
  "Antarmuka Web Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Halaman proyek Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Terapkan penetapan titik mount dan instal"
 ],
 "Applying changes...": [
  null,
  "Menerapkan perubahan..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Tetapkan partisi ke titik mount. Berguna untuk tata letak kustom yang telah dikonfigurasi sebelumnya."
 ],
 "Automatic log file upload": [
  null,
  "Pengunggahan otomatis berkas log"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Mengatur tanggal dan waktu menggunakan server waktu secara otomatis"
 ],
 "Automatically set timezone": [
  null,
  "Atur zona waktu secara otomatis"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Ruang kosong yang tersedia: $0. Instalasi membutuhkan: $1."
 ],
 "Back": [
  null,
  "Mundur"
 ],
 "Base environment": [
  null,
  "Lingkungan dasar"
 ],
 "Brief description of the issue": [
  null,
  "Deskripsi singkat tentang masalah"
 ],
 "Bug report details": [
  null,
  "Detail laporan bug"
 ],
 "Bugzilla API key": [
  null,
  "Kunci API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Dengan melanjutkan memakai perangkat lunak ini, Anda paham dan menerima risiko yang terkait dengan perangkat lunak prarilis, yang hendak Anda pakai hanya untuk tujuan pengujian dan pengembangan dan Anda bersedia melaporkan sebarang kutu atau masalah untuk memajukan karya ini."
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Change destination": [
  null,
  "Ubah tujuan"
 ],
 "Change hostname": [
  null,
  "Ubah nama host"
 ],
 "Change partition layout": [
  null,
  "Ubah tata letak partisi"
 ],
 "Change system keyboard layout": [
  null,
  "Mengubah tata letak keyboard sistem"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Perubahan yang dibuat di sini seketika memengaruhi sistem. Tidak ada 'tak jadi'."
 ],
 "Checking installation configuration...": [
  null,
  "Memeriksa konfigurasi instalasi..."
 ],
 "Checking storage configuration": [
  null,
  "Memeriksa konfigurasi penyimpanan"
 ],
 "Clear search": [
  null,
  "Bersihkan pencarian"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Klik 'Berikutnya' lagi untuk melanjutkan meskipun ada peringatan ini."
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Close storage editor": [
  null,
  "Tutup editor penyimpanan"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Penyimpanan Cockpit tidak menyediakan frasa sandi untuk membuka kunci perangkat yang terenkripsi."
 ],
 "Completed": [
  null,
  "Lengkap"
 ],
 "Configuration is incomplete": [
  null,
  "Konfigurasi tidak lengkap"
 ],
 "Configure NTP servers": [
  null,
  "Konfigurasikan server NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Konfigurasikan server NTP kustom"
 ],
 "Configure network": [
  null,
  "Konfigurasi jaringan"
 ],
 "Configure storage": [
  null,
  "Konfigurasikan penyimpanan"
 ],
 "Configure storage again": [
  null,
  "Konfigurasikan penyimpanan lagi"
 ],
 "Confirm passphrase": [
  null,
  "Konfirmasi frasa sandi"
 ],
 "Continue": [
  null,
  "Lanjutkan"
 ],
 "Continue installation": [
  null,
  "Lanjutkan instalasi"
 ],
 "Continue installation?": [
  null,
  "Lanjutkan instalasi?"
 ],
 "Continue with installation": [
  null,
  "Lanjutkan dengan instalasi"
 ],
 "Correct these issues before continuing.": [
  null,
  "Perbaiki masalah ini sebelum melanjutkan."
 ],
 "Create Account": [
  null,
  "Buat Akun"
 ],
 "Create account": [
  null,
  "Buat akun"
 ],
 "Currently installed: $0": [
  null,
  "Saat ini terinstal: $0"
 ],
 "Custom": [
  null,
  "Ubahan"
 ],
 "Date": [
  null,
  "Tanggal"
 ],
 "Date and time": [
  null,
  "Tanggal dan waktu"
 ],
 "Delete partition": [
  null,
  "Hapus partisi"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Penghapusan partisi tertentu dapat mencegah $0 melakukan booting: $1"
 ],
 "Description": [
  null,
  "Deskripsi"
 ],
 "Destination": [
  null,
  "Tujuan"
 ],
 "Destination is encrypted": [
  null,
  "Tujuan dienkripsi"
 ],
 "Detailed description of the issue": [
  null,
  "Deskripsi terperinci tentang masalah"
 ],
 "Detected valid storage layout:": [
  null,
  "Tata letak penyimpanan valid yang terdeteksi:"
 ],
 "Device": [
  null,
  "Peranti"
 ],
 "Duplicate device.": [
  null,
  "Peranti duplikat."
 ],
 "Duplicate mount point.": [
  null,
  "Titik kait duplikat."
 ],
 "Enable root account": [
  null,
  "Fungsikan akun root"
 ],
 "Encrypt my data": [
  null,
  "Enkripsikan data saya"
 ],
 "Encrypted": [
  null,
  "Terenkripsi"
 ],
 "Encryption": [
  null,
  "Enkripsi"
 ],
 "Enter PIN": [
  null,
  "Masukkan PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Masukkan PIN untuk mengakses penginstal"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Masukkan kunci API Bugzilla Anda untuk membuat laporan bug. Anda akan dapat meninjau dan mengedit detail bug pada langkah berikutnya."
 ],
 "Environment": [
  null,
  "Lingkungan"
 ],
 "Erase data and install": [
  null,
  "Hapus data dan pasang"
 ],
 "Error details": [
  null,
  "Rincian kesalahan"
 ],
 "Exit to live desktop": [
  null,
  "Keluar ke live desktop"
 ],
 "Extended partition": [
  null,
  "Partisi diperluas"
 ],
 "Failed to report issue": [
  null,
  "Gagal melaporkan masalah"
 ],
 "Failed to save layouts": [
  null,
  "Gagal menyimpan tata letak"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux memerlukan setidaknya ruang disk $0."
 ],
 "Finalization": [
  null,
  "Finalisasi"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalisasi: Konfigurasi sistem telah lengkap. Finalisasi instalasi mungkin makan waktu beberapa saat."
 ],
 "Find layout": [
  null,
  "Temukan tata letak"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Untuk keamanan yang lebih baik, hindari menggunakan akun root secara langsung. Sebaliknya, gunakan akun lokal di atas untuk mengelola sistem."
 ],
 "Full name": [
  null,
  "Nama lengkap"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Nama lengkap tidak boleh mengandung karakter titik dua"
 ],
 "Helper text": [
  null,
  "Teks bantuan"
 ],
 "Hide API key": [
  null,
  "Sembunyikan kunci API"
 ],
 "Hide PIN": [
  null,
  "Sembunyikan PIN"
 ],
 "Hide confirmed password": [
  null,
  "Sembunyikan kata sandi terkonfirmasi"
 ],
 "Hide passphrase": [
  null,
  "Sembunyikan frasa sandi"
 ],
 "Hide password": [
  null,
  "Sembunyikan kata sandi"
 ],
 "Hostname": [
  null,
  "Nama host"
 ],
 "How would you like to install?": [
  null,
  "Bagaimana Anda ingin memasang?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Saya memahami bahwa semua data yang ada akan dihapus dari disk yang dipilih"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Saya memahami bahwa beberapa data yang ada akan dihapus"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Saya memahami bahwa beberapa partisi akan dimodifikasi"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Bila kosong, nama host akan transien dan diatur oleh informasi jaringan."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Jika tidak ada opsi di atas yang sesuai, gunakan editor penyimpanan untuk membuat partisi kustom sebelum melanjutkan."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Bila Anda mengonfigurasi partisi, yang berikut ini diperlukan:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Jika Anda tidak menyetujui pengunggahan otomatis berkas log, Anda dapat $0 sebagai gantinya. Pelaporan manual memungkinkan Anda meninjau dan melampirkan berkas log secara selektif sendiri."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Bila Anda tidak paham atau menerima risiko tersebut, harap keluar dari program ini."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Jika masalah Anda cocok dengan salah satu kutu di atas, Anda dapat membukanya dan menambahkan informasi Anda di sana alih-alih membuat laporan duplikat."
 ],
 "In progress": [
  null,
  "Dalam progres"
 ],
 "Initializing...": [
  null,
  "Menginisialisasi..."
 ],
 "Install": [
  null,
  "Pasang"
 ],
 "Installation failed": [
  null,
  "Instalasi gagal"
 ],
 "Installation method": [
  null,
  "Metode instalasi"
 ],
 "Installation of the system failed": [
  null,
  "Pemasangan sistem gagal"
 ],
 "Installation of the system failed: $0": [
  null,
  "Instalasi sistem gagal: $0"
 ],
 "Installation type": [
  null,
  "Tipe instalasi"
 ],
 "Installing": [
  null,
  "Memasang"
 ],
 "Insufficient disk space": [
  null,
  "Ruang disk tidak mencukupi"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "PIN tidak valid. Silakan coba lagi."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Konfigurasi RAID yang tidak valid terdeteksi. Jika array RAID Anda dibuat langsung di atas disk, tabel partisi harus dibuat di atas array tersebut. Jika array RAID Anda dibuat di atas partisi, array tersebut harus berisi satu sistem berkas atau format (mis., LVM PV). Setiap partisi yang ada pada array ini akan diabaikan."
 ],
 "Invalid hostname": [
  null,
  "Nama host tidak valid"
 ],
 "Jump to first incomplete step": [
  null,
  "Loncat ke langkah pertama yang belum selesai"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Pertahankan tata letak disk saat ini dan gunakan ruang yang tersedia, untuk melakukan dual-boot dengan OS lain."
 ],
 "Keyboard": [
  null,
  "Papan Ketik"
 ],
 "Keyboard layout during boot": [
  null,
  "Tata letak keyboard selama boot"
 ],
 "Language": [
  null,
  "Bahasa"
 ],
 "Launch storage editor": [
  null,
  "Buka editor penyimpanan"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Pelajari lebih lanjut tentang akses terbatas dalam konfigurasi"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Biarkan kedua kolom frasa sandi kosong untuk menggunakan kata sandi kosong."
 ],
 "Location": [
  null,
  "Lokasi"
 ],
 "Locked devices": [
  null,
  "Perangkat yang terkunci"
 ],
 "Log in": [
  null,
  "Masuk"
 ],
 "Make current": [
  null,
  "Jadikan saat ini"
 ],
 "Manual disk configuration": [
  null,
  "Konfigurasi disk manual"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Konfigurasi disk manual: Pemetaan titik kait"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Boleh memuat huruf, angka, dan strip."
 ],
 "May need more free space": [
  null,
  "Mungkin memerlukan lebih banyak ruang kosong"
 ],
 "Medium": [
  null,
  "Medium"
 ],
 "Minimum of $0 required": [
  null,
  "Minimum $0 diperlukan"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Tidak cocok antara pilihan format ulang perangkat induk dan perangkat anak."
 ],
 "Mount point": [
  null,
  "Titik kait"
 ],
 "Mount point assignment": [
  null,
  "Penugasan titik kait"
 ],
 "Move down": [
  null,
  "Pindah ke bawah"
 ],
 "Move up": [
  null,
  "Pindah ke atas"
 ],
 "Must be at least $0 characters": [
  null,
  "Mesti paling tidak $0 karakter"
 ],
 "My issue is different, continue": [
  null,
  "Masalah saya berbeda, lanjutkan"
 ],
 "NTP Servers": [
  null,
  "Server NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Needs at least $0": [
  null,
  "Membutuhkan setidaknya $0"
 ],
 "Network": [
  null,
  "Jaringan"
 ],
 "Network Configuration": [
  null,
  "Konfigurasi jaringan"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Jaringan tidak tersedia. Konfigurasikan jaringan di menu bilah puncak untuk melaporkan masalah."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Jaringan tidak tersedia. Konfigurasikan jaringan untuk melaporkan masalah."
 ],
 "Network plugin failed": [
  null,
  "Plugin jaringan gagal"
 ],
 "Next": [
  null,
  "Berikutnya"
 ],
 "No devices": [
  null,
  "Tidak ada perangkat"
 ],
 "No disks available": [
  null,
  "Tidak tersedia disk"
 ],
 "No disks selected": [
  null,
  "Tidak ada disk yang dipilih"
 ],
 "No keyboard layouts selected": [
  null,
  "Tidak ada tata letak keyboard yang dipilih"
 ],
 "No layouts selected yet": [
  null,
  "Belum ada tata letak yang dipilih"
 ],
 "No results found": [
  null,
  "Tidak ditemukan hasil"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Tidak ada peta tombol VConsole yang valid yang dapat diperoleh untuk tata letak keyboard yang dipilih. Harap pilih tata letak keyboard yang berbeda."
 ],
 "Not enough available free space": [
  null,
  "Tidak cukup ruang kosong yang tersedia"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Tidak cukup ruang bebas pada disk yang dipilih."
 ],
 "Not enough space on selected disks.": [
  null,
  "Tidak cukup ruang bebas pada disk yang dipilih."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Pemberitahuan: Ini adalah perangkat lunak pra-rilis yang dimaksudkan hanya untuk tujuan pengembangan dan pengujian. JANGAN gunakan perangkat lunak ini untuk pekerjaan penting apa pun atau untuk lingkungan produksi."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Buka formulir entri bug Bugzilla"
 ],
 "Operating system": [
  null,
  "Sistem operasi"
 ],
 "Options": [
  null,
  "Opsi"
 ],
 "Other keyboards": [
  null,
  "Papan ketik lain"
 ],
 "Partitions (advanced)": [
  null,
  "Partisi (tingkat lanjut)"
 ],
 "Passphrase": [
  null,
  "Frasa sandi"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Frasa sandi tidak cocok dengan perangkat yang terkunci"
 ],
 "Passphrases must match": [
  null,
  "Frasa sandi tidak cocok"
 ],
 "Pending": [
  null,
  "Tertunda"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Harap lampirkan berkas log $0 ke masalah."
 ],
 "Please enter a PIN": [
  null,
  "Harap masukkan PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Silakan pilih setidaknya satu disk untuk melanjutkan."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Ditemukan kutu duplikat potensial"
 ],
 "Powered by Anaconda": [
  null,
  "Ditenagai oleh Anaconda"
 ],
 "Pre-release": [
  null,
  "Prarilis"
 ],
 "Prefer to report manually? $0": [
  null,
  "Lebih suka melaporkan secara manual? $0"
 ],
 "Proceed with installation": [
  null,
  "Lanjutkan dengan instalasi"
 ],
 "Quit": [
  null,
  "Keluar"
 ],
 "Quit installer?": [
  null,
  "Keluar pemasang?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Pembacaan informasi tentang OS gagal."
 ],
 "Reading information about the computer failed.": [
  null,
  "Gagal membaca informasi tentang komputer."
 ],
 "Reading installer configuration failed.": [
  null,
  "Gagal membaca konfigurasi pemasang."
 ],
 "Reading installer version information failed.": [
  null,
  "Gagal membaca informasi versi pemasang."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Nama host nyata hanya boleh memuat karakter, digit, strip (bukan sebagai karakter pertama atau terakhir), dan titik"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Panjang nama host nyata mesti 64 karakter atau kurang"
 ],
 "Reboot": [
  null,
  "Boot ulang"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Mulai ulang Windows untuk mengubah ukuran partisi yang dienkripsi BitLocker. Sediakan setidaknya $0 ruang kosong untuk instalasi."
 ],
 "Reboot system?": [
  null,
  "Boot ulang sistem?"
 ],
 "Reclaim additional space": [
  null,
  "Mengambil kembali ruang tambahan"
 ],
 "Reclaim space": [
  null,
  "Mengambil kembali ruang"
 ],
 "Reclaim space (required)": [
  null,
  "Mengambil kembali ruang (diperlukan)"
 ],
 "Recommended": [
  null,
  "Direkomendasikan"
 ],
 "Recommended partitions:": [
  null,
  "Partisi yang disarankan:"
 ],
 "Reformat": [
  null,
  "Format ulang"
 ],
 "Reinstall Fedora": [
  null,
  "Instal ulang Fedora"
 ],
 "Remove": [
  null,
  "Hapus"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Hapus semua partisi pada perangkat yang dipilih, termasuk sistem operasi yang ada."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Hapus atau ubah ukuran sistem file yang ada untuk mengosongkan ruang untuk penginstalan."
 ],
 "Remove server": [
  null,
  "Hapus server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Menghapus sistem berkas akan menghapus semua data yang ada di dalamnya secara permanen. Mengubah ukuran partisi dapat mengosongkan ruang yang tidak terpakai, namun tidak bebas risiko. Pastikan Anda memiliki cadangan dari segala sesuatu yang penting sebelum mengklaim ulang kapasitas."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Ganti instalasi saat ini, tetapi pertahankan file di home."
 ],
 "Report Issue": [
  null,
  "Laporkan Masalah"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Laporkan masalah atau berikan masukan dengan membuka formulir entri bug Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Laporkan masalah"
 ],
 "Reporting issue...": [
  null,
  "Sedang melaporkan masalah..."
 ],
 "Required": [
  null,
  "Diperlukan"
 ],
 "Requirements": [
  null,
  "Persyaratan"
 ],
 "Rescan devices": [
  null,
  "Memindai ulang perangkat"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Pemindaian ulang disk gagal."
 ],
 "Resize": [
  null,
  "Ubah ukuran"
 ],
 "Resize partition": [
  null,
  "Ubah ukuran partisi"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Mengubah ukuran partisi berikut ini dari $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Batasi akses ke laporan"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Membatasi laporan ke grup $0. $1"
 ],
 "Return to installation": [
  null,
  "Kembali ke instalasi"
 ],
 "Return to storage editor": [
  null,
  "Kembali ke penyunting penyimpanan"
 ],
 "Review and install": [
  null,
  "Tinjau dan pasang"
 ],
 "Root account has been configured": [
  null,
  "Akun root telah dikonfigurasi"
 ],
 "Root account is enabled": [
  null,
  "Akun root diaktifkan"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Akun root telah diaktifkan, tetapi belum ada akun pengguna yang dikonfigurasi."
 ],
 "Root password has been set.": [
  null,
  "Kata sandi root telah diisi."
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Pindai kode QR dengan telepon Anda atau kunjungi:"
 ],
 "Search for a language": [
  null,
  "Mencari bahasa"
 ],
 "Search for additional software": [
  null,
  "Cari perangkat lunak tambahan"
 ],
 "Search for an environment": [
  null,
  "Mencari lingkungan"
 ],
 "Search keyboard layout": [
  null,
  "Cari tata letak papan tik"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Amankan data Anda menggunakan enkripsi berbasis disk. Hanya berlaku untuk partisi baru"
 ],
 "Select": [
  null,
  "Pilih"
 ],
 "Select a device": [
  null,
  "Pilih suatu perangkat"
 ],
 "Select city": [
  null,
  "Pilih kota"
 ],
 "Select destination": [
  null,
  "Pilih tujuan"
 ],
 "Select region": [
  null,
  "Pilih wilayah"
 ],
 "Selected (top = current)": [
  null,
  "Terpilih (atas = saat ini)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Format '$0' dari perangkat yang dipilih tidak bisa diformat ulang."
 ],
 "Send us feedback on your installation": [
  null,
  "Kirimi kami umpan balik tentang instalasi Anda"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Server tidak dapat diakses."
 ],
 "Set custom hostname": [
  null,
  "Atur nama host ubahan"
 ],
 "Share disk with other operating systems": [
  null,
  "Bagikan disk dengan sistem operasi lain"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Bagikan disk dengan sistem operasi lain: $0"
 ],
 "Show AM/PM": [
  null,
  "Tampilkan AM/PM"
 ],
 "Show API key": [
  null,
  "Tampilkan kunci API"
 ],
 "Show PIN": [
  null,
  "Tampilkan PIN"
 ],
 "Show confirmed password": [
  null,
  "Tampilkan kata sandi terkonfirmasi"
 ],
 "Show passphrase": [
  null,
  "Tampilkan frasa sandi"
 ],
 "Show password": [
  null,
  "Tampilkan kata sandi"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "Software installation": [
  null,
  "Instalasi perangkat lunak"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalasi perangkat lunak: Konfigurasi penyimpanan selesai. Perangkat lunak saat ini sedang dipasang ke perangkat Anda."
 ],
 "Software selection": [
  null,
  "Pemilihan perangkat lunak"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Beberapa langkah instalasi masih perlu diselesaikan sebelum Anda dapat melanjutkan."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Beberapa partisi yang diperlukan kurang: $0"
 ],
 "Space": [
  null,
  "Ruang"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Storage configuration": [
  null,
  "Konfigurasi penyimpanan"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Konfigurasi penyimpanan: Penyimpanan saat ini sedang dikonfigurasi."
 ],
 "Storage editor": [
  null,
  "Editor penyimpanan"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Penyimpanan didasarkan pada konfigurasi dari 'Ubah penyimpanan'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Tata letak penyimpanan ditentukan oleh berkas kickstart. Tata letak partisi yang direncanakan dapat ditinjau di langkah ringkasan."
 ],
 "Storage plugin failed": [
  null,
  "Plugin penyimpanan gagal"
 ],
 "Storage requirements not met": [
  null,
  "Kebutuhan penyimpanan tidak dipenuhi"
 ],
 "Strong": [
  null,
  "Kuat"
 ],
 "Successfully installed": [
  null,
  "Sukses dipasang"
 ],
 "Successfully unlocked $0.": [
  null,
  "Berhasil membuka $0."
 ],
 "Suggested keyboards": [
  null,
  "Papan tik yang disarankan"
 ],
 "Suggested languages": [
  null,
  "Bahasa yang disarankan"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System configuration": [
  null,
  "Konfigurasi sistem"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Konfigurasi sistem: Instalasi perangkat lunak selesai. Sistem sedang dikonfigurasi."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Instalasi Anaconda telah berhenti secara tidak terduga."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Kutu terbuka berikut mungkin terkait dengan masalah Anda. Harap tinjau sebelum membuat laporan baru."
 ],
 "The following user will be created:": [
  null,
  "Pengguna berikut akan dibuat:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Pemasangan membutuhkan ruang disk sebesar $0; namun, kapasitas disk yang dipilih hanya sebesar $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Pemasang tidak dapat melanjutkan karena suatu kesalahan kritis."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Pemasang tidak dapat melanjutkan karena suatu kesalahan kritis: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Frasa sandi yang Anda berikan mengandung karakter non ASCII. Anda mungkin tidak bisa beralih antar tata letak papan tik ketika mengetikkannya."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Tata letak keyboard default yang dipilih tidak mendukung karakter ASCII. Silakan pilih tata letak yang mendukung ASCII sebagai default."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Editor penyimpanan memungkinkan Anda mengubah ukuran, menghapus, dan membuat partisi. Editor ini dapat mengatur LVM dan banyak lagi. Editor ini dimaksudkan untuk digunakan sebagai utilitas tingkat lanjut dan tidak ditujukan untuk digunakan dalam instalasi biasa."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "File log ini mungkin berisi informasi sensitif seperti alamat IP, nama pengguna, atau detail sistem lainnya."
 ],
 "This hostname can't be submitted": [
  null,
  "Nama host ini tidak bisa dikirim"
 ],
 "This is unstable, pre-release software": [
  null,
  "Ini perangkat lunak pra-rilis yang tidak stabil"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Tata letak ini akan digunakan untuk membuka kunci sistem Anda saat boot"
 ],
 "This may take a moment": [
  null,
  "Ini mungkin perlu waktu"
 ],
 "This will take a few moments": [
  null,
  "Ini akan makan waktu beberapa saat"
 ],
 "Time": [
  null,
  "Waktu"
 ],
 "Timezone": [
  null,
  "Zona Waktu"
 ],
 "Title": [
  null,
  "Judul"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Untuk mulai memakai $0, boot ulang sistem Anda."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Untuk melanjutkan, pilih perangkat untuk dipasangi."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Untuk menggunakan opsi ini, ubah ukuran atau hapus partisi yang ada untuk mengosongkan setidaknya $0."
 ],
 "Type": [
  null,
  "Tipe"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Tidak dapat menjadwalkan penghapusan $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Tidak dapat menjadwalkan pengubahan ukuran $0"
 ],
 "Undo last action": [
  null,
  "Batalkan tindakan terakhir"
 ],
 "Unlock": [
  null,
  "Buka kunci"
 ],
 "Unlock encrypted devices": [
  null,
  "Buka kunci perangkat terenkripsi"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Buka kunci partisi terenkripsi untuk mempertahankan data yang ada dan menampilkan lebih banyak metode instalasi."
 ],
 "Use configured storage": [
  null,
  "Gunakan penyimpanan yang dikonfigurasi"
 ],
 "Use entire disk": [
  null,
  "Gunakan seluruh disk"
 ],
 "Use free space": [
  null,
  "Gunakan ruang kosong"
 ],
 "Use local account": [
  null,
  "Gunakan akun lokal"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Gunakan perangkat RAID untuk partisi otomatis"
 ],
 "User creation": [
  null,
  "Pembuatan pengguna"
 ],
 "User name": [
  null,
  "Nama pengguna"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Nama pengguna hanya boleh mengandung: huruf dari a-z, angka 0-9, strip $0, titik $1, garis bawah $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Nama pengguna tidak boleh berupa kata yang dicadangkan"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Nama pengguna harus kurang dari 33 karakter"
 ],
 "Validating...": [
  null,
  "Sedang memvalidasi..."
 ],
 "Weak": [
  null,
  "Lemah"
 ],
 "Welcome": [
  null,
  "Selamat Datang"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Selamat datang di Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Selamat datang! Mari memasang $0 sekarang."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Saat Anda mengirimkan laporan bug ini, berkas log berikut akan diunggah secara otomatis: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Partisi Windows dengan enkripsi BitLocker tidak dapat diubah ukurannya"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Anda dapat membebaskan cukup ruang di sini dan membiarkan pemasang menangani sisanya atau secara manual menyiapkan partisi."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Anda dapat membuat kunci API untuk akun Bugzilla Anda $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Anda harus mengaktifkan akun root atau membuat akun pengguna lokal untuk melanjutkan."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Anda harus terhubung ke jaringan untuk mengaktifkan pengaturan tanggal dan waktu secara otomatis."
 ],
 "Your progress will not be saved.": [
  null,
  "Kemajuan Anda tidak akan disimpan."
 ],
 "completed step": [
  null,
  "langkah yang telah lengkap"
 ],
 "current step": [
  null,
  "langkah kini"
 ],
 "delete": [
  null,
  "hapus"
 ],
 "edit": [
  null,
  "sunting"
 ],
 "encrypt": [
  null,
  "enkripsi"
 ],
 "encrypted": [
  null,
  "terenkripsi"
 ],
 "extended partition": [
  null,
  "partisi yang diperluas"
 ],
 "format as $0": [
  null,
  "format sebagai $0"
 ],
 "here": [
  null,
  "di sini"
 ],
 "incomplete": [
  null,
  "tidak lengkap"
 ],
 "mount": [
  null,
  "kait"
 ],
 "pending step": [
  null,
  "langkah tertunda"
 ],
 "report the issue manually": [
  null,
  "laporkan masalah secara manual"
 ],
 "resized from $0": [
  null,
  "diubah ukurannya dari $0"
 ],
 "shrink": [
  null,
  "perkecil"
 ],
 "shrink to $0": [
  null,
  "mengecil menjadi $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "undo"
 ]
});
