cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Journal": [
  null,
  "Журнал"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "Hardware information": [
  null,
  "Сведения об оборудовании"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "active": [
  null,
  "активно"
 ],
 "Default": [
  null,
  "По умолчанию"
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "System": [
  null,
  "Система"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "$0 key changed": [
  null,
  "Изменён $0 ключ"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "Permission denied": [
  null,
  "Отказано в доступе"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Create $0": [
  null,
  "Создать $0"
 ],
 "Ok": [
  null,
  "ОК"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "You now have administrative access.": [
  null,
  "Получены права администратора."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Нет доступных методов получения административного доступа (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Пройдите проверку подлинности для получения прав администратора"
 ],
 "Switch to administrative access": [
  null,
  "Переключиться на доступ с правами администратора"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Problem becoming administrator": [
  null,
  "При получении прав администратора возникли проблемы"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Ограничить доступ"
 ],
 "Switch to limited access": [
  null,
  "Переключится на ограниченный доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "В ограниченном режиме доступа ограничиваются полномочия администратора. В некоторых разделах веб-консоли будет урезаны функциональные возможности."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Браузер запоминает уровень доступа от сеанса к сеансу."
 ],
 "Limited access": [
  null,
  "Ограниченный доступ"
 ],
 "Turn on administrative access": [
  null,
  "Включить доступ с правами администратора"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "less than a minute ago": [
  null,
  "менее минуты назад"
 ],
 "in less than a minute": [
  null,
  "менее минуты"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного ПО"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Unknown host: $0": [
  null,
  "Неизвестный хост: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль."
 ],
 "SSH key login": [
  null,
  "Вход с помощью SSH-ключа"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit передал код ошибки $0"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Ошибка при инициализации"
 ],
 "Failed": [
  null,
  "Ошибка"
 ],
 "Home": [
  null,
  "Домашний каталог"
 ],
 "Downloads": [
  null,
  "Загрузки"
 ],
 "Not a directory": [
  null,
  "Не является каталогом"
 ],
 "All files": [
  null,
  "Все файлы"
 ],
 "Recent": [
  null,
  "Недавние"
 ],
 "No recent directories": [
  null,
  "Нет недавних каталогов"
 ],
 "No recent files": [
  null,
  "Нет недавних файлов"
 ],
 "Type to filter": [
  null,
  "Введите условия фильтра"
 ],
 "File chooser actions": [
  null,
  "Действия выбора файлов"
 ],
 "Open in file browser": [
  null,
  "Открыть в файловом менеджере"
 ],
 "Hide hidden files": [
  null,
  "Скрыть скрытые файлы"
 ],
 "Show hidden files": [
  null,
  "Показывать скрытые файлы"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Clear filters": [
  null,
  "Очистить фильтры"
 ],
 "Directory is empty": [
  null,
  "Каталог пуст"
 ],
 "Directory has no sub-directories": [
  null,
  "Каталог не содержит подкаталогов"
 ],
 "This directory contains only hidden files": [
  null,
  "Этот каталог содержит только скрытые файлы"
 ],
 "No matching results": [
  null,
  "Нет подходящих результатов"
 ],
 "Folder": [
  null,
  "Папка"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Select an option": [
  null,
  "Выбор опции"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "$0 is not a directory": [
  null,
  "$0 не является каталогом"
 ],
 "$0 does not exist": [
  null,
  "$0 не существует"
 ],
 "Font size": [
  null,
  "Размер шрифта"
 ],
 "Decrease by one": [
  null,
  "Уменьшить на один"
 ],
 "Increase by one": [
  null,
  "Увеличить на один"
 ],
 "Appearance": [
  null,
  "Стиль отображения"
 ],
 "Black": [
  null,
  "Чёрный"
 ],
 "White": [
  null,
  "Белый"
 ],
 "Reset": [
  null,
  "Сбросить"
 ],
 "Unable to open directory": [
  null,
  "Не удается открыть каталог"
 ],
 "Running process prevents directory change": [
  null,
  "Запущенный процесс препятствует изменению каталога"
 ],
 "Change directory": [
  null,
  "Сменить каталог"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Смена каталога приведет к принудительной остановке текущего процесса. Процесс также можно остановить вручную в терминале, прежде чем продолжить."
 ],
 "Terminal not available": [
  null,
  "Терминал недоступен"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Этот браузер не поддерживает WebGL2."
 ],
 "unknown": [
  null,
  "неизвестно"
 ],
 "Shutdown": [
  null,
  "Выключить"
 ],
 "running $0": [
  null,
  "выполняется $0"
 ],
 "Current boot": [
  null,
  "Текущая сессия"
 ],
 "Previous boot": [
  null,
  "Предыдущая загрузка"
 ],
 "Last 24 hours": [
  null,
  "Последние 24 часа"
 ],
 "Last 7 days": [
  null,
  "Последние 7 дней"
 ],
 "Only emergency": [
  null,
  "Только экстренные оповещения"
 ],
 "Alert and above": [
  null,
  "Оповещения и выше"
 ],
 "Critical and above": [
  null,
  "Критические оповещения и выше"
 ],
 "Error and above": [
  null,
  "Сообщения об ошибках и выше"
 ],
 "Warning and above": [
  null,
  "Предупреждающие сообщения и выше"
 ],
 "Notice and above": [
  null,
  "Уведомления и выше"
 ],
 "Info and above": [
  null,
  "Информационные сообщения и выше"
 ],
 "Debug and above": [
  null,
  "Отладочные сообщения и выше"
 ],
 "Toggle filters": [
  null,
  "Переключение фильтров"
 ],
 "Time": [
  null,
  "Время"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Identifier": [
  null,
  "Идентификатор"
 ],
 "Filters": [
  null,
  "Фильтры"
 ],
 "Pause": [
  null,
  "Приостановить"
 ],
 "Resume": [
  null,
  "Возобновить"
 ],
 "All": [
  null,
  "Все"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Дата должна быть представлена в формате YYYY-MM-DD hh:mm:ss. Также можно использовать строки «yesterday» (вчера), «today» (сегодня), «tomorrow» (завтра). Строка «now» (сейчас) означает текущее время. Наконец, можно указывать относительное время с префиксом «-» или «+»"
 ],
 "Since": [
  null,
  "C"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Показывать записи, начиная с указанной даты и более поздних."
 ],
 "Until": [
  null,
  "До"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Показывать записи, начиная с указанной даты и более ранних."
 ],
 "Boot": [
  null,
  "Загрузка"
 ],
 "Show messages from a specific boot.": [
  null,
  "Показать сообщения для указанной загрузки."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Здесь можно добавить строку для совпадения с параметром «_BOOT_ID=». При отсутствии строки выводятся записи журнала для текущей загрузки. Если вместо идентификатора загрузки указано положительное число, будут выведены загрузки с началаведения журнала, если же число меньше или равно нулю, вывод записей начинается с конца журнала. Например, 1 выводит первую загрузку в журнале в хронологическом порядке, 2 — вторую и так далее; при этом -0 означает последнюю загрузку, -1 предпоследнюю загрузку и так далее."
 ],
 "Unit": [
  null,
  "Устройство"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Показать сообщения для указанного юнита systemd."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Здесь можно добавить строку для совпадения с параметрами «_SYSTEMD_UNIT=», «COREDUMP_UNIT=» и «UNIT=» для поиска всех возможных сообщений по указанному юниту. Значение параметра может быть представлено в виде нескольких юнитов, разделённых запятыми."
 ],
 "Free-form search": [
  null,
  "Произвольный поиск"
 ],
 "Show messages containing given string.": [
  null,
  "Показать сообщения, содержащие данную строку."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Любая текстовая строка в сообщениях журнала может быть отфильтрована. Строка также может быть представлена в виде регулярного выражения. Также поддерживает фильтрацию по полям журнала сообщений. Это значения, разделенные пробелами, в форме ПОЛЕ=ЗНАЧЕНИЕ, где значение может быть списком возможных значений, разделенных запятыми."
 ],
 "journalctl manpage": [
  null,
  "Man-страница journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Успешно скопировано в буфер обмена"
 ],
 "Create timer": [
  null,
  "Создать таймер"
 ],
 "Edit timer": [
  null,
  "Изменить таймер"
 ],
 "Timer creation failed": [
  null,
  "Не удалось создать таймер"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Не удалось получить условия запуска таймера"
 ],
 "Failed to get the timer command": [
  null,
  "Не удалось получить команду таймера"
 ],
 "This field cannot be empty": [
  null,
  "Это поле не может быть пустым"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Допускаются только буквы, цифры и символы «:», «_», «.», «@» и «-»"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Shell command": [
  null,
  "Команда оболочки"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Эта команда будет выполнена через /bin/sh."
 ],
 "Trigger": [
  null,
  "Триггер"
 ],
 "At specific time": [
  null,
  "В определённое время"
 ],
 "After system boot": [
  null,
  "После загрузки системы"
 ],
 "Seconds": [
  null,
  "сек"
 ],
 "Minutes": [
  null,
  "мин"
 ],
 "Hours": [
  null,
  "ч"
 ],
 "Weeks": [
  null,
  "нед"
 ],
 "Delay must be a number": [
  null,
  "Величина задержки должна быть задана в виде числа"
 ],
 "Repeat": [
  null,
  "Повторять"
 ],
 "Don't repeat": [
  null,
  "Без повтора"
 ],
 "Minutely": [
  null,
  "Ежеминутно"
 ],
 "Hourly": [
  null,
  "Ежечасно"
 ],
 "Daily": [
  null,
  "Ежедневно"
 ],
 "Weekly": [
  null,
  "Еженедельно"
 ],
 "Monthly": [
  null,
  "Ежемесячно"
 ],
 "Yearly": [
  null,
  "Ежегодно"
 ],
 "Run at": [
  null,
  "Запускать в"
 ],
 "At second": [
  null,
  "В секунду"
 ],
 "At minute": [
  null,
  "В минуту"
 ],
 "Run on": [
  null,
  "Запускать по"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Количество минут должно лежать в интервале от 0 до 59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Количество секунд должно быть в интервале от 0 до 59"
 ],
 "Repeat weekly": [
  null,
  "Повторять еженедельно"
 ],
 "Mondays": [
  null,
  "По понедельникам"
 ],
 "Tuesdays": [
  null,
  "По вторникам"
 ],
 "Wednesdays": [
  null,
  "По средам"
 ],
 "Thursdays": [
  null,
  "По четвергам"
 ],
 "Fridays": [
  null,
  "По пятницам"
 ],
 "Saturdays": [
  null,
  "По субботам"
 ],
 "Sundays": [
  null,
  "По воскресеньям"
 ],
 "Repeat monthly": [
  null,
  "Повторять ежемесячно"
 ],
 "1st": [
  null,
  "1-го числа"
 ],
 "2nd": [
  null,
  "2-го числа"
 ],
 "3rd": [
  null,
  "3-го числа"
 ],
 "4th": [
  null,
  "4-го числа"
 ],
 "5th": [
  null,
  "5-го числа"
 ],
 "6th": [
  null,
  "6-го числа"
 ],
 "7th": [
  null,
  "7-го числа"
 ],
 "8th": [
  null,
  "8-го числа"
 ],
 "9th": [
  null,
  "9-го числа"
 ],
 "10th": [
  null,
  "10-го числа"
 ],
 "11th": [
  null,
  "11-го числа"
 ],
 "12th": [
  null,
  "12-го числа"
 ],
 "13th": [
  null,
  "13-го числа"
 ],
 "14th": [
  null,
  "14-го числа"
 ],
 "15th": [
  null,
  "15-го числа"
 ],
 "16th": [
  null,
  "16-го числа"
 ],
 "17th": [
  null,
  "17-го числа"
 ],
 "18th": [
  null,
  "18-го числа"
 ],
 "19th": [
  null,
  "19-го числа"
 ],
 "20th": [
  null,
  "20-го числа"
 ],
 "21th": [
  null,
  "21-го числа"
 ],
 "22th": [
  null,
  "22-го числа"
 ],
 "23th": [
  null,
  "23-го числа"
 ],
 "24th": [
  null,
  "24-го числа"
 ],
 "25th": [
  null,
  "25-го числа"
 ],
 "26th": [
  null,
  "26-го числа"
 ],
 "27th": [
  null,
  "27-го числа"
 ],
 "28th": [
  null,
  "28-го числа"
 ],
 "29th": [
  null,
  "29-го числа"
 ],
 "30th": [
  null,
  "30-го числа"
 ],
 "31st": [
  null,
  "31-го числа"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Unclean shutdown": [
  null,
  "Некорректное завершение работы"
 ],
 "View logs": [
  null,
  "Смотреть журналы"
 ],
 "Dismiss": [
  null,
  "Закрыть"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Запланировано отключение в $0"
 ],
 "Cancel poweroff": [
  null,
  "Отменить выключение"
 ],
 "Scheduled reboot at $0": [
  null,
  "Запланирована перезагрузка в $0"
 ],
 "Cancel reboot": [
  null,
  "Отменить перезагрузку"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "Set hostname": [
  null,
  "Установить название узла"
 ],
 "Configuration": [
  null,
  "Настройка"
 ],
 "Hostname": [
  null,
  "Имя узла"
 ],
 "System time": [
  null,
  "Системное время"
 ],
 "Domain": [
  null,
  "Домен"
 ],
 "Performance profile": [
  null,
  "Профиль производительности"
 ],
 "Secure shell keys": [
  null,
  "Ключи Secure Shell"
 ],
 "Show fingerprints": [
  null,
  "Показать отпечатки"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "не удалось отобразить список SSH-ключей узла: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Не удалось загрузить SSH-ключи"
 ],
 "Error message": [
  null,
  "Сообщение об ошибке"
 ],
 "Loading keys...": [
  null,
  "Загрузка ключей…"
 ],
 "No host keys found.": [
  null,
  "Ключи узла не найдены."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Отпечатки SSH-ключей компьютера"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Реальное имя узла должно содержать не более 64 символов"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Реальное имя узла может содержать только строчные буквы, цифры, тире и точки (с заполненными поддоменами)"
 ],
 "Change host name": [
  null,
  "Изменить имя узла"
 ],
 "Pretty host name": [
  null,
  "Автоматическое имя узла"
 ],
 "Real host name": [
  null,
  "Реальное имя узла"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Пользователю $0 запрещено изменять правила шифрования"
 ],
 "Cryptographic policy": [
  null,
  "Правило шифрования"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Рекомендуется, безопасные настройки для существующих сейчас моделей угроз."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT с разрешённой проверкой подписи SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Увеличение возможностей взаимодействия за счёт увеличения количества направлений атак."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY с возможностью взаимодействия с Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "При загрузке в режиме FIPS можно использовать только утверждённые и разрешённые алгоритмы."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS с дополнительными ограничениями по общим критериям."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Обеспечивает защиту от атак, предполагаемых в ближайшей перспективе, за счёт уменьшения возможностей взаимодействия."
 ],
 "Custom cryptographic policy": [
  null,
  "Дополнительное правило шифрования"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "«Правила шифрования» (Crypto Policies) — это системный компонент для настройки основных криптографических подсистем, включающих протоколы TLS, IPSec, SSH, DNSSec и Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Изменить правила шифрования"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Применение новой политики… Это может занять несколько минут."
 ],
 "Reapply and reboot": [
  null,
  "Повторно применить и перезагрузить"
 ],
 "Apply and reboot": [
  null,
  "Применить и перезагрузить"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS активирован неправильно"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Правило шифрования несовместимо"
 ],
 "Review cryptographic policy": [
  null,
  "Пересмотреть правила шифрования"
 ],
 "System information": [
  null,
  "Сведения о системе"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Asset tag": [
  null,
  "Тег актива"
 ],
 "Machine ID": [
  null,
  "Идентификатор системы"
 ],
 "Up since": [
  null,
  "Время начала работы"
 ],
 "View hardware details": [
  null,
  "Просмотреть сведения об оборудовании"
 ],
 "Last successful login:": [
  null,
  "Последний удачный вход:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 неудачная попытка входа в систему",
  "$0 неудачные попытки входа в систему",
  "$0 неудачных попыток входа в систему"
 ],
 "View login history": [
  null,
  "Смотреть истории входов"
 ],
 "recommended": [
  null,
  "рекомендуется"
 ],
 "inconsistent": [
  null,
  "несогласованный"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Присоединение к этому домену требует установки realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Не удается присоединиться к домену, потому что на этой системе нет realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Присоединение к этому домену не поддерживается"
 ],
 "Login format": [
  null,
  "Формат учётной записи"
 ],
 "Server software": [
  null,
  "Серверное программное обеспечение"
 ],
 "Client software": [
  null,
  "Клиентское программное обеспечение"
 ],
 "Leave domain": [
  null,
  "Выйти из домена"
 ],
 "Leave $0": [
  null,
  "Выйти из $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "После выхода из домена только пользователи с локальными учётными данными смогут выполнить вход в эту систему. Это также может повлиять и на другие службы, поскольку параметры разрешения DNS и список доверенных центров сертификации могут измениться."
 ],
 "Validating address": [
  null,
  "Проверка адреса"
 ],
 "Contacted domain": [
  null,
  "Связь с доменом установлена"
 ],
 "Domain could not be contacted": [
  null,
  "Не удалось установить связь с доменом"
 ],
 "Domain is not supported": [
  null,
  "Домен не поддерживается"
 ],
 "Domain address": [
  null,
  "Адрес домена"
 ],
 "Domain administrator name": [
  null,
  "Имя администратора домена"
 ],
 "Domain administrator password": [
  null,
  "Пароль администратора домена"
 ],
 "Joining": [
  null,
  "Присоединение"
 ],
 "Join": [
  null,
  "Присоединиться"
 ],
 "This may take a while": [
  null,
  "Это может занять некоторое время"
 ],
 "Not permitted to configure realms": [
  null,
  "Запрещено настраивать области"
 ],
 "Join domain": [
  null,
  "Присоединиться к домену"
 ],
 "Install realmd support": [
  null,
  "Установить поддержку realmd"
 ],
 "$0 disk is failing": [
  null,
  "Сбой $0 диска",
  "Сбой $0 дисков",
  "Сбой $0 дисков"
 ],
 "Connected to Insights": [
  null,
  "Подключено к Insights"
 ],
 "Not connected to Insights": [
  null,
  "Нет подключения к Insights"
 ],
 "Health": [
  null,
  "Здоровье"
 ],
 "of $0 CPU": [
  null,
  "из $0 процессора",
  "из $0 процессоров",
  "из $0 процессоров"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "Memory": [
  null,
  "Память"
 ],
 "View metrics and history": [
  null,
  "Смотреть метрики и историю"
 ],
 "Tuned is not available": [
  null,
  "Демон tuned недоступен"
 ],
 "Tuned is not running": [
  null,
  "Демон tuned не запущен"
 ],
 "Tuned is off": [
  null,
  "Демон tuned отключен"
 ],
 "This system is using the recommended profile": [
  null,
  "Эта система использует рекомендуемый профиль"
 ],
 "This system is using a custom profile": [
  null,
  "Эта система использует настраиваемый профиль"
 ],
 "none": [
  null,
  "нет"
 ],
 "Communication with tuned has failed": [
  null,
  "Сбой связи с демоном tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Не удалось включить демон tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Не удалось отключить демон tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Не удалось отключить профиль демона tuned"
 ],
 "Failed to switch profile": [
  null,
  "Не удалось переключить профиль"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Disable tuned": [
  null,
  "Отключить демон tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Сбой при запуске демона tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned — это служба, предназначенная для контроля системы и оптимизации производительности при определённых нагрузках. В основе Tuned лежат профили, позволяющие настроить систему для различных случаев использования."
 ],
 "Change performance profile": [
  null,
  "Изменить профиль производительности"
 ],
 "Change profile": [
  null,
  "Изменить профиль"
 ],
 "Edit /etc/motd": [
  null,
  "Изменение /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Не удалось сохранить изменения в /etc/motd"
 ],
 "Save changes": [
  null,
  "Сохранить изменения"
 ],
 "Edit motd": [
  null,
  "Изменение motd"
 ],
 "Stub": [
  null,
  "Заглушка"
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Bad setting": [
  null,
  "Плохой параметр"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Merged": [
  null,
  "Объединённый"
 ],
 "Running": [
  null,
  "Работает"
 ],
 "Reloading": [
  null,
  "Перезагрузка"
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Failed to start": [
  null,
  "Сбой запуска"
 ],
 "Maintenance": [
  null,
  "Обслуживание"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Linked": [
  null,
  "Linked"
 ],
 "Alias": [
  null,
  "Псевдоним"
 ],
 "Masked": [
  null,
  "Скрыто"
 ],
 "Static": [
  null,
  "Статически"
 ],
 "Invalid": [
  null,
  "Недопустимый"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Generated": [
  null,
  "Сгенерирован"
 ],
 "Transient": [
  null,
  "Transient"
 ],
 "Bad": [
  null,
  "Плохо"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Сбой подписки на сигналы systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Не удалось подключиться к dbus: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Не удалось вывести список юнитов: $0"
 ],
 "$0 service has failed": [
  null,
  "Сбой $0 службы",
  "Сбой $0 служб",
  "Сбой $0 служб"
 ],
 "Loading of units failed": [
  null,
  "Не удалось загрузить юниты"
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "Listing units": [
  null,
  "Вывод списка юнитов"
 ],
 "Filter by name or description": [
  null,
  "Фильтровать по имени или описанию"
 ],
 "Active state": [
  null,
  "Активное состояние"
 ],
 "File state": [
  null,
  "Состояние файла"
 ],
 "$0 filters applied": [
  null,
  "Фильтров применено: $0"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Пользователю $0 не разрешено изменять параметры, влияющие на безопасность ЦП"
 ],
 "Mitigations": [
  null,
  "Меры по защите"
 ],
 "Version": [
  null,
  "Версия"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Версия BIOS"
 ],
 "BIOS date": [
  null,
  "Дата BIOS"
 ],
 "CPU security": [
  null,
  "Безопасность процессора"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Отключить одновременную многопотоковость"
 ],
 "Read more...": [
  null,
  "Подробнее…"
 ],
 "Save and reboot": [
  null,
  "Сохранить и перезагрузить"
 ],
 "CPU security toggles": [
  null,
  "Переключатели безопасности ЦП"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Программные обходные решения помогают предотвратить проблемы безопасности ЦП. Побочным эффектом этих мер является снижение производительности. Вы изменяете эти параметры на свой страх и риск."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Класс"
 ],
 "Vendor": [
  null,
  "Производитель"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Технология памяти"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Rank": [
  null,
  "Ранг"
 ],
 "Speed": [
  null,
  "Скорость"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Для информации о памяти необходимы права администратора."
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "Failed to fetch logs": [
  null,
  "Не удалось получить журналы"
 ],
 "Clear all filters": [
  null,
  "Сбросить все фильтры"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Не удается найти журналы на основе текущего сочетания фильтров."
 ],
 "No logs found": [
  null,
  "Журналов не найдено"
 ],
 "Load earlier entries": [
  null,
  "Загрузить более ранние записи"
 ],
 "You may try to load older entries.": [
  null,
  "Вы можете попробовать загрузить более старые записи."
 ],
 "Allow running (unmask)": [
  null,
  "Разрешить выполнение (снять маску)"
 ],
 "Reload": [
  null,
  "Перезагрузить"
 ],
 "Restart": [
  null,
  "Перезапустить"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Clear 'Failed to start'": [
  null,
  "Очистить «Сбой запуска»"
 ],
 "Mask service": [
  null,
  "Скрыть службу"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Маскирование службы делает невозможным выполнение всех связанных с ней служб. Эффект может оказаться серьёзнее, чем кажется. Подтвердите маскирование данной службы."
 ],
 "Disallow running (mask)": [
  null,
  "Запретить выполнение (добавить маску)"
 ],
 "Unpin unit": [
  null,
  "Открепить юнит"
 ],
 "Pin unit": [
  null,
  "Закрепить юнит"
 ],
 "Additional actions": [
  null,
  "Дополнительные действия"
 ],
 "Note": [
  null,
  "Примечание"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Эта служба не предназначена для явного включения."
 ],
 "Forbidden from running": [
  null,
  "Выполнение запрещено"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Active since ": [
  null,
  "Активно с "
 ],
 "Required by ": [
  null,
  "Требуется для "
 ],
 "Read-only": [
  null,
  "Только чтение"
 ],
 "Requires administration access to edit": [
  null,
  "Для изменения необходимы права администратора"
 ],
 "Automatically starts": [
  null,
  "Запускается автоматически"
 ],
 "Updating status...": [
  null,
  "Обновление состояния…"
 ],
 "Stop and disable": [
  null,
  "Остановить и отключить"
 ],
 "Start and enable": [
  null,
  "Включить и запустить"
 ],
 "Failed to load unit": [
  null,
  "Не удалось загрузить модуль"
 ],
 "View all services": [
  null,
  "Смотреть все службы"
 ],
 "Triggers": [
  null,
  "Triggers="
 ],
 "Triggered by": [
  null,
  "TriggeredBy="
 ],
 "Requires": [
  null,
  "Requires="
 ],
 "Requisite": [
  null,
  "Requisite="
 ],
 "Wants": [
  null,
  "Wants="
 ],
 "Binds to": [
  null,
  "BindsTo="
 ],
 "Part of": [
  null,
  "Часть"
 ],
 "Required by": [
  null,
  "RequiredBy="
 ],
 "Requisite of": [
  null,
  "RequisiteOf="
 ],
 "Wanted by": [
  null,
  "WantedBy="
 ],
 "Bound by": [
  null,
  "BoundBy="
 ],
 "Consists of": [
  null,
  "ConsistsOf="
 ],
 "Conflicts": [
  null,
  "Conflicts="
 ],
 "Conflicted by": [
  null,
  "ConflictedBy="
 ],
 "Before": [
  null,
  "Before="
 ],
 "After": [
  null,
  "After="
 ],
 "On failure": [
  null,
  "При сбое"
 ],
 "Propagates reload to": [
  null,
  "PropagatesReloadTo="
 ],
 "Reload propagated from": [
  null,
  "ReloadPropagatedFrom="
 ],
 "Joins namespace of": [
  null,
  "JoinsNamespaceOf="
 ],
 "Condition $0=$1 was not met": [
  null,
  "Не выполнено условие $0=$1"
 ],
 "Deletion will remove the following files:": [
  null,
  "При удалении будут уничтожены следующие файлы:"
 ],
 "Pinned unit": [
  null,
  "Закреплённый юнит"
 ],
 "Status": [
  null,
  "Статус"
 ],
 "Path": [
  null,
  "Путь"
 ],
 "Listen": [
  null,
  "Прослушивать"
 ],
 "Container": [
  null,
  "Контейнер"
 ],
 "View Podman container": [
  null,
  "Просмотр контейнера Podman"
 ],
 "Condition failed": [
  null,
  "Условие не выполнено"
 ],
 "Show more relationships": [
  null,
  "Показать больше связей"
 ],
 "Show relationships": [
  null,
  "Показать связи"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Timer deletion failed": [
  null,
  "Не удалось удалить таймер"
 ],
 "Targets": [
  null,
  "Цели"
 ],
 "Sockets": [
  null,
  "Сокеты"
 ],
 "Timers": [
  null,
  "Таймеры"
 ],
 "Paths": [
  null,
  "Пути"
 ],
 "Go to $0": [
  null,
  "Перейти к $0"
 ],
 "Journal entry not found": [
  null,
  "Запись в журнале не найдена"
 ],
 "Journal entry": [
  null,
  "Запись в журнале"
 ],
 "Entry at $0": [
  null,
  "Запись в $0"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Loading unit failed": [
  null,
  "Не удалось загрузить модуль"
 ],
 "Service logs": [
  null,
  "Журналы службы"
 ],
 "No log entries": [
  null,
  "Нет записей в журнале"
 ],
 "Systemd units": [
  null,
  "Юниты systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Совпадения с критериями фильтров отсутствуют. Сбросьте все фильтры для вывода результатов."
 ],
 "Does not automatically start": [
  null,
  "Не запускается автоматически"
 ],
 "Cannot be enabled": [
  null,
  "Не может быть активирован"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Веб-консоль работает в режиме ограниченного доступа."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск. Он поддерживает следующие цели дампа: «local» (диск), «ssh» и «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "с $0 на $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "c $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "на $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Домен"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Присоединение к домену"
 ]
});
