cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Služby"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "network": [
  null,
  "síť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "rozhraní"
 ],
 "bridge": [
  null,
  "most"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "spřažení linek (bond)"
 ],
 "team": [
  null,
  "spřažení linek (team)"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac adresa"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "brána firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zóna"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Správa síťových spřažení (bond)"
 ],
 "Managing networking teams": [
  null,
  "Správa síťových spřažení (team)"
 ],
 "Managing networking bridges": [
  null,
  "Správa síťových mostů"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sítí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ]
});
