cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "ფაილების ბრაუზერი"
 ],
 "files": [
  null,
  "ფაილები"
 ],
 "explorer": [
  null,
  "დამთვალიერებელი"
 ],
 "filesystem": [
  null,
  "ფაილური სისტემა"
 ]
});
