cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "as",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
