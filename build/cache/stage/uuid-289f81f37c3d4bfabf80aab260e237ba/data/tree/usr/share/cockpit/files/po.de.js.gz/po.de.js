cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit-Dateien"
 ],
 "Home": [
  null,
  "Persönlicher Ordner"
 ],
 "Unable to create bookmark directory": [
  null,
  "Lesezeichenverzeichnis kann nicht erstellt werden"
 ],
 "Unable to save bookmark file": [
  null,
  "Lesezeichendatei kann nicht gespeichert werden"
 ],
 "Remove from bookmarks": [
  null,
  "Aus den Lesezeichen entfernen"
 ],
 "Add to bookmarks": [
  null,
  "Zu den Lesezeichen hinzufügen"
 ],
 "Bookmarks": [
  null,
  "Lesezeichen"
 ],
 "Bookmarked": [
  null,
  "Als Lesezeichen gespeichert"
 ],
 "Not bookmarked": [
  null,
  "Nicht als Lesezeichen gespeichert"
 ],
 "Filesystem": [
  null,
  "Dateisystem"
 ],
 "Edit path": [
  null,
  "Pfad bearbeiten"
 ],
 "Name": [
  null,
  "Name"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Largest size": [
  null,
  "Größte Größe"
 ],
 "Smallest size": [
  null,
  "Kleinste Größe"
 ],
 "Modified": [
  null,
  "Geändert"
 ],
 "First modified": [
  null,
  "Zuerst geändert"
 ],
 "Last modified": [
  null,
  "Zuletzt geändert"
 ],
 "Owner": [
  null,
  "Eigentümer"
 ],
 "Owner ascending": [
  null,
  "Eigentümer aufsteigend"
 ],
 "Owner descending": [
  null,
  "Eigentümer absteigend"
 ],
 "Permissions": [
  null,
  "Berechtigungen"
 ],
 "Most permissive": [
  null,
  "Am meisten zulässig"
 ],
 "Least permissive": [
  null,
  "Am wenigsten zulässig"
 ],
 "Show keyboard shortcuts": [
  null,
  "Tastenkombinationen anzeigen"
 ],
 "Filter directory": [
  null,
  "Verzeichnis filtern"
 ],
 "Display as a list": [
  null,
  "Als Liste anzeigen"
 ],
 "Display as a grid": [
  null,
  "Als Raster anzeigen"
 ],
 "Sort": [
  null,
  "Sortieren"
 ],
 "Hide hidden items": [
  null,
  "Versteckte Elemente ausblenden"
 ],
 "Show hidden items": [
  null,
  "Versteckte Elemente anzeigen"
 ],
 "$0 files": [
  null,
  "$0 Dateien"
 ],
 "Uploaded as $0, $1": [
  null,
  "Als $0, $1 hochgeladen"
 ],
 "Replace file $0?": [
  null,
  "Datei $0 ersetzen?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Eine Datei mit gleichem Namen existiert bereits in \"$0\". Sie zu ersetzen wird ihren Inhalt überschreiben."
 ],
 "New file": [
  null,
  "Neue Datei"
 ],
 "Original file on server": [
  null,
  "Originaldatei auf dem Server"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Diese Aktion auf alle widersprüchlichen Dateien anwenden"
 ],
 "Replace": [
  null,
  "Ersetzen"
 ],
 "Keep original": [
  null,
  "Original behalten"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Upload error": [
  null,
  "Hochladefehler"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Hochgeladene Datei kann nicht zum endgültigen Zielort verschoben werden"
 ],
 "Cancelled": [
  null,
  "Abgebrochen"
 ],
 "Cancelled upload of $0": [
  null,
  "Upload von $0 abgebrochen"
 ],
 "File uploaded": [
  null,
  "Datei hochgeladen"
 ],
 "Files uploaded": [
  null,
  "Dateien hochgeladen"
 ],
 "Change permissions": [
  null,
  "Berechtigungen ändern"
 ],
 "Uploads": [
  null,
  "Hochladevorgänge"
 ],
 "Cancel upload of $0": [
  null,
  "Upload von $0 abbrechen"
 ],
 "Upload $0% completed": [
  null,
  "Hochladen $0% abgeschlossen"
 ],
 "Upload": [
  null,
  "Hochladen"
 ],
 "None": [
  null,
  "Keine"
 ],
 "Execute-only": [
  null,
  "Nur Ausführen"
 ],
 "Write-only": [
  null,
  "Nur schreiben"
 ],
 "Write and execute": [
  null,
  "Schreiben und ausführen"
 ],
 "Read-only": [
  null,
  "Nur lesen"
 ],
 "Read and execute": [
  null,
  "Lesen und ausführen"
 ],
 "Read and write": [
  null,
  "Lesen und schreiben"
 ],
 "Read, write, and execute": [
  null,
  "Lesen, schreiben und ausführen"
 ],
 "Block device": [
  null,
  "Blockorientiertes Gerät"
 ],
 "Character device": [
  null,
  "Zeichengerät"
 ],
 "Directory": [
  null,
  "Verzeichnis"
 ],
 "Named pipe": [
  null,
  "Named Pipe"
 ],
 "Symbolic link": [
  null,
  "Symbolische Verknüpfung"
 ],
 "Regular file": [
  null,
  "Reguläre Datei"
 ],
 "Socket": [
  null,
  "Socket"
 ],
 "Name cannot be empty": [
  null,
  "Name darf nicht leer sein"
 ],
 "Name too long": [
  null,
  "Name zu lang"
 ],
 "Name cannot include a /": [
  null,
  "Name darf kein / enthalten"
 ],
 "Filename is the same as original name": [
  null,
  "Der Dateiname ist derselbe wie der ursprüngliche Name"
 ],
 "Directory with the same name exists": [
  null,
  "Verzeichniseigentümer mit gleichem Namen existiert bereits"
 ],
 "File exists": [
  null,
  "Datei existiert"
 ],
 "Pasting failed": [
  null,
  "Einfügen fehlgeschlagen"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" existiert, es wird nicht mit Einfügen überschrieben."
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Create directory": [
  null,
  "Verzeichnis erstellen"
 ],
 "Create file": [
  null,
  "Datei erstellen"
 ],
 "Edit permissions": [
  null,
  "Berechtigungen bearbeiten"
 ],
 "Open in terminal": [
  null,
  "Im Terminal öffnen"
 ],
 "Open text file": [
  null,
  "Textdatei öffnen"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Download": [
  null,
  "Herunterladen"
 ],
 "Create link": [
  null,
  "Link erstellen"
 ],
 "Drop files to upload": [
  null,
  "Dateien zum Hochladen ablegen"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Dateien können nicht abgelegt werden, ein anderer Hochladevorgang ist bereits im Gange"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Go up a directory": [
  null,
  "Ein Verzeichnis nach oben gehen"
 ],
 "Go back": [
  null,
  "Zurück"
 ],
 "Go forward": [
  null,
  "Weitergehen"
 ],
 "Activate selected item, enter directory": [
  null,
  "Ausgewählten Eintrag aktivieren, Verzeichnis eingeben"
 ],
 "Rename selected file or directory": [
  null,
  "Ausgewählte Datei oder ausgewähltes Verzeichnis umbenennen"
 ],
 "Create new directory": [
  null,
  "Neues Verzeichnis erstellen"
 ],
 "Copy selected file or directory": [
  null,
  "Ausgewählte Datei oder ausgewähltes Verzeichnis kopieren"
 ],
 "Paste file or directory": [
  null,
  "Datei oder Verzeichnis einfügen"
 ],
 "Select all": [
  null,
  "Alles auswählen"
 ],
 "Save current file": [
  null,
  "Die momentan geöffnete Datei speichern"
 ],
 "Close editor": [
  null,
  "Schließe den Editor"
 ],
 "Keyboard shortcuts": [
  null,
  "Tastenkombinationen"
 ],
 "Navigation": [
  null,
  "Navigation"
 ],
 "Editing": [
  null,
  "Bearbeiten"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Löschen von $0 Elementen erzwingen"
 ],
 "Delete $0 items?": [
  null,
  "$0 Elemente löschen?"
 ],
 "Force delete file $0?": [
  null,
  "Löschen der Datei $0 erzwingen?"
 ],
 "Delete file $0?": [
  null,
  "Datei $0 löschen?"
 ],
 "Force delete link $0?": [
  null,
  "Löschen der Verknüpfung $0 erzwingen?"
 ],
 "Delete link $0?": [
  null,
  "Link $0 löschen?"
 ],
 "Force delete directory $0?": [
  null,
  "Löschen von Verzeichnis $0 erzwingen?"
 ],
 "Delete directory $0?": [
  null,
  "Verzeichnis $0 löschen?"
 ],
 "Force delete $0": [
  null,
  "Löschen von $0 erzwingen"
 ],
 "Delete $0?": [
  null,
  "$0 löschen?"
 ],
 "No access": [
  null,
  "Kein Zugriff"
 ],
 "Missing type": [
  null,
  "Fehlender Typ"
 ],
 "Collapse": [
  null,
  "Einklappen"
 ],
 "Show all files": [
  null,
  "Alle Dateien anzeigen"
 ],
 "$0 permissions": [
  null,
  "$0-Berechtigungen"
 ],
 "Permissions for $0 files": [
  null,
  "Berechtigungen für $0 Dateien"
 ],
 "Ownership": [
  null,
  "Eigentümerschaft"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Access": [
  null,
  "Zugriff"
 ],
 "Owner access": [
  null,
  "Eigentümerzugriff"
 ],
 "Group access": [
  null,
  "Gruppenzugriff"
 ],
 "Others access": [
  null,
  "Anderer Zugriff"
 ],
 "Security context": [
  null,
  "Sicherheitskontext"
 ],
 "Set executable as program": [
  null,
  "Ausführbare Datei als Programm festlegen"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change permissions for enclosed files": [
  null,
  "Berechtigungen für enthaltene Dateien ändern"
 ],
 "(original owner)": [
  null,
  "(ursprünglicher Eigentümer)"
 ],
 "keep original owners": [
  null,
  "Originaleigentümer behalten"
 ],
 "Paste as owner": [
  null,
  "Als Eigentümer einfügen"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Die eingefügten Dateien haben einen anderen Eigentümer. Standardmäßig wird der Eigentümer so geändert, dass er mit dem Zielverzeichnis übereinstimmt."
 ],
 "New owner": [
  null,
  "Neuer Eigentümer"
 ],
 "Overwrite": [
  null,
  "Überschreiben"
 ],
 "New filename": [
  null,
  "Neuer Dateiname"
 ],
 "New name": [
  null,
  "Neuer Name"
 ],
 "Rename $0?": [
  null,
  "$0 umbenennen?"
 ],
 "link to $0": [
  null,
  "Link zu $0"
 ],
 "Create link to $0": [
  null,
  "Link zu $0 erstellen"
 ],
 "Target": [
  null,
  "Ziel"
 ],
 "Symlink name": [
  null,
  "Name des symbolischen Links"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolut vs. Relativ"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Absolute symbolische Links sind ideal, um auf Dateien oder Verzeichnisse zu verweisen, die sich nicht verschieben lassen, wie z. B. Systemdateien."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Relative symbolische Links sind nützlich, wenn sowohl ein symbolischer Link als auch das Ziel gleichzeitig verschoben werden können, z. B. beim Umbenennen oder Verschieben eines übergeordneten Verzeichnisses."
 ],
 "Absolute": [
  null,
  "Absolut"
 ],
 "Relative": [
  null,
  "Relativ"
 ],
 "The file has been removed on disk": [
  null,
  "Die Datei wurde von der Festplatte entfernt"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Die existierende Datei wurde unerwartet geändert"
 ],
 "Edit $0": [
  null,
  "$0 bearbeiten"
 ],
 "View $0": [
  null,
  "$0 ansehen"
 ],
 "The file has changed on disk": [
  null,
  "Die Datei hat sich auf der Festplatte geändert"
 ],
 "Reload": [
  null,
  "Neu laden"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save changes?": [
  null,
  "Änderungen speichern?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Die Datei wurde nach dem Öffnen gelöscht; durch Speichern wird sie neu erstellt."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Die Datei hat sich auf der Festplatte zwischen dem Zeitpunkt des Öffnens und jetzt verändert"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 hat nicht gespeicherte Änderungen, die endgültig verloren gehen, wenn sie verworfen werden."
 ],
 "Discard": [
  null,
  "Verwerfen"
 ],
 "File name": [
  null,
  "Dateiname"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Cannot create file in current directory": [
  null,
  "Datei im aktuellen Verzeichnis kann nicht erstellt werden"
 ],
 "Permission denied": [
  null,
  "Erlaubnis verweigert"
 ],
 "Directory name cannot be empty": [
  null,
  "Verzeichnisname darf nicht leer sein"
 ],
 "Directory name too long": [
  null,
  "Verzeichnisname zu lang"
 ],
 "Directory name cannot include a /": [
  null,
  "Verzeichnisname darf kein / enthalten"
 ],
 "Directory name": [
  null,
  "Verzeichnisname"
 ],
 "Directory owner": [
  null,
  "Verzeichniseigentümer"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "Clear filter": [
  null,
  "Filter entfernen"
 ],
 "Directory is empty": [
  null,
  "Verzeichnis ist leer"
 ],
 "$0 item is hidden": [
  null,
  "$0 Element ist verborgen",
  "$0 Elemente sind verborgen"
 ],
 "Folder": [
  null,
  "Ordner"
 ],
 "File": [
  null,
  "Datei"
 ],
 "Others": [
  null,
  "Andere"
 ],
 "$0 files selected": [
  null,
  "$0 Dateien ausgewählt"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Verzeichnis enthält $0 Verzeichnisse, $1 Dateien"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Verzeichnis enthält $0 Verzeichnisse, $1 Dateien, $2 versteckte"
 ],
 "User": [
  null,
  "Benutzer"
 ]
});
