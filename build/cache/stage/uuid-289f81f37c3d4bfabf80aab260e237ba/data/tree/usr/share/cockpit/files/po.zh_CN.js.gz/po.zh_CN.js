cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit 文件"
 ],
 "Home": [
  null,
  "家目录"
 ],
 "Unable to create bookmark directory": [
  null,
  "无法创建书签目录"
 ],
 "Unable to save bookmark file": [
  null,
  "无法保存书签文件"
 ],
 "Remove from bookmarks": [
  null,
  "从书签中删除"
 ],
 "Add to bookmarks": [
  null,
  "添加到书签"
 ],
 "Bookmarks": [
  null,
  "书签"
 ],
 "Filesystem": [
  null,
  "文件系统"
 ],
 "Edit path": [
  null,
  "编辑路径"
 ],
 "Name": [
  null,
  "名称"
 ],
 "A-Z": [
  null,
  "由 A 到 Z"
 ],
 "Z-A": [
  null,
  "由 Z 到 A"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Largest size": [
  null,
  "尺寸最大"
 ],
 "Smallest size": [
  null,
  "尺寸最小"
 ],
 "Modified": [
  null,
  "修改时间"
 ],
 "First modified": [
  null,
  "最先修改"
 ],
 "Last modified": [
  null,
  "最后修改"
 ],
 "Owner": [
  null,
  "所有者"
 ],
 "Owner ascending": [
  null,
  "所有者升序"
 ],
 "Owner descending": [
  null,
  "所有者降序"
 ],
 "Permissions": [
  null,
  "权限"
 ],
 "Most permissive": [
  null,
  "最大权限"
 ],
 "Least permissive": [
  null,
  "最小权限"
 ],
 "Show keyboard shortcuts": [
  null,
  "显示键盘快捷方式"
 ],
 "Filter directory": [
  null,
  "筛选目录"
 ],
 "Display as a list": [
  null,
  "以列表显示"
 ],
 "Display as a grid": [
  null,
  "以网格显示"
 ],
 "Sort": [
  null,
  "排序"
 ],
 "Hide hidden items": [
  null,
  "不显示隐藏项目"
 ],
 "Show hidden items": [
  null,
  "显示隐藏项目"
 ],
 "$0 files": [
  null,
  "$0 文件"
 ],
 "Uploaded as $0, $1": [
  null,
  "上传为 $0，$1"
 ],
 "Replace file $0?": [
  null,
  "替换文件 $0 ？"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "已存在和 $0 同名的文件，替换该文件将会覆盖其内容。"
 ],
 "New file": [
  null,
  "新文件"
 ],
 "Original file on server": [
  null,
  "服务器上原有的文件"
 ],
 "Apply this action to all conflicting files": [
  null,
  "将此操作应用于所有冲突文件"
 ],
 "Replace": [
  null,
  "替换"
 ],
 "Keep original": [
  null,
  "保留原本的"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Failed": [
  null,
  "失败"
 ],
 "Upload error": [
  null,
  "上传失败"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "无法将上传的文件移至最终目的地"
 ],
 "Cancelled": [
  null,
  "已取消"
 ],
 "Cancelled upload of $0": [
  null,
  "已取消上传 $0"
 ],
 "File uploaded": [
  null,
  "文件已上传"
 ],
 "Files uploaded": [
  null,
  "文件已上传"
 ],
 "Change permissions": [
  null,
  "更改权限"
 ],
 "Uploads": [
  null,
  "上传项目"
 ],
 "Cancel upload of $0": [
  null,
  "取消上传 $0"
 ],
 "Upload $0% completed": [
  null,
  "上传 $0 已完成"
 ],
 "Upload": [
  null,
  "上传"
 ],
 "None": [
  null,
  "无"
 ],
 "Execute-only": [
  null,
  "只能执行"
 ],
 "Write-only": [
  null,
  "只能写入"
 ],
 "Write and execute": [
  null,
  "写入与执行"
 ],
 "Read-only": [
  null,
  "只读"
 ],
 "Read and execute": [
  null,
  "读取与执行"
 ],
 "Read and write": [
  null,
  "读取与写入"
 ],
 "Read, write, and execute": [
  null,
  "读取，写入与执行"
 ],
 "Block device": [
  null,
  "块设备"
 ],
 "Character device": [
  null,
  "字符设备"
 ],
 "Directory": [
  null,
  "目录"
 ],
 "Named pipe": [
  null,
  "命名管道"
 ],
 "Symbolic link": [
  null,
  "符号链接"
 ],
 "Regular file": [
  null,
  "常规文件"
 ],
 "Socket": [
  null,
  "Socket"
 ],
 "Name cannot be empty": [
  null,
  "名称不能为空"
 ],
 "Name too long": [
  null,
  "名称太长"
 ],
 "Name cannot include a /": [
  null,
  "名称不能包含 /"
 ],
 "Filename is the same as original name": [
  null,
  "文件名与原文件名同名"
 ],
 "Directory with the same name exists": [
  null,
  "同名的目录已经存在"
 ],
 "File exists": [
  null,
  "文件已存在"
 ],
 "Pasting failed": [
  null,
  "粘贴失败"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" 存在，没有使用粘贴覆盖。"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Create directory": [
  null,
  "创建目录"
 ],
 "Create file": [
  null,
  "创建文件"
 ],
 "Edit permissions": [
  null,
  "编辑权限"
 ],
 "Open in terminal": [
  null,
  "在终端中打开"
 ],
 "Open text file": [
  null,
  "打开文本文件"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Rename": [
  null,
  "重命名"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Download": [
  null,
  "下载"
 ],
 "Create link": [
  null,
  "创建链接"
 ],
 "Drop files to upload": [
  null,
  "拖放文件以上传"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "无法拖放文件，另一个上传已在进行中"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Go up a directory": [
  null,
  "转到上级目录"
 ],
 "Go back": [
  null,
  "回退"
 ],
 "Go forward": [
  null,
  "继续"
 ],
 "Activate selected item, enter directory": [
  null,
  "激活所选项目，进入目录"
 ],
 "Rename selected file or directory": [
  null,
  "重命名所选的文件或目录"
 ],
 "Create new directory": [
  null,
  "创建新目录"
 ],
 "Copy selected file or directory": [
  null,
  "复制所选的文件或目录"
 ],
 "Paste file or directory": [
  null,
  "粘贴文件或目录"
 ],
 "Select all": [
  null,
  "选择全部"
 ],
 "Close editor": [
  null,
  ""
 ],
 "Keyboard shortcuts": [
  null,
  "键盘快捷键"
 ],
 "Navigation": [
  null,
  "导航"
 ],
 "Editing": [
  null,
  "编辑"
 ],
 "Editor": [
  null,
  "编辑器"
 ],
 "Force delete $0 items": [
  null,
  "强制删除 $0 个项目"
 ],
 "Delete $0 items?": [
  null,
  "删除 $0 个项目？"
 ],
 "Force delete file $0?": [
  null,
  "强制删除文件 $0 ？"
 ],
 "Delete file $0?": [
  null,
  "删除文件 $0 ？"
 ],
 "Force delete link $0?": [
  null,
  "强制删除链接 $0 ?"
 ],
 "Delete link $0?": [
  null,
  "删除链接 $0 ？"
 ],
 "Force delete directory $0?": [
  null,
  "强制删除目录 $0 ？"
 ],
 "Delete directory $0?": [
  null,
  "删除目录 $0 ？"
 ],
 "Force delete $0": [
  null,
  "强制删除 $0"
 ],
 "Delete $0?": [
  null,
  "删除 $0 ？"
 ],
 "No access": [
  null,
  "无访问权限"
 ],
 "Missing type": [
  null,
  "缺少类型"
 ],
 "Collapse": [
  null,
  "折叠"
 ],
 "Show all files": [
  null,
  "显示所有文件"
 ],
 "$0 permissions": [
  null,
  "$0 权限"
 ],
 "Permissions for $0 files": [
  null,
  "$0 文件的权限"
 ],
 "Ownership": [
  null,
  "所有权"
 ],
 "Group": [
  null,
  "组"
 ],
 "Access": [
  null,
  "访问"
 ],
 "Owner access": [
  null,
  "所有者访问权限"
 ],
 "Group access": [
  null,
  "用户组访问权限"
 ],
 "Others access": [
  null,
  "其它人访问权限"
 ],
 "Security context": [
  null,
  "安全上下文"
 ],
 "Set executable as program": [
  null,
  "将可执行文件设置为程序"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change permissions for enclosed files": [
  null,
  "更改所附文件的权限"
 ],
 "(original owner)": [
  null,
  "（原始所有者）"
 ],
 "keep original owners": [
  null,
  "保留原始所有者"
 ],
 "Paste as owner": [
  null,
  "以指定所有者粘贴"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "要粘贴的文件所有者与目标目录不同。默认情况下，所有权将更改为与目标目录一致。"
 ],
 "New owner": [
  null,
  "新所有者"
 ],
 "Overwrite": [
  null,
  "覆盖"
 ],
 "New filename": [
  null,
  "新文件名"
 ],
 "New name": [
  null,
  "新名称"
 ],
 "Rename $0?": [
  null,
  "将 $0 重新命名？"
 ],
 "link to $0": [
  null,
  "链接到 $0"
 ],
 "Create link to $0": [
  null,
  "创建到 $0 的链接"
 ],
 "Target": [
  null,
  "目标"
 ],
 "Symlink name": [
  null,
  "符号链接名称"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Absolute vs. Relative": [
  null,
  "绝对 vs. 相对"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "绝对符号链接适合指向不会被移动的文件或目录，例如系统文件。"
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "相对符号链接适合符号链接与目标同时移动的场景，例如重命名或移动一父目录时。"
 ],
 "Absolute": [
  null,
  "绝对"
 ],
 "Relative": [
  null,
  "相对"
 ],
 "The file has been removed on disk": [
  null,
  "文件已从磁盘上删除"
 ],
 "The existing file changed unexpectedly": [
  null,
  "现有文件被意外更改"
 ],
 "Edit $0": [
  null,
  "编辑 $0"
 ],
 "View $0": [
  null,
  "查看 $0"
 ],
 "The file has changed on disk": [
  null,
  "文件已在磁盘上进行了更改"
 ],
 "Reload": [
  null,
  "重载"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save changes?": [
  null,
  "保存更改？"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "文件在打开后已被删除，保存将重新创建该文件。"
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "该文件在打开后和现在之间已在磁盘上发生更改"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 有未保存的更改，丢弃后将永久丢失。"
 ],
 "Discard": [
  null,
  "丢弃"
 ],
 "File name": [
  null,
  "文件名"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Cannot create file in current directory": [
  null,
  "不能在当前目录中创建文件"
 ],
 "Permission denied": [
  null,
  "权限被拒绝"
 ],
 "Directory name cannot be empty": [
  null,
  "目录名称不能为空"
 ],
 "Directory name too long": [
  null,
  "目录名称太长"
 ],
 "Directory name cannot include a /": [
  null,
  "目录名称不能包含 /"
 ],
 "Directory name": [
  null,
  "目录名称"
 ],
 "Directory owner": [
  null,
  "目录所有者"
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "Clear filter": [
  null,
  "清除过滤器"
 ],
 "Directory is empty": [
  null,
  "目录为空"
 ],
 "$0 item is hidden": [
  null,
  "$0 项目被隐藏"
 ],
 "Folder": [
  null,
  "文件夹"
 ],
 "File": [
  null,
  "文件"
 ],
 "Others": [
  null,
  "其它"
 ],
 "$0 files selected": [
  null,
  "选择了 $0 个文件"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "目录包含 $0 目录、$1 文件"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "目录包含 $0 目录、$1 文件、$2 隐藏"
 ],
 "User": [
  null,
  "用户"
 ]
});
