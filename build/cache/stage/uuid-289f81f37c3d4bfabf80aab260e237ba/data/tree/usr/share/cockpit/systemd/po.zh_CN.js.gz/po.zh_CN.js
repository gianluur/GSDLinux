cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "密钥发生变化通常是因为重新安装了操作系统。但是，意外的变更也可能意味着有第三方正试图拦截您的连接。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要确保您的连接没有被恶意第三方截取，请验证主机密钥指纹："
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "结果指纹可以通过公共方法（包括电子邮件）共享。"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Journal": [
  null,
  "日志"
 ],
 "Terminal": [
  null,
  "终端"
 ],
 "Hardware information": [
  null,
  "硬件信息"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copied": [
  null,
  "复制的"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "active": [
  null,
  "激活"
 ],
 "Default": [
  null,
  "默认"
 ],
 "Light": [
  null,
  "亮色"
 ],
 "Dark": [
  null,
  "暗色"
 ],
 "Help": [
  null,
  "帮助"
 ],
 "Select": [
  null,
  "选择"
 ],
 "System": [
  null,
  "系统"
 ],
 "Search": [
  null,
  "搜索"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安装"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "主机 $0 上找不到版本兼容的 Cockpit。"
 ],
 "Add": [
  null,
  "添加"
 ],
 "$0 key changed": [
  null,
  "已更改 $0 个密钥"
 ],
 "Trust and add host": [
  null,
  "信任并添加主机"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要验证指纹，在 $0 上运行以下内容（在实际的物理机器上本地进行，或通过一个可信任的网络进行）："
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指纹匹配，请点击“信任并添加主机”。否则，请不要连接并联系您的管理员。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成的指纹可以通过公共方法（包括电子邮件）共享。如果您需要其他人为您进行验证，他们可以使用任何方法发送结果。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次连接到 $0。"
 ],
 "Verify fingerprint": [
  null,
  "验证指纹"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "通过一个可信网络运行这个命令，或在远程机器上运行这个命令："
 ],
 "The fingerprint should match:": [
  null,
  "指纹应匹配："
 ],
 "The password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key passwords do not match": [
  null,
  "密钥密码不匹配"
 ],
 "Log in to $0": [
  null,
  "登录到 $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "无法登录到 $0 。主机不接受密码登录，或您的任何 SSH 密钥。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受密码保护的，主机不允许使用密码登录。请在 $1 提供密钥的密码。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受保护的。您可以用您的登录密码或通过在 $1 提供密钥的密码来登录。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "创建一个新的 SSH 密钥，并对其进行授权"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "将在 $2 上为 $1 创建位于 $0 的新 SSH 密钥，并将其添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Key password": [
  null,
  "密钥密码"
 ],
 "Confirm key password": [
  null,
  "确认密钥密码"
 ],
 "Authorize SSH key": [
  null,
  "授权 SSH 密钥"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 密钥 $0 将被添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Authentication": [
  null,
  "认证"
 ],
 "SSH key": [
  null,
  "SSH 密钥"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 密钥 $0 将会在剩余的会话中可用，也可以在登录到其他主机时可用。"
 ],
 "Permission denied": [
  null,
  "权限被拒绝"
 ],
 "Clear input value": [
  null,
  "清除输入值"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "Create $0": [
  null,
  "创建 $0"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "You now have administrative access.": [
  null,
  "您已经获取了管理员权限。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "没有可用于获取管理权限的方法 (sudo -A, pkexec)。"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "请进行身份验证以获取管理员权限"
 ],
 "Switch to administrative access": [
  null,
  "切换到管理员权限"
 ],
 "Authenticate": [
  null,
  "认证"
 ],
 "Administrative access": [
  null,
  "管理员权限"
 ],
 "Problem becoming administrator": [
  null,
  "成为管理员时出现问题"
 ],
 "Method": [
  null,
  "模式"
 ],
 "Limit access": [
  null,
  "限制访问"
 ],
 "Switch to limited access": [
  null,
  "切换到限制权限"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限制访问模式会限制管理员权限。Web 控制台部分功能将会减少。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的浏览器将会在不同会话之间记住您的访问级别。"
 ],
 "Limited access": [
  null,
  "被限制的访问"
 ],
 "Turn on administrative access": [
  null,
  "开启管理员权限"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "less than a minute ago": [
  null,
  "少于一分钟前"
 ],
 "in less than a minute": [
  null,
  "少于一分钟"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Excellent password": [
  null,
  "密码强度优秀"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Unknown host: $0": [
  null,
  "未知主机：$0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "无法使用 SSH 密钥身份验证登录到 $0。请提供密码。"
 ],
 "SSH key login": [
  null,
  "SSH 密钥登录"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit 已报告错误码 $0"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "Row expansion": [
  null,
  "行扩展"
 ],
 "Row select": [
  null,
  "行选择"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Error during initialization": [
  null,
  "初始化时出错"
 ],
 "Failed": [
  null,
  "失败"
 ],
 "Home": [
  null,
  ""
 ],
 "Not a directory": [
  null,
  "不是目录"
 ],
 "Type to filter": [
  null,
  "输入内容来过滤"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "文件系统"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "Folder": [
  null,
  "文件夹"
 ],
 "File": [
  null,
  "文件"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "当前登录的用户无权查看系统更改"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Select an option": [
  null,
  "选择一个选项"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 exited with code $1": [
  null,
  "$0 退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "$0 失败"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Server has closed the connection.": [
  null,
  "服务器已关闭了连接。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "$0 is not a directory": [
  null,
  "$0 不是目录"
 ],
 "$0 does not exist": [
  null,
  "$0 不存在"
 ],
 "Font size": [
  null,
  "字体大小"
 ],
 "Decrease by one": [
  null,
  "减一"
 ],
 "Increase by one": [
  null,
  "加一"
 ],
 "Appearance": [
  null,
  "外观"
 ],
 "Black": [
  null,
  "黑色"
 ],
 "White": [
  null,
  "白"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Unable to open directory": [
  null,
  "无法打开目录"
 ],
 "Running process prevents directory change": [
  null,
  "运行进程会防止目录更改"
 ],
 "Change directory": [
  null,
  "更改目录"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "更改目录将强制停止当前运行的进程。在继续之前，也可以手动在终端中停止进程。"
 ],
 "Terminal not available": [
  null,
  "终端不可用"
 ],
 "This browser does not support WebGL2.": [
  null,
  "此浏览器不支持 WebGL2。"
 ],
 "unknown": [
  null,
  "未知"
 ],
 "Shutdown": [
  null,
  "关机"
 ],
 "running $0": [
  null,
  "运行中 $0"
 ],
 "Current boot": [
  null,
  "当前启动"
 ],
 "Previous boot": [
  null,
  "以前启动"
 ],
 "Last 24 hours": [
  null,
  "最近 24 小时"
 ],
 "Last 7 days": [
  null,
  "最近 7 天"
 ],
 "Only emergency": [
  null,
  "只限紧急情况"
 ],
 "Alert and above": [
  null,
  "“警报 (Alert)”及更高级别"
 ],
 "Critical and above": [
  null,
  "Critical 及更高级别"
 ],
 "Error and above": [
  null,
  "Error 及更高级别"
 ],
 "Warning and above": [
  null,
  "Warning 及更高级别"
 ],
 "Notice and above": [
  null,
  "Notice 及更高级别"
 ],
 "Info and above": [
  null,
  "Info 及更高级别"
 ],
 "Debug and above": [
  null,
  "Debug 及更高级别"
 ],
 "Toggle filters": [
  null,
  "切换过滤器"
 ],
 "Time": [
  null,
  "时间"
 ],
 "Priority": [
  null,
  "优先级"
 ],
 "Identifier": [
  null,
  "标识符"
 ],
 "Filters": [
  null,
  "过滤"
 ],
 "Pause": [
  null,
  "暂停"
 ],
 "Resume": [
  null,
  "继续"
 ],
 "All": [
  null,
  "所有"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日期规格应为 YYYY-MM-DD hh:mm:ss 格式。另外，也可以使用字符串 'yesterday', 'today', 'tomorrow'。'now' 代表当前时间。另外，还可以指定相对时间，前缀为 '-' 或 '+'"
 ],
 "Since": [
  null,
  "自从"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "显示指定日期及以后的条目。"
 ],
 "Until": [
  null,
  "直到"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "显示指定日期及以前的条目。"
 ],
 "Boot": [
  null,
  "引导"
 ],
 "Show messages from a specific boot.": [
  null,
  "显示来自特定引导的消息."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "这将添加一个 '_BOOT_ID=' 匹配项。 如果未指定，则将显示来自当前引导的日志。 在没有指定 ID 时，正偏移将从日志开始查找启动，而等于或小于零的偏移将从日志末尾开始查找启动。因此，1 表示日志中第一次引导（按时间顺序排列），2 为第二个，以此类推；-0 是最后一次引导，-1 是最后一次引导前的一个，以此类推。"
 ],
 "Unit": [
  null,
  "单元"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "显示指定 systemd 单元的消息。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "这将添加 '_SYSTEMD_UNIT='、'COREDUMP_UNIT=' 和 'UNIT=' 匹配项，以查找给定单元的所有可能消息。可以包含以逗号分隔的多个单元。"
 ],
 "Free-form search": [
  null,
  "自由形式搜索"
 ],
 "Show messages containing given string.": [
  null,
  "显示包含给定字符串的消息."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "您可以对日志中的任意文本字符串进行过滤（可使用正则表达式）。此外，本过滤器支持按消息日志字段进行过滤：各字段由空格分隔（格式为 FIELD=VALUE），其中赋值 (VALUE) 亦可是由逗号分隔列出的、符合格式的各种赋值。"
 ],
 "journalctl manpage": [
  null,
  "journalctl 手册页"
 ],
 "Successfully copied to clipboard": [
  null,
  "成功复制到剪贴板"
 ],
 "Create timer": [
  null,
  "创建定时器"
 ],
 "Edit timer": [
  null,
  "编辑定时器"
 ],
 "Timer creation failed": [
  null,
  "计时器创建失败"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "无法获取定时器的启动条件"
 ],
 "Failed to get the timer command": [
  null,
  "获取定时器命令失败"
 ],
 "This field cannot be empty": [
  null,
  "该字段不能为空"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "只允许使用字母, 数字, : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Shell command": [
  null,
  "Shell 命令"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "此命令将由 /bin/sh 执行。"
 ],
 "Trigger": [
  null,
  "触发器"
 ],
 "At specific time": [
  null,
  "在指定时间"
 ],
 "After system boot": [
  null,
  "系统引导后"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Minutes": [
  null,
  "分钟"
 ],
 "Hours": [
  null,
  "小时"
 ],
 "Weeks": [
  null,
  "周"
 ],
 "Delay must be a number": [
  null,
  "延迟必须是一个数字"
 ],
 "Repeat": [
  null,
  "重复"
 ],
 "Don't repeat": [
  null,
  "不要重复"
 ],
 "Minutely": [
  null,
  "每分钟"
 ],
 "Hourly": [
  null,
  "每小时"
 ],
 "Daily": [
  null,
  "每日"
 ],
 "Weekly": [
  null,
  "每周"
 ],
 "Monthly": [
  null,
  "每月"
 ],
 "Yearly": [
  null,
  "每年"
 ],
 "Run at": [
  null,
  "运行于"
 ],
 "At second": [
  null,
  "在秒"
 ],
 "At minute": [
  null,
  "在分钟"
 ],
 "Run on": [
  null,
  "运行于"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分钟需要是 0-59 间的数字"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "秒需要是 0-59 之间的数字"
 ],
 "Repeat weekly": [
  null,
  "每周重复"
 ],
 "Mondays": [
  null,
  "周一"
 ],
 "Tuesdays": [
  null,
  "周二"
 ],
 "Wednesdays": [
  null,
  "周三"
 ],
 "Thursdays": [
  null,
  "周四"
 ],
 "Fridays": [
  null,
  "周五"
 ],
 "Saturdays": [
  null,
  "周六"
 ],
 "Sundays": [
  null,
  "周日"
 ],
 "Repeat monthly": [
  null,
  "每月重复"
 ],
 "1st": [
  null,
  "1 日"
 ],
 "2nd": [
  null,
  "2 日"
 ],
 "3rd": [
  null,
  "3 日"
 ],
 "4th": [
  null,
  "4 日"
 ],
 "5th": [
  null,
  "5 日"
 ],
 "6th": [
  null,
  "6 日"
 ],
 "7th": [
  null,
  "7 日"
 ],
 "8th": [
  null,
  "8 日"
 ],
 "9th": [
  null,
  "9 日"
 ],
 "10th": [
  null,
  "10 日"
 ],
 "11th": [
  null,
  "11 日"
 ],
 "12th": [
  null,
  "12 日"
 ],
 "13th": [
  null,
  "13 日"
 ],
 "14th": [
  null,
  "14 日"
 ],
 "15th": [
  null,
  "15 日"
 ],
 "16th": [
  null,
  "16 日"
 ],
 "17th": [
  null,
  "17 日"
 ],
 "18th": [
  null,
  "18 日"
 ],
 "19th": [
  null,
  "19 日"
 ],
 "20th": [
  null,
  "20 日"
 ],
 "21th": [
  null,
  "21 日"
 ],
 "22th": [
  null,
  "22 日"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "24 日"
 ],
 "25th": [
  null,
  "25 日"
 ],
 "26th": [
  null,
  "26 日"
 ],
 "27th": [
  null,
  "27 日"
 ],
 "28th": [
  null,
  "28 日"
 ],
 "29th": [
  null,
  "29 日"
 ],
 "30th": [
  null,
  "30 日"
 ],
 "31st": [
  null,
  "31 日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Unclean shutdown": [
  null,
  "非正常关机"
 ],
 "View logs": [
  null,
  "查看日志"
 ],
 "Dismiss": [
  null,
  "清除"
 ],
 "Scheduled poweroff at $0": [
  null,
  "计划在 $0 关闭电源"
 ],
 "Cancel poweroff": [
  null,
  "取消关机"
 ],
 "Scheduled reboot at $0": [
  null,
  "计划在 $0 重启"
 ],
 "Cancel reboot": [
  null,
  "取消重启"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "Set hostname": [
  null,
  "设置主机名"
 ],
 "Configuration": [
  null,
  "配置"
 ],
 "Hostname": [
  null,
  "主机名"
 ],
 "System time": [
  null,
  "系统时间"
 ],
 "Domain": [
  null,
  "域"
 ],
 "Performance profile": [
  null,
  "性能配置集"
 ],
 "Secure shell keys": [
  null,
  "安全 shell 密钥"
 ],
 "Show fingerprints": [
  null,
  "显示指纹"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "列出 SSH 主机密钥失败: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "加载 SSH 密钥失败"
 ],
 "Error message": [
  null,
  "错误信息"
 ],
 "Loading keys...": [
  null,
  "正在加载密钥 ......"
 ],
 "No host keys found.": [
  null,
  "没有找到主机密钥。"
 ],
 "Machine SSH key fingerprints": [
  null,
  "主机 SSH 密钥指纹"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "实际主机名必须小于等于64个字符"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "实际主机名仅包含小写字母、数字、破折号和句号（包括填充的子域）"
 ],
 "Change host name": [
  null,
  "修改主机名"
 ],
 "Pretty host name": [
  null,
  "易读主机名"
 ],
 "Real host name": [
  null,
  "实际主机名"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "用户 $0 不允许修改加密策略"
 ],
 "Cryptographic policy": [
  null,
  "加密策略"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "建议的，当前威胁模型的安全设置。"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "允许带有 SHA-1 签名验证的 DEFAULT。"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "更高的互操作性，但代价是攻击面增大。"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "具有活动目录互操作性的 LEGACY。"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "仅在使用 FIPS 模式引导时才使用已批准和允许的算法。"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "具有进一步通用标准限制的 FIPS。"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "防止近期被安全攻击会降低互操作性。"
 ],
 "Custom cryptographic policy": [
  null,
  "自定义加密策略"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "加密策略是一个系统组件，用于配置核心加密子系统，涵盖 TLS、IPSec、SSH、DNSSec 和 Kerberos 协议。"
 ],
 "Change cryptographic policy": [
  null,
  "更改加密策略"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "正在应用新策略…… 这可能需要几分钟时间。"
 ],
 "Reapply and reboot": [
  null,
  "重新应用并重启"
 ],
 "Apply and reboot": [
  null,
  "应用并重启"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS 没有被正确启用"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "加密策略不一致"
 ],
 "Review cryptographic policy": [
  null,
  "检查加密策略"
 ],
 "System information": [
  null,
  "系统信息"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Asset tag": [
  null,
  "资产标签"
 ],
 "Machine ID": [
  null,
  "机器编号"
 ],
 "Up since": [
  null,
  "运行时间"
 ],
 "View hardware details": [
  null,
  "查看硬件详细信息"
 ],
 "Last successful login:": [
  null,
  "最后成功的登录："
 ],
 "$0 failed login attempt": [
  null,
  "$0 尝试登录失败"
 ],
 "View login history": [
  null,
  "查看登录历史记录"
 ],
 "recommended": [
  null,
  "推荐"
 ],
 "inconsistent": [
  null,
  "不一致"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "加入域需要安装 realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "无法加入域，因为 realmd 在此系统上不可用"
 ],
 "Joining this domain is not supported": [
  null,
  "不支持加入该域"
 ],
 "Login format": [
  null,
  "登录格式"
 ],
 "Server software": [
  null,
  "服务器软件"
 ],
 "Client software": [
  null,
  "客户端软件"
 ],
 "Leave domain": [
  null,
  "离开域"
 ],
 "Leave $0": [
  null,
  "离开 $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "离开该域后，仅有使用本地凭据的用户可以登录到该主机。这一操作还可能更改 DNS 解析设置及 CA 信任列表，进而影响其他服务。"
 ],
 "Validating address": [
  null,
  "验证地址"
 ],
 "Contacted domain": [
  null,
  "联系的域"
 ],
 "Domain could not be contacted": [
  null,
  "无法联系到域"
 ],
 "Domain is not supported": [
  null,
  "不支持域"
 ],
 "Domain address": [
  null,
  "域地址"
 ],
 "Domain administrator name": [
  null,
  "域管理员用户名"
 ],
 "Domain administrator password": [
  null,
  "域管理员密码"
 ],
 "Joining": [
  null,
  "加入"
 ],
 "Join": [
  null,
  "加入"
 ],
 "This may take a while": [
  null,
  "这可能需要一些时间"
 ],
 "Not permitted to configure realms": [
  null,
  "不允许配置域"
 ],
 "Join domain": [
  null,
  "加入域"
 ],
 "Install realmd support": [
  null,
  "安装 realmd 支持"
 ],
 "$0 disk is failing": [
  null,
  "$0 磁盘失败"
 ],
 "Connected to Insights": [
  null,
  "已连接到 Insights"
 ],
 "Not connected to Insights": [
  null,
  "没有连接到 Insights"
 ],
 "Health": [
  null,
  "健康"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU"
 ],
 "Usage": [
  null,
  "占用率"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "内存"
 ],
 "View metrics and history": [
  null,
  "查看指标和历史记录"
 ],
 "Tuned is not available": [
  null,
  "Tuned 不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未运行"
 ],
 "Tuned is off": [
  null,
  "Tuned 已关闭"
 ],
 "This system is using the recommended profile": [
  null,
  "该系统正在使用推荐的配置集"
 ],
 "This system is using a custom profile": [
  null,
  "该系统正在使用自定义的配置集"
 ],
 "none": [
  null,
  "空"
 ],
 "Communication with tuned has failed": [
  null,
  "与 tuned 通信失败"
 ],
 "Failed to enable tuned": [
  null,
  "启用 tuned 失败"
 ],
 "Failed to disable tuned": [
  null,
  "禁用 tuned 失败"
 ],
 "Failed to disable tuned profile": [
  null,
  "禁用调优的配置文件失败"
 ],
 "Failed to switch profile": [
  null,
  "切换配置集失败"
 ],
 "None": [
  null,
  "无"
 ],
 "Disable tuned": [
  null,
  "禁用 tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 启动失败"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned 是一个监控您的系统并优化某些工作负载性能的服务。Tuned 的核心是配置集（profile），使用它为不同的用例调整您的系统。"
 ],
 "Change performance profile": [
  null,
  "变更性能配置"
 ],
 "Change profile": [
  null,
  "变更配置"
 ],
 "Edit /etc/motd": [
  null,
  "编辑 /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "保存 /etc/motd 中的更改失败"
 ],
 "Save changes": [
  null,
  "保存更改"
 ],
 "Edit motd": [
  null,
  "编辑 motd"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Bad setting": [
  null,
  "错误设置"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Merged": [
  null,
  "合并"
 ],
 "Running": [
  null,
  "正在运行"
 ],
 "Reloading": [
  null,
  "重新加载中"
 ],
 "Not running": [
  null,
  "未运行"
 ],
 "Failed to start": [
  null,
  "启动失败"
 ],
 "Maintenance": [
  null,
  "维护"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Linked": [
  null,
  "已链接"
 ],
 "Alias": [
  null,
  "别名"
 ],
 "Masked": [
  null,
  "已屏蔽"
 ],
 "Static": [
  null,
  "静态"
 ],
 "Invalid": [
  null,
  "无效"
 ],
 "Indirect": [
  null,
  "间接的"
 ],
 "Generated": [
  null,
  "生成的"
 ],
 "Transient": [
  null,
  "短暂的"
 ],
 "Bad": [
  null,
  "错误"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "订阅 systemd 信号失败：$0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "连接到 dbus 失败：$0"
 ],
 "Listing units failed: $0": [
  null,
  "列出单元失败：$0"
 ],
 "$0 service has failed": [
  null,
  "$0 个系统服务故障"
 ],
 "Loading of units failed": [
  null,
  "单元加载失败"
 ],
 "Loading...": [
  null,
  "加载中……"
 ],
 "Listing units": [
  null,
  "列出单元"
 ],
 "Filter by name or description": [
  null,
  "根据名称或描述进行过滤"
 ],
 "Active state": [
  null,
  "启动状态"
 ],
 "File state": [
  null,
  "文件状态"
 ],
 "$0 filters applied": [
  null,
  "已应用 $0 个筛选条件"
 ],
 "User": [
  null,
  "用户"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "用户 $0 没有权限修改 cpu 安全缓解方案设置"
 ],
 "Mitigations": [
  null,
  "缓解"
 ],
 "Version": [
  null,
  "版本"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS 版本"
 ],
 "BIOS date": [
  null,
  "BIOS 日期"
 ],
 "CPU security": [
  null,
  "CPU安全性"
 ],
 "Disable simultaneous multithreading": [
  null,
  "禁用同步多线程"
 ],
 "Read more...": [
  null,
  "读取更多..."
 ],
 "Save and reboot": [
  null,
  "保存并重启"
 ],
 "CPU security toggles": [
  null,
  "CPU安全性开关"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "基于软件的临时解决方案可以帮助防止 CPU 安全问题。这些缓解方案会对性能有一定影响。改变这些设置可能会存在风险。"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "等级"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "内存技术"
 ],
 "Size": [
  null,
  "大小"
 ],
 "State": [
  null,
  "状态"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "查看内存信息需要管理访问权限。"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "Failed to fetch logs": [
  null,
  "获取日志失败"
 ],
 "Clear all filters": [
  null,
  "清除所有过滤规则"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "使用当前的过滤器组合找不到任何日志。"
 ],
 "No logs found": [
  null,
  "没有找到日志"
 ],
 "Load earlier entries": [
  null,
  "载入更早条目"
 ],
 "You may try to load older entries.": [
  null,
  "您可以尝试加载较早的条目。"
 ],
 "Allow running (unmask)": [
  null,
  "启用服务 (unmask)"
 ],
 "Reload": [
  null,
  "重载"
 ],
 "Restart": [
  null,
  "重启"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Clear 'Failed to start'": [
  null,
  "清除 'Failed to start'"
 ],
 "Mask service": [
  null,
  "屏蔽服务"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "屏蔽服务会阻止所有依赖它的单元运行，其影响可能比预期更大。请确认您要屏蔽这个单元。"
 ],
 "Disallow running (mask)": [
  null,
  "不允许运行 (屏蔽)"
 ],
 "Unpin unit": [
  null,
  "未固定单元"
 ],
 "Pin unit": [
  null,
  "固定单元"
 ],
 "Additional actions": [
  null,
  "额外操作"
 ],
 "Note": [
  null,
  "注意"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "该单元没有设计为需要明确启用。"
 ],
 "Forbidden from running": [
  null,
  "禁止运行"
 ],
 "Start service": [
  null,
  "启动服务"
 ],
 "Active since ": [
  null,
  "完成启动时间： "
 ],
 "Required by ": [
  null,
  "要求自 "
 ],
 "Read-only": [
  null,
  "只读"
 ],
 "Requires administration access to edit": [
  null,
  "需要管理访问权限进行编辑"
 ],
 "Automatically starts": [
  null,
  "自动启动"
 ],
 "Updating status...": [
  null,
  "更新状态 ..."
 ],
 "Stop and disable": [
  null,
  "停止并禁用"
 ],
 "Start and enable": [
  null,
  "开始并启用"
 ],
 "Failed to load unit": [
  null,
  "加载单元失败"
 ],
 "View all services": [
  null,
  "查看所有服务"
 ],
 "Triggers": [
  null,
  "触发器"
 ],
 "Triggered by": [
  null,
  "触发于"
 ],
 "Requires": [
  null,
  "要求"
 ],
 "Requisite": [
  null,
  "必要"
 ],
 "Wants": [
  null,
  "需要"
 ],
 "Binds to": [
  null,
  "绑定到"
 ],
 "Part of": [
  null,
  "部分"
 ],
 "Required by": [
  null,
  "要求的"
 ],
 "Requisite of": [
  null,
  "必备的"
 ],
 "Wanted by": [
  null,
  "需要于"
 ],
 "Bound by": [
  null,
  "绑定于"
 ],
 "Consists of": [
  null,
  "组成"
 ],
 "Conflicts": [
  null,
  "冲突"
 ],
 "Conflicted by": [
  null,
  "冲突"
 ],
 "Before": [
  null,
  "前于"
 ],
 "After": [
  null,
  "后于"
 ],
 "On failure": [
  null,
  "失败时"
 ],
 "Propagates reload to": [
  null,
  "传播重新加载到"
 ],
 "Reload propagated from": [
  null,
  "重新加载的传播来自"
 ],
 "Joins namespace of": [
  null,
  "加入命名空间"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 不满足"
 ],
 "Deletion will remove the following files:": [
  null,
  "删除操作会删除以下文件："
 ],
 "Pinned unit": [
  null,
  "固定单元"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Path": [
  null,
  "路径"
 ],
 "Listen": [
  null,
  "监听"
 ],
 "Container": [
  null,
  "容器"
 ],
 "View Podman container": [
  null,
  "查看 Podman 容器"
 ],
 "Condition failed": [
  null,
  "条件失败"
 ],
 "Show more relationships": [
  null,
  "显示更多关系"
 ],
 "Show relationships": [
  null,
  "显示关系"
 ],
 "Confirm deletion of $0": [
  null,
  "确认删除 $0"
 ],
 "Timer deletion failed": [
  null,
  "计时器删除失败"
 ],
 "Targets": [
  null,
  "目标"
 ],
 "Sockets": [
  null,
  "插槽"
 ],
 "Timers": [
  null,
  "计时器"
 ],
 "Paths": [
  null,
  "路径"
 ],
 "Go to $0": [
  null,
  "前往 $0"
 ],
 "Journal entry not found": [
  null,
  "未找到日志条目"
 ],
 "Journal entry": [
  null,
  "日志条目"
 ],
 "Entry at $0": [
  null,
  "于 $0 的条目"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "Loading unit failed": [
  null,
  "加载单元失败"
 ],
 "Service logs": [
  null,
  "服务日志"
 ],
 "No log entries": [
  null,
  "无日志条目"
 ],
 "Systemd units": [
  null,
  "Systemd 单元"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "没有结果符合过滤条件。清除所有过滤器以显示结果。"
 ],
 "Does not automatically start": [
  null,
  "不自动启动"
 ],
 "Cannot be enabled": [
  null,
  "无法被启用"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web 控制台正运行于限制访问模式。"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一款服务器管理工具，可让您通过 Web 浏览器轻松管理 Linux 服务器。在终端和 Web 界面之间切换毫无障碍。通过 Cockpit 启动的服务也可以在终端中停止。同样，如果终端中出现错误，也可以在 Cockpit 的日志界面中看到。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常适合新的系统管理员使用，让他们能够轻松完成存储管理、查看日志以及启动和停止服务等简单任务。您可以同时监控和管理多台服务器。只需单击一下即可添加服务器，让这些主机协同工作。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、组合、VLAN 和防火墙等。NetworkManager 与 Ubuntu 默认的 systemd-networkd 以及 Debian 的 ifupdown 脚本不兼容。"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具用于配置 SELinux 策略，并可帮助理解和解决策略违规问题。"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具用于将系统配置为写入内核崩溃转储。它支持“local”（磁盘）、“ssh” 和“nfs” 转储目标。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "来自 $1 上的 $0"
 ],
 "from <host>\u0004from $0": [
  null,
  "来自 $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "在 $0 上"
 ],
 "dialog-title\u0004Domain": [
  null,
  "域"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "加入域"
 ]
});
