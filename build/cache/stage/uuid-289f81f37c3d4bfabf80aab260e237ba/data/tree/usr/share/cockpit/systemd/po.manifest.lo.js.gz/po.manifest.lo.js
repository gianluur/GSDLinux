cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "ບັນດາບໍລິການ"
 ],
 "Terminal": [
  null,
  "ເທີມີນໍ (Terminal)"
 ],
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Overview": [
  null,
  "ພາບລວມ"
 ],
 "Logs": [
  null,
  "ບັນທຶກລັອກ"
 ],
 "time": [
  null,
  "ເວລາ"
 ],
 "date": [
  null,
  "ວັນທີ"
 ],
 "restart": [
  null,
  "ເລີ່ມຕົ້ນໃໝ່"
 ],
 "shut": [
  null,
  "ປິດ"
 ],
 "domain": [
  null,
  "ໂດເມນ"
 ],
 "machine": [
  null,
  "ເຄື່ອງ"
 ],
 "operating system": [
  null,
  "ລະບົບປະຕິບັດການ"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "ແທັກສິນຊັບ"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "ພະລັງງານ"
 ],
 "version": [
  null,
  "ເວີຊັນ"
 ],
 "host": [
  null,
  "ໂຮສຕ໌"
 ],
 "hardware": [
  null,
  "ຮາດແວ"
 ],
 "mitigation": [
  null,
  "ການຜ່ອນເບົາ"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "ໜ່ວຍຄວາມຈຳ"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ແຣມ (ram)"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "ຊີຣຽວ"
 ],
 "graphs": [
  null,
  "ກຣາບ"
 ],
 "metrics": [
  null,
  "ເມທຣິກ (metrics)"
 ],
 "history": [
  null,
  "ປະຫວັດ"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "ດິດ"
 ],
 "network": [
  null,
  "ເຄືອຂ່າຍ"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "ປະສິດທິພາບ"
 ],
 "Configuring system settings": [
  null,
  "ກຳລັງຕັ້ງຄ່າລະບົບ"
 ],
 "service": [
  null,
  "ບໍລິການ"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ເປົ້າໝາຍ"
 ],
 "socket": [
  null,
  "ຊັອກເກັດ"
 ],
 "timer": [
  null,
  "ຕົວຕັ້ງເວລາ"
 ],
 "path": [
  null,
  "ເສັ້ນທາງ (path)"
 ],
 "unit": [
  null,
  "unit"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "ບູດ"
 ],
 "mask": [
  null,
  "ມາກ (mask)"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "ເປີດໃຊ້ງານ"
 ],
 "disable": [
  null,
  "ປິດໃຊ້ງານ"
 ],
 "Managing services": [
  null,
  "ການຈັດການບໍລິການ"
 ],
 "journal": [
  null,
  "ບັນທຶກ (journal)"
 ],
 "warning": [
  null,
  "ຄຳເຕືອນ"
 ],
 "error": [
  null,
  "ຂໍ້ຜິດພາດ"
 ],
 "debug": [
  null,
  "ດີບັກ (debug)"
 ],
 "crash": [
  null,
  "ຄຣັຊ"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "ກຳລັງກວດສອບບັນທຶກເຫດການ"
 ],
 "console": [
  null,
  "ຄອນໂຊລ"
 ],
 "command": [
  null,
  "ຄຳສັ່ງ"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "ເຊວ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
