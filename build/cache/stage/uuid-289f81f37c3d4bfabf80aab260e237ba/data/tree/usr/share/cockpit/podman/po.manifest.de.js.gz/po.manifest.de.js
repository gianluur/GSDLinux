cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-Container"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "Container"
 ],
 "image": [
  null,
  "Image"
 ]
});
