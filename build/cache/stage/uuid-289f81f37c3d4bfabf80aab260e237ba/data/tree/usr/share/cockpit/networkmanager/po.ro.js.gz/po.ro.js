cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Schimbarea cheilor este adesea rezultatul reinstalării sistemului de operare. Cu toate acestea, o schimbare neașteptată poate indica o încercare a unei terțe părți de a vă intercepta conexiunea."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pentru a vă asigura că conexiunea dumneavoastră nu este interceptată de o terță parte rău intenționată, vă rugăm să verificați amprenta cheii gazdei:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Conectează-te"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Servicii"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Firewall": [
  null,
  "Paravan de protecție"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Copy": [
  null,
  "Copiază"
 ],
 "Copied": [
  null,
  "Copiat"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Details": [
  null,
  "Detalii"
 ],
 "Public key": [
  null,
  "Cheie publică"
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Edit": [
  null,
  "Editare"
 ],
 "Select": [
  null,
  "Selectează"
 ],
 "Unexpected error": [
  null,
  "Eroare neașteptată"
 ],
 "No results found": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nu este instalat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Pe $0 nu este instalată o versiune compatibilă a Cockpit."
 ],
 "Connect": [
  null,
  "Conectare"
 ],
 "Add": [
  null,
  "Adaugă"
 ],
 "$0 key changed": [
  null,
  "Cheia $0 a fost schimbată"
 ],
 "Trust and add host": [
  null,
  "Am încredere, adaugă gazda"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pentru a verifica o amprentă digitală, executați următoarea comandă pe $0, fie fizic, de la mașină, fie printr-o rețea de încredere:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Dacă amprenta digitală se potrivește, faceți clic pe „Am încredere, adaugă gazda”. În caz contrar, nu vă conectați și contactați administratorul."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică. Dacă îi ceri altcuiva să efectueze verificarea în locul tău, acea persoană îți poate trimite rezultatele prin orice metodă."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vă conectați la $0 pentru prima dată."
 ],
 "Verify fingerprint": [
  null,
  "Verifică amprenta digitală"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Executați această comandă într-o rețea de încredere sau direct pe mașina la distanță:"
 ],
 "The fingerprint should match:": [
  null,
  "Amprenta digitală trebuie să se potrivească:"
 ],
 "The password can not be empty": [
  null,
  "Parola nu poate fi goală"
 ],
 "The key password can not be empty": [
  null,
  "Parola cheii nu poate fi goală"
 ],
 "The key passwords do not match": [
  null,
  "Parolele cheii nu se potrivesc"
 ],
 "Log in to $0": [
  null,
  "Conectează-te la $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nu se poate efectua autentificarea la $0. Gazda nu acceptă autentificarea cu parolă și niciuna dintre cheile dvs. SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată de o parolă, iar serverul nu permite autentificarea cu o parolă. Vă rugăm să introduceți parola cheii la $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată. Vă puteți autentifica fie folosind parola de acces, fie introducând parola cheii la $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Creează o nouă cheie SSH și-o autorizează"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se va crea o nouă cheie SSH la $0 pentru $1 pe $2, iar aceasta va fi adăugată la fișierul $3 al lui $4 pe $5."
 ],
 "Key password": [
  null,
  "Parola cheii"
 ],
 "Confirm key password": [
  null,
  "Confirmă parola cheii"
 ],
 "Authorize SSH key": [
  null,
  "Autorizează cheia SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Cheia SSH $0 din $1 de pe $2 va fi adăugată la fișierul $3 din $4 de pe $5."
 ],
 "Authentication": [
  null,
  "Autentificare"
 ],
 "SSH key": [
  null,
  "Cheie SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Cheia SSH $0 va fi disponibilă pe durata restului sesiunii și va putea fi utilizată și pentru conectarea la alte gazde."
 ],
 "Disconnected": [
  null,
  "Deconectat"
 ],
 "Permission denied": [
  null,
  "Permisiune refuzată"
 ],
 "Clear input value": [
  null,
  "Șterge valoarea introdusă"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de dată incorect și format de oră incorect"
 ],
 "Invalid time format": [
  null,
  "Format de oră nevalid"
 ],
 "Invalid date format": [
  null,
  "Format de dată incorect"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nu se poate planifica un eveniment în trecut"
 ],
 "No delay": [
  null,
  "Fără întârziere"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minute"
 ],
 "20 minutes": [
  null,
  "20 de minute"
 ],
 "40 minutes": [
  null,
  "40 de minute"
 ],
 "60 minutes": [
  null,
  "60 de minute"
 ],
 "Specific time": [
  null,
  "Momentul specificat"
 ],
 "Shut down": [
  null,
  "Oprire"
 ],
 "Reboot": [
  null,
  "Repornire"
 ],
 "Message to logged in users": [
  null,
  "Mesaj pentru utilizatorii autentificați"
 ],
 "Delay": [
  null,
  "Întârziere"
 ],
 "Pick date": [
  null,
  "Alegeți data"
 ],
 "Toggle date picker": [
  null,
  "Activează/dezactivează selectorul de dată"
 ],
 "Synchronized": [
  null,
  "Sincronizat"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizat cu $0"
 ],
 "Synchronizing": [
  null,
  "Se sincronizează"
 ],
 "Trying to synchronize with $0": [
  null,
  "Se încearcă sincronizarea cu $0"
 ],
 "Not synchronized": [
  null,
  "Nu este sincronizat"
 ],
 "Log messages": [
  null,
  "Mesaje de jurnal"
 ],
 "NTP server": [
  null,
  "server NTP"
 ],
 "Manually": [
  null,
  "În mod manual"
 ],
 "Automatically using NTP": [
  null,
  "Utilizând NTP în mod automat"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizând în mod automat servere NTP suplimentare"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizând în mod automat servere NTP specifice"
 ],
 "Time zone": [
  null,
  "Fusul orar"
 ],
 "Set time": [
  null,
  "Ajustează ora"
 ],
 "Invalid timezone": [
  null,
  "Fus orar nevalid"
 ],
 "Need at least one NTP server": [
  null,
  "Este necesar cel puțin un server NTP"
 ],
 "Change system time": [
  null,
  "Schimbă ora sistemului"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Path to file": [
  null,
  "Ruta către fișier"
 ],
 "No such file or directory": [
  null,
  "Nu există un astfel de fișier sau director"
 ],
 "Create $0": [
  null,
  "Creează $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Află mai multe"
 ],
 "You now have administrative access.": [
  null,
  "Acum aveți acces de administrator."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nu sunt disponibile metode pentru a obține acces administrativ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentificați-vă pentru a obține acces administrativ"
 ],
 "Switch to administrative access": [
  null,
  "Treceți la acces administrativ"
 ],
 "Authenticate": [
  null,
  "Autentifica"
 ],
 "Administrative access": [
  null,
  "Acces administrativ"
 ],
 "Problem becoming administrator": [
  null,
  "Probleme în devenirea administrator"
 ],
 "Method": [
  null,
  "Metodă"
 ],
 "Limit access": [
  null,
  "Limitează accesul"
 ],
 "Switch to limited access": [
  null,
  "Treceți la acces limitat"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Modul de acces limitat restricționează privilegiile administrative. Anumite secțiuni ale consolei web vor avea funcționalități reduse."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Navigatorul dvs. va reține nivelul dvs. de acces între sesiuni."
 ],
 "Limited access": [
  null,
  "Acces limitat"
 ],
 "Turn on administrative access": [
  null,
  "Activează accesul de administrator"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ani",
  "$0 de ani"
 ],
 "$0 month": [
  null,
  "$0 lună",
  "$0 luni",
  "$0 de luni"
 ],
 "$0 week": [
  null,
  "$0 săptămână",
  "$0 săptămâni",
  "$0 de săptămâni"
 ],
 "$0 day": [
  null,
  "$0 zi",
  "$0 zile",
  "$0 de zile"
 ],
 "$0 hour": [
  null,
  "$0 oră",
  "$0 ore",
  "$0 de ore"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minute",
  "$0 de minute"
 ],
 "Go to now": [
  null,
  "Mergi la acum"
 ],
 "1 hour": [
  null,
  "1 oră"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 zi"
 ],
 "1 week": [
  null,
  "1 săptămână"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nu s-a putut activa $0 în firewalld"
 ],
 "Visit firewall": [
  null,
  "Accedeți la paravanul de protecție"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adaugă $0"
 ],
 "less than a minute ago": [
  null,
  "acum mai puțin de un minut"
 ],
 "in less than a minute": [
  null,
  "în mai puțin de un minut"
 ],
 "Password is too weak": [
  null,
  "Parola este prea slabă (este ușor de ghicit)"
 ],
 "Excellent password": [
  null,
  "Parolă excelentă"
 ],
 "Password is not acceptable": [
  null,
  "Parola nu este acceptabilă"
 ],
 "Strong password": [
  null,
  "Parolă puternică"
 ],
 "Acceptable password": [
  null,
  "Parolă acceptabilă"
 ],
 "Weak password": [
  null,
  "Parolă slabă (ușor de ghicit)"
 ],
 "Show password": [
  null,
  "Afișează parola"
 ],
 "Hide password": [
  null,
  "Ascunde parola"
 ],
 "password quality": [
  null,
  "calitatea parolei"
 ],
 "Show confirmation password": [
  null,
  "Afișează parola de confirmare"
 ],
 "Hide confirmation password": [
  null,
  "Ascunde parola de confirmare"
 ],
 "Additional packages:": [
  null,
  "Pachete suplimentare:"
 ],
 "Removals:": [
  null,
  "Eliminare:"
 ],
 "Total size: $0": [
  null,
  "Dimensiunea totală: $0"
 ],
 "Install software": [
  null,
  "Instalează software-ul"
 ],
 "$0 will be installed.": [
  null,
  "$0 va fi instalat."
 ],
 "Install": [
  null,
  "Instalează"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Se așteaptă finalizarea altor operații de gestionare a software-ului"
 ],
 "Checking installed software": [
  null,
  "Se verifică software-ul instalat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nu este disponibil din niciun depozit."
 ],
 "Downloading $0": [
  null,
  "Se descarcă $0"
 ],
 "Removing $0": [
  null,
  "Se elimină $0"
 ],
 "Installing $0": [
  null,
  "Se instalează $0"
 ],
 "Unknown host: $0": [
  null,
  "Gazdă necunoscută: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nu se poate efectua autentificarea la $0 folosind autentificarea cu cheie SSH. Vă rugăm să introduceți parola."
 ],
 "SSH key login": [
  null,
  "Autentificare cu cheie SSH"
 ],
 "[no data]": [
  null,
  "[nu există date]"
 ],
 "[binary data]": [
  null,
  "[date binare]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit s-a prăbușit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a raportat codul de eroare $0"
 ],
 "show less": [
  null,
  "afișează mai puțin"
 ],
 "show more": [
  null,
  "afișează mai mult"
 ],
 "Row expansion": [
  null,
  "Extinderea rândului"
 ],
 "Row select": [
  null,
  "Selectare rând"
 ],
 "Ctrl+Insert": [
  null,
  "«Ctrl+Insert»"
 ],
 "Paste": [
  null,
  "Lipește"
 ],
 "Shift+Insert": [
  null,
  "«Shift+Insert»"
 ],
 "Paste error": [
  null,
  "Eroare la lipire"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Navigatorul dvs. nu permite lipirea din meniul contextual. Puteți folosi combinația de taste «Shift+Insert»."
 ],
 "Error during initialization": [
  null,
  "Eroare în timpul inițializării"
 ],
 "Failed": [
  null,
  "Nu a funcționat"
 ],
 "Home": [
  null,
  "Acasă"
 ],
 "Downloads": [
  null,
  "Descărcări"
 ],
 "Not a directory": [
  null,
  "Nu este un director"
 ],
 "All files": [
  null,
  "Toate fișierele"
 ],
 "Recent": [
  null,
  "Recente"
 ],
 "No recent directories": [
  null,
  "Nu există directoare recente"
 ],
 "No recent files": [
  null,
  "Nu există fișiere recente"
 ],
 "Type to filter": [
  null,
  "Tastați pentru a filtra"
 ],
 "File chooser actions": [
  null,
  "Acțiuni ale selectorului de fișiere"
 ],
 "Open in file browser": [
  null,
  "Deschide în exploratorul de fișiere"
 ],
 "Hide hidden files": [
  null,
  "Ascunde elementele ascunse"
 ],
 "Show hidden files": [
  null,
  "Afișează fișierele ascunse"
 ],
 "Filesystem": [
  null,
  "Sistem de fișiere"
 ],
 "Clear filters": [
  null,
  "Șterge filtrele"
 ],
 "Directory is empty": [
  null,
  "Directorul este gol"
 ],
 "Directory has no sub-directories": [
  null,
  "Directorul nu conține subdirectoare"
 ],
 "This directory contains only hidden files": [
  null,
  "Acest director conține doar fișiere ascunse"
 ],
 "No matching results": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Folder": [
  null,
  "Dosar"
 ],
 "File": [
  null,
  "Fișier"
 ],
 "Copy to clipboard": [
  null,
  "Copiază în clipboard"
 ],
 "Automation script": [
  null,
  "Script de automatizare"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Creează un fișier de sarcini nou cu acest conținut."
 ],
 "Ansible roles documentation": [
  null,
  "Documentația privind rolurile Ansible"
 ],
 "Shell script": [
  null,
  "script Shell"
 ],
 "No system modifications": [
  null,
  "Nicio modificare a sistemului"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Utilizatorul conectat nu are permisiunea de a vizualiza modificările aduse sistemului"
 ],
 "Loading system modifications...": [
  null,
  "Se încarcă modificările aduse sistemului..."
 ],
 "View automation script": [
  null,
  "Vizualizează scriptul de automatizare"
 ],
 "Occurrences": [
  null,
  "Apariții"
 ],
 "View all logs": [
  null,
  "Vizualizează toate jurnalele"
 ],
 "Other": [
  null,
  "Alta"
 ],
 "Unknown": [
  null,
  "Necunoscută"
 ],
 "Desktop": [
  null,
  "Calculator de birou"
 ],
 "Low profile desktop": [
  null,
  "Calculator de birou cu profil redus"
 ],
 "Pizza box": [
  null,
  "„Pizza box”"
 ],
 "Mini tower": [
  null,
  "Mini turn"
 ],
 "Tower": [
  null,
  "Turn"
 ],
 "Portable": [
  null,
  "Portabil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispozitiv de buzunar"
 ],
 "Docking station": [
  null,
  "Stație de andocare"
 ],
 "All-in-one": [
  null,
  "Toate într-unul"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Calculator compact"
 ],
 "Lunch box": [
  null,
  "„Lunch box”"
 ],
 "Main server chassis": [
  null,
  "Șasiul serverului principal"
 ],
 "Expansion chassis": [
  null,
  "Șasiu de expansiune"
 ],
 "Sub-Chassis": [
  null,
  "Sub-șasiu"
 ],
 "Bus expansion chassis": [
  null,
  "Șasiu de expansiune de magistrală"
 ],
 "Peripheral chassis": [
  null,
  "Șasiu periferic"
 ],
 "RAID chassis": [
  null,
  "Șasiu RAID"
 ],
 "Rack mount chassis": [
  null,
  "Șasiu de montare în rack"
 ],
 "Sealed-case PC": [
  null,
  "PC cu carcasă sigilată"
 ],
 "Multi-system chassis": [
  null,
  "Șasiu multi-sistem"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avansat"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Servitor blade (lamă)"
 ],
 "Tablet": [
  null,
  "Tabletă"
 ],
 "Convertible": [
  null,
  "Convertibil"
 ],
 "Detachable": [
  null,
  "Detașabil (amovibil)"
 ],
 "IoT gateway": [
  null,
  "Poartă de acces IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrat"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 Gio"
 ],
 "Single rank": [
  null,
  "Rang unic"
 ],
 "Dual rank": [
  null,
  "Rang dual"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Prezent"
 ],
 "Old password not accepted": [
  null,
  "Vechea parolă nu este acceptată"
 ],
 "Failed to change password": [
  null,
  "Schimbarea parolei a eșuat"
 ],
 "New password was not accepted": [
  null,
  "Noua parolă nu a fost acceptată"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "A expirat timpul de așteptare pentru generarea cheii prin ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Nu este o cheie privată validă"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A expirat timpul de așteptare pentru adăugarea prin ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisiuni de fișier nevalide"
 ],
 "Password not accepted": [
  null,
  "Parola nu este acceptată"
 ],
 "Select an option": [
  null,
  "Selectați o opțiune"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 a fost omorât cu semnalul $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 a ieșit cu codul $1"
 ],
 "$0 failed": [
  null,
  "$0 a eșuat"
 ],
 "Your session has been terminated.": [
  null,
  "Sesiunea dumneavoastră a fost încheiată."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesiunea dumneavoastră a expirat. Vă rugăm să vă autentificați din nou."
 ],
 "Not permitted to perform this action.": [
  null,
  "Nu este permisă efectuarea acestei acțiuni."
 ],
 "Login failed": [
  null,
  "Autentificare eșuată"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serverul a refuzat autentificarea prin orice metodă acceptată."
 ],
 "Untrusted host": [
  null,
  "Gazdă nesigură (nu este de încredere)"
 ],
 "Host key is incorrect": [
  null,
  "Cheia gazdei este incorectă"
 ],
 "Internal error": [
  null,
  "Eroare internă"
 ],
 "Connection has timed out.": [
  null,
  "Timpul de conectare a expirat."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nu este instalat în sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Nu se pot transmite datele de autentificare"
 ],
 "Server has closed the connection.": [
  null,
  "Serverul a închis conexiunea."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nu este compatibil cu software-ul din sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nu a putut stabili legătura cu gazda specificată."
 ],
 "Too much data": [
  null,
  "Prea multe date"
 ],
 "Priority": [
  null,
  "Prioritate"
 ],
 "Description": [
  null,
  "Descriere"
 ],
 "Save": [
  null,
  "Salvează"
 ],
 "edit": [
  null,
  "editează"
 ],
 "None": [
  null,
  "Niciuna"
 ],
 "Enabled": [
  null,
  "Activat"
 ],
 "Disabled": [
  null,
  "Dezactivat"
 ],
 "Generated": [
  null,
  "Generat"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Șterge"
 ],
 "Start service": [
  null,
  "Pornire serviciu"
 ],
 "Status": [
  null,
  "Starea"
 ],
 "Delete $0": [
  null,
  "Șterge $0"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Actions": [
  null,
  "Acțiuni"
 ],
 "Options": [
  null,
  "Opțiuni"
 ],
 "Not available": [
  null,
  "Nu este disponibil"
 ],
 "Ignore": [
  null,
  "Ignoră"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Preserve": [
  null,
  "Păstrează"
 ],
 "Random": [
  null,
  "Aleator"
 ],
 "Stable": [
  null,
  "Stabilă"
 ],
 "Use $0": [
  null,
  "Utilizează $0"
 ],
 "Failed to save settings": [
  null,
  "Nu s-au putut salva configurările"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Crearea acestui $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Create it": [
  null,
  "Creează-l"
 ],
 "Invalid prefix $0": [
  null,
  "Prefix nevalid $0"
 ],
 "Invalid metric $0": [
  null,
  "Metrică nevalidă $0"
 ],
 "Invalid address $0": [
  null,
  "Adresă nevalidă $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefix sau mască de rețea nevalidă $0"
 ],
 "Testing connection": [
  null,
  "Testarea conexiunii"
 ],
 "Restoring connection": [
  null,
  "Se restaurează dconexiunea"
 ],
 "Troubleshoot…": [
  null,
  "Soluționare probleme…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager nu rulează"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager nu este instalat"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Dispozitivele de rețea și graficele necesită NetworkManager"
 ],
 "Enable service": [
  null,
  "Activează serviciul"
 ],
 "Network interface '$0' not found": [
  null,
  "Interfața de rețea „$0” nu a fost găsită"
 ],
 "Return to overview page": [
  null,
  "Înapoi la pagina de prezentare generală"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nu aveți permisiunea de a modifica paravanul de protecție."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nu aveți permisiunea de a dezactiva paravanul de protecție"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nu aveți permisiunea de a activa paravanul de protecție"
 ],
 "Disable the firewall": [
  null,
  "Dezactivează paravanul de protecție"
 ],
 "Enable the firewall": [
  null,
  "Activează paravanul de protecție"
 ],
 "Edit service $0": [
  null,
  "Editează serviciul $0"
 ],
 "Remove service $0": [
  null,
  "Elimină serviciul $0"
 ],
 "Included Services": [
  null,
  "Servicii incluse"
 ],
 "Additional port": [
  null,
  "Port suplimentar"
 ],
 "Remove additional port": [
  null,
  "Elimină portul suplimentar"
 ],
 "Remove zone $0": [
  null,
  "Elimină zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Adaugă servicii la zona $0"
 ],
 "Add services": [
  null,
  "Adaugă servicii"
 ],
 "Service": [
  null,
  "Serviciu"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "zona $0"
 ],
 "Interface": [
  null,
  "Interfață",
  "Interfețe",
  "Interfețe"
 ],
 "Allowed addresses": [
  null,
  "Adrese permise"
 ],
 "Entire subnet": [
  null,
  "Întreaga subrețea"
 ],
 "There are no active services in this zone": [
  null,
  "Nu există servicii active în această zonă"
 ],
 "Filter services": [
  null,
  "Filtrează serviciile"
 ],
 "Failed to edit service": [
  null,
  "Editarea serviciului a eșuat"
 ],
 "Failed to add port": [
  null,
  "Adăugarea portului a eșuat"
 ],
 "Failed to add service": [
  null,
  "Adăugarea serviciului a eșuat"
 ],
 "Unknown service name": [
  null,
  "Nume de serviciu necunoscut"
 ],
 "Invalid port number": [
  null,
  "Număr de port nevalid"
 ],
 "Invalid range": [
  null,
  "Interval nevalid"
 ],
 "Range must be strictly ordered": [
  null,
  "Intervalul trebuie să fie ordonat strict"
 ],
 "Edit service": [
  null,
  "Editează serviciul"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Editează serviciul personalizat în zona $0"
 ],
 "Add ports": [
  null,
  "Adaugă porturi"
 ],
 "Add ports to $0 zone": [
  null,
  "Adaugă porturi la zona $0"
 ],
 "Add services to $0 zone": [
  null,
  "Adaugă servicii la zona $0"
 ],
 "Custom ports": [
  null,
  "Porturi personalizate"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemplu: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Sunt acceptate porturi, intervale și servicii separate prin virgule"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemplu: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Dacă câmpul este lăsat necompletat, ID-ul va fi generat pe baza serviciilor asociate porturilor și a numerelor de port"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Adăugarea porturilor personalizate va reinițializa firewalld. O reinițializare va duce la pierderea oricărei configurații valabile doar pe durata rulării!"
 ],
 "Failed to add zone": [
  null,
  "Adăugarea zonei a eșuat"
 ],
 "Add zone": [
  null,
  "Adăugă zonă"
 ],
 "Trust level": [
  null,
  "Nivel de încredere"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sortate de la cele mai puțin de încredere la cele mai de încredere"
 ],
 "Custom zones": [
  null,
  "Zone personalizate"
 ],
 "No description available": [
  null,
  "Nu există nicio descriere disponibilă"
 ],
 "Included services": [
  null,
  "Servicii incluse"
 ],
 "The cockpit service is automatically included": [
  null,
  "Serviciul de cockpit este inclus automat"
 ],
 "Interfaces": [
  null,
  "Interfețe"
 ],
 "Range": [
  null,
  "Interval"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adresă IP cu prefix de direcționare. Separați valorile multiple prin virgule. Exemplu: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmă eliminarea lui $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Această zonă conține serviciul «cockpit». Asigurați-vă că această zonă nu se aplică conexiunii dvs. actuale la consola web."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Eliminarea zonei va duce la eliminarea tuturor serviciilor din cadrul acesteia."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Eliminarea serviciului cockpit poate duce la imposibilitatea accesării consolei web. Asigurați-vă că această zonă nu se aplică conexiunii dvs. actuale la consola web."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Elimină serviciul $0 din zona $1"
 ],
 "Firewall is not available": [
  null,
  "Paravanul de protecție nu este disponibil"
 ],
 "Please install the $0 package": [
  null,
  "Instalați pachetul de $0"
 ],
 "Add a new zone": [
  null,
  "Adaugă o zonă nouă"
 ],
 "Add new zone": [
  null,
  "Adaugă o zonă nouă"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Solicitările primite sunt blocate în mod implicit. Solicitările trimise nu sunt blocate."
 ],
 "Connected": [
  null,
  "Conectat"
 ],
 "Wireless": [
  null,
  "Fără fir"
 ],
 "Wired": [
  null,
  "Cu fir"
 ],
 "No networks found": [
  null,
  "Nu s-au găsit rețele"
 ],
 "No interface selected": [
  null,
  "Nu a fost selectată nicio interfață"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "Selectați o interfață de rețea pentru a configura conexiunea."
 ],
 "SSID can not be empty": [
  null,
  "SSID-ul nu poate fi gol"
 ],
 "Password can not be empty": [
  null,
  "Parola nu poate fi goală"
 ],
 "Failed to connect": [
  null,
  "Nu s-a putut conecta"
 ],
 "Check your password.": [
  null,
  "Verificați-vă parola."
 ],
 "Connect to hidden network": [
  null,
  "Conectare la rețeaua ascunsă"
 ],
 "Connect to $0": [
  null,
  "Conectare la $0"
 ],
 "Network name": [
  null,
  "Numele rețelei"
 ],
 "Security": [
  null,
  "Securitate"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Ștergerea $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Pornirea $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Switch on $0": [
  null,
  "Pornește $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Oprirea $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Switch off $0": [
  null,
  "Oprește $0"
 ],
 "Bond": [
  null,
  "Legătură"
 ],
 "Team": [
  null,
  "Echipă"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Punte"
 ],
 "Unknown \"$0\"": [
  null,
  "„$0” necunoscută"
 ],
 "Carrier": [
  null,
  "Purtătoare"
 ],
 "Yes": [
  null,
  "Da"
 ],
 "No": [
  null,
  "Nu"
 ],
 "Inactive": [
  null,
  "Inactivă"
 ],
 "Unknown configuration": [
  null,
  "Configurație necunoscută"
 ],
 "Additional address $val": [
  null,
  "Adresă suplimentară $val"
 ],
 "Address $val": [
  null,
  "Adresă $val"
 ],
 "Gateway $gateway": [
  null,
  "Poarta de acces $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS suplimentar $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domenii de căutare DNS suplimentare $val"
 ],
 "DNS search domains $val": [
  null,
  "Domenii de căutare DNS $val"
 ],
 "General": [
  null,
  "Generale"
 ],
 "Connect automatically": [
  null,
  "Conectare automată"
 ],
 "Automatic": [
  null,
  "Automat"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Monitorizarea ARP"
 ],
 "Broken configuration": [
  null,
  "Configurație defectuoasă"
 ],
 "Team port": [
  null,
  "Portul echipei"
 ],
 "Spanning tree protocol": [
  null,
  "STP (Spanning tree protocol)"
 ],
 "Priority $priority": [
  null,
  "Prioritate $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Întârzierea de redirecționare $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Salut, timp $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Vechimea maximă a mesajului $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Costul rutei $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Modul „hairpin”"
 ],
 "Bridge port": [
  null,
  "Portul punții"
 ],
 "Parent $parent": [
  null,
  "Părinte $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Parola rețelei nu este salvată. Vă rugăm să vă deconectați și să vă reconectați la această rețea."
 ],
 "Failed to connect to $0": [
  null,
  "Conectarea la $0 a eșuat"
 ],
 "secured": [
  null,
  "securizat"
 ],
 "open": [
  null,
  "deschisă"
 ],
 "Last connected: $0": [
  null,
  "Ultima dată conectat: $0"
 ],
 "Signal strength": [
  null,
  "Intensitatea semnalului"
 ],
 "Not permitted to disconnect network": [
  null,
  "Nu este permisă deconectarea de la rețea"
 ],
 "Disconnect": [
  null,
  "Deconectare"
 ],
 "Not permitted to connect to network": [
  null,
  "Nu este permisă conectarea la rețea"
 ],
 "Forget": [
  null,
  "Uită"
 ],
 "$0 hidden network": [
  null,
  "$0 rețea ascunsă",
  "$0 rețele ascunse",
  "$0 de rețele ascunse"
 ],
 "Filter": [
  null,
  "Filtru"
 ],
 "Refresh": [
  null,
  "Actualizare"
 ],
 "Available networks": [
  null,
  "Rețele disponibile"
 ],
 "Network": [
  null,
  "Rețea"
 ],
 "Mode": [
  null,
  "Mod"
 ],
 "Signal": [
  null,
  "Semnal"
 ],
 "Rate": [
  null,
  "Rata"
 ],
 "Primary action": [
  null,
  "Acțiunea primară"
 ],
 "Secondary actions": [
  null,
  "Acțiuni scundare"
 ],
 "Not permitted to configure network devices": [
  null,
  "Nu este permisă configurarea dispozitivelor de rețea"
 ],
 "Enable or disable the device": [
  null,
  "Activează sau dezactivează dispozitivul"
 ],
 "This device cannot be managed here.": [
  null,
  "Acest dispozitiv nu poate fi gestionat aici."
 ],
 "Connection will be lost": [
  null,
  "Conexiunea va fi pierdută"
 ],
 "Keep connection": [
  null,
  "Menține conexiunea"
 ],
 "Invalid IP address: $0": [
  null,
  "Adresă IP nevalidă: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Adresă de destinație nevalidă: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Adresă de poartă de acces nevalidă: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Adresă DNS nevalidă: $0"
 ],
 "Preparing": [
  null,
  "Se pregătește"
 ],
 "Configuring": [
  null,
  "Se configurează"
 ],
 "Authenticating": [
  null,
  "Se autentifică"
 ],
 "Configuring IP": [
  null,
  "Se configurează adresa IP"
 ],
 "Checking IP": [
  null,
  "Se verifică adresa IP"
 ],
 "Waiting": [
  null,
  "Se așteaptă"
 ],
 "Active": [
  null,
  "Activ"
 ],
 "Deactivating": [
  null,
  "Se dezactivează"
 ],
 "Adhoc": [
  null,
  "Ad-hoc"
 ],
 "Infra": [
  null,
  "Infra."
 ],
 "AP": [
  null,
  "Pct. acces"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Fără purtătoare"
 ],
 "Part of $0": [
  null,
  "Parte din $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Modificarea parametrilor va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Change the settings": [
  null,
  "Modifică parametrii"
 ],
 "Add bridge": [
  null,
  "Adaugă punte"
 ],
 "Edit bridge settings": [
  null,
  "Editează parametrii punții"
 ],
 "Ports": [
  null,
  "Porturi"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "Prioritate STP"
 ],
 "STP forward delay": [
  null,
  "Întârzierea de redirecționare STP"
 ],
 "STP hello time": [
  null,
  "Durata salutului STP"
 ],
 "STP maximum message age": [
  null,
  "Vechimea maximă a mesajului STP"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Copiere de rezervă activă"
 ],
 "Load balancing": [
  null,
  "Echilibrarea încărcării"
 ],
 "Broadcast": [
  null,
  "Difuzare"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Pasiv"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "Add team": [
  null,
  "Adaugă echipă"
 ],
 "Edit team settings": [
  null,
  "Editează parametrii echipei"
 ],
 "Runner": [
  null,
  "Executor"
 ],
 "Balancer": [
  null,
  "Echilibrator"
 ],
 "Primary": [
  null,
  "Primară"
 ],
 "Link watch": [
  null,
  "Urmărire legătură"
 ],
 "Link up delay": [
  null,
  "Întârzierea de conectare a legăturii"
 ],
 "Link down delay": [
  null,
  "Întârzierea de deconectare a legăturii"
 ],
 "Ping interval": [
  null,
  "Intervalul de ping"
 ],
 "Ping target": [
  null,
  "Țintă ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automat (doar DHCP)"
 ],
 "Link local": [
  null,
  "Legătură locală"
 ],
 "Manual": [
  null,
  "Manual"
 ],
 "Shared": [
  null,
  "Partajată"
 ],
 "Prefix length or netmask": [
  null,
  "Lungimea prefixului sau masca de rețea"
 ],
 "Prefix length": [
  null,
  "Lungimea prefixului"
 ],
 "IPv4 settings": [
  null,
  "Configurație IPv4"
 ],
 "IPv6 settings": [
  null,
  "Configurație IPv6"
 ],
 "Addresses": [
  null,
  "Adrese"
 ],
 "Select method": [
  null,
  "Selectați metoda"
 ],
 "Add address": [
  null,
  "Adaugă adresă"
 ],
 "Address": [
  null,
  "Adresă"
 ],
 "Remove item": [
  null,
  "Elimină elementul"
 ],
 "Gateway": [
  null,
  "Poartă de acces"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Adaugă un server DNS"
 ],
 "DNS search domains": [
  null,
  "Domenii de căutare DNS"
 ],
 "Add search domain": [
  null,
  "Adaugă domeniu de căutare"
 ],
 "Search domain": [
  null,
  "Domeniu de căutare"
 ],
 "Routes": [
  null,
  "Rute"
 ],
 "Add route": [
  null,
  "Adaugă rută"
 ],
 "Metric": [
  null,
  "Metrica"
 ],
 "Enter a valid MAC address": [
  null,
  "Introduceți o adresă MAC validă"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 rețea",
  "$0 rețele",
  "$0 de rețele"
 ],
 "Add VPN": [
  null,
  "Adaugă VPN"
 ],
 "Add bond": [
  null,
  "Adăugare legătură"
 ],
 "Add VLAN": [
  null,
  "Adaugă VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Editează regulile și zonele"
 ],
 "$0 active zone": [
  null,
  "$0 zonă activă",
  "$0 zone active",
  "$0 de zone active"
 ],
 "Managed interfaces": [
  null,
  "Interfețe gestionate"
 ],
 "IP address": [
  null,
  "Adresă IP"
 ],
 "Sending": [
  null,
  "Se trimite"
 ],
 "Receiving": [
  null,
  "Se primesc date"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfețe negestionate"
 ],
 "Network logs": [
  null,
  "Jurnale de rețea"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresele nu sunt formatate corect"
 ],
 "Invalid IP address '$0'": [
  null,
  "Adresă IP nevalidă „$0”"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Pachetul wireguard-tools nu este instalat"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Partenerul #$0 are un punct final nevalid. Acesta trebuie specificat în formatul gazdă:port, de exemplu 1.2.3.4:51820, [2001:db8::1]:51820 sau example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Partenerul #$0 are un port de destinație nevalid. Portul trebuie să fie un număr."
 ],
 "Listen port must be a number": [
  null,
  "Portul de ascultare trebuie să fie un număr"
 ],
 "Add WireGuard VPN": [
  null,
  "Adaugă WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Editează WireGuard VPN"
 ],
 "Private key": [
  null,
  "Cheie privată"
 ],
 "Paste existing key": [
  null,
  "Lipește cheia existentă"
 ],
 "Regenerate": [
  null,
  "Regenerare"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Cheia publică va fi generată după introducerea unei chei private valide"
 ],
 "Listen port": [
  null,
  "Portul de ascultare"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Va fi stabilit la „Automat”"
 ],
 "IP addresses": [
  null,
  "Adrese IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Se pot specifica mai multe adrese folosind virgule sau spații ca delimitatori."
 ],
 "Peers": [
  null,
  "Parteneri"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Partenerii sunt alte mașini care se conectează la aceasta. Cheile publice ale celorlalte dispozitive vor fi partajate între ele."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Punctul final care funcționează ca un „server” trebuie specificat sub forma gazdă:port; în caz contrar, câmpul poate fi lăsat necompletat."
 ],
 "Add peer": [
  null,
  "Adaugă partener (peer)"
 ],
 "Endpoint": [
  null,
  "Punct final"
 ],
 "Allowed IPs": [
  null,
  "Adrese IP permise"
 ],
 "No peers added.": [
  null,
  "Nu s-au adăugat parteneri (peer)."
 ],
 "Edit VLAN settings": [
  null,
  "Editează parametrii VNC"
 ],
 "Parent": [
  null,
  "Părinte"
 ],
 "VLAN ID": [
  null,
  "ID VLAN"
 ],
 "Transmitting": [
  null,
  "Transmitere"
 ],
 "MTU must be a positive number": [
  null,
  "MTU trebuie să fie un număr pozitiv"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Set to": [
  null,
  "Ajustează la"
 ],
 "Team port settings": [
  null,
  "Parametrii portului echipei"
 ],
 "Sticky": [
  null,
  "Persistent"
 ],
 "LACP key": [
  null,
  "Cheia LACP"
 ],
 "Bridge port settings": [
  null,
  "Configurarea portului punții"
 ],
 "Path cost": [
  null,
  "Costul rutei"
 ],
 "Hair pin mode": [
  null,
  "Modul „hairpin”"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Echilibrarea adaptivă a sarcinii de transmisie"
 ],
 "Adaptive load balancing": [
  null,
  "Echilibrarea adaptivă a încărcării"
 ],
 "MII (recommended)": [
  null,
  "MII (recomandat)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Editează parametrii legăturii"
 ],
 "Network bond": [
  null,
  "Legătură de rețea"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "O legătură de rețea combină mai multe interfețe de rețea într-o singură interfață logică, oferind o rată de transfer mai mare sau redundanță."
 ],
 "Link monitoring": [
  null,
  "Monitorizarea legăturii"
 ],
 "Monitoring interval": [
  null,
  "Intervalul de monitorizare"
 ],
 "Monitoring targets": [
  null,
  "Ținte de monitorizare"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Eliminarea lui $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "Remove $0": [
  null,
  "Elimină $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Adăugarea lui $0 va întrerupe conexiunea cu serverul și va face ca interfața de administrare să nu mai fie disponibilă."
 ],
 "No interfaces available": [
  null,
  "Nu există interfețe de rețea disponibile"
 ],
 "Add member": [
  null,
  "Adaugă membru"
 ],
 "Interface members": [
  null,
  "Membrii interfeței"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web pentru servere Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit este un gestionator de servere care facilitează administrarea serverelor Linux prin intermediul unui navigator web. Trecerea de la terminal la instrumentul web și invers nu reprezintă nicio problemă. Un serviciu pornit prin Cockpit poate fi oprit prin terminal. La fel, dacă apare o eroare în terminal, aceasta poate fi vizualizată în interfața de jurnal a Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit este ideal pentru administratorii de sistem începători, permițându-le să efectueze cu ușurință sarcini simple, precum administrarea spațiului de stocare, verificarea jurnalelor și pornirea sau oprirea serviciilor. Puteți monitoriza și administra mai multe servere în același timp. Trebuie doar să le adăugați cu un singur clic, iar sistemul se va ocupa de restul."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "După ce Cockpit este instalat, activați-l cu comanda «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurarea Cockpit a NetworkManager și Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Acest instrument gestionează rețelele, cum ar fi legăturile, punțile, grupurile, rețelele VLAN și paravanele de protecție, folosind NetworkManager și Firewalld. NetworkManager nu este compatibil cu scripturile implicite systemd-networkd din Ubuntu și ifupdown din Debian."
 ],
 "Manage storage": [
  null,
  "Gestionează spațiul de stocare"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Acest instrument gestionează spațiul de stocare local, cum ar fi sistemele de fișiere, grupurile de volume LVM2 și montările NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Colectarea și organizarea datelor de diagnosticare și asistență"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Acest instrument generează un fișier de arhivă care conține informații de configurare și diagnosticare din sistemul în funcțiune. Fișierul de arhivă poate fi stocat local sau centralizat în scopuri de înregistrare sau monitorizare sau poate fi trimis reprezentanților serviciului de asistență tehnică, dezvoltatorilor sau administratorilor de sistem pentru a facilita identificarea problemelor tehnice și depanarea."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurarea și soluționarea problemelor în Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Acest instrument configurează politica SELinux și poate fi de ajutor în înțelegerea și rezolvarea încălcărilor politicii."
 ],
 "Collect kernel crash dumps": [
  null,
  "Colectarea fișierelor cu conținutul memoriei în momentul apariției unei erori fatale ale sistemului de către nucleu"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Acest instrument configurează sistemul pentru a genera fișiere cu conținutul memoriei din momentul apariției unei erori fatale de către nucleui. Acesta acceptă destinațiile de salvare „local” (pe disc), „ssh” și „nfs”."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrare cu ajutorul consolei web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Este necesară autentificarea pentru a efectua operații cu drepturi speciale în consola web Cockpit"
 ]
});
