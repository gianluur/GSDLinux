cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Керування файлами"
 ],
 "files": [
  null,
  "файли"
 ],
 "explorer": [
  null,
  "навігатор"
 ],
 "filesystem": [
  null,
  "файлова система"
 ]
});
