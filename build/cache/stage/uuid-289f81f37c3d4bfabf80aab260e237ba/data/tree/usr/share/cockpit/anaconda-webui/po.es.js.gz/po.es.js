cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 error",
  "$0 errores"
 ],
 "$0 installation": [
  null,
  "Instalación de $0"
 ],
 "$0 installer": [
  null,
  "Instalador de $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 es una partición expandida de MBR que contiene particiones lógicas. Quitar todas las particiones lógicas además quitará automáticamente la partición extendida."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 es requerido, pero solo $1 está disponible."
 ],
 "$0 warning": [
  null,
  "$0 aviso",
  "$0 avisos"
 ],
 "$0 will be deleted": [
  null,
  "$0 será eliminado"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "El sistema de archivos «$0» no puede estar en un dispositivo de bloques cifrados"
 ],
 "'$0' must be assigned to $1": [
  null,
  "«$0» debe estar asignado a $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "«$0» ha de estar en un dispositivo formateado para «$1»"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' debe estar en una Partición de Sistema EFI. La partición seleccionada utiliza un sistema de archivo FAT, pero no está marcado como un ESP. Deje a el tipo de la partición sea de Sistema EFI y habilite el indicador ‘esp’."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "La partición «$0» se ha encontrado en el dispositivo MDRAID $1. Las particiones del cargador de arranque en dispositivos MDRAID no están admitidas."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Una cuenta de usuario estándar con acceso administrativo para realizar cambios del sistema completo."
 ],
 "Abort installation": [
  null,
  "Interrumpir la instalación"
 ],
 "About": [
  null,
  "Acerca de"
 ],
 "Account": [
  null,
  "Cuenta"
 ],
 "Actions": [
  null,
  "Acciones"
 ],
 "Add another server...": [
  null,
  "Añadir otro servidor…"
 ],
 "Add mount": [
  null,
  "Agregar montaje"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Adjuntos para tu entorno elegido"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Adjuntos no específicos para tu entorno"
 ],
 "Additional languages": [
  null,
  "Idiomas adicionales"
 ],
 "Additional software for the selected environment": [
  null,
  "Software adicional para el entorno seleccionado"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Todos los cambios realizados en el editor de almacenamiento surten efecto inmediatamente."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Todos los dispositivos que utilicen esta frase contraseña se desbloquearán"
 ],
 "Anaconda Web UI": [
  null,
  "IU Web de Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Página del proyecto Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aplicar asignación del punto de montaje e instalación"
 ],
 "Applying changes...": [
  null,
  "Aplicando cambios…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Asigne particiones para puntos de montaje. Útil para despliegues personales pre-configurados."
 ],
 "Automatic log file upload": [
  null,
  "Subida automática de bitácora"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Establece Fecha y hora automáticamente, utilizando servidores de hora"
 ],
 "Automatically set timezone": [
  null,
  "Establece zona horaria automáticamente"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Espacio libre disponible: $0. La instalación requiere: $1."
 ],
 "Back": [
  null,
  "Atrás"
 ],
 "Base environment": [
  null,
  "Entorno base"
 ],
 "Brief description of the issue": [
  null,
  "Descripción de resumen del asunto"
 ],
 "Bug report details": [
  null,
  "Detalles del informe de error"
 ],
 "Bugzilla API key": [
  null,
  "Clave API de Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Al continuar utilizando este software, entiende y acepta los riesgos asociados con el software previo al lanzamiento, que utilizará para pruebas y desarrollo únicamente, y está dispuesto a informar de cualquier defecto o problema que encuentre con el fin de mejorar este trabajo."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change": [
  null,
  "Modificar"
 ],
 "Change destination": [
  null,
  "Modificar destino"
 ],
 "Change hostname": [
  null,
  "Modificar nombre de anfitrión"
 ],
 "Change partition layout": [
  null,
  "Cambio de distribución de partición"
 ],
 "Change system keyboard layout": [
  null,
  "Modificar distribución de teclado del sistema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Los cambios realizados aquí afectarán inmediatamente al sistema. No existe la opción «deshacer»."
 ],
 "Checking installation configuration...": [
  null,
  "Probando la configuración de instalación…"
 ],
 "Checking storage configuration": [
  null,
  "Probando la configuración de almacenamiento"
 ],
 "Clear search": [
  null,
  "Vaciar búsqueda"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Pulse 'Siguiente' de nuevo para proceder a pesar de estos avisos."
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Close storage editor": [
  null,
  "Cierre el editor de almacenaje"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "El almacenamiento de Cockpit no proporcionó la frase de contraseña para desbloquear el dispositivo cifrado."
 ],
 "Completed": [
  null,
  "Completado"
 ],
 "Configuration is incomplete": [
  null,
  "La configuración está incompleta"
 ],
 "Configure NTP servers": [
  null,
  "Configurar servidores NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurar servidores personales de NTP"
 ],
 "Configure network": [
  null,
  "Configurar red"
 ],
 "Configure storage": [
  null,
  "Configurar el almacenamiento"
 ],
 "Configure storage again": [
  null,
  "Volver a configurar el almacén"
 ],
 "Confirm passphrase": [
  null,
  "Confirmar la frase de contraseña"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Continue installation": [
  null,
  "Continuar la instalación"
 ],
 "Continue installation?": [
  null,
  "¿Continúo la instalación?"
 ],
 "Continue with installation": [
  null,
  "Continuar con la instalación"
 ],
 "Correct these issues before continuing.": [
  null,
  "Corrija esas incidencias antes de continuar."
 ],
 "Create Account": [
  null,
  "Crear cuenta"
 ],
 "Create account": [
  null,
  "Crear una cuenta"
 ],
 "Currently installed: $0": [
  null,
  "Instalado actualmente: $0"
 ],
 "Custom": [
  null,
  "Personalizar"
 ],
 "Date": [
  null,
  "Fecha"
 ],
 "Date and time": [
  null,
  "Fecha y hora"
 ],
 "Delete partition": [
  null,
  "Eliminar partición"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "La eliminación de ciertas particiones puede impedir que $0 arranque: $1"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Destination": [
  null,
  "Destino"
 ],
 "Destination is encrypted": [
  null,
  "El destino está cifrado"
 ],
 "Detailed description of the issue": [
  null,
  "Descripción detallada del asunto"
 ],
 "Detected valid storage layout:": [
  null,
  "Detectada disposición de almacenamiento válida:"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Duplicate device.": [
  null,
  "Dispositivo duplicado."
 ],
 "Duplicate mount point.": [
  null,
  "Punto de montaje duplicado."
 ],
 "Enable root account": [
  null,
  "Activar cuenta root"
 ],
 "Encrypt my data": [
  null,
  "Cifrar mis datos"
 ],
 "Encrypted": [
  null,
  "Cifrado"
 ],
 "Encryption": [
  null,
  "Cifrado"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Introduzca su clave API de Bugzilla para crear un informe de fallo. Será capaz de revisar y editar los detalles del fallo en el paso siguiente."
 ],
 "Environment": [
  null,
  "Entorno"
 ],
 "Erase data and install": [
  null,
  "Borrar los datos e instalar"
 ],
 "Error details": [
  null,
  "Detalles del error"
 ],
 "Exit to live desktop": [
  null,
  "Sale al escritorio vivo"
 ],
 "Extended partition": [
  null,
  "Partición extendida"
 ],
 "Failed to report issue": [
  null,
  "Incorrecto al informar defecto"
 ],
 "Failed to save layouts": [
  null,
  "Incorrecto al guardar distribuciones"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux requiere al menos $0 de espacio en disco."
 ],
 "Finalization": [
  null,
  "Finalizar"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizando: La configuración del sistema se ha completado. La finalización de la instalación puede tardar unos instantes."
 ],
 "Find layout": [
  null,
  "Buscar distribución"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Para mejor seguridad, evite utilizar la cuenta root directamente. En su lugar, utilice la cuenta local para gestionar el sistema."
 ],
 "Full name": [
  null,
  "Nombre completo"
 ],
 "Full name cannot contain colon characters": [
  null,
  "El nombre completo no puede contener el carácter de dos puntos"
 ],
 "Helper text": [
  null,
  "Texto de ayuda"
 ],
 "Hide API key": [
  null,
  "Ocultar clave API"
 ],
 "Hide confirmed password": [
  null,
  "Ocultar contraseña confirmada"
 ],
 "Hide passphrase": [
  null,
  "Ocultar frase de contraseña"
 ],
 "Hide password": [
  null,
  "Ocultar contraseña"
 ],
 "Hostname": [
  null,
  "Nombre del hospedaje"
 ],
 "How would you like to install?": [
  null,
  "¿Cómo desea realizar la instalación?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Entiendo que se borrarán todos los datos existentes",
  "Entiendo que se borrarán todos los datos existentes en los discos seleccionados"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Entiendo que algunos datos existentes serán borrados"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Entiendo que algunas particiones serán modificadas"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Si está vacío, el nombre de host será transitorio y lo establecerá la información de red."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Si está configurando particiones se requiere lo siguiente:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Si no consientes una subida de bitácora automática, puedes $0 en su lugar. Informe manual le concede revisar y seleccionar bitácoras adjuntas tú mismo."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Si no entiende o no acepta los riesgos, por favor salga de este programa."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "En curso"
 ],
 "Initializing...": [
  null,
  "Inicializando…"
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Installation failed": [
  null,
  "Instalación incorrecta"
 ],
 "Installation method": [
  null,
  "Método de instalación"
 ],
 "Installation of the system failed": [
  null,
  "Fallo en la instalación del sistema"
 ],
 "Installation of the system failed: $0": [
  null,
  "Fallo en la instalación del sistema: $0"
 ],
 "Installation type": [
  null,
  "Tipo de instalación"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Insufficient disk space": [
  null,
  "Espacio de disco insuficiente"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Detectada configuración RAID no válida. Si su colección RAID se crea directamente en la cima de discos, debe crearse una tabla de partición en la colección. Si su colección RAID se crea en la cima de las particiones, debe contener un único sistema de archivos o formato (p.ej. LVM PV). Cualquiera de las particiones existentes en esta colección serán ignoradas."
 ],
 "Invalid hostname": [
  null,
  "Nombre de huésped no válido"
 ],
 "Jump to first incomplete step": [
  null,
  "Vaya al primer paso incompleto"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Mantenga la disposición actual y utilice el espacio disponible, para arranque dual con otro SO."
 ],
 "Keyboard": [
  null,
  "Teclado"
 ],
 "Keyboard layout during boot": [
  null,
  "Distribución del teclado al arrancar"
 ],
 "Language": [
  null,
  "Idioma"
 ],
 "Launch storage editor": [
  null,
  "Iniciar el editor de almacenamiento"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Aprenda más sobre accesos restringidos en la configuración"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Abandona ambos campos de frases de acceso vacías para utilizar una contraseña vacía."
 ],
 "Location": [
  null,
  "Lugar"
 ],
 "Locked devices": [
  null,
  "Dispositivos bloqueados"
 ],
 "Make current": [
  null,
  "Realizar actual"
 ],
 "Manual disk configuration": [
  null,
  "Configuración manual del dispositivo"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuración manual del disco: Asignación de puntos de montaje"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Puede contener letras, números y guiones."
 ],
 "May need more free space": [
  null,
  "Puede necesitar más espacio libre"
 ],
 "Medium": [
  null,
  "Medio"
 ],
 "Minimum of $0 required": [
  null,
  "Se requiere como mínimo $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "No coincide la selección de reformateo entre el dispositivo padre y el dispositivo hijo."
 ],
 "Mount point": [
  null,
  "Punto de montaje"
 ],
 "Mount point assignment": [
  null,
  "Asignación del punto de montaje"
 ],
 "Move down": [
  null,
  "Bajar"
 ],
 "Move up": [
  null,
  "Subir"
 ],
 "Must be at least $0 characters": [
  null,
  "Debe tener al menos $0 caracteres"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Servidores NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Needs at least $0": [
  null,
  "Necesita al menos $0"
 ],
 "Network": [
  null,
  "Red"
 ],
 "Network Configuration": [
  null,
  "Configuración de Red"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Red no disponible. Configure la red en el menú de la barra superior para informar del problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Red no disponible. Configure la red para informar del problema."
 ],
 "Network plugin failed": [
  null,
  "Complemento de red incorrecto"
 ],
 "Next": [
  null,
  "Siguiente"
 ],
 "No devices": [
  null,
  "No hay dispositivos"
 ],
 "No disks available": [
  null,
  "Ningún disco disponible"
 ],
 "No disks selected": [
  null,
  "No se seleccionó ningún disco"
 ],
 "No layouts selected yet": [
  null,
  "Sin distribución aún seleccionada"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Ningún mapa de teclado de VConsole puede ser obtenido para la distribución(es) de teclado seleccionadas. Utilice una selección de distribución de teclado diferente."
 ],
 "Not enough available free space": [
  null,
  "No hay suficiente espacio libre disponible"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "No hay espacio libre suficiente en los discos seleccionados."
 ],
 "Not enough space on selected disks.": [
  null,
  "No hay espacio libre suficiente en los discos seleccionados."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Aviso: Este es un software previo al lanzamiento estable, para desarrollo y prueba únicamente. NO lo utilice para ningún trabajo importante ni en entornos de producción."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Abre un formulario de apunte de fallo en Bugzilla"
 ],
 "Operating system": [
  null,
  "Sistema operativo"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Other keyboards": [
  null,
  "Otros teclados"
 ],
 "Partitions (advanced)": [
  null,
  "Particiones (avanzado)"
 ],
 "Passphrase": [
  null,
  "Frase contraseña"
 ],
 "Passphrase did not match any locked device": [
  null,
  "La frase de contraseña no coincide con ningún dispositivo bloqueado"
 ],
 "Passphrases must match": [
  null,
  "Las frases de contraseña deben coincidir"
 ],
 "Pending": [
  null,
  "Pendiente"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Adjunte el boletín $0 al problema."
 ],
 "Please select at least one disk to continue": [
  null,
  "Seleccione al menos un disco para continuar"
 ],
 "Pool": [
  null,
  "Conjunto"
 ],
 "Powered by Anaconda": [
  null,
  "Desarrollado por Anaconda"
 ],
 "Pre-release": [
  null,
  "Previo al lanzamiento"
 ],
 "Prefer to report manually? $0": [
  null,
  "¿Preferir informar manualmente? $0"
 ],
 "Proceed with installation": [
  null,
  "Proceder a la instalación"
 ],
 "Quit": [
  null,
  "Salir"
 ],
 "Quit installer?": [
  null,
  "¿Salir del instalador?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Lectura incorrecta de información sobre el SO."
 ],
 "Reading information about the computer failed.": [
  null,
  "Lectura de información sobre el equipo incorrecta."
 ],
 "Reading installer configuration failed.": [
  null,
  "Lectura de configuración del instalador incorrecta."
 ],
 "Reading installer version information failed.": [
  null,
  "Lectura la información de la versión del instalador incorrecta."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Nombre de hospedaje real solo pude contener caracteres, dígitos, guiones (no comenzando o terminando un carácter) y puntos"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "El nombre del hospedaje real debe ser de 64 caracteres o menos"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reinicia a Windows para redimensionar particiones cifradas BitLocker. Haga al menos $0 de espacio libre disponible para la instalación."
 ],
 "Reboot system?": [
  null,
  "¿Reiniciar el sistema?"
 ],
 "Reclaim additional space": [
  null,
  "Reclamar espacio adicional"
 ],
 "Reclaim space": [
  null,
  "Reclamar espacio"
 ],
 "Reclaim space (required)": [
  null,
  "Reclamar espacio (requerido)"
 ],
 "Recommended": [
  null,
  "Recomendado"
 ],
 "Recommended partitions:": [
  null,
  "Particiones recomendadas:"
 ],
 "Reformat": [
  null,
  "Reformatear"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstalar Fedora"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Quitar todas las particiones en el mismo dispositivo, incluyendo el sistema operativo existente."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Quita o redimensiona el sistema de archivos existente para liberar espacio para la instalación."
 ],
 "Remove server": [
  null,
  "Servidor remoto"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Quitar un sistema de archivos eliminará permanentemente todos los datos que contiene. Redimensionar una partición puede liberar espacio no utilizado, pero no está libre de riesgos. Asegúrese que tenga copias de respaldo de cualquier cosa importante antes de reclamar espacio."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Remplazar la instalación actual, pero conserva los archivos dentro de /home."
 ],
 "Report Issue": [
  null,
  "Informar un defecto"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Informe un fallo o proporcione retroalimentación abriendo el formulario $0 de apunte de defecto de Bugzilla."
 ],
 "Report issue": [
  null,
  "Informar defecto"
 ],
 "Reporting issue...": [
  null,
  "Informando defecto…"
 ],
 "Required": [
  null,
  "Requerido"
 ],
 "Requirements": [
  null,
  "Requisitos"
 ],
 "Rescan devices": [
  null,
  "Reanalizar dispositivos"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Reanalizado de discos incorrecto."
 ],
 "Resize": [
  null,
  "Redimensionar"
 ],
 "Resize partition": [
  null,
  "Redimensionar partición"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Redimensionando las siguientes particiones desde $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Restringir acceso al informe"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Restringe el informe al grupo $0. $1"
 ],
 "Return to installation": [
  null,
  "Volver a la instalación"
 ],
 "Return to storage editor": [
  null,
  "Volver al editor de almaceaje"
 ],
 "Review and install": [
  null,
  "Revisar e instalar"
 ],
 "Root account is enabled": [
  null,
  "La cuenta root está habilitada"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "La cuenta root está habilitada, pero no ha sido configurada ninguna cuenta de usuario"
 ],
 "Root password has been set.": [
  null,
  "Se ha establecido la contraseña del root."
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Analizar el código QR con su teléfono o visite:"
 ],
 "Search for a language": [
  null,
  "Buscar un idioma"
 ],
 "Search for additional software": [
  null,
  "Búsqueda para software adicional"
 ],
 "Search for an environment": [
  null,
  "Buscar un entorno"
 ],
 "Search keyboard layout": [
  null,
  "Buscar distribución del teclado"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Asegure sus datos utilizando discos basados en cifrado. Solo aplique a particiones nuevas"
 ],
 "Select": [
  null,
  "Seleccionar"
 ],
 "Select a device": [
  null,
  "Seleccione un dispositivo"
 ],
 "Select city": [
  null,
  "Seleccionar ciudad"
 ],
 "Select destination": [
  null,
  "Seleccionar destino"
 ],
 "Select region": [
  null,
  "Seleccionar región"
 ],
 "Selected (top = current)": [
  null,
  "Seleccionado (cima = actual)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "El formato del dispositivo «$0» seleccionado no puede ser reformateado."
 ],
 "Send us feedback on your installation": [
  null,
  "Envíenos un informe en su instalación"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server is not reachable": [
  null,
  "El servidor no es alcanzable"
 ],
 "Set custom hostname": [
  null,
  "Fijar nombre de hospedaje personal"
 ],
 "Share disk with other operating systems": [
  null,
  "Compartir disco con otros sistemas operativos"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Compartir disco con otros sistemas operativos: $0"
 ],
 "Show AM/PM": [
  null,
  "Mostrar AM/PM"
 ],
 "Show API key": [
  null,
  "Mostrar clave API"
 ],
 "Show confirmed password": [
  null,
  "Mostrar contraseña confirmada"
 ],
 "Show passphrase": [
  null,
  "Mostrar frase contraseña"
 ],
 "Show password": [
  null,
  "Mostrar contraseña"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Software installation": [
  null,
  "Instalación de software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalación del software: Configuración de almacenamiento completada. Se está instalando el software en su dispositivo."
 ],
 "Software selection": [
  null,
  "Selección de software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Algunos pasos de la instalación aún necesita ser completados antes que pueda continuar."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Algunas particiones requeridas faltan: $0"
 ],
 "Space": [
  null,
  "Espacio"
 ],
 "Stacktrace": [
  null,
  "Seguimiento de pila"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Storage configuration": [
  null,
  "Configuración de almacenamiento"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuración de almacenamiento: Se está configurando el almacenamiento."
 ],
 "Storage editor": [
  null,
  "Editor de almacenamiento"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "El almacén está basado en la configuración de «Modificar almacenaje»."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "La disposición del almacenamiento está definida por el archivo kickstart. La disposición de particionado planificada puede ser revisada en el paso de resumen."
 ],
 "Storage plugin failed": [
  null,
  "Complemento de almacenaje incorrecto"
 ],
 "Storage requirements not met": [
  null,
  "No se obtuvieron los requisitos de almacenaje"
 ],
 "Strong": [
  null,
  "Robusta"
 ],
 "Successfully installed": [
  null,
  "Instalado correctamente"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 desbloqueado correctamente."
 ],
 "Suggested keyboards": [
  null,
  "Teclados sugeridos"
 ],
 "Suggested languages": [
  null,
  "Idiomas sugeridos"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Configuración del sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuración del sistema: Instalación del software completada. Se está configurando el sistema."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "La instalación Anaconda se ha detenido inesperadamente."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Se creará el siguiente usuario:",
  "Se crearán los siguientes usuarios:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "La instalación necesita $0 de espacio del disco; sin embargo, la capacidad de los discos seleccionados solo es de $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "El instalador no se puede continuar debido a un error crítico."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "El instalador no se puede continuar debido a un error crítico: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "La frase de contraseña que ha proporcionado contiene caracteres fuera del rango ASCII. Es probable que no sea capaz de cambiar la disposición del teclado cuando necesite escribirla."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "La distribución seleccionada del teclado por defecto no admite caracteres ASCII. Elija una distribución de compatible con ASCII como el predeterminado."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "El editor de almacenaje le permite redimensionar, borrar y crear particiones. Puede configurar LVM y mucho más. Esto significa que puede ser una utilidad avanzada y ni intente usarse en una típica instalación."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Esos archivos de bitácoras pueden contener información sensible como direcciones IP, identificador de usuario, u otros detalles del sistema."
 ],
 "This hostname can't be submitted": [
  null,
  "Este nombre de hospedaje no pude ser enviado"
 ],
 "This is unstable, pre-release software": [
  null,
  "Este software es previo al lanzamiento e inestable"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Esta distribución será utilizada para desbloquear su sistema al arrancar"
 ],
 "This may take a moment": [
  null,
  "Esto puede tardar un rato"
 ],
 "This will take a few moments": [
  null,
  "Esto tomará un poco de rato"
 ],
 "Time": [
  null,
  "Hora y día"
 ],
 "Timezone": [
  null,
  "Zona horaria"
 ],
 "Title": [
  null,
  "Título"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Para comenzar utilizando $0, reinicie sus sistema."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Para continuar, seleccione los dispositivos a los que instalar."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Para utilizar esta opción, redimensione o quite particiones existentes para liberar al menos $0."
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "No es posible programar la eliminación de $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "No es posible programar el redimensionamiento de $0"
 ],
 "Undo last action": [
  null,
  "Deshacer la última acción"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Unlock encrypted devices": [
  null,
  "Desbloquear dispositivos cifrados"
 ],
 "Use configured storage": [
  null,
  "Utilizar el almacenamiento configurado"
 ],
 "Use entire disk": [
  null,
  "Utilizar todo el disco"
 ],
 "Use free space": [
  null,
  "Utilizar el espacio libre"
 ],
 "Use local account": [
  null,
  "Utilizar cuenta local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Utilizar el dispositivo RAID para el particionamiento automático"
 ],
 "User creation": [
  null,
  "Creación de usuario"
 ],
 "User name": [
  null,
  "Nombre de usuario"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "El nombre de usuario solo puede contener: letras de la A a la Z, dígitos 0-9, guion $0, punto $1 y guion bajo $2"
 ],
 "User name must not be a reserved word": [
  null,
  "El nombre de usuario no debe ser una palabra reservada"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Los nombres de usuario deben ser reducidos como mucho a 22 caracteres"
 ],
 "Validating...": [
  null,
  "Validando…"
 ],
 "Weak": [
  null,
  "Débil"
 ],
 "Welcome": [
  null,
  "Bienvenido/a"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Le damos la bienvenida a Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Le damos la bienvenida. Ahora instalemos $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Cuándo envíe este informe de defecto, las bitácoras siguientes serán subidas automáticamente: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Las particiones de Windows con cifrado BitLocker no pueden ser redimensionadas"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Puede liberar suficiente espacio aquí y dejar que el instalador se encargue del resto o bien configurar manualmente las particiones."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Puedes generar la clave de API para vuestra cuenta Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Tienen que habilitar la cuenta root o cree una cuenta de usuario local para proceder."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Debe estar conectado a una red para habilitar automáticamente la fecha y la hora."
 ],
 "Your progress will not be saved.": [
  null,
  "Su progreso no será guardado."
 ],
 "completed step": [
  null,
  "paso completado"
 ],
 "current step": [
  null,
  "paso actual"
 ],
 "delete": [
  null,
  "eliminar"
 ],
 "edit": [
  null,
  "editar"
 ],
 "encrypt": [
  null,
  "cifrar"
 ],
 "encrypted": [
  null,
  "cifrado"
 ],
 "extended partition": [
  null,
  "partición expandida"
 ],
 "format as $0": [
  null,
  "dar formato como $0"
 ],
 "here": [
  null,
  "aquí"
 ],
 "incomplete": [
  null,
  "incompleto"
 ],
 "mount": [
  null,
  "montar"
 ],
 "pending step": [
  null,
  "paso pendiente"
 ],
 "report the issue manually": [
  null,
  "informe el asunto manualmente"
 ],
 "resized from $0": [
  null,
  "redimensionado desde $0"
 ],
 "shrink": [
  null,
  "reducir"
 ],
 "shrink to $0": [
  null,
  "reducir a $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "deshacer"
 ]
});
