cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "Force delete": [
  null,
  "削除の強制"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Must be a valid IP address": [
  null,
  "有効な IP アドレスにしてください"
 ],
 "1 to 65535": [
  null,
  "1 - 65535"
 ],
 "Container port must not be empty": [
  null,
  "コンテナーポートは空欄にできません"
 ],
 "IP address": [
  null,
  "IP アドレス"
 ],
 "IP address help": [
  null,
  "IP アドレスヘルプ"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "ホスト IP を 0.0.0.0 に設定した場合、またはまったく設定しなかった場合、ポートはホスト上のすべての IP にバインドされます。"
 ],
 "Host port": [
  null,
  "ホストポート"
 ],
 "Host port help": [
  null,
  "ホストポートヘルプ"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "ホストポートが設定されていない場合、コンテナーポートにはホストのポートがランダムに割り当てられます。"
 ],
 "Container port": [
  null,
  "コンテナーポート"
 ],
 "Protocol": [
  null,
  "プロトコル"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "アイテムの削除"
 ],
 "Image name is required": [
  null,
  "イメージ名が必要です"
 ],
 "Image name is not unique": [
  null,
  "イメージ名は一意ではありません"
 ],
 "Failed to commit container $0": [
  null,
  "コンテナー $0 のコミットに失敗しました"
 ],
 "New image name": [
  null,
  "新しいイメージ名"
 ],
 "Tag": [
  null,
  "タグ"
 ],
 "Author": [
  null,
  "作成者"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "例: 名前 <yourname@example.com>"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Pause container when creating image": [
  null,
  "イメージの作成時にコンテナーを一時停止します"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Dockerフォーマットは、イメージをDockerまたはMoby Engineで共有する時に便利です"
 ],
 "Use legacy Docker format": [
  null,
  "レガシーの Docker フォーマットの使用"
 ],
 "Commit container": [
  null,
  "コンテナーのコミット"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "$0 コンテナーの現在の状態に基づいて、新しいイメージを作成します。"
 ],
 "Commit": [
  null,
  "コミット"
 ],
 "Force commit": [
  null,
  "強制コミット"
 ],
 "Failed to force remove container $0": [
  null,
  "コンテナー $0 を強制的に削除できませんでした"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "実行中のコンテナーを削除すると、その中のすべてのデータが削除されます。"
 ],
 "Failed to stop container $0": [
  null,
  "コンテナー $0 の停止に失敗しました"
 ],
 "Failed to start container $0": [
  null,
  "コンテナー $0 の起動に失敗しました"
 ],
 "Failed to resume container $0": [
  null,
  "コンテナー $0 のレジュームに失敗しました"
 ],
 "Failed to pause container $0": [
  null,
  "コンテナー $0 の一時停止に失敗しました"
 ],
 "Failed to restart container $0": [
  null,
  "コンテナー $0 の再起動に失敗しました"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Restart": [
  null,
  "再起動"
 ],
 "Force stop": [
  null,
  "停止の強制"
 ],
 "Force restart": [
  null,
  "再起動の強制"
 ],
 "Pause": [
  null,
  "一時停止"
 ],
 "Resume": [
  null,
  "再開"
 ],
 "Checkpoint": [
  null,
  "チェックポイント"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Restore": [
  null,
  "復元"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Healthy": [
  null,
  "健全"
 ],
 "Unhealthy": [
  null,
  "異常"
 ],
 "Checking health": [
  null,
  "ヘルスチェック"
 ],
 "Prune unused containers": [
  null,
  "使用していないコンテナーの削除"
 ],
 "Terminal not available": [
  null,
  "ターミナルは利用できません"
 ],
 "This browser does not support WebGL2.": [
  null,
  "このブラウザはWebGL2に対応していません。"
 ],
 "View $0 logs": [
  null,
  ""
 ],
 "not available": [
  null,
  "利用できません"
 ],
 "n/a": [
  null,
  "N/A"
 ],
 "$0% of $1 limit": [
  null,
  "上限 $1 中の $0 %"
 ],
 "service": [
  null,
  ""
 ],
 "system": [
  null,
  "システム"
 ],
 "user:": [
  null,
  "ユーザー:"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Integration": [
  null,
  "インテグレーション"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Console": [
  null,
  "コンソール"
 ],
 "Health check": [
  null,
  "ヘルスチェック"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "Click to see published ports": [
  null,
  "クリックして公開されたポートを表示します"
 ],
 "ports": [
  null,
  "ポート"
 ],
 "Click to see volumes": [
  null,
  "クリックしてボリュームを表示します"
 ],
 "volumes": [
  null,
  "ボリューム"
 ],
 "Container": [
  null,
  "コンテナー"
 ],
 "Owner": [
  null,
  "所有者"
 ],
 "State": [
  null,
  "状態"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "No containers": [
  null,
  "コンテナーなし"
 ],
 "No containers in this pod": [
  null,
  "この Pod 内のコンテナーはありません"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "No containers that match the current filter": [
  null,
  "現在のフィルターに一致するコンテナーがありません"
 ],
 "No running containers": [
  null,
  "実行中のコンテナーはありません"
 ],
 "Show": [
  null,
  "表示"
 ],
 "All": [
  null,
  "すべて"
 ],
 "Only running": [
  null,
  "実行のみ"
 ],
 "Create pod": [
  null,
  "Pod の作成"
 ],
 "Create container": [
  null,
  "コンテナーの作成"
 ],
 "Containers": [
  null,
  "コンテナー"
 ],
 "Create container in pod": [
  null,
  "Pod でのコンテナーの作成"
 ],
 "Failed to restore container $0": [
  null,
  "コンテナー $0 の復元に失敗しました"
 ],
 "Restore container $0": [
  null,
  "コンテナー $0 の復元"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "すべての一時的なチェックポイントファイルを維持"
 ],
 "Restore with established TCP connections": [
  null,
  "確立された TCP 接続での復元"
 ],
 "Ignore IP address if set statically": [
  null,
  "静的に設定された場合は IP アドレスを無視"
 ],
 "Ignore MAC address if set statically": [
  null,
  "静的に設定された場合は MAC アドレスを無視"
 ],
 "Pod failed to be created": [
  null,
  "Pod の作成に失敗しました"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "無効な文字です。名前には文字、数字、および特定の句読点 (_ . -) のみを使用できます。"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Pod name": [
  null,
  "Pod 名"
 ],
 "System": [
  null,
  "システム"
 ],
 "User:": [
  null,
  "ユーザー:"
 ],
 "No ports exposed": [
  null,
  "開放されているポートはありません"
 ],
 "Port mapping": [
  null,
  "ポートマッピング"
 ],
 "Add port mapping": [
  null,
  "ポートマッピングの追加"
 ],
 "No volumes specified": [
  null,
  "指定されているボリュームはありません"
 ],
 "Volumes": [
  null,
  "ボリューム"
 ],
 "Add volume": [
  null,
  "ボリュームの追加"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Type to filter…": [
  null,
  "入力してフィルタリング…"
 ],
 "Container path must not be empty": [
  null,
  "コンテナーパスは空欄にできません"
 ],
 "Host path": [
  null,
  "ホストパス"
 ],
 "Container path": [
  null,
  "コンテナーパス"
 ],
 "Mode": [
  null,
  "モード"
 ],
 "Writable": [
  null,
  "書き込み可能"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "ラベルなし"
 ],
 "Shared": [
  null,
  "共有"
 ],
 "Private": [
  null,
  "プライベート"
 ],
 "Read-write access": [
  null,
  "読み書きアクセス"
 ],
 "Read-only access": [
  null,
  "読み取り専用アクセス"
 ],
 "Show less": [
  null,
  "簡易表示"
 ],
 "Show more": [
  null,
  "詳細表示"
 ],
 "Loading details...": [
  null,
  "詳細をロード中..."
 ],
 "Ports": [
  null,
  "ポート"
 ],
 "Environment variables": [
  null,
  "環境変数"
 ],
 "Failed to download image $0:$1": [
  null,
  "イメージ $0 のダウンロードに失敗しました: $1"
 ],
 "Error message": [
  null,
  "エラーメッセージ"
 ],
 "unused": [
  null,
  "未使用"
 ],
 "$0 container": [
  null,
  "$0 コンテナー"
 ],
 "History": [
  null,
  "履歴"
 ],
 "Image": [
  null,
  "イメージ"
 ],
 "Created": [
  null,
  "作成済み"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "ディスクの空き容量"
 ],
 "Used by": [
  null,
  "使用中"
 ],
 "No images": [
  null,
  "イメージなし"
 ],
 "No images that match the current filter": [
  null,
  "現在のフィルターに一致するイメージがありません"
 ],
 "Hide intermediate images": [
  null,
  "中間イメージを非表示"
 ],
 "Show intermediate images": [
  null,
  "中間イメージの表示"
 ],
 "Images": [
  null,
  "イメージ"
 ],
 "$0 image total, $1": [
  null,
  "$0 イメージ合計、$1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 の未使用イメージ、$1"
 ],
 "Hide images": [
  null,
  "イメージを非表示"
 ],
 "Show images": [
  null,
  "イメージの表示"
 ],
 "Pulling": [
  null,
  "プル中"
 ],
 "Download new image": [
  null,
  "新規イメージのダウンロード"
 ],
 "Pull all images": [
  null,
  "すべてのイメージを取得"
 ],
 "Prune unused images": [
  null,
  "未使用イメージの削除"
 ],
 "Pull": [
  null,
  "プル"
 ],
 "Up since:": [
  null,
  "開始:"
 ],
 "Exited": [
  null,
  "終了"
 ],
 "systemd service": [
  null,
  ""
 ],
 "View $0": [
  null,
  ""
 ],
 "Gateway": [
  null,
  "ゲートウェイ"
 ],
 "MAC address": [
  null,
  "MAC アドレス"
 ],
 "Latest checkpoint": [
  null,
  "最終チェックポイント"
 ],
 "No containers are using this image": [
  null,
  "このイメージを使用するコンテナーはありません"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "Loading logs...": [
  null,
  "ログをロード中..."
 ],
 "Delete unused system images:": [
  null,
  "使用されていないシステムイメージの削除:"
 ],
 "Delete unused images of user $0:": [
  null,
  "ユーザ $0 のタグ付けされたイメージの削除:"
 ],
 "Failed to prune unused images": [
  null,
  "使用されていないイメージのpruneに失敗しました"
 ],
 "Pruning images": [
  null,
  "イメージを削除中"
 ],
 "Prune": [
  null,
  "削除"
 ],
 "Failed to checkpoint container $0": [
  null,
  "コンテナー $0 のチェックポイントに失敗しました"
 ],
 "Checkpoint container $0": [
  null,
  "チェックポイントコンテナー $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "チェックポイントをディスクに書き込む後もそのまま実行したままにする"
 ],
 "Support preserving established TCP connections": [
  null,
  "確立された TCP 接続の保持サポート"
 ],
 "Failed to search for new images": [
  null,
  "新規イメージの検索に失敗しました"
 ],
 "Failed to search for images: $0": [
  null,
  "イメージの検索に失敗しました: $0"
 ],
 "Failed to search for images.": [
  null,
  "イメージの検索に失敗しました。"
 ],
 "Search for an image": [
  null,
  "イメージの検索"
 ],
 "Search for": [
  null,
  "検索"
 ],
 "Search by name or description": [
  null,
  "名前または説明による検索"
 ],
 "in": [
  null,
  "場所"
 ],
 "All registries": [
  null,
  "すべてのレジストリー"
 ],
 "Searching...": [
  null,
  "検索中..."
 ],
 "No images found": [
  null,
  "イメージが見つかりません"
 ],
 "Start typing to look for images.": [
  null,
  "イメージを検索するために入力を開始します。"
 ],
 "No results for $0": [
  null,
  "$0 の結果なし"
 ],
 "Retry another term.": [
  null,
  "別の用語を再試行します。"
 ],
 "Download": [
  null,
  "ダウンロード"
 ],
 "No action": [
  null,
  "アクションなし"
 ],
 "Container failed to be started": [
  null,
  "コンテナーの開始に失敗しました"
 ],
 "Failed to clean up container": [
  null,
  "コンテナーのクリーンアップに失敗しました"
 ],
 "Container failed to be created": [
  null,
  "コンテナーの作成に失敗しました"
 ],
 "downloading": [
  null,
  "ダウンロード中"
 ],
 "Failed to run container $0": [
  null,
  "コンテナー $0 の実行に失敗しました"
 ],
 "Failed to create container $0": [
  null,
  "コンテナー $0 の作成に失敗しました"
 ],
 "Failed to pull image $0": [
  null,
  "イメージ $0 のpullに失敗しました"
 ],
 "Local images": [
  null,
  "ローカルのイメージ"
 ],
 "Name already in use": [
  null,
  "名前はすでに使用中です"
 ],
 "Search by registry": [
  null,
  "レジストリーで検索"
 ],
 "Local": [
  null,
  "ローカル"
 ],
 "Container name": [
  null,
  "コンテナー名"
 ],
 "Owner help": [
  null,
  "所有者のヘルプ"
 ],
 "Ideal for running services": [
  null,
  "実行中のサービスに最適"
 ],
 "Resource limits can be set": [
  null,
  "リソース制限を設定できます"
 ],
 "Checkpoint and restore support": [
  null,
  "チェックポイントおよび復元のサポート"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "1024 未満のポートをマッピングできます"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Ideal for development": [
  null,
  "開発に最適"
 ],
 "Restricted by user account permissions": [
  null,
  "ユーザーアカウントのパーミッションによって制限"
 ],
 "Image selection help": [
  null,
  "イメージ選択のヘルプ"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "Example: $0": [
  null,
  "例: $0"
 ],
 "Searching: $0": [
  null,
  "検索中: $0"
 ],
 "Search string or container location": [
  null,
  "検索文字列またはコンテナーのロケーション"
 ],
 "Pull latest image": [
  null,
  "最新イメージのプル"
 ],
 "Entrypoint": [
  null,
  "エントリーポイント"
 ],
 "With terminal": [
  null,
  "端末の使用"
 ],
 "Memory limit": [
  null,
  "メモリー制限"
 ],
 "Decrease memory": [
  null,
  "メモリーを減らす"
 ],
 "Increase memory": [
  null,
  "メモリーを増やす"
 ],
 "Memory unit": [
  null,
  "メモリーユニット"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "CPU 共有"
 ],
 "CPU Shares help": [
  null,
  "CPU share のヘルプ"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 共有は実行中のコンテナーの優先度を決定します。デフォルトの優先度は 1024 です。数値が高いほど、このコンテナーの優先度が高くなります。数値が低いほど優先度が低くなります。"
 ],
 "Decrease CPU shares": [
  null,
  "CPU 共有を減らす"
 ],
 "Increase CPU shares": [
  null,
  "CPU 共有を増やす"
 ],
 "Restart policy": [
  null,
  "再起動ポリシー"
 ],
 "Restart policy help": [
  null,
  "再起動ポリシーのヘルプ"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "コンテナーの終了時に従う再起動ポリシー。コンテナーの自動起動に linger を使用すると、ユーザーアカウントで ecryptfs、systemd-homed、NFS、または 2FA が使用されている場合など、一部の状況では機能しない場合があります。"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "コンテナーの終了時に従う再起動ポリシー。"
 ],
 "No": [
  null,
  "いいえ"
 ],
 "On failure": [
  null,
  "障害発生時"
 ],
 "Always": [
  null,
  "常時"
 ],
 "Maximum retries": [
  null,
  "最大施行数"
 ],
 "Decrease maximum retries": [
  null,
  "最大再試行回数を減らす"
 ],
 "Increase maximum retries": [
  null,
  "最大再試行回数を増やす"
 ],
 "No environment variables specified": [
  null,
  "環境変数が指定されていません"
 ],
 "Add variable": [
  null,
  "変数の追加"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "一括インポートのために、キー=値ペアからなる 1 つまたは複数の行を任意のフィールドに貼り付けます"
 ],
 "Interval": [
  null,
  "間隔"
 ],
 "Health check interval help": [
  null,
  "ヘルスチェックの間隔のヘルプ"
 ],
 "Interval how often health check is run.": [
  null,
  "ヘルスチェックの実行頻度 (間隔)。"
 ],
 "Decrease interval": [
  null,
  "間隔を縮小する"
 ],
 "Increase interval": [
  null,
  "間隔を増やす"
 ],
 "seconds": [
  null,
  "秒"
 ],
 "Timeout": [
  null,
  "タイムアウト"
 ],
 "Health check timeout help": [
  null,
  "ヘルスチェックのタイムアウトのヘルプ"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "間隔が失敗したとみなされる前に、ヘルスチェックを完了するために許容される最大時間。"
 ],
 "Decrease timeout": [
  null,
  "タイムアウトを縮小する"
 ],
 "Increase timeout": [
  null,
  "タイムアウトを拡大する"
 ],
 "Start period": [
  null,
  "開始期間"
 ],
 "Health check start period help": [
  null,
  "ヘルスチェックの開始期間のヘルプ"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "コンテナーのブートストラップに必要な初期化時間。"
 ],
 "Decrease start period": [
  null,
  "開始期間を縮小する"
 ],
 "Increase start period": [
  null,
  "開始期間を拡大する"
 ],
 "Retries": [
  null,
  "再試行回数"
 ],
 "Health check retries help": [
  null,
  "ヘルスチェックの再試行のヘルプ"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "ヘルスチェックが異常であると見なされるまでに許可される再試行の回数。"
 ],
 "Decrease retries": [
  null,
  "再試行回数を減らす"
 ],
 "Increase retries": [
  null,
  "再試行を増やす"
 ],
 "When unhealthy": [
  null,
  "異常な場合"
 ],
 "Health failure check action help": [
  null,
  "ヘルスチェック失敗時のアクションのヘルプ"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "コンテナーが異常な状態に移行したときに実行するアクション。"
 ],
 "Create container in $0": [
  null,
  "$0 でのコンテナーの作成"
 ],
 "Create and run": [
  null,
  "作成して実行する"
 ],
 "Description": [
  null,
  ""
 ],
 "Version": [
  null,
  ""
 ],
 "Links": [
  null,
  ""
 ],
 "Documentation": [
  null,
  ""
 ],
 "Tags": [
  null,
  "タグ"
 ],
 "Created by": [
  null,
  "作成元"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Comments": [
  null,
  "コメント"
 ],
 "Unable to load image history": [
  null,
  "イメージ履歴をロードできません"
 ],
 "Key must not be empty": [
  null,
  "キーは空欄にできません"
 ],
 "Key must not begin with a digit": [
  null,
  "キーの先頭を数字にすることはできません"
 ],
 "Key contains invalid characters": [
  null,
  "キーに無効な文字が含まれています"
 ],
 "Key": [
  null,
  "キー"
 ],
 "Value": [
  null,
  "値"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "Podman service failed": [
  null,
  "Podman サービスが失敗しました"
 ],
 "Troubleshoot": [
  null,
  "トラブルシュート"
 ],
 "Failed to force remove image $0": [
  null,
  "イメージ $0 の強制削除に失敗しました"
 ],
 "intermediate image": [
  null,
  "中間イメージ"
 ],
 "Failed to remove image $0": [
  null,
  "イメージ $0 の削除に失敗しました"
 ],
 "intermediate": [
  null,
  "中間"
 ],
 "Delete $0 image?": [
  null,
  "$0 イメージを削除しますか?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "このイメージには、複数のタグが存在します。削除するタグ付けされたイメージを選択します。"
 ],
 "Delete image": [
  null,
  "イメージの削除"
 ],
 "Delete tagged images": [
  null,
  "タグ付けされたイメージの削除"
 ],
 "Container is not running": [
  null,
  "コンテナーが実行されていません"
 ],
 "Error occurred while connecting console": [
  null,
  "コンソールへの接続中にエラーが発生しました"
 ],
 "Force delete pod $0?": [
  null,
  "Pod $0 を強制的に削除しますか?"
 ],
 "Delete pod $0?": [
  null,
  "Pod $0 を削除しますか?"
 ],
 "An error occurred": [
  null,
  "エラーが発生しました"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "空の Pod $0 は完全に削除されます。"
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "この Pod を削除すると、以下のコンテナーが削除されます:"
 ],
 "Failed to start pod $0": [
  null,
  "Pod $0 の起動に失敗しました"
 ],
 "Failed to stop pod $0": [
  null,
  "Pod $0 の停止に失敗しました"
 ],
 "Failed to restart pod $0": [
  null,
  "Pod $0 の再起動に失敗しました"
 ],
 "Failed to resume pod $0": [
  null,
  "Pod $0 の再開に失敗しました"
 ],
 "Failed to pause pod $0": [
  null,
  "Pod $0 の一時停止に失敗しました"
 ],
 "Failed to prune unused containers": [
  null,
  "使用されていないイメージの prune に失敗しました"
 ],
 "Removes selected non-running containers": [
  null,
  "選択した実行中でないコンテナーを削除します"
 ],
 "Pruning containers": [
  null,
  "コンテナーに prune を実行中"
 ],
 "Container name is required.": [
  null,
  "コンテナー名が必要です。"
 ],
 "Failed to rename container $0": [
  null,
  "コンテナーの名前変更に失敗しました $0"
 ],
 "New container name": [
  null,
  "新しいコンテナー名"
 ],
 "Rename container $0": [
  null,
  "コンテナーの名前変更 $0"
 ],
 "Paused": [
  null,
  "一時停止"
 ],
 "Stopped": [
  null,
  "停止中"
 ],
 "Removing": [
  null,
  "削除中"
 ],
 "Configured": [
  null,
  "設定済み"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "$0 second": [
  null,
  "$0 秒"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Failing streak": [
  null,
  "失敗の連続"
 ],
 "Failed to run health check on container $0": [
  null,
  "コンテナーでのヘルスチェックの実行に失敗しました $0"
 ],
 "Run health check": [
  null,
  "ヘルスチェックを実行する"
 ],
 "Last 5 runs": [
  null,
  "過去 5 回の実行"
 ],
 "Started at": [
  null,
  "開始日時"
 ],
 "Passed health run": [
  null,
  "合格したヘルスの実行"
 ],
 "Failed health run": [
  null,
  "失敗したヘルスの実行"
 ],
 "Failed to remove container $0": [
  null,
  "コンテナー $0 の削除に失敗しました"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "コンテナーを削除すると、コンテナー内のすべてのデータが削除されます。"
 ]
});
