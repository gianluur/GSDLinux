cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Containere Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "container"
 ],
 "image": [
  null,
  "imagine"
 ]
});
