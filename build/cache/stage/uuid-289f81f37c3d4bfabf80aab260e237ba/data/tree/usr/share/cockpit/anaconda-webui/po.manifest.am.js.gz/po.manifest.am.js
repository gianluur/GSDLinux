cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "am",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
