cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servicii"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Overview": [
  null,
  "Vedere de ansamblu"
 ],
 "Logs": [
  null,
  "Jurnale"
 ],
 "time": [
  null,
  "ora"
 ],
 "date": [
  null,
  "data"
 ],
 "restart": [
  null,
  "repornire"
 ],
 "shut": [
  null,
  "oprește"
 ],
 "domain": [
  null,
  "domeniu"
 ],
 "machine": [
  null,
  "mașina"
 ],
 "operating system": [
  null,
  "sistemul de operare"
 ],
 "os": [
  null,
  "so"
 ],
 "asset tag": [
  null,
  "etichetă de identificare a obiectului"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "alimentare"
 ],
 "version": [
  null,
  "versiunea"
 ],
 "host": [
  null,
  "gazdă"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "atenuare"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "memorie"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "serial"
 ],
 "graphs": [
  null,
  "grafice"
 ],
 "metrics": [
  null,
  "măsurători"
 ],
 "history": [
  null,
  "istoric"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "discuri"
 ],
 "network": [
  null,
  "rețea"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "performanță"
 ],
 "Configuring system settings": [
  null,
  "Se configurează parametrii sistemului"
 ],
 "service": [
  null,
  "serviciu"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ținta"
 ],
 "socket": [
  null,
  "soclu"
 ],
 "timer": [
  null,
  "temporizator"
 ],
 "path": [
  null,
  "ruta"
 ],
 "unit": [
  null,
  "unitatea"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "pornire"
 ],
 "mask": [
  null,
  "mască"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "activează"
 ],
 "disable": [
  null,
  "dezactivează"
 ],
 "Managing services": [
  null,
  "Gestionarea serviciilor"
 ],
 "journal": [
  null,
  "jurnal"
 ],
 "warning": [
  null,
  "avertisment"
 ],
 "error": [
  null,
  "eroare"
 ],
 "debug": [
  null,
  "depanare"
 ],
 "crash": [
  null,
  "colaps"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "Revizuirea jurnalelor"
 ],
 "console": [
  null,
  "consolă"
 ],
 "command": [
  null,
  "comanda"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
