cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "gl",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
