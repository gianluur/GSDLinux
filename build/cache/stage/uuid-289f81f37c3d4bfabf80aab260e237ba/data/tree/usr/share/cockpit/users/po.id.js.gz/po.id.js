cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Kunci yang berubah sering kali disebabkan oleh instalasi ulang sistem operasi. Namun, perubahan yang tidak terduga dapat menunjukkan upaya pihak ketiga untuk mencegat koneksi Anda."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Untuk memastikan bahwa koneksi Anda tidak dicegat oleh pihak ketiga berbahaya, harap verifikasi sidik jari kunci host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email."
 ],
 "User name": [
  null,
  "Nama pengguna"
 ],
 "Password": [
  null,
  "Kata sandi"
 ],
 "Log in": [
  null,
  "Masuk"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Local accounts": [
  null,
  "Akun lokal"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Fingerprint": [
  null,
  "Sidik jari"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Copied": [
  null,
  "Disalin"
 ],
 "New password": [
  null,
  "Kata sandi baru"
 ],
 "Confirm password": [
  null,
  "Konfirmasi sandi"
 ],
 "Add key": [
  null,
  "Tambahkan kunci"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Remove": [
  null,
  "Hapus"
 ],
 "Log out": [
  null,
  "Keluar"
 ],
 "Select": [
  null,
  "Pilih"
 ],
 "Unexpected error": [
  null,
  "Kesalahan tak terduga"
 ],
 "No results found": [
  null,
  "Tidak ada hasil ditemukan"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit tidak terpasang"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Versi Cockpit yang kompatibel tidak terinstal pada $0."
 ],
 "Add": [
  null,
  "Tambah"
 ],
 "$0 key changed": [
  null,
  "Kunci $0 telah berubah"
 ],
 "Trust and add host": [
  null,
  "Percayai dan tambahkan host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Untuk memverifikasi sidik jari, jalankan perintah berikut di $0 saat berada langsung di mesin atau melalui jaringan tepercaya:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jika sidik jari cocok, klik 'Percayai dan tambahkan host'. Jika tidak, jangan sambungkan dan hubungi administrator Anda."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email. Jika Anda meminta orang lain untuk melakukan verifikasi, mereka dapat mengirim hasilnya dengan metode apa pun."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Anda terhubung ke $0 untuk pertama kalinya."
 ],
 "Verify fingerprint": [
  null,
  "Verifikasi sidik jari"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Jalankan perintah ini melalui jaringan tepercaya atau langsung di mesin jarak jauh:"
 ],
 "The fingerprint should match:": [
  null,
  "Sidik jari harus cocok:"
 ],
 "The password can not be empty": [
  null,
  "Kata sandi tidak boleh kosong"
 ],
 "The key password can not be empty": [
  null,
  "Kata sandi kunci tidak boleh kosong"
 ],
 "The key passwords do not match": [
  null,
  "Kata sandi kunci tidak cocok"
 ],
 "Log in to $0": [
  null,
  "Masuk ke $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Tidak dapat masuk ke $0. Host tidak menerima login dengan kata sandi atau salah satu kunci SSH Anda."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi oleh kata sandi, dan host tidak mengizinkan login dengan kata sandi. Harap berikan kata sandi untuk kunci di $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi. Anda dapat masuk dengan kata sandi login Anda atau dengan memberikan kata sandi untuk kunci di $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Buat kunci SSH baru dan otorisasi"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH baru di $0 akan dibuat untuk $1 di $2 dan akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Key password": [
  null,
  "Kata sandi kunci"
 ],
 "Confirm key password": [
  null,
  "Konfirmasi kata sandi kunci"
 ],
 "Authorize SSH key": [
  null,
  "Otorisasi kunci SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH $0 dari $1 di $2 akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Authentication": [
  null,
  "Autentikasi"
 ],
 "SSH key": [
  null,
  "Kunci SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Kunci SSH $0 akan tersedia selama sisa sesi dan dapat digunakan untuk login ke host lain."
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Clear input value": [
  null,
  "Hapus nilai masukan"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format tanggal dan waktu tidak valid"
 ],
 "Invalid time format": [
  null,
  "Format waktu tidak valid"
 ],
 "Invalid date format": [
  null,
  "Format tanggal tidak valid"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tidak dapat menjadwalkan acara di masa lalu"
 ],
 "No delay": [
  null,
  "Tanpa penundaan"
 ],
 "1 minute": [
  null,
  "1 Menit"
 ],
 "5 minutes": [
  null,
  "5 menit"
 ],
 "20 minutes": [
  null,
  "20 Menit"
 ],
 "40 minutes": [
  null,
  "40 Menit"
 ],
 "60 minutes": [
  null,
  "60 Menit"
 ],
 "Specific time": [
  null,
  "Waktu tertentu"
 ],
 "Shut down": [
  null,
  "Matikan"
 ],
 "Reboot": [
  null,
  "Reboot"
 ],
 "Message to logged in users": [
  null,
  "Pesan ke pengguna yang sedang masuk"
 ],
 "Delay": [
  null,
  "Jeda"
 ],
 "Pick date": [
  null,
  "Pilih tanggal"
 ],
 "Toggle date picker": [
  null,
  "Beralih pemilih tanggal"
 ],
 "Synchronized": [
  null,
  "Tersinkronisasi"
 ],
 "Synchronized with $0": [
  null,
  "Tersinkronisasi dengan $0"
 ],
 "Synchronizing": [
  null,
  "Sedang menyinkronkan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Mencoba menyinkronkan dengan $0"
 ],
 "Not synchronized": [
  null,
  "Tidak tersinkronisasi"
 ],
 "Log messages": [
  null,
  "Pesan log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Secara manual"
 ],
 "Automatically using NTP": [
  null,
  "Secara otomatis menggunakan NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Menggunakan server NTP tambahan secara otomatis"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Menggunakan server NTP tertentu secara otomatis"
 ],
 "Time zone": [
  null,
  "Zona waktu"
 ],
 "Set time": [
  null,
  "Atur waktu"
 ],
 "Invalid timezone": [
  null,
  "Zona waktu tidak valid"
 ],
 "Need at least one NTP server": [
  null,
  "Membutuhkan setidaknya satu server NTP"
 ],
 "Change system time": [
  null,
  "Ubah Waktu Sistem"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Path to file": [
  null,
  "Jalur ke berkas"
 ],
 "No such file or directory": [
  null,
  "Tidak ada berkas atau direktori"
 ],
 "Create $0": [
  null,
  "Buat $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Pelajari lebih lanjut"
 ],
 "You now have administrative access.": [
  null,
  "Anda sekarang memiliki akses administratif."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Tidak ada metode untuk mendapatkan akses administratif yang tersedia (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Silakan autentikasi untuk mendapatkan akses administratif"
 ],
 "Switch to administrative access": [
  null,
  "Beralih ke akses administratif"
 ],
 "Authenticate": [
  null,
  "Autentikasi"
 ],
 "Administrative access": [
  null,
  "Akses administratif"
 ],
 "Problem becoming administrator": [
  null,
  "Masalah saat menjadi administrator"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Limit access": [
  null,
  "Batasi akses"
 ],
 "Switch to limited access": [
  null,
  "Beralih ke mode akses terbatas"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Mode akses terbatas membatasi hak administratif. Beberapa bagian dari konsol web akan memiliki fungsionalitas yang terbatas."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Peramban Anda akan mengingat tingkat akses Anda di seluruh sesi."
 ],
 "Limited access": [
  null,
  "Akses terbatas"
 ],
 "Turn on administrative access": [
  null,
  "Aktifkan akses administratif"
 ],
 "$0 year": [
  null,
  "$0 tahun"
 ],
 "$0 month": [
  null,
  "$0 bulan"
 ],
 "$0 week": [
  null,
  "$0 minggu"
 ],
 "$0 day": [
  null,
  "$0 hari"
 ],
 "$0 hour": [
  null,
  "$0 jam"
 ],
 "$0 minute": [
  null,
  "$0 menit"
 ],
 "Go to now": [
  null,
  "Pergi ke sekarang"
 ],
 "1 hour": [
  null,
  "1 jam"
 ],
 "6 hours": [
  null,
  "6 jam"
 ],
 "1 day": [
  null,
  "1 hari"
 ],
 "1 week": [
  null,
  "1 minggu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Gagal mengaktifkan $0 di firewalld"
 ],
 "Visit firewall": [
  null,
  "Kunjungi firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Tambahkan $0"
 ],
 "less than a minute ago": [
  null,
  "kurang dari satu menit yang lalu"
 ],
 "in less than a minute": [
  null,
  "dalam waktu kurang dari satu menit"
 ],
 "Password is too weak": [
  null,
  "Kata sandi terlalu lemah"
 ],
 "Excellent password": [
  null,
  "Sandi bagus"
 ],
 "Password is not acceptable": [
  null,
  "Kata sandi tidak dapat diterima"
 ],
 "Strong password": [
  null,
  "Kata sandi kuat"
 ],
 "Acceptable password": [
  null,
  "Kata sandi dapat diterima"
 ],
 "Weak password": [
  null,
  "Kata sandi lemah"
 ],
 "Show password": [
  null,
  "Tampilkan kata sandi"
 ],
 "Hide password": [
  null,
  "Sembunyikan kata sandi"
 ],
 "password quality": [
  null,
  "kualitas kata sandi"
 ],
 "Show confirmation password": [
  null,
  "Tampilkan konfirmasi kata sandi"
 ],
 "Hide confirmation password": [
  null,
  "Sembunyikan konfirmasi kata sandi"
 ],
 "Additional packages:": [
  null,
  "Paket tambahan:"
 ],
 "Removals:": [
  null,
  "Penghapusan:"
 ],
 "Total size: $0": [
  null,
  "Total ukuran: $0"
 ],
 "Install software": [
  null,
  "Instal perangkat lunak"
 ],
 "$0 will be installed.": [
  null,
  "$0 akan diinstal."
 ],
 "Install": [
  null,
  "Instal"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Menunggu operasi pengelolaan perangkat lunak lain selesai"
 ],
 "Checking installed software": [
  null,
  "Memeriksa perangkat lunak yang terpasang"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 tidak tersedia dari repositori mana pun."
 ],
 "Downloading $0": [
  null,
  "Mengunduh $0"
 ],
 "Removing $0": [
  null,
  "Menghapus $0"
 ],
 "Installing $0": [
  null,
  "Memasang $0"
 ],
 "Unknown host: $0": [
  null,
  "Host tidak dikenal: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Tidak dapat masuk ke $0 menggunakan autentikasi kunci SSH. Harap berikan kata sandi."
 ],
 "SSH key login": [
  null,
  "Login dengan kunci SSH"
 ],
 "[no data]": [
  null,
  "[Tidak ada data]"
 ],
 "[binary data]": [
  null,
  "[data biner]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit berhenti secara mendadak"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit melaporkan kode kesalahan $0"
 ],
 "show less": [
  null,
  "tampilkan lebih sedikit"
 ],
 "show more": [
  null,
  "tampilkan lebih banyak"
 ],
 "Row expansion": [
  null,
  "Perluasan baris"
 ],
 "Row select": [
  null,
  "Pilih baris"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Kesalahan menempel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Peramban Anda tidak mengizinkan tempel dari menu konteks. Anda dapat menggunakan Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Kesalahan saat inisialisasi"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Downloads": [
  null,
  "Unduhan"
 ],
 "Not a directory": [
  null,
  "Bukan direktori"
 ],
 "All files": [
  null,
  "Semua berkas"
 ],
 "Recent": [
  null,
  "Terbaru"
 ],
 "No recent directories": [
  null,
  "Tidak ada direktori terbaru"
 ],
 "No recent files": [
  null,
  "Tidak ada berkas terbaru"
 ],
 "Type to filter": [
  null,
  "Ketik untuk memfilter"
 ],
 "File chooser actions": [
  null,
  "Tindakan pemilih berkas"
 ],
 "Open in file browser": [
  null,
  "Buka di peramban berkas"
 ],
 "Hide hidden files": [
  null,
  "Sembunyikan berkas tersembunyi"
 ],
 "Show hidden files": [
  null,
  "Tampilkan berkas tersembunyi"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Clear filters": [
  null,
  "Hapus filter"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "Directory has no sub-directories": [
  null,
  "Direktori tidak memiliki subdirektori"
 ],
 "This directory contains only hidden files": [
  null,
  "Direktori ini hanya berisi berkas tersembunyi"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "Folder": [
  null,
  "Folder"
 ],
 "File": [
  null,
  "Berkas"
 ],
 "Copy to clipboard": [
  null,
  "Salin ke papan klip"
 ],
 "Automation script": [
  null,
  "Skrip otomatisasi"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Buat berkas tugas baru dengan konten ini."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentasi peran Ansible"
 ],
 "Shell script": [
  null,
  "Skrip shell"
 ],
 "No system modifications": [
  null,
  "Tidak ada modifikasi sistem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Pengguna yang masuk tidak diizinkan melihat modifikasi sistem"
 ],
 "Loading system modifications...": [
  null,
  "Memuat modifikasi sistem..."
 ],
 "View automation script": [
  null,
  "Lihat skrip otomatisasi"
 ],
 "Occurrences": [
  null,
  "Kejadian"
 ],
 "View all logs": [
  null,
  "Lihat semua log"
 ],
 "Other": [
  null,
  "Lainnya"
 ],
 "Unknown": [
  null,
  "Tidak diketahui"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop profil rendah"
 ],
 "Pizza box": [
  null,
  "Casing pipih (Pizza box)"
 ],
 "Mini tower": [
  null,
  "Menara mini"
 ],
 "Tower": [
  null,
  "Menara"
 ],
 "Portable": [
  null,
  "Portabel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Perangkat genggam"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer hemat ruang"
 ],
 "Lunch box": [
  null,
  "Casing kecil"
 ],
 "Main server chassis": [
  null,
  "Chassis server utama"
 ],
 "Expansion chassis": [
  null,
  "Chassis ekspansi"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassis ekspansi bus"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferal"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis rak mount"
 ],
 "Sealed-case PC": [
  null,
  "PC tertutup rapat"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multi-sistem"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Penutup pisau"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Dapat dilepas"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC Embedded"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC stik"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Peringkat tunggal"
 ],
 "Dual rank": [
  null,
  "Peringkat ganda"
 ],
 "Absent": [
  null,
  "Absen"
 ],
 "Present": [
  null,
  "Ada"
 ],
 "Old password not accepted": [
  null,
  "Kata sandi lama tidak diterima"
 ],
 "Failed to change password": [
  null,
  "Gagal mengubah kata sandi"
 ],
 "New password was not accepted": [
  null,
  "Kata sandi baru tidak diterima"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Permintaan melalui ssh-keygen habis waktu"
 ],
 "Not a valid private key": [
  null,
  "Bukan kunci pribadi yang valid"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Permintaan melalui ssh-add habis waktu"
 ],
 "Invalid file permissions": [
  null,
  "Izin berkas tidak valid"
 ],
 "Password not accepted": [
  null,
  "Kata sandi tidak diterima"
 ],
 "Select an option": [
  null,
  "Pilih opsi"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dihentikan dengan sinyal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 keluar dengan kode $1"
 ],
 "$0 failed": [
  null,
  "$0 gagal"
 ],
 "Your session has been terminated.": [
  null,
  "Sesi Anda telah diakhiri."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesi Anda telah kedaluwarsa. Harap login kembali."
 ],
 "Not permitted to perform this action.": [
  null,
  "Tidak diizinkan untuk melakukan tindakan ini."
 ],
 "Login failed": [
  null,
  "Login gagal"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server menolak mengautentikasi menggunakan metode apa pun yang didukung."
 ],
 "Untrusted host": [
  null,
  "Host tidak tepercaya"
 ],
 "Host key is incorrect": [
  null,
  "Kunci host salah"
 ],
 "Internal error": [
  null,
  "Kesalahan internal"
 ],
 "Connection has timed out.": [
  null,
  "Koneksi timeout."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit tidak terpasang pada sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Tidak dapat meneruskan kredensial login"
 ],
 "Server has closed the connection.": [
  null,
  "Server telah menutup koneksi."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit tidak kompatibel dengan perangkat lunak di sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit tidak dapat menghubungi host yang diberikan."
 ],
 "Too much data": [
  null,
  "Terlalu banyak data"
 ],
 "edit": [
  null,
  "ubah"
 ],
 "Loading...": [
  null,
  "Memuat..."
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Delete files": [
  null,
  "Hapus berkas"
 ],
 "Delete $0": [
  null,
  "Hapus $0"
 ],
 "Edit user": [
  null,
  "Edit pengguna"
 ],
 "Log user out": [
  null,
  "Keluarkan pengguna"
 ],
 "Lock account": [
  null,
  "Kunci akun"
 ],
 "Delete account": [
  null,
  "Hapus akun"
 ],
 "Logged in": [
  null,
  "Sudah masuk"
 ],
 "Never logged in": [
  null,
  "Tidak pernah login"
 ],
 "Your account": [
  null,
  "Akun Anda"
 ],
 "Group name": [
  null,
  "Nama grup"
 ],
 "# of users": [
  null,
  "Jumlah pengguna"
 ],
 "Accounts": [
  null,
  "Akun"
 ],
 "Search for name or ID": [
  null,
  "Cari berdasarkan nama atau ID"
 ],
 "Create new group": [
  null,
  "Buat grup baru"
 ],
 "Groups": [
  null,
  "Grup"
 ],
 "$0 more...": [
  null,
  "$0 lainnya..."
 ],
 "Clear filter": [
  null,
  "Hapus filter"
 ],
 "Username": [
  null,
  "Nama pengguna"
 ],
 "Full name": [
  null,
  "Nama Lengkap"
 ],
 "Last active": [
  null,
  "Terakhir aktif"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Actions": [
  null,
  "Tindakan"
 ],
 "Search for name, group or ID": [
  null,
  "Cari berdasarkan nama, grup, atau ID"
 ],
 "Create new account": [
  null,
  "Buat akun baru"
 ],
 "No group name specified": [
  null,
  "Tidak ada nama grup yang ditentukan"
 ],
 "Group name can only consist of letters, digits, dots, dashes, and underscores": [
  null,
  "Nama grup hanya boleh terdiri dari huruf, angka, titik, tanda hubung, dan garis bawah"
 ],
 "A group with this name already exists": [
  null,
  "Grup dengan nama ini sudah ada"
 ],
 "No ID specified": [
  null,
  "Tidak ada ID yang ditentukan"
 ],
 "Group ID must be positive integer": [
  null,
  "ID grup harus berupa bilangan bulat positif"
 ],
 "Create": [
  null,
  "Buat"
 ],
 "New name": [
  null,
  "Nama baru"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Mengganti nama grup dapat memengaruhi aturan sudo dan sejenisnya"
 ],
 "Group name cannot be empty": [
  null,
  "Nama grup tidak boleh kosong"
 ],
 "Rename group $0": [
  null,
  "Ganti nama grup $0"
 ],
 "Rename": [
  null,
  "Ganti nama"
 ],
 "Login history": [
  null,
  "Riwayat login"
 ],
 "Login history list": [
  null,
  "Daftar riwayat login"
 ],
 "Started": [
  null,
  "Dimulai"
 ],
 "Ended": [
  null,
  "Berakhir"
 ],
 "From": [
  null,
  "Dari"
 ],
 "Prompting via passwd timed out": [
  null,
  "Permintaan melalui passwd habis waktu"
 ],
 "You must wait longer to change your password": [
  null,
  "Anda harus menunggu lebih lama untuk mengubah kata sandi Anda"
 ],
 "Old password": [
  null,
  "Kata sandi lama"
 ],
 "Confirm new password": [
  null,
  "Konfirmasi sandi baru"
 ],
 "The passwords do not match": [
  null,
  "Kata sandi tidak cocok"
 ],
 "Password is longer than 256 characters": [
  null,
  "Kata sandi lebih dari 256 karakter"
 ],
 "Set password": [
  null,
  "Atur kata sandi"
 ],
 "Set weak password": [
  null,
  "Atur kata sandi lemah"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Akun '$0' akan dipaksa mengganti kata sandi pada login berikutnya"
 ],
 "Force password change": [
  null,
  "Paksa ubah sandi"
 ],
 "Reset password": [
  null,
  "Atur ulang kata sandi"
 ],
 "Logout $0": [
  null,
  "Keluar $0"
 ],
 "Rename group": [
  null,
  "Ganti nama grup"
 ],
 "Delete group": [
  null,
  "Hapus grup"
 ],
 "Home directory": [
  null,
  "Direktori home"
 ],
 "Path to directory": [
  null,
  "Jalur ke direktori"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "User ID": [
  null,
  "ID pengguna"
 ],
 "Use password": [
  null,
  "Gunakan kata sandi"
 ],
 "Require password change on first login": [
  null,
  "Wajib ganti kata sandi saat login pertama"
 ],
 "Disallow password authentication": [
  null,
  "Larangan autentikasi kata sandi"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Metode autentikasi lain masih tersedia bahkan ketika autentikasi kata sandi interaktif tidak diizinkan."
 ],
 "No user name specified": [
  null,
  "Tidak ada nama pengguna yang ditentukan"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Nama pengguna hanya boleh terdiri dari huruf a-z, angka, titik, tanda hubung, dan garis bawah."
 ],
 "This user name already exists": [
  null,
  "Nama pengguna ini sudah ada"
 ],
 "No real name specified": [
  null,
  "Nama asli belum ditentukan"
 ],
 "The full name must not contain colons.": [
  null,
  "Nama lengkap tidak boleh mengandung tanda titik dua."
 ],
 "User ID must be a positive integer": [
  null,
  "ID pengguna harus berupa bilangan bulat positif"
 ],
 "User ID must not be lower than $0": [
  null,
  "ID pengguna tidak boleh lebih rendah dari $0"
 ],
 "User ID must not be higher than $0": [
  null,
  "ID pengguna tidak boleh lebih tinggi dari $0"
 ],
 "User ID is already used by another user": [
  null,
  "ID pengguna sudah digunakan oleh pengguna lain"
 ],
 "Empty password": [
  null,
  "Sandi kosong"
 ],
 "$0 is an existing file": [
  null,
  "$0 adalah berkas yang sudah ada"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "Direktori home $0 sudah ada. Kepemilikannya akan dialihkan kepada pengguna baru."
 ],
 "Create and change ownership of home directory": [
  null,
  "Buat dan ubah kepemilikan direktori home"
 ],
 "Create account with weak password": [
  null,
  "Buat akun dengan kata sandi lemah"
 ],
 "Create account with non-unique UID": [
  null,
  "Buat akun dengan UID tidak unik"
 ],
 "Never expire password": [
  null,
  "Jangan pernah kedaluwarsa kata sandi"
 ],
 "Password must be changed": [
  null,
  "Kata sandi harus diubah"
 ],
 "Require password change on $0": [
  null,
  "Wajib mengganti kata sandi pada $0"
 ],
 "Never expire account": [
  null,
  "Jangan biarkan akun kedaluwarsa"
 ],
 "Expire account on $0": [
  null,
  "Nonaktifkan akun pada $0"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Akun tidak tersedia atau tidak dapat disunting."
 ],
 "Back to accounts": [
  null,
  "Kembali ke akun"
 ],
 "Never": [
  null,
  "Tidak pernah"
 ],
 "Terminate session": [
  null,
  "Akhiri sesi"
 ],
 "Last login": [
  null,
  "Login terakhir"
 ],
 "Options": [
  null,
  "Opsi"
 ],
 "Disallow interactive password": [
  null,
  "Larangan penggunaan kata sandi interaktif"
 ],
 "Force change": [
  null,
  "Ubah Paksa"
 ],
 "change": [
  null,
  "ubah"
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "Pengguna harus logout dan login ulang agar konfigurasi baru berlaku."
 ],
 "Undo": [
  null,
  "Batalkan"
 ],
 "Permanently delete $0 group?": [
  null,
  "Hapus permanen $0 grup?"
 ],
 "This group is the primary group for the following users:": [
  null,
  "Grup ini adalah grup utama untuk pengguna berikut:"
 ],
 "Force delete": [
  null,
  "Paksa hapus"
 ],
 "Change shell": [
  null,
  "Ubah shell"
 ],
 "Expire account on": [
  null,
  "Nonaktifkan akun pada"
 ],
 "Please specify an expiration date": [
  null,
  "Silakan tentukan tanggal kedaluwarsa"
 ],
 "Invalid expiration date": [
  null,
  "Tanggal kedaluwarsa tidak valid"
 ],
 "Account expiration": [
  null,
  "Kedaluwarsa Akun"
 ],
 "Require password change every $0 days": [
  null,
  "Wajib mengganti kata sandi setiap $0 hari"
 ],
 "Invalid number of days": [
  null,
  "Jumlah hari tidak valid"
 ],
 "Password expiration": [
  null,
  "Kedaluwarsa kata sandi"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Tempel isi berkas kunci SSH publik Anda di sini"
 ],
 "Add public key": [
  null,
  "Tambahkan kunci publik"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Anda tidak memiliki izin untuk melihat kunci publik yang diotorisasi untuk akun ini."
 ],
 "Failed to load authorized keys.": [
  null,
  "Gagal memuat kunci yang diotorisasi."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Tidak ada kunci publik yang diotorisasi untuk akun ini."
 ],
 "Authorized public SSH keys": [
  null,
  "Kunci SSH publik yang diotorisasi"
 ],
 "Unnamed": [
  null,
  "Tanpa nama"
 ],
 "Invalid key": [
  null,
  "Kunci tidak valid"
 ],
 "Error saving authorized keys: ": [
  null,
  "Kesalahan menyimpan kunci yang diotorisasi: "
 ],
 "The key you provided was not valid.": [
  null,
  "Kunci yang Anda berikan tidak valid."
 ],
 "Lock $0": [
  null,
  "Kunci $0"
 ],
 "Lock": [
  null,
  "Kunci"
 ],
 "user": [
  null,
  "pengguna"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsol Web untuk server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit adalah manajer server yang memudahkan administrasi server Linux Anda melalui browser web. Berpindah antara terminal dan alat web tidak menjadi masalah. Layanan yang dijalankan melalui Cockpit dapat dihentikan melalui terminal. Demikian pula, jika terjadi kesalahan di terminal, hal itu dapat dilihat di antarmuka jurnal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit sempurna untuk sysadmin baru, memungkinkan mereka melakukan tugas sederhana dengan mudah seperti administrasi penyimpanan, memeriksa jurnal, serta memulai dan menghentikan layanan. Anda dapat memantau dan mengelola beberapa server sekaligus. Cukup tambahkan dengan satu klik, dan mesin Anda akan saling menjaga."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Setelah Cockpit diinstal, aktifkan dengan \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurasi Cockpit untuk NetworkManager dan Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Alat ini mengelola jaringan seperti bond, bridge, team, VLAN, dan firewall menggunakan NetworkManager dan Firewalld. NetworkManager tidak kompatibel dengan systemd-networkd bawaan Ubuntu dan skrip ifupdown milik Debian."
 ],
 "Manage storage": [
  null,
  "Kelola penyimpanan"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Alat ini mengelola penyimpanan lokal seperti sistem berkas, grup volume LVM2, dan mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kumpulkan dan kemas data diagnostik serta dukungan"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Alat ini menghasilkan arsip berisi informasi konfigurasi dan diagnostik dari sistem yang sedang berjalan. Arsip dapat disimpan secara lokal atau pusat untuk pencatatan atau pelacakan, atau dikirim ke tim dukungan teknis, pengembang, atau administrator sistem untuk membantu dalam analisis kesalahan dan debugging teknis."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfigurasi dan pemecahan masalah Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Alat ini mengonfigurasi kebijakan SELinux dan membantu memahami serta menyelesaikan pelanggaran kebijakan."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kumpulkan dump crash kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Alat ini mengonfigurasi sistem untuk menulis dump crash kernel. Ini mendukung target dump \"local\" (disk), \"ssh\", dan \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasi dengan Konsol Web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentikasi diperlukan untuk melakukan tugas berprivileg dengan Konsol Web Cockpit"
 ]
});
