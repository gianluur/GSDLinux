cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "unmount": [
  null,
  "odpojit (unmount)"
 ],
 "mount": [
  null,
  "mount"
 ],
 "format": [
  null,
  "formátovat"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "souborový systém"
 ],
 "partition": [
  null,
  "oddíl"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "svazek"
 ],
 "disk": [
  null,
  "disk"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "šifrování"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Správa oddílů"
 ],
 "Managing NFS mounts": [
  null,
  "Správa NFS připojení"
 ],
 "Managing RAIDs": [
  null,
  "Správa RAID polí"
 ],
 "Managing LVMs": [
  null,
  "Správa LVM svazků"
 ],
 "Managing physical drives": [
  null,
  "Správa fyzických disků"
 ],
 "Managing VDOs": [
  null,
  "Správa VDO optimalizátorů"
 ],
 "Using LUKS encryption": [
  null,
  "S použitím LUKS šifrování"
 ],
 "Using Tang server": [
  null,
  "S použitím Tang serveru"
 ]
});
