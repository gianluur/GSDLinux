cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Unlock": [
  null,
  "Odblokuj"
 ],
 "Add key": [
  null,
  "Dodaj klucz"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Select": [
  null,
  "Wybierz"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "Set": [
  null,
  "Ustaw"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "Permission denied": [
  null,
  "Odmowa dostępu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "You now have administrative access.": [
  null,
  "Uzyskano dostęp administracyjny."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Proszę się uwierzytelnić, aby uzyskać dostęp administracyjny"
 ],
 "Switch to administrative access": [
  null,
  "Przełącz na dostęp administracyjny"
 ],
 "Authenticate": [
  null,
  "Uwierzytelnij"
 ],
 "Administrative access": [
  null,
  "Dostęp administracyjny"
 ],
 "Problem becoming administrator": [
  null,
  "Problem podczas zostawania administratorem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Ogranicz dostęp"
 ],
 "Switch to limited access": [
  null,
  "Przełącz na ograniczony dostęp"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Tryb ograniczonego dostępu ogranicza uprawnienia administracyjne. Część konsoli internetowej będzie miała zmniejszoną funkcjonalność."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Używana przeglądarka będzie pamiętała poziom dostępu użytkownika między sesjami."
 ],
 "Limited access": [
  null,
  "Ograniczony dostęp"
 ],
 "Turn on administrative access": [
  null,
  "Włącz dostęp administracyjny"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "PackageKit reported error code $0": [
  null,
  "Usługa PackageKit zgłosiła kod błędu $0"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrowanie"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "System plików"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Brak wyników"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Plik"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "View logs": [
  null,
  "Wyświetl dzienniki"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Użycie"
 ],
 "none": [
  null,
  "brak"
 ],
 "Not found": [
  null,
  "Nie odnaleziono"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Running": [
  null,
  "Działające"
 ],
 "Not running": [
  null,
  "Niedziałające"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "Vendor": [
  null,
  "Producent"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "State": [
  null,
  "Stan"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Start": [
  null,
  "Rozpocznij"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Confirm deletion of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Username": [
  null,
  "Nazwa użytkownika"
 ],
 "Actions": [
  null,
  "Działania"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Rename": [
  null,
  "Zmień nazwę"
 ],
 "Started": [
  null,
  "Rozpoczęto"
 ],
 "Delete group": [
  null,
  "Usuń grupę"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Lock": [
  null,
  "Zablokuj"
 ],
 "Service": [
  null,
  "Usługa"
 ],
 "Disconnect": [
  null,
  "Rozłącz"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "$0 disk is missing": [
  null,
  "Brak $0 dysku",
  "Brak $0 dysków",
  "Brak $0 dysków"
 ],
 "Location": [
  null,
  "Położenie"
 ],
 "Compression": [
  null,
  "Kompresja"
 ],
 "Storage logs": [
  null,
  "Dzienniki urządzeń do przechowywania danych"
 ],
 "Name cannot be empty.": [
  null,
  "Nazwa nie może być pusta."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nazwa nie może być dłuższa niż 127 znaków."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nazwa nie może zawierać znaku „$0”."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nazwa nie może zawierać spacji."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nazwa nie może być dłuższa niż $0 znaków"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nazwa nie może być dłuższa niż $0 B"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pula dla cienkich woluminów logicznych"
 ],
 "Thin logical volume": [
  null,
  "Cienki wolumin logiczny"
 ],
 "Logical volume (snapshot)": [
  null,
  "Wolumin logiczny (migawka)"
 ],
 "Logical volume": [
  null,
  "Wolumin logiczny"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupa woluminów LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Urządzenie VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Zaszyfrowany wolumin logiczny $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Zaszyfrowana partycja $0"
 ],
 "Logical volume of $0": [
  null,
  "Wolumin logiczny $0"
 ],
 "Partition of $0": [
  null,
  "Partycja $0"
 ],
 "Encrypted $0": [
  null,
  "Zaszyfrowane $0"
 ],
 "unpartitioned space on $0": [
  null,
  "nieprzydzielone miejsce na $0"
 ],
 "unmount": [
  null,
  "odmontowanie"
 ],
 "mount": [
  null,
  "montowanie"
 ],
 "stop": [
  null,
  "zatrzymaj"
 ],
 "remove from LVM2": [
  null,
  "usuń z LVM2"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Create and mount": [
  null,
  "Utwórz i zamontuj"
 ],
 "Create only": [
  null,
  "Tylko utwórz"
 ],
 "Mount Point": [
  null,
  "Punkt montowania"
 ],
 "delete": [
  null,
  "usuń"
 ],
 "Unmount": [
  null,
  "Odmontuj"
 ],
 "Mount": [
  null,
  "Zamontuj"
 ],
 "Mount point": [
  null,
  "Punkt montowania"
 ],
 "$0 is in use": [
  null,
  "$0 jest używane"
 ],
 "Permanently delete $0?": [
  null,
  "Trwale usunąć $0?"
 ],
 "Label": [
  null,
  "Etykieta"
 ],
 "Capacity": [
  null,
  "Pojemność"
 ],
 "Aborted": [
  null,
  ""
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "Degraded": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Abort test": [
  null,
  ""
 ],
 "Disk is failing": [
  null,
  "Na dysku występują błędy"
 ],
 "Disk is OK": [
  null,
  "Dysk jest OK"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Drive": [
  null,
  "Napęd"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "No media inserted": [
  null,
  "Nie włożono żadnego nośnika"
 ],
 "Device file": [
  null,
  "Plik urządzenia"
 ],
 "Free space": [
  null,
  "Wolne miejsce"
 ],
 "Create partition": [
  null,
  "Utwórz partycję"
 ],
 "Extended partition": [
  null,
  "Rozszerzona partycja"
 ],
 "Partitions": [
  null,
  "Partycje"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Usunięcie partycji usunie wszystkie znajdujące się na niej dane."
 ],
 "No free space after this partition": [
  null,
  "Brak wolnego miejsca po tej partycji"
 ],
 "Partition": [
  null,
  "Partycja"
 ],
 "Shrink": [
  null,
  "Zmniejsz"
 ],
 "Grow": [
  null,
  "Powiększ"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ musi zawierać dokładnie dwa heksadecymalne znaki (od 0 do 9, A do F)."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ musi być w formie NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Zmiana typu partycji może nie pozwolić systemowi się uruchomić."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Ta partycja nie jest całkowicie używana przez swoją zawartość."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Rozmiar partycji to $0. Rozmiar zawartości to $1."
 ],
 "Shrink partition": [
  null,
  "Zmniejsz partycję"
 ],
 "Grow content": [
  null,
  "Powiększ zawartość"
 ],
 "initialize": [
  null,
  "zainicjuj"
 ],
 "Initialize disk $0": [
  null,
  "Zainicjuj dysk $0"
 ],
 "Partitioning": [
  null,
  "Partycjonowanie"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Zgodne ze wszystkimi systemami i urządzeniami (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Zgodne z nowoczesnymi systemami i dyskami twardymi > 2 TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Brak partycjonowania"
 ],
 "Overwrite": [
  null,
  "Zastąp"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Zastąp istniejące dane zerami (wolniejsze)"
 ],
 "Initialize": [
  null,
  "Zainicjuj"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Zainicjowanie usuwa wszystkie dane na dysku."
 ],
 "Device is read-only": [
  null,
  "Urządzenie jest tylko do odczytu"
 ],
 "Create partition table": [
  null,
  "Utwórz tablicę partycji"
 ],
 "Size must be a number": [
  null,
  "Rozmiar musi być liczbą"
 ],
 "Size cannot be zero": [
  null,
  "Rozmiar nie może wynosić zero"
 ],
 "Size cannot be negative": [
  null,
  "Rozmiar nie może być ujemny"
 ],
 "Size is too large": [
  null,
  "Rozmiar jest za duży"
 ],
 "Size must be at least $0": [
  null,
  "Rozmiar musi wynosić co najmniej $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "wolumin fizyczny grupy woluminów LVM2"
 ],
 "backing device for VDO device": [
  null,
  "urządzenie podstawowe urządzenia VDO"
 ],
 "member of Stratis pool": [
  null,
  "element puli Stratis"
 ],
 "device of btrfs volume": [
  null,
  "urządzenie wolumenu btrfs"
 ],
 "This device is currently in use.": [
  null,
  "To urządzenie jest obecnie używane."
 ],
 "Device": [
  null,
  "Urządzenie"
 ],
 "Use": [
  null,
  "Użyj"
 ],
 "Services using the location": [
  null,
  "Usługi używające położenia"
 ],
 "Processes using the location": [
  null,
  "Procesy używające położenia"
 ],
 "Currently in use": [
  null,
  "Obecnie używane"
 ],
 "These changes will be made:": [
  null,
  "Te zmiany zostaną wprowadzone:"
 ],
 "Action": [
  null,
  "Działanie"
 ],
 "Important data might be deleted:": [
  null,
  "Ważne dane mogą zostać usunięte:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Powiązane procesy i usługi zostaną siłowo zatrzymane."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Powiązane procesy zostaną siłowo zatrzymane."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Powiązane usługi zostaną siłowo zatrzymane."
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Potwierdzam że chce stracić te dane na zawsze"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Punkt montowania $0 jest używany przez te procesy:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Polecenie"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Punkt montowania $0 jest używany przez te usługi:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Wymienione procesy i usługi zostaną siłowo zatrzymane."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Wymienione procesy zostaną siłowo zatrzymane."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Wymienione usługi zostaną siłowo zatrzymane."
 ],
 "Sorry": [
  null,
  "Przepraszam"
 ],
 "Usage of $0": [
  null,
  "Użycie $0"
 ],
 "Data used": [
  null,
  "Użyte dane"
 ],
 "Metadata used": [
  null,
  "Użyte metadane"
 ],
 "Use compression": [
  null,
  "Kompresja"
 ],
 "Deduplication": [
  null,
  "Deduplikacja"
 ],
 "Use deduplication": [
  null,
  "Deduplikacja"
 ],
 "Rename volume group": [
  null,
  "Zmień nazwę grupy woluminów"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Usunięcie usuwa wszystkie dane w grupie woluminów."
 ],
 "Create snapshot": [
  null,
  "Utwórz migawkę"
 ],
 "Add disks": [
  null,
  "Dodaj dyski"
 ],
 "Disks": [
  null,
  "Dyski"
 ],
 "No disks are available.": [
  null,
  "Brak dostępnych dysków."
 ],
 "At least one disk is needed.": [
  null,
  "Wymagany jest co najmniej jeden dysk."
 ],
 "No free space": [
  null,
  "Brak wolnego miejsca"
 ],
 "LVM2 volume group": [
  null,
  "Grupa woluminów LVM2"
 ],
 "Create new logical volume": [
  null,
  "Utwórz nowy wolumin logiczny"
 ],
 "No logical volumes": [
  null,
  "Brak woluminów logicznych"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Tej grupie wolumenów brakuje wolumenów fizycznych."
 ],
 "Physical volumes": [
  null,
  "Woluminy fizyczne"
 ],
 "Rename logical volume": [
  null,
  "Zmiana nazwy woluminu logicznego"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Usunięcie woluminu logicznego usunie wszystkie znajdujące się na nim dane."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Nie ma wystarczająco wolnego miejsca które mogło by zostać użyte do naprawy. Przynajmniej $0 które nie jest wykorzystywane przez ten wolumen logiczny jest potrzebne na fizycznych wolumenach."
 ],
 "An additional $0 must be selected": [
  null,
  "Dodatkowe $0 musi zostać wybrane"
 ],
 "Repair": [
  null,
  "Napraw"
 ],
 "Deactivate": [
  null,
  "Dezaktywuj"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Mirrored (RAID 1)": [
  null,
  "Lustrzany (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Ten wolumin logiczny nie jest całkowicie używany przez swoją zawartość."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Rozmiar woluminu to $0. Rozmiar zawartości to $1."
 ],
 "Shrink volume": [
  null,
  "Zmniejsz wolumin"
 ],
 "Layout": [
  null,
  "Układ"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Ten wolumen logiczny stracił trochę swoich wolumenów fizycznych i nie może być dłużej używany. Musisz go usunąć i stworzyć nowy który zajmie jego miejsce."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Ten logiczny wolumen stracił część swoich fizycznych wolumenów ale nie stracił jeszcze żadnych danych. Powinieneś go naprawić aby odzyskał swoją oryginalną redundancje."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Ten logiczny wolumen stracił część swoich fizycznych wolumenów ale nie stracił jeszcze żadnych danych. Powinieneś być w stanie go naprawić."
 ],
 "Stripes": [
  null,
  ""
 ],
 "Create volume group": [
  null,
  "Utwórz grupę woluminów"
 ],
 "LVM2 physical volume": [
  null,
  "Wolumin fizyczny LVM2"
 ],
 "Volume group": [
  null,
  "Grupa woluminów"
 ],
 "Create thin volume": [
  null,
  "Utwórz cienki wolumin"
 ],
 "Not enough space": [
  null,
  "Za mało miejsca"
 ],
 "Activate": [
  null,
  "Aktywuj"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "WEWNĘTRZNY BŁĄD - Ten wolumen logiczny jest zaznaczony jako aktywny i powinien mieć powiązane urządzenie blokowe. Ale, takie urządzenie nie zostało znalezione."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Zainstalowanie $0 usunęłoby $1."
 ],
 "Installing packages": [
  null,
  "Instalowanie pakietów"
 ],
 "Block device for filesystems": [
  null,
  "Urządzenie blokowe dla systemów plików"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pula dla cienko nadzorowanych woluminów"
 ],
 "Linear": [
  null,
  "Liniowy"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Wolumin systemu plików VDO (kompresja/deduplikacja)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Create logical volume": [
  null,
  "Utwórz wolumin logiczny"
 ],
 "Purpose": [
  null,
  "Zastosowanie"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Pakiet $0 zostanie zainstalowany, aby utworzyć urządzenia VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 wymaga parzystej liczby fizycznych wolumenów"
 ],
 "Logical size": [
  null,
  "Rozmiar logiczny"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Oszczędź miejsce kompresując poszczególne bloki za pomocą L4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Oszczędź miejsce przez przechowywanie identycznych bloków danych tylko raz"
 ],
 "Creating VDO device": [
  null,
  "Tworzenie urządzenia VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Ten punkt montowania NFS jest używany. Można zmieniać tylko jego opcje."
 ],
 "NFS mount": [
  null,
  "Punkt montowania NFS"
 ],
 "New NFS mount": [
  null,
  "Nowy punkt montowania NFS"
 ],
 "Server address": [
  null,
  "Adres serwera"
 ],
 "Server cannot be empty.": [
  null,
  "Serwer nie może być pusty."
 ],
 "Path on server": [
  null,
  "Ścieżka na serwerze"
 ],
 "Path on server cannot be empty.": [
  null,
  "Ścieżka na serwerze nie może być pusta."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Ścieżka na serwerze musi zaczynać się od „/”."
 ],
 "Local mount point": [
  null,
  "Lokalny punkt montowania"
 ],
 "Mount point cannot be empty.": [
  null,
  "Punkt montowania nie może być pusty."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Punkt montowania musi zaczynać się od „/”."
 ],
 "Mount options": [
  null,
  "Opcje montowania"
 ],
 "Mount at boot": [
  null,
  "Montowanie podczas uruchamiania"
 ],
 "Mount read only": [
  null,
  "Montowanie tylko do odczytu"
 ],
 "Custom mount options": [
  null,
  "Niestandardowe opcje montowania"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nie można odmontować systemu plików"
 ],
 "Stop and unmount": [
  null,
  "Zatrzymaj i odmontuj"
 ],
 "Unable to remove mount": [
  null,
  "Nie można usunąć punktu montowania"
 ],
 "Stop and remove": [
  null,
  "Zatrzymaj i usuń"
 ],
 "Start multipath": [
  null,
  "Uruchom urządzenie wielościeżkowe"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "W systemie obecne są urządzenia z wieloma ścieżkami, ale usługa urządzeń wielościeżkowych nie jest uruchomiona."
 ],
 "Category": [
  null,
  "Kategoria"
 ],
 "Encryption": [
  null,
  "Szyfrowanie"
 ],
 "Last modified: $0": [
  null,
  "Ostatnia modyfikacja: $0"
 ],
 "Stored passphrase": [
  null,
  "Zachowane hasło"
 ],
 "Encryption options": [
  null,
  "Opcje szyfrowania"
 ],
 "Encryption type": [
  null,
  "Typ szyfrowania"
 ],
 "Cleartext device": [
  null,
  "Urządzenie tekstowe"
 ],
 "yes": [
  null,
  "tak"
 ],
 "Disk passphrase": [
  null,
  "Hasło dysku"
 ],
 "Passphrase cannot be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "Unlocking disk": [
  null,
  "Odblokowywanie dysku"
 ],
 "Checking for $0 package": [
  null,
  "Wyszukiwanie pakietu $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Pakiet $0 musi być zainstalowany."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Pakiet $0 nie jest dostępny w żadnym repozytorium."
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Wyszukiwanie obsługi NBDE w obrazie initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Obraz initrd musi zostać ponownie utworzony."
 ],
 "Regenerating initrd": [
  null,
  "Ponowne tworzenie obrazu initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Dodawanie rd.neednet=1 do wiersza poleceń jądra"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Dodawanie „$0” do opcji systemów plików"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Dodawanie „$0” do opcji szyfrowania"
 ],
 "Enabling $0": [
  null,
  "Włączanie $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Dodaj szyfrowanie dysku dowiązanego sieciowo"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Komputer obecnie nie obsługuje odblokowywania głównego systemu plików za pomocą serwera kluczy Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Komputer obecnie nie obsługuje odblokowywania systemu plików za pomocą serwera kluczy Tang podczas uruchamiania."
 ],
 "These additional steps are necessary:": [
  null,
  "Potrzebne jest wykonanie tych dodatkowych kroków:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zapisanie nowego hasła wymaga odblokowania dysku. Proszę podać obecne hasło dysku."
 ],
 "Fix NBDE support": [
  null,
  "Napraw obsługę NBDE"
 ],
 "Adding key": [
  null,
  "Dodawanie klucza"
 ],
 "Key source": [
  null,
  "Źródło kluczy"
 ],
 "Repeat passphrase": [
  null,
  "Powtórzenie hasła"
 ],
 "Passphrase": [
  null,
  "Hasło"
 ],
 "Tang keyserver": [
  null,
  "Serwer kluczy Tang"
 ],
 "New passphrase": [
  null,
  "Nowe hasło"
 ],
 "Passphrases do not match": [
  null,
  "Hasła się nie zgadzają"
 ],
 "Keyserver address": [
  null,
  "Adres serwera kluczy"
 ],
 "Change passphrase": [
  null,
  "Zmień hasło"
 ],
 "Old passphrase": [
  null,
  "Poprzednie hasło"
 ],
 "Edit Tang keyserver": [
  null,
  "Modyfikuj serwer kluczy Tang"
 ],
 "Verify key": [
  null,
  "Zweryfikuj klucz"
 ],
 "Trust key": [
  null,
  "Zaufaj kluczowi"
 ],
 "Passphrase can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Usunięcie hasła może uniemożliwić odblokowanie $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potwierdź usunięcie alternatywnym hasłem"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Usunięcie hasła bez potwierdzenia innym hasłem może uniemożliwić odblokowywanie lub zarządzanie kluczami, jeśli inne hasła zostaną zapomniane lub utracone."
 ],
 "Passphrase from any other key slot": [
  null,
  "Hasło z jakiegoś innego gniazda na klucze"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Usunąć hasło w gnieździe na klucze $0?"
 ],
 "Remove $0?": [
  null,
  "Usunąć $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Usunąć serwer kluczy Tang?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Obecnie zalogowany użytkownik nie ma zezwolenia na wyświetlanie informacji o kluczach."
 ],
 "No keys added": [
  null,
  "Nie dodano kluczy"
 ],
 "Slot $0": [
  null,
  "Gniazdo $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Modyfikacja klucza wymaga wolnego gniazda"
 ],
 "The last key slot can not be removed": [
  null,
  "Nie można usunąć ostatniego gniazda na klucz"
 ],
 "Keyserver": [
  null,
  "Serwer kluczy"
 ],
 "Unknown type": [
  null,
  "Nieznany typ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nie można modyfikować gniazd na klucze o nieznanym typie w tym miejscu"
 ],
 "Keys": [
  null,
  "Klucze"
 ],
 "$0 slot remains": [
  null,
  "$0 pozostałe gniazdo",
  "$0 pozostałe gniazda",
  "$0 pozostałych gniazd"
 ],
 "No available slots": [
  null,
  "Brak dostępnych gniazd"
 ],
 "No free key slots": [
  null,
  "Brak wolnych gniazd na klucze"
 ],
 "Address cannot be empty": [
  null,
  "Adres nie może być pusty"
 ],
 "Address is not a valid URL": [
  null,
  "Adres nie jest prawidłowym adresem URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Proszę sprawdzić sumę klucza z serwerem Tang."
 ],
 "How to check": [
  null,
  "Jak sprawdzić"
 ],
 "In a terminal, run: ": [
  null,
  "W terminalu należy wykonać: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Pomyślnie skopiowano do schowka."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Proszę sprawdzić, czy suma SHA-256 lub SHA-1 z wiersza poleceń zgadza się z tą w tym oknie."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "subwolumen btrfs $0 wolumenu $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Punkt montowania nie może być pusty"
 ],
 "Mount point is already used for $0": [
  null,
  "Punkt montowania jest już używany dla $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Pod tym punktem montowania są już zamontowane systemy plików."
 ],
 "Please unmount them first.": [
  null,
  "Proszę je najpierw odmontować."
 ],
 "read only": [
  null,
  "tylko do odczytu"
 ],
 "never mount at boot": [
  null,
  "bez montowania podczas uruchamiania"
 ],
 "after network": [
  null,
  "po sieci"
 ],
 "ignore failure": [
  null,
  "ignorowanie niepowodzenia"
 ],
 "stop boot on failure": [
  null,
  "zatrzymanie uruchamiania po niepowodzeniu"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "System plików nie ma trwałego punktu montowania."
 ],
 "The filesystem is not mounted.": [
  null,
  "System plików nie jest zamontowany."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "System plików zostanie odblokowany i zamontowany podczas następnego uruchomienia. Może to wymagać wpisania hasła."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "System plików jest obecnie zamontowany na $0, ale będzie zamontowany na $1 podczas następnego uruchomienia."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montowanie automatycznie na $0 podczas uruchamiania"
 ],
 "Mount on $0 now": [
  null,
  "Zamontuj na $0 teraz"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "System plików nie jest obecnie zamontowany, ale będzie zamontowany podczas następnego uruchomienia."
 ],
 "Do not mount automatically on boot": [
  null,
  "Bez automatycznego montowania podczas uruchamiania"
 ],
 "Mount now": [
  null,
  "Zamontuj teraz"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "System plików jest obecnie zamontowany, ale nie będzie zamontowany po następnym uruchomieniu."
 ],
 "Mount also automatically on boot": [
  null,
  "Montowanie także automatycznie podczas uruchamiania"
 ],
 "Unmount now": [
  null,
  "Odmontuj teraz"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "System plików jest obecnie zamontowany na $0, ale nie będzie zamontowany po następnym uruchomieniu."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "System plików jest skonfigurowany do automatycznego montowania podczas uruchamiania, ale jego kontener szyfrowania nie będzie wtedy odblokowywany."
 ],
 "Unlock automatically on boot": [
  null,
  "Automatyczne odblokowywanie podczas uruchamiania"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Niespójny punkt montowania systemu plików"
 ],
 "Filesystem name": [
  null,
  "Nazwa systemu plików"
 ],
 "Filesystem is locked": [
  null,
  "System plików jest zablokowany"
 ],
 "Mounts before services start": [
  null,
  "Montuje przed uruchomieniem usług"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Odpowiednie dla krytycznych punktów montowania, takich jak /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Uruchomienie się nie powiedzie, jeśli system plików nie jest montowany, uniemożliwiając zdalny dostęp"
 ],
 "Mounts in parallel with services": [
  null,
  "Montuje równolegle z usługami"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Uruchomienie nadal się powiedzie, kiedy system plików nie jest montowany"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Montuje równolegle z usługami, ale po włączeniu sieci"
 ],
 "Does not mount during boot": [
  null,
  "Bez montowania podczas uruchamiania"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Przydatne dla punktów montowania, które są opcjonalne lub potrzebują działania użytkownika (np. hasła)"
 ],
 "At boot": [
  null,
  "Podczas uruchamiania"
 ],
 "Mount before services start": [
  null,
  "Montowanie przed uruchomieniem usług"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montowanie bez czekania, ignorowanie niepowodzenia"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montowanie po włączeniu sieci, ignorowanie niepowodzenia"
 ],
 "Do not mount": [
  null,
  "Bez montowania"
 ],
 "Mount filesystem": [
  null,
  "Zamontuj system plików"
 ],
 "Unmount filesystem $0": [
  null,
  "Odmontuj system plików $0"
 ],
 "Mount configuration": [
  null,
  "Konfiguracja montowania"
 ],
 "Swap": [
  null,
  "Partycja wymiany"
 ],
 "Used": [
  null,
  "Używane"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odblokuj zaszyfrowaną pulę Stratis"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Proszę podać hasło puli na tych urządzeniach blokowych:"
 ],
 "Stratis pool": [
  null,
  "Pula Stratis"
 ],
 "Block devices": [
  null,
  "Urządzenia blokowe"
 ],
 "Pool passphrase": [
  null,
  "Hasło puli"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  ""
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  ""
 ],
 "Create filesystem": [
  null,
  "Utwórz system plików"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Usunięcie puli Stratis usunie wszystkie zawarte w niej dane."
 ],
 "Rename Stratis pool": [
  null,
  "Zmień nazwę puli Stratis"
 ],
 "Add block devices": [
  null,
  "Dodaj urządzenia blokowe"
 ],
 "Tier": [
  null,
  "Warstwa"
 ],
 "Data": [
  null,
  "Dane"
 ],
 "Cache": [
  null,
  "Pamięć podręczna"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  ""
 ],
 "Create new filesystem": [
  null,
  "Utwórz nowy system plików"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Ta pula nie używa całego miejsca na swoich urządzeniach blokowych."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Część urządzeń blokowych tej puli powiększyło się po utworzeniu puli. Można bezpiecznie powiększyć pulę, aby wykorzystać nowo dostępne miejsce."
 ],
 "Grow the pool to take all space": [
  null,
  "Powiększ pulę do użycia całego miejsca"
 ],
 "This pool is in a degraded state.": [
  null,
  "Ta pula jest w stanie zdegradowanym."
 ],
 "No filesystems": [
  null,
  "Brak systemów plików"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "To hasło jest jedynym sposobem na odblokowanie puli i nie może zostać usunięte."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Ten serwer kluczy jest jedynym sposobem na odblokowanie puli i nie może zostać usunięty."
 ],
 "Add passphrase": [
  null,
  "Dodaj hasło"
 ],
 "Add keyserver": [
  null,
  "Dodaj serwer kluczy"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  ""
 ],
 "Confirm": [
  null,
  "Potwierdź"
 ],
 "Remove passphrase?": [
  null,
  "Usunąć hasło?"
 ],
 "Add Tang keyserver": [
  null,
  "Dodaj serwer kluczy Tang"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  ""
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Name can not be empty.": [
  null,
  "Nazwa nie może być pusta."
 ],
 "A pool with this name exists already.": [
  null,
  "Pula o tej nazwie już istnieje."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "System plików o tej nazwie już istnieje w tej puli."
 ],
 "Create Stratis pool": [
  null,
  "Utwórz pulę Stratis"
 ],
 "No block devices are available.": [
  null,
  "Brak dostępnych urządzeń blokowych."
 ],
 "At least one block device is needed.": [
  null,
  "Wymagane jest co najmniej jedno urządzenie blokowe."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Zaszyfruj dane za pomocą hasła"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Zaszyfruj dane za pomocą serwera kluczy Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Utwórz migawkę systemu plików $0"
 ],
 "Create snapshot and mount": [
  null,
  "Utwórz migawkę i zamontuj"
 ],
 "Create snapshot only": [
  null,
  "Tylko utwórz migawkę"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Usunięcie systemu plików usunie wszystkie znajdujące się w nim dane."
 ],
 "Snapshot": [
  null,
  "Migawka"
 ],
 "Rename filesystem": [
  null,
  "Zmień nazwę systemu plików"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Create RAID device": [
  null,
  "Utwórz urządzenie RAID"
 ],
 "RAID level": [
  null,
  "Poziom macierzy RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Striping)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Lustrzany)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Dedykowana parzystość)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Rozproszona parzystość)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Podwójna rozproszona parzystość)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RID 10 (Striping lustrzany)"
 ],
 "Chunk size": [
  null,
  "Rozmiar bloku"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Wymagany jest co najmniej $0 dysk.",
  "Wymagane są co najmniej $0 dyski.",
  "Wymaganych jest co najmniej $0 dysków."
 ],
 "In sync": [
  null,
  "Zsynchronizowane"
 ],
 "Spare": [
  null,
  "Zapasowe"
 ],
 "Recovering": [
  null,
  "Odzyskiwanie"
 ],
 "Write-mostly": [
  null,
  "Głównie zapisywane"
 ],
 "Blocked": [
  null,
  "Zablokowane"
 ],
 "Unknown ($0)": [
  null,
  "Nieznane ($0)"
 ],
 "Need a spare disk": [
  null,
  "Potrzeba wolnego dysku"
 ],
 "Confirm stopping of $0": [
  null,
  "Potwierdź zatrzymanie $0"
 ],
 "Stop device": [
  null,
  "Zatrzymaj urządzenie"
 ],
 "Add disk": [
  null,
  "Dodaj dysk"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "Dyski: $0"
 ],
 "$0 chunk size": [
  null,
  "Rozmiar bloku: $0"
 ],
 "Add a bitmap": [
  null,
  "Dodaj mapę bitową"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Usunięcie usuwa wszystkie dane na urządzeniu VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Utworzenie tego urządzenia VDO nie zostało ukończone, więc nie można go używać."
 ],
 "Remove device": [
  null,
  "Usuń urządzenie"
 ],
 "Grow to take all space": [
  null,
  "Powiększ do użycia całego miejsca"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "To urządzenie VDO nie używa całości swojego urządzenia podstawowego."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Tylko $0 z $1 jest używane."
 ],
 "Grow logical size of $0": [
  null,
  "Powiększ rozmiar logiczny $0"
 ],
 "Physical": [
  null,
  "Fizyczny"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 danych + $1 nadwyżki użyto z $2 ($3)"
 ],
 "Logical": [
  null,
  "Logiczny"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 używanych z $1 ($2 zapisano)"
 ],
 "Index memory": [
  null,
  "Pamięć indeksu"
 ],
 "SMART self-test of $target": [
  null,
  "Test SMART $target"
 ],
 "Ejecting $target": [
  null,
  "Wysuwanie $target"
 ],
 "Unlocking $target": [
  null,
  "Odblokowywanie $target"
 ],
 "Locking $target": [
  null,
  "Blokowanie $target"
 ],
 "Modifying $target": [
  null,
  "Modyfikowanie $target"
 ],
 "Resizing $target": [
  null,
  "Zmienianie rozmiaru $target"
 ],
 "Starting swapspace $target": [
  null,
  "Uruchamianie przestrzeni wymiany $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Zatrzymywanie przestrzeni wymiany $target"
 ],
 "Mounting $target": [
  null,
  "Montowanie $target"
 ],
 "Unmounting $target": [
  null,
  "Odmontowywanie $target"
 ],
 "Checking $target": [
  null,
  "Sprawdzanie $target"
 ],
 "Repairing $target": [
  null,
  "Naprawianie $target"
 ],
 "Erasing $target": [
  null,
  "Czyszczenie $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Tworzenie systemu plików w $target"
 ],
 "Setting up loop device $target": [
  null,
  "Ustawianie urządzenia zwrotnego $target"
 ],
 "Deleting $target": [
  null,
  "Usuwanie $target"
 ],
 "Creating partition $target": [
  null,
  "Tworzenie partycji $target"
 ],
 "Cleaning up for $target": [
  null,
  "Czyszczenie dla $target"
 ],
 "Securely erasing $target": [
  null,
  "Bezpieczne usuwanie zawartości $target"
 ],
 "Very securely erasing $target": [
  null,
  "Bardzo bezpieczne usuwanie zawartości $target"
 ],
 "Marking $target as faulty": [
  null,
  "Oznaczanie $target jako wadliwe"
 ],
 "Activating $target": [
  null,
  "Aktywowanie $target"
 ],
 "Deactivating $target": [
  null,
  "Dezaktywowanie $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Tworzenie migawki $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Tworzenie grupy woluminów LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Usuwanie grupy woluminów LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Dodawanie woluminu fizycznego do $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Usuwanie woluminu fizycznego z $target"
 ],
 "Emptying $target": [
  null,
  "Opróżnianie $target"
 ],
 "Creating logical volume $target": [
  null,
  "Tworzenie woluminu logicznego $target"
 ],
 "Renaming $target": [
  null,
  "Zmienianie nazwy $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Działanie „$operation” na $target"
 ],
 "unknown target": [
  null,
  "nieznany cel"
 ],
 "Jobs": [
  null,
  "Zadania"
 ],
 "Reading": [
  null,
  "Odczytywanie"
 ],
 "Writing": [
  null,
  "Zapisywanie"
 ],
 "Install Stratis support": [
  null,
  "Zainstaluj obsługę Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Pakiet $0 musi być zainstalowany, aby tworzyć pule Stratis."
 ],
 "Install NFS support": [
  null,
  "Zainstaluj obsługę NFS"
 ],
 "Create LVM2 volume group": [
  null,
  "Utwórz grupę woluminów LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Zmień nazwę inicjatora iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Dodaj portal iSCSI"
 ],
 "Server address cannot be empty.": [
  null,
  "Adres serwera nie może być pusty."
 ],
 "Next": [
  null,
  "Dalej"
 ],
 "Invalid username or password": [
  null,
  "Nieprawidłowa nazwa użytkownika lub hasło"
 ],
 "Unknown host name": [
  null,
  "Nieznana nazwa komputera"
 ],
 "Unable to reach server": [
  null,
  "Nie można połączyć się z serwerem"
 ],
 "Available targets on $0": [
  null,
  "Dostępne cele w $0"
 ],
 "Authentication required": [
  null,
  "Wymagane jest uwierzytelnienie"
 ],
 "Target": [
  null,
  "Cel"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Urządzenia podstawowe VDO nie mogą być zmniejszane"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Urządzenia blokowe Stratis nie mogą być zmniejszane"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nie można tutaj zmniejszać nieznanych danych."
 ],
 "Unlock before resizing": [
  null,
  "Odblokuj przed zmianą rozmiaru"
 ],
 "Activate before resizing": [
  null,
  "Aktywuj przed zmianą rozmiaru"
 ],
 "Grow logical volume": [
  null,
  "Powiększ wolumin logiczny"
 ],
 "Grow partition": [
  null,
  "Powiększ partycję"
 ],
 "grow": [
  null,
  "powiększ"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Dokładnie $0 fizycznych wolumenów musi zostać wybranych"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zmiana rozmiaru zaszyfrowanego systemu plików wymaga odblokowania dysku. Proszę podać obecne hasło dysku."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Shrink logical volume": [
  null,
  "Zmniejsz wolumin logiczny"
 ],
 "shrink": [
  null,
  "zmniejsz"
 ],
 "Block device": [
  null,
  "Urządzenie blokowe"
 ],
 "Create partition on $0": [
  null,
  "Utwórz partycję na $0"
 ],
 "Format $0": [
  null,
  "Sformatuj $0"
 ],
 "No filesystem": [
  null,
  "Brak systemu plików"
 ],
 "(recommended)": [
  null,
  "(zalecane)"
 ],
 "No encryption": [
  null,
  "Bez szyfrowania"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Ponowne użycie istniejącego szyfrowania ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Ponowne użycie istniejącego szyfrowania"
 ],
 "format": [
  null,
  "format"
 ],
 "Format and mount": [
  null,
  "Sformatuj i zamontuj"
 ],
 "Format only": [
  null,
  "Tylko sformatuj"
 ],
 "Format": [
  null,
  "Sformatuj"
 ],
 "Store passphrase": [
  null,
  "Przechowaj hasło"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Sformatowanie usuwa wszystkie dane na urządzeniu do przechowywania danych."
 ],
 "Unrecognized data": [
  null,
  "Nierozpoznane dane"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Urządzenia do przechowywania danych nie mogą być zarządzane na tym systemie."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "B"
 ]
});
