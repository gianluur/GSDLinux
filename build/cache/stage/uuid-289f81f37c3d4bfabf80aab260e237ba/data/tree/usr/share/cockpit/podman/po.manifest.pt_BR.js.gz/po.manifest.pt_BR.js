cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Contêineres do Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "contêiner"
 ],
 "image": [
  null,
  "imagem"
 ]
});
