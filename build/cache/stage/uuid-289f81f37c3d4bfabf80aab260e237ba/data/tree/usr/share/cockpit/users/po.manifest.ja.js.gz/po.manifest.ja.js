cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Accounts": [
  null,
  "アカウント"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "パスワード"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "ユーザー名"
 ],
 "login": [
  null,
  "ログイン"
 ],
 "access": [
  null,
  "アクセス"
 ],
 "roles": [
  null,
  "ロール"
 ],
 "keys": [
  null,
  "鍵"
 ],
 "Managing user accounts": [
  null,
  "ユーザーアカウント管理"
 ]
});
