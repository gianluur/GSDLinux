cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Explorador de archivos"
 ],
 "files": [
  null,
  "archivos"
 ],
 "explorer": [
  null,
  "explorador"
 ],
 "filesystem": [
  null,
  "sistema de archivos"
 ]
});
