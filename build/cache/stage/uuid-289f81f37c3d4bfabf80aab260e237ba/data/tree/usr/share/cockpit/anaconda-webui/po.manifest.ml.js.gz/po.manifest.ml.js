cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ml",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
