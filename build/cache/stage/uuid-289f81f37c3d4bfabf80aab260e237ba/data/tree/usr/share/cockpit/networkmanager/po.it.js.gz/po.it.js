cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "Password": [
  null,
  "Password"
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Copy": [
  null,
  "copia"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Public key": [
  null,
  "Chiave pubblica"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "Connect": [
  null,
  "Connetti"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "Trust and add host": [
  null,
  "Considera attendibile e aggiungi host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'impronta digitale risultante può essere condivisa tramite metodi pubblici, inclusa l'email. Se chiedi a qualcun altro di eseguire la verifica per te, può inviare i risultati utilizzando qualsiasi metodo."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta."
 ],
 "Verify fingerprint": [
  null,
  "Verifica impronta digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "The fingerprint should match:": [
  null,
  "L'impronta digitale dovrebbe corrispondere a:"
 ],
 "The password can not be empty": [
  null,
  "La password non può essere vuota"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossibile accedere a $0. L'host non accetta l'accesso con password né alcuna delle tue chiavi SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta da password e l'host non consente l'accesso con password. Fornire la password della chiave $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta. Puoi accedere con la tua password di accesso o fornendo la password della chiave $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La chiave SSH $0 di $1 su $2 verrà aggiunta al file $3 di $4 su $5."
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La chiave SSH $0 sarà resa disponibile per il resto della sessione e sarà utilizzabile anche per l'accesso ad altri host."
 ],
 "Disconnected": [
  null,
  "Disconnesso"
 ],
 "Permission denied": [
  null,
  "Permesso negato"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change": [
  null,
  "Modifica"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nessun metodo per ottenere l'accesso amministrativo è disponibile (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Switch to administrative access": [
  null,
  "Passa all'accesso amministrativo"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema diventando amministratore"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld$0"
 ],
 "Visit firewall": [
  null,
  "Vai al firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "less than a minute ago": [
  null,
  "meno di un minuto fa"
 ],
 "in less than a minute": [
  null,
  "in meno di un minuto"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Weak password": [
  null,
  "Password debole"
 ],
 "Show password": [
  null,
  "Mostra la password"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "password quality": [
  null,
  "qualità password"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Removing $0": [
  null,
  "Rimozione di $0"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Unknown host: $0": [
  null,
  "Host sconosciuto: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossibile accedere a $0 usando l'autenticazione con chiave SSH. Fornire la password."
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Error during initialization": [
  null,
  "Si e verificato un errore durante l'inizializzazione"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Home": [
  null,
  "Home"
 ],
 "Downloads": [
  null,
  "Scaricati"
 ],
 "Not a directory": [
  null,
  "Non è una cartella"
 ],
 "All files": [
  null,
  "Tutti i file"
 ],
 "Recent": [
  null,
  "Recenti"
 ],
 "No recent directories": [
  null,
  "Nessuna cartella recente"
 ],
 "No recent files": [
  null,
  "Nessun file recente"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "File chooser actions": [
  null,
  "Azioni per scegliere il file"
 ],
 "Open in file browser": [
  null,
  "Aprire in un esploratore dei file"
 ],
 "Hide hidden files": [
  null,
  "Nascondi file nascosti"
 ],
 "Show hidden files": [
  null,
  "Mostra file nascosti"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Clear filters": [
  null,
  "Cancella filtri"
 ],
 "Directory is empty": [
  null,
  "La cartella è vuota"
 ],
 "Directory has no sub-directories": [
  null,
  "La cartella non ha sotto-cartelle"
 ],
 "This directory contains only hidden files": [
  null,
  "Questa cartella contiene soltanto file nascosti"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "Folder": [
  null,
  "Cartella"
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "View all logs": [
  null,
  "Visualizza tutti i log"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Priority": [
  null,
  "Priorità"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Generated": [
  null,
  "Generato"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Start service": [
  null,
  "Avvia il servizio"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Delete $0": [
  null,
  "Cancella $0"
 ],
 "Group": [
  null,
  "Gruppo"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Not available": [
  null,
  "Non disponibile"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Permanent": [
  null,
  "Permanente"
 ],
 "Preserve": [
  null,
  "Preserva"
 ],
 "Random": [
  null,
  "Casuale"
 ],
 "Stable": [
  null,
  "Stabile"
 ],
 "Use $0": [
  null,
  "Usa $0"
 ],
 "Failed to save settings": [
  null,
  "Impossibile salvare le impostazioni"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La creazione di questo $0 interromperà la connessione al server e renderà non disponibile l'interfaccia utente di amministrazione."
 ],
 "Create it": [
  null,
  "Crea"
 ],
 "Invalid prefix $0": [
  null,
  "Prefisso $0 non valido"
 ],
 "Invalid metric $0": [
  null,
  "Metrica $0 non valida"
 ],
 "Invalid address $0": [
  null,
  "Indirizzo $0 non valido"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefisso o maschera di rete non valido $0"
 ],
 "Testing connection": [
  null,
  "Test connessione"
 ],
 "Restoring connection": [
  null,
  "Ripristino della connessione"
 ],
 "Troubleshoot…": [
  null,
  "Risoluzione problemi…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager non è in esecuzione"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager non è installato"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "I dispositivi di rete e i grafici richiedono NetworkManager"
 ],
 "Enable service": [
  null,
  "Attiva il servizio"
 ],
 "Network interface '$0' not found": [
  null,
  "Interfaccia di rete '$0' non trovata"
 ],
 "Return to overview page": [
  null,
  "Torna alla pagina panoramica"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Non sei autorizzato a modificare il firewall."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Non autorizzato a disabilitare il firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Non autorizzato ad abilitare il firewall"
 ],
 "Disable the firewall": [
  null,
  "Disabilita il firewall"
 ],
 "Enable the firewall": [
  null,
  "Abilita il firewall"
 ],
 "Edit service $0": [
  null,
  "Modifica servizio $0"
 ],
 "Remove service $0": [
  null,
  "Rimuovere il servizio $0"
 ],
 "Included Services": [
  null,
  "Servizi Inclusi"
 ],
 "Additional port": [
  null,
  "Porta aggiuntiva"
 ],
 "Remove additional port": [
  null,
  "Rimuovere la porta aggiuntiva"
 ],
 "Remove zone $0": [
  null,
  "Rimuovere la zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Aggiungi servizi alla zona $0"
 ],
 "Add services": [
  null,
  "Aggiungi Servizi"
 ],
 "Service": [
  null,
  "Servizio"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "Zona $0"
 ],
 "Interface": [
  null,
  "Interfaccia",
  "Interfacce"
 ],
 "Allowed addresses": [
  null,
  "Indirizzi consentiti"
 ],
 "Entire subnet": [
  null,
  "Intera sottorete"
 ],
 "There are no active services in this zone": [
  null,
  "Non ci sono servizi attivi in questa zona"
 ],
 "Filter services": [
  null,
  "Filtra Servizi"
 ],
 "Failed to edit service": [
  null,
  "Impossibile modificare il servizio"
 ],
 "Failed to add port": [
  null,
  "Impossibile aggiungere la porta"
 ],
 "Failed to add service": [
  null,
  "Impossibile aggiungere il servizio"
 ],
 "Unknown service name": [
  null,
  "Nome del servizio sconosciuto"
 ],
 "Invalid port number": [
  null,
  "Numero porta non valido"
 ],
 "Invalid range": [
  null,
  "Intervallo non valido"
 ],
 "Range must be strictly ordered": [
  null,
  "L'intervallo deve essere rigorosamente ordinato"
 ],
 "Edit service": [
  null,
  "Modifica servizio"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modifica servizi personalizzati nella zona $0"
 ],
 "Add ports": [
  null,
  "Aggiungi Porte"
 ],
 "Add ports to $0 zone": [
  null,
  "Aggiungi porte alla zona $0"
 ],
 "Add services to $0 zone": [
  null,
  "Aggiungi servizi alla zona $0"
 ],
 "Custom ports": [
  null,
  "Porte personalizzate"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Esempio: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Sono accettate porte, intervalli e servizi separati da virgole"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Esempio: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Se lasciato vuoto, l'ID verrà generato in base alla porta dei servizi associati e ai numeri di porta"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Aggiungere porte personalizzate ricaricherà firewalld. Un ricaricamento provocherà la perdita di qualsiasi configurazione non persistente!"
 ],
 "Failed to add zone": [
  null,
  "Impossibile aggiungere la zona"
 ],
 "Add zone": [
  null,
  "Aggiungi zona"
 ],
 "Trust level": [
  null,
  "Livello di fedeltà"
 ],
 "Sorted from least to most trusted": [
  null,
  "Ordinati dal meno affidabile al più affidabile"
 ],
 "Custom zones": [
  null,
  "Zone personalizzate"
 ],
 "No description available": [
  null,
  "Nessuna descrizione disponibile"
 ],
 "Included services": [
  null,
  "Servizi inclusi"
 ],
 "The cockpit service is automatically included": [
  null,
  "Il servizio cockpit è incluso automaticamente"
 ],
 "Interfaces": [
  null,
  "Interfacce"
 ],
 "Range": [
  null,
  "Intervallo"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Indirizzo IP con prefisso di routing. Separare più valori con una virgola. Esempio: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Conferma la rimozione di $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Questa zona contiene il servizio cockpit. Assicurarsi che questa zona non si applichi all'attuale connessione della Web Console."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "La rimozione della zona rimuoverà tutti i servizi al suo interno."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "La rimozione del servizio cockpit potrebbe rendere irraggiungibile la Web Console. Assicurarsi che questa zona non si applichi alla corrente connessione alla Web Console."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Rimuovere il servizio $0 dalla zona $1"
 ],
 "Firewall is not available": [
  null,
  "Il firewall non è disponibile"
 ],
 "Please install the $0 package": [
  null,
  "Installare il pacchetto $0"
 ],
 "Add a new zone": [
  null,
  "Aggiungi una nuova zona"
 ],
 "Add new zone": [
  null,
  "Aggiungi una nuova zona"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Le richieste in ingresso sono bloccate per impostazione predefinita. Le richieste in uscita non sono bloccate."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "Il nome non può essere vuoto"
 ],
 "Password can not be empty": [
  null,
  "La password non può essere vuota"
 ],
 "Failed to connect": [
  null,
  "Impossibile connettersi"
 ],
 "Check your password.": [
  null,
  "Password della chiave."
 ],
 "Connect to hidden network": [
  null,
  "Connetti a rete nascosta"
 ],
 "Connect to $0": [
  null,
  "Connettersi a $0"
 ],
 "Network name": [
  null,
  "Nome della rete"
 ],
 "Security": [
  null,
  "Sicurezza"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L'eliminazione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L'attivazione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Switch on $0": [
  null,
  "Accendi $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La disattivazione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Switch off $0": [
  null,
  "Spegni $0"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Team": [
  null,
  "Team"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Bridge"
 ],
 "Unknown \"$0\"": [
  null,
  "Sconosciuto \"$0\""
 ],
 "Carrier": [
  null,
  "Carrier"
 ],
 "Yes": [
  null,
  "Sì"
 ],
 "No": [
  null,
  "No"
 ],
 "Inactive": [
  null,
  "Inattiva"
 ],
 "Unknown configuration": [
  null,
  "Configurazione sconosciuta"
 ],
 "Additional address $val": [
  null,
  "Indirizzo aggiuntivo $val"
 ],
 "Address $val": [
  null,
  "Indirizzo $val"
 ],
 "Gateway $gateway": [
  null,
  "Portale $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS aggiuntivo $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domini di ricerca DNS aggiuntivi $val"
 ],
 "DNS search domains $val": [
  null,
  "Domini di ricerca DNS $val"
 ],
 "General": [
  null,
  "Generale"
 ],
 "Connect automatically": [
  null,
  "Connessione automatica"
 ],
 "Automatic": [
  null,
  "Automatico"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Monitoraggio ARP"
 ],
 "Broken configuration": [
  null,
  "Configurazione errata"
 ],
 "Team port": [
  null,
  "Porta team"
 ],
 "Spanning tree protocol": [
  null,
  "Protocollo spanning tree"
 ],
 "Priority $priority": [
  null,
  "Priorità $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Ritardo in avanti $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Ciao tempo $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Età massima del messaggio $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Costo della traiettoria $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Modalità hairpin"
 ],
 "Bridge port": [
  null,
  "Porta del bridge"
 ],
 "Parent $parent": [
  null,
  "Genitore $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "La password di rete non è memorizzata. Dimentica e riconnettiti a questa rete."
 ],
 "Failed to connect to $0": [
  null,
  "Impossibile connetersi a $0"
 ],
 "secured": [
  null,
  "protetta"
 ],
 "open": [
  null,
  "aperto"
 ],
 "Last connected: $0": [
  null,
  "Ultima connessione: $0"
 ],
 "Signal strength": [
  null,
  "Potenza del segnale"
 ],
 "Not permitted to disconnect network": [
  null,
  "Disconnessione dalla rete non consentita"
 ],
 "Disconnect": [
  null,
  "Disconnetti"
 ],
 "Not permitted to connect to network": [
  null,
  "Connessione alla rete non consentita"
 ],
 "Forget": [
  null,
  "Dimentica"
 ],
 "$0 hidden network": [
  null,
  "$0 rete nascosta",
  "$0 reti nascoste"
 ],
 "Filter": [
  null,
  "Filtri"
 ],
 "Refresh": [
  null,
  "Aggiorna"
 ],
 "Available networks": [
  null,
  "Reti disponibili"
 ],
 "Network": [
  null,
  "Rete"
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Signal": [
  null,
  "Segnale"
 ],
 "Rate": [
  null,
  "Rate"
 ],
 "Not permitted to configure network devices": [
  null,
  "Non è consentito configurare i dispositivi di rete"
 ],
 "Enable or disable the device": [
  null,
  "Abilita o disabilita il dispositivo"
 ],
 "This device cannot be managed here.": [
  null,
  "Questo dispositivo non può essere gestito qui."
 ],
 "Connection will be lost": [
  null,
  "La connessione andrà persa"
 ],
 "Keep connection": [
  null,
  "Mantenere la connessione"
 ],
 "Invalid IP address: $0": [
  null,
  "Indirizzo IP non valido: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Indirizzo di destinazione non valido: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Indirizzo gateway non valido: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Indirizzo DNS non valido: $0"
 ],
 "Preparing": [
  null,
  "Preparazione"
 ],
 "Configuring": [
  null,
  "Configurazione"
 ],
 "Authenticating": [
  null,
  "Autenticazione"
 ],
 "Configuring IP": [
  null,
  "Configurazione dell'IP"
 ],
 "Checking IP": [
  null,
  "Controllo dell'IP"
 ],
 "Waiting": [
  null,
  "In attesa"
 ],
 "Active": [
  null,
  "Attivo"
 ],
 "Deactivating": [
  null,
  "Disattivazione"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infrastruttura"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Nessun carrier"
 ],
 "Part of $0": [
  null,
  "Parte di $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La modifica delle impostazioni interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Change the settings": [
  null,
  "Modifica le impostazioni"
 ],
 "Add bridge": [
  null,
  "Aggiungi bridge"
 ],
 "Edit bridge settings": [
  null,
  "Modifica le impostazioni del bridge"
 ],
 "Ports": [
  null,
  "Porte"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocollo dello spanning tree (STP)"
 ],
 "STP priority": [
  null,
  "Priorità STP"
 ],
 "STP forward delay": [
  null,
  "Ritardo in avanti STP"
 ],
 "STP hello time": [
  null,
  "Ciao tempo STP"
 ],
 "STP maximum message age": [
  null,
  "Età massima del messaggio STP"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Backup attivo"
 ],
 "Load balancing": [
  null,
  "Bilanciamento del carico"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passivo"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "ping NSNA"
 ],
 "Add team": [
  null,
  "Aggiungi team"
 ],
 "Edit team settings": [
  null,
  "Modifica le impostazioni della squadra"
 ],
 "Runner": [
  null,
  "Esecutore"
 ],
 "Balancer": [
  null,
  "Equilibratore"
 ],
 "Primary": [
  null,
  "Primario"
 ],
 "Link watch": [
  null,
  "Link watch"
 ],
 "Link up delay": [
  null,
  "Ritardo ripristino collegamento"
 ],
 "Link down delay": [
  null,
  "Ritardo caduta collegamento"
 ],
 "Ping interval": [
  null,
  "Intervallo ping"
 ],
 "Ping target": [
  null,
  "Target ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatico (solo DHCP)"
 ],
 "Link local": [
  null,
  "Collegamento locale"
 ],
 "Manual": [
  null,
  "Manuale"
 ],
 "Shared": [
  null,
  "Condiviso"
 ],
 "Prefix length or netmask": [
  null,
  "Lunghezza prefisso o maschera di rete"
 ],
 "Prefix length": [
  null,
  "Lunghezza prefisso"
 ],
 "IPv4 settings": [
  null,
  "Impostazioni IPv4"
 ],
 "IPv6 settings": [
  null,
  "Impostazioni IPv6"
 ],
 "Addresses": [
  null,
  "Indirizzi"
 ],
 "Select method": [
  null,
  "Seleziona metodo"
 ],
 "Add address": [
  null,
  "Aggiungi indirizzo"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "Remove item": [
  null,
  "Rimuovi elemento"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Aggiungi server DNS"
 ],
 "DNS search domains": [
  null,
  "Domini di ricerca DNS"
 ],
 "Add search domain": [
  null,
  "Aggiungi dominio di ricerca"
 ],
 "Search domain": [
  null,
  "dominio di ricerca"
 ],
 "Routes": [
  null,
  "Rotte"
 ],
 "Add route": [
  null,
  "Aggiungi percorso"
 ],
 "Metric": [
  null,
  "Metriche"
 ],
 "Enter a valid MAC address": [
  null,
  "Immettere un indirizzo MAC valido"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "Rete $0",
  "RetI $0"
 ],
 "Add VPN": [
  null,
  "Aggiungi VPN"
 ],
 "Add bond": [
  null,
  "Aggiungi bond"
 ],
 "Add VLAN": [
  null,
  "Aggiungi VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Modifica regole e zone"
 ],
 "$0 active zone": [
  null,
  "zona attiva $0",
  "zona attive $0"
 ],
 "Managed interfaces": [
  null,
  "Interfacce gestite"
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "Sending": [
  null,
  "Invio"
 ],
 "Receiving": [
  null,
  "Ricevo"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfacce non gestite"
 ],
 "Network logs": [
  null,
  "Log di rete"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Gli indirizzi non sono formattati correttamente"
 ],
 "Invalid IP address '$0'": [
  null,
  "Indirizzo IP non valido '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "il pacchetto wireguard-tools non è installato"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Il peer #$0 ha un endpoint non valido. Deve essere specificato come host:porta, ad esempio 1.2.3.4:51820, [2001:db8::1]:51820 o example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Il peer #$0 ha una porta endpoint non valida. La porta deve essere un numero."
 ],
 "Listen port must be a number": [
  null,
  "La porta di ascolto deve essere un numero"
 ],
 "Add WireGuard VPN": [
  null,
  "Aggiungi WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Modifica VPN WireGuard"
 ],
 "Private key": [
  null,
  "Chiave privata"
 ],
 "Paste existing key": [
  null,
  "Incolla la chiave esistente"
 ],
 "Regenerate": [
  null,
  "Rigenerare"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "La chiave pubblica verrà generata quando viene inserita una chiave privata valida"
 ],
 "Listen port": [
  null,
  "Ascolta la porta"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Verrà impostato su \"Automatico\""
 ],
 "IP addresses": [
  null,
  "Indirizzi IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "È possibile specificare più indirizzi utilizzando virgole o spazi come delimitatori."
 ],
 "Peers": [
  null,
  "Peer"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "I peer sono altre macchine che si connettono a questa. Le chiavi pubbliche di altre macchine verranno condivise tra loro."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "L'endpoint che funge da \"server\" deve essere specificato come host:porta, altrimenti può essere lasciato vuoto."
 ],
 "Add peer": [
  null,
  "Aggiungi peer"
 ],
 "Endpoint": [
  null,
  "Endpoint"
 ],
 "Allowed IPs": [
  null,
  "IP consentiti"
 ],
 "No peers added.": [
  null,
  "Nessun peer aggiunto."
 ],
 "Edit VLAN settings": [
  null,
  "Modifica le impostazioni VLAN"
 ],
 "Parent": [
  null,
  "Genitore"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "Trasmissione"
 ],
 "MTU must be a positive number": [
  null,
  "MTU deve essere un numero positivo"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Imposta a"
 ],
 "Team port settings": [
  null,
  "Impostazioni della porta del team"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "LACP key": [
  null,
  "Chiave LACP"
 ],
 "Bridge port settings": [
  null,
  "Impostazioni della porta del bridge"
 ],
 "Path cost": [
  null,
  "Costo percorso"
 ],
 "Hair pin mode": [
  null,
  "Modalità hairpin"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Bilanciamento del carico di trasmissione adattivo"
 ],
 "Adaptive load balancing": [
  null,
  "Bilanciamento del carico adattivo"
 ],
 "MII (recommended)": [
  null,
  "MII (consigliato)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Modifica le impostazioni dei bond"
 ],
 "Network bond": [
  null,
  "Bond di Rete"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Un bond di rete combina più interfacce di rete in un'unica interfaccia con portata del canale o ridondanza più elevati."
 ],
 "Link monitoring": [
  null,
  "Monitoraggio dei collegamenti"
 ],
 "Monitoring interval": [
  null,
  "Intervallo di monitoraggio"
 ],
 "Monitoring targets": [
  null,
  "Obiettivi di monitoraggio"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La rimozione di $0 interromperà la connessione al server e renderà l'interfaccia utente di amministrazione non disponibile."
 ],
 "Remove $0": [
  null,
  "Rimuovere $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L'aggiunta di $0 interromperà la connessione al server e renderà non disponibile l'interfaccia utente di amministrazione."
 ],
 "No interfaces available": [
  null,
  "Nessuna interfaccia disponibile"
 ],
 "Add member": [
  null,
  "Aggiungi membro"
 ],
 "Interface members": [
  null,
  "Membri interfaccia"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Questo strumento configura il sistema per scrivere i dump di crash del kernel. Supporta le destinazioni di dump \"locale\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ]
});
