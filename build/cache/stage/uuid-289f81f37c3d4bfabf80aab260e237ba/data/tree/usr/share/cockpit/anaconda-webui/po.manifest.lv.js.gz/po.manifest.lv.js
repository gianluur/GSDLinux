cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2),
  "language": "lv",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
