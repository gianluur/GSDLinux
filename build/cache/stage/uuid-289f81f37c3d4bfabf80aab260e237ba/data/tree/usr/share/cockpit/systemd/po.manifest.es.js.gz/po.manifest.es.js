cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servicios"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "time": [
  null,
  "hora"
 ],
 "date": [
  null,
  "fecha"
 ],
 "restart": [
  null,
  "reiniciar"
 ],
 "shut": [
  null,
  "cerrar"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "machine": [
  null,
  "máquina"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "so"
 ],
 "asset tag": [
  null,
  "etiqueta de propiedad"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "corriente"
 ],
 "version": [
  null,
  "versión"
 ],
 "host": [
  null,
  "anfitrión"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "migitación"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "serie"
 ],
 "graphs": [
  null,
  "gráficos"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "history": [
  null,
  "histórico"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "discos"
 ],
 "network": [
  null,
  "red"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "rendimiento"
 ],
 "Configuring system settings": [
  null,
  "Cambiando la configuración del sistema"
 ],
 "service": [
  null,
  "servicio"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "destino"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "temporizador"
 ],
 "path": [
  null,
  "ruta"
 ],
 "unit": [
  null,
  "unit"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "arrancar"
 ],
 "mask": [
  null,
  "máscara"
 ],
 "unmask": [
  null,
  "desenmascarar"
 ],
 "enable": [
  null,
  "activar"
 ],
 "disable": [
  null,
  "desactivar"
 ],
 "Managing services": [
  null,
  "Gestión de servicios"
 ],
 "journal": [
  null,
  "journal"
 ],
 "warning": [
  null,
  "aviso"
 ],
 "error": [
  null,
  "error"
 ],
 "debug": [
  null,
  "depurar"
 ],
 "crash": [
  null,
  "colapso"
 ],
 "coredump": [
  null,
  "volcado"
 ],
 "Reviewing logs": [
  null,
  "Revisión de registros"
 ],
 "console": [
  null,
  "consola"
 ],
 "command": [
  null,
  "comando"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
