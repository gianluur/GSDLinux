cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
