cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "km",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
