cockpit.locale({
 "": {
  "plural-forms": ((n) => (n > 1)),
  "language": "fil",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "",
  ""
 ],
 "$0 installation": [
  null,
  "Installation ng $0"
 ],
 "$0 installer": [
  null,
  "Installer ng $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "Ang $0 ay isang MBR extended partition na naglalaman ng mga logical partition. Kapag tinanggal lahat ng mga logical partition, awtomatiko ring tatanggalin ang extended partition."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "Buburahin ang $0"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Hindi pwedeng ilagay ang '$0' filesystem sa isang encrypted na block device"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "Dapat nasa device na naka-format sa '$1' ang '$0'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Nakakita nang '$0' partition sa MDRAID device na $1. Hindi suportado ang mga bootloader partition sa loob ng isang MDRAID device."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  "Tungkol"
 ],
 "Account": [
  null,
  "Account"
 ],
 "Actions": [
  null,
  "Mga aksyon"
 ],
 "Add another server...": [
  null,
  ""
 ],
 "Add mount": [
  null,
  "Magdagdag ng mount"
 ],
 "Add-ons for your chosen environment": [
  null,
  ""
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "Additional languages": [
  null,
  "Karagdagang wika"
 ],
 "Additional software for the selected environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Agad na eepekto lahat ng mga pagbabagong ginawa sa storage editor."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Maa-unlock lahat ng mga device na gumagamit ng passphrase na ito"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Pahina ng proyekto ng Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "I-apply ang mga nakatakdang mount point at i-install"
 ],
 "Applying changes...": [
  null,
  ""
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Magtakda ng mga partition sa mga mount point. Nakatutulong para sa naka-preconfigure na mga custom layout."
 ],
 "Automatic log file upload": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Magagamit na bakanteng espasyo: $0. Kailangan ng installation: $1."
 ],
 "Back": [
  null,
  "Bumalik"
 ],
 "Base environment": [
  null,
  ""
 ],
 "Brief description of the issue": [
  null,
  ""
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Sa patuloy na paggamit ng software na ito, naiintindihan at tinatanggap mo ang mga panganib dulot ng paggamit ng pre-release na software, sa pag-testing at development mo lang ito balak gamitin, at handa kang mag-ulat ng mga bug o problema para mas pahusayin ang produktong ito."
 ],
 "Cancel": [
  null,
  "Kanselahin"
 ],
 "Change": [
  null,
  "Baguhin"
 ],
 "Change destination": [
  null,
  "Palitan ang destinasyon"
 ],
 "Change hostname": [
  null,
  "Baguhin ang hostname"
 ],
 "Change system keyboard layout": [
  null,
  "Palitan ang keyboard layout ng system"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Agad-agad na makakaapekto sa system ang mga pagbabagong gagawin rito. Wala nang bawian, walang 'undo'."
 ],
 "Checking storage configuration": [
  null,
  "Sinusuri ang configuration ng storage"
 ],
 "Clear search": [
  null,
  "I-clear ang search"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Isara"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Hindi nagbigay ang storage ng Cockpit ng passphrase para i-unlock ang naka-encrypt na device."
 ],
 "Completed": [
  null,
  "Kumpleto"
 ],
 "Configuration is incomplete": [
  null,
  ""
 ],
 "Configure storage": [
  null,
  "I-configure ang storage"
 ],
 "Configure storage again": [
  null,
  "I-configure ulit ang storage"
 ],
 "Confirm passphrase": [
  null,
  "Kumpirmahin ang passphrase"
 ],
 "Continue": [
  null,
  "Tumuloy"
 ],
 "Continue installation": [
  null,
  "Ituloy ang installation"
 ],
 "Continue with installation": [
  null,
  "Tumuloy sa installation"
 ],
 "Correct these issues before continuing.": [
  null,
  ""
 ],
 "Create Account": [
  null,
  "Gumawa ng Account"
 ],
 "Create account": [
  null,
  "Gumawa ng account"
 ],
 "Currently installed: $0": [
  null,
  "Kasalukuyang naka-install: $0"
 ],
 "Custom": [
  null,
  "Custom"
 ],
 "Date": [
  null,
  ""
 ],
 "Date and time": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Maaaring hindi maka-boot ang $0 kung tatanggalin ang ilang partition: $1"
 ],
 "Destination": [
  null,
  "Destinasyon"
 ],
 "Destination is encrypted": [
  null,
  "Naka-encrypt ang destinasyon"
 ],
 "Detailed description of the issue": [
  null,
  ""
 ],
 "Detected valid storage layout:": [
  null,
  "Naka-detect ng valid na storage layout:"
 ],
 "Device": [
  null,
  "Device"
 ],
 "Duplicate device.": [
  null,
  "Dobleng device."
 ],
 "Duplicate mount point.": [
  null,
  "Dobleng mount point."
 ],
 "Enable root account": [
  null,
  "I-enable ang root account"
 ],
 "Encrypt my data": [
  null,
  "I-encrypt ang data ko"
 ],
 "Encrypted": [
  null,
  "Naka-encrypt"
 ],
 "Encryption": [
  null,
  "Encryption"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Environment": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Burahin ang data at i-install"
 ],
 "Error details": [
  null,
  "Detalye ng error"
 ],
 "Exit to live desktop": [
  null,
  "Umalis papuntang live desktop"
 ],
 "Extended partition": [
  null,
  "Extended partition"
 ],
 "Failed to save layouts": [
  null,
  ""
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Kailangan ng Fedora Linux ng hindi bababa sa $0 na espasyo sa disk."
 ],
 "Finalization": [
  null,
  "Pagfa-finalize"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Nagfa-finalize: Tapos na ang pagko-configure sa system. Maaaring abutin ng ilang minuto ang pagfa-finalize ng installation."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Buong pangalan"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Dapat walang tutuldok ang buong pangalan"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Itago ang kumpirmadong password"
 ],
 "Hide passphrase": [
  null,
  "Itago ang passphrase"
 ],
 "Hide password": [
  null,
  "Itago ang password"
 ],
 "Hostname": [
  null,
  "Hostname"
 ],
 "How would you like to install?": [
  null,
  "Paano mo gustong mag-install?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Naiintindihan kong mabubura ang ilang kasalukuyang data"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Naiintindihan kong mababago ang ilang mga partition"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Kung walang laman, magiging panandalian lang at nakabase sa impormasyon ng network ang hostname."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Kailangan ang mga sumusunod kung magko-configure ka ng mga partition:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Kung hindi mo naiintindihan o tanggap ang mga panganib, mangyaring isara ang program na ito."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Umaandar"
 ],
 "Initializing...": [
  null,
  "Inihahanda..."
 ],
 "Install": [
  null,
  "I-install"
 ],
 "Installation failed": [
  null,
  "Nabigo ang pag-install"
 ],
 "Installation method": [
  null,
  "Paraan sa pag-install"
 ],
 "Installation of the system failed": [
  null,
  "Nabigo ang pag-install ng system"
 ],
 "Installation of the system failed: $0": [
  null,
  "Nabigo ang pag-install ng system: $0"
 ],
 "Installation type": [
  null,
  "Uri ng installation"
 ],
 "Installing": [
  null,
  "Ini-install"
 ],
 "Insufficient disk space": [
  null,
  "Kulang ng espasyo sa disk"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Nakakita ng 'di-wastong RAID configuration. Kung direktang nakapatong sa mga disk ang iyong RAID array, kailangang gumawa ng isang partition table sa array. Kung nakapatong sa mga partition ang iyong RAID array, dapat may isa itong filesystem o format (hal., LVM PV). Hindi papansinin ang mga kasalukuyang partition sa array na ito."
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Panatilihin ang kasalukuyang layout ng disk at gamitin ang bakanteng espasyo para makipag-dual boot sa isa pang OS."
 ],
 "Keyboard": [
  null,
  "Keyboard"
 ],
 "Keyboard layout during boot": [
  null,
  "Keyboard layout habang nagbo-boot"
 ],
 "Language": [
  null,
  "Wika"
 ],
 "Launch storage editor": [
  null,
  "Buksan ang editor ng storage"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Lokasyon"
 ],
 "Locked devices": [
  null,
  "Mga naka-lock na device"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "Manu-manong configuration ng disk"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manu-manong configuration ng disk: Pagtatakda ng mga mount point"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Pwedeng may mga letra, numero, at gitling."
 ],
 "Medium": [
  null,
  "Medium"
 ],
 "Minimum of $0 required": [
  null,
  "Kailangan ng hindi bababa sa $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "May hindi pagkakatugma sa reformat selection sa pagitan ng parent device at child device."
 ],
 "Mount point": [
  null,
  "Mount point"
 ],
 "Mount point assignment": [
  null,
  "Pagtatakda ng mount point"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "Dapat hindi bababa sa $0 karakter"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  ""
 ],
 "NTS": [
  null,
  ""
 ],
 "Name": [
  null,
  "Pangalan"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  ""
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Hindi available ang network. I-configure ang network sa bar menu sa itaas para i-ulat ang problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Hindi available ang network. I-configure ang network para i-ulat ang problema."
 ],
 "Next": [
  null,
  "Susunod"
 ],
 "No devices": [
  null,
  "Walang device"
 ],
 "No disks available": [
  null,
  "Walang magagamit na disk"
 ],
 "No disks selected": [
  null,
  "Walang napiling disk"
 ],
 "No results found": [
  null,
  "Walang nakitang resulta"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Hindi sapat ang bakanteng espasyo sa mga napiling disk."
 ],
 "Not enough space on selected disks.": [
  null,
  "Hindi sapat ang espasyo sa mga napiling disk."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Abiso: Ito ay pre-release software na para lamang sa development at testing. HUWAG gamitin ang software na ito para sa importanteng trabaho o sa mga production environment."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Operating system"
 ],
 "Other keyboards": [
  null,
  "Iba pang mga keyboard"
 ],
 "Partitions (advanced)": [
  null,
  "Mga partition (advanced)"
 ],
 "Passphrase": [
  null,
  "Passphrase"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Hindi tumugma ang passphrase sa anumang naka-lock na device"
 ],
 "Passphrases must match": [
  null,
  "Dapat tumugma ang mga passphrase"
 ],
 "Pending": [
  null,
  "Nakabinbin"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Paki-attach ang log file na $0 sa issue."
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "Mangyaring pumili ng hindi bababa sa isang disk para magpatuloy"
 ],
 "Pool": [
  null,
  ""
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Pinapagana ng Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-release"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Tumuloy sa installation"
 ],
 "Quit": [
  null,
  "Umalis"
 ],
 "Quit installer?": [
  null,
  "Umalis sa installer?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Nabigo ang pagbasa ng impormasyon tungkol sa OS."
 ],
 "Reading information about the computer failed.": [
  null,
  "Nabigo ang pagbasa ng impormasyon tungkol sa kompyuter."
 ],
 "Reading installer configuration failed.": [
  null,
  "Nabigo ang pagbasa ng configuration ng installer."
 ],
 "Reading installer version information failed.": [
  null,
  "Nabigo ang pagbasa ng impormasyon tungkol sa bersyon ng installer."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Mga letra, numero, gitling (na hindi nakalagay sa simula o dulo), at tuldok lamang ang pwedeng ilagay sa tunay na hostname"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Dapat hindi lalagpas sa 64 karakter ang tunay na hostname"
 ],
 "Reboot": [
  null,
  "Mag-reboot"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Mag-reboot pabalik sa Windows para i-resize ang mga partition na in-encrypt ng BitLocker. Gumawa ng hindi bababa sa $0 na bakanteng espasyo para sa pag-install."
 ],
 "Reboot system?": [
  null,
  "I-reboot ang system?"
 ],
 "Reclaim additional space": [
  null,
  "I-reclaim ang karagdagang espasyo"
 ],
 "Reclaim space": [
  null,
  "I-reclaim ang espasyo"
 ],
 "Reclaim space (required)": [
  null,
  "I-reclaim ang espasyo (kinakailangan)"
 ],
 "Recommended": [
  null,
  "Inirerekomenda"
 ],
 "Recommended partitions:": [
  null,
  "Mga inirerekomendang partition:"
 ],
 "Reformat": [
  null,
  "I-reformat"
 ],
 "Reinstall Fedora": [
  null,
  "I-reinstall ang Fedora"
 ],
 "Remove": [
  null,
  "Tanggalin"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Tanggalin lahat ng mga partition sa mga napiling device, kasama ang mga kasalukuyang operating system."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Tanggalin o baguhin ang laki ng mga kasalukuyang filesystem para makakuha ng bakanteng espasyo para sa installation."
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Palitan ang kasalukuyang installation, pero panatilihin ang mga file sa home."
 ],
 "Report Issue": [
  null,
  "I-ulat ang Issue"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "I-ulat ang issue"
 ],
 "Required": [
  null,
  "Kinakailangan"
 ],
 "Requirements": [
  null,
  "Mga requirement"
 ],
 "Rescan devices": [
  null,
  "Mag-rescan ng mga device"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Nagkaproblema sa pagre-rescan ng mga disk."
 ],
 "Resize": [
  null,
  "I-resize"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Ire-resize ang mga sumusunod na partition mula sa $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Bumalik sa installation"
 ],
 "Return to storage editor": [
  null,
  "Bumalik sa editor ng storage"
 ],
 "Review and install": [
  null,
  "I-review at i-install"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  ""
 ],
 "Save": [
  null,
  "I-save"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "I-scan ang QR code gamit ang cellphone mo o pumunta sa:"
 ],
 "Search for a language": [
  null,
  "Maghanap ng wika"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "I-secure ang data mo gamit ang disk-based encryption. Ilalapat lang sa mga bagong partition"
 ],
 "Select": [
  null,
  "Pumili"
 ],
 "Select a device": [
  null,
  "Pumili ng device"
 ],
 "Select destination": [
  null,
  "Pumili ng destinasyon"
 ],
 "Selected (top = current)": [
  null,
  ""
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Hindi ma-reformat ang '$0' na format ng napiling device."
 ],
 "Send us feedback on your installation": [
  null,
  "Magbigay sa amin ng feedback tungkol sa iyong installation"
 ],
 "Server": [
  null,
  ""
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "Magtakda ng custom na hostname"
 ],
 "Show AM/PM": [
  null,
  ""
 ],
 "Show API key": [
  null,
  ""
 ],
 "Show PIN": [
  null,
  ""
 ],
 "Show confirmed password": [
  null,
  "Ipakita ang kumpirmadong password"
 ],
 "Show passphrase": [
  null,
  "Ipakita ang passphrase"
 ],
 "Show password": [
  null,
  "Ipakita ang password"
 ],
 "Size": [
  null,
  "Laki"
 ],
 "Software installation": [
  null,
  "Installation ng software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Installation ng software: Kumpleto na ang configuration ng storage. Ini-install na ngayon ang software sa iyong device."
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Nawawala ang ilang kinakailangang partition: $0"
 ],
 "Space": [
  null,
  "Espasyo"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Storage"
 ],
 "Storage configuration": [
  null,
  "Configuration ng storage"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuration ng storage: Kasalukuyang kino-configure ang storage."
 ],
 "Storage editor": [
  null,
  "Editor ng storage"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Nakabase ang storage sa configuration mula sa 'Baguhin ang storage'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Nagkaproblema sa storage plugin"
 ],
 "Storage requirements not met": [
  null,
  "Hindi natugunan ang mga kinakailangan sa storage"
 ],
 "Strong": [
  null,
  "Matatag"
 ],
 "Successfully installed": [
  null,
  "Matagumpay na na-install"
 ],
 "Successfully unlocked $0.": [
  null,
  "Matagumpay na na-unlock ang $0."
 ],
 "Suggested languages": [
  null,
  "Iminumungkahing wika"
 ],
 "System": [
  null,
  "System"
 ],
 "System configuration": [
  null,
  "Configuration ng system"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuration ng system: Tapos na ang installation ng software. Kino-configure na ang system."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "",
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Hindi makatuloy ang installer dahil sa isang kritikal na error."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Hindi makatuloy ang installer dahil sa isang kritikal na error: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Naglalaman ng karakter na hindi ASCII ang passphrase na inilagay mo. Maaaring hindi ka makalilipat sa iba't-ibang keyboard layout habang tina-type ito."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "Hindi maipapasa ang hostname na ito"
 ],
 "This is unstable, pre-release software": [
  null,
  "Unstable, pre-release software ito"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "Maaaring abutin ito ng ilang segundo"
 ],
 "This will take a few moments": [
  null,
  "Maaaring abutin ito ng ilang saglit"
 ],
 "Time": [
  null,
  ""
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Mag-reboot para simulang gamitin ang $0."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Para tumuloy, piliin ang mga device na i-installan."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Para gamitin ang opsyong ito, i-resize o tanggalin ang mga kasalukuyang partition para makabakante ng hindi bababa sa $0."
 ],
 "Type": [
  null,
  "Uri"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Hindi maiskedyul ang pagbura ng $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Hindi maiskedyul ang pag-resize ng $0"
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "I-unlock"
 ],
 "Unlock encrypted devices": [
  null,
  "I-unlock ang mga naka-encrypt na device"
 ],
 "Use configured storage": [
  null,
  "Gamitin ang naka-configure na storage"
 ],
 "Use entire disk": [
  null,
  "Gamitin ang buong disk"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  ""
 ],
 "User name": [
  null,
  "User name"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Mga letrang a-z, mga numerong 0-9, gitling $0, tuldok $1, at salungguhit $2 lamang ang pwedeng nasa user name"
 ],
 "User name must not be a reserved word": [
  null,
  "Hindi dapat isang nakareserbang salita ang user name"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Dapat hindi lalagpas sa 33 karakter ang user name"
 ],
 "Weak": [
  null,
  "Mahina"
 ],
 "Welcome": [
  null,
  "Maligayang pagdating"
 ],
 "Welcome to Fedora Linux": [
  null,
  ""
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Maligayang pagdating. I-install na natin ang $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Hindi mare-resize ang mga Windows partition na na-encrypt ng BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Pwede kang magbakante ng sapat na espasyo rito at hayaan ang installer asikasuhin ito, o manu-manong i-set up ang mga partition."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "Hindi mase-save ang progreso mo."
 ],
 "completed step": [
  null,
  "kumpletong hakbang"
 ],
 "current step": [
  null,
  "kasalukuyang hakbang"
 ],
 "delete": [
  null,
  "burahin"
 ],
 "edit": [
  null,
  "i-edit"
 ],
 "encrypt": [
  null,
  "i-encrypt"
 ],
 "encrypted": [
  null,
  "naka-encrypt"
 ],
 "extended partition": [
  null,
  "extended partition"
 ],
 "format as $0": [
  null,
  "i-format bilang $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "mount"
 ],
 "pending step": [
  null,
  "nakabinbing hakbang"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "ni-resize mula $0"
 ],
 "shrink": [
  null,
  "paliitin"
 ],
 "shrink to $0": [
  null,
  "paliitin sa $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "i-undo"
 ]
});
