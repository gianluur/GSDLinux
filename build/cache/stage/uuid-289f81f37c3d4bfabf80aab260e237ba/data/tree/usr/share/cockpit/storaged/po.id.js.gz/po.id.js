cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Kunci yang berubah sering kali disebabkan oleh instalasi ulang sistem operasi. Namun, perubahan yang tidak terduga dapat menunjukkan upaya pihak ketiga untuk mencegat koneksi Anda."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Untuk memastikan bahwa koneksi Anda tidak dicegat oleh pihak ketiga berbahaya, harap verifikasi sidik jari kunci host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email."
 ],
 "Password": [
  null,
  "Kata sandi"
 ],
 "Log in": [
  null,
  "Masuk"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Type": [
  null,
  "Jenis"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Copied": [
  null,
  "Disalin"
 ],
 "Unlock": [
  null,
  "Buka kunci"
 ],
 "Add key": [
  null,
  "Tambahkan kunci"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Edit": [
  null,
  "Edit"
 ],
 "Remove": [
  null,
  "Hapus"
 ],
 "Select": [
  null,
  "Pilih"
 ],
 "No results found": [
  null,
  "Tidak ada hasil ditemukan"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit tidak terpasang"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Versi Cockpit yang kompatibel tidak terinstal pada $0."
 ],
 "Set": [
  null,
  "Atur"
 ],
 "Add": [
  null,
  "Tambah"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "Kunci $0 telah berubah"
 ],
 "Trust and add host": [
  null,
  "Percayai dan tambahkan host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Untuk memverifikasi sidik jari, jalankan perintah berikut di $0 saat berada langsung di mesin atau melalui jaringan tepercaya:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jika sidik jari cocok, klik 'Percayai dan tambahkan host'. Jika tidak, jangan sambungkan dan hubungi administrator Anda."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email. Jika Anda meminta orang lain untuk melakukan verifikasi, mereka dapat mengirim hasilnya dengan metode apa pun."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Anda terhubung ke $0 untuk pertama kalinya."
 ],
 "Verify fingerprint": [
  null,
  "Verifikasi sidik jari"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Jalankan perintah ini melalui jaringan tepercaya atau langsung di mesin jarak jauh:"
 ],
 "The fingerprint should match:": [
  null,
  "Sidik jari harus cocok:"
 ],
 "The password can not be empty": [
  null,
  "Kata sandi tidak boleh kosong"
 ],
 "The key password can not be empty": [
  null,
  "Kata sandi kunci tidak boleh kosong"
 ],
 "The key passwords do not match": [
  null,
  "Kata sandi kunci tidak cocok"
 ],
 "Log in to $0": [
  null,
  "Masuk ke $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Tidak dapat masuk ke $0. Host tidak menerima login dengan kata sandi atau salah satu kunci SSH Anda."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi oleh kata sandi, dan host tidak mengizinkan login dengan kata sandi. Harap berikan kata sandi untuk kunci di $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi. Anda dapat masuk dengan kata sandi login Anda atau dengan memberikan kata sandi untuk kunci di $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Buat kunci SSH baru dan otorisasi"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH baru di $0 akan dibuat untuk $1 di $2 dan akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Key password": [
  null,
  "Kata sandi kunci"
 ],
 "Confirm key password": [
  null,
  "Konfirmasi kata sandi kunci"
 ],
 "Authorize SSH key": [
  null,
  "Otorisasi kunci SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH $0 dari $1 di $2 akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Authentication": [
  null,
  "Autentikasi"
 ],
 "SSH key": [
  null,
  "Kunci SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Kunci SSH $0 akan tersedia selama sisa sesi dan dapat digunakan untuk login ke host lain."
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Clear input value": [
  null,
  "Hapus nilai masukan"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format tanggal dan waktu tidak valid"
 ],
 "Invalid time format": [
  null,
  "Format waktu tidak valid"
 ],
 "Invalid date format": [
  null,
  "Format tanggal tidak valid"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tidak dapat menjadwalkan acara di masa lalu"
 ],
 "No delay": [
  null,
  "Tanpa penundaan"
 ],
 "1 minute": [
  null,
  "1 Menit"
 ],
 "5 minutes": [
  null,
  "5 menit"
 ],
 "20 minutes": [
  null,
  "20 Menit"
 ],
 "40 minutes": [
  null,
  "40 Menit"
 ],
 "60 minutes": [
  null,
  "60 Menit"
 ],
 "Specific time": [
  null,
  "Waktu tertentu"
 ],
 "Shut down": [
  null,
  "Matikan"
 ],
 "Reboot": [
  null,
  "Reboot"
 ],
 "Message to logged in users": [
  null,
  "Pesan ke pengguna yang sedang masuk"
 ],
 "Delay": [
  null,
  "Jeda"
 ],
 "Pick date": [
  null,
  "Pilih tanggal"
 ],
 "Toggle date picker": [
  null,
  "Beralih pemilih tanggal"
 ],
 "Synchronized": [
  null,
  "Tersinkronisasi"
 ],
 "Synchronized with $0": [
  null,
  "Tersinkronisasi dengan $0"
 ],
 "Synchronizing": [
  null,
  "Sedang menyinkronkan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Mencoba menyinkronkan dengan $0"
 ],
 "Not synchronized": [
  null,
  "Tidak tersinkronisasi"
 ],
 "Log messages": [
  null,
  "Pesan log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Secara manual"
 ],
 "Automatically using NTP": [
  null,
  "Secara otomatis menggunakan NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Menggunakan server NTP tambahan secara otomatis"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Menggunakan server NTP tertentu secara otomatis"
 ],
 "Time zone": [
  null,
  "Zona waktu"
 ],
 "Set time": [
  null,
  "Atur waktu"
 ],
 "Invalid timezone": [
  null,
  "Zona waktu tidak valid"
 ],
 "Need at least one NTP server": [
  null,
  "Membutuhkan setidaknya satu server NTP"
 ],
 "Change system time": [
  null,
  "Ubah Waktu Sistem"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Path to file": [
  null,
  "Jalur ke berkas"
 ],
 "No such file or directory": [
  null,
  "Tidak ada berkas atau direktori"
 ],
 "Create $0": [
  null,
  "Buat $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Pelajari lebih lanjut"
 ],
 "You now have administrative access.": [
  null,
  "Anda sekarang memiliki akses administratif."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Tidak ada metode untuk mendapatkan akses administratif yang tersedia (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Silakan autentikasi untuk mendapatkan akses administratif"
 ],
 "Switch to administrative access": [
  null,
  "Beralih ke akses administratif"
 ],
 "Authenticate": [
  null,
  "Autentikasi"
 ],
 "Administrative access": [
  null,
  "Akses administratif"
 ],
 "Problem becoming administrator": [
  null,
  "Masalah saat menjadi administrator"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Limit access": [
  null,
  "Batasi akses"
 ],
 "Switch to limited access": [
  null,
  "Beralih ke mode akses terbatas"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Mode akses terbatas membatasi hak administratif. Beberapa bagian dari konsol web akan memiliki fungsionalitas yang terbatas."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Peramban Anda akan mengingat tingkat akses Anda di seluruh sesi."
 ],
 "Limited access": [
  null,
  "Akses terbatas"
 ],
 "Turn on administrative access": [
  null,
  "Aktifkan akses administratif"
 ],
 "$0 year": [
  null,
  "$0 tahun"
 ],
 "$0 month": [
  null,
  "$0 bulan"
 ],
 "$0 week": [
  null,
  "$0 minggu"
 ],
 "$0 day": [
  null,
  "$0 hari"
 ],
 "$0 hour": [
  null,
  "$0 jam"
 ],
 "$0 minute": [
  null,
  "$0 menit"
 ],
 "Go to now": [
  null,
  "Pergi ke sekarang"
 ],
 "1 hour": [
  null,
  "1 jam"
 ],
 "6 hours": [
  null,
  "6 jam"
 ],
 "1 day": [
  null,
  "1 hari"
 ],
 "1 week": [
  null,
  "1 minggu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Gagal mengaktifkan $0 di firewalld"
 ],
 "Visit firewall": [
  null,
  "Kunjungi firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Tambahkan $0"
 ],
 "less than a minute ago": [
  null,
  "kurang dari satu menit yang lalu"
 ],
 "in less than a minute": [
  null,
  "dalam waktu kurang dari satu menit"
 ],
 "Password is too weak": [
  null,
  "Kata sandi terlalu lemah"
 ],
 "Excellent password": [
  null,
  "Sandi bagus"
 ],
 "Password is not acceptable": [
  null,
  "Kata sandi tidak dapat diterima"
 ],
 "Strong password": [
  null,
  "Kata sandi kuat"
 ],
 "Acceptable password": [
  null,
  "Kata sandi dapat diterima"
 ],
 "Weak password": [
  null,
  "Kata sandi lemah"
 ],
 "Show password": [
  null,
  "Tampilkan kata sandi"
 ],
 "Hide password": [
  null,
  "Sembunyikan kata sandi"
 ],
 "password quality": [
  null,
  "kualitas kata sandi"
 ],
 "Show confirmation password": [
  null,
  "Tampilkan konfirmasi kata sandi"
 ],
 "Hide confirmation password": [
  null,
  "Sembunyikan konfirmasi kata sandi"
 ],
 "Additional packages:": [
  null,
  "Paket tambahan:"
 ],
 "Removals:": [
  null,
  "Penghapusan:"
 ],
 "Total size: $0": [
  null,
  "Total ukuran: $0"
 ],
 "Install software": [
  null,
  "Instal perangkat lunak"
 ],
 "$0 will be installed.": [
  null,
  "$0 akan diinstal."
 ],
 "Install": [
  null,
  "Instal"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Menunggu operasi pengelolaan perangkat lunak lain selesai"
 ],
 "Checking installed software": [
  null,
  "Memeriksa perangkat lunak yang terpasang"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 tidak tersedia dari repositori mana pun."
 ],
 "Downloading $0": [
  null,
  "Mengunduh $0"
 ],
 "Removing $0": [
  null,
  "Menghapus $0"
 ],
 "Installing $0": [
  null,
  "Memasang $0"
 ],
 "Unknown host: $0": [
  null,
  "Host tidak dikenal: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Tidak dapat masuk ke $0 menggunakan autentikasi kunci SSH. Harap berikan kata sandi."
 ],
 "SSH key login": [
  null,
  "Login dengan kunci SSH"
 ],
 "[no data]": [
  null,
  "[Tidak ada data]"
 ],
 "[binary data]": [
  null,
  "[data biner]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit berhenti secara mendadak"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit melaporkan kode kesalahan $0"
 ],
 "show less": [
  null,
  "tampilkan lebih sedikit"
 ],
 "show more": [
  null,
  "tampilkan lebih banyak"
 ],
 "Row expansion": [
  null,
  "Perluasan baris"
 ],
 "Row select": [
  null,
  "Pilih baris"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Kesalahan menempel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Peramban Anda tidak mengizinkan tempel dari menu konteks. Anda dapat menggunakan Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Kesalahan saat inisialisasi"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Downloads": [
  null,
  "Unduhan"
 ],
 "Not a directory": [
  null,
  "Bukan direktori"
 ],
 "All files": [
  null,
  "Semua berkas"
 ],
 "Recent": [
  null,
  "Terbaru"
 ],
 "No recent directories": [
  null,
  "Tidak ada direktori terbaru"
 ],
 "No recent files": [
  null,
  "Tidak ada berkas terbaru"
 ],
 "Type to filter": [
  null,
  "Ketik untuk memfilter"
 ],
 "File chooser actions": [
  null,
  "Tindakan pemilih berkas"
 ],
 "Open in file browser": [
  null,
  "Buka di peramban berkas"
 ],
 "Hide hidden files": [
  null,
  "Sembunyikan berkas tersembunyi"
 ],
 "Show hidden files": [
  null,
  "Tampilkan berkas tersembunyi"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Clear filters": [
  null,
  "Hapus filter"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "Directory has no sub-directories": [
  null,
  "Direktori tidak memiliki subdirektori"
 ],
 "This directory contains only hidden files": [
  null,
  "Direktori ini hanya berisi berkas tersembunyi"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "Folder": [
  null,
  "Folder"
 ],
 "File": [
  null,
  "Berkas"
 ],
 "Copy to clipboard": [
  null,
  "Salin ke papan klip"
 ],
 "Automation script": [
  null,
  "Skrip otomatisasi"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Buat berkas tugas baru dengan konten ini."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentasi peran Ansible"
 ],
 "Shell script": [
  null,
  "Skrip shell"
 ],
 "No system modifications": [
  null,
  "Tidak ada modifikasi sistem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Pengguna yang masuk tidak diizinkan melihat modifikasi sistem"
 ],
 "Loading system modifications...": [
  null,
  "Memuat modifikasi sistem..."
 ],
 "View automation script": [
  null,
  "Lihat skrip otomatisasi"
 ],
 "Occurrences": [
  null,
  "Kejadian"
 ],
 "View all logs": [
  null,
  "Lihat semua log"
 ],
 "Other": [
  null,
  "Lainnya"
 ],
 "Unknown": [
  null,
  "Tidak diketahui"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop profil rendah"
 ],
 "Pizza box": [
  null,
  "Casing pipih (Pizza box)"
 ],
 "Mini tower": [
  null,
  "Menara mini"
 ],
 "Tower": [
  null,
  "Menara"
 ],
 "Portable": [
  null,
  "Portabel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Perangkat genggam"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer hemat ruang"
 ],
 "Lunch box": [
  null,
  "Casing kecil"
 ],
 "Main server chassis": [
  null,
  "Chassis server utama"
 ],
 "Expansion chassis": [
  null,
  "Chassis ekspansi"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassis ekspansi bus"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferal"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis rak mount"
 ],
 "Sealed-case PC": [
  null,
  "PC tertutup rapat"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multi-sistem"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Penutup pisau"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Dapat dilepas"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC Embedded"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC stik"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Peringkat tunggal"
 ],
 "Dual rank": [
  null,
  "Peringkat ganda"
 ],
 "Absent": [
  null,
  "Absen"
 ],
 "Present": [
  null,
  "Ada"
 ],
 "Old password not accepted": [
  null,
  "Kata sandi lama tidak diterima"
 ],
 "Failed to change password": [
  null,
  "Gagal mengubah kata sandi"
 ],
 "New password was not accepted": [
  null,
  "Kata sandi baru tidak diterima"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Permintaan melalui ssh-keygen habis waktu"
 ],
 "Not a valid private key": [
  null,
  "Bukan kunci pribadi yang valid"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Permintaan melalui ssh-add habis waktu"
 ],
 "Invalid file permissions": [
  null,
  "Izin berkas tidak valid"
 ],
 "Password not accepted": [
  null,
  "Kata sandi tidak diterima"
 ],
 "Select an option": [
  null,
  "Pilih opsi"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dihentikan dengan sinyal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 keluar dengan kode $1"
 ],
 "$0 failed": [
  null,
  "$0 gagal"
 ],
 "Your session has been terminated.": [
  null,
  "Sesi Anda telah diakhiri."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesi Anda telah kedaluwarsa. Harap login kembali."
 ],
 "Not permitted to perform this action.": [
  null,
  "Tidak diizinkan untuk melakukan tindakan ini."
 ],
 "Login failed": [
  null,
  "Login gagal"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server menolak mengautentikasi menggunakan metode apa pun yang didukung."
 ],
 "Untrusted host": [
  null,
  "Host tidak tepercaya"
 ],
 "Host key is incorrect": [
  null,
  "Kunci host salah"
 ],
 "Internal error": [
  null,
  "Kesalahan internal"
 ],
 "Connection has timed out.": [
  null,
  "Koneksi timeout."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit tidak terpasang pada sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Tidak dapat meneruskan kredensial login"
 ],
 "Server has closed the connection.": [
  null,
  "Server telah menutup koneksi."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit tidak kompatibel dengan perangkat lunak di sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit tidak dapat menghubungi host yang diberikan."
 ],
 "Too much data": [
  null,
  "Terlalu banyak data"
 ],
 "Description": [
  null,
  "Deskripsi"
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "View logs": [
  null,
  "Lihat log"
 ],
 "Dismiss": [
  null,
  "Abaikan"
 ],
 "edit": [
  null,
  "ubah"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Penggunaan"
 ],
 "none": [
  null,
  "tidak ada"
 ],
 "Not found": [
  null,
  "Tidak ditemukan"
 ],
 "Error": [
  null,
  "Kesalahan"
 ],
 "Running": [
  null,
  "Berjalan"
 ],
 "Not running": [
  null,
  "Tidak berjalan"
 ],
 "Loading...": [
  null,
  "Memuat..."
 ],
 "User": [
  null,
  "Pengguna"
 ],
 "Vendor": [
  null,
  "Vendor"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "State": [
  null,
  "Status"
 ],
 "Stop": [
  null,
  "Hentikan"
 ],
 "Start": [
  null,
  "Mulai"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Confirm deletion of $0": [
  null,
  "Konfirmasi penghapusan $0"
 ],
 "Username": [
  null,
  "Nama pengguna"
 ],
 "Actions": [
  null,
  "Tindakan"
 ],
 "Create": [
  null,
  "Buat"
 ],
 "Rename": [
  null,
  "Ganti nama"
 ],
 "Started": [
  null,
  "Dimulai"
 ],
 "Delete group": [
  null,
  "Hapus grup"
 ],
 "Options": [
  null,
  "Opsi"
 ],
 "Lock": [
  null,
  "Kunci"
 ],
 "Use $0": [
  null,
  "Gunakan $0"
 ],
 "Service": [
  null,
  "Layanan"
 ],
 "Disconnect": [
  null,
  "Terputus"
 ],
 "Address": [
  null,
  "Alamat"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk tidak ada"
 ],
 "Location": [
  null,
  "Lokasi"
 ],
 "Compression": [
  null,
  "Kompresi"
 ],
 "Storage logs": [
  null,
  "Log penyimpanan"
 ],
 "Name cannot be empty.": [
  null,
  "Nama tidak boleh kosong."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nama tidak boleh lebih panjang dari 127 karakter."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nama tidak boleh mengandung karakter '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nama tidak boleh mengandung spasi."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nama tidak boleh lebih panjang dari $0 karakter"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nama tidak boleh lebih panjang dari $0 byte"
 ],
 "$name (from $host)": [
  null,
  "$name (dari $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Kolam untuk volume logis tipis"
 ],
 "Thin logical volume": [
  null,
  "Volume logis tipis"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logis (snapshot)"
 ],
 "Logical volume": [
  null,
  "Volume logis"
 ],
 "MDRAID device $0": [
  null,
  "Perangkat MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Grup volume LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Perangkat VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logis terenkripsi dari $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partisi terenkripsi dari $0"
 ],
 "Logical volume of $0": [
  null,
  "Volume logis dari $0"
 ],
 "Partition of $0": [
  null,
  "Partisi dari $0"
 ],
 "Encrypted $0": [
  null,
  "Terenkripsi $0"
 ],
 "unpartitioned space on $0": [
  null,
  "ruang tidak terpartisi pada $0"
 ],
 "unmount": [
  null,
  "unmount"
 ],
 "mount": [
  null,
  "mount"
 ],
 "remove from btrfs volume": [
  null,
  "hapus dari volume btrfs"
 ],
 "stop": [
  null,
  "hentikan"
 ],
 "remove from MDRAID": [
  null,
  "hapus dari MDRAID"
 ],
 "remove from LVM2": [
  null,
  "hapus dari LVM2"
 ],
 "btrfs device": [
  null,
  "perangkat btrfs"
 ],
 "btrfs volume": [
  null,
  "volume btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Nama tidak boleh lebih panjang dari 255 karakter."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Nama tidak boleh mengandung karakter '/'."
 ],
 "Create and mount": [
  null,
  "Buat dan mount"
 ],
 "Create only": [
  null,
  "Hanya buat"
 ],
 "Create subvolume": [
  null,
  "Buat subvolume"
 ],
 "Mount Point": [
  null,
  "Titik mount"
 ],
 "delete": [
  null,
  "hapus"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Hapus permanen subvolume $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Menghapus akan menghapus semua data pada subvolume ini dan semua turunannya."
 ],
 "Edit mount point": [
  null,
  "Edit titik mount"
 ],
 "Unmount": [
  null,
  "Unmount"
 ],
 "Mount": [
  null,
  "Mount"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Setidaknya satu subvolume perlu di-mount"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Subvolume terakhir yang di-mount tidak dapat dihapus"
 ],
 "btrfs subvolume": [
  null,
  "subvolume btrfs"
 ],
 "Snapshot origin": [
  null,
  "Asal snapshot"
 ],
 "Mount point": [
  null,
  "Titik mount"
 ],
 "No subvolumes": [
  null,
  "Tidak ada subvolume"
 ],
 "btrfs subvolumes": [
  null,
  "subvolume btrfs"
 ],
 "Snapshots": [
  null,
  "Snapshot"
 ],
 "No snapshots found": [
  null,
  "Tidak ada snapshot ditemukan"
 ],
 "snapshot": [
  null,
  "snapshot"
 ],
 "$0 is in use": [
  null,
  "$0 sedang digunakan"
 ],
 "Permanently delete $0?": [
  null,
  "Hapus $0 secara permanen?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Menghapus akan menghapus semua data pada volume btrfs."
 ],
 "Delete filesystem": [
  null,
  "Hapus sistem berkas"
 ],
 "Change label": [
  null,
  "Ubah label"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Sistem berkas di-mount hanya baca"
 ],
 "Label": [
  null,
  "Label"
 ],
 "Capacity": [
  null,
  "Kapasitas"
 ],
 "btrfs devices": [
  null,
  "perangkat btrfs"
 ],
 "No devices found": [
  null,
  "Tidak ditemukan perangkat"
 ],
 "btrfs filesystem": [
  null,
  "sistem berkas btrfs"
 ],
 "Successful": [
  null,
  "Berhasil"
 ],
 "Aborted": [
  null,
  "Dibatalkan"
 ],
 "In progress": [
  null,
  "Sedang berlangsung"
 ],
 "Interrupted": [
  null,
  "Terhenti"
 ],
 "Did not complete": [
  null,
  "Tidak selesai"
 ],
 "Failed (Unknown)": [
  null,
  "Gagal (Tidak diketahui)"
 ],
 "Failed (Electrical)": [
  null,
  "Gagal (Listrik)"
 ],
 "Failed (Servo)": [
  null,
  "Gagal (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Gagal (Baca)"
 ],
 "Failed (Damaged)": [
  null,
  "Gagal (Rusak)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Dibatalkan oleh Reset Tingkat Pengendali"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Dibatalkan karena penghapusan namespace dari inventaris namespace"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Dibatalkan karena pemrosesan perintah Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Terjadi kesalahan fatal selama operasi pengujian mandiri"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Selesai dengan segmen yang gagal, dan segmen yang gagal tidak diketahui"
 ],
 "Completed with one or more failed segments": [
  null,
  "Selesai dengan satu atau lebih segmen yang gagal"
 ],
 "Aborted for unknown reason": [
  null,
  "Dibatalkan karena alasan yang tidak diketahui"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Dibatalkan karena operasi sanitasi"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Kapasitas cadangan di bawah ambang batas"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Suhu di luar ambang batas yang direkomendasikan"
 ],
 "Degraded": [
  null,
  "Degradasi"
 ],
 "All media is in read-only mode": [
  null,
  "Semua media berada dalam mode hanya-baca"
 ],
 "Volatile memory backup failed": [
  null,
  "Cadangan memori volatil gagal"
 ],
 "Persistent memory has become read-only": [
  null,
  "Memori persisten menjadi hanya baca"
 ],
 "Run short test": [
  null,
  "Jalankan pengujian singkat"
 ],
 "Run extended test": [
  null,
  "Jalankan pengujian lanjutan"
 ],
 "Abort test": [
  null,
  "Batalkan pengujian"
 ],
 "Disk is failing": [
  null,
  "Disk mengalami kegagalan"
 ],
 "Disk is OK": [
  null,
  "Disk dalam kondisi baik"
 ],
 "Assessment": [
  null,
  "Penilaian"
 ],
 "Power on hours": [
  null,
  "Jam nyala daya"
 ],
 "$0 hours": [
  null,
  "$0 jam"
 ],
 "Self-test status": [
  null,
  "Status uji mandiri"
 ],
 "Number of bad sectors": [
  null,
  "Jumlah sektor rusak"
 ],
 "Attributes failing": [
  null,
  "Atribut gagal"
 ],
 "Media drive": [
  null,
  "Drive media"
 ],
 "Solid State Drive": [
  null,
  "Solid State Drive"
 ],
 "Hard Disk Drive": [
  null,
  "Hard Disk Drive"
 ],
 "iSCSI Drive": [
  null,
  "Drive iSCSI"
 ],
 "Drive": [
  null,
  "Drive"
 ],
 "Device health (SMART)": [
  null,
  "Kesehatan perangkat (SMART)"
 ],
 "Firmware version": [
  null,
  "Versi firmware"
 ],
 "Serial number": [
  null,
  "Nomor seri"
 ],
 "World wide name": [
  null,
  "Nama global (World wide name)"
 ],
 "No media inserted": [
  null,
  "Tidak ada media yang dimasukkan"
 ],
 "Device file": [
  null,
  "Berkas perangkat"
 ],
 "Multipathed devices": [
  null,
  "Perangkat multipath"
 ],
 "Free space": [
  null,
  "Ruang bebas"
 ],
 "Create partition": [
  null,
  "Buat Partisi"
 ],
 "Extended partition": [
  null,
  "Partisi diperluas"
 ],
 "$0 partitions": [
  null,
  "$0 partisi"
 ],
 "Partitions": [
  null,
  "Partisi"
 ],
 "No partitions found": [
  null,
  "Tidak ada partisi yang ditemukan"
 ],
 "Unexpected partitions": [
  null,
  "Partisi tidak terduga"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Partisi tidak didukung pada perangkat blok ini. Jika digunakan sebagai disk untuk mesin virtual, partisi harus dikelola oleh sistem operasi di dalam mesin virtual."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Menghapus partisi akan menghapus semua data di dalamnya."
 ],
 "No free space after this partition": [
  null,
  "Tidak ada ruang kosong setelah partisi ini"
 ],
 "EFI system partition": [
  null,
  "partisi sistem EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partisi boot BIOS"
 ],
 "Partition": [
  null,
  "Partisi"
 ],
 "Shrink": [
  null,
  "Kecilkan"
 ],
 "Grow": [
  null,
  "Perbesar"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partisi boot PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "Ruang swap Linux"
 ],
 "Linux filesystem data": [
  null,
  "Data sistem berkas Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partisi Manajer Volume Logis"
 ],
 "Custom": [
  null,
  "Kustom"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tipe harus berisi tepat dua karakter heksadesimal (0 sampai 9, A sampai F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tipe hanya boleh berisi karakter 0 sampai 9, A sampai F, dan \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tipe harus dalam format NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Atur tipe partisi dari $0"
 ],
 "Custom type": [
  null,
  "Tipe kustom"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Mengubah tipe partisi dapat mencegah sistem melakukan boot."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Partisi ini tidak sepenuhnya digunakan oleh kontennya."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Ukuran partisi adalah $0. Ukuran konten adalah $1."
 ],
 "Shrink partition": [
  null,
  "Perkecil partisi"
 ],
 "Grow content": [
  null,
  "Perbesar konten"
 ],
 "initialize": [
  null,
  "inisialisasi"
 ],
 "Initialize disk $0": [
  null,
  "Inisialisasi disk $0"
 ],
 "Partitioning": [
  null,
  "Pemartisian"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel dengan semua sistem dan perangkat (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel dengan sistem modern dan hard disk > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Tidak ada partisi"
 ],
 "Overwrite": [
  null,
  "Timpa"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Timpa data yang ada dengan nol (lebih lambat)"
 ],
 "Initialize": [
  null,
  "Inisialisasi"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Inisialisasi akan menghapus semua data pada disk."
 ],
 "Device is read-only": [
  null,
  "Perangkat bersifat hanya-baca"
 ],
 "Create partition table": [
  null,
  "Buat Tabel Partisi"
 ],
 "Size must be a number": [
  null,
  "Ukuran harus berupa angka"
 ],
 "Size cannot be zero": [
  null,
  "Ukuran tidak boleh nol"
 ],
 "Size cannot be negative": [
  null,
  "Ukuran tidak boleh negatif"
 ],
 "Size is too large": [
  null,
  "Ukuran terlalu besar"
 ],
 "Size must be at least $0": [
  null,
  "Ukuran harus minimal $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume fisik dari grup volume LVM2"
 ],
 "member of MDRAID device": [
  null,
  "anggota dari perangkat MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "perangkat pendukung untuk perangkat VDO"
 ],
 "member of Stratis pool": [
  null,
  "anggota dari kolam Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Sistem berkas di luar target"
 ],
 "device of btrfs volume": [
  null,
  "perangkat dari volume btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Perangkat ini sedang digunakan."
 ],
 "Device": [
  null,
  "Perangkat"
 ],
 "Use": [
  null,
  "Gunakan"
 ],
 "Services using the location": [
  null,
  "Layanan yang menggunakan lokasi ini"
 ],
 "Processes using the location": [
  null,
  "Proses yang menggunakan lokasi ini"
 ],
 "Currently in use": [
  null,
  "Sedang digunakan"
 ],
 "(Not part of target)": [
  null,
  "(Tidak termasuk dalam target)"
 ],
 "These changes will be made:": [
  null,
  "Perubahan berikut akan dilakukan:"
 ],
 "Action": [
  null,
  "Tindakan"
 ],
 "Important data might be deleted:": [
  null,
  "Data penting mungkin akan dihapus:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Proses dan layanan terkait akan dihentikan secara paksa."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Proses terkait akan dihentikan secara paksa."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Layanan terkait akan dihentikan secara paksa."
 ],
 "Checking filesystem usage": [
  null,
  "Memeriksa penggunaan sistem berkas"
 ],
 "$0 used, $1 total": [
  null,
  "$0 digunakan, total $1"
 ],
 "Device contains unrecognized data": [
  null,
  "Perangkat berisi data yang tidak dikenali"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Perangkat terenkripsi yang dikunci mungkin berisi data"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Saya mengonfirmasi bahwa saya ingin kehilangan data ini selamanya"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Titik mount $0 sedang digunakan oleh proses berikut:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Perintah"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Titik mount $0 sedang digunakan oleh layanan berikut:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Proses dan layanan yang terdaftar akan dihentikan secara paksa."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Proses yang terdaftar akan dihentikan secara paksa."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Layanan yang terdaftar akan dihentikan secara paksa."
 ],
 "Sorry": [
  null,
  "Maaf"
 ],
 "Usage of $0": [
  null,
  "Penggunaan $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Kolam LVM2 VDO"
 ],
 "Data used": [
  null,
  "Data yang digunakan"
 ],
 "Metadata used": [
  null,
  "Metadata yang digunakan"
 ],
 "Use compression": [
  null,
  "Gunakan kompresi"
 ],
 "Deduplication": [
  null,
  "Dedupikasi"
 ],
 "Use deduplication": [
  null,
  "Gunakan deduplikasi"
 ],
 "Rename volume group": [
  null,
  "Ganti nama grup volume"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Grup volume ini berisi sistem berkas root. Mengganti namanya mungkin memerlukan perubahan tambahan pada konfigurasi bootloader atau baris perintah kernel."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Menghapus akan menghapus semua data pada grup volume."
 ],
 "Create snapshot": [
  null,
  "Buat snapshot"
 ],
 "Add disks": [
  null,
  "Tambah Disk"
 ],
 "Disks": [
  null,
  "Disk"
 ],
 "No disks are available.": [
  null,
  "Tidak ada disk yang tersedia."
 ],
 "At least one disk is needed.": [
  null,
  "Setidaknya satu disk diperlukan."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Grup volume kehilangan beberapa volume fisik"
 ],
 "No free space": [
  null,
  "Tidak ada ruang kosong"
 ],
 "LVM2 volume group": [
  null,
  "Grup volume LVM2"
 ],
 "Add physical volume": [
  null,
  "Tambahkan volume fisik"
 ],
 "LVM2 logical volumes": [
  null,
  "Volume logis LVM2"
 ],
 "Create new logical volume": [
  null,
  "Buat logical volume baru"
 ],
 "No logical volumes": [
  null,
  "Tidak ada volume logis"
 ],
 "Remove missing physical volumes?": [
  null,
  "Hapus volume fisik yang hilang?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Grup volume ini kehilangan beberapa volume fisik."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Grup volume dengan volume fisik yang hilang tidak dapat diganti namanya."
 ],
 "Physical volumes": [
  null,
  "Volume fisik"
 ],
 "No physical volumes found": [
  null,
  "Tidak ada volume fisik yang ditemukan"
 ],
 "LVM2 physical volumes": [
  null,
  "Volume fisik LVM2"
 ],
 "Rename logical volume": [
  null,
  "Ganti nama volume logis"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Hapus permanen logical volume $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Menghapus volume logis akan menghapus semua data di dalamnya."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Tidak dapat memperbaiki volume logis $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Ruang yang tersedia tidak mencukupi untuk digunakan dalam perbaikan. Setidaknya $0 diperlukan pada volume fisik yang belum digunakan oleh volume logis ini."
 ],
 "An additional $0 must be selected": [
  null,
  "Tambahan $0 harus dipilih"
 ],
 "Repair logical volume $0": [
  null,
  "Perbaiki volume logis $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Pilih volume fisik yang harus digunakan untuk memperbaiki volume logis. Setidaknya $0 diperlukan."
 ],
 "Physical Volumes": [
  null,
  "Volume fisik"
 ],
 "Repair": [
  null,
  "Perbaiki"
 ],
 "deactivate": [
  null,
  "nonaktifkan"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Nonaktifkan logical volume $0/$1?"
 ],
 "Deactivate": [
  null,
  "Nonaktifkan"
 ],
 "Not enough space to grow": [
  null,
  "Ruang tidak cukup untuk memperbesar"
 ],
 "LVM2 logical volume": [
  null,
  "Volume logis LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Stripe (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Cermin (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Stripe dan mirror (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Paritas khusus (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Paritas terdistribusi (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Paritas ganda terdistribusi (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Volume logis ini tidak sepenuhnya digunakan oleh kontennya."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Ukuran volume adalah $0. Ukuran konten adalah $1."
 ],
 "Shrink volume": [
  null,
  "Kecilkan volume"
 ],
 "Layout": [
  null,
  "Tata letak"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Volume logis ini telah kehilangan beberapa volume fisiknya dan tidak dapat lagi digunakan. Anda harus menghapusnya dan membuat yang baru sebagai pengganti."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Volume logis ini telah kehilangan beberapa volume fisik tetapi belum kehilangan data apa pun. Anda harus memperbaikinya untuk memulihkan redundansi aslinya."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Volume logis ini telah kehilangan beberapa volume fisik tetapi mungkin belum kehilangan data apa pun. Anda mungkin dapat memperbaikinya."
 ],
 "Stripes": [
  null,
  "Stripe"
 ],
 "$0 synchronized": [
  null,
  "$0 tersinkronisasi"
 ],
 "Create volume group": [
  null,
  "Buat grup volume"
 ],
 "LVM2 physical volume": [
  null,
  "Volume fisik LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Yang terakhir tidak dapat dihapus"
 ],
 "Not enough free space": [
  null,
  "Ruang kosong tidak mencukupi"
 ],
 "Volume group": [
  null,
  "Grup volume"
 ],
 "Create thin volume": [
  null,
  "Buat volume tipis"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volume logis LVM2 yang disediakan tipis"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Buat volume logis tipis baru"
 ],
 "Not enough space": [
  null,
  "Ruang tidak mencukupi"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Kolam untuk volume logis LVM2 yang disediakan tipis"
 ],
 "Inactive logical volume": [
  null,
  "Volume logis tidak aktif"
 ],
 "Activate": [
  null,
  "Aktifkan"
 ],
 "Unsupported logical volume": [
  null,
  "Volume logis tidak didukung"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "KESALAHAN INTERNAL – Volume logis ini ditandai sebagai aktif dan seharusnya memiliki perangkat blok terkait. Namun, perangkat blok semacam itu tidak ditemukan."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Menginstal $0 akan menghapus $1."
 ],
 "Installing packages": [
  null,
  "Menginstal paket"
 ],
 "Block device for filesystems": [
  null,
  "Perangkat blok untuk sistem berkas"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Kolam untuk volume yang disediakan tipis"
 ],
 "Linear": [
  null,
  "Linier"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume sistem berkas VDO (kompresi/dedupikasi)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data akan disimpan pada volume fisik yang dipilih tanpa redundansi tambahan atau peningkatan kinerja apa pun."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data akan disimpan pada volume fisik yang dipilih secara bergantian untuk meningkatkan kinerja. Setidaknya dua volume harus dipilih."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data akan disimpan sebagai dua atau lebih salinan pada volume fisik yang dipilih, untuk meningkatkan keandalan. Setidaknya dua volume harus dipilih."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data akan disimpan sebagai dua salinan dan juga secara bergantian pada volume fisik yang dipilih, untuk meningkatkan keandalan dan kinerja. Setidaknya empat volume harus dipilih."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data akan disimpan pada volume fisik yang dipilih sehingga salah satu dapat hilang tanpa memengaruhi data. Setidaknya tiga volume harus dipilih."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data akan disimpan pada volume fisik yang dipilih sehingga salah satu dapat hilang tanpa memengaruhi data. Data juga disimpan secara bergantian untuk meningkatkan kinerja. Setidaknya tiga volume harus dipilih."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data akan disimpan pada volume fisik yang dipilih sehingga hingga dua di antaranya dapat hilang bersamaan tanpa memengaruhi data. Data juga disimpan secara bergantian untuk meningkatkan kinerja. Setidaknya lima volume harus dipilih."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Semua $0 volume fisik yang dipilih diperlukan untuk tata letak yang dipilih."
 ],
 "Create logical volume": [
  null,
  "Buat volume logis"
 ],
 "Purpose": [
  null,
  "Tujuan"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paket $0 akan diinstal untuk membuat perangkat VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 memerlukan jumlah volume fisik genap"
 ],
 "Logical size": [
  null,
  "Ukuran logis"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Hemat ruang dengan mengompres blok individu menggunakan LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Hemat ruang dengan menyimpan blok data identik hanya sekali"
 ],
 "Creating VDO device": [
  null,
  "Membuat perangkat VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Mount NFS ini sedang digunakan dan hanya opsinya yang dapat diubah."
 ],
 "NFS mount": [
  null,
  "Mount NFS"
 ],
 "New NFS mount": [
  null,
  "Mount NFS baru"
 ],
 "Server address": [
  null,
  "Alamat server"
 ],
 "Server cannot be empty.": [
  null,
  "Server tidak boleh kosong."
 ],
 "Path on server": [
  null,
  "Jalur di server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Jalur di server tidak boleh kosong."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Jalur di server harus diawali dengan \"/\"."
 ],
 "Local mount point": [
  null,
  "Titik mount lokal"
 ],
 "Mount point cannot be empty.": [
  null,
  "Titik mount tidak boleh kosong."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Titik mount harus diawali dengan \"/\"."
 ],
 "Mount options": [
  null,
  "Opsi mount"
 ],
 "Mount at boot": [
  null,
  "Mount saat boot"
 ],
 "Mount read only": [
  null,
  "Mount hanya baca"
 ],
 "Custom mount options": [
  null,
  "Opsi mount kustom"
 ],
 "Unable to unmount filesystem": [
  null,
  "Tidak dapat unmount sistem berkas"
 ],
 "Stop and unmount": [
  null,
  "Hentikan dan unmount"
 ],
 "Unable to remove mount": [
  null,
  "Tidak dapat menghapus mount"
 ],
 "Stop and remove": [
  null,
  "Hentikan dan hapus"
 ],
 "(not mounted)": [
  null,
  "(tidak di-mount)"
 ],
 "Start multipath": [
  null,
  "Mulai multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Ada perangkat dengan banyak jalur di sistem, tetapi layanan multipath tidak berjalan."
 ],
 "Show all $0 rows": [
  null,
  "Tampilkan semua $0 baris"
 ],
 "Category": [
  null,
  "Kategori"
 ],
 "more info": [
  null,
  "info lebih lanjut"
 ],
 "Encryption": [
  null,
  "Enkripsi"
 ],
 "encrypted": [
  null,
  "terenkripsi"
 ],
 "Last modified: $0": [
  null,
  "Terakhir dimodifikasi: $0"
 ],
 "Stored passphrase": [
  null,
  "Frasa sandi tersimpan"
 ],
 "Encryption options": [
  null,
  "Opsi enkripsi"
 ],
 "Encryption type": [
  null,
  "Tipe enkripsi"
 ],
 "Cleartext device": [
  null,
  "Perangkat teks biasa"
 ],
 "yes": [
  null,
  "ya"
 ],
 "Disk passphrase": [
  null,
  "Frasa sandi disk"
 ],
 "Passphrase cannot be empty": [
  null,
  "Frasa sandi tidak boleh kosong"
 ],
 "Unlocking disk": [
  null,
  "Membuka kunci disk"
 ],
 "Checking for $0 package": [
  null,
  "Memeriksa package $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Paket $0 harus diinstal."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Paket $0 tidak tersedia dari repositori mana pun."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Gagal menginstal $0: PackageKit atau dnf5daemon-server tidak terinstal"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Kesalahan PackageManager tak terduga selama instalasi $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Memeriksa dukungan NBDE di initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd harus dibuat ulang."
 ],
 "Regenerating initrd": [
  null,
  "Membuat ulang initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Menambahkan rd.neednet=1 ke baris perintah kernel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Menambahkan \"$0\" ke opsi sistem berkas"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Menambahkan \"$0\" ke opsi enkripsi"
 ],
 "Enabling $0": [
  null,
  "Mengaktifkan $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Tambahkan Enkripsi Disk Terikat Jaringan"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Sistem saat ini tidak mendukung pembukaan kunci sistem berkas root menggunakan server kunci Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Sistem saat ini tidak mendukung pembukaan kunci sistem berkas menggunakan server kunci Tang selama boot."
 ],
 "These additional steps are necessary:": [
  null,
  "Langkah tambahan berikut diperlukan:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Menyimpan frasa sandi baru memerlukan pembukaan kunci disk. Harap berikan frasa sandi disk saat ini."
 ],
 "Fix NBDE support": [
  null,
  "Perbaiki dukungan NBDE"
 ],
 "Adding key": [
  null,
  "Menambahkan kunci"
 ],
 "Key source": [
  null,
  "Sumber kunci"
 ],
 "Repeat passphrase": [
  null,
  "Ulangi frasa sandi"
 ],
 "Passphrase": [
  null,
  "Frasa sandi"
 ],
 "Tang keyserver": [
  null,
  "Server kunci Tang"
 ],
 "New passphrase": [
  null,
  "Frasa sandi baru"
 ],
 "Passphrases do not match": [
  null,
  "Frasa sandi tidak cocok"
 ],
 "Keyserver address": [
  null,
  "Alamat server kunci"
 ],
 "Change passphrase": [
  null,
  "Ubah frasa sandi"
 ],
 "Old passphrase": [
  null,
  "Frasa sandi lama"
 ],
 "Edit Tang keyserver": [
  null,
  "Edit server kunci Tang"
 ],
 "Verify key": [
  null,
  "Verifikasi kunci"
 ],
 "Trust key": [
  null,
  "Percayai kunci"
 ],
 "Passphrase can not be empty": [
  null,
  "Frasa sandi tidak boleh kosong"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Penghapusan frasa sandi dapat mencegah pembukaan kunci $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Konfirmasi penghapusan dengan frasa sandi alternatif"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Menghapus frasa sandi tanpa konfirmasi dari frasa sandi lainnya dapat mencegah pembukaan kunci atau pengelolaan kunci, jika frasa sandi lainnya terlupa atau hilang."
 ],
 "Passphrase from any other key slot": [
  null,
  "Frasa sandi dari slot kunci lainnya"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Hapus frasa sandi di slot kunci $0?"
 ],
 "Remove $0?": [
  null,
  "Hapus $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Penghapusan dapat mencegah pembukaan kunci $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Hapus server kunci Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Lepaskan kunci di dalam slot $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Pengguna yang saat ini masuk tidak diizinkan melihat informasi tentang kunci."
 ],
 "No keys added": [
  null,
  "Tidak ada kunci yang ditambahkan"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Mengedit kunci memerlukan slot kosong"
 ],
 "The last key slot can not be removed": [
  null,
  "Slot kunci terakhir tidak dapat dihapus"
 ],
 "Keyserver": [
  null,
  "Server kunci"
 ],
 "Unknown type": [
  null,
  "Tipe tidak diketahui"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Slot kunci dengan tipe tidak dikenal tidak dapat diedit di sini"
 ],
 "Keys": [
  null,
  "Kunci"
 ],
 "$0 slot remains": [
  null,
  "$0 slot tersisa"
 ],
 "No available slots": [
  null,
  "Tidak ada slot yang tersedia"
 ],
 "No free key slots": [
  null,
  "Tidak ada slot kunci yang tersedia"
 ],
 "Locked data": [
  null,
  "Data terkunci"
 ],
 "lock": [
  null,
  "kunci"
 ],
 "Lock $0?": [
  null,
  "Kunci $0?"
 ],
 "Address cannot be empty": [
  null,
  "Alamat tidak boleh kosong"
 ],
 "Address is not a valid URL": [
  null,
  "Alamat bukan URL yang valid"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Periksa hash kunci dengan server Tang."
 ],
 "How to check": [
  null,
  "Cara memeriksa"
 ],
 "In a terminal, run: ": [
  null,
  "Di terminal, jalankan: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Berhasil disalin ke papan klip!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Periksa apakah hash SHA-256 atau SHA-1 dari perintah sesuai dengan dialog ini."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "subvolume btrfs $0 dari $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Titik mount tidak boleh kosong"
 ],
 "Mount point is already used for $0": [
  null,
  "Titik mount sudah digunakan untuk $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Sistem berkas sudah di-mount di bawah titik mount ini."
 ],
 "Please unmount them first.": [
  null,
  "Harap unmount terlebih dahulu."
 ],
 "read only": [
  null,
  "hanya baca"
 ],
 "never mount at boot": [
  null,
  "jangan mount saat boot"
 ],
 "after network": [
  null,
  "setelah jaringan"
 ],
 "ignore failure": [
  null,
  "abaikan kegagalan"
 ],
 "stop boot on failure": [
  null,
  "hentikan boot saat gagal"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Sistem berkas tidak memiliki titik mount yang ditetapkan."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Sistem berkas tidak memiliki titik mount permanen."
 ],
 "The filesystem is not mounted.": [
  null,
  "Sistem berkas tidak di-mount."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Sistem berkas akan dibuka dan di-mount saat boot berikutnya. Ini mungkin memerlukan input frasa sandi."
 ],
 "(no assigned mount point)": [
  null,
  "(tidak ada titik mount yang ditetapkan)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Sistem berkas saat ini di-mount pada $0 tetapi akan di-mount pada $1 saat boot berikutnya."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Mount secara otomatis pada $0 saat boot"
 ],
 "Mount on $0 now": [
  null,
  "Mount di $0 sekarang"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Sistem berkas saat ini tidak di-mount tetapi akan di-mount saat boot berikutnya."
 ],
 "Do not mount automatically on boot": [
  null,
  "Jangan mount secara otomatis saat boot"
 ],
 "Mount now": [
  null,
  "Mount sekarang"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Sistem berkas saat ini di-mount tetapi tidak akan di-mount setelah boot berikutnya."
 ],
 "Mount also automatically on boot": [
  null,
  "Mount juga secara otomatis saat boot"
 ],
 "Unmount now": [
  null,
  "Unmount sekarang"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Sistem berkas saat ini di-mount pada $0 tetapi tidak akan di-mount setelah boot berikutnya."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Sistem berkas dikonfigurasi untuk di-mount secara otomatis saat boot, tetapi kontainer enkripsinya tidak akan dibuka saat itu."
 ],
 "Unlock automatically on boot": [
  null,
  "Buka kunci otomatis saat boot"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Mount sistem berkas tidak konsisten"
 ],
 "$0 filesystem": [
  null,
  "$0 Sistem berkas"
 ],
 "Filesystem name": [
  null,
  "Nama sistem berkas"
 ],
 "Filesystem is locked": [
  null,
  "Sistem berkas terkunci"
 ],
 "Mounts before services start": [
  null,
  "Dimount sebelum layanan dimulai"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Cocok untuk mount kritis, seperti /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Boot gagal jika sistem berkas tidak di-mount, mencegah akses jarak jauh"
 ],
 "Mounts in parallel with services": [
  null,
  "Dimount secara paralel dengan layanan"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Boot tetap berhasil meskipun sistem berkas tidak di-mount"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Dimount secara paralel dengan layanan, tetapi setelah jaringan tersedia"
 ],
 "Does not mount during boot": [
  null,
  "Tidak di-mount selama boot"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Berguna untuk mount yang bersifat opsional atau memerlukan interaksi (seperti frasa sandi)"
 ],
 "At boot": [
  null,
  "Saat boot"
 ],
 "Mount before services start": [
  null,
  "Mount sebelum layanan dimulai"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Mount tanpa menunggu, abaikan kegagalan"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Mount setelah jaringan tersedia, abaikan kegagalan"
 ],
 "Do not mount": [
  null,
  "Jangan mount"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Perangkat ini tidak dapat digunakan untuk target instalasi."
 ],
 "Mount filesystem": [
  null,
  "Mount sistem berkas"
 ],
 "Unmount filesystem $0": [
  null,
  "Unmount sistem berkas $0"
 ],
 "Mount configuration": [
  null,
  "Konfigurasi mount"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Digunakan"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Buka kunci kolam Stratis terenkripsi"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Berikan frasa sandi untuk kolam pada perangkat blok ini:"
 ],
 "Stratis pool": [
  null,
  "Kolam Stratis"
 ],
 "stopped": [
  null,
  "berhenti"
 ],
 "Block devices": [
  null,
  "Perangkat blok"
 ],
 "No block devices found": [
  null,
  "Tidak ditemukan perangkat blok"
 ],
 "Stratis block devices": [
  null,
  "Perangkat blok Stratis"
 ],
 "Stratis block device": [
  null,
  "Perangkat blok Stratis"
 ],
 "data": [
  null,
  "data"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Silakan berikan frasa sandi kolam yang sudah ada."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Jika server kunci di $0 tidak dapat dijangkau, Anda dapat memberikan frasa sandi yang sudah ada."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Jika tidak ada server kunci yang dapat dijangkau, Anda dapat memberikan frasa sandi yang sudah ada."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Jika tidak ada metode pembukaan kunci non-interaktif yang berfungsi, Anda dapat memberikan frasa sandi yang sudah ada."
 ],
 "Pool passphrase": [
  null,
  "Frasa sandi kolam"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Server kunci di $0 harus dapat dijangkau."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Setidaknya satu server kunci harus dapat dijangkau."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Setidaknya satu metode pembukaan kunci non-interaktif harus berfungsi."
 ],
 "Create filesystem": [
  null,
  "Buat sistem berkas"
 ],
 "Stratis filesystem": [
  null,
  "Sistem berkas Stratis"
 ],
 "Set initial size": [
  null,
  "Atur ukuran awal"
 ],
 "Limit size": [
  null,
  "Batasi ukuran"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Menghapus kolam Stratis akan menghapus semua data yang dikandungnya."
 ],
 "Rename Stratis pool": [
  null,
  "Ganti nama kolam Stratis"
 ],
 "Add block devices": [
  null,
  "Tambahkan perangkat blok"
 ],
 "Tier": [
  null,
  "Tingkat"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Menambahkan perangkat blok memerlukan pembukaan kunci kolam."
 ],
 "Encrypted Stratis pool": [
  null,
  "Kolam Stratis terenkripsi"
 ],
 "Delete pool": [
  null,
  "Hapus pool"
 ],
 "Encryption tokens": [
  null,
  "Token enkripsi"
 ],
 "Stratis filesystems": [
  null,
  "Sistem berkas Stratis"
 ],
 "Create new filesystem": [
  null,
  "Buat sistem berkas baru"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Kolam ini tidak menggunakan seluruh ruang pada perangkat bloknya."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Beberapa perangkat blok di kolam ini telah bertambah ukuran setelah dibuat. Kolam dapat diperbesar dengan aman untuk menggunakan ruang yang baru tersedia."
 ],
 "Grow the pool to take all space": [
  null,
  "Perbesar kolam untuk menggunakan semua ruang"
 ],
 "This pool is in a degraded state.": [
  null,
  "Kolam ini dalam keadaan terdegradasi."
 ],
 "No filesystems": [
  null,
  "Tidak ada sistem berkas"
 ],
 "Stratis filesystems pool": [
  null,
  "Kolam sistem berkas Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Frasa sandi ini adalah satu-satunya cara untuk membuka kolam dan tidak dapat dihapus."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Server kunci ini adalah satu-satunya cara untuk membuka kunci kolam dan tidak dapat dihapus."
 ],
 "Add passphrase": [
  null,
  "Tambahkan frasa sandi"
 ],
 "Add keyserver": [
  null,
  "Tambahkan server kunci"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "Token terakhir tidak dapat dihapus"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Tidak ada ruang tersisa untuk frasa sandi atau server kunci."
 ],
 "Confirm": [
  null,
  "Konfirmasi"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Menambahkan frasa sandi memerlukan pembukaan kunci kolam."
 ],
 "Remove passphrase?": [
  null,
  "Hapus frasa sandi?"
 ],
 "Add Tang keyserver": [
  null,
  "Tambahkan server kunci Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Menambahkan server kunci memerlukan pembukaan kunci kolam."
 ],
 "Remove Clevis token?": [
  null,
  "Hapus token Clevis?"
 ],
 "Metadata format": [
  null,
  "Format metadata"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Kolam dengan format metadata V1 dibatasi maksimal satu frasa sandi dan satu server kunci."
 ],
 "Overprovisioning": [
  null,
  "Kelebihan penyediaan"
 ],
 "Allow overprovisioning": [
  null,
  "Izinkan kelebihan penyediaan"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Ukuran sistem berkas virtual lebih besar dari kolam. Kelebihan penyediaan tidak dapat dinonaktifkan."
 ],
 "Allocated": [
  null,
  "Dialokasikan"
 ],
 "Name can not be empty.": [
  null,
  "Nama tidak boleh kosong."
 ],
 "A pool with this name exists already.": [
  null,
  "Kolam dengan nama ini sudah ada."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Sistem berkas dengan nama ini sudah ada di kolam ini."
 ],
 "Create Stratis pool": [
  null,
  "Buat kolam Stratis"
 ],
 "No block devices are available.": [
  null,
  "Tidak ada perangkat blok yang tersedia."
 ],
 "At least one block device is needed.": [
  null,
  "Diperlukan setidaknya satu perangkat blok."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Enkripsi data dengan frasa sandi"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Enkripsi data dengan server kunci Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Buat snapshot dari sistem berkas $0"
 ],
 "Create snapshot and mount": [
  null,
  "Buat snapshot dan mount"
 ],
 "Create snapshot only": [
  null,
  "Hanya buat snapshot"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Menghapus sistem berkas akan menghapus semua data di dalamnya."
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Rename filesystem": [
  null,
  "Ganti nama sistem berkas"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Atur batas ukuran sistem berkas virtual"
 ],
 "Limit virtual filesystem size": [
  null,
  "Batasi ukuran sistem berkas virtual"
 ],
 "Virtual size limit": [
  null,
  "Batas ukuran virtual"
 ],
 "Virtual size": [
  null,
  "Ukuran virtual"
 ],
 "Create RAID device": [
  null,
  "Buat perangkat RAID"
 ],
 "RAID level": [
  null,
  "Level RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (mirror)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (paritas khusus)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (paritas terdistribusi)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (paritas ganda terdistribusi)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe dari mirror)"
 ],
 "Chunk size": [
  null,
  "Ukuran potongan"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Setidaknya diperlukan disk sebesar $0."
 ],
 "MDRAID disk": [
  null,
  "Disk MDRAID"
 ],
 "In sync": [
  null,
  "Sinkron"
 ],
 "Spare": [
  null,
  "Cadangan"
 ],
 "Recovering": [
  null,
  "Sedang memulihkan"
 ],
 "Write-mostly": [
  null,
  "Sering menulis"
 ],
 "Blocked": [
  null,
  "Diblokir"
 ],
 "Unknown ($0)": [
  null,
  "Tidak diketahui ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Perangkat MDRAID harus berjalan"
 ],
 "MDRAID device is recovering": [
  null,
  "Perangkat MDRAID sedang memulihkan"
 ],
 "Need a spare disk": [
  null,
  "Membutuhkan disk cadangan"
 ],
 "Last disk can not be removed": [
  null,
  "Disk terakhir tidak dapat dihapus"
 ],
 "MDRAID device": [
  null,
  "Perangkat MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Konfirmasi penghentian $0"
 ],
 "Stop device": [
  null,
  "Hentikan perangkat"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Menghapus akan menghapus semua data pada perangkat MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Perangkat MDRAID harus berjalan"
 ],
 "Add disk": [
  null,
  "Tambah Disk"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 disk"
 ],
 "$0 chunk size": [
  null,
  "$0 ukuran chunk"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Perangkat MDRAID dalam kondisi terdegradasi"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Perangkat MDRAID ini tidak memiliki bitmap niat-tulis. Bitmap semacam itu dapat mempercepat proses sinkronisasi secara signifikan."
 ],
 "Add a bitmap": [
  null,
  "Tambahkan bitmap"
 ],
 "No disks found": [
  null,
  "Tidak ada disk ditemukan"
 ],
 "MDRAID disks": [
  null,
  "Disk MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Menghapus akan menghapus semua data pada perangkat VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Pembuatan perangkat VDO ini tidak selesai dan perangkat tidak dapat digunakan."
 ],
 "Remove device": [
  null,
  "Hapus perangkat"
 ],
 "Grow to take all space": [
  null,
  "Perbesar untuk menggunakan semua ruang"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Perangkat VDO ini tidak menggunakan seluruh perangkat pendukungnya."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Hanya $0 dari $1 yang digunakan."
 ],
 "Grow logical size of $0": [
  null,
  "Perbesar ukuran logis dari $0"
 ],
 "Physical": [
  null,
  "Fisik"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 overhead yang digunakan sebesar $2 ($3)"
 ],
 "Logical": [
  null,
  "Logis"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 digunakan dari $1 ($2 dihemat)"
 ],
 "Index memory": [
  null,
  "Indeks memori"
 ],
 "SMART self-test of $target": [
  null,
  "Uji mandiri SMART untuk $target"
 ],
 "Ejecting $target": [
  null,
  "Mengeluarkan $target"
 ],
 "Unlocking $target": [
  null,
  "Membuka kunci $target"
 ],
 "Locking $target": [
  null,
  "Mengunci $target"
 ],
 "Modifying $target": [
  null,
  "Memodifikasi $target"
 ],
 "Resizing $target": [
  null,
  "Mengubah ukuran $target"
 ],
 "Starting swapspace $target": [
  null,
  "Memulai ruang swap $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Menghentikan ruang swap $target"
 ],
 "Mounting $target": [
  null,
  "Mem-mount $target"
 ],
 "Unmounting $target": [
  null,
  "Meng-unmount $target"
 ],
 "Checking $target": [
  null,
  "Memeriksa $target"
 ],
 "Repairing $target": [
  null,
  "Memperbaiki $target"
 ],
 "Erasing $target": [
  null,
  "Menghapus $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Membuat sistem berkas di $target"
 ],
 "Setting up loop device $target": [
  null,
  "Menyiapkan perangkat loop $target"
 ],
 "Deleting $target": [
  null,
  "Menghapus $target"
 ],
 "Creating partition $target": [
  null,
  "Membuat partisi $target"
 ],
 "Cleaning up for $target": [
  null,
  "Membersihkan untuk $target"
 ],
 "Securely erasing $target": [
  null,
  "Menghapus dengan aman $target"
 ],
 "Very securely erasing $target": [
  null,
  "Menghapus $target dengan sangat aman"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Menghentikan perangkat MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Memulai perangkat MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Menandai $target sebagai rusak"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Menghapus $target dari perangkat MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Membuat perangkat MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Memeriksa perangkat MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Memeriksa dan memperbaiki perangkat MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Memulihkan perangkat MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Menyinkronkan perangkat MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Mengaktifkan $target"
 ],
 "Deactivating $target": [
  null,
  "Menonaktifkan $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Membuat snapshot dari $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Membuat grup volume LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Menghapus grup volume LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Menambahkan volume fisik ke $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Menghapus volume fisik dari $target"
 ],
 "Emptying $target": [
  null,
  "Mengosongkan $target"
 ],
 "Creating logical volume $target": [
  null,
  "Membuat volume logis $target"
 ],
 "Renaming $target": [
  null,
  "Mengganti nama $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operasi '$operation' pada $target"
 ],
 "unknown target": [
  null,
  "target tidak diketahui"
 ],
 "Jobs": [
  null,
  "Pekerjaan"
 ],
 "Reading": [
  null,
  "Membaca"
 ],
 "Writing": [
  null,
  "Menulis"
 ],
 "Install Stratis support": [
  null,
  "Instal dukungan Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paket $0 harus diinstal untuk membuat kolam Stratis."
 ],
 "Install NFS support": [
  null,
  "Instal dukungan NFS"
 ],
 "Create MDRAID device": [
  null,
  "Buat perangkat MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Buat grup volume LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ubah nama inisiator iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Tambah Portal iSCSI"
 ],
 "Local storage": [
  null,
  "Penyimpanan lokal"
 ],
 "Networked storage": [
  null,
  "Penyimpanan jaringan"
 ],
 "Create storage device": [
  null,
  "Buat perangkat penyimpanan"
 ],
 "No storage found": [
  null,
  "Tidak ada penyimpanan yang ditemukan"
 ],
 "Server address cannot be empty.": [
  null,
  "Alamat server tidak boleh kosong."
 ],
 "Next": [
  null,
  "Berikutnya"
 ],
 "Invalid username or password": [
  null,
  "Nama pengguna atau kata sandi tidak valid"
 ],
 "Unknown host name": [
  null,
  "Nama host tidak diketahui"
 ],
 "Unable to reach server": [
  null,
  "Tidak dapat menjangkau server"
 ],
 "Available targets on $0": [
  null,
  "Target yang tersedia di $0"
 ],
 "Authentication required": [
  null,
  "Autentikasi dibutuhkan"
 ],
 "iSCSI portal": [
  null,
  "portal iSCSI"
 ],
 "iSCSI drives": [
  null,
  "drive iSCSI"
 ],
 "No drives found": [
  null,
  "Tidak ada drive ditemukan"
 ],
 "Target": [
  null,
  "Target"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Perangkat pendukung VDO tidak dapat diperkecil"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Perangkat blok Stratis tidak dapat diperkecil"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Data yang tidak dikenali tidak dapat diperkecil di sini."
 ],
 "Unlock before resizing": [
  null,
  "Buka kunci sebelum mengubah ukuran"
 ],
 "$0 can not be resized here": [
  null,
  "$0 tidak bisa diubah ukurannya di sini"
 ],
 "$0 can not be resized": [
  null,
  "$0 tidak bisa diubah ukurannya"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 tidak bisa dibuat lebih kecil"
 ],
 "$0 can not be made larger": [
  null,
  "$0 tidak bisa dibuat lebih besar"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Volume fisik tidak dapat diubah ukurannya di sini"
 ],
 "Swap can not be resized here": [
  null,
  "Swap tidak dapat diubah ukurannya di sini"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Data yang tidak dikenali tidak dapat diperkecil di sini"
 ],
 "Activate before resizing": [
  null,
  "Aktifkan sebelum mengubah ukuran"
 ],
 "Grow logical volume": [
  null,
  "Perbesar volume logis"
 ],
 "Grow partition": [
  null,
  "Perbesar partisi"
 ],
 "grow": [
  null,
  "kembangkan"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Tepat $0 volume fisik harus dipilih"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Mengubah ukuran sistem berkas terenkripsi memerlukan pembukaan kunci disk. Harap berikan frasa sandi disk saat ini."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Tepat $0 volume fisik perlu dipilih, satu untuk setiap stripe dari volume logis."
 ],
 "Shrink logical volume": [
  null,
  "Kecilkan volume logis"
 ],
 "shrink": [
  null,
  "perkecil"
 ],
 "Unformatted data": [
  null,
  "Data tidak diformat"
 ],
 "Block device": [
  null,
  "Perangkat blok"
 ],
 "Device number": [
  null,
  "Nomor perangkat"
 ],
 "Create partition on $0": [
  null,
  "Buat Partisi pada $0"
 ],
 "Format $0": [
  null,
  "Format $0"
 ],
 "No filesystem": [
  null,
  "Tidak ada sistem berkas"
 ],
 "(recommended)": [
  null,
  "(direkomendasikan)"
 ],
 "No encryption": [
  null,
  "Tanpa enkripsi"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Gunakan kembali enkripsi yang sudah ada ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Gunakan kembali enkripsi yang sudah ada"
 ],
 "format": [
  null,
  "format"
 ],
 "Format and mount": [
  null,
  "Format dan mount"
 ],
 "Format only": [
  null,
  "Hanya format"
 ],
 "Format": [
  null,
  "Format"
 ],
 "Create and start": [
  null,
  "Buat dan mulai"
 ],
 "Format and start": [
  null,
  "Format dan mulai"
 ],
 "Store passphrase": [
  null,
  "Simpan frasa sandi"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Disk perlu dibuka kuncinya sebelum diformat. Harap berikan frasa sandi yang sudah ada."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Pemformatan akan menghapus semua data pada perangkat penyimpanan."
 ],
 "Unrecognized data": [
  null,
  "Data tidak dikenali"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Penyimpanan tidak dapat dikelola di sistem ini."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsol Web untuk server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit adalah manajer server yang memudahkan administrasi server Linux Anda melalui browser web. Berpindah antara terminal dan alat web tidak menjadi masalah. Layanan yang dijalankan melalui Cockpit dapat dihentikan melalui terminal. Demikian pula, jika terjadi kesalahan di terminal, hal itu dapat dilihat di antarmuka jurnal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit sempurna untuk sysadmin baru, memungkinkan mereka melakukan tugas sederhana dengan mudah seperti administrasi penyimpanan, memeriksa jurnal, serta memulai dan menghentikan layanan. Anda dapat memantau dan mengelola beberapa server sekaligus. Cukup tambahkan dengan satu klik, dan mesin Anda akan saling menjaga."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Setelah Cockpit diinstal, aktifkan dengan \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurasi Cockpit untuk NetworkManager dan Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Alat ini mengelola jaringan seperti bond, bridge, team, VLAN, dan firewall menggunakan NetworkManager dan Firewalld. NetworkManager tidak kompatibel dengan systemd-networkd bawaan Ubuntu dan skrip ifupdown milik Debian."
 ],
 "Manage storage": [
  null,
  "Kelola penyimpanan"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Alat ini mengelola penyimpanan lokal seperti sistem berkas, grup volume LVM2, dan mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kumpulkan dan kemas data diagnostik serta dukungan"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Alat ini menghasilkan arsip berisi informasi konfigurasi dan diagnostik dari sistem yang sedang berjalan. Arsip dapat disimpan secara lokal atau pusat untuk pencatatan atau pelacakan, atau dikirim ke tim dukungan teknis, pengembang, atau administrator sistem untuk membantu dalam analisis kesalahan dan debugging teknis."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfigurasi dan pemecahan masalah Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Alat ini mengonfigurasi kebijakan SELinux dan membantu memahami serta menyelesaikan pelanggaran kebijakan."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kumpulkan dump crash kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Alat ini mengonfigurasi sistem untuk menulis dump crash kernel. Ini mendukung target dump \"local\" (disk), \"ssh\", dan \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasi dengan Konsol Web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentikasi diperlukan untuk melakukan tugas berprivileg dengan Konsol Web Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
