cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "Hardware information": [
  null,
  "Informácie o hardware"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "active": [
  null,
  "Aktívna"
 ],
 "Default": [
  null,
  "Predvolené"
 ],
 "Light": [
  null,
  "Svetlý"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Search": [
  null,
  "Hľadať"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "Permission denied": [
  null,
  "Prístup odmietnutý"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "You now have administrative access.": [
  null,
  "Teraz máte prístup na úrovni správcu systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pre získanie prístupu na úrovni správcu sa prosím overte"
 ],
 "Switch to administrative access": [
  null,
  "Prepnúť na prístup pre správcu"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s prepínaním na správcu"
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Limit access": [
  null,
  "Obmedziť prístup"
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim obmedzeného prístupu obmedzuje oprávnenia pre správu. Niektoré časti webovej konzole budú poskytovať menej funkcií."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prehliadač si bude úroveň prístupu pamätať aj pre budúce spustenia."
 ],
 "Limited access": [
  null,
  "Obmedzený prístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnúť prístup na úrovni správcu"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásil chybový kód $0"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrujte písaním"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Súborový systém"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Súbor"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "$0 is not a directory": [
  null,
  "$0 nie je adresár"
 ],
 "$0 does not exist": [
  null,
  "$0 neexistuje"
 ],
 "Font size": [
  null,
  "Veľkosť písma"
 ],
 "Decrease by one": [
  null,
  "Znížiť o jedno"
 ],
 "Increase by one": [
  null,
  "Zvýšiť o jednu"
 ],
 "Appearance": [
  null,
  "Vzhľad"
 ],
 "Black": [
  null,
  "Čierny"
 ],
 "White": [
  null,
  "Biely"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  ""
 ],
 "unknown": [
  null,
  "neznáme"
 ],
 "Shutdown": [
  null,
  "Vypnúť"
 ],
 "running $0": [
  null,
  "beží na $0"
 ],
 "Current boot": [
  null,
  "Od tohto spustenia"
 ],
 "Previous boot": [
  null,
  "Predchádzajúci štart"
 ],
 "Last 24 hours": [
  null,
  "Posledných 24 hodín"
 ],
 "Last 7 days": [
  null,
  "Posledných 7 dní"
 ],
 "Only emergency": [
  null,
  "Iba núdzové"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnejšie"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnejšie"
 ],
 "Error and above": [
  null,
  "Chyba a závažnejšie"
 ],
 "Warning and above": [
  null,
  "Varovanie a závažnejšie"
 ],
 "Notice and above": [
  null,
  "Oznámenie a závažnejšie"
 ],
 "Info and above": [
  null,
  "Informácia a závažnejšie"
 ],
 "Debug and above": [
  null,
  "Ladiace a závažnejšie"
 ],
 "Toggle filters": [
  null,
  "Prepnúť filtre"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "Filters": [
  null,
  "Filtre"
 ],
 "Pause": [
  null,
  "Pozastaviť"
 ],
 "Resume": [
  null,
  "Obnoviť chod"
 ],
 "All": [
  null,
  "Všetko"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Zadané dátumy by mali byť vo formáte RRRR-MM-DD hh:mm:ss. Prípadne je možné použiť aj reťazce „yesterday\" (včera), „today\" (dnes), „tomorrow\" (zajtra). „Now\" (teraz) odkazuje na aktuálny čas. Ďalej je možné zadávať relatívne časy uvedené predponou „-\" alebo „+\""
 ],
 "Since": [
  null,
  "Od"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Začať zobrazovať položky od zadaného dátumu vyššie."
 ],
 "Until": [
  null,
  "Až do"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Začať zobrazovať položky od zadaného dátumu ďalej do minulosti."
 ],
 "Boot": [
  null,
  "Zavádzanie"
 ],
 "Show messages from a specific boot.": [
  null,
  "Zobraziť správy z konkrétneho štartu systému."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Toto pridá zhodu pre „_BOOT_ID=“. Ak nie je určené, zobrazia sa záznamy udalostí pre súčasný štart systému. Ak identifikátor štartu vynecháte, kladný posun prehľadá štarty od začiatku žurnálu a posun rovný alebo menší ak nula prehľadá štarty od jeho konca. Preto 1 znamená v chronologickom poradí prvý štart nájdený v žurnáli, 2 druhý atď. Odbodne -0 znamená posledný štart, -1 predposledný štart atď."
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Zobraziť správy pre zadanú jednotku systemd."
 ],
 "Free-form search": [
  null,
  "Vyhľadávania voľnou formou"
 ],
 "Show messages containing given string.": [
  null,
  "Zobraziť správy obsahujúce zadaný reťazec."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "V správach záznamu je možné filtrovať podľa ľubovoľného textového reťazca. Reťazec tiež môže mať podobu regulárneho výrazu. Rovnako je podporované filtrovanie podľa polí správ záznamu udalostí. Tie uvádzajte ako medzerami oddeľované hodnoty v podobe POLE=HODNOTA, kde hodnota môže byť čiarkou oddelený zoznam možných hodnôt."
 ],
 "journalctl manpage": [
  null,
  "manuálové stránky k journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Úspešne skopírované do schránky"
 ],
 "Create timer": [
  null,
  "Vytvoriť časovač"
 ],
 "Timer creation failed": [
  null,
  "Vytvorenie časovača zlyhalo"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "Meno používateľa nesmie byť prázdne"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sú povolené iba písmena, čísla a znaky :_.@-"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "Spúšťač"
 ],
 "At specific time": [
  null,
  "V konkrétny čas"
 ],
 "After system boot": [
  null,
  "Po štarte systému"
 ],
 "Seconds": [
  null,
  "Sekundy"
 ],
 "Minutes": [
  null,
  "Minúty"
 ],
 "Hours": [
  null,
  "Hodiny"
 ],
 "Weeks": [
  null,
  "Týždne"
 ],
 "Delay must be a number": [
  null,
  "Je potrebné, aby oneskorenie bolo číslo"
 ],
 "Repeat": [
  null,
  "Opakovať"
 ],
 "Don't repeat": [
  null,
  "Neopakovať"
 ],
 "Minutely": [
  null,
  "Po minútach"
 ],
 "Hourly": [
  null,
  "Každú hodinu"
 ],
 "Daily": [
  null,
  "Denne"
 ],
 "Weekly": [
  null,
  "Každý týždeň"
 ],
 "Monthly": [
  null,
  "Každý mesiac"
 ],
 "Yearly": [
  null,
  "Každý rok"
 ],
 "Run at": [
  null,
  "Spustiť v"
 ],
 "At second": [
  null,
  "V sekunde"
 ],
 "At minute": [
  null,
  "V minúte"
 ],
 "Run on": [
  null,
  "Spustiť na"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minúta musí byť číslo medzi 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Je potrebné, aby sekunda bola číslo medzi 0 a 59"
 ],
 "Repeat weekly": [
  null,
  "Opakovať každý týždeň"
 ],
 "Mondays": [
  null,
  "Pondelky"
 ],
 "Tuesdays": [
  null,
  "utorky"
 ],
 "Wednesdays": [
  null,
  "Stredy"
 ],
 "Thursdays": [
  null,
  "štvrtky"
 ],
 "Fridays": [
  null,
  "Piatky"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Sundays": [
  null,
  "Nedele"
 ],
 "Repeat monthly": [
  null,
  "Opakovať každý mesiac"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Unclean shutdown": [
  null,
  ""
 ],
 "View logs": [
  null,
  "Zobraziť záznamy udalostí"
 ],
 "Dismiss": [
  null,
  "Zahodiť"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Naplánované vypnutie o $0"
 ],
 "Cancel poweroff": [
  null,
  "Zrušiť vypínanie"
 ],
 "Scheduled reboot at $0": [
  null,
  "Naplánovaný reštart o $0"
 ],
 "Cancel reboot": [
  null,
  "Zrušiť reštart"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "Set hostname": [
  null,
  "Nastaviť názov stroja"
 ],
 "Configuration": [
  null,
  "Konfigurácia"
 ],
 "Hostname": [
  null,
  "Názov stroja"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Performance profile": [
  null,
  "Profil výkonu"
 ],
 "Secure shell keys": [
  null,
  "Kľúče zabezpečeného shellu"
 ],
 "Show fingerprints": [
  null,
  "Zobraziť odtlačky"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nepodarilo sa vypísať SSH kľúče stroja: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Načítanie SSH kľúčov sa nepodarilo"
 ],
 "Error message": [
  null,
  "Chybové hlásenie"
 ],
 "Loading keys...": [
  null,
  "Načítavam kľúče..."
 ],
 "No host keys found.": [
  null,
  "Neboli nájdené žiadne kľúče stroja."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Odtlačky SSH kľúčov stroja"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Skutočný názov stroja musí byť 64 znakov alebo menej"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutočný názov stroja môže obsahovať iba malé písmená, číslice, pomlčky a bodky (pri použití subdomén)"
 ],
 "Change host name": [
  null,
  "Zmeniť názov stroja"
 ],
 "Pretty host name": [
  null,
  "Pekný názov stroja"
 ],
 "Real host name": [
  null,
  "Skutočný názov stroja"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Používateľ $0 nemá oprávnenia meniť politiky pre šifrovanie"
 ],
 "Cryptographic policy": [
  null,
  "Politiky pre šifrovanie"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Odporúčané, bezpečné nastavenia pre aktuálne modely hrozieb."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "PREDVOLENÝ so zapnutím overovania podpisu SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Vyššia interoperabilita za cenu zvýšeného vystavenia sa útokom."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "PÔVODNÉ s interoperabilitou s Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Pri štarte systému v režime FIPS použiť iba schválené a povolené algoritmy."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS s ďalšími obmedzeniami Common Criteria."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chráni pred očakávanými útokmi v blízkej budúcnosti za cenu horšej interoperability."
 ],
 "Custom cryptographic policy": [
  null,
  "Používateľom definovaná politiky pre šifrovanie"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografické politiky sú súčasť systému, ktorá nastavuje hlavné kryptografické subsystémy, pokrýva protokoly TLS, IPSec, SSH, DNSSec a Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Zmeniť politiky pre šifrovanie"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplikujú sa nové politiky… Toto môže niekoľko minút trvať."
 ],
 "Reapply and reboot": [
  null,
  "Znovu použiť a reštartovať"
 ],
 "Apply and reboot": [
  null,
  "Použiť a reštartovať"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS nie je poriadne zapnuté"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Politiky pre šifrovanie nie sú konzistentné"
 ],
 "Review cryptographic policy": [
  null,
  "Skontrolovať politiky pre šifrovanie"
 ],
 "System information": [
  null,
  "Informácie o systéme"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Inventárny štítok"
 ],
 "Machine ID": [
  null,
  "Identifikátor stroja"
 ],
 "Up since": [
  null,
  "Beží od"
 ],
 "View hardware details": [
  null,
  "Zobraziť podrobnosti o hardvéri"
 ],
 "Last successful login:": [
  null,
  "Posledné úspešné prihlásenie:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 neúspešný pokus o prihlásenie",
  "$0 neúspešné pokusy o prihlásenie",
  "$0 neúspešných pokusov o prihlásenie"
 ],
 "View login history": [
  null,
  "Zobraziť históriu prihlásení"
 ],
 "recommended": [
  null,
  "odporúčaný"
 ],
 "inconsistent": [
  null,
  "nekonzistentný"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Pripájanie sa do domény vyžaduje inštaláciu realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nie je možné pridanie do domény, pretože na tomto systéme chýba realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Pridanie do tejto domény nie je podporované"
 ],
 "Login format": [
  null,
  "Formát prihlasovania"
 ],
 "Server software": [
  null,
  "Serverový softvér"
 ],
 "Client software": [
  null,
  "Softvér klienta"
 ],
 "Leave domain": [
  null,
  "Opustiť doménu"
 ],
 "Leave $0": [
  null,
  "Opustiť $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opustení domény sa k tomuto stroji budú môcť prihlásiť iba tí užívatelia, ktorý majú účet priamo na ňom. Môže to postihnúť aj ostatné služby, ako je nastavenie DNS prekladu a môže sa zmeniť zoznam dôveryhodných cert. autorít."
 ],
 "Validating address": [
  null,
  "Overujem adresu"
 ],
 "Contacted domain": [
  null,
  "Pripojená doména"
 ],
 "Domain could not be contacted": [
  null,
  "Doménu sa nepodarilo kontaktovať"
 ],
 "Domain is not supported": [
  null,
  "Doména nie je podporovaná"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Meno správcu domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správcu domény"
 ],
 "Joining": [
  null,
  "Pridávam"
 ],
 "Join": [
  null,
  "Spojiť"
 ],
 "This may take a while": [
  null,
  "Toto môže chvíľu trvať"
 ],
 "Not permitted to configure realms": [
  null,
  "Nemáte oprávnenia nastavovať realmy"
 ],
 "Join domain": [
  null,
  "Pripojiť sa k doméne"
 ],
 "Install realmd support": [
  null,
  "Nainštalovať podporu pre realmd"
 ],
 "Not connected to Insights": [
  null,
  "Nepripojené k Insights"
 ],
 "Health": [
  null,
  "Kondícia systému"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "z $0 procesorov",
  "z $0 procesorov"
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Pamäť"
 ],
 "View metrics and history": [
  null,
  "Zobraziť metriky a históriu"
 ],
 "Tuned is not available": [
  null,
  "Tuned nie je k dispozícii"
 ],
 "Tuned is not running": [
  null,
  "Tuned nie je spustené"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používa odporúčaný profil"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používa používateľom definovaný profil"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikácia s tuned sa nepodarila"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodarilo sa aktivovať tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodarilo sa deaktivovať tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Nepodarilo sa vypnúť profil tuned"
 ],
 "Failed to switch profile": [
  null,
  "Nepodarilo sa prepnúť profil"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "Disable tuned": [
  null,
  "Vypnúť tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Spustenie procesu služby tuned skončilo neúspechom"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba, ktorá sleduje váš systém a optimalizuje jeho výkon pod určitými typmi záťaží. Jadrom Tuned sú profily, ktoré ladia váš systém pre rôzne prípady použitia."
 ],
 "Change performance profile": [
  null,
  "Zmeniť profil výkonu"
 ],
 "Change profile": [
  null,
  "Zmeniť profil"
 ],
 "Edit /etc/motd": [
  null,
  "Upraviť /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodarilo sa uložiť zmeny v /etc/motd"
 ],
 "Save changes": [
  null,
  "Uložiť zmeny"
 ],
 "Edit motd": [
  null,
  "Upraviť motd"
 ],
 "Stub": [
  null,
  "Výhonok"
 ],
 "Not found": [
  null,
  "Nenájdené"
 ],
 "Bad setting": [
  null,
  "Chybné nastavenie"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Merged": [
  null,
  "Zlúčené"
 ],
 "Running": [
  null,
  "Beží"
 ],
 "Reloading": [
  null,
  "Opätovne načítam"
 ],
 "Not running": [
  null,
  "Nespustená"
 ],
 "Failed to start": [
  null,
  "Nepodarilo sa spustiť"
 ],
 "Maintenance": [
  null,
  "Údržba"
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Linked": [
  null,
  "Odkazované"
 ],
 "Alias": [
  null,
  "Alternatívny názov"
 ],
 "Masked": [
  null,
  "Maskovaná"
 ],
 "Static": [
  null,
  "Statická"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Indirect": [
  null,
  "Nepriamo"
 ],
 "Generated": [
  null,
  "Vytvorené"
 ],
 "Transient": [
  null,
  "Prechodné"
 ],
 "Bad": [
  null,
  "Chybné"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Prihlásenie k odberu signálov systemd sa nepodarilo: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Pripojenie k dbus sa nepodarilo: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Vypisovanie jednotiek skončilo s chybou: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 služba havarovala",
  "$0 služby havarovali",
  "$0 služieb havarovalo"
 ],
 "Loading of units failed": [
  null,
  "Načítanie jednotiek sa nepodarilo"
 ],
 "Loading...": [
  null,
  "Načítavam..."
 ],
 "Listing units": [
  null,
  "Vypisujem jednotky"
 ],
 "Filter by name or description": [
  null,
  "Filtrovať podľa názvu či popisu"
 ],
 "Active state": [
  null,
  "Aktívny stav"
 ],
 "File state": [
  null,
  "Stav súboru"
 ],
 "$0 filters applied": [
  null,
  ""
 ],
 "User": [
  null,
  "Používateľ"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Používateľ $0 nie je oprávnený meniť zmierňovanie dopadu chýb zabezpečenia procesora"
 ],
 "Mitigations": [
  null,
  "Zmiernenia dopadu"
 ],
 "Version": [
  null,
  "Verzia"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Verzia BIOSu"
 ],
 "BIOS date": [
  null,
  "Dátum vydania BIOSu"
 ],
 "CPU security": [
  null,
  "Zabezpečenie procesoru"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnúť simultánny multithreading"
 ],
 "Read more...": [
  null,
  "Zistiť viac…"
 ],
 "Save and reboot": [
  null,
  "Uložiť a reštartovať"
 ],
 "CPU security toggles": [
  null,
  "Prepínače zabezpečenia procesora"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softvérové ošetrenie problémov zabezpečenia procesoru znižujúce riziko ich zneužitia. Majú negatívny vplyv na výkon. Nastavenie meňte na vlastnú zodpovednosť."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Trieda"
 ],
 "Vendor": [
  null,
  "Výrobca"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Technológia pamäte"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Speed": [
  null,
  "Rýchlosť"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zobrazovanie informácií o pamäti vyžaduje oprávnenie na úrovni správcu systému."
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "Failed to fetch logs": [
  null,
  "Nepodarilo sa získať záznamy udalostí"
 ],
 "Clear all filters": [
  null,
  "Vypnúť všetky filtre"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nepodarilo sa nájsť žiadne záznamy pre danú kombináciu filtrov."
 ],
 "No logs found": [
  null,
  "Nenájdené žiadne záznamy udalostí"
 ],
 "Load earlier entries": [
  null,
  "Načítať skoršie položky"
 ],
 "You may try to load older entries.": [
  null,
  "Môžte skúsiť načítať skoršie záznamy."
 ],
 "Allow running (unmask)": [
  null,
  "Povoliť spustenie (odmaskovať)"
 ],
 "Reload": [
  null,
  "Znova načítať"
 ],
 "Restart": [
  null,
  "Reštart"
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistiť „Nepodarilo sa spustiť“"
 ],
 "Mask service": [
  null,
  "Maskovať službu"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskovanie služby zabráni spúšťaniu všetkých závislých jednotiek. Toto môže mať väčší dopad ako je zamýšľané. Prosím potvrďte, že chcete maskovať túto jednotku."
 ],
 "Disallow running (mask)": [
  null,
  "Nepovoliť spustenie (maskovať)"
 ],
 "Unpin unit": [
  null,
  "Zrušiť pripnutie jednotky"
 ],
 "Pin unit": [
  null,
  "Pripnúť jednotku"
 ],
 "Additional actions": [
  null,
  "Ďalšie akcie"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Táto jednotka je navrhnutá na to, aby bola výslovne zapnutá."
 ],
 "Forbidden from running": [
  null,
  "Spustenie je zakázané"
 ],
 "Start service": [
  null,
  "Spustiť službu"
 ],
 "Active since ": [
  null,
  "Aktívna od "
 ],
 "Required by ": [
  null,
  "Vyžadované "
 ],
 "Read-only": [
  null,
  "Iba na čítanie"
 ],
 "Requires administration access to edit": [
  null,
  "Pre úpravu sa vyžadujú administrátorské práva"
 ],
 "Automatically starts": [
  null,
  "Spúšťa sa automaticky"
 ],
 "Updating status...": [
  null,
  "Aktualizujem stav..."
 ],
 "Stop and disable": [
  null,
  "Zastaviť a vypnúť"
 ],
 "Start and enable": [
  null,
  "Spustiť a zapnúť"
 ],
 "Failed to load unit": [
  null,
  "Jednotku sa nepodarilo načítať"
 ],
 "View all services": [
  null,
  "Zobraziť všetky služby"
 ],
 "Triggers": [
  null,
  "Spúšťače"
 ],
 "Triggered by": [
  null,
  "Spustené na základe"
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requisite": [
  null,
  "Rekvizita"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Binds to": [
  null,
  "Viaže sa na"
 ],
 "Part of": [
  null,
  "Súčasť"
 ],
 "Required by": [
  null,
  "Vyžadované"
 ],
 "Requisite of": [
  null,
  "Závislosť pre"
 ],
 "Wanted by": [
  null,
  "Vyžadované"
 ],
 "Bound by": [
  null,
  "Viazaný"
 ],
 "Consists of": [
  null,
  "Skladá sa z"
 ],
 "Conflicts": [
  null,
  "V konflikte"
 ],
 "Conflicted by": [
  null,
  "V konflikte"
 ],
 "Before": [
  null,
  "Pred"
 ],
 "After": [
  null,
  "Po"
 ],
 "On failure": [
  null,
  "Pri chybe"
 ],
 "Propagates reload to": [
  null,
  "Propaguje načítať opäť k"
 ],
 "Reload propagated from": [
  null,
  "Znovu načítať propagované z"
 ],
 "Joins namespace of": [
  null,
  "Pripája menný priestor od"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmienka $0=$1 nebola splnená"
 ],
 "Deletion will remove the following files:": [
  null,
  "Zmazanie odstráni nasledujúce súbory:"
 ],
 "Pinned unit": [
  null,
  "Pripnutá jednotka"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Path": [
  null,
  "Cesta"
 ],
 "Listen": [
  null,
  "Načúvať"
 ],
 "View Podman container": [
  null,
  ""
 ],
 "Condition failed": [
  null,
  "Podmienka nesplnená"
 ],
 "Show more relationships": [
  null,
  "Zobraziť ďalšie vzťahy"
 ],
 "Show relationships": [
  null,
  "Zobraziť vzťahy"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte odstránenie $0"
 ],
 "Timer deletion failed": [
  null,
  "Odstránenie časovača zlyhalo"
 ],
 "Targets": [
  null,
  "Ciele"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "Paths": [
  null,
  "Cesty"
 ],
 "Go to $0": [
  null,
  "Prejsť na $0"
 ],
 "Journal entry not found": [
  null,
  "Položka žurnálu nájdená"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Entry at $0": [
  null,
  "Položka z"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "Loading unit failed": [
  null,
  "Načítanie jednotiek zlyhalo"
 ],
 "Service logs": [
  null,
  "Záznamy udalostí služby"
 ],
 "No log entries": [
  null,
  "Žiadne záznamy udalostí"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Kritériám filtra nezodpovedajú žiadne výsledky. Pre zobrazenie výsledkov vypnite všetky filtre."
 ],
 "Does not automatically start": [
  null,
  "Nespúšťa sa automaticky"
 ],
 "Cannot be enabled": [
  null,
  "Nie je možné povoliť"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzola beží v režime obmedzeného prístupu."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Doména"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Pridať do domény"
 ]
});
