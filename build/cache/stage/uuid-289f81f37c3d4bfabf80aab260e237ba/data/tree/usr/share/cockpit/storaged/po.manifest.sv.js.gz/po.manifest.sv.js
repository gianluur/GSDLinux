cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "mount": [
  null,
  "montering"
 ],
 "format": [
  null,
  "formatera"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "partition": [
  null,
  "partition"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volym"
 ],
 "disk": [
  null,
  "disk"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "disk"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Hantera partitioner"
 ],
 "Managing NFS mounts": [
  null,
  "Hantera NFS-monteringar"
 ],
 "Managing RAIDs": [
  null,
  "Hantera RAID:ar"
 ],
 "Managing LVMs": [
  null,
  "Hantera LVM:er"
 ],
 "Managing physical drives": [
  null,
  "Hantera fysiska diskar"
 ],
 "Managing VDOs": [
  null,
  "Hantera VDO:er"
 ],
 "Using LUKS encryption": [
  null,
  "Använder LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Använder Tang-server"
 ]
});
