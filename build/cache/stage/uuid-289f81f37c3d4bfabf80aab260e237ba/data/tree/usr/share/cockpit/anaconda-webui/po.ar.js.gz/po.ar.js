cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "لا أخطاء",
  "خطأ واحد",
  "خطأن",
  "$0 أخطاء",
  "$0 خطأً",
  "$0 خطأ"
 ],
 "$0 installation": [
  null,
  "تثبيت $0"
 ],
 "$0 installer": [
  null,
  "مُثبّت $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 هو قسم MBR موسع يحتوي على أقسام منطقية. ستؤدي إزالة جميع الأقسام المنطقية أيضًا إلى إزالة القسم الموسع تلقائيًا."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "مطلوب $0، ولكن يتوفر $1 فقط."
 ],
 "$0 warning": [
  null,
  "$0 تحذير",
  "تحذير",
  "تحذيران",
  "$0 تحذيرات",
  "$0 تحذير",
  "$0 تحذير"
 ],
 "$0 will be deleted": [
  null,
  "$0 سيُحذف"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "لا يمكن أن يكون نظام الملفات '$0' على جهاز كُتلة مُعمَّاة"
 ],
 "'$0' must be assigned to $1": [
  null,
  "يجب تعيين '$0' إلى $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "يجب أن يكون '$0' على جهاز مهيأ إلى '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "يجب أن يكون '$0' على قسم نظام EFI. يستخدم القسم المحدّد نظام ملفات FAT، ولكنه غير محدد كـ ESP. عيِّن نوع القسم إلى EFI System وفعِّل علامة esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "عُثر على قسم '$0' على جهاز MDRAID $1. أقسام محمّل إقلاع (bootloader) على أجهزة MDRAID غير مدعومة."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "حساب مستخدم قياسي بصلاحيات إدارية لإجراء تغييرات على مستوى النظام."
 ],
 "Abort installation": [
  null,
  "أجهض التثبيت"
 ],
 "About": [
  null,
  "حول"
 ],
 "Account": [
  null,
  "حساب"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Add another server...": [
  null,
  "أضف خادم آخر..."
 ],
 "Add mount": [
  null,
  "أضف نقطة وصل"
 ],
 "Add-ons for your chosen environment": [
  null,
  "الإضافات لبيئتك المختارة"
 ],
 "Add-ons not specific to your environment": [
  null,
  "الإضافات غير مخصصة لبيئتك"
 ],
 "Additional languages": [
  null,
  "اللّغات المتاحة"
 ],
 "Additional software for the selected environment": [
  null,
  "برمجيات إضافية للبيئة المُنتقاة"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "تسري جميع التغييرات التي أجريت في محرّر التخزين على الفور."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "سيُفتح جميع الأجهزة التي تستخدم عبارة السر هذه"
 ],
 "Anaconda Web UI": [
  null,
  "أناكوندا واجهة ويب"
 ],
 "Anaconda project page": [
  null,
  "صفحة مشروع أناكوندا"
 ],
 "Apply mount point assignment and install": [
  null,
  "طبق تعيين نقطة الوصل وثبِّت"
 ],
 "Applying changes...": [
  null,
  "يطبِّق التغييرات..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "عيّن الأقسام إلى نقاط الوصل. مفيد للتخطيطات المخصّصة مضبطة مسبقًا."
 ],
 "Automatic log file upload": [
  null,
  "رفع ملف السجل تلقائيًا"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "عيّن التاريخ والوقت تلقائيًا، باستخدام خوادم الوقت"
 ],
 "Automatically set timezone": [
  null,
  "عيّن المنطقة الزمنية تلقائيًا"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "المساحة الخالية المتاحة: $0. يتطلب التثبيت: $1."
 ],
 "Back": [
  null,
  "ارجع"
 ],
 "Base environment": [
  null,
  "البيئة الأساسية"
 ],
 "Brief description of the issue": [
  null,
  "وصف موجز للمشكلة"
 ],
 "Bug report details": [
  null,
  "تفاصيل تقرير الخطأ"
 ],
 "Bugzilla API key": [
  null,
  "مفتاح Bugzilla API"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "استمرارك في استخدام هذا البرنامج، فأنت تدرك وتقبل المخاطر المرتبطة بالبرمجيات التي أُصدرت مسبقًا، وعليك استخدامها لأغراض الاختبار والتطوير فقط، وأنت على استعداد للإبلاغ عن أي أخطاء أو مشاكل من أجل تحسين هذا العمل."
 ],
 "Cancel": [
  null,
  "ألغِ"
 ],
 "Change": [
  null,
  "غيّر"
 ],
 "Change destination": [
  null,
  "غيّر الوجهة"
 ],
 "Change hostname": [
  null,
  "غيّر اسم المضيف"
 ],
 "Change partition layout": [
  null,
  "غيّر تخطيط الأقسام"
 ],
 "Change system keyboard layout": [
  null,
  "غيّر نظام تخطيط لوحة المفاتيح"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "ستؤثر التغييرات التي أجريت هنا على النظام فورًا. لا يوجد \"تراجع\"."
 ],
 "Checking installation configuration...": [
  null,
  "يجري التحقق من تضبيط التثبيت..."
 ],
 "Checking storage configuration": [
  null,
  "التحقق من تضبيط وحدة التخزين"
 ],
 "Clear search": [
  null,
  "امسح البحث"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "انقر فوق 'التالي' مرة أخرى للمتابعة على الرغم من هذه التحذيرات."
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Close storage editor": [
  null,
  "أغلق محرّر التخزين"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "لم يوفر Cockpit storage عبارة السر لفتح الجهاز المُعمَّى."
 ],
 "Completed": [
  null,
  "اكتُمل"
 ],
 "Configuration is incomplete": [
  null,
  "التضبيط غير مكتمل"
 ],
 "Configure NTP servers": [
  null,
  "اضبط خوادم NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "اضبط خوادم NTP المخصّصة"
 ],
 "Configure network": [
  null,
  "اضبط الشبكة"
 ],
 "Configure storage": [
  null,
  "اضبط التخزين"
 ],
 "Configure storage again": [
  null,
  "اضبط التخزين مرة أخرى"
 ],
 "Confirm passphrase": [
  null,
  "أكّد عبارة السر"
 ],
 "Continue": [
  null,
  "استمر"
 ],
 "Continue installation": [
  null,
  "استمر التثبيت"
 ],
 "Continue installation?": [
  null,
  "استمر التثبيت؟"
 ],
 "Continue with installation": [
  null,
  "استمر مع التثبيت"
 ],
 "Correct these issues before continuing.": [
  null,
  "أصلح هذه الأخطاء قبل الاستمرار."
 ],
 "Create Account": [
  null,
  "إنشاء حساب"
 ],
 "Create account": [
  null,
  "أنشئ حسابًا"
 ],
 "Currently installed: $0": [
  null,
  "المثبتة حاليًا: $0"
 ],
 "Custom": [
  null,
  "مخصّص"
 ],
 "Date": [
  null,
  "التاريخ"
 ],
 "Date and time": [
  null,
  "التاريخ والوقت"
 ],
 "Delete partition": [
  null,
  "احذف القسم"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "قد يؤدي حذف بعض الأقسام إلى منع $0 من الإقلاع: $1"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Destination": [
  null,
  "الوجهة"
 ],
 "Destination is encrypted": [
  null,
  "الوجهة مُعمَّاة"
 ],
 "Detailed description of the issue": [
  null,
  "وصف مفصل للمشكلة"
 ],
 "Detected valid storage layout:": [
  null,
  "كُشف عن تخطيط تخزين صالح:"
 ],
 "Device": [
  null,
  "جهاز"
 ],
 "Duplicate device.": [
  null,
  "جهاز مكرّر."
 ],
 "Duplicate mount point.": [
  null,
  "نقطة الوصل مكرّرة."
 ],
 "Enable root account": [
  null,
  "فعّل حساب الجذر"
 ],
 "Encrypt my data": [
  null,
  "عمِّ «(شفّر)» بياناتي"
 ],
 "Encrypted": [
  null,
  "مُعمَّاة"
 ],
 "Encryption": [
  null,
  "التعمية"
 ],
 "Enter PIN": [
  null,
  "أدخِل PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "أدخِل PIN للوصول إلى المثبِّت"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "أدخل مفتاح Bugzilla API لإنشاء تقرير عن خطأ. ستتمكن من مراجعة وتعديل تفاصيل الخطأ في الخطوة التالية."
 ],
 "Environment": [
  null,
  "البيئة"
 ],
 "Erase data and install": [
  null,
  "أمحو البيانات وثبّت"
 ],
 "Error details": [
  null,
  "تفاصيل الخطأ"
 ],
 "Exit to live desktop": [
  null,
  "اخرج إلى سطح المكتب المباشر"
 ],
 "Extended partition": [
  null,
  "قسم ممتد"
 ],
 "Failed to report issue": [
  null,
  "فشل في الإبلاغ عن المشكلة"
 ],
 "Failed to save layouts": [
  null,
  "فشل حفظ التخطيطات"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "يتطلب فيدورا لينكس $0 على الأقل من مساحة القرص."
 ],
 "Finalization": [
  null,
  "الختام"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "اللمسات الأخيرة: اكتمل تضبيط النظام. قد يستغرق الانتهاء من التثبيت بضع لحظات."
 ],
 "Find layout": [
  null,
  "ابحث عن تخطيط"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "لأمان أفضل، تجنب استخدام حساب الجذر مباشرةً. بدلاً من ذلك، استخدم الحساب المحلي أعلاه لإدارة النظام."
 ],
 "Full name": [
  null,
  "الاسم الكامل"
 ],
 "Full name cannot contain colon characters": [
  null,
  "لا يمكن للاسم الكامل أن يحتوي على فواصل"
 ],
 "Helper text": [
  null,
  "نص المساعدة"
 ],
 "Hide API key": [
  null,
  "أخفِ مفتاح API"
 ],
 "Hide PIN": [
  null,
  "أخفِ PIN"
 ],
 "Hide confirmed password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Hide passphrase": [
  null,
  "أخفِ عبارة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "Hostname": [
  null,
  "اسم المضيف"
 ],
 "How would you like to install?": [
  null,
  "كيف تريد التثبيت؟"
 ],
 "I understand that all existing data will be erased": [
  null,
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة حاليًا",
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة حاليًا",
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة على الأقراص المُحدّدة",
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة على الأقراص المُحدّدة",
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة على الأقراص المُحدّدة",
  "أدرك تمامًا أنه سيتم مسح جميع البيانات الموجودة على الأقراص المُحدّدة"
 ],
 "I understand that some existing data will be erased": [
  null,
  "أتفهم أنه سيتم مسح بعض البيانات الموجودة حاليًا"
 ],
 "I understand that some partitions will be modified": [
  null,
  "أتفهم أنه سيتم تعديل بعض الأقسام"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "إذا كان فارغًا، فسيكون اسم المضيف عابرًا ويتم تعيينه بواسطة معلومات الشبكة."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "إذا لم ينطبق أي من الخيارات المذكورة أعلاه، فاستخدم محرِّر التخزين لإنشاء تقسيم مخصّص قبل المتابعة."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "إذا كنت تضبط الأقسام، فيجب اتباع التالي:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "إذا لم توافق على التحميل التلقائي لملفات السجلّ، يمكنك بدلاً من ذلك $0. يتيح لك الإبلاغ اليدوي مراجعة وإرفاق ملفات السجل بنفسك بشكل انتقائي."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "إذا كنت لا تفهم أو لا تقبل المخاطر، ففضلاً أخرج من هذا البرنامج."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "إذا كانت مشكلتك تتطابق مع إحدى الأخطاء المذكورة أعلاه، فيمكنك فتحها وإضافة معلوماتك إليها بدلاً من إنشاء تقرير مكرر."
 ],
 "In progress": [
  null,
  "جارِ العمل"
 ],
 "Initializing...": [
  null,
  "التهيئة..."
 ],
 "Install": [
  null,
  "ثبِّت"
 ],
 "Installation failed": [
  null,
  "فشل التثبيت"
 ],
 "Installation method": [
  null,
  "طريقة التثبيت"
 ],
 "Installation of the system failed": [
  null,
  "فشل تثبيت النظام"
 ],
 "Installation of the system failed: $0": [
  null,
  "فشل تثبيت النظام: $0"
 ],
 "Installation type": [
  null,
  "نوع التثبيت"
 ],
 "Installing": [
  null,
  "جارِ التثبيت"
 ],
 "Insufficient disk space": [
  null,
  "مساحة القرص غير كافية"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "PIN غير صحيح. يُرجى المحاولة مرة أخرى."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "اكتُشف تضبيط RAID غير صالح. إذا أُنشئت مصفوفة RAID مباشرةً فوق الأقراص، فيجب إنشاء جدول أقسام عليها. إذا أُنشئت مصفوفة RAID فوق أقسام، فيجب أن تحتوي على نظام ملفات أو تنسيق واحد (مثل LVM PV). سيتم تجاهل أي أقسام موجودة على هذه المصفوفة."
 ],
 "Invalid hostname": [
  null,
  "اسم المضيف غير صالح"
 ],
 "Jump to first incomplete step": [
  null,
  "اقفز إلى أول خطوة غير مكتملة"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "احتفظ بتخطيط القرص الحالي واستخدم المساحة المتاحة، للإقلاع المزدوج مع نظام تشغيل آخر."
 ],
 "Keyboard": [
  null,
  "لوحة المفاتيح"
 ],
 "Keyboard layout during boot": [
  null,
  "تخطيط لوحة المفاتيح أثناء الإقلاع"
 ],
 "Language": [
  null,
  "اللّغة"
 ],
 "Launch storage editor": [
  null,
  "أطلِق محرّر التخزين"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "تعرّف على المزيد حول الوصول المقيد في التضبيط"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "اترك كِلا حقلي عبارة المرور فارغين لاستخدام كلمة سر فارغة."
 ],
 "Location": [
  null,
  "الموقع"
 ],
 "Locked devices": [
  null,
  "الأجهزة المقفلة"
 ],
 "Log in": [
  null,
  "لِج"
 ],
 "Make current": [
  null,
  "اجعله الحالي"
 ],
 "Manual disk configuration": [
  null,
  "تضبيط القرص اليدوي"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "تضبيط القرص اليدوي: تعيين نقطة الوصل"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "قد يحتوي على حروف وأرقام وشرطات."
 ],
 "May need more free space": [
  null,
  "قد تحتاج إلى مساحة فارغة أكبر"
 ],
 "Medium": [
  null,
  "متوسط"
 ],
 "Minimum of $0 required": [
  null,
  "الحد الأدنى المطلوب هو $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "عدم تطابق بين الجهاز الأصل وتحديد إعادة تهيئة الجهاز الفرعي."
 ],
 "Mount point": [
  null,
  "نقطة الوصل"
 ],
 "Mount point assignment": [
  null,
  "تعيين نقطة الوصل"
 ],
 "Move down": [
  null,
  "حرّك لأسفل"
 ],
 "Move up": [
  null,
  "حرّك لأعلى"
 ],
 "Must be at least $0 characters": [
  null,
  "يجب ألا يقل عدد المحارف عن $0"
 ],
 "My issue is different, continue": [
  null,
  "مشكلتي مختلفة، استمر"
 ],
 "NTP Servers": [
  null,
  "خوادم NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Needs at least $0": [
  null,
  "يحتاج إلى $0 على الأقل"
 ],
 "Network": [
  null,
  "شبكة"
 ],
 "Network Configuration": [
  null,
  "تضبيط الشبكة"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "الشبكة غير متوفرة. اضبط الشبكة في قائمة الشريط العلوي للإبلاغ عن المشكلة."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "الشبكة غير متوفرة. اضبط الشبكة للإبلاغ عن المشكلة."
 ],
 "Network plugin failed": [
  null,
  "فشل المكون الإضافي للشبكة"
 ],
 "Next": [
  null,
  "التالي"
 ],
 "No devices": [
  null,
  "لا يوجد أجهزة"
 ],
 "No disks available": [
  null,
  "لا توجد أقراص متاحة"
 ],
 "No disks selected": [
  null,
  "لم تحدّد أيّ قرص"
 ],
 "No keyboard layouts selected": [
  null,
  "لم يحدّد أي تخطيطات لوحة مفاتيح"
 ],
 "No layouts selected yet": [
  null,
  "لم يحدد أي تخطيطات بعد"
 ],
 "No results found": [
  null,
  "لم يُعثر على نتائج"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "لا يمكن الحصول على تخطيط مفاتيح VConsole صالح لتخطيط/ات لوحة المفاتيح المحدّد. يُرجى اختيار تخطيط لوحة مفاتيح مختلف."
 ],
 "Not enough available free space": [
  null,
  "لا توجد مساحة فارغة كافية"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "لا تتوفر مساحة خالية كافية في الأقراص المُحدّدة."
 ],
 "Not enough space on selected disks.": [
  null,
  "لا تتوفر المساحة الكافية في الأقراص المُحدّدة."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "ملحوظة: هذا برنامج أُصدر مسبقًا وهو مخصّص لأغراض التطوير والاختبار فقط. لا تستخدم هذا البرنامج لأي عمل حرِج أو لبيئات الإنتاج."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "افتح نموذج إدخال بلاغ خطأ في Bugzilla"
 ],
 "Operating system": [
  null,
  "نظام التشغيل"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Other keyboards": [
  null,
  "لوحات مفاتيح أخرى"
 ],
 "Partitions (advanced)": [
  null,
  "التقسيمات (متقدم)"
 ],
 "Passphrase": [
  null,
  "عبارة السر"
 ],
 "Passphrase did not match any locked device": [
  null,
  "لم تتطابق عبارة السر مع أي جهاز مُقفل"
 ],
 "Passphrases must match": [
  null,
  "يجب أن تتطابق عبارتا السر"
 ],
 "Pending": [
  null,
  "منتظر"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "يُرجى إرفاق ملف السجل $0 للمشكلة."
 ],
 "Please enter a PIN": [
  null,
  "أدخِل PIN من فضلك"
 ],
 "Please select at least one disk to continue": [
  null,
  "الرجاء تحديد قرص واحد على الأقل لاستمرار"
 ],
 "Pool": [
  null,
  "مجمع"
 ],
 "Potential duplicate bugs found": [
  null,
  "عُثر على أخطاء محتملة مكررة"
 ],
 "Powered by Anaconda": [
  null,
  "مدعوم من أناكوندا"
 ],
 "Pre-release": [
  null,
  "الإصدار الأولي"
 ],
 "Prefer to report manually? $0": [
  null,
  "تفضل التبليغ يدويًا؟ $0"
 ],
 "Proceed with installation": [
  null,
  "واصِل التثبيت"
 ],
 "Quit": [
  null,
  "أنهِ"
 ],
 "Quit installer?": [
  null,
  "إنهاء المثبِّت؟"
 ],
 "Reading information about the OS failed.": [
  null,
  "فشلت قراءة المعلومات حول نظام التشغيل."
 ],
 "Reading information about the computer failed.": [
  null,
  "فشلت قراءة المعلومات حول الحاسب."
 ],
 "Reading installer configuration failed.": [
  null,
  "فشلت قراءة تضبيط المثبِّت."
 ],
 "Reading installer version information failed.": [
  null,
  "فشلت قراءة معلومات إصدار المثبِّت."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "اسم المضيف الحقيقي يمكن أن يحتوي فقط على محارف وأرقام وشرطات (لا تبدأ أو تنتهي بمحرف) ونقاط"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "ينبغي أن يكون طول اسم المضيف ٦٤ حرفا أو أقل"
 ],
 "Reboot": [
  null,
  "أعد التشغيل"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "أعد تشغيل Windows لتغيير حجم الأقسام المُعمَّاة باستخدام BitLocker. أتح مساحة خالية لا تقل عن $0 للتثبيت."
 ],
 "Reboot system?": [
  null,
  "إعادة تشغيل النظام؟"
 ],
 "Reclaim additional space": [
  null,
  "استعد المساحة لإضافية"
 ],
 "Reclaim space": [
  null,
  "استعد المساحة"
 ],
 "Reclaim space (required)": [
  null,
  "استعد المساحة (مطلوب)"
 ],
 "Recommended": [
  null,
  "مستحسن"
 ],
 "Recommended partitions:": [
  null,
  "التقسيمات الموصى بها:"
 ],
 "Reformat": [
  null,
  "أعِد التهيئة"
 ],
 "Reinstall Fedora": [
  null,
  "أعد تثبيت فيدورا"
 ],
 "Remove": [
  null,
  "أزِل"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "أزِل جميع الأقسام الموجودة على الأجهزة المُحدّدة، بما في ذلك أنظمة التشغيل الموجودة."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "أزِل أنظمة الملفات الموجودة أو غيّر حجمها لإخلاء مساحة للتثبيت."
 ],
 "Remove server": [
  null,
  "أزِل الخادم"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "سيؤدي حذف نظام ملفات إلى حذف جميع البيانات التي يحتويها نهائيًا. قد يؤدي تغيير حجم القسم إلى إخلاء المساحة الغير مستخدمة، ولكنه ليس خاليًا من المخاطر. تأكد من الاحتفاظ بنُسخ احتياطية لأي بيانات مهمة قبل استعادة المساحة."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "استبدل التثبيت الحالي، ولكن احتفظ بملفات المنزل."
 ],
 "Report Issue": [
  null,
  "أبلغ عن مشكلة"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "أبلغ عن مشكلة أو قدم ملاحظات عن طريق فتح نموذج إدخال خطأ Bugzilla $0."
 ],
 "Report issue": [
  null,
  "أبلغ عن مشكلة"
 ],
 "Reporting issue...": [
  null,
  "يُبلغ عن مشكلة..."
 ],
 "Required": [
  null,
  "مطلوب"
 ],
 "Requirements": [
  null,
  "متطلبات"
 ],
 "Rescan devices": [
  null,
  "أعد فحص الأجهزة"
 ],
 "Rescanning of the disks failed.": [
  null,
  "فشلت عملية إعادة فحص الأقراص."
 ],
 "Resize": [
  null,
  "غيّر الحجم"
 ],
 "Resize partition": [
  null,
  "غيِّر حجم القسم"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "غيّر حجم الأقسام التالية من $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "تقييد الوصول إلى التقرير"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "يقصر التقرير على المجموعة $0. $1"
 ],
 "Return to installation": [
  null,
  "عُد إلى التثبيت"
 ],
 "Return to storage editor": [
  null,
  "عُد إلى محرّر التخزين"
 ],
 "Review and install": [
  null,
  "راجع وثبِّت"
 ],
 "Root account has been configured": [
  null,
  "ضُبط حساب جذر"
 ],
 "Root account is enabled": [
  null,
  "حساب الجذر مُفعّل"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "فُعَّل حساب الجذر، ولكن لم يُضبط أي حساب مستخدم"
 ],
 "Root password has been set.": [
  null,
  "عُيِّن كلمة سر الجذر."
 ],
 "Save": [
  null,
  "احفظ"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "امسح QR باستخدام هاتفك أو زُر:"
 ],
 "Search for a language": [
  null,
  "ابحث عن لُغة"
 ],
 "Search for additional software": [
  null,
  "ابحث عن برمجيات إضافية"
 ],
 "Search for an environment": [
  null,
  "ابحث عن بيئة"
 ],
 "Search keyboard layout": [
  null,
  "البحث عن تخطيط لوحة المفاتيح"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "أمّن بياناتك باستخدام التعمية المستندة إلى القرص. ينطبق فقط على الأقسام الجديدة"
 ],
 "Select": [
  null,
  "حدّد"
 ],
 "Select a device": [
  null,
  "الجهاز المُحدّد"
 ],
 "Select city": [
  null,
  "حدّد مدينة"
 ],
 "Select destination": [
  null,
  "حدّد الهدف"
 ],
 "Select region": [
  null,
  "حدّد منطقة"
 ],
 "Selected (top = current)": [
  null,
  "محدّد (الأعلى = الحالي)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "الجهاز المهيء المُحدّد '$0' لا يمكن إعادة تهيئته."
 ],
 "Send us feedback on your installation": [
  null,
  "أرسل لنا تعليقاتك حول تثبيتك"
 ],
 "Server": [
  null,
  "الخادم"
 ],
 "Server is not reachable": [
  null,
  "الخادم لا يمكن الوصول إليه"
 ],
 "Set custom hostname": [
  null,
  "اضبط اسم مضيف مخصّص"
 ],
 "Share disk with other operating systems": [
  null,
  "شارك القرص مع نظام تشغيل آخر"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "شارك القرص مع أنظمة تشغيل أخرى: $0"
 ],
 "Show AM/PM": [
  null,
  "أظهِر صباحًا/مساءً"
 ],
 "Show API key": [
  null,
  "أظهِر مفتاح API"
 ],
 "Show PIN": [
  null,
  "أظهِر PIN"
 ],
 "Show confirmed password": [
  null,
  "أظهِر كلمة السر المؤكدة"
 ],
 "Show passphrase": [
  null,
  "أظهِر عبارة السر"
 ],
 "Show password": [
  null,
  "أظهِر كلمة السر"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Software installation": [
  null,
  "تثبيت البرمجيات"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "تثبيت البرنامج: اكتمل تضبيط التخزين. يتم الآن تثبيت البرنامج على جهازك."
 ],
 "Software selection": [
  null,
  "انتقاء البرمجيات"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "لا تزال هناك بعض خطوات التثبيت التي يجب إكمالها قبل أن تتمكن من الاستمرار."
 ],
 "Some required partitions are missing: $0": [
  null,
  "بعض الأقسام المطلوبة مفقودة: $0"
 ],
 "Space": [
  null,
  "المساحة"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Storage configuration": [
  null,
  "تضبيط التخزين"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "تضبيط التخزين: التخزين حاليًا قيد التضبيط."
 ],
 "Storage editor": [
  null,
  "محرّر التخزين"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "يعتمد التخزين على تضبيط من \"تعديل التخزين\"."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "حُدد مخطط التخزين بواسطة ملف الـ kickstart. ويمكن مراجعة مخطط التقسيم المخطط له في خطوة الملخص."
 ],
 "Storage plugin failed": [
  null,
  "فشل المكون الإضافي للتخزين"
 ],
 "Storage requirements not met": [
  null,
  "متطلبات التخزين غير مستوفاة"
 ],
 "Strong": [
  null,
  "قوية"
 ],
 "Successfully installed": [
  null,
  "نجح التثبيت"
 ],
 "Successfully unlocked $0.": [
  null,
  "فُتح بنجاح $0."
 ],
 "Suggested keyboards": [
  null,
  "لوحات المفاتيح المقترحة"
 ],
 "Suggested languages": [
  null,
  "اللّغات المقترحة"
 ],
 "System": [
  null,
  "النظام"
 ],
 "System configuration": [
  null,
  "تضبيط النظام"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "تضبيط النظام: اكتمل تثبيت البرنامج. يتم الآن تضبيط النظام."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "توقف تثبيت أناكوندا بشكل غير متوقع."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "قد تكون الأخطاء المفتوحة التالية ذات صلة بمشكلتك. يُرجى مراجعتها قبل إنشاء تقرير جديد."
 ],
 "The following user will be created:": [
  null,
  "لا مستخدم لإنشاء:",
  "سيُنشئ المستخدم التالي:",
  "سيُنشئ المستخدمين التاليين:",
  "سيُنشئ المستخدمين التاليين:",
  "سيُنشئ المستخدمين التاليين:",
  "سيُنشئ المستخدمين التاليين:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "يحتاج التثبيت إلى $0 من مساحة القرص؛ ومع ذلك، فإن سعة الأقراص المُحدّدة هي $1 فقط."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "يتعذر على المثبِّت الاستمرار بسبب خطأ فادح."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "يتعذر على المثبِّت الاستمرار بسبب خطأ فادح: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "تحتوي عبارة السر التي أدخلتها على حروفا ليست ASCII (لاتينية). قد لا تتمكن من التبديل بين تخطيطات لوحة المفاتيح عند كتابتها."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "تخطيط لوحة المفاتيح المبدئية المحدد لا يدعم أحرف ASCII. يُرجى اختيار تخطيط يدعم ASCII كالمبدئي."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "يتيح لك محرّر التخزين تغيير حجم الأقسام وحذفها وإنشائها. كما يمكنه إعداد LVM وغير ذلك الكثير. صُمّم للاستخدام كأداة مساعدة متقدمة، وليس للاستخدام في التثبيتات التقليدية."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "قد تحتوي ملفات السجلات هذه على معلومات حساسة مثل عناوين IP أو أسماء المستخدمين أو تفاصيل نظام أخرى."
 ],
 "This hostname can't be submitted": [
  null,
  "لا يمكن إرسال اسم المضيف هذا"
 ],
 "This is unstable, pre-release software": [
  null,
  "هذه برمجيّات ما قبل الإصدار وهي غير مستقرة"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "سيتم استخدام هذا التخطيط لفتح نظامك عند التمهيد"
 ],
 "This may take a moment": [
  null,
  "قد تأخذ قليلًا من الوقت"
 ],
 "This will take a few moments": [
  null,
  "سيستغرق ذلك بضع لحظات"
 ],
 "Time": [
  null,
  "الوقت"
 ],
 "Timezone": [
  null,
  "المنطقة الزمنية"
 ],
 "Title": [
  null,
  "العنوان"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "لبدء استخدام $0، أعد تشغيل الجهاز."
 ],
 "To continue, select the devices to install to.": [
  null,
  "لاستمرار، حدّد الأجهزة المراد التثبيت عليها."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "لاستخدام هذا الخيار، غيّر حجم الأقسام الموجودة أو أزلها لإخلاء $0 على الأقل."
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "غير قادر على جدولة حذف $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "غير قادر على جدولة تغيير حجم $0"
 ],
 "Undo last action": [
  null,
  "تراجع عن آخر إجراء"
 ],
 "Unlock": [
  null,
  "افتح"
 ],
 "Unlock encrypted devices": [
  null,
  "افتح الأجهزة المُعمَّاة"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "افتح الأقسام المُعمَّاة للاحتفاظ بالبيانات الموجودة وإظهار المزيد من طُرق التثبيت."
 ],
 "Use configured storage": [
  null,
  "استخدام التخزين المضبط"
 ],
 "Use entire disk": [
  null,
  "استخدم القرص بأكمله"
 ],
 "Use free space": [
  null,
  "استخدم المساحة الخالية"
 ],
 "Use local account": [
  null,
  "استخدم حساب محلي"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "استخدم جهاز RAID للتقسيم التلقائي"
 ],
 "User creation": [
  null,
  "إنشاء المستخدم"
 ],
 "User name": [
  null,
  "اسم المستخدم"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "يمكن أن يحتوي اسم المستخدم فقط على: الأحرف من a-z، والأرقام من 0-9، والشرطة $0، والنقطة $1، والشرطة السفلية $2"
 ],
 "User name must not be a reserved word": [
  null,
  "يجب ألا يكون اسم المستخدم كلمة محجوزة"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "ينبغي أن يكون اسماء المستخدمين أقصر من 33 حرفا"
 ],
 "Validating...": [
  null,
  "يتحقق..."
 ],
 "Weak": [
  null,
  "ضعيفة"
 ],
 "Welcome": [
  null,
  "الترحيب"
 ],
 "Welcome to Fedora Linux": [
  null,
  "مرحبًا بكم في فيدورا لينكس"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "أهلاً وسهلاً بك. هيا لنثبت $0 الآن."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "عند تقديمك لهذا التقرير عن الخطأ، سيتم رفع ملفات السجلّ التالية تلقائيًا: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "لا يمكن تغيير حجم أقسام Windows المزودة بتعمية BitLocker"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "يمكنك إما إخلاء مساحة كافية هنا والسماح للمُثبِّت بالتعامل مع الباقي أو إعداد الأقسام يدويًا."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "يمكنك إنشاء مفتاح API لحساب Bugzilla الخاص بك $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "يجب عليك تفعيل حساب الجذر أو إنشاء حساب مستخدم محلي للمتابعة."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "يجب أن تكون متصلاً بالشبكة لتفعيل التاريخ والوقت التلقائيين."
 ],
 "Your progress will not be saved.": [
  null,
  "لن يُحفظ تقدمك."
 ],
 "completed step": [
  null,
  "اكتملت الخطوة"
 ],
 "current step": [
  null,
  "الخطوة الحالية"
 ],
 "delete": [
  null,
  "احذف"
 ],
 "edit": [
  null,
  "عدل"
 ],
 "encrypt": [
  null,
  "عمِّ"
 ],
 "encrypted": [
  null,
  "مُعمَّاة"
 ],
 "extended partition": [
  null,
  "قسم موسع"
 ],
 "format as $0": [
  null,
  "هيئ ك $0"
 ],
 "here": [
  null,
  "هنا"
 ],
 "incomplete": [
  null,
  "غير مكتمل"
 ],
 "mount": [
  null,
  "اوصل"
 ],
 "pending step": [
  null,
  "خطوة معلقة"
 ],
 "report the issue manually": [
  null,
  "بلغ عن المشكلة يدويًا"
 ],
 "resized from $0": [
  null,
  "غُيّر الحجم من $0"
 ],
 "shrink": [
  null,
  "قلّص"
 ],
 "shrink to $0": [
  null,
  "قلّص إلى $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "تراجع"
 ]
});
