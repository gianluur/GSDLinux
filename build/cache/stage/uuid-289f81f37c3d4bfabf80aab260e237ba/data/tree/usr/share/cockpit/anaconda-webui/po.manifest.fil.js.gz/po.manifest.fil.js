cockpit.locale({
 "": {
  "plural-forms": ((n) => (n > 1)),
  "language": "fil",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
