cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Fișiere Cockpit"
 ],
 "Home": [
  null,
  "Acasă"
 ],
 "Unable to create bookmark directory": [
  null,
  "Nu se poate crea directorul de marcaje"
 ],
 "Unable to save bookmark file": [
  null,
  "Nu se poate salva fișierul cu marcaje"
 ],
 "Remove from bookmarks": [
  null,
  "Elimină din marcaje"
 ],
 "Add to bookmarks": [
  null,
  "Adaugă la marcaje"
 ],
 "Bookmarks": [
  null,
  "Marcaje"
 ],
 "Bookmarked": [
  null,
  "Adăugat la marcaje"
 ],
 "Not bookmarked": [
  null,
  "Nu este adăugat la marcaje"
 ],
 "Filesystem": [
  null,
  "Sistem de fișiere"
 ],
 "Edit path": [
  null,
  "Editează ruta"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Dimensiune"
 ],
 "Largest size": [
  null,
  "Dimensiune mai mare"
 ],
 "Smallest size": [
  null,
  "Dimensiune mai mică"
 ],
 "Modified": [
  null,
  "Modificat"
 ],
 "First modified": [
  null,
  "Prima modificare"
 ],
 "Last modified": [
  null,
  "Ultima modificare"
 ],
 "Owner": [
  null,
  "Proprietar"
 ],
 "Owner ascending": [
  null,
  "Proprietar ascendent"
 ],
 "Owner descending": [
  null,
  "Proprietar descendent"
 ],
 "Permissions": [
  null,
  "Permisiuni"
 ],
 "Most permissive": [
  null,
  "Mai mult permisiv"
 ],
 "Least permissive": [
  null,
  "Mai puțin permisiv"
 ],
 "Show keyboard shortcuts": [
  null,
  "Afișează comenzile rapide de la tastatură"
 ],
 "Filter directory": [
  null,
  "Filtrare director"
 ],
 "Display as a list": [
  null,
  "Afișează sub formă de listă"
 ],
 "Display as a grid": [
  null,
  "Afișează sub formă de grilă"
 ],
 "Sort": [
  null,
  "Sortare"
 ],
 "Hide hidden items": [
  null,
  "Ascunde elementele ascunse"
 ],
 "Show hidden items": [
  null,
  "Afișează elementele ascunse"
 ],
 "$0 files": [
  null,
  "$0 fișiere"
 ],
 "Uploaded as $0, $1": [
  null,
  "Încărcat ca $0, $1"
 ],
 "Replace file $0?": [
  null,
  "Se înlocuiește fișierul $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Un fișier cu același nume există deja în „$0”. Înlocuirea acestuia va suprascrie conținutul său."
 ],
 "New file": [
  null,
  "Fișier nou"
 ],
 "Original file on server": [
  null,
  "Fișierul original de pe server"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Aplică această acțiune tuturor fișierelor care intră în conflict"
 ],
 "Replace": [
  null,
  "Înlocuiește"
 ],
 "Keep original": [
  null,
  "Păstrează originalul"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Failed": [
  null,
  "Nu a funcționat"
 ],
 "Upload error": [
  null,
  "Eroare la încărcare"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Nu se poate muta fișierul încărcat în destinația finală"
 ],
 "Cancelled": [
  null,
  "Anulată"
 ],
 "Cancelled upload of $0": [
  null,
  "Anulată încărcarea lui $0"
 ],
 "File uploaded": [
  null,
  "Fișier încărcat"
 ],
 "Files uploaded": [
  null,
  "Fișiere încărcate"
 ],
 "Change permissions": [
  null,
  "Modifică permisiunile"
 ],
 "Uploads": [
  null,
  "Încărcări"
 ],
 "Cancel upload of $0": [
  null,
  "Anulează încărcarea lui $0"
 ],
 "Upload $0% completed": [
  null,
  "Încărcare $0% finalizată"
 ],
 "Upload": [
  null,
  "Încărcare"
 ],
 "None": [
  null,
  "Niciuna"
 ],
 "Execute-only": [
  null,
  "Doar execuție"
 ],
 "Write-only": [
  null,
  "Numai-scriere"
 ],
 "Write and execute": [
  null,
  "Scriere și executare"
 ],
 "Read-only": [
  null,
  "Numai-citire"
 ],
 "Read and execute": [
  null,
  "Citire și executare"
 ],
 "Read and write": [
  null,
  "Citire și scriere"
 ],
 "Read, write, and execute": [
  null,
  "Citire, scriere și executare"
 ],
 "Block device": [
  null,
  "Dispozitiv de blocuri"
 ],
 "Character device": [
  null,
  "Dispozitiv de caractere"
 ],
 "Directory": [
  null,
  "Director"
 ],
 "Named pipe": [
  null,
  "Conductă cu nume"
 ],
 "Symbolic link": [
  null,
  "Legătură simbolică"
 ],
 "Regular file": [
  null,
  "Fișier obișnuit"
 ],
 "Socket": [
  null,
  "Soclu"
 ],
 "Name cannot be empty": [
  null,
  "Numele nu poate fi gol"
 ],
 "Name too long": [
  null,
  "Numele este prea lung"
 ],
 "Name cannot include a /": [
  null,
  "Numele nu poate să includă o /"
 ],
 "Filename is the same as original name": [
  null,
  "Numele fișierului este același cu numele original"
 ],
 "Directory with the same name exists": [
  null,
  "Există deja un director cu același nume"
 ],
 "File exists": [
  null,
  "Fișierul există"
 ],
 "Pasting failed": [
  null,
  "Lipirea a eșuat"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "„$0” există, nu se suprascrie la lipire."
 ],
 "Paste": [
  null,
  "Lipește"
 ],
 "Create directory": [
  null,
  "Creează un director"
 ],
 "Create file": [
  null,
  "Creează un fișier"
 ],
 "Edit permissions": [
  null,
  "Editează permisiunile"
 ],
 "Open in terminal": [
  null,
  "Deschide în terminal"
 ],
 "Open text file": [
  null,
  "Deschide fișierul de text"
 ],
 "Copy": [
  null,
  "Copiază"
 ],
 "Rename": [
  null,
  "Redenumește"
 ],
 "Delete": [
  null,
  "Șterge"
 ],
 "Download": [
  null,
  "Descărcare"
 ],
 "Create link": [
  null,
  "Creează o legătură"
 ],
 "Drop files to upload": [
  null,
  "Trageți fișierele pentru a le încărca"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Nu se pot adăuga fișiere, deoarece este deja în curs o altă încărcare"
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Go up a directory": [
  null,
  "Mergi la directorul părinte"
 ],
 "Go back": [
  null,
  "Înapoi"
 ],
 "Go forward": [
  null,
  "Înainte"
 ],
 "Activate selected item, enter directory": [
  null,
  "Activează elementul selectat, intră în director"
 ],
 "Rename selected file or directory": [
  null,
  "Redenumește fișierul sau directorul selectat"
 ],
 "Create new directory": [
  null,
  "Creează un nou director"
 ],
 "Copy selected file or directory": [
  null,
  "Copiază fișierul sau directorul selectat"
 ],
 "Paste file or directory": [
  null,
  "Lipește fișierul sau directorul"
 ],
 "Select all": [
  null,
  "Selectează tot"
 ],
 "Save current file": [
  null,
  "Salvează fișierul curent"
 ],
 "Close editor": [
  null,
  "Închide editorul"
 ],
 "Keyboard shortcuts": [
  null,
  "Taste de comenzi rapide"
 ],
 "Navigation": [
  null,
  "Navigare"
 ],
 "Editing": [
  null,
  "Editare"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Forțează ștergerea a $0 elemente"
 ],
 "Delete $0 items?": [
  null,
  "Ștergeți $0 elemente?"
 ],
 "Force delete file $0?": [
  null,
  "Forțați ștergerea fișierului $0?"
 ],
 "Delete file $0?": [
  null,
  "Ștergeți fișierul $0?"
 ],
 "Force delete link $0?": [
  null,
  "Forțați ștergerea legăturii $0?"
 ],
 "Delete link $0?": [
  null,
  "Ștergeți legătura $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Forțați ștergerea directorului $0?"
 ],
 "Delete directory $0?": [
  null,
  "Ștergeți directorul $0?"
 ],
 "Force delete $0": [
  null,
  "Forțează ștergerea $0"
 ],
 "Delete $0?": [
  null,
  "Ștergeți $0?"
 ],
 "No access": [
  null,
  "Fără acces"
 ],
 "Missing type": [
  null,
  "Tipul lipsește"
 ],
 "Collapse": [
  null,
  "Restrânge"
 ],
 "Show all files": [
  null,
  "Afișează toate fișierele"
 ],
 "$0 permissions": [
  null,
  "permisiuni $0"
 ],
 "Permissions for $0 files": [
  null,
  "Permisiuni pentru $0 fișiere"
 ],
 "Ownership": [
  null,
  "Deținător"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Access": [
  null,
  "Acces"
 ],
 "Owner access": [
  null,
  "Acces proprietar"
 ],
 "Group access": [
  null,
  "Acces grup"
 ],
 "Others access": [
  null,
  "Acces pentru alții"
 ],
 "Security context": [
  null,
  "Context de securitate"
 ],
 "Set executable as program": [
  null,
  "Definiți executabilul ca program"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Change permissions for enclosed files": [
  null,
  "Modifică permisiunile pentru fișierele atașate"
 ],
 "(original owner)": [
  null,
  "(proprietarul inițial)"
 ],
 "keep original owners": [
  null,
  "păstrează proprietarii originali"
 ],
 "Paste as owner": [
  null,
  "Lipește ca proprietar"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Fișierele care sunt lipite au un alt proprietar. În mod implicit, proprieterul va fi schimbat pentru a corespunde directorului de destinație."
 ],
 "New owner": [
  null,
  "Proprietar nou"
 ],
 "Overwrite": [
  null,
  "Suprascrie"
 ],
 "New filename": [
  null,
  "Nume nou de fișier"
 ],
 "New name": [
  null,
  "Nume nou"
 ],
 "Rename $0?": [
  null,
  "Se redenumește $0?"
 ],
 "link to $0": [
  null,
  "legătură la $0"
 ],
 "Create link to $0": [
  null,
  "Creează o legătură la $0"
 ],
 "Target": [
  null,
  "Ținta"
 ],
 "Symlink name": [
  null,
  "Nume legătură simbolică"
 ],
 "Type": [
  null,
  "Tip"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolută vs. relativă"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Legăturile simbolice absolute sunt ideale atunci când se face referire la fișiere sau directoare care nu se vor muta, cum ar fi fișierele de sistem."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Legăturile simbolice relative sunt utile atunci când atât legătura simbolică, cât și destinația pot fi mutate în același timp, de exemplu atunci când se redenumește sau se mută un director părinte."
 ],
 "Absolute": [
  null,
  "Absolută"
 ],
 "Relative": [
  null,
  "Relativă"
 ],
 "The file has been removed on disk": [
  null,
  "Fișierul a fost șters de pe disc"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Fișierul existent s-a modificat în mod neașteptat"
 ],
 "Edit $0": [
  null,
  "Editează $0"
 ],
 "View $0": [
  null,
  "Vizualizare $0"
 ],
 "The file has changed on disk": [
  null,
  "Fișierul a fost modificat pe disc"
 ],
 "Reload": [
  null,
  "Reîncărcare"
 ],
 "Ignore": [
  null,
  "Ignoră"
 ],
 "Save": [
  null,
  "Salvează"
 ],
 "Save changes?": [
  null,
  "Salvați modificările:?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Fișierul a fost șters pe disc după ce a fost deschis; salvarea îl va recrea (din memoria tampon)."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Fișierul a fost modificat pe disc între momentul în care a fost deschis și momentul actual"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 conține modificări nesalvate, care se vor pierde definitiv dacă sunt anulate(eliminate)."
 ],
 "Discard": [
  null,
  "Eliminare"
 ],
 "File name": [
  null,
  "Numele fișierului"
 ],
 "Create": [
  null,
  "Creează"
 ],
 "Cannot create file in current directory": [
  null,
  "Nu se poate crea fișierul în directorul curent"
 ],
 "Permission denied": [
  null,
  "Permisiune refuzată"
 ],
 "Directory name cannot be empty": [
  null,
  "Numele directorului nu poate să fie gol"
 ],
 "Directory name too long": [
  null,
  "Numele directorului este prea lung"
 ],
 "Directory name cannot include a /": [
  null,
  "Numele directorului nu poate să includă o /"
 ],
 "Directory name": [
  null,
  "Numele directorului"
 ],
 "Directory owner": [
  null,
  "Proprietarul directorului"
 ],
 "No matching results": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Clear filter": [
  null,
  "Șterge filtrul"
 ],
 "Directory is empty": [
  null,
  "Directorul este gol"
 ],
 "$0 item is hidden": [
  null,
  "$0 element este ascuns",
  "$0 elemente sunt ascunse",
  "$0 de elemente sunt ascunse"
 ],
 "Folder": [
  null,
  "Dosar"
 ],
 "File": [
  null,
  "Fișier"
 ],
 "Others": [
  null,
  "Alții"
 ],
 "$0 files selected": [
  null,
  "$0 fișiere selectate"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Directorul conține $0 directoare și $1 fișiere"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Directorul conține $0 directoare și $1 fișiere, $2 ascunse"
 ],
 "User": [
  null,
  "Utilizator"
 ]
});
