cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 个错误"
 ],
 "$0 installation": [
  null,
  "$0 安装"
 ],
 "$0 installer": [
  null,
  "$0 安装程序"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 是包含逻辑分区的 MBR 扩展分区。删除所有逻辑分区也会自动删除扩展分区。"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "需要 $0 ，但只有 $1 可用。"
 ],
 "$0 warning": [
  null,
  "$0 个警告"
 ],
 "$0 will be deleted": [
  null,
  "$0 将被删除"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' 文件系统不能位于加密块设备上"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' 必须分配给 $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' 必须位于格式化为 '$1' 的设备上"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' 必须位于 EFI 系统分区（ESP）上。选中的分区使用了 FAT 文件系统，但并未被标记为 ESP。将分区类型设置为 EFI System 并启用 esp 标志。"
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "在 MDRAID 设备 $1 上发现“$0”分区。不支持 MDRAID 设备上的引导加载程序分区。"
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "一个拥有管理员权限的标准用户账户，可执行系统级更改。"
 ],
 "Abort installation": [
  null,
  "中止安装"
 ],
 "About": [
  null,
  "关于"
 ],
 "Account": [
  null,
  "账户"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Add another server...": [
  null,
  "添加其它服务器..."
 ],
 "Add mount": [
  null,
  "添加挂载"
 ],
 "Add-ons for your chosen environment": [
  null,
  "适用于您选定环境的附加组件"
 ],
 "Add-ons not specific to your environment": [
  null,
  "不特定于您环境的附加组件"
 ],
 "Additional languages": [
  null,
  "其他语言"
 ],
 "Additional software for the selected environment": [
  null,
  "用于已选环境的附加软件"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "在存储编辑器中所做的所有更改都会立即生效。"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "所有使用此密码的设备都将被解锁"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web 界面"
 ],
 "Anaconda project page": [
  null,
  "Anaconda 项目页面"
 ],
 "Apply mount point assignment and install": [
  null,
  "应用挂载点分配并安装"
 ],
 "Applying changes...": [
  null,
  "正在应用更改..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "将分区分配给挂载点。对于预配置的自定义布局很有用。"
 ],
 "Automatic log file upload": [
  null,
  "自动上传日志文件"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "使用时间服务器自动设置日期与时间"
 ],
 "Automatically set timezone": [
  null,
  "自动设置时区"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "可用空间: $0。安装需要: $1。"
 ],
 "Back": [
  null,
  "返回"
 ],
 "Base environment": [
  null,
  "基本环境"
 ],
 "Brief description of the issue": [
  null,
  "问题简述"
 ],
 "Bug report details": [
  null,
  "缺陷报告详情"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API 密钥"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "点击 \"继续\" ，则说明您了解并接受预发行版的风险，只将该软件用于测试和开发，并且愿意报告所有程序错误或问题，以便改进本软件。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change destination": [
  null,
  "更改目标位置"
 ],
 "Change hostname": [
  null,
  "更改主机名"
 ],
 "Change partition layout": [
  null,
  "更改分区布局"
 ],
 "Change system keyboard layout": [
  null,
  "更改系统键盘布局"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "此处所做的更改将立即影响系统。无法“撤消”。"
 ],
 "Checking installation configuration...": [
  null,
  "正在检查安装配置..."
 ],
 "Checking storage configuration": [
  null,
  "正在检查存储配置"
 ],
 "Clear search": [
  null,
  "清除搜索"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "再次点击“下一步”以忽略这些警告继续操作。"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Close storage editor": [
  null,
  "关闭存储编辑器"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit 存储没有提供解锁加密设备的密码。"
 ],
 "Completed": [
  null,
  "已完成"
 ],
 "Configuration is incomplete": [
  null,
  "配置未完成"
 ],
 "Configure NTP servers": [
  null,
  "配置 NTP 服务器"
 ],
 "Configure custom NTP servers": [
  null,
  "配置自定义 NTP 服务器"
 ],
 "Configure network": [
  null,
  "配置网络"
 ],
 "Configure storage": [
  null,
  "配置存储"
 ],
 "Configure storage again": [
  null,
  "再次配置存储"
 ],
 "Confirm passphrase": [
  null,
  "确认密码"
 ],
 "Continue": [
  null,
  "继续"
 ],
 "Continue installation": [
  null,
  "继续安装"
 ],
 "Continue installation?": [
  null,
  "继续安装？"
 ],
 "Continue with installation": [
  null,
  "继续安装"
 ],
 "Correct these issues before continuing.": [
  null,
  "继续前请修正这些问题。"
 ],
 "Create Account": [
  null,
  "创建账户"
 ],
 "Create account": [
  null,
  "创建账户"
 ],
 "Currently installed: $0": [
  null,
  "目前安装：$0"
 ],
 "Custom": [
  null,
  "自定义"
 ],
 "Date": [
  null,
  "日期"
 ],
 "Date and time": [
  null,
  "日期和时间"
 ],
 "Delete partition": [
  null,
  "删除分区"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "删除某些分区可能会导致$0无法启动：$1"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Destination": [
  null,
  "目标位置"
 ],
 "Destination is encrypted": [
  null,
  "目标位置已加密"
 ],
 "Detailed description of the issue": [
  null,
  "问题详述"
 ],
 "Detected valid storage layout:": [
  null,
  "检测到有效的存储布局："
 ],
 "Device": [
  null,
  "设备"
 ],
 "Duplicate device.": [
  null,
  "重复的设备。"
 ],
 "Duplicate mount point.": [
  null,
  "重复的挂载点。"
 ],
 "Enable root account": [
  null,
  "启用 root 账户"
 ],
 "Encrypt my data": [
  null,
  "加密我的数据"
 ],
 "Encrypted": [
  null,
  "已加密"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "Enter PIN": [
  null,
  "输入PIN密钥"
 ],
 "Enter PIN to access the installer": [
  null,
  "输入PIN密钥以进入安装器"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "输入您的 Bugzilla API 密钥以创建缺陷报告。 您可以在下一步查看与编辑缺陷详情。"
 ],
 "Environment": [
  null,
  "环境"
 ],
 "Erase data and install": [
  null,
  "删除数据内容并安装"
 ],
 "Error details": [
  null,
  "错误详情"
 ],
 "Exit to live desktop": [
  null,
  "退出到 live 桌面"
 ],
 "Extended partition": [
  null,
  "扩展分区"
 ],
 "Failed to report issue": [
  null,
  "报告问题失败"
 ],
 "Failed to save layouts": [
  null,
  "保存布局失败"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux 至少需要 $0 的磁盘空间。"
 ],
 "Finalization": [
  null,
  "最后确定"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "最终确定：系统配置已经完成。最终完成安装可能需要一些时间。"
 ],
 "Find layout": [
  null,
  "查找布局"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "为了更好的安全性，避免直接使用root账户。相反，请使用以上的本地账户来管理系统。"
 ],
 "Full name": [
  null,
  "全名"
 ],
 "Full name cannot contain colon characters": [
  null,
  "全名不能含有冒号"
 ],
 "Helper text": [
  null,
  "帮助文本"
 ],
 "Hide API key": [
  null,
  "隐藏 API 密钥"
 ],
 "Hide PIN": [
  null,
  "隐藏 PIN 密钥"
 ],
 "Hide confirmed password": [
  null,
  "隐藏确认的密码"
 ],
 "Hide passphrase": [
  null,
  "隐藏口令"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "Hostname": [
  null,
  "主机名"
 ],
 "How would you like to install?": [
  null,
  "您想如何安装？"
 ],
 "I understand that all existing data will be erased": [
  null,
  "我明白所选磁盘上的所有现有数据将被删除"
 ],
 "I understand that some existing data will be erased": [
  null,
  "我明白部分现有数据将被删除"
 ],
 "I understand that some partitions will be modified": [
  null,
  "我明白有些分区会被修改"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "如果为空，主机名将是由网络信息设置的临时主机名。"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "如若以上选项都不适用，请在继续之前使用存储编辑器创建自定义分区。"
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "如果要配置分区，则需要以下内容："
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "如果您不同意自动上传日志文件，您可以改为 $0。手动报告允许您自己审查并选择是否附加日志文件。"
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "如果您不了解或不接受此风险，请点击 \"退出\" 按钮退出程序。"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "如果你的问题与以上的问题匹配，你可以打开它并添加你的信息而不是新建一个重复的报告。"
 ],
 "In progress": [
  null,
  "进行中"
 ],
 "Initializing...": [
  null,
  "初始化中..."
 ],
 "Install": [
  null,
  "安装"
 ],
 "Installation completed": [
  null,
  "安装完成"
 ],
 "Installation failed": [
  null,
  "安装失败"
 ],
 "Installation method": [
  null,
  "安装方案"
 ],
 "Installation of the system failed": [
  null,
  "系统安装失败"
 ],
 "Installation of the system failed: $0": [
  null,
  "系统安装失败：$0"
 ],
 "Installation type": [
  null,
  "安装类型"
 ],
 "Installing": [
  null,
  "正在安装"
 ],
 "Insufficient disk space": [
  null,
  "磁盘空间不足"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "无效的PIN密钥，请重试。"
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "检测到无效的 RAID 配置。如果您的 RAID 阵列直接在磁盘上创建，则必须在阵列上创建分区表。如果您的 RAID 阵列在分区上创建，则它必须包含单个文件系统或格式（例如 LVM PV）。此阵列上的任何现有分区都将被忽略。"
 ],
 "Invalid hostname": [
  null,
  "无效主机名"
 ],
 "Jump to first incomplete step": [
  null,
  "跳转至第一个未完成的步骤"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "保留当前磁盘布局并使用可用空间，以便与另一个操作系统双启动。"
 ],
 "Keyboard": [
  null,
  "键盘"
 ],
 "Keyboard layout during boot": [
  null,
  "启动期间的键盘布局"
 ],
 "Language": [
  null,
  "语言"
 ],
 "Launch storage editor": [
  null,
  "启动存储编辑器"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "在配置中详细了解受限访问"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "将两个密码框都留空以使用空密码。"
 ],
 "Location": [
  null,
  "位置"
 ],
 "Locked devices": [
  null,
  "锁定的设备"
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Make current": [
  null,
  "使用当前生效的"
 ],
 "Manual disk configuration": [
  null,
  "手动配置磁盘"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "手动磁盘配置：挂载点映射"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "可能包含字母、数字和破折号。"
 ],
 "May need more free space": [
  null,
  "可能需要更多空闲空间"
 ],
 "Medium": [
  null,
  "中等"
 ],
 "Minimum of $0 required": [
  null,
  "最低要求为 $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "父设备和子设备重新格式化选择不匹配。"
 ],
 "Mount point": [
  null,
  "挂载点"
 ],
 "Mount point assignment": [
  null,
  "挂载点配置"
 ],
 "Move down": [
  null,
  "向下移动"
 ],
 "Move up": [
  null,
  "向上移动"
 ],
 "Must be at least $0 characters": [
  null,
  "必须至少包含$0字符"
 ],
 "My issue is different, continue": [
  null,
  "我的问题是不同的，继续"
 ],
 "NTP Servers": [
  null,
  "NTP 服务器"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Needs at least $0": [
  null,
  "至少需要 $0"
 ],
 "Network": [
  null,
  "网络"
 ],
 "Network Configuration": [
  null,
  "网络配置"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "网络不可用。在顶部栏菜单中配置网络以报告问题。"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "网络不可用。请配置网络以报告该问题。"
 ],
 "Network plugin failed": [
  null,
  "网络插件失败"
 ],
 "Next": [
  null,
  "下一个"
 ],
 "No devices": [
  null,
  "无设备"
 ],
 "No disks available": [
  null,
  "没有可用的磁盘"
 ],
 "No disks selected": [
  null,
  "未选择任何磁盘"
 ],
 "No keyboard layouts selected": [
  null,
  "未选择任何键盘布局"
 ],
 "No layouts selected yet": [
  null,
  "尚未选择任何布局"
 ],
 "No results found": [
  null,
  "未找到结果"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "无法为所选的键盘布局获取有效的VConsole键位映射。请尝试其他键盘布局。"
 ],
 "Not enough available free space": [
  null,
  "没有足够可用剩余空间"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "所选磁盘中没有足够剩余空间。"
 ],
 "Not enough space on selected disks.": [
  null,
  "所选磁盘中没有足够空间。"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "注意：该预发行软件仅用于开发和测试。绝不要在任何关键工作及生产环境中使用此软件。"
 ],
 "Open Bugzilla bug entry form": [
  null,
  "打开 Bugzilla 缺陷报告表单"
 ],
 "Operating system": [
  null,
  "操作系统"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Other keyboards": [
  null,
  "其他键盘"
 ],
 "Partitions (advanced)": [
  null,
  "分区（高级）"
 ],
 "Passphrase": [
  null,
  "密码"
 ],
 "Passphrase did not match any locked device": [
  null,
  "密码与任何锁定的设备都不匹配"
 ],
 "Passphrases must match": [
  null,
  "密码必须匹配"
 ],
 "Pending": [
  null,
  "待办的"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "请将日志文件 $0 附加到问题中。"
 ],
 "Please enter a PIN": [
  null,
  "请输入PIN密钥"
 ],
 "Please select at least one disk to continue": [
  null,
  "请至少选择一个磁盘以继续"
 ],
 "Pool": [
  null,
  "池"
 ],
 "Potential duplicate bugs found": [
  null,
  "可能发现重复的漏洞"
 ],
 "Powered by Anaconda": [
  null,
  "由 Anaconda 强力驱动"
 ],
 "Pre-release": [
  null,
  "预发布"
 ],
 "Prefer to report manually? $0": [
  null,
  "倾向于手动报告吗？ $0"
 ],
 "Proceed with installation": [
  null,
  "继续安装"
 ],
 "Quit": [
  null,
  "退出"
 ],
 "Quit installer?": [
  null,
  "退出安装程序？"
 ],
 "Reading information about the OS failed.": [
  null,
  "读取操作系统的信息失败。"
 ],
 "Reading information about the computer failed.": [
  null,
  "读取计算机信息失败。"
 ],
 "Reading installer configuration failed.": [
  null,
  "读取安装程序配置失败。"
 ],
 "Reading installer version information failed.": [
  null,
  "读取安装程序版本信息失败。"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "真实主机名只能包含字符、数字、破折号（不是开始或结束字符）和点"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "实际主机名必须不超过 64 个字符"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "重新启动 Windows 以调整 BitLocker 加密分区的大小。为安装提供至少 $0 的可用空间。"
 ],
 "Reboot system?": [
  null,
  "重启系统？"
 ],
 "Reclaim additional space": [
  null,
  "回收更多空间"
 ],
 "Reclaim space": [
  null,
  "回收空间"
 ],
 "Reclaim space (required)": [
  null,
  "回收空间（必需）"
 ],
 "Recommended": [
  null,
  "推荐的"
 ],
 "Recommended partitions:": [
  null,
  "建议的分区："
 ],
 "Reformat": [
  null,
  "重新格式化"
 ],
 "Reinstall Fedora": [
  null,
  "重新安装 Fedora"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "删除所选设备上的所有分区，包括现有操作系统。"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "删除或调整现有文件系统的大小以释放安装空间。"
 ],
 "Remove server": [
  null,
  "移除服务器"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "删除文件系统将永久删除其中包含的所有数据。调整分区大小可以释放未使用的空间，但并非毫无风险。在回收空间之前，请务必备份所有重要内容。"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "替换当前安装，但将文件保留在主目录中。"
 ],
 "Report Issue": [
  null,
  "报告问题"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "打开 Bugzilla 缺陷报告表单 $0 来报告问题或提供反馈。"
 ],
 "Report issue": [
  null,
  "报告问题"
 ],
 "Reporting issue...": [
  null,
  "报告问题中..."
 ],
 "Required": [
  null,
  "必需的"
 ],
 "Requirements": [
  null,
  "必需的"
 ],
 "Rescan devices": [
  null,
  "重新扫描设备"
 ],
 "Rescanning of the disks failed.": [
  null,
  "重新扫描磁盘失败。"
 ],
 "Resize": [
  null,
  "调整大小"
 ],
 "Resize partition": [
  null,
  "调整分区大小"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "从 $0 调整以下分区的大小：$1"
 ],
 "Restrict access to the report": [
  null,
  "限制访问报告"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "将报告限制在 $0 组内。$1"
 ],
 "Return to installation": [
  null,
  "返回安装"
 ],
 "Return to storage editor": [
  null,
  "返回存储编辑器"
 ],
 "Review and install": [
  null,
  "检查并安装"
 ],
 "Root account has been configured": [
  null,
  "管理员账户已经配置完毕"
 ],
 "Root account is enabled": [
  null,
  "Root 帐户已启用"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root账户已启用，但尚未配置任何用户帐户"
 ],
 "Root password has been set.": [
  null,
  "Root 密码已设置。"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "使用手机扫描二维码或访问："
 ],
 "Search for a language": [
  null,
  "搜索语言"
 ],
 "Search for additional software": [
  null,
  "搜索其他软件"
 ],
 "Search for an environment": [
  null,
  "搜索环境"
 ],
 "Search keyboard layout": [
  null,
  "搜索键盘布局"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "使用基于磁盘的加密保护您的数据。仅适用于新分区"
 ],
 "Select": [
  null,
  "选择"
 ],
 "Select a device": [
  null,
  "所选一个设备"
 ],
 "Select city": [
  null,
  "选择城市"
 ],
 "Select destination": [
  null,
  "选择目标位置"
 ],
 "Select region": [
  null,
  "选择区域"
 ],
 "Selected (top = current)": [
  null,
  "已选中（顶部 = 当前）"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "无法重新格式化所选设备的格式 '$0'。"
 ],
 "Send us feedback on your installation": [
  null,
  "向我们发送有关您的安装的反馈"
 ],
 "Server": [
  null,
  "服务器"
 ],
 "Server is not reachable": [
  null,
  "服务器不可达"
 ],
 "Set custom hostname": [
  null,
  "设置自定义主机名"
 ],
 "Share disk with other operating systems": [
  null,
  "与其他操作系统共享磁盘"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "与其它操作系统共享磁盘： $0"
 ],
 "Show AM/PM": [
  null,
  "显示 AM/PM"
 ],
 "Show API key": [
  null,
  "显示 API 密钥"
 ],
 "Show PIN": [
  null,
  "显示 PIN 密钥"
 ],
 "Show confirmed password": [
  null,
  "显示确认密码"
 ],
 "Show passphrase": [
  null,
  "显示密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Software installation": [
  null,
  "软件安装"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "软件安装：存储配置完成。该软件现在正在安装到您的设备上。"
 ],
 "Software selection": [
  null,
  "软件选择"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "在继续之前，您还需要完成一些安装步骤。"
 ],
 "Some required partitions are missing: $0": [
  null,
  "缺少一些必需的分区：$0"
 ],
 "Space": [
  null,
  "空间"
 ],
 "Stacktrace": [
  null,
  "栈回溯"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Storage configuration": [
  null,
  "存储配置"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "存储配置：当前正在配置存储。"
 ],
 "Storage editor": [
  null,
  "存储编辑器"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "存储基于‘修改存储’的配置。"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "存储布局由 Kickstart 文件定义。您可以在“摘要”步骤中查看预设的分区布局。"
 ],
 "Storage plugin failed": [
  null,
  "存储插件失败"
 ],
 "Storage requirements not met": [
  null,
  "未满足存储要求"
 ],
 "Strong": [
  null,
  "强"
 ],
 "Successfully installed": [
  null,
  "安装成功"
 ],
 "Successfully unlocked $0.": [
  null,
  "成功解锁 $0。"
 ],
 "Suggested keyboards": [
  null,
  "建议的键盘"
 ],
 "Suggested languages": [
  null,
  "建议语言"
 ],
 "System": [
  null,
  "系统"
 ],
 "System configuration": [
  null,
  "系统配置"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "系统配置： 软件安装完成。现在正在配置系统。"
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda安装意外停止。"
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "以下的问题可能与你的问题有关，请你在创建新报告之前检查这些问题是否与你的问题有关。"
 ],
 "The following user will be created:": [
  null,
  "将创建以下用户："
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "安装需要$0的磁盘空间；但是所选磁盘的容量只有$1。"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "安装程序由于严重错误而无法继续。"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "安装程序由于严重错误而无法继续：$0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "自设定磁盘加密密码以来，键盘布局已发生变更。请重新输入密码。"
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "您设定的密码中包括非 ASCII 字符。在输入时您可能无法切换键盘布局。"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "所选的默认键盘布局不支持ASCII字符。请将默认布局更改为支持ASCII字符的布局。"
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "存储编辑器允许您调整分区大小、删除分区和创建分区。它可以设置 LVM 等。它旨在用作高级实用程序，不适用于典型安装。"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "这些日志可能包含敏感信息，如 IP 地址、用户名或其他系统信息。"
 ],
 "This hostname can't be submitted": [
  null,
  "无法提交此主机名"
 ],
 "This is unstable, pre-release software": [
  null,
  "这是不稳定的预发行软件"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "此布局将用于在启动时解锁系统"
 ],
 "This may take a moment": [
  null,
  "这可能需要些时间"
 ],
 "This will take a few moments": [
  null,
  "这需要一些时间"
 ],
 "Time": [
  null,
  "时间"
 ],
 "Timezone": [
  null,
  "时区"
 ],
 "Title": [
  null,
  "标题"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "要使用 $0，请重新启动系统。"
 ],
 "To continue, select the devices to install to.": [
  null,
  "要想继续，请选择要安装的设备。"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "要使用此选项，请调整大小或删除现有分区以释放至少 $0。"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "无法安排删除 $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "无法安排调整 $0 的大小"
 ],
 "Undo last action": [
  null,
  "撤销上次动作"
 ],
 "Unlock": [
  null,
  "解锁"
 ],
 "Unlock encrypted devices": [
  null,
  "解锁加密设备"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "解锁加密分区以保留现有数据并显示更多安装方法。"
 ],
 "Use configured storage": [
  null,
  "使用配置的存储"
 ],
 "Use entire disk": [
  null,
  "使用整个磁盘"
 ],
 "Use free space": [
  null,
  "使用空闲空间"
 ],
 "Use local account": [
  null,
  "使用本地账户"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "使用 RAID 设备进行自动分区"
 ],
 "User creation": [
  null,
  "创建用户"
 ],
 "User name": [
  null,
  "用户名"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "用户名只能包含：a-z 字母、0-9 数字、破折号 $0、句点 $1、下划线 $2"
 ],
 "User name must not be a reserved word": [
  null,
  "用户名不能是保留字"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "用户名必须少于 33 个字符"
 ],
 "Validating...": [
  null,
  "验证中..."
 ],
 "Weak": [
  null,
  "弱"
 ],
 "Welcome": [
  null,
  "欢迎"
 ],
 "Welcome to Fedora Linux": [
  null,
  "欢迎使用 Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "欢迎。现在就来安装 $0 吧。"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "当您提交该缺陷报告时，如下日志文件将被自动上传：$0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "使用 BitLocker 加密的 Windows 分区无法调整大小"
 ],
 "You can close this browser window now.": [
  null,
  "你现在可以关闭这个浏览器窗口了。"
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "您可以在此处释放足够的空间并让安装程序处理其余部分，或者手动设置分区。"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "您可以为您的 Bugzilla 账户 $0 生成 API 密钥。"
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "你必须启用root账户或创建本地用户账户以继续。"
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "你必须连接到网络才能启用自动设置日期与时间。"
 ],
 "Your progress will not be saved.": [
  null,
  "您的进度将不会被保存。"
 ],
 "completed step": [
  null,
  "已完成操作"
 ],
 "current step": [
  null,
  "当前操作"
 ],
 "delete": [
  null,
  "删除"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "encrypt": [
  null,
  "加密"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "extended partition": [
  null,
  "扩展分区"
 ],
 "format as $0": [
  null,
  "格式化为 $0"
 ],
 "here": [
  null,
  "这里"
 ],
 "incomplete": [
  null,
  "未完成"
 ],
 "mount": [
  null,
  "挂载"
 ],
 "pending step": [
  null,
  "待执行操作"
 ],
 "report the issue manually": [
  null,
  "手动报告问题"
 ],
 "resized from $0": [
  null,
  "从 $0 调整为"
 ],
 "shrink": [
  null,
  "缩小"
 ],
 "shrink to $0": [
  null,
  "缩小至 $0"
 ],
 "transient, will use DHCP": [
  null,
  "临时的，将使用DHCP"
 ],
 "undo": [
  null,
  "撤消"
 ]
});
