cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ia",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
