cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Public key": [
  null,
  "Chave Pública"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "Unexpected error": [
  null,
  "Erro inesperado"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "Connect": [
  null,
  "Conectar"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Você está se conectando com $0 pela primeira vez."
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Execute este comando por meio de uma rede confiável ou fisicamente na máquina remota:"
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Não foi possível efetuar login em $0. O host não aceita login por senha nem por nenhuma de suas chaves SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida por senha, e o host não permite login com senha. Por favor, forneça a senha da chave no endereço $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida. Você pode acessar usando sua senha de login ou fornecendo a senha da chave no endereço $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "Key password": [
  null,
  "Senha da chave"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "A chave SSH $0 de $1 em $2 serão adicionadas ao arquivo $3 de $4 em $5."
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "A chave SSH $0 ficará disponível durante o restante da sessão e também poderá ser usada para fazer login em outros hosts."
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Permission denied": [
  null,
  "Permissão negada"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Pick date": [
  null,
  "Selecionar data"
 ],
 "Toggle date picker": [
  null,
  "Alternar o seletor de data"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "You now have administrative access.": [
  null,
  "Agora você tem acesso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Não existem métodos disponíveis para obter acesso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentique-se para obter acesso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Trocar para acesso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema ao se tornar administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Switch to limited access": [
  null,
  "Trocar para acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "O modo de acesso limitado restringe os privilégios administrativos. Algumas partes do console web terão funcionalidade reduzida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Seu navegador irá memorizar seu nível de acesso entre as sessões."
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar acesso administrativo"
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitar firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Strong password": [
  null,
  "Senha forte"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Weak password": [
  null,
  "Senha fraca"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "Show confirmation password": [
  null,
  "Mostrar a senha de confirmação"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando a conclusão de outras operações de gerenciamento de software"
 ],
 "Checking installed software": [
  null,
  "Verificando software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Não foi possível efetuar login em $0 usando autenticação por chave SSH. Por favor, forneça a senha."
 ],
 "SSH key login": [
  null,
  "Login com chave SSH"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportou código de erro $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "Row expansion": [
  null,
  "Expansão de linha"
 ],
 "Row select": [
  null,
  "Seleção de linha"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Erro de colagem"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Seu navegador não permite colar texto pelo menu de contexto. Você pode usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Erro durante inicialização"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Home": [
  null,
  "Pasta pessoal"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Não é um diretório"
 ],
 "All files": [
  null,
  "Todos os arquivos"
 ],
 "Recent": [
  null,
  "Recentes"
 ],
 "No recent directories": [
  null,
  "Nenhum diretório recente"
 ],
 "No recent files": [
  null,
  "Nenhum arquivo recente"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "File chooser actions": [
  null,
  "Ações do seletor de arquivos"
 ],
 "Open in file browser": [
  null,
  "Abrir no navegador de arquivos"
 ],
 "Hide hidden files": [
  null,
  "Ocultar arquivos ocultos"
 ],
 "Show hidden files": [
  null,
  "Mostrar arquivos ocultos"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Clear filters": [
  null,
  "Limpar filtros"
 ],
 "Directory is empty": [
  null,
  "O diretório está vazio"
 ],
 "Directory has no sub-directories": [
  null,
  "O diretório não tem subdiretórios"
 ],
 "This directory contains only hidden files": [
  null,
  "Este diretório contém apenas arquivos ocultos"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "Folder": [
  null,
  "Pasta"
 ],
 "File": [
  null,
  "Arquivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "O usuário conectado não tem permissão para visualizar as modificações do sistema"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "View automation script": [
  null,
  "Ver script de automação"
 ],
 "Occurrences": [
  null,
  "Ocorrências"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Select an option": [
  null,
  "Selecione uma opção"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Not permitted to perform this action.": [
  null,
  "Não autorizado a executar esta ação."
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Host key is incorrect": [
  null,
  "Chave de host incorreta"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Priority": [
  null,
  "Prioridade"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "edit": [
  null,
  "editar"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Generated": [
  null,
  "Gerado"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Start service": [
  null,
  "Começar serviço"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Delete $0": [
  null,
  "Deletar $0"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Not available": [
  null,
  "Indisponível"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Permanent": [
  null,
  "Permanente"
 ],
 "Preserve": [
  null,
  "Preservar"
 ],
 "Random": [
  null,
  "Aleatório(a)"
 ],
 "Stable": [
  null,
  "Estável"
 ],
 "Use $0": [
  null,
  "Usar $0"
 ],
 "Failed to save settings": [
  null,
  "Falha ao salvar as configurações"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Criar esse $0 quebrará a conexão com o servidor e tornará a interface de administração indisponível."
 ],
 "Create it": [
  null,
  "Criá-lo"
 ],
 "Invalid prefix $0": [
  null,
  "Prefixo inválido $0"
 ],
 "Invalid metric $0": [
  null,
  "Métrica inválida $0"
 ],
 "Invalid address $0": [
  null,
  "Endereço inválido $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefixo ou máscara de rede inválidos $0"
 ],
 "Testing connection": [
  null,
  "Testando conexão"
 ],
 "Restoring connection": [
  null,
  "Restaurando conexão"
 ],
 "Troubleshoot…": [
  null,
  "Solução de problemas…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager não está em execução"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager não está instalado"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Dispositivos de rede e gráficos requerem o NetworkManager"
 ],
 "Enable service": [
  null,
  "Ativar serviço"
 ],
 "Network interface '$0' not found": [
  null,
  "Interface de rede '$0' não encontrada"
 ],
 "Return to overview page": [
  null,
  "Retornar à página de visão geral"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Você não está autorizado a modificar o firewall."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Não autorizado a desabilitar o firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Não autorizado a habilitar o firewall"
 ],
 "Disable the firewall": [
  null,
  "Desabilitar o firewall"
 ],
 "Enable the firewall": [
  null,
  "Habilitar o firewall"
 ],
 "Edit service $0": [
  null,
  "Editar serviço $0"
 ],
 "Remove service $0": [
  null,
  "Remover serviço $0"
 ],
 "Included Services": [
  null,
  "Serviços inclusos"
 ],
 "Additional port": [
  null,
  "Porta adicional"
 ],
 "Remove additional port": [
  null,
  "Remover porta adicional"
 ],
 "Remove zone $0": [
  null,
  "Remover zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Adicionar serviços à zona $0"
 ],
 "Add services": [
  null,
  "Adicionar serviços"
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "Zona $0"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Allowed addresses": [
  null,
  "Endereços permitidos"
 ],
 "Entire subnet": [
  null,
  "Toda a sub-rede"
 ],
 "There are no active services in this zone": [
  null,
  "Não existem serviços ativos nesta zona"
 ],
 "Filter services": [
  null,
  "Serviços de filtro"
 ],
 "Failed to edit service": [
  null,
  "Falha ao editar serviço"
 ],
 "Failed to add port": [
  null,
  "Falha ao adicionar porta"
 ],
 "Failed to add service": [
  null,
  "Falha ao adicionar serviço"
 ],
 "Unknown service name": [
  null,
  "Nome de serviço desconhecido"
 ],
 "Invalid port number": [
  null,
  "Número de porta inválido"
 ],
 "Invalid range": [
  null,
  "Intervalo inválido"
 ],
 "Range must be strictly ordered": [
  null,
  "O intervalo deve ser estritamente ordenado"
 ],
 "Edit service": [
  null,
  "Editar Serviço"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Editar serviços customizado para zona $0"
 ],
 "Add ports": [
  null,
  "Adicionar portas"
 ],
 "Add ports to $0 zone": [
  null,
  "Adicionar portas para zona $0"
 ],
 "Add services to $0 zone": [
  null,
  "Adicionar serviços à zona $0"
 ],
 "Custom ports": [
  null,
  "Portas customizadas"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemplo: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "São aceitos portas, intervalos e serviços separados por vírgula"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemplo: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Se deixado em branco, o ID será gerado com base nos serviços de porta e números de porta associados"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Adicionar portas personalizadas recarregará o firewalld. Uma recarga resultará na perda de qualquer configuração somente em tempo de execução!"
 ],
 "Failed to add zone": [
  null,
  "Falha ao adicionar zona"
 ],
 "Add zone": [
  null,
  "Adicionar zona"
 ],
 "Trust level": [
  null,
  "Nível de confiança"
 ],
 "Sorted from least to most trusted": [
  null,
  "Classificados do menos confiável ao mais confiável"
 ],
 "Custom zones": [
  null,
  "Zonas customizadas"
 ],
 "No description available": [
  null,
  "Sem descrição disponível"
 ],
 "Included services": [
  null,
  "Serviços inclusos"
 ],
 "The cockpit service is automatically included": [
  null,
  "O serviço de cockpit está incluído automaticamente"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Range": [
  null,
  "Intervalo"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Endereço IP com prefixo de roteamento. Separe múltiplos valores com uma vírgula. Exemplo: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmar remoção de $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Esta zona contém o serviço cockpit. Certifique-se de que esta zona não se aplique à sua conexão atual do console web."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Remover a zona vai remover todos os serviços nele."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "A remoção do serviço do cockpit pode resultar na inacessibilidade do console web. Certifique-se de que esta zona não se aplique à sua conexão atual com o console web."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Remover o serviço $0 da zona $1"
 ],
 "Firewall is not available": [
  null,
  "Firewall não está disponível"
 ],
 "Please install the $0 package": [
  null,
  "Por favor, instale o pacote de $0"
 ],
 "Add a new zone": [
  null,
  "Adicionar uma nova zona"
 ],
 "Add new zone": [
  null,
  "Adicionar nova zona"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "As solicitações de entrada são bloqueadas por padrão. As solicitações de saída não são bloqueadas."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "O SSID não pode estar vazio"
 ],
 "Password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "Failed to connect": [
  null,
  "Falha ao conectar"
 ],
 "Check your password.": [
  null,
  "Verifique sua senha."
 ],
 "Connect to hidden network": [
  null,
  "Conectar a rede desconhecida"
 ],
 "Connect to $0": [
  null,
  "Conectar à $0"
 ],
 "Network name": [
  null,
  "Nome da rede"
 ],
 "Security": [
  null,
  "Segurança"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Excluindo $0 a conexão com o servidor será encerrada, e tornará a administração da interface do usuário indisponível."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Ligando $0 irá encerrar a conexão com o servidor e tornará a administração da interface do usuário indisponível."
 ],
 "Switch on $0": [
  null,
  "Ligar $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Desligando $0 irá encerrar a conexão com o servidor, e tornará a administração da interface do usuário indisponível."
 ],
 "Switch off $0": [
  null,
  "Desligar $0"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Team": [
  null,
  "Equipe"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Ponte"
 ],
 "Unknown \"$0\"": [
  null,
  "Desconhecido \"$0\""
 ],
 "Carrier": [
  null,
  "Sinal"
 ],
 "Yes": [
  null,
  "Sim"
 ],
 "No": [
  null,
  "Não"
 ],
 "Inactive": [
  null,
  "Inativo"
 ],
 "Unknown configuration": [
  null,
  "Configuração desconhecida"
 ],
 "Additional address $val": [
  null,
  "Endereço adicional $val"
 ],
 "Address $val": [
  null,
  "Endereço $val"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS adicional $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domínios de pesquisa de DNS adicionais $val"
 ],
 "DNS search domains $val": [
  null,
  "Domínios de Pesquisa DNS $val"
 ],
 "General": [
  null,
  "Geral"
 ],
 "Connect automatically": [
  null,
  "Conecte automaticamente"
 ],
 "Automatic": [
  null,
  "Automático"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Monitoramento ARP"
 ],
 "Broken configuration": [
  null,
  "Configuração quebrada"
 ],
 "Team port": [
  null,
  "Porta da Equipe"
 ],
 "Spanning tree protocol": [
  null,
  "Protocolo Spanning tree"
 ],
 "Priority $priority": [
  null,
  "Prioridade $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Encaminhado Atraso $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Tempo de hello $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Máxima permanência da mensagem $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Custo do caminho $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Modo Hairpin"
 ],
 "Bridge port": [
  null,
  "Bridge porta"
 ],
 "Parent $parent": [
  null,
  "Pai $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "A senha da rede não está armazenada. Remova e reconecte esta rede."
 ],
 "Failed to connect to $0": [
  null,
  "Falha ao conectar a $0"
 ],
 "secured": [
  null,
  "segura"
 ],
 "open": [
  null,
  "aberta"
 ],
 "Last connected: $0": [
  null,
  "Última conexão: $0"
 ],
 "Signal strength": [
  null,
  "Força do sinal"
 ],
 "Not permitted to disconnect network": [
  null,
  "Não autorizado a desconectar a rede"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Not permitted to connect to network": [
  null,
  "Não autorizado a se conectar à rede"
 ],
 "Forget": [
  null,
  "Esquecer"
 ],
 "$0 hidden network": [
  null,
  "$0 rede oculta",
  "$0 redes ocultas"
 ],
 "Filter": [
  null,
  "Filtro"
 ],
 "Refresh": [
  null,
  "Atualizar"
 ],
 "Available networks": [
  null,
  "Redes disponíveis"
 ],
 "Network": [
  null,
  "Rede"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Signal": [
  null,
  "Sinal"
 ],
 "Rate": [
  null,
  "Taxa"
 ],
 "Not permitted to configure network devices": [
  null,
  "Não autorizado a configurar dispositivos de rede"
 ],
 "Enable or disable the device": [
  null,
  "Habilitar ou desabilitar o dispositivo"
 ],
 "This device cannot be managed here.": [
  null,
  "Este dispositivo não pode ser gerenciado aqui."
 ],
 "Connection will be lost": [
  null,
  "A conexão será perdida"
 ],
 "Keep connection": [
  null,
  "Manter conexão"
 ],
 "Invalid IP address: $0": [
  null,
  "Endereço IP inválido: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Endereço de destino inválido: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Endereço de gateway inválido: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Endereço DNS inválido: $0"
 ],
 "Preparing": [
  null,
  "Preparando"
 ],
 "Configuring": [
  null,
  "Configurando"
 ],
 "Authenticating": [
  null,
  "Autenticando"
 ],
 "Configuring IP": [
  null,
  "Configurando IP"
 ],
 "Checking IP": [
  null,
  "Checando IP"
 ],
 "Waiting": [
  null,
  "Aguardando"
 ],
 "Active": [
  null,
  "Ativo"
 ],
 "Deactivating": [
  null,
  "Desativando"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Sem sinal"
 ],
 "Part of $0": [
  null,
  "Parte of $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Alterar as configurações irá encerrar a conexão com o servidor, e tornará a administração interface do usuário indisponível."
 ],
 "Change the settings": [
  null,
  "Alterar as configurações"
 ],
 "Add bridge": [
  null,
  "Adicionar ponte"
 ],
 "Edit bridge settings": [
  null,
  "Editar configurações de ponte"
 ],
 "Ports": [
  null,
  "Portas"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocolo Spanning tree (STP)"
 ],
 "STP priority": [
  null,
  "STP Prioridade"
 ],
 "STP forward delay": [
  null,
  "STP Atraso de Redirecionamento"
 ],
 "STP hello time": [
  null,
  "Tempo de saudação STP"
 ],
 "STP maximum message age": [
  null,
  "STP Máxima permanência de mensagem"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Backup ativo"
 ],
 "Load balancing": [
  null,
  "Balanceamento de Carga"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passivo"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Adicionar equipe"
 ],
 "Edit team settings": [
  null,
  "Editar configurações da Equipe"
 ],
 "Runner": [
  null,
  "Executor"
 ],
 "Balancer": [
  null,
  "Balanceador"
 ],
 "Primary": [
  null,
  "Primário"
 ],
 "Link watch": [
  null,
  "Link para assistir"
 ],
 "Link up delay": [
  null,
  "Link up atraso"
 ],
 "Link down delay": [
  null,
  "Link down atraso"
 ],
 "Ping interval": [
  null,
  "Intervalo de Ping"
 ],
 "Ping target": [
  null,
  "Alvo do Ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automático (apenas DHCP)"
 ],
 "Link local": [
  null,
  "Link Local"
 ],
 "Manual": [
  null,
  "Manual"
 ],
 "Shared": [
  null,
  "Compartilhado"
 ],
 "Prefix length or netmask": [
  null,
  "Comprimento do prefixo ou máscara de rede"
 ],
 "Prefix length": [
  null,
  "Comprimento do prefixo"
 ],
 "IPv4 settings": [
  null,
  "IPv4 Ajustes"
 ],
 "IPv6 settings": [
  null,
  "IPv6 Ajustes"
 ],
 "Addresses": [
  null,
  "Endereços"
 ],
 "Select method": [
  null,
  "Selecionar método"
 ],
 "Add address": [
  null,
  "Adicionar endereço"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "Remove item": [
  null,
  "Remover item"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Adicionar servidor DNS"
 ],
 "DNS search domains": [
  null,
  "DNS Busca de Domínios"
 ],
 "Add search domain": [
  null,
  "Adicionar busca de domínios"
 ],
 "Search domain": [
  null,
  "Domínio de pesquisa"
 ],
 "Routes": [
  null,
  "Rotas"
 ],
 "Add route": [
  null,
  "Adicionar rota"
 ],
 "Metric": [
  null,
  "Métricas"
 ],
 "Enter a valid MAC address": [
  null,
  "Insira um endereço MAC válido"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 rede",
  "$0 redes"
 ],
 "Add VPN": [
  null,
  "Adicionar VPN"
 ],
 "Add bond": [
  null,
  "Adicionar vínculo"
 ],
 "Add VLAN": [
  null,
  "Adicionar VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Editar regras e zonas"
 ],
 "$0 active zone": [
  null,
  "$0 zona ativa",
  "$0 zonas ativas"
 ],
 "Managed interfaces": [
  null,
  "Interfaces Gerenciadas"
 ],
 "IP address": [
  null,
  "Endereço IP"
 ],
 "Sending": [
  null,
  "Enviando"
 ],
 "Receiving": [
  null,
  "Recebendo"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces Não Gerenciadas"
 ],
 "Network logs": [
  null,
  "Logs de rede"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Os endereços não estão formatados corretamente"
 ],
 "Invalid IP address '$0'": [
  null,
  "Endereço IP inválido \"$0\""
 ],
 "wireguard-tools package is not installed": [
  null,
  "O pacote wireguard-tools não está instalado"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Par #$0 tem um endpoint inválido. Ele deve ser especificado como host:porta. Por exemplo, 1.2.3.4:51820, [2001:db8::1]:51820 ou example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Par #$0 tem uma porta de endpoint inválida. A porta deve ser um número."
 ],
 "Listen port must be a number": [
  null,
  "A porta de escuta deve ser um número"
 ],
 "Add WireGuard VPN": [
  null,
  "Adicionar WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Editar VPN WireGuard"
 ],
 "Private key": [
  null,
  "Chave privada"
 ],
 "Paste existing key": [
  null,
  "Colar chave existente"
 ],
 "Regenerate": [
  null,
  "Regenerar"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "A chave pública será gerada quando uma chave privada válida for inserida"
 ],
 "Listen port": [
  null,
  "Porta de escuta"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Será definido como \"Automático\""
 ],
 "IP addresses": [
  null,
  "Endereços IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Múltiplos endereços podem ser especificados usando vírgulas ou espaços como delimitadores."
 ],
 "Peers": [
  null,
  "Pares"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Pares são outras máquinas que se conectam a esta. Chaves públicas de outras máquinas serão compartilhadas entre si."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "O endpoint que atua como um \"servidor\" precisa ser especificado como host:porta, caso contrário, pode ser deixado em branco."
 ],
 "Add peer": [
  null,
  "Adicionar par"
 ],
 "Endpoint": [
  null,
  "Endpoint"
 ],
 "Allowed IPs": [
  null,
  "IPs permitidos"
 ],
 "No peers added.": [
  null,
  "Nenhum par adicionado."
 ],
 "Edit VLAN settings": [
  null,
  "Editar configurações VLAN"
 ],
 "Parent": [
  null,
  "Parente"
 ],
 "VLAN ID": [
  null,
  "ID da VLAN"
 ],
 "Transmitting": [
  null,
  "Transmitindo"
 ],
 "MTU must be a positive number": [
  null,
  "O MTU deve ser um número positivo"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Configurado para"
 ],
 "Team port settings": [
  null,
  "Configurações da Porta da Equipe"
 ],
 "Sticky": [
  null,
  "Persistente"
 ],
 "LACP key": [
  null,
  "Chave LACP"
 ],
 "Bridge port settings": [
  null,
  "Configurações da Porta de Ponte"
 ],
 "Path cost": [
  null,
  "Custo do Caminho"
 ],
 "Hair pin mode": [
  null,
  "Modo Hair pin"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Transmissão dinâmica de balanceamento de carga"
 ],
 "Adaptive load balancing": [
  null,
  "Balanceamento de carga dinâmico"
 ],
 "MII (recommended)": [
  null,
  "MII (Recomendado)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Editar configurações de ligação"
 ],
 "Network bond": [
  null,
  "Agregação de rede"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Uma ligação de rede combina várias interfaces de rede em uma interface lógica com maior taxa de transferência ou redundância."
 ],
 "Link monitoring": [
  null,
  "Monitoramento de Link"
 ],
 "Monitoring interval": [
  null,
  "Monitorando intervalo"
 ],
 "Monitoring targets": [
  null,
  "Alvos de monitoramento"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Removendo $0 irá encerrar a conexão com o servidor e tornará a administração da interface do usuário indisponível."
 ],
 "Remove $0": [
  null,
  "Remover $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Adicionar $0 irá interromper a conexão com o servidor e tornará a interface de administração indisponível."
 ],
 "No interfaces available": [
  null,
  "Nenhuma interface disponível"
 ],
 "Add member": [
  null,
  "Adicionar membro"
 ],
 "Interface members": [
  null,
  "Membros da interface"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuração e resolução de problemas do Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ]
});
