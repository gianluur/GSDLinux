cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Browser file"
 ],
 "files": [
  null,
  "File"
 ],
 "explorer": [
  null,
  "Explorer"
 ],
 "filesystem": [
  null,
  "filesystem"
 ]
});
