cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "User name": [
  null,
  "Nome utente"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Local accounts": [
  null,
  "Account locali"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Fingerprint": [
  null,
  "Impronta digitale"
 ],
 "Copy": [
  null,
  "copia"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "New password": [
  null,
  "Nuova password"
 ],
 "Confirm password": [
  null,
  "Conferma la password"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Remove": [
  null,
  "Rimuovi"
 ],
 "Log out": [
  null,
  "Esci"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "Trust and add host": [
  null,
  "Considera attendibile e aggiungi host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'impronta digitale risultante può essere condivisa tramite metodi pubblici, inclusa l'email. Se chiedi a qualcun altro di eseguire la verifica per te, può inviare i risultati utilizzando qualsiasi metodo."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta."
 ],
 "Verify fingerprint": [
  null,
  "Verifica impronta digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "The fingerprint should match:": [
  null,
  "L'impronta digitale dovrebbe corrispondere a:"
 ],
 "The password can not be empty": [
  null,
  "La password non può essere vuota"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossibile accedere a $0. L'host non accetta l'accesso con password né alcuna delle tue chiavi SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta da password e l'host non consente l'accesso con password. Fornire la password della chiave $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta. Puoi accedere con la tua password di accesso o fornendo la password della chiave $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La chiave SSH $0 di $1 su $2 verrà aggiunta al file $3 di $4 su $5."
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La chiave SSH $0 sarà resa disponibile per il resto della sessione e sarà utilizzabile anche per l'accesso ad altri host."
 ],
 "Permission denied": [
  null,
  "Permesso negato"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change": [
  null,
  "Modifica"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nessun metodo per ottenere l'accesso amministrativo è disponibile (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Switch to administrative access": [
  null,
  "Passa all'accesso amministrativo"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema diventando amministratore"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld$0"
 ],
 "Visit firewall": [
  null,
  "Vai al firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "less than a minute ago": [
  null,
  "meno di un minuto fa"
 ],
 "in less than a minute": [
  null,
  "in meno di un minuto"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Weak password": [
  null,
  "Password debole"
 ],
 "Show password": [
  null,
  "Mostra la password"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "password quality": [
  null,
  "qualità password"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Removing $0": [
  null,
  "Rimozione di $0"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Unknown host: $0": [
  null,
  "Host sconosciuto: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossibile accedere a $0 usando l'autenticazione con chiave SSH. Fornire la password."
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Error during initialization": [
  null,
  "Si e verificato un errore durante l'inizializzazione"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Home": [
  null,
  "Home"
 ],
 "Downloads": [
  null,
  "Scaricati"
 ],
 "Not a directory": [
  null,
  "Non è una cartella"
 ],
 "All files": [
  null,
  "Tutti i file"
 ],
 "Recent": [
  null,
  "Recenti"
 ],
 "No recent directories": [
  null,
  "Nessuna cartella recente"
 ],
 "No recent files": [
  null,
  "Nessun file recente"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "File chooser actions": [
  null,
  "Azioni per scegliere il file"
 ],
 "Open in file browser": [
  null,
  "Aprire in un esploratore dei file"
 ],
 "Hide hidden files": [
  null,
  "Nascondi file nascosti"
 ],
 "Show hidden files": [
  null,
  "Mostra file nascosti"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Clear filters": [
  null,
  "Cancella filtri"
 ],
 "Directory is empty": [
  null,
  "La cartella è vuota"
 ],
 "Directory has no sub-directories": [
  null,
  "La cartella non ha sotto-cartelle"
 ],
 "This directory contains only hidden files": [
  null,
  "Questa cartella contiene soltanto file nascosti"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "Folder": [
  null,
  "Cartella"
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "View all logs": [
  null,
  "Visualizza tutti i log"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Delete files": [
  null,
  "Cancella file"
 ],
 "Delete $0": [
  null,
  "Cancella $0"
 ],
 "Edit user": [
  null,
  "Modifica utente"
 ],
 "Log user out": [
  null,
  "disconnetti l'utente"
 ],
 "Lock account": [
  null,
  "Blocca account"
 ],
 "Delete account": [
  null,
  "Elimina un account"
 ],
 "Logged in": [
  null,
  "Autenticato"
 ],
 "Never logged in": [
  null,
  "Nessuno autenticato"
 ],
 "Your account": [
  null,
  "Il tuo account"
 ],
 "Group name": [
  null,
  "Nome del gruppo"
 ],
 "# of users": [
  null,
  "di utenti"
 ],
 "Accounts": [
  null,
  "Account"
 ],
 "Search for name or ID": [
  null,
  "Cerca per nome o ID"
 ],
 "Create new group": [
  null,
  "Crea nuovo gruppo"
 ],
 "Groups": [
  null,
  "Gruppi"
 ],
 "$0 more...": [
  null,
  "$0 di più..."
 ],
 "Clear filter": [
  null,
  "Cancella filtro"
 ],
 "Username": [
  null,
  "Nome utente"
 ],
 "Full name": [
  null,
  "Nome completo"
 ],
 "Last active": [
  null,
  "ultima attività"
 ],
 "Group": [
  null,
  "Gruppo"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Search for name, group or ID": [
  null,
  "Cerca per nome, gruppo o ID"
 ],
 "Create new account": [
  null,
  "Crea un nuovo account"
 ],
 "No group name specified": [
  null,
  "Non è stato specificato il nome del gruppo"
 ],
 "Group name can only consist of letters, digits, dots, dashes, and underscores": [
  null,
  "Il nome del gruppo può contenere solo lettere, cifre, punti, trattini e trattini bassi"
 ],
 "A group with this name already exists": [
  null,
  "Esiste già un gruppo con questo nome"
 ],
 "No ID specified": [
  null,
  "Nessun ID specificato"
 ],
 "Group ID must be positive integer": [
  null,
  "L'ID del gruppo deve essere un numero intero positivo"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "New name": [
  null,
  "Nuovo nome"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "Rinominare un gruppo può influenzare le regole di sudo e simili"
 ],
 "Group name cannot be empty": [
  null,
  "Il nome del gruppo non può essere vuoto"
 ],
 "Rename group $0": [
  null,
  "Rinominare il gruppo $0"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Login history": [
  null,
  "Cronologia accessi"
 ],
 "Login history list": [
  null,
  "Elenco cronologia accessi"
 ],
 "Started": [
  null,
  "Avviato"
 ],
 "Ended": [
  null,
  "Concluso"
 ],
 "From": [
  null,
  "Da"
 ],
 "Prompting via passwd timed out": [
  null,
  "Richiesta tramite passwd scaduta"
 ],
 "You must wait longer to change your password": [
  null,
  "Devi aspettare più a lungo per cambiare la tua password"
 ],
 "Old password": [
  null,
  "Vecchia password"
 ],
 "Confirm new password": [
  null,
  "Conferma nuova password"
 ],
 "The passwords do not match": [
  null,
  "Le password non corrispondono"
 ],
 "Password is longer than 256 characters": [
  null,
  "La password è più lunga di 256 caratteri"
 ],
 "Set password": [
  null,
  "Imposta password"
 ],
 "Set weak password": [
  null,
  "Imposta una password debole"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "L'account '$0' sarà costretto a cambiare la propria password al prossimo login"
 ],
 "Force password change": [
  null,
  "Forzare la modifica della password"
 ],
 "Reset password": [
  null,
  "Resetta password"
 ],
 "Logout $0": [
  null,
  "Disconnetti $0"
 ],
 "Rename group": [
  null,
  "Rinomina il gruppo"
 ],
 "Delete group": [
  null,
  "Elimina gruppo"
 ],
 "Home directory": [
  null,
  "Home Directory"
 ],
 "Path to directory": [
  null,
  "Percorso della directory"
 ],
 "Shell": [
  null,
  "Shell"
 ],
 "User ID": [
  null,
  "ID utente"
 ],
 "Use password": [
  null,
  "Usa password"
 ],
 "Require password change on first login": [
  null,
  "Richiedi la modifica della password al primo accesso"
 ],
 "Disallow password authentication": [
  null,
  "Non consentire l'autenticazione con password"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Altri metodi di autenticazione sono ancora disponibili anche quando l'autenticazione tramite password interattiva non è consentita."
 ],
 "No user name specified": [
  null,
  "Nessun nome utente specificato"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Il nome utente può essere composto solo da lettere da a-z, cifre, punti, trattini e sottolineature."
 ],
 "This user name already exists": [
  null,
  "Questo nome utente esiste già"
 ],
 "No real name specified": [
  null,
  "Nessun nome reale specificato"
 ],
 "The full name must not contain colons.": [
  null,
  "Il nome completo non deve contenere i due punti."
 ],
 "User ID must be a positive integer": [
  null,
  "L'ID utente deve essere un numero intero positivo"
 ],
 "User ID must not be lower than $0": [
  null,
  "L'ID utente non deve essere inferiore a $0"
 ],
 "User ID must not be higher than $0": [
  null,
  "L'ID utente non deve essere superiore a $0"
 ],
 "User ID is already used by another user": [
  null,
  "ID utente già utilizzato da un altro utente"
 ],
 "Empty password": [
  null,
  "Password vuota"
 ],
 "$0 is an existing file": [
  null,
  "$0 è un file non esistente"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "La directory home $0 esiste già. La sua proprietà verrà cambiata con quella del nuovo utente."
 ],
 "Create and change ownership of home directory": [
  null,
  "Creare e cambiare la proprietà della home directory"
 ],
 "Create account with weak password": [
  null,
  "Crea l'account con una password debole"
 ],
 "Create account with non-unique UID": [
  null,
  "Crea un account con un UID non univoco"
 ],
 "Never expire password": [
  null,
  "Non far scadere mai la password"
 ],
 "Password must be changed": [
  null,
  "La password deve essere cambiata"
 ],
 "Require password change on $0": [
  null,
  "Richiedi la modifica della password su $0"
 ],
 "Never expire account": [
  null,
  "Nessun account scaduto"
 ],
 "Expire account on $0": [
  null,
  "Scadenza dell'account il $0"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Account non disponibile o non modificabile."
 ],
 "Back to accounts": [
  null,
  "Torna agli account"
 ],
 "Never": [
  null,
  "Mai"
 ],
 "Terminate session": [
  null,
  "Termina la sessione"
 ],
 "Last login": [
  null,
  "Ultimo accesso"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Disallow interactive password": [
  null,
  "Non consentire password interattiva"
 ],
 "Force change": [
  null,
  "Forza modifica"
 ],
 "change": [
  null,
  "cambia"
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "L'utente deve disconnettersi e riconnettersi affinché la nuova configurazione abbia effetto."
 ],
 "Undo": [
  null,
  "Annulla"
 ],
 "Permanently delete $0 group?": [
  null,
  "Eliminare definitivamente $0 il gruppo?"
 ],
 "This group is the primary group for the following users:": [
  null,
  "Questo gruppo è il gruppo principale per i seguenti utenti:"
 ],
 "Force delete": [
  null,
  "Forza eliminazione"
 ],
 "Change shell": [
  null,
  "Cambia shell"
 ],
 "Expire account on": [
  null,
  "Scadenza dell'account il"
 ],
 "Please specify an expiration date": [
  null,
  "Specifica una data di scadenza"
 ],
 "Invalid expiration date": [
  null,
  "Data di scadenza non valida"
 ],
 "Account expiration": [
  null,
  "Scadenza account"
 ],
 "Require password change every $0 days": [
  null,
  "Richiedi la modifica della password ogni $0 giorni"
 ],
 "Invalid number of days": [
  null,
  "Numero di giorni non valido"
 ],
 "Password expiration": [
  null,
  "Scadenza della password"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Incollare qui il contenuto del file della chiave SSH pubblica"
 ],
 "Add public key": [
  null,
  "Aggiungi chiave pubblica"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Non hai il permesso di visualizzare le chiavi pubbliche autorizzate per questo account."
 ],
 "Failed to load authorized keys.": [
  null,
  "Impossibile caricare le chiavi autorizzate."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Non ci sono chiavi pubbliche autorizzate per questo account."
 ],
 "Authorized public SSH keys": [
  null,
  "Chiavi SSH pubbliche autorizzate"
 ],
 "Unnamed": [
  null,
  "Senza nome"
 ],
 "Invalid key": [
  null,
  "Chiave non valida"
 ],
 "Error saving authorized keys: ": [
  null,
  "Errore nel salvare le chiavi autorizzate: "
 ],
 "The key you provided was not valid.": [
  null,
  "La chiave fornita non era valida."
 ],
 "Lock $0": [
  null,
  "Blocca $0"
 ],
 "Lock": [
  null,
  "Blocca"
 ],
 "user": [
  null,
  "utente"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Questo strumento configura il sistema per scrivere i dump di crash del kernel. Supporta le destinazioni di dump \"locale\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ]
});
