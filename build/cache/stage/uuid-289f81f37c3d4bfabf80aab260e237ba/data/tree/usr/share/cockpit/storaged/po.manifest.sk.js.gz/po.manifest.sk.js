cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "unmount": [
  null,
  "odpojiť"
 ],
 "mount": [
  null,
  "mount"
 ],
 "format": [
  null,
  "Formátovať"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "Súborový systém"
 ],
 "partition": [
  null,
  "oddiel"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "zväzok"
 ],
 "disk": [
  null,
  "disk"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "Šifrovanie"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Správa oddielov"
 ],
 "Managing NFS mounts": [
  null,
  "Správa NFS pripojení"
 ],
 "Managing RAIDs": [
  null,
  "Správa RAID polí"
 ],
 "Managing LVMs": [
  null,
  "Správa LVM"
 ],
 "Managing physical drives": [
  null,
  "Správa fyzických diskov"
 ],
 "Managing VDOs": [
  null,
  "Správa VDO optimalizátorov"
 ],
 "Using LUKS encryption": [
  null,
  "S použitím LUKS šifrovania"
 ],
 "Using Tang server": [
  null,
  "S použitím servera Tang"
 ]
});
