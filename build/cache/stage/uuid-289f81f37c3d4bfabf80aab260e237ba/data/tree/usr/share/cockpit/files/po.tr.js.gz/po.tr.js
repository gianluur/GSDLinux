cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Dosyalar"
 ],
 "Home": [
  null,
  "Ev dizini"
 ],
 "Unable to create bookmark directory": [
  null,
  "Yer işareti dizini oluşturulamıyor"
 ],
 "Unable to save bookmark file": [
  null,
  "Yer işareti dosyası kaydedilemiyor"
 ],
 "Remove from bookmarks": [
  null,
  "Yer işaretlerinden kaldır"
 ],
 "Add to bookmarks": [
  null,
  "Yer işaretlerine ekle"
 ],
 "Bookmarks": [
  null,
  "Yer işaretleri"
 ],
 "Bookmarked": [
  null,
  "Yer işaretlerine eklendi"
 ],
 "Not bookmarked": [
  null,
  "Yer işaretlerine eklenmedi"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Edit path": [
  null,
  "Yolu düzenle"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Largest size": [
  null,
  "En büyük boyut"
 ],
 "Smallest size": [
  null,
  "En küçük boyut"
 ],
 "Modified": [
  null,
  "Değiştirilme"
 ],
 "First modified": [
  null,
  "İlk değiştirilme"
 ],
 "Last modified": [
  null,
  "Son değiştirilme"
 ],
 "Owner": [
  null,
  "Sahibi"
 ],
 "Owner ascending": [
  null,
  "Sahibine göre artan"
 ],
 "Owner descending": [
  null,
  "Sahibine göre azalan"
 ],
 "Permissions": [
  null,
  "İzinler"
 ],
 "Most permissive": [
  null,
  "En çok izin veren"
 ],
 "Least permissive": [
  null,
  "En az izin veren"
 ],
 "Show keyboard shortcuts": [
  null,
  "Klavye kısayollarını göster"
 ],
 "Filter directory": [
  null,
  "Dizini filtrele"
 ],
 "Display as a list": [
  null,
  "Liste olarak görüntüle"
 ],
 "Display as a grid": [
  null,
  "Izgara olarak görüntüle"
 ],
 "Sort": [
  null,
  "Sırala"
 ],
 "Hide hidden items": [
  null,
  "Gizli ögeleri gizle"
 ],
 "Show hidden items": [
  null,
  "Gizli ögeleri göster"
 ],
 "$0 files": [
  null,
  "$0 dosya"
 ],
 "Uploaded as $0, $1": [
  null,
  "$0, $1 olarak karşıya yüklendi"
 ],
 "Replace file $0?": [
  null,
  "$0 dosyası değiştirilsin mi?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Aynı ada sahip bir dosya \"$0\" içinde zaten var. Değiştirmek içeriğinin üzerine yazacaktır."
 ],
 "New file": [
  null,
  "Yeni dosya"
 ],
 "Original file on server": [
  null,
  "Sunucudaki orijinal dosya"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Bu eylemi çakışan tüm dosyalara uygula"
 ],
 "Replace": [
  null,
  "Değiştir"
 ],
 "Keep original": [
  null,
  "Orijinali sakla"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Upload error": [
  null,
  "Karşıya yükleme hatası"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Karşıya yüklenen dosya son hedefe taşınamıyor"
 ],
 "Cancelled": [
  null,
  "İptal edildi"
 ],
 "Cancelled upload of $0": [
  null,
  "$0 karşıya yüklenmesi iptal edildi"
 ],
 "File uploaded": [
  null,
  "Dosya karşıya yüklendi"
 ],
 "Files uploaded": [
  null,
  "Dosyalar karşıya yüklendi"
 ],
 "Change permissions": [
  null,
  "İzinleri değiştir"
 ],
 "Uploads": [
  null,
  "Yüklenenler"
 ],
 "Cancel upload of $0": [
  null,
  "$0 karşıya yüklenmesini iptal et"
 ],
 "Upload $0% completed": [
  null,
  "Karşıya yükleme %$0 tamamlandı"
 ],
 "Upload": [
  null,
  "Karşıya yükle"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Execute-only": [
  null,
  "Yalnızca çalıştır"
 ],
 "Write-only": [
  null,
  "Yalnızca yaz"
 ],
 "Write and execute": [
  null,
  "Yaz ve çalıştır"
 ],
 "Read-only": [
  null,
  "Yalnızca oku"
 ],
 "Read and execute": [
  null,
  "Oku ve çalıştır"
 ],
 "Read and write": [
  null,
  "Oku ve yaz"
 ],
 "Read, write, and execute": [
  null,
  "Oku, yaz ve çalıştır"
 ],
 "Block device": [
  null,
  "Blok aygıtı"
 ],
 "Character device": [
  null,
  "Karakter aygıtı"
 ],
 "Directory": [
  null,
  "Dizin"
 ],
 "Named pipe": [
  null,
  "Adlı boru (pipe)"
 ],
 "Symbolic link": [
  null,
  "Sembolik bağlantı"
 ],
 "Regular file": [
  null,
  "Normal dosya"
 ],
 "Socket": [
  null,
  "Soket"
 ],
 "Name cannot be empty": [
  null,
  "Ad boş olamaz"
 ],
 "Name too long": [
  null,
  "Ad çok uzun"
 ],
 "Name cannot include a /": [
  null,
  "Ad / karakteri içeremez"
 ],
 "Filename is the same as original name": [
  null,
  "Dosya adı ilk adıyla aynı"
 ],
 "Directory with the same name exists": [
  null,
  "Aynı ada sahip dizin var"
 ],
 "File exists": [
  null,
  "Dosya var"
 ],
 "Pasting failed": [
  null,
  "Yapıştırma başarısız oldu"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" var, yapıştırma ile üzerine yazılmıyor."
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Create directory": [
  null,
  "Dizin oluştur"
 ],
 "Create file": [
  null,
  "Dosya oluştur"
 ],
 "Edit permissions": [
  null,
  "İzinleri düzenle"
 ],
 "Open in terminal": [
  null,
  "Terminalde aç"
 ],
 "Open text file": [
  null,
  "Metin dosyası aç"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Download": [
  null,
  "İndir"
 ],
 "Create link": [
  null,
  "Bağlantı oluştur"
 ],
 "Drop files to upload": [
  null,
  "Karşıya yüklenecek dosyaları bırakın"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Dosyalar bırakılamıyor, başka bir karşıya yükleme zaten devam ediyor"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Go up a directory": [
  null,
  "Bir dizin yukarı git"
 ],
 "Go back": [
  null,
  "Geri git"
 ],
 "Go forward": [
  null,
  "İleri git"
 ],
 "Activate selected item, enter directory": [
  null,
  "Seçili ögeyi etkinleştir, dizine gir"
 ],
 "Rename selected file or directory": [
  null,
  "Seçili dosya veya dizini yeniden adlandır"
 ],
 "Create new directory": [
  null,
  "Yeni dizin oluştur"
 ],
 "Copy selected file or directory": [
  null,
  "Seçili dosya veya dizini kopyala"
 ],
 "Paste file or directory": [
  null,
  "Dosya veya dizini yapıştır"
 ],
 "Select all": [
  null,
  "Tümünü seç"
 ],
 "Save current file": [
  null,
  "Şu anki dosyayı kaydet"
 ],
 "Close editor": [
  null,
  "Düzenleyiciyi kapat"
 ],
 "Keyboard shortcuts": [
  null,
  "Klavye kısayolları"
 ],
 "Navigation": [
  null,
  "Gezinme"
 ],
 "Editing": [
  null,
  "Düzenleme"
 ],
 "Editor": [
  null,
  "Düzenleyici"
 ],
 "Force delete $0 items": [
  null,
  "$0 ögeyi silmeye zorla"
 ],
 "Delete $0 items?": [
  null,
  "$0 öge silinsin mi?"
 ],
 "Force delete file $0?": [
  null,
  "$0 dosyası silmeye zorlansın mı?"
 ],
 "Delete file $0?": [
  null,
  "$0 dosyası silinsin mi?"
 ],
 "Force delete link $0?": [
  null,
  "$0 bağlantısı silmeye zorlansın mı?"
 ],
 "Delete link $0?": [
  null,
  "$0 bağlantısı silinsin mi?"
 ],
 "Force delete directory $0?": [
  null,
  "$0 dizini silmeye zorlansın mı?"
 ],
 "Delete directory $0?": [
  null,
  "$0 dizini silinsin mi?"
 ],
 "Force delete $0": [
  null,
  "$0 ögesini silmeye zorla"
 ],
 "Delete $0?": [
  null,
  "$0 silinsin mi?"
 ],
 "No access": [
  null,
  "Erişim yok"
 ],
 "Missing type": [
  null,
  "Tür eksik"
 ],
 "Collapse": [
  null,
  "Daralt"
 ],
 "Show all files": [
  null,
  "Tüm dosyaları göster"
 ],
 "$0 permissions": [
  null,
  "$0 izinleri"
 ],
 "Permissions for $0 files": [
  null,
  "$0 dosya için izinler"
 ],
 "Ownership": [
  null,
  "Sahiplik"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Access": [
  null,
  "Erişim"
 ],
 "Owner access": [
  null,
  "Sahibinin erişimi"
 ],
 "Group access": [
  null,
  "Grup erişimi"
 ],
 "Others access": [
  null,
  "Diğerlerinin erişimi"
 ],
 "Security context": [
  null,
  "Güvenlik bağlamı"
 ],
 "Set executable as program": [
  null,
  "Çalıştırılabilir program olarak ayarla"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change permissions for enclosed files": [
  null,
  "İçerilen dosyalar için izinleri değiştir"
 ],
 "(original owner)": [
  null,
  "(orijinal sahibi)"
 ],
 "keep original owners": [
  null,
  "orijinal sahiplerini sakla"
 ],
 "Paste as owner": [
  null,
  "Sahibi olarak yapıştır"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Yapıştırılan dosyaların farklı bir sahibi var. Varsayılan olarak sahiplik, hedef dizin ile eşleşmesi için değiştirilecektir."
 ],
 "New owner": [
  null,
  "Yeni sahibi"
 ],
 "Overwrite": [
  null,
  "Üzerine yaz"
 ],
 "New filename": [
  null,
  "Yeni dosya adı"
 ],
 "New name": [
  null,
  "Yeni ad"
 ],
 "Rename $0?": [
  null,
  "$0 yeniden adlandırılsın mı?"
 ],
 "link to $0": [
  null,
  "$0 için bağlantı"
 ],
 "Create link to $0": [
  null,
  "$0 için bağlantı oluştur"
 ],
 "Target": [
  null,
  "Hedef"
 ],
 "Symlink name": [
  null,
  "Sembolik bağlantı adı"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Absolute vs. Relative": [
  null,
  "Göreceli'ye karşı Kesin"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Kesin sembolik bağlantılar, sistem dosyaları gibi hareket etmeyen dosyalara veya dizinlere başvururken idealdir."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Göreceli sembolik bağlantılar, bir üst dizini yeniden adlandırırken veya taşırken olduğu gibi, hem bir sembolik bağlantı hem de hedef aynı anda hareket edebildiğinde kullanışlıdır."
 ],
 "Absolute": [
  null,
  "Kesin"
 ],
 "Relative": [
  null,
  "Göreceli"
 ],
 "The file has been removed on disk": [
  null,
  "Dosya diskten kaldırıldı"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Var olan dosya beklenmedik şekilde değişti"
 ],
 "Edit $0": [
  null,
  "$0 dosyasını düzenle"
 ],
 "View $0": [
  null,
  "$0 dosyasını görüntüle"
 ],
 "The file has changed on disk": [
  null,
  "Dosya disk üzerinde değişti"
 ],
 "Reload": [
  null,
  "Yeniden yükle"
 ],
 "Ignore": [
  null,
  "Yok say"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save changes?": [
  null,
  "Değişiklikler kaydedilsin mi?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Dosya açıldıktan sonra silindi, kaydetmek yeniden oluşturacak."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Dosya, açıldığı zaman ile şu an arasında diskte değişti"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 kaydedilmemiş değişikliklere sahip ve vazgeçilirse kalıcı olarak kaybolacaktır."
 ],
 "Discard": [
  null,
  "Vazgeç"
 ],
 "File name": [
  null,
  "Dosya adı"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Cannot create file in current directory": [
  null,
  "Şu anki dizinde dosya oluşturulamıyor"
 ],
 "Permission denied": [
  null,
  "İzin reddedildi"
 ],
 "Directory name cannot be empty": [
  null,
  "Dizin adı boş olamaz"
 ],
 "Directory name too long": [
  null,
  "Dizin adı çok uzun"
 ],
 "Directory name cannot include a /": [
  null,
  "Dizin adı / karakteri içeremez"
 ],
 "Directory name": [
  null,
  "Dizin adı"
 ],
 "Directory owner": [
  null,
  "Dizin sahibi"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuç yok"
 ],
 "Clear filter": [
  null,
  "Filtreyi temizle"
 ],
 "Directory is empty": [
  null,
  "Dizin boş"
 ],
 "$0 item is hidden": [
  null,
  "$0 gizli öge",
  "$0 gizli öge"
 ],
 "Folder": [
  null,
  "Klasör"
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Others": [
  null,
  "Diğerleri"
 ],
 "$0 files selected": [
  null,
  "$0 dosya seçildi"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Dizin, $0 dizin ve $1 dosya içeriyor"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Dizin, $0 dizin ve $1 dosya içeriyor, $2 tanesi gizli"
 ],
 "User": [
  null,
  "Kullanıcı"
 ]
});
