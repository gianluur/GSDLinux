cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Kunci yang berubah sering kali disebabkan oleh instalasi ulang sistem operasi. Namun, perubahan yang tidak terduga dapat menunjukkan upaya pihak ketiga untuk mencegat koneksi Anda."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Untuk memastikan bahwa koneksi Anda tidak dicegat oleh pihak ketiga berbahaya, harap verifikasi sidik jari kunci host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email."
 ],
 "Password": [
  null,
  "Kata sandi"
 ],
 "Log in": [
  null,
  "Masuk"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Layanan"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Copied": [
  null,
  "Disalin"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Details": [
  null,
  "Detail"
 ],
 "Public key": [
  null,
  "Kunci publik"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Edit": [
  null,
  "Edit"
 ],
 "Select": [
  null,
  "Pilih"
 ],
 "Unexpected error": [
  null,
  "Kesalahan tak terduga"
 ],
 "No results found": [
  null,
  "Tidak ada hasil ditemukan"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit tidak terpasang"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Versi Cockpit yang kompatibel tidak terinstal pada $0."
 ],
 "Connect": [
  null,
  "Hubungkan"
 ],
 "Add": [
  null,
  "Tambah"
 ],
 "$0 key changed": [
  null,
  "Kunci $0 telah berubah"
 ],
 "Trust and add host": [
  null,
  "Percayai dan tambahkan host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Untuk memverifikasi sidik jari, jalankan perintah berikut di $0 saat berada langsung di mesin atau melalui jaringan tepercaya:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jika sidik jari cocok, klik 'Percayai dan tambahkan host'. Jika tidak, jangan sambungkan dan hubungi administrator Anda."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email. Jika Anda meminta orang lain untuk melakukan verifikasi, mereka dapat mengirim hasilnya dengan metode apa pun."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Anda terhubung ke $0 untuk pertama kalinya."
 ],
 "Verify fingerprint": [
  null,
  "Verifikasi sidik jari"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Jalankan perintah ini melalui jaringan tepercaya atau langsung di mesin jarak jauh:"
 ],
 "The fingerprint should match:": [
  null,
  "Sidik jari harus cocok:"
 ],
 "The password can not be empty": [
  null,
  "Kata sandi tidak boleh kosong"
 ],
 "The key password can not be empty": [
  null,
  "Kata sandi kunci tidak boleh kosong"
 ],
 "The key passwords do not match": [
  null,
  "Kata sandi kunci tidak cocok"
 ],
 "Log in to $0": [
  null,
  "Masuk ke $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Tidak dapat masuk ke $0. Host tidak menerima login dengan kata sandi atau salah satu kunci SSH Anda."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi oleh kata sandi, dan host tidak mengizinkan login dengan kata sandi. Harap berikan kata sandi untuk kunci di $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi. Anda dapat masuk dengan kata sandi login Anda atau dengan memberikan kata sandi untuk kunci di $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Buat kunci SSH baru dan otorisasi"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH baru di $0 akan dibuat untuk $1 di $2 dan akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Key password": [
  null,
  "Kata sandi kunci"
 ],
 "Confirm key password": [
  null,
  "Konfirmasi kata sandi kunci"
 ],
 "Authorize SSH key": [
  null,
  "Otorisasi kunci SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH $0 dari $1 di $2 akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Authentication": [
  null,
  "Autentikasi"
 ],
 "SSH key": [
  null,
  "Kunci SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Kunci SSH $0 akan tersedia selama sisa sesi dan dapat digunakan untuk login ke host lain."
 ],
 "Disconnected": [
  null,
  "Terputus"
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Clear input value": [
  null,
  "Hapus nilai masukan"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format tanggal dan waktu tidak valid"
 ],
 "Invalid time format": [
  null,
  "Format waktu tidak valid"
 ],
 "Invalid date format": [
  null,
  "Format tanggal tidak valid"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tidak dapat menjadwalkan acara di masa lalu"
 ],
 "No delay": [
  null,
  "Tanpa penundaan"
 ],
 "1 minute": [
  null,
  "1 Menit"
 ],
 "5 minutes": [
  null,
  "5 menit"
 ],
 "20 minutes": [
  null,
  "20 Menit"
 ],
 "40 minutes": [
  null,
  "40 Menit"
 ],
 "60 minutes": [
  null,
  "60 Menit"
 ],
 "Specific time": [
  null,
  "Waktu tertentu"
 ],
 "Shut down": [
  null,
  "Matikan"
 ],
 "Reboot": [
  null,
  "Reboot"
 ],
 "Message to logged in users": [
  null,
  "Pesan ke pengguna yang sedang masuk"
 ],
 "Delay": [
  null,
  "Jeda"
 ],
 "Pick date": [
  null,
  "Pilih tanggal"
 ],
 "Toggle date picker": [
  null,
  "Beralih pemilih tanggal"
 ],
 "Synchronized": [
  null,
  "Tersinkronisasi"
 ],
 "Synchronized with $0": [
  null,
  "Tersinkronisasi dengan $0"
 ],
 "Synchronizing": [
  null,
  "Sedang menyinkronkan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Mencoba menyinkronkan dengan $0"
 ],
 "Not synchronized": [
  null,
  "Tidak tersinkronisasi"
 ],
 "Log messages": [
  null,
  "Pesan log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Secara manual"
 ],
 "Automatically using NTP": [
  null,
  "Secara otomatis menggunakan NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Menggunakan server NTP tambahan secara otomatis"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Menggunakan server NTP tertentu secara otomatis"
 ],
 "Time zone": [
  null,
  "Zona waktu"
 ],
 "Set time": [
  null,
  "Atur waktu"
 ],
 "Invalid timezone": [
  null,
  "Zona waktu tidak valid"
 ],
 "Need at least one NTP server": [
  null,
  "Membutuhkan setidaknya satu server NTP"
 ],
 "Change system time": [
  null,
  "Ubah Waktu Sistem"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Path to file": [
  null,
  "Jalur ke berkas"
 ],
 "No such file or directory": [
  null,
  "Tidak ada berkas atau direktori"
 ],
 "Create $0": [
  null,
  "Buat $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Pelajari lebih lanjut"
 ],
 "You now have administrative access.": [
  null,
  "Anda sekarang memiliki akses administratif."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Tidak ada metode untuk mendapatkan akses administratif yang tersedia (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Silakan autentikasi untuk mendapatkan akses administratif"
 ],
 "Switch to administrative access": [
  null,
  "Beralih ke akses administratif"
 ],
 "Authenticate": [
  null,
  "Autentikasi"
 ],
 "Administrative access": [
  null,
  "Akses administratif"
 ],
 "Problem becoming administrator": [
  null,
  "Masalah saat menjadi administrator"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Limit access": [
  null,
  "Batasi akses"
 ],
 "Switch to limited access": [
  null,
  "Beralih ke mode akses terbatas"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Mode akses terbatas membatasi hak administratif. Beberapa bagian dari konsol web akan memiliki fungsionalitas yang terbatas."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Peramban Anda akan mengingat tingkat akses Anda di seluruh sesi."
 ],
 "Limited access": [
  null,
  "Akses terbatas"
 ],
 "Turn on administrative access": [
  null,
  "Aktifkan akses administratif"
 ],
 "$0 year": [
  null,
  "$0 tahun"
 ],
 "$0 month": [
  null,
  "$0 bulan"
 ],
 "$0 week": [
  null,
  "$0 minggu"
 ],
 "$0 day": [
  null,
  "$0 hari"
 ],
 "$0 hour": [
  null,
  "$0 jam"
 ],
 "$0 minute": [
  null,
  "$0 menit"
 ],
 "Go to now": [
  null,
  "Pergi ke sekarang"
 ],
 "1 hour": [
  null,
  "1 jam"
 ],
 "6 hours": [
  null,
  "6 jam"
 ],
 "1 day": [
  null,
  "1 hari"
 ],
 "1 week": [
  null,
  "1 minggu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Gagal mengaktifkan $0 di firewalld"
 ],
 "Visit firewall": [
  null,
  "Kunjungi firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Tambahkan $0"
 ],
 "less than a minute ago": [
  null,
  "kurang dari satu menit yang lalu"
 ],
 "in less than a minute": [
  null,
  "dalam waktu kurang dari satu menit"
 ],
 "Password is too weak": [
  null,
  "Kata sandi terlalu lemah"
 ],
 "Excellent password": [
  null,
  "Sandi bagus"
 ],
 "Password is not acceptable": [
  null,
  "Kata sandi tidak dapat diterima"
 ],
 "Strong password": [
  null,
  "Kata sandi kuat"
 ],
 "Acceptable password": [
  null,
  "Kata sandi dapat diterima"
 ],
 "Weak password": [
  null,
  "Kata sandi lemah"
 ],
 "Show password": [
  null,
  "Tampilkan kata sandi"
 ],
 "Hide password": [
  null,
  "Sembunyikan kata sandi"
 ],
 "password quality": [
  null,
  "kualitas kata sandi"
 ],
 "Show confirmation password": [
  null,
  "Tampilkan konfirmasi kata sandi"
 ],
 "Hide confirmation password": [
  null,
  "Sembunyikan konfirmasi kata sandi"
 ],
 "Additional packages:": [
  null,
  "Paket tambahan:"
 ],
 "Removals:": [
  null,
  "Penghapusan:"
 ],
 "Total size: $0": [
  null,
  "Total ukuran: $0"
 ],
 "Install software": [
  null,
  "Instal perangkat lunak"
 ],
 "$0 will be installed.": [
  null,
  "$0 akan diinstal."
 ],
 "Install": [
  null,
  "Instal"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Menunggu operasi pengelolaan perangkat lunak lain selesai"
 ],
 "Checking installed software": [
  null,
  "Memeriksa perangkat lunak yang terpasang"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 tidak tersedia dari repositori mana pun."
 ],
 "Downloading $0": [
  null,
  "Mengunduh $0"
 ],
 "Removing $0": [
  null,
  "Menghapus $0"
 ],
 "Installing $0": [
  null,
  "Memasang $0"
 ],
 "Unknown host: $0": [
  null,
  "Host tidak dikenal: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Tidak dapat masuk ke $0 menggunakan autentikasi kunci SSH. Harap berikan kata sandi."
 ],
 "SSH key login": [
  null,
  "Login dengan kunci SSH"
 ],
 "[no data]": [
  null,
  "[Tidak ada data]"
 ],
 "[binary data]": [
  null,
  "[data biner]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit berhenti secara mendadak"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit melaporkan kode kesalahan $0"
 ],
 "show less": [
  null,
  "tampilkan lebih sedikit"
 ],
 "show more": [
  null,
  "tampilkan lebih banyak"
 ],
 "Row expansion": [
  null,
  "Perluasan baris"
 ],
 "Row select": [
  null,
  "Pilih baris"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Kesalahan menempel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Peramban Anda tidak mengizinkan tempel dari menu konteks. Anda dapat menggunakan Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Kesalahan saat inisialisasi"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Downloads": [
  null,
  "Unduhan"
 ],
 "Not a directory": [
  null,
  "Bukan direktori"
 ],
 "All files": [
  null,
  "Semua berkas"
 ],
 "Recent": [
  null,
  "Terbaru"
 ],
 "No recent directories": [
  null,
  "Tidak ada direktori terbaru"
 ],
 "No recent files": [
  null,
  "Tidak ada berkas terbaru"
 ],
 "Type to filter": [
  null,
  "Ketik untuk memfilter"
 ],
 "File chooser actions": [
  null,
  "Tindakan pemilih berkas"
 ],
 "Open in file browser": [
  null,
  "Buka di peramban berkas"
 ],
 "Hide hidden files": [
  null,
  "Sembunyikan berkas tersembunyi"
 ],
 "Show hidden files": [
  null,
  "Tampilkan berkas tersembunyi"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Clear filters": [
  null,
  "Hapus filter"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "Directory has no sub-directories": [
  null,
  "Direktori tidak memiliki subdirektori"
 ],
 "This directory contains only hidden files": [
  null,
  "Direktori ini hanya berisi berkas tersembunyi"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "Folder": [
  null,
  "Folder"
 ],
 "File": [
  null,
  "Berkas"
 ],
 "Copy to clipboard": [
  null,
  "Salin ke papan klip"
 ],
 "Automation script": [
  null,
  "Skrip otomatisasi"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Buat berkas tugas baru dengan konten ini."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentasi peran Ansible"
 ],
 "Shell script": [
  null,
  "Skrip shell"
 ],
 "No system modifications": [
  null,
  "Tidak ada modifikasi sistem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Pengguna yang masuk tidak diizinkan melihat modifikasi sistem"
 ],
 "Loading system modifications...": [
  null,
  "Memuat modifikasi sistem..."
 ],
 "View automation script": [
  null,
  "Lihat skrip otomatisasi"
 ],
 "Occurrences": [
  null,
  "Kejadian"
 ],
 "View all logs": [
  null,
  "Lihat semua log"
 ],
 "Other": [
  null,
  "Lainnya"
 ],
 "Unknown": [
  null,
  "Tidak diketahui"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop profil rendah"
 ],
 "Pizza box": [
  null,
  "Casing pipih (Pizza box)"
 ],
 "Mini tower": [
  null,
  "Menara mini"
 ],
 "Tower": [
  null,
  "Menara"
 ],
 "Portable": [
  null,
  "Portabel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Perangkat genggam"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer hemat ruang"
 ],
 "Lunch box": [
  null,
  "Casing kecil"
 ],
 "Main server chassis": [
  null,
  "Chassis server utama"
 ],
 "Expansion chassis": [
  null,
  "Chassis ekspansi"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassis ekspansi bus"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferal"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis rak mount"
 ],
 "Sealed-case PC": [
  null,
  "PC tertutup rapat"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multi-sistem"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Penutup pisau"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Dapat dilepas"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC Embedded"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC stik"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Peringkat tunggal"
 ],
 "Dual rank": [
  null,
  "Peringkat ganda"
 ],
 "Absent": [
  null,
  "Absen"
 ],
 "Present": [
  null,
  "Ada"
 ],
 "Old password not accepted": [
  null,
  "Kata sandi lama tidak diterima"
 ],
 "Failed to change password": [
  null,
  "Gagal mengubah kata sandi"
 ],
 "New password was not accepted": [
  null,
  "Kata sandi baru tidak diterima"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Permintaan melalui ssh-keygen habis waktu"
 ],
 "Not a valid private key": [
  null,
  "Bukan kunci pribadi yang valid"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Permintaan melalui ssh-add habis waktu"
 ],
 "Invalid file permissions": [
  null,
  "Izin berkas tidak valid"
 ],
 "Password not accepted": [
  null,
  "Kata sandi tidak diterima"
 ],
 "Select an option": [
  null,
  "Pilih opsi"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dihentikan dengan sinyal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 keluar dengan kode $1"
 ],
 "$0 failed": [
  null,
  "$0 gagal"
 ],
 "Your session has been terminated.": [
  null,
  "Sesi Anda telah diakhiri."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesi Anda telah kedaluwarsa. Harap login kembali."
 ],
 "Not permitted to perform this action.": [
  null,
  "Tidak diizinkan untuk melakukan tindakan ini."
 ],
 "Login failed": [
  null,
  "Login gagal"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server menolak mengautentikasi menggunakan metode apa pun yang didukung."
 ],
 "Untrusted host": [
  null,
  "Host tidak tepercaya"
 ],
 "Host key is incorrect": [
  null,
  "Kunci host salah"
 ],
 "Internal error": [
  null,
  "Kesalahan internal"
 ],
 "Connection has timed out.": [
  null,
  "Koneksi timeout."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit tidak terpasang pada sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Tidak dapat meneruskan kredensial login"
 ],
 "Server has closed the connection.": [
  null,
  "Server telah menutup koneksi."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit tidak kompatibel dengan perangkat lunak di sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit tidak dapat menghubungi host yang diberikan."
 ],
 "Too much data": [
  null,
  "Terlalu banyak data"
 ],
 "Priority": [
  null,
  "Prioritas"
 ],
 "Description": [
  null,
  "Deskripsi"
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "edit": [
  null,
  "ubah"
 ],
 "None": [
  null,
  "Tidak ada"
 ],
 "Enabled": [
  null,
  "Diaktifkan"
 ],
 "Disabled": [
  null,
  "Dinonaktifkan"
 ],
 "Generated": [
  null,
  "Dihasilkan"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Start service": [
  null,
  "Mulai layanan"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Delete $0": [
  null,
  "Hapus $0"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Actions": [
  null,
  "Tindakan"
 ],
 "Options": [
  null,
  "Opsi"
 ],
 "Not available": [
  null,
  "Tidak tersedia"
 ],
 "Ignore": [
  null,
  "Abaikan"
 ],
 "Permanent": [
  null,
  "Permanen"
 ],
 "Preserve": [
  null,
  "Pertahankan"
 ],
 "Random": [
  null,
  "Acak"
 ],
 "Stable": [
  null,
  "Stabil"
 ],
 "Use $0": [
  null,
  "Gunakan $0"
 ],
 "Failed to save settings": [
  null,
  "Gagal menyimpan pengaturan"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Membuat $0 ini akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Create it": [
  null,
  "Buat itu"
 ],
 "Invalid prefix $0": [
  null,
  "Prefiks tidak valid $0"
 ],
 "Invalid metric $0": [
  null,
  "Metrik tidak valid $0"
 ],
 "Invalid address $0": [
  null,
  "Alamat tidak valid $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefiks atau netmask tidak valid $0"
 ],
 "Testing connection": [
  null,
  "Menguji koneksi"
 ],
 "Restoring connection": [
  null,
  "Memulihkan koneksi"
 ],
 "Troubleshoot…": [
  null,
  "Pemecahan masalah…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager tidak berjalan"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager tidak terinstal"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Perangkat jaringan dan grafik memerlukan NetworkManager"
 ],
 "Enable service": [
  null,
  "Aktifkan layanan"
 ],
 "Network interface '$0' not found": [
  null,
  "Antarmuka jaringan '$0' tidak ditemukan"
 ],
 "Return to overview page": [
  null,
  "Kembali ke halaman ringkasan"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Anda tidak diizinkan untuk memodifikasi firewall."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Tidak diizinkan untuk menonaktifkan firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Tidak diizinkan untuk mengaktifkan firewall"
 ],
 "Disable the firewall": [
  null,
  "Nonaktifkan firewall"
 ],
 "Enable the firewall": [
  null,
  "Aktifkan firewall"
 ],
 "Edit service $0": [
  null,
  "Edit layanan $0"
 ],
 "Remove service $0": [
  null,
  "Hapus layanan $0"
 ],
 "Included Services": [
  null,
  "Layanan yang Disertakan"
 ],
 "Additional port": [
  null,
  "Port tambahan"
 ],
 "Remove additional port": [
  null,
  "Hapus port tambahan"
 ],
 "Remove zone $0": [
  null,
  "Hapus zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Tambahkan layanan ke zona $0"
 ],
 "Add services": [
  null,
  "Tambah Layanan"
 ],
 "Service": [
  null,
  "Layanan"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 zona"
 ],
 "Interface": [
  null,
  "Antarmuka"
 ],
 "Allowed addresses": [
  null,
  "Alamat yang Diizinkan"
 ],
 "Entire subnet": [
  null,
  "Seluruh subnet"
 ],
 "There are no active services in this zone": [
  null,
  "Tidak ada layanan aktif di zona ini"
 ],
 "Filter services": [
  null,
  "Saring layanan"
 ],
 "Failed to edit service": [
  null,
  "Gagal mengedit layanan"
 ],
 "Failed to add port": [
  null,
  "Gagal menambahkan port"
 ],
 "Failed to add service": [
  null,
  "Gagal menambahkan layanan"
 ],
 "Unknown service name": [
  null,
  "Nama layanan tidak diketahui"
 ],
 "Invalid port number": [
  null,
  "Nomor port tidak valid"
 ],
 "Invalid range": [
  null,
  "Rentang tidak valid"
 ],
 "Range must be strictly ordered": [
  null,
  "Rentang harus diurutkan secara ketat"
 ],
 "Edit service": [
  null,
  "Edit layanan"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Edit layanan kustom di zona $0"
 ],
 "Add ports": [
  null,
  "Tambah Port"
 ],
 "Add ports to $0 zone": [
  null,
  "Tambahkan port ke zona $0"
 ],
 "Add services to $0 zone": [
  null,
  "Tambahkan layanan ke zona $0"
 ],
 "Custom ports": [
  null,
  "Port kustom"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Contoh: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Port, rentang, dan layanan yang dipisahkan koma diterima"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Contoh: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Jika dikosongkan, ID akan dibuat berdasarkan layanan port terkait dan nomor port"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Menambahkan port kustom akan memuat ulang firewalld. Pemuatan ulang akan menyebabkan hilangnya konfigurasi hanya-runtime!"
 ],
 "Failed to add zone": [
  null,
  "Gagal menambahkan zona"
 ],
 "Add zone": [
  null,
  "Tambah zona"
 ],
 "Trust level": [
  null,
  "Tingkat kepercayaan"
 ],
 "Sorted from least to most trusted": [
  null,
  "Diurutkan dari yang paling tidak tepercaya ke yang paling tepercaya"
 ],
 "Custom zones": [
  null,
  "Zona ubahan"
 ],
 "No description available": [
  null,
  "Tidak ada deskripsi yang tersedia"
 ],
 "Included services": [
  null,
  "Layanan yang disertakan"
 ],
 "The cockpit service is automatically included": [
  null,
  "Layanan cockpit disertakan secara otomatis"
 ],
 "Interfaces": [
  null,
  "Antarmuka"
 ],
 "Range": [
  null,
  "Rentang"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Alamat IP dengan prefiks rute. Pisahkan beberapa nilai dengan koma. Contoh: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Konfirmasi penghapusan $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Zona ini berisi layanan cockpit. Pastikan zona ini tidak berlaku untuk koneksi konsol web Anda saat ini."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Menghapus zona akan menghapus semua layanan di dalamnya."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Menghapus layanan Cockpit dapat menyebabkan konsol web menjadi tidak dapat dijangkau. Pastikan zona ini tidak berlaku untuk koneksi konsol web Anda saat ini."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Hapus layanan $0 dari zona $1"
 ],
 "Firewall is not available": [
  null,
  "Firewall tidak tersedia"
 ],
 "Please install the $0 package": [
  null,
  "Silakan instal paket $0"
 ],
 "Add a new zone": [
  null,
  "Tambahkan zona baru"
 ],
 "Add new zone": [
  null,
  "Tambahkan zona baru"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Permintaan masuk diblokir secara default. Permintaan keluar tidak diblokir."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID tidak boleh kosong"
 ],
 "Password can not be empty": [
  null,
  "Kata sandi tidak boleh kosong"
 ],
 "Failed to connect": [
  null,
  "Gagal terhubung"
 ],
 "Check your password.": [
  null,
  "Periksa kata sandi Anda."
 ],
 "Connect to hidden network": [
  null,
  "Hubungkan ke jaringan tersembunyi"
 ],
 "Connect to $0": [
  null,
  "Hubungkan ke $0"
 ],
 "Network name": [
  null,
  "Nama jaringan"
 ],
 "Security": [
  null,
  "Keamanan"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Pribadi"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Menghapus $0 akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Menyalakan $0 akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Switch on $0": [
  null,
  "Nyalakan $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Mematikan $0 akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Switch off $0": [
  null,
  "Matikan $0"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Team": [
  null,
  "Tim"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Bridge"
 ],
 "Unknown \"$0\"": [
  null,
  "Tidak diketahui \"$0\""
 ],
 "Carrier": [
  null,
  "Operator"
 ],
 "Yes": [
  null,
  "Ya"
 ],
 "No": [
  null,
  "Tidak"
 ],
 "Inactive": [
  null,
  "Tidak aktif"
 ],
 "Unknown configuration": [
  null,
  "Konfigurasi tidak diketahui"
 ],
 "Additional address $val": [
  null,
  "Alamat tambahan $val"
 ],
 "Address $val": [
  null,
  "Alamat $val"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS tambahan $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domain pencarian DNS tambahan $val"
 ],
 "DNS search domains $val": [
  null,
  "Domain pencarian DNS $val"
 ],
 "General": [
  null,
  "Umum"
 ],
 "Connect automatically": [
  null,
  "Sambungkan otomatis"
 ],
 "Automatic": [
  null,
  "Otomatis"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Pemantauan ARP"
 ],
 "Broken configuration": [
  null,
  "Konfigurasi rusak"
 ],
 "Team port": [
  null,
  "Port tim"
 ],
 "Spanning tree protocol": [
  null,
  "Protokol spanning tree"
 ],
 "Priority $priority": [
  null,
  "Prioritas $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Penundaan penerusan $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Waktu hello $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Usia pesan maksimum $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Biaya jalur $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Mode hairpin"
 ],
 "Bridge port": [
  null,
  "Port bridge"
 ],
 "Parent $parent": [
  null,
  "Induk $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Kata sandi jaringan tidak tersimpan. Harap lupakan dan hubungkan kembali ke jaringan ini."
 ],
 "Failed to connect to $0": [
  null,
  "Gagal terhubung ke $0"
 ],
 "secured": [
  null,
  "diamankan"
 ],
 "open": [
  null,
  "terbuka"
 ],
 "Last connected: $0": [
  null,
  "Terakhir terhubung: $0"
 ],
 "Signal strength": [
  null,
  "Kekuatan sinyal"
 ],
 "Not permitted to disconnect network": [
  null,
  "Tidak diizinkan untuk memutuskan jaringan"
 ],
 "Disconnect": [
  null,
  "Terputus"
 ],
 "Not permitted to connect to network": [
  null,
  "Tidak diizinkan untuk terhubung ke jaringan"
 ],
 "Forget": [
  null,
  "Lupakan"
 ],
 "$0 hidden network": [
  null,
  "$0 jaringan tersembunyi"
 ],
 "Filter": [
  null,
  "Filter"
 ],
 "Refresh": [
  null,
  "Segarkan"
 ],
 "Available networks": [
  null,
  "Jaringan tersedia"
 ],
 "Network": [
  null,
  "Jaringan"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Signal": [
  null,
  "Sinyal"
 ],
 "Rate": [
  null,
  "Laju"
 ],
 "Not permitted to configure network devices": [
  null,
  "Tidak diizinkan untuk mengonfigurasi perangkat jaringan"
 ],
 "Enable or disable the device": [
  null,
  "Aktifkan atau nonaktifkan perangkat"
 ],
 "This device cannot be managed here.": [
  null,
  "Perangkat ini tidak dapat dikelola di sini."
 ],
 "Connection will be lost": [
  null,
  "Koneksi akan hilang"
 ],
 "Keep connection": [
  null,
  "Pertahankan koneksi"
 ],
 "Invalid IP address: $0": [
  null,
  "Alamat IP tidak valid: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Alamat tujuan tidak valid: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Alamat gateway tidak valid: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Alamat DNS tidak valid: $0"
 ],
 "Preparing": [
  null,
  "Menyiapkan"
 ],
 "Configuring": [
  null,
  "Mengonfigurasi"
 ],
 "Authenticating": [
  null,
  "Autentikasi"
 ],
 "Configuring IP": [
  null,
  "Mengkonfigurasi IP"
 ],
 "Checking IP": [
  null,
  "Memeriksa IP"
 ],
 "Waiting": [
  null,
  "Menunggu"
 ],
 "Active": [
  null,
  "Aktif"
 ],
 "Deactivating": [
  null,
  "Menonaktifkan"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Tidak ada sinyal jaringan"
 ],
 "Part of $0": [
  null,
  "Bagian dari $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Mengubah pengaturan akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Change the settings": [
  null,
  "Mengubah pengaturan"
 ],
 "Add bridge": [
  null,
  "Tambah Bridge"
 ],
 "Edit bridge settings": [
  null,
  "Edit pengaturan jembatan"
 ],
 "Ports": [
  null,
  "Port"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protokol spanning tree (STP)"
 ],
 "STP priority": [
  null,
  "Prioritas STP"
 ],
 "STP forward delay": [
  null,
  "Penundaan penerusan STP"
 ],
 "STP hello time": [
  null,
  "Waktu hello STP"
 ],
 "STP maximum message age": [
  null,
  "Usia pesan maksimum STP"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Pencadangan Aktif"
 ],
 "Load balancing": [
  null,
  "Penyeimbangan beban"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Pasif"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "Add team": [
  null,
  "Tambah Tim"
 ],
 "Edit team settings": [
  null,
  "Edit pengaturan tim"
 ],
 "Runner": [
  null,
  "Pelari"
 ],
 "Balancer": [
  null,
  "Penyeimbang"
 ],
 "Primary": [
  null,
  "Primer"
 ],
 "Link watch": [
  null,
  "Pemantauan tautan aktif"
 ],
 "Link up delay": [
  null,
  "Penundaan tautan naik"
 ],
 "Link down delay": [
  null,
  "Penundaan penurunan tautan"
 ],
 "Ping interval": [
  null,
  "Interval ping"
 ],
 "Ping target": [
  null,
  "Target ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Otomatis (hanya DHCP)"
 ],
 "Link local": [
  null,
  "Link lokal"
 ],
 "Manual": [
  null,
  "Manual"
 ],
 "Shared": [
  null,
  "Dibagikan"
 ],
 "Prefix length or netmask": [
  null,
  "Panjang prefiks atau netmask"
 ],
 "Prefix length": [
  null,
  "Panjang prefiks"
 ],
 "IPv4 settings": [
  null,
  "Pengaturan IPv4"
 ],
 "IPv6 settings": [
  null,
  "Pengaturan IPv6"
 ],
 "Addresses": [
  null,
  "Alamat"
 ],
 "Select method": [
  null,
  "Pilih metode"
 ],
 "Add address": [
  null,
  "Tambahkan alamat"
 ],
 "Address": [
  null,
  "Alamat"
 ],
 "Remove item": [
  null,
  "Hapus item"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Tambahkan server DNS"
 ],
 "DNS search domains": [
  null,
  "Domain Pencarian DNS"
 ],
 "Add search domain": [
  null,
  "Tambahkan domain pencarian"
 ],
 "Search domain": [
  null,
  "Domain pencarian"
 ],
 "Routes": [
  null,
  "Rute"
 ],
 "Add route": [
  null,
  "Tambahkan rute"
 ],
 "Metric": [
  null,
  "Metrik"
 ],
 "Enter a valid MAC address": [
  null,
  "Masukkan alamat MAC yang valid"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 jaringan"
 ],
 "Add VPN": [
  null,
  "Tambahkan VPN"
 ],
 "Add bond": [
  null,
  "Tambah Bond"
 ],
 "Add VLAN": [
  null,
  "Tambahkan VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Edit aturan dan zona"
 ],
 "$0 active zone": [
  null,
  "$0 zona aktif"
 ],
 "Managed interfaces": [
  null,
  "Antarmuka terkelola"
 ],
 "IP address": [
  null,
  "Alamat IP"
 ],
 "Sending": [
  null,
  "Mengirim"
 ],
 "Receiving": [
  null,
  "Menerima"
 ],
 "Unmanaged interfaces": [
  null,
  "Antarmuka tidak dikelola"
 ],
 "Network logs": [
  null,
  "Log jaringan"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Alamat tidak diformat dengan benar"
 ],
 "Invalid IP address '$0'": [
  null,
  "Alamat IP tidak valid '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "paket wireguard-tools tidak terinstal"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Rekan #$0 memiliki titik akhir yang tidak valid. Harus ditentukan sebagai host:port, misalnya 1.2.3.4:51820, [2001:db8::1]:51820 atau example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Rekan #$0 memiliki port titik akhir yang tidak valid. Port harus berupa angka."
 ],
 "Listen port must be a number": [
  null,
  "Port dengar harus berupa angka"
 ],
 "Add WireGuard VPN": [
  null,
  "Tambahkan WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Edit WireGuard VPN"
 ],
 "Private key": [
  null,
  "Kunci pribadi"
 ],
 "Paste existing key": [
  null,
  "Tempel kunci yang ada"
 ],
 "Regenerate": [
  null,
  "Buat ulang"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Kunci publik akan dibuat ketika kunci pribadi yang valid dimasukkan"
 ],
 "Listen port": [
  null,
  "Port dengar"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Akan diatur ke \"Otomatis\""
 ],
 "IP addresses": [
  null,
  "Alamat IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Beberapa alamat dapat ditentukan menggunakan koma atau spasi sebagai pemisah."
 ],
 "Peers": [
  null,
  "Rekan"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Rekan adalah mesin lain yang terhubung dengan mesin ini. Kunci publik dari mesin lain akan dibagikan satu sama lain."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Titik akhir yang bertindak sebagai \"server\" perlu ditentukan sebagai host:port, jika tidak dapat dikosongkan."
 ],
 "Add peer": [
  null,
  "Tambahkan rekan"
 ],
 "Endpoint": [
  null,
  "Titik akhir"
 ],
 "Allowed IPs": [
  null,
  "IP yang diizinkan"
 ],
 "No peers added.": [
  null,
  "Tidak ada rekan yang ditambahkan."
 ],
 "Edit VLAN settings": [
  null,
  "Edit pengaturan VLAN"
 ],
 "Parent": [
  null,
  "Induk"
 ],
 "VLAN ID": [
  null,
  "ID VLAN"
 ],
 "Transmitting": [
  null,
  "Mengirim"
 ],
 "MTU must be a positive number": [
  null,
  "MTU harus berupa angka positif"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Set to": [
  null,
  "Atur menjadi"
 ],
 "Team port settings": [
  null,
  "Pengaturan port tim"
 ],
 "Sticky": [
  null,
  "Lengket"
 ],
 "LACP key": [
  null,
  "Kunci LACP"
 ],
 "Bridge port settings": [
  null,
  "Pengaturan Port Bridge"
 ],
 "Path cost": [
  null,
  "Biaya jalur"
 ],
 "Hair pin mode": [
  null,
  "Mode hair pin"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Penyeimbangan beban transmisi adaptif"
 ],
 "Adaptive load balancing": [
  null,
  "Penyeimbangan beban adaptif"
 ],
 "MII (recommended)": [
  null,
  "MII (disarankan)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Edit pengaturan bond"
 ],
 "Network bond": [
  null,
  "Bond jaringan"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Ikatan jaringan menggabungkan beberapa antarmuka jaringan menjadi satu antarmuka logis dengan throughput lebih tinggi atau redundancy."
 ],
 "Link monitoring": [
  null,
  "Pemantauan tautan"
 ],
 "Monitoring interval": [
  null,
  "Interval pemantauan"
 ],
 "Monitoring targets": [
  null,
  "Target pemantauan"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Menghapus $0 akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "Remove $0": [
  null,
  "Hapus $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Menambahkan $0 akan memutus koneksi ke server dan membuat antarmuka administrasi tidak tersedia."
 ],
 "No interfaces available": [
  null,
  "Tidak ada antarmuka yang tersedia"
 ],
 "Add member": [
  null,
  "Tambahkan anggota"
 ],
 "Interface members": [
  null,
  "Anggota antarmuka"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsol Web untuk server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit adalah manajer server yang memudahkan administrasi server Linux Anda melalui browser web. Berpindah antara terminal dan alat web tidak menjadi masalah. Layanan yang dijalankan melalui Cockpit dapat dihentikan melalui terminal. Demikian pula, jika terjadi kesalahan di terminal, hal itu dapat dilihat di antarmuka jurnal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit sempurna untuk sysadmin baru, memungkinkan mereka melakukan tugas sederhana dengan mudah seperti administrasi penyimpanan, memeriksa jurnal, serta memulai dan menghentikan layanan. Anda dapat memantau dan mengelola beberapa server sekaligus. Cukup tambahkan dengan satu klik, dan mesin Anda akan saling menjaga."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Setelah Cockpit diinstal, aktifkan dengan \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurasi Cockpit untuk NetworkManager dan Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Alat ini mengelola jaringan seperti bond, bridge, team, VLAN, dan firewall menggunakan NetworkManager dan Firewalld. NetworkManager tidak kompatibel dengan systemd-networkd bawaan Ubuntu dan skrip ifupdown milik Debian."
 ],
 "Manage storage": [
  null,
  "Kelola penyimpanan"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Alat ini mengelola penyimpanan lokal seperti sistem berkas, grup volume LVM2, dan mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kumpulkan dan kemas data diagnostik serta dukungan"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Alat ini menghasilkan arsip berisi informasi konfigurasi dan diagnostik dari sistem yang sedang berjalan. Arsip dapat disimpan secara lokal atau pusat untuk pencatatan atau pelacakan, atau dikirim ke tim dukungan teknis, pengembang, atau administrator sistem untuk membantu dalam analisis kesalahan dan debugging teknis."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfigurasi dan pemecahan masalah Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Alat ini mengonfigurasi kebijakan SELinux dan membantu memahami serta menyelesaikan pelanggaran kebijakan."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kumpulkan dump crash kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Alat ini mengonfigurasi sistem untuk menulis dump crash kernel. Ini mendukung target dump \"local\" (disk), \"ssh\", dan \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasi dengan Konsol Web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentikasi diperlukan untuk melakukan tugas berprivileg dengan Konsol Web Cockpit"
 ]
});
