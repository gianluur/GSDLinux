cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "eu",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
