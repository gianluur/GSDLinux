cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Accounts": [
  null,
  "Conturi"
 ],
 "user": [
  null,
  "utilizator"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "parolă"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nume-utilizator"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "acces"
 ],
 "roles": [
  null,
  "roluri"
 ],
 "keys": [
  null,
  "chei"
 ],
 "Managing user accounts": [
  null,
  "Gestionarea conturilor de utilizator"
 ]
});
