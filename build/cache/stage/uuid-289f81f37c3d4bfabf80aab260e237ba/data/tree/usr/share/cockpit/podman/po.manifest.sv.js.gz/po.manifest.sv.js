cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-behållare"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "behållare"
 ],
 "image": [
  null,
  "avbild"
 ]
});
