cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit filer"
 ],
 "Home": [
  null,
  "Hem"
 ],
 "Unable to create bookmark directory": [
  null,
  "Kan inte skapa en bokmärkeskatalog"
 ],
 "Unable to save bookmark file": [
  null,
  "Kan inte spara bokmärkesfilen"
 ],
 "Remove from bookmarks": [
  null,
  "Ta bort från bokmärken"
 ],
 "Add to bookmarks": [
  null,
  "Lägg till i bokmärken"
 ],
 "Bookmarks": [
  null,
  "Bokmärken"
 ],
 "Bookmarked": [
  null,
  "Bokmärkt"
 ],
 "Not bookmarked": [
  null,
  "Inte bokmärkt"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Edit path": [
  null,
  "Redigera sökväg"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Largest size": [
  null,
  "Störst storlek"
 ],
 "Smallest size": [
  null,
  "Minsta storlek"
 ],
 "Modified": [
  null,
  "Modifierad"
 ],
 "First modified": [
  null,
  "Först modifierad"
 ],
 "Last modified": [
  null,
  "Senast modifierad"
 ],
 "Owner": [
  null,
  "Ägare"
 ],
 "Owner ascending": [
  null,
  "Ägare ökande"
 ],
 "Owner descending": [
  null,
  "Ägare minskande"
 ],
 "Permissions": [
  null,
  "Behörigheter"
 ],
 "Most permissive": [
  null,
  "Mest tillåtande"
 ],
 "Least permissive": [
  null,
  "Minst tillåtande"
 ],
 "Show keyboard shortcuts": [
  null,
  "Visa tangentbordsgenvägar"
 ],
 "Filter directory": [
  null,
  "Filtrera katalog"
 ],
 "Display as a list": [
  null,
  "Visa som en lista"
 ],
 "Display as a grid": [
  null,
  "Visa som ett rutnät"
 ],
 "Sort": [
  null,
  "Sortera"
 ],
 "Hide hidden items": [
  null,
  "Dölj dolda objekt"
 ],
 "Show hidden items": [
  null,
  "Visa dolda objekt"
 ],
 "$0 files": [
  null,
  "$0 filer"
 ],
 "Uploaded as $0, $1": [
  null,
  "Uppladdad som $0,$1"
 ],
 "Replace file $0?": [
  null,
  "Ersätt fil $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "En fil med samma namn finns redan i \"$0\". Om du ersätter den kommer dess innehåll att skrivas över."
 ],
 "New file": [
  null,
  "Ny fil"
 ],
 "Original file on server": [
  null,
  "Original fil på server"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Tillämpa den här åtgärden på alla konfliktfiler"
 ],
 "Replace": [
  null,
  "Ersätt"
 ],
 "Keep original": [
  null,
  "Behåll original"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Upload error": [
  null,
  "Uppladdningsfel"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Det gick inte att flytta uppladdad fil till slutdestinationen"
 ],
 "Cancelled": [
  null,
  "Avbruten"
 ],
 "Cancelled upload of $0": [
  null,
  "Avbruten uppladdning av $0"
 ],
 "File uploaded": [
  null,
  "Fil uppladdad"
 ],
 "Files uploaded": [
  null,
  "Filer uppladdade"
 ],
 "Change permissions": [
  null,
  "Ändra behörigheter"
 ],
 "Uploads": [
  null,
  "Uppladdningar"
 ],
 "Cancel upload of $0": [
  null,
  "Avbryt uppladdning av $0"
 ],
 "Upload $0% completed": [
  null,
  "Uppladdning $0% slutförd"
 ],
 "Upload": [
  null,
  "Ladda upp"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Execute-only": [
  null,
  "Exekvering-endast"
 ],
 "Write-only": [
  null,
  "Skriv-endast"
 ],
 "Write and execute": [
  null,
  "Skriv och exekvera"
 ],
 "Read-only": [
  null,
  "Läs-endast"
 ],
 "Read and execute": [
  null,
  "Läs och exekvera"
 ],
 "Read and write": [
  null,
  "Läs och skriv"
 ],
 "Read, write, and execute": [
  null,
  "Läs, skriv, och exekvera"
 ],
 "Block device": [
  null,
  "Blockenhet"
 ],
 "Character device": [
  null,
  "Teckenenhet"
 ],
 "Directory": [
  null,
  "Katalog"
 ],
 "Named pipe": [
  null,
  "Namngivet rör"
 ],
 "Symbolic link": [
  null,
  "Symbolisk länk"
 ],
 "Regular file": [
  null,
  "Vanlig fil"
 ],
 "Socket": [
  null,
  "Uttag"
 ],
 "Name cannot be empty": [
  null,
  "Namn kan inte vara tomt"
 ],
 "Name too long": [
  null,
  "Namn för långt"
 ],
 "Name cannot include a /": [
  null,
  "Namn kan inte inkludera ett /"
 ],
 "Filename is the same as original name": [
  null,
  "Filnamn är samma som originalnamn"
 ],
 "Directory with the same name exists": [
  null,
  "Katalog med samma namn existerar"
 ],
 "File exists": [
  null,
  "Fil existerar"
 ],
 "Pasting failed": [
  null,
  "Inklistring misslyckades"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" existerar, skriver inte över med klistra in."
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Create directory": [
  null,
  "Skapa katalog"
 ],
 "Create file": [
  null,
  "Skapa fil"
 ],
 "Edit permissions": [
  null,
  "Redigera behörigheter"
 ],
 "Open in terminal": [
  null,
  "Öppna i terminal"
 ],
 "Open text file": [
  null,
  "Öppna en textfil"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Download": [
  null,
  "Hämta"
 ],
 "Create link": [
  null,
  "Skapa länk"
 ],
 "Drop files to upload": [
  null,
  "Släpp filer för att ladda upp"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Det går inte att släppa filer, en annan uppladdning pågår redan"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Go up a directory": [
  null,
  "Gå upp en katalog"
 ],
 "Go back": [
  null,
  "Gå tillbaka"
 ],
 "Go forward": [
  null,
  "Gå framåt"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktivera valt objekt, gå in i katalog"
 ],
 "Rename selected file or directory": [
  null,
  "Byt namn på vald fil eller katalog"
 ],
 "Create new directory": [
  null,
  "Skapa ny katalog"
 ],
 "Copy selected file or directory": [
  null,
  "Kopiera vald fil eller katalog"
 ],
 "Paste file or directory": [
  null,
  "Klistra in fil eller katalog"
 ],
 "Select all": [
  null,
  "Välj alla"
 ],
 "Save current file": [
  null,
  "Spara nuvarande fil"
 ],
 "Close editor": [
  null,
  "Stäng redigerare"
 ],
 "Keyboard shortcuts": [
  null,
  "Tangentbordsgenvägar"
 ],
 "Navigation": [
  null,
  "Navigering"
 ],
 "Editing": [
  null,
  "Redigerar"
 ],
 "Editor": [
  null,
  "Redigerare"
 ],
 "Force delete $0 items": [
  null,
  "Tvinga radering $0 objekt"
 ],
 "Delete $0 items?": [
  null,
  "Radera $0 objekt?"
 ],
 "Force delete file $0?": [
  null,
  "Tvinga radering av fil $0?"
 ],
 "Delete file $0?": [
  null,
  "Radera fil $0?"
 ],
 "Force delete link $0?": [
  null,
  "Tvinga radering av länk $0?"
 ],
 "Delete link $0?": [
  null,
  "Radera länk $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Tvinga radering av katalog $0?"
 ],
 "Delete directory $0?": [
  null,
  "Radera katalog $0?"
 ],
 "Force delete $0": [
  null,
  "Tvinga radering $0"
 ],
 "Delete $0?": [
  null,
  "Radera $0?"
 ],
 "No access": [
  null,
  "Ingen åtkomst"
 ],
 "Missing type": [
  null,
  "Saknar typ"
 ],
 "Collapse": [
  null,
  "Fäll ihop"
 ],
 "Show all files": [
  null,
  "Visa alla filer"
 ],
 "$0 permissions": [
  null,
  "$0 behörigheter"
 ],
 "Permissions for $0 files": [
  null,
  "Behörigheter för $0 filer"
 ],
 "Ownership": [
  null,
  "Ägarskap"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Access": [
  null,
  "Åtkomst"
 ],
 "Owner access": [
  null,
  "Ägare tillgång"
 ],
 "Group access": [
  null,
  "Gruppåtkomst"
 ],
 "Others access": [
  null,
  "Andra tillgång"
 ],
 "Security context": [
  null,
  "Säkerhetskontext"
 ],
 "Set executable as program": [
  null,
  "Ställ in körbar fil som program"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change permissions for enclosed files": [
  null,
  "Ändra behörigheter för bifogade filer"
 ],
 "(original owner)": [
  null,
  "(original ägare)"
 ],
 "keep original owners": [
  null,
  "behåll ursprungliga ägare"
 ],
 "Paste as owner": [
  null,
  "Klistra in som ägare"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Filer som klistras in har en annan ägare. Som standard kommer äganderätten att ändras för att matcha målkatalogen."
 ],
 "New owner": [
  null,
  "Ny ägare"
 ],
 "Overwrite": [
  null,
  "Skriv över"
 ],
 "New filename": [
  null,
  "Nytt filnamn"
 ],
 "New name": [
  null,
  "Nytt namn"
 ],
 "Rename $0?": [
  null,
  "Byt namn på $0?"
 ],
 "link to $0": [
  null,
  "länk till $0"
 ],
 "Create link to $0": [
  null,
  "Skapa länk till $0"
 ],
 "Target": [
  null,
  "Mål"
 ],
 "Symlink name": [
  null,
  "Namn på symbolisk länk"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolut vs. Relativ"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Absoluta symboliska länkar är idealiska när du hänvisar till filer eller kataloger som inte kan flyttas, till exempel systemfiler."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Relativa symboliska länkar är användbara när både en symbolisk länk och mål kan flyttas samtidigt, till exempel när du byter namn på eller flyttar en överordnad katalog."
 ],
 "Absolute": [
  null,
  "Absolut"
 ],
 "Relative": [
  null,
  "Relativ"
 ],
 "The file has been removed on disk": [
  null,
  "Filen har tagits bort på disken"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Den befintliga filen ändrades oväntat"
 ],
 "Edit $0": [
  null,
  "Redigera $0"
 ],
 "View $0": [
  null,
  "Visa $0"
 ],
 "The file has changed on disk": [
  null,
  "Filen har ändrats på disken"
 ],
 "Reload": [
  null,
  "Ladda om"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save changes?": [
  null,
  "Spara ändringar?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Filen raderades efter att den öppnades, om du sparar kommer den att återskapas."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Filen har ändrats på disken mellan när den öppnades och nu"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 har osparade ändringar och som kommer att gå förlorade för alltid om de kasseras."
 ],
 "Discard": [
  null,
  "Kassera"
 ],
 "File name": [
  null,
  "Filnamn"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Cannot create file in current directory": [
  null,
  "Kan inte skapa fil i nuvarande katalog"
 ],
 "Permission denied": [
  null,
  "Åtkomst nekas"
 ],
 "Directory name cannot be empty": [
  null,
  "Katalognamn kan inte vara tomt"
 ],
 "Directory name too long": [
  null,
  "Katalognamn för långt"
 ],
 "Directory name cannot include a /": [
  null,
  "Katalognamn kan inte inkludera /"
 ],
 "Directory name": [
  null,
  "Katalognamn"
 ],
 "Directory owner": [
  null,
  "Katalogägare"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "Clear filter": [
  null,
  "Rensa filter"
 ],
 "Directory is empty": [
  null,
  "Katalog är tom"
 ],
 "$0 item is hidden": [
  null,
  "($0 objekt är dolt)",
  "($0 objekt är dolda)"
 ],
 "Folder": [
  null,
  "Mapp"
 ],
 "File": [
  null,
  "Fil"
 ],
 "Others": [
  null,
  "Övriga"
 ],
 "$0 files selected": [
  null,
  "$0 filer valda"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Katalog innehåller $0 kataloger, $1 filer"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Katalog innehåller $0 kataloger, $1 filer, $2 dolda"
 ],
 "User": [
  null,
  "Användare"
 ]
});
