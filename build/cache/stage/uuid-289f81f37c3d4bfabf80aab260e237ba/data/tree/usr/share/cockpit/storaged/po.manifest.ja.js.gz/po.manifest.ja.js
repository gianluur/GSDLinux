cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "ファイルシステム"
 ],
 "partition": [
  null,
  "パーティション"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "volume": [
  null,
  "ボリューム"
 ],
 "disk": [
  null,
  "ディスク"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "ドライブ"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "encryption": [
  null,
  "暗号化"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "パーティション管理"
 ],
 "Managing NFS mounts": [
  null,
  "NFS マウントの管理"
 ],
 "Managing RAIDs": [
  null,
  "RAID の管理"
 ],
 "Managing LVMs": [
  null,
  "LVM の管理"
 ],
 "Managing physical drives": [
  null,
  "物理ドライブの管理"
 ],
 "Managing VDOs": [
  null,
  "VDO の管理"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 暗号化の使用"
 ],
 "Using Tang server": [
  null,
  "Tang サーバーの使用"
 ]
});
