cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "מערכת קבצים"
 ],
 "partition": [
  null,
  "מחיצה"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "כרך"
 ],
 "disk": [
  null,
  "כונן"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "כונן"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "הצפנה"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "ניהול מחיצות"
 ],
 "Managing NFS mounts": [
  null,
  "ניהול עיגוני NFS"
 ],
 "Managing RAIDs": [
  null,
  "ניהול RAIDים"
 ],
 "Managing LVMs": [
  null,
  "ניהול LVMים"
 ],
 "Managing physical drives": [
  null,
  "ניהול כוננים פיזיים"
 ],
 "Managing VDOs": [
  null,
  "ניהול VDOים"
 ],
 "Using LUKS encryption": [
  null,
  "באמצעות הצפנת LUKS"
 ],
 "Using Tang server": [
  null,
  "באמצעות שרת Tang"
 ]
});
