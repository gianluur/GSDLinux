cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 のインストール"
 ],
 "$0 installer": [
  null,
  "$0 のインストーラー"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 は論理パーティションを含む MBR 拡張パーティションです。全ての論理パーティションを削除すると拡張パーティションも自動的に削除されます。"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 が必要ですが、 $1 のみ利用可能です。"
 ],
 "$0 warning": [
  null,
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 は削除されます"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "ファイルシステム '$0' は、暗号化ブロックデバイス上に置くことができません"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' は、'$1' にフォーマットされたデバイス上でなければなりません"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "システム全体の変更を行うための管理者権限を持つ標準ユーザーアカウント。"
 ],
 "About": [
  null,
  "About"
 ],
 "Account": [
  null,
  "アカウント"
 ],
 "Actions": [
  null,
  "アクション"
 ],
 "Add another server...": [
  null,
  "他のサーバーの追加..."
 ],
 "Add mount": [
  null,
  "マウントの追加"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "ストレージエディターで行った変更は全て即座に反映されます。"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "すべてのデバイスは、このパスフレーズにてロック解除されています"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web UI"
 ],
 "Anaconda project page": [
  null,
  "Anacondaプロジェクトページ"
 ],
 "Apply mount point assignment and install": [
  null,
  "マウントポイントの割り当てを適用してインストールする"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "パーティションをマウントポイントに割り当てます。カスタムレイアウトを事前設定している場合に便利です。"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "タイムサーバーを利用して、自動で日付と時間を設定する"
 ],
 "Automatically set timezone": [
  null,
  "タイムゾーンの自動設定"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "利用可能な空き領域: $0。 インストールに必要な領域: $1。"
 ],
 "Back": [
  null,
  "戻る"
 ],
 "Base environment": [
  null,
  "ベース環境"
 ],
 "Brief description of the issue": [
  null,
  "この問題の簡単な説明"
 ],
 "Bug report details": [
  null,
  "バグ レポートの詳細"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API キー"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "このソフトウェアの使用を継続することにより、お客様は、プレリリースのソフトウェアに関連するリスクを理解および承諾し、これをテストおよび開発目的にのみ使用して、このソフトウェアを強化するためにバグや問題を率先して報告するものとします。"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change destination": [
  null,
  "インストール先を変更"
 ],
 "Change hostname": [
  null,
  "ホスト名の変更"
 ],
 "Change partition layout": [
  null,
  "インストール先を変更"
 ],
 "Change system keyboard layout": [
  null,
  "システムのキーボードレイアウトを変更"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "ここで行う変更はシステムに直ちに影響を及ぼします。操作を'元に戻す'ことはできません。"
 ],
 "Checking storage configuration": [
  null,
  "ストレージ設定をチェック中"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "'Next' を再度押し、警告を無視して実行する。"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Close storage editor": [
  null,
  "ストレージエディターを閉じる"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit ストレージが暗号化デバイス解除用のパスフレーズを提示しませんてした。"
 ],
 "Completed": [
  null,
  "完了しました"
 ],
 "Configure NTP servers": [
  null,
  "NTP サーバーの設定"
 ],
 "Configure custom NTP servers": [
  null,
  "カスタム NTP サーバーの設定"
 ],
 "Configure storage": [
  null,
  "ストレージの設定"
 ],
 "Configure storage again": [
  null,
  "ストレージを再度設定"
 ],
 "Confirm passphrase": [
  null,
  "パスフレーズの確認"
 ],
 "Continue": [
  null,
  "続行"
 ],
 "Continue installation": [
  null,
  "インストールを続行する"
 ],
 "Continue with installation": [
  null,
  "インストールを続行する"
 ],
 "Create Account": [
  null,
  "アカウントを作成"
 ],
 "Create account": [
  null,
  "アカウントを作成"
 ],
 "Currently installed: $0": [
  null,
  "インストール済み: $0"
 ],
 "Custom": [
  null,
  "カスタム"
 ],
 "Date": [
  null,
  ""
 ],
 "Date and time": [
  null,
  "日付と時刻"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  ""
 ],
 "Description": [
  null,
  "説明"
 ],
 "Destination": [
  null,
  "インストール先"
 ],
 "Destination is encrypted": [
  null,
  "インストール先は暗号化されています"
 ],
 "Detected valid storage layout:": [
  null,
  "有効なストレージ構成が見つかりました:"
 ],
 "Device": [
  null,
  "デバイス"
 ],
 "Duplicate device.": [
  null,
  "重複されたデバイスです。"
 ],
 "Duplicate mount point.": [
  null,
  "重複されたマウントポイントです。"
 ],
 "Enable root account": [
  null,
  "rootアカウントを有効化"
 ],
 "Encrypt my data": [
  null,
  "データを暗号化する"
 ],
 "Encrypted": [
  null,
  "暗号化済み"
 ],
 "Encryption": [
  null,
  "暗号化"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Environment": [
  null,
  "環境"
 ],
 "Erase data and install": [
  null,
  "データを消去してインストールします"
 ],
 "Error details": [
  null,
  "エラーの詳細"
 ],
 "Exit to live desktop": [
  null,
  "ライブデスクトップに戻る"
 ],
 "Extended partition": [
  null,
  "拡張パーティション"
 ],
 "Failed to report issue": [
  null,
  "Issueの報告に失敗しました"
 ],
 "Failed to save layouts": [
  null,
  "レイアウトの保存に失敗しました"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux は最低でも $0 のディスク領域を必要とします。"
 ],
 "Finalization": [
  null,
  "終了処理"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "最終処理中: システム構成が完了しました。 インストールの完了には少し時間がかかる場合があります。"
 ],
 "Find layout": [
  null,
  "レイアウトの追加"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "セキュリティのために、Root アカウントを直接使うことを避けてください。代わりに、システムの管理にローカルアカウントを使用してください。"
 ],
 "Full name": [
  null,
  "フルネーム"
 ],
 "Full name cannot contain colon characters": [
  null,
  "フルネームにはコロン ':' を使用できません"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "確認済みパスワードを非表示にする"
 ],
 "Hide passphrase": [
  null,
  "パスフレーズを非表示にする"
 ],
 "Hide password": [
  null,
  "パスワードを非表示にする"
 ],
 "Hostname": [
  null,
  "ホスト名"
 ],
 "How would you like to install?": [
  null,
  "どのようにインストールしますか？"
 ],
 "I understand that some existing data will be erased": [
  null,
  "既存のデータが一部削除されることを理解しました"
 ],
 "I understand that some partitions will be modified": [
  null,
  "一部のパーティションが変更されることを理解しました"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "空白にすると、ホストネームはネットワーク情報によって設定されます。"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "パーティション構成をする場合は以下が必要になります:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "リスクを理解または承諾しない場合は、このプログラムを終了してください。"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "進行中"
 ],
 "Initializing...": [
  null,
  "初期化中..."
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Installation failed": [
  null,
  "インストールに失敗しました"
 ],
 "Installation method": [
  null,
  "インストール方法"
 ],
 "Installation of the system failed": [
  null,
  "システムのインストールに失敗しました"
 ],
 "Installation of the system failed: $0": [
  null,
  "システムのインストールに失敗しました: $0"
 ],
 "Installation type": [
  null,
  "インストールタイプ"
 ],
 "Installing": [
  null,
  "インストール中"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  "無効なホスト名です"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "別の OS とデュアルブートできるように、現在のディスクレイアウトを維持し、利用可能な領域を使用します。"
 ],
 "Keyboard": [
  null,
  "キーボード"
 ],
 "Keyboard layout during boot": [
  null,
  "起動時のキーボードレイアウト"
 ],
 "Language": [
  null,
  "言語"
 ],
 "Launch storage editor": [
  null,
  "ストレージエディターを起動"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "場所"
 ],
 "Locked devices": [
  null,
  "ロックされたデバイス"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "手動のディスク構成"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "手動のディスク構成: マウントポイントの割り当て"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "May need more free space": [
  null,
  "より多くの空き容量が必要かもしれません"
 ],
 "Medium": [
  null,
  "まあまあ"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "親デバイスと子デバイスの再フォーマットの選択が一致していません。"
 ],
 "Mount point": [
  null,
  "マウントポイント"
 ],
 "Mount point assignment": [
  null,
  "マウントポイントの割り当て"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "$0文字以上である必要があります"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP サーバー"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "ネットワーク"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "ネットワークが利用できません。 問題を報告するには、上のバーのメニューでネットワークを構成します。"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "ネットワークが利用できません。 問題を報告するには、ネットワークを設定してください。"
 ],
 "Next": [
  null,
  "次へ"
 ],
 "No devices": [
  null,
  "デバイスがありません"
 ],
 "No disks available": [
  null,
  "利用可能なディスクがありません"
 ],
 "No disks selected": [
  null,
  "ディスクが選択されていません"
 ],
 "No layouts selected yet": [
  null,
  "レイアウトが選択されていません"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "十分な空き領域がありません"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "選択したディスクには十分な空き領域がありません。"
 ],
 "Not enough space on selected disks.": [
  null,
  "選択したディスクには十分な空き領域がありません。"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "注記: これは、開発およびテストのみを目的としたプレリリースのソフトウェアです。このソフトウェアは、重要な作業や実稼働環境では使用しないでください。"
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "オペレーティングシステム"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other keyboards": [
  null,
  "他のキーボード"
 ],
 "Partitions (advanced)": [
  null,
  "パーティション (上級者向け)"
 ],
 "Passphrase": [
  null,
  "パスフレーズ"
 ],
 "Passphrase did not match any locked device": [
  null,
  "パスフレーズがロックされたデバイスのどれとも一致しませんでした"
 ],
 "Passphrases must match": [
  null,
  "パスワードは一致する必要があります"
 ],
 "Pending": [
  null,
  "保留中"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "ログファイル $0 をIssueに添付してください。"
 ],
 "Please select at least one disk to continue": [
  null,
  "続行するには少なくともディスクを 1 つ選択してください"
 ],
 "Pool": [
  null,
  "プール"
 ],
 "Powered by Anaconda": [
  null,
  "Powered by Anaconda"
 ],
 "Pre-release": [
  null,
  "プレリリース"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "インストールを継続"
 ],
 "Quit": [
  null,
  "終了"
 ],
 "Quit installer?": [
  null,
  "インストーラーを終了しますか？"
 ],
 "Reading information about the OS failed.": [
  null,
  "OS に関する情報の読み取りに失敗しました。"
 ],
 "Reading information about the computer failed.": [
  null,
  "コンピュータに関する情報の読み取りに失敗しました。"
 ],
 "Reading installer configuration failed.": [
  null,
  "インストーラーの設定の読み込みに失敗しました。"
 ],
 "Reading installer version information failed.": [
  null,
  "インストーラーのバージョン情報の読み取りに失敗しました。"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Reboot system?": [
  null,
  "システムを再起動しますか？"
 ],
 "Reclaim space": [
  null,
  "領域の再利用"
 ],
 "Reclaim space (required)": [
  null,
  "領域の再利用 (必須)"
 ],
 "Recommended": [
  null,
  "推奨"
 ],
 "Recommended partitions:": [
  null,
  "推奨されるパーティション:"
 ],
 "Reformat": [
  null,
  "再フォーマット"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora を再インストールする"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "既存のオペレーティングシステムを含む、選択したデバイス上のすべてのパーティションを削除します。"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "インストール用の領域を解放するために、既存のファイルシステムを削除・リサイズしてください。"
 ],
 "Remove server": [
  null,
  "サーバーの削除"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "ファイルシステムの削除は中に含まれるデータを全て完全に削除します。パーティションのリサイズは未使用領域を解放できますが、リスクを伴います。領域を再利用する前に、重要なデータは必ずバックアップしてください。"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  "Issueを報告する"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Issueを報告する"
 ],
 "Reporting issue...": [
  null,
  "Issueを報告中..."
 ],
 "Required": [
  null,
  "必要です"
 ],
 "Requirements": [
  null,
  "必要条件"
 ],
 "Rescan devices": [
  null,
  "デバイスの再スキャン"
 ],
 "Rescanning of the disks failed.": [
  null,
  "ディスクの再スキャンに失敗しました。"
 ],
 "Resize": [
  null,
  "サイズの変更"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "インストールに戻る"
 ],
 "Return to storage editor": [
  null,
  "ストレージエディターに戻る"
 ],
 "Review and install": [
  null,
  "確認とインストール"
 ],
 "Root account is enabled": [
  null,
  "root アカウントは有効です"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "root アカウントが有効ですが、ユーザーアカウントが設定されていません"
 ],
 "Root password has been set.": [
  null,
  "ルートパスワードが設定されました。"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "携帯電話でQRコードを読み取るか、こちらをご覧ください:"
 ],
 "Search for a language": [
  null,
  "言語の検索"
 ],
 "Search for additional software": [
  null,
  "追加のソフトウェアを検索"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "ディスクベースの暗号化でデータを保護します。新規パーティションにのみ適用されます"
 ],
 "Select": [
  null,
  "選択"
 ],
 "Select a device": [
  null,
  "デバイスを選択する"
 ],
 "Select destination": [
  null,
  "インストール先を選択"
 ],
 "Select region": [
  null,
  "地域の選択"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "選択したデバイスのフォーマット '$0' は再フォーマットできません。"
 ],
 "Send us feedback on your installation": [
  null,
  "インストールに関するフィードバックをお寄せください"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Share disk with other operating systems": [
  null,
  "他のオペレーティングシステムとディスクを共有"
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Show AM/PM": [
  null,
  "AM/PM を表示"
 ],
 "Show confirmed password": [
  null,
  "パスワードの確認を表示する"
 ],
 "Show passphrase": [
  null,
  "パスフレーズを表示する"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Size": [
  null,
  ""
 ],
 "Software installation": [
  null,
  "ソフトウェアのインストール"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "ソフトウェアのインストール: ストレージの構成が完了しました。 ソフトウェアがデバイスにインストールされています。"
 ],
 "Software selection": [
  null,
  "ソフトウェアの選択"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "いくつかのパーティションが見つかりません: $0"
 ],
 "Space": [
  null,
  "領域"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Storage configuration": [
  null,
  "ストレージの設定"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "ストレージの構成: ストレージは現在構成中です。"
 ],
 "Storage editor": [
  null,
  "ストレージエディター"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "ストレージは「ストレージの変更」の設定に基づいています。"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage requirements not met": [
  null,
  "ストレージ要件が満たされていません"
 ],
 "Strong": [
  null,
  "強固"
 ],
 "Successfully installed": [
  null,
  "インストールが成功しました"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 の解除に成功しました。"
 ],
 "Suggested keyboards": [
  null,
  "提案されたキーボード"
 ],
 "Suggested languages": [
  null,
  "提案された言語"
 ],
 "System": [
  null,
  "システム"
 ],
 "System configuration": [
  null,
  "システム設定"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "システムの構成: ソフトウェアのインストールが完了しました。 現在システムを構成中です。"
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "重大なエラーが発生したため、インストーラーは続行できません。"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "重大なエラーが発生したため、インストーラーは続行できません: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "入力した パスフレーズに ASCII 以外の文字が含まれています。入力する際、キーボードレイアウトの切り替えができない場合があります。"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "ストレージエディターではパーティションのリサイズ、削除、作成が可能です。LVM の設定なども可能です。これは高度なユーティリティであり、通常のインストールで使用することは想定されていません。"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This is unstable, pre-release software": [
  null,
  "これは、プレリリースの不安定なソフトウェアです"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "このレイアウトは起動時にシステムのロック解除で使用されます"
 ],
 "This may take a moment": [
  null,
  "これには少し時間がかかる場合があります"
 ],
 "This will take a few moments": [
  null,
  "これには少し時間がかかります"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Timezone": [
  null,
  "タイムゾーン"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "$0の使用を開始するには、システムを再起動します。"
 ],
 "To continue, select the devices to install to.": [
  null,
  "続行するには、インストール先のデバイスを選択します。"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "このオプションを使用するには、既存のパーティションをリサイズ・削除して、少なくとも $0 の容量を解放してください。"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0 の削除を予約できません"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0 のリサイズを予約できません"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Unlock encrypted devices": [
  null,
  "暗号化されたデバイスのロック解除を行います"
 ],
 "Use configured storage": [
  null,
  "構成したストレージを使用する"
 ],
 "Use entire disk": [
  null,
  "ディスク全体を使用"
 ],
 "Use free space": [
  null,
  "空き領域を使用する"
 ],
 "User creation": [
  null,
  "ユーザー作成"
 ],
 "User name": [
  null,
  "ユーザー名"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "ユーザー名は次の文字のみを使用できます: a-z の文字、0-9 の数字、ダッシュ $0、ピリオド $1、アンダースコア $2"
 ],
 "User name must not be a reserved word": [
  null,
  "ユーザ名は指定された文字のみを使用してください"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "ユーザー名は 33 文字未満にしてください"
 ],
 "Weak": [
  null,
  "弱い"
 ],
 "Welcome": [
  null,
  "ようこそ"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "ようこそ。今すぐ $0 をインストールしましょう。"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker で暗号化された Windows パーティションはリサイズできません"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "ここでインストールに十分な領域を確保して、あとはインストーラーに任せることもできますし、手動でパーティションを構成することもできます。"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "進行状況は保存されません。"
 ],
 "completed step": [
  null,
  "完了した手順"
 ],
 "current step": [
  null,
  "現在の手順"
 ],
 "edit": [
  null,
  ""
 ],
 "encrypt": [
  null,
  "暗号化"
 ],
 "encrypted": [
  null,
  "暗号化済み"
 ],
 "format as $0": [
  null,
  "$0 としてフォーマットする"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "マウント"
 ],
 "pending step": [
  null,
  "保留中の手順"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "shrink to $0": [
  null,
  "$0 に縮小"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  ""
 ]
});
