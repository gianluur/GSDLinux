cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Palvelut"
 ],
 "Terminal": [
  null,
  "Pääte"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "time": [
  null,
  "aika"
 ],
 "date": [
  null,
  "päivämäärä"
 ],
 "restart": [
  null,
  "käynnistä uudelleen"
 ],
 "shut": [
  null,
  "sulje"
 ],
 "domain": [
  null,
  "toimialue"
 ],
 "machine": [
  null,
  "kone"
 ],
 "operating system": [
  null,
  "käyttöjärjestelmä"
 ],
 "os": [
  null,
  "käyttöjärjestelmä"
 ],
 "asset tag": [
  null,
  "sisältötunniste"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "virta"
 ],
 "version": [
  null,
  "versio"
 ],
 "host": [
  null,
  "kone"
 ],
 "hardware": [
  null,
  "laitteisto"
 ],
 "mitigation": [
  null,
  "lievennys"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "muisti"
 ],
 "cpu": [
  null,
  "suoritin"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram-muisti"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "sarja"
 ],
 "graphs": [
  null,
  "kaaviot"
 ],
 "metrics": [
  null,
  "mittarit"
 ],
 "history": [
  null,
  "historia"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "levyt"
 ],
 "network": [
  null,
  "verkko"
 ],
 "cgroups": [
  null,
  "c-ryhmät"
 ],
 "performance": [
  null,
  "suorituskyky"
 ],
 "Configuring system settings": [
  null,
  "Järjestelmäasetusten määrittäminen"
 ],
 "service": [
  null,
  "palvelu"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "kohde"
 ],
 "socket": [
  null,
  "pistoke"
 ],
 "timer": [
  null,
  "ajastin"
 ],
 "path": [
  null,
  "polku"
 ],
 "unit": [
  null,
  "yksikkö"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "käynnistys"
 ],
 "mask": [
  null,
  "peite"
 ],
 "unmask": [
  null,
  "poista peite"
 ],
 "enable": [
  null,
  "ota käyttöön"
 ],
 "disable": [
  null,
  "poista käytöstä"
 ],
 "Managing services": [
  null,
  "Palvelujen hallinta"
 ],
 "journal": [
  null,
  "päiväkirja"
 ],
 "warning": [
  null,
  "varoitus"
 ],
 "error": [
  null,
  "virhe"
 ],
 "debug": [
  null,
  "virheenjäljitys"
 ],
 "crash": [
  null,
  "kaatuminen"
 ],
 "coredump": [
  null,
  "ytimen tyhjennys"
 ],
 "Reviewing logs": [
  null,
  "Tarkistetaan lokeja"
 ],
 "console": [
  null,
  "konsoli"
 ],
 "command": [
  null,
  "komento"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "komentotulkki"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
