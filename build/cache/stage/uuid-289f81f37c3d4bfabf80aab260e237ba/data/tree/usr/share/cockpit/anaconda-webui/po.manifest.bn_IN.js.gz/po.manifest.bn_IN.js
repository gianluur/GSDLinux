cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "bn_IN",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
