cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Unlock": [
  null,
  "Déverrouiller"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Select": [
  null,
  "Sélectionner"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "Set": [
  null,
  "Ensemble"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "Permission denied": [
  null,
  "Permission refusée"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "You now have administrative access.": [
  null,
  "Vous avez l’accès administrateur."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Aucun moyen d'obtenir un accès d'administration n'est disponible (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Veuillez vous authentifier pour obtenir un accès administrateur"
 ],
 "Switch to administrative access": [
  null,
  "Passer à l’accès administrateur"
 ],
 "Authenticate": [
  null,
  "S’authentifier"
 ],
 "Administrative access": [
  null,
  "Accès administrateur"
 ],
 "Problem becoming administrator": [
  null,
  "Problème pour devenir administrateur"
 ],
 "Method": [
  null,
  "Méthode"
 ],
 "Limit access": [
  null,
  "Limiter l’accès"
 ],
 "Switch to limited access": [
  null,
  "Passer en accès limité"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Le mode accès limité restreint les privilèges d’administration. Certaines parties de la console web auront des fonctionnalités réduites."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Votre navigateur se souviendra de votre niveau d’accès d’une session à l’autre."
 ],
 "Limited access": [
  null,
  "Accès limité"
 ],
 "Turn on administrative access": [
  null,
  "Activez l’accès administrateur"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "password quality": [
  null,
  "qualité du mot de passe"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun dépôt."
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a signalé le code d’erreur $0"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Error during initialization": [
  null,
  "Erreur pendant l’initialisation"
 ],
 "Failed": [
  null,
  "Échec"
 ],
 "Home": [
  null,
  "Répertoire personnel"
 ],
 "Downloads": [
  null,
  "Téléchargements"
 ],
 "Not a directory": [
  null,
  "Pas un répertoire"
 ],
 "All files": [
  null,
  "Tous les fichiers"
 ],
 "Recent": [
  null,
  "Récent"
 ],
 "No recent directories": [
  null,
  "Aucun répertoire récent"
 ],
 "No recent files": [
  null,
  "Aucun fichier récent"
 ],
 "Type to filter": [
  null,
  "Tapez pour filtrer"
 ],
 "File chooser actions": [
  null,
  "Actions du sélecteur de fichiers"
 ],
 "Open in file browser": [
  null,
  "Ouvrir dans le navigateur de fichiers"
 ],
 "Hide hidden files": [
  null,
  "Masquer les fichiers cachés"
 ],
 "Show hidden files": [
  null,
  "Afficher les fichiers cachés"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Clear filters": [
  null,
  "Effacer les filtres"
 ],
 "Directory is empty": [
  null,
  "Le répertoire est vide"
 ],
 "Directory has no sub-directories": [
  null,
  "Le répertoire n'a aucun sous-répertoire"
 ],
 "This directory contains only hidden files": [
  null,
  "Ce répertoire contient seulement des fichiers cachés"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "Folder": [
  null,
  "Dossier"
 ],
 "File": [
  null,
  "Fichier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "View logs": [
  null,
  "Voir les journaux"
 ],
 "Dismiss": [
  null,
  "Ignorer"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "Model": [
  null,
  "Modèle"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "none": [
  null,
  "aucun"
 ],
 "Not found": [
  null,
  "Non trouvé"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "Not running": [
  null,
  "Pas en cours d’exécution"
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "Vendor": [
  null,
  "Fournisseur"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "State": [
  null,
  "État"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Username": [
  null,
  "Nom d’utilisateur"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Started": [
  null,
  "Démarré"
 ],
 "Delete group": [
  null,
  "Supprimer le groupe"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Lock": [
  null,
  "Verrouillage"
 ],
 "Use $0": [
  null,
  "Utiliser $0"
 ],
 "Service": [
  null,
  "Service"
 ],
 "Disconnect": [
  null,
  "Déconnecter"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "$0 disk is missing": [
  null,
  "$0 disque est manquant",
  "$0 disques sont manquants"
 ],
 "Location": [
  null,
  "Emplacement"
 ],
 "Compression": [
  null,
  "Compression"
 ],
 "Storage logs": [
  null,
  "Journaux de stockage"
 ],
 "Name cannot be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Le nom ne peut pas dépasser 127 caractères."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Le nom ne peut pas contenir le caractère « $0 »."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Le nom ne peut pas contenir d’espace."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Le nom ne peut pas dépasser $0 caractères"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Le nom ne peut pas dépasser $0 octets"
 ],
 "$name (from $host)": [
  null,
  "$name (de $host )"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool pour les volumes logiques à allocation fine"
 ],
 "Thin logical volume": [
  null,
  "Volume logique à allocation fine"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logique (instantané)"
 ],
 "Logical volume": [
  null,
  "Volume logique"
 ],
 "MDRAID device $0": [
  null,
  "Périphérique MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Groupe de volumes LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Périphérique VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logique chiffré de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partition chiffrée de $0"
 ],
 "Logical volume of $0": [
  null,
  "Volume logique de $0"
 ],
 "Partition of $0": [
  null,
  "Partition de $0"
 ],
 "Encrypted $0": [
  null,
  "Chiffré $0"
 ],
 "unpartitioned space on $0": [
  null,
  "espace non partitionné sur $0"
 ],
 "unmount": [
  null,
  "Démonter"
 ],
 "mount": [
  null,
  "monter"
 ],
 "remove from btrfs volume": [
  null,
  "retirer d'un volume btrfs"
 ],
 "stop": [
  null,
  "arrêter"
 ],
 "remove from MDRAID": [
  null,
  "retirer du MDRAID"
 ],
 "remove from LVM2": [
  null,
  "retirer de LVM2"
 ],
 "btrfs device": [
  null,
  "Périphérique btrfs"
 ],
 "btrfs volume": [
  null,
  "Volume btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Le nom ne peut pas dépasser 255 caractères."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Le nom ne peut pas contenir le caractère '/'."
 ],
 "Create and mount": [
  null,
  "Créer et monter"
 ],
 "Create only": [
  null,
  "Créer uniquement"
 ],
 "Create subvolume": [
  null,
  "Créer un sous-volume"
 ],
 "Mount Point": [
  null,
  "Point de montage"
 ],
 "delete": [
  null,
  "supprimer"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Supprimer définitivement le sous-volume $0 ?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "La suppression efface toutes les données sur ce sous-volume et sur tous ses enfants."
 ],
 "Edit mount point": [
  null,
  "Modifier le point de montage"
 ],
 "Unmount": [
  null,
  "Démonter"
 ],
 "Mount": [
  null,
  "Monter"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Au moins 1 sous-volume doit être monté"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Le dernier sous-volume monté ne peut pas être supprimé"
 ],
 "btrfs subvolume": [
  null,
  "Sous-volume btrfs"
 ],
 "Snapshot origin": [
  null,
  "Origine de l'instantané"
 ],
 "Mount point": [
  null,
  "Point de montage"
 ],
 "No subvolumes": [
  null,
  "Aucun sous-volume"
 ],
 "btrfs subvolumes": [
  null,
  "Sous-volumes btrfs"
 ],
 "Snapshots": [
  null,
  "Instantanés"
 ],
 "No snapshots found": [
  null,
  "Aucun instantané trouvé"
 ],
 "snapshot": [
  null,
  "instantané"
 ],
 "$0 is in use": [
  null,
  "$0 est en cours d’utilisation"
 ],
 "Permanently delete $0?": [
  null,
  "Supprimer définitivement $0 ?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "La suppression efface toutes les données sur un volume Btrfs."
 ],
 "Delete filesystem": [
  null,
  "Supprimer le système de fichiers"
 ],
 "Change label": [
  null,
  "Changer l’étiquette"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Le système de fichiers est monté en lecture seule"
 ],
 "Label": [
  null,
  "Étiquette"
 ],
 "Capacity": [
  null,
  "Capacité"
 ],
 "btrfs devices": [
  null,
  "Périphériques btrfs"
 ],
 "No devices found": [
  null,
  "Aucun périphérique trouvé"
 ],
 "btrfs filesystem": [
  null,
  "Système de fichiers btrfs"
 ],
 "Successful": [
  null,
  "Réussi"
 ],
 "Aborted": [
  null,
  "Interrompu"
 ],
 "In progress": [
  null,
  "En cours"
 ],
 "Interrupted": [
  null,
  "Interrompu"
 ],
 "Did not complete": [
  null,
  "Ne s'est pas terminé"
 ],
 "Failed (Unknown)": [
  null,
  "Échec (inconnu)"
 ],
 "Failed (Electrical)": [
  null,
  "Échec (électrique)"
 ],
 "Failed (Servo)": [
  null,
  "Échec (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Échec (lecture)"
 ],
 "Failed (Damaged)": [
  null,
  "Échec (endommagé)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Interrompu par une réinitialisation au niveau du contrôleur"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Interrompu par la suppression d'un espace de noms dans l'inventaire d'espaces de noms"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Interrompu par le traitement d'une commande Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Une erreur fatale s'est produite durant l'opération d'autotest"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Terminé avec l'échec d'un segment inconnu"
 ],
 "Completed with one or more failed segments": [
  null,
  "Terminé avec l'échec d'un ou plusieurs segments"
 ],
 "Aborted for unknown reason": [
  null,
  "Interrompu pour une raison inconnue"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Interrompu par une opération d'assainissement"
 ],
 "Spare capacity is below the threshold": [
  null,
  "La capacité restante est inférieure au seuil"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Température dépassant les seuils recommandés"
 ],
 "Degraded": [
  null,
  "Dégradé"
 ],
 "All media is in read-only mode": [
  null,
  "Tous les supports sont en mode Lecture seule"
 ],
 "Volatile memory backup failed": [
  null,
  "Échec de la sauvegarde de la mémoire volatile"
 ],
 "Persistent memory has become read-only": [
  null,
  "La mémoire persistante est passée en lecture seule"
 ],
 "Run short test": [
  null,
  "Exécuter un test court"
 ],
 "Run extended test": [
  null,
  "Exécuter un test étendu"
 ],
 "Abort test": [
  null,
  "Interrompre le test"
 ],
 "Disk is failing": [
  null,
  "Le disque est défaillant"
 ],
 "Disk is OK": [
  null,
  "Le disque est OK"
 ],
 "Assessment": [
  null,
  "Évaluation"
 ],
 "Power on hours": [
  null,
  "Heures totales"
 ],
 "$0 hours": [
  null,
  "$0 heures"
 ],
 "Self-test status": [
  null,
  "État d'autotest"
 ],
 "Number of bad sectors": [
  null,
  "Nombre de secteurs défectueux"
 ],
 "Attributes failing": [
  null,
  "Attributs en échec"
 ],
 "Media drive": [
  null,
  "Lecteur de supports"
 ],
 "Solid State Drive": [
  null,
  "Disque SSD"
 ],
 "Hard Disk Drive": [
  null,
  "Lecteur de disque dur"
 ],
 "iSCSI Drive": [
  null,
  "Lecteur iSCSI"
 ],
 "Drive": [
  null,
  "Lecteur"
 ],
 "Device health (SMART)": [
  null,
  "Santé de l'appareil (SMART)"
 ],
 "Firmware version": [
  null,
  "Version du micrologiciel"
 ],
 "Serial number": [
  null,
  "Numéro de série"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "Aucun support inséré"
 ],
 "Device file": [
  null,
  "Fichier de périphérique"
 ],
 "Multipathed devices": [
  null,
  "Appareils multi-chemins"
 ],
 "Free space": [
  null,
  "Espace libre"
 ],
 "Create partition": [
  null,
  "Créer une partition"
 ],
 "Extended partition": [
  null,
  "Partition étendue"
 ],
 "$0 partitions": [
  null,
  "Partitions $0"
 ],
 "Partitions": [
  null,
  "Partitions"
 ],
 "No partitions found": [
  null,
  "Aucune partition trouvée"
 ],
 "Unexpected partitions": [
  null,
  "Partition inattendues"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Les partitions ne sont pas prises en charge sur ce périphérique block. S'il est utilisé en tant que disque pour une machine virtuelle, les partitions doivent être gérées par le système d'exploitation à l'intérieur de la machine virtuelle."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "La suppression d’une partition supprimera toutes les données qui s’y trouvent."
 ],
 "No free space after this partition": [
  null,
  "Aucun espace libre après cette partition"
 ],
 "EFI system partition": [
  null,
  "Partition système EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partition de démarrage BIOS"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Shrink": [
  null,
  "Réduire"
 ],
 "Grow": [
  null,
  "Augmenter"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partition de démarrage PReP pour PowerPC"
 ],
 "Linux swap space": [
  null,
  "Espace swap Linux"
 ],
 "Linux filesystem data": [
  null,
  "Données de système de fichiers Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partition Logical Volume Manager"
 ],
 "Custom": [
  null,
  "Personnalisé"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Le type doit contenir exactement deux caractères hexadécimaux (0 à 9, A à F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Le type ne peut contenir que les caractères de 0 à 9 et de A à F, ainsi que le caractère \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Le type doit être au format NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Définir le type de partition de $0"
 ],
 "Custom type": [
  null,
  "Type personnalisé"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Modifier les types de partition pourrait empêcher le système de démarrer."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Cette partition n’est pas complètement utilisée par son contenu."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Taille de la partition : $0. Taille du contenu : $1."
 ],
 "Shrink partition": [
  null,
  "Réduire la partition"
 ],
 "Grow content": [
  null,
  "Augmenter le contenu"
 ],
 "initialize": [
  null,
  "initialiser"
 ],
 "Initialize disk $0": [
  null,
  "Initialiser le disque $0"
 ],
 "Partitioning": [
  null,
  "Partitionnement"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatible avec tous les systèmes et périphériques (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatible avec les systèmes modernes et les disques durs > 2 To (GPT)"
 ],
 "No partitioning": [
  null,
  "Pas de partitionnement"
 ],
 "Overwrite": [
  null,
  "Écraser"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Écraser les données existantes avec des zéros (plus lent)"
 ],
 "Initialize": [
  null,
  "Initialiser"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "L’initialisation efface toutes les données d’un disque."
 ],
 "Device is read-only": [
  null,
  "Périphérique en lecture seule"
 ],
 "Create partition table": [
  null,
  "Créer une table de partitions"
 ],
 "Size must be a number": [
  null,
  "La taille doit être un nombre"
 ],
 "Size cannot be zero": [
  null,
  "La taille ne peut pas être nulle"
 ],
 "Size cannot be negative": [
  null,
  "La taille ne peut pas être négative"
 ],
 "Size is too large": [
  null,
  "La taille est trop grande"
 ],
 "Size must be at least $0": [
  null,
  "La taille doit être au moins $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume physique du groupe de volumes LVM2"
 ],
 "member of MDRAID device": [
  null,
  "membre d'un périphérique MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "périphérique de sauvegarde pour périphérique VDO"
 ],
 "member of Stratis pool": [
  null,
  "membre du pool Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Système de fichiers hors de la cible"
 ],
 "device of btrfs volume": [
  null,
  "périphérique d'un volume btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Ce périphérique est actuellement en cours d’utilisation."
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Use": [
  null,
  "Utilisation"
 ],
 "Services using the location": [
  null,
  "Services utilisant l’emplacement"
 ],
 "Processes using the location": [
  null,
  "Processus utilisant l’emplacement"
 ],
 "Currently in use": [
  null,
  "Actuellement en cours d’utilisation"
 ],
 "(Not part of target)": [
  null,
  "(Ne fait pas partie de la cible)"
 ],
 "These changes will be made:": [
  null,
  "Ces changements seront effectués :"
 ],
 "Action": [
  null,
  "Action"
 ],
 "Important data might be deleted:": [
  null,
  "Des données importantes pourraient être supprimées :"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Les processus et services connexes seront arrêtés de force."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Les processus connexes seront arrêtés de force."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Les services connexes seront arrêtés par la force."
 ],
 "Checking filesystem usage": [
  null,
  "Vérification de l'utilisation des systèmes de fichiers"
 ],
 "$0 used, $1 total": [
  null,
  "$0 utilisés, $1 au total"
 ],
 "Device contains unrecognized data": [
  null,
  "L'appareil contient des données non reconnues"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Un périphérique chiffré et verrouillé pourrait contenir des données"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Je confirme vouloir perdre définitivement ces données"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Le point de montage $0 est utilisé par ces processus :"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Commande"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Le point de montage $0 est utilisé par ces services :"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Les processus et services listés seront stoppés en force."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Les processus énumérés seront stoppés en force."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Les services répertoriés seront stoppés en force."
 ],
 "Sorry": [
  null,
  "Désolé"
 ],
 "Usage of $0": [
  null,
  "Utilisation de $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Pool VDO LVM2"
 ],
 "Data used": [
  null,
  "Données utilisées"
 ],
 "Metadata used": [
  null,
  "Méta-données utilisées"
 ],
 "Use compression": [
  null,
  "Utiliser la compression"
 ],
 "Deduplication": [
  null,
  "Déduplication"
 ],
 "Use deduplication": [
  null,
  "Déduplication"
 ],
 "Rename volume group": [
  null,
  "Renommer le groupe de volumes"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Ce groupe de volumes contient le système de fichiers racine. Renommer ce groupe pourrait nécessiter des modifications de la configuration du bootloader ou de la ligne de commande du noyau."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "La suppression efface toutes les données d’un groupe de volumes."
 ],
 "Create snapshot": [
  null,
  "Créer un instantané"
 ],
 "Add disks": [
  null,
  "Ajouter des disques"
 ],
 "Disks": [
  null,
  "Disques"
 ],
 "No disks are available.": [
  null,
  "Aucun disque disponible."
 ],
 "At least one disk is needed.": [
  null,
  "Au moins un disque est nécessaire."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Il manque des volumes physiques dans le groupe de volumes"
 ],
 "No free space": [
  null,
  "Pas d’espace libre"
 ],
 "LVM2 volume group": [
  null,
  "Groupe de volumes LVM2"
 ],
 "Add physical volume": [
  null,
  "Ajouter le volume physique"
 ],
 "LVM2 logical volumes": [
  null,
  "Volume logique LVM2"
 ],
 "Create new logical volume": [
  null,
  "Créer un nouveau volume logique"
 ],
 "No logical volumes": [
  null,
  "Pas de volumes logiques"
 ],
 "Remove missing physical volumes?": [
  null,
  "Retirer les volumes physiques manquants ?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Il manque certains volumes physiques dans ce groupe de volumes."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Un groupe de volumes avec des volumes physiques manquants ne peut pas être renommé."
 ],
 "Physical volumes": [
  null,
  "Volumes physiques"
 ],
 "No physical volumes found": [
  null,
  "Aucun volume physique trouvé"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumes physiques LVM2"
 ],
 "Rename logical volume": [
  null,
  "Renommer le volume logique"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Supprimer définitivement le volume logique $0/$1 ?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "La suppression d’un volume logique supprimera toutes les données qu’il contient."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Impossible de réparer le volume logique $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Il n'y a pas assez d'espace libre pouvant être utilisé pour une réparation. Au moins $0 sont nécessaires sur des volumes physiques n'étant pas déjà utilisés pour ce volume logique."
 ],
 "An additional $0 must be selected": [
  null,
  "Un $0 additionnel doit être sélectionné"
 ],
 "Repair logical volume $0": [
  null,
  "Réparer le volume logique $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Sélectionnez les volumes physiques à utiliser pour réparer le volume logique. Au moins $0 volumes physiques sont nécessaires."
 ],
 "Physical Volumes": [
  null,
  "Volumes physiques"
 ],
 "Repair": [
  null,
  "Réparer"
 ],
 "deactivate": [
  null,
  "désactiver"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Désactiver le volume logique $0/$1 ?"
 ],
 "Deactivate": [
  null,
  "Désactiver"
 ],
 "Not enough space to grow": [
  null,
  "Espace insuffisant pour agrandir le volume"
 ],
 "LVM2 logical volume": [
  null,
  "Volume logique LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "En bandes (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "En miroir (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "En bandes et en miroir (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Parité dédiée (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Parité répartie (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Parité doublement distribuée (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Ce volume logique n’est pas complètement utilisé par son contenu."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "La taille du volume est $0. La taille du contenu est $1."
 ],
 "Shrink volume": [
  null,
  "Réduire le volume"
 ],
 "Layout": [
  null,
  "Disposition"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques et ne peut plus être utilisé. Vous devez le supprimer et en créer un nouveau pour le remplacer."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques mais n'a pas encore perdu de données. Vous devriez le réparer pour rétablir la redondance d'origine."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques mais pourrait ne pas avoir encore perdu de données. Vous arriverez peut-être à le réparer."
 ],
 "Stripes": [
  null,
  "Bandes"
 ],
 "$0 synchronized": [
  null,
  "$0 synchronisé"
 ],
 "Create volume group": [
  null,
  "Créer un groupe de volumes"
 ],
 "LVM2 physical volume": [
  null,
  "Volume physique LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Impossible de retirer le dernier volume"
 ],
 "Not enough free space": [
  null,
  "Pas assez d’espace libre"
 ],
 "Volume group": [
  null,
  "Groupe de volumes"
 ],
 "Create thin volume": [
  null,
  "Créer un volume à allocation fine"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volumes logiques LVM2 à allocation fine et dynamique"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Créer un nouveau volume logique à allocation fine et dynamique"
 ],
 "Not enough space": [
  null,
  "Espace insuffisant"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool pour les volumes logiques LVM2 à allocation fine et dynamique"
 ],
 "Inactive logical volume": [
  null,
  "Volume logique inactif"
 ],
 "Activate": [
  null,
  "Activer"
 ],
 "Unsupported logical volume": [
  null,
  "Volume logique non pris en charge"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERREUR INTERNE – Ce volume logique est marqué comme actif et devrait avoir un périphérique block associé. Or, aucun périphérique block correspondant n'a pu être trouvé."
 ],
 "Installing $0 would remove $1.": [
  null,
  "L’installation de $0 supprimerait $1."
 ],
 "Installing packages": [
  null,
  "Installation des paquets"
 ],
 "Block device for filesystems": [
  null,
  "Périphérique block pour système de fichiers"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool pour les volumes à allocation fine et dynamique"
 ],
 "Linear": [
  null,
  "Linéaire"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume du système de fichiers VDO (compression/dédoublonnage)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés sans aucune amélioration vis-à-vis de la redondance ou des performances."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Les données seront stockées en alternance sur les volumes physiques sélectionnés pour améliorer les performances. Au moins deux volumes doivent être sélectionnés."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés en deux copies ou plus, pour améliorer la fiabilité. Au moins deux volumes doivent être sélectionnés."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Les données seront stockées en deux copies et en alternant entre les volumes physiques sélectionnés, pour améliorer la fiabilité et les performances. Au moins quatre volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que l'un d'entre eux puisse être perdu sans affecter l'intégrité des données. Au moins trois volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que l'un d'entre eux puisse être perdu sans affecter l'intégrité des données. Les données sont également stockées en alternance afin d'améliorer les performances. Au moins trois volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que deux d'entre eux puissent être perdus sans affecter l'intégrité des données. Les données sont également stockées en alternance afin d'améliorer les performances. Au moins cinq volumes doivent être sélectionnés."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "L'ensemble des $0 volumes physiques sélectionnés sont nécessaires pour le schéma choisi."
 ],
 "Create logical volume": [
  null,
  "Créer un volume logique"
 ],
 "Purpose": [
  null,
  "Objectif"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Le paquet $0 sera installé pour créer des périphériques VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Le RAID10 nécessite un nombre pair de volumes physiques"
 ],
 "Logical size": [
  null,
  "Taille logique"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Économiser de l’espace en compressant les blocs individuels avec LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Économiser de l’espace en stockant une seule fois les blocs de données identiques"
 ],
 "Creating VDO device": [
  null,
  "Création d’un périphérique VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Ce montage NFS est en cours d’utilisation et seules ses options peuvent être modifiées."
 ],
 "NFS mount": [
  null,
  "Point de montage NFS"
 ],
 "New NFS mount": [
  null,
  "Nouveau point de montage NFS"
 ],
 "Server address": [
  null,
  "Adresse du serveur"
 ],
 "Server cannot be empty.": [
  null,
  "Le serveur ne peut pas être vide."
 ],
 "Path on server": [
  null,
  "Chemin sur le serveur"
 ],
 "Path on server cannot be empty.": [
  null,
  "Le chemin sur le serveur ne peut pas être vide."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Le chemin sur le serveur doit commencer par « / »."
 ],
 "Local mount point": [
  null,
  "Point de montage local"
 ],
 "Mount point cannot be empty.": [
  null,
  "Le point de montage ne peut pas être vide."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Le point de montage doit commencer par « / »."
 ],
 "Mount options": [
  null,
  "Options de montage"
 ],
 "Mount at boot": [
  null,
  "Monter au démarrage"
 ],
 "Mount read only": [
  null,
  "Monter en lecture seule"
 ],
 "Custom mount options": [
  null,
  "Options de montage personnalisées"
 ],
 "Unable to unmount filesystem": [
  null,
  "Impossible de démonter le système de fichiers"
 ],
 "Stop and unmount": [
  null,
  "Arrêter et démonter"
 ],
 "Unable to remove mount": [
  null,
  "Impossible de supprimer le montage"
 ],
 "Stop and remove": [
  null,
  "Arrêter et retirer"
 ],
 "(not mounted)": [
  null,
  "(non monté)"
 ],
 "Start multipath": [
  null,
  "Démarrer Multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Il y a des périphériques avec plusieurs chemins sur le système, mais le service multipath n’est pas en cours d’exécution."
 ],
 "Show all $0 rows": [
  null,
  "Afficher l'ensemble des $0 lignes"
 ],
 "Category": [
  null,
  "Catégorie"
 ],
 "more info": [
  null,
  "plus d’infos"
 ],
 "Encryption": [
  null,
  "Chiffrement"
 ],
 "encrypted": [
  null,
  "chiffré"
 ],
 "Last modified: $0": [
  null,
  "Dernière modification : $0"
 ],
 "Stored passphrase": [
  null,
  "Phrase secrète stockée"
 ],
 "Encryption options": [
  null,
  "Options de chiffrement"
 ],
 "Encryption type": [
  null,
  "Type de chiffrement"
 ],
 "Cleartext device": [
  null,
  "Périphérique en clair"
 ],
 "yes": [
  null,
  "oui"
 ],
 "Disk passphrase": [
  null,
  "Phrase secrète du disque"
 ],
 "Passphrase cannot be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Unlocking disk": [
  null,
  "Déverrouillage du disque"
 ],
 "Checking for $0 package": [
  null,
  "Vérification du paquet $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Le paquet $0 doit être installé."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Le paquet $0 n’est disponible dans aucun dépôt."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Erreur lors de l'installation de $0 : ni PackageKit ni dnf5daemon-server ne sont installés"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Erreur PackageManager inattendue lors de l'installation de $0 : $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Vérification du support NBDE dans initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "L'initrd doit être régénéré."
 ],
 "Regenerating initrd": [
  null,
  "Régénération d’ initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Ajout de rd.neednet=1 à la ligne de commande du noyau"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Ajout de \"$0\" aux options du système de fichiers"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Ajout de \"$0\" aux options de chiffrement"
 ],
 "Enabling $0": [
  null,
  "Permettre l'accès à $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Ajouter le chiffrement de disque lié au réseau (NBDE)"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Le système ne prend actuellement pas en charge le déverrouillage du système de fichiers racine avec un serveur de clés Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Le système ne prend actuellement pas en charge le déverrouillage d'un système de fichiers avec un serveur de clés Tang pendant le démarrage."
 ],
 "These additional steps are necessary:": [
  null,
  "Ces étapes supplémentaires sont nécessaires :"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "L'enregistrement d'une nouvelle phrase secrète nécessite le déverrouillage du disque. Veuillez fournir la phrase secrète du disque actuel."
 ],
 "Fix NBDE support": [
  null,
  "Correction du support NBDE"
 ],
 "Adding key": [
  null,
  "Ajout d’une clé"
 ],
 "Key source": [
  null,
  "Source de la clé"
 ],
 "Repeat passphrase": [
  null,
  "Répéter la phrase secrète"
 ],
 "Passphrase": [
  null,
  "Phrase secrète"
 ],
 "Tang keyserver": [
  null,
  "Serveur de clés Tang"
 ],
 "New passphrase": [
  null,
  "Nouvelle phrase secrète"
 ],
 "Passphrases do not match": [
  null,
  "Les phrases secrète ne correspondent pas"
 ],
 "Keyserver address": [
  null,
  "Adresse du serveur"
 ],
 "Change passphrase": [
  null,
  "Modifier la phrase secrète"
 ],
 "Old passphrase": [
  null,
  "Ancienne phrase secrète"
 ],
 "Edit Tang keyserver": [
  null,
  "Modifier le serveur de clés Tang"
 ],
 "Verify key": [
  null,
  "Vérifier la clé"
 ],
 "Trust key": [
  null,
  "Clé de confiance"
 ],
 "Passphrase can not be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "La suppression de la phrase secrète peut empêcher le déverrouillage de $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirmer la suppression avec une phrase secrète alternative"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "La suppression d’une phrase secrète sans confirmation d’une autre phrase secrète peut empêcher le déverrouillage ou la gestion des clés, si les autres phrases secrètes sont oubliées ou perdues."
 ],
 "Passphrase from any other key slot": [
  null,
  "Phrase secrète de n’importe quel autre emplacement de clé"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Supprimer la phrase de secrète dans l’emplacement de la clé $0 ?"
 ],
 "Remove $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Le retrait est susceptible d'empêcher le déverrouillage de $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Supprimer le serveur de clés Tang ?"
 ],
 "Remove key in slot $0?": [
  null,
  "Retirer la clé à l’emplacement $0 ?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les informations sur les clés."
 ],
 "No keys added": [
  null,
  "Aucune clé n’a été ajoutée"
 ],
 "Slot $0": [
  null,
  "Emplacement $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "La modification d’une clé nécessite un emplacement libre"
 ],
 "The last key slot can not be removed": [
  null,
  "Le dernier logement de clé ne peut pas être retiré"
 ],
 "Keyserver": [
  null,
  "Serveur de clés"
 ],
 "Unknown type": [
  null,
  "Type inconnu"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Les emplacements de clé de type inconnu ne peuvent pas être édités ici"
 ],
 "Keys": [
  null,
  "Clés"
 ],
 "$0 slot remains": [
  null,
  "$0 il reste un créneau",
  "$0 logements restants"
 ],
 "No available slots": [
  null,
  "Pas d’emplacements disponibles"
 ],
 "No free key slots": [
  null,
  "Pas d’emplacements libres pour les clés"
 ],
 "Locked data": [
  null,
  "Données verrouillées"
 ],
 "lock": [
  null,
  "verrouiller"
 ],
 "Lock $0?": [
  null,
  "Verrouiller $0 ?"
 ],
 "Address cannot be empty": [
  null,
  "L’adresse ne peut pas être vide"
 ],
 "Address is not a valid URL": [
  null,
  "L’adresse ne correspond pas à une URL valide"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Vérifiez le hash de la clé avec le serveur Tang."
 ],
 "How to check": [
  null,
  "Comment vérifier"
 ],
 "In a terminal, run: ": [
  null,
  "Dans un terminal, exécuter : "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copié dans le presse-papiers avec succès !"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Vérifiez que le hash SHA-256 ou SHA-1 de la commande correspond à celui dans cette boîte de dialogue."
 ],
 "SHA-256": [
  null,
  "SHA256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Sous-volume btrfs $0 de $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Le point de montage ne peut pas être vide"
 ],
 "Mount point is already used for $0": [
  null,
  "Le point de montage est déjà utilisé pour $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Les systèmes de fichiers sont déjà montés en dessous de ce point de montage."
 ],
 "Please unmount them first.": [
  null,
  "Veuillez commencer par les démonter."
 ],
 "read only": [
  null,
  "lecture seule"
 ],
 "never mount at boot": [
  null,
  "ne jamais monter au démarrage"
 ],
 "after network": [
  null,
  "après le réseau"
 ],
 "ignore failure": [
  null,
  "ignorer l'échec"
 ],
 "stop boot on failure": [
  null,
  "arrêter le démarrage en cas d'échec"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Le système de fichiers n’a pas de point de montage assigné."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Le système de fichiers n’a pas de point de montage permanent."
 ],
 "The filesystem is not mounted.": [
  null,
  "Le système de fichiers n’est pas monté."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Le système de fichiers sera déverrouillé et monté au prochain démarrage. Cela peut nécessiter la saisie d’une phrase secrète."
 ],
 "(no assigned mount point)": [
  null,
  "(aucun point de montage assigné)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Le système de fichiers est actuellement monté sur $0 mais sera monté sur $1 au prochain démarrage."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montage automatique $0 au démarrage"
 ],
 "Mount on $0 now": [
  null,
  "Montez sur $0 maintenant"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Le système de fichiers n’est pas actuellement monté mais sera monté au prochain démarrage."
 ],
 "Do not mount automatically on boot": [
  null,
  "Ne pas monter automatiquement au démarrage"
 ],
 "Mount now": [
  null,
  "Monter maintenant"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté mais ne le sera plus après le prochain démarrage."
 ],
 "Mount also automatically on boot": [
  null,
  "Monter automatiquement au démarrage également"
 ],
 "Unmount now": [
  null,
  "Supprimer le montage maintenant"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté $0 mais ne sera pas monté après le prochain démarrage."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Le système de fichiers est configuré pour être monté automatiquement au démarrage, mais son conteneur de chiffrement ne sera pas encore déverrouillé."
 ],
 "Unlock automatically on boot": [
  null,
  "Déverrouiller automatiquement au démarrage"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montage de système de fichiers incohérent"
 ],
 "$0 filesystem": [
  null,
  "Système de fichiers $0"
 ],
 "Filesystem name": [
  null,
  "Nom du système de fichiers"
 ],
 "Filesystem is locked": [
  null,
  "Le système de fichiers est verrouillé"
 ],
 "Mounts before services start": [
  null,
  "Montage avant le démarrage des services"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Approprié pour les montages critiques, tels que /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Le démarrage échoue si le système de fichiers n'est pas monté, ce qui empêche l'accès à distance"
 ],
 "Mounts in parallel with services": [
  null,
  "Montage en parallèle avec les services"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Le démarrage réussit toujours lorsque le système de fichiers n'est pas monté"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Montage en parallèle avec les services, mais après que le réseau soit disponible"
 ],
 "Does not mount during boot": [
  null,
  "Ne se monte pas au démarrage"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Utile pour les montages facultatifs ou nécessitant une interaction (comme les phrases secrètes)"
 ],
 "At boot": [
  null,
  "Au démarrage"
 ],
 "Mount before services start": [
  null,
  "Montage avant le début des services"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monter sans attendre, ignorer les échecs"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monter après que le réseau soit devenu disponible, ignorer les échecs"
 ],
 "Do not mount": [
  null,
  "Ne pas monter"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Ce périphérique ne peut pas être utilisé pour la cible d'installation."
 ],
 "Mount filesystem": [
  null,
  "Monter le système de fichiers"
 ],
 "Unmount filesystem $0": [
  null,
  "Démonter le système de fichiers $0"
 ],
 "Mount configuration": [
  null,
  "Configuration de montage"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Utilisé"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Déverrouiller le pool Stratis chiffré"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Fournissez la phrase secrète pour le pool sur ces périphériques block :"
 ],
 "Stratis pool": [
  null,
  "Pool Stratis"
 ],
 "stopped": [
  null,
  "arrêté"
 ],
 "Block devices": [
  null,
  "Périphériques block"
 ],
 "No block devices found": [
  null,
  "Aucun périphérique block trouvé"
 ],
 "Stratis block devices": [
  null,
  "Périphériques block Stratis"
 ],
 "Stratis block device": [
  null,
  "Périphérique block Stratis"
 ],
 "data": [
  null,
  "données"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Veuillez fournir une phrase secrète existante du pool."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Si le serveur de clés à l'adresse $0 n'est pas atteignable, vous pouvez fournir une phrase secrète existante."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Si aucun serveur de clé n'est atteignable, vous pouvez fournir une phrase secrète existante."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Si aucune des méthodes de déverrouillage non interactives ne fonctionne, vous pouvez fournir une phrase secrète existante."
 ],
 "Pool passphrase": [
  null,
  "Phrase secrète du pool"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Le serveur de clés à l'adresse $0 doit être atteignable."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Au moins un serveur de clés doit être atteignable."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Au moins une des méthodes de déverrouillage non interactives doit fonctionner."
 ],
 "Create filesystem": [
  null,
  "Créer un système de fichiers"
 ],
 "Stratis filesystem": [
  null,
  "Système de fichiers Stratis"
 ],
 "Set initial size": [
  null,
  "Définir une taille initiale"
 ],
 "Limit size": [
  null,
  "Limiter la taille"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "La suppression d’un pool Stratis efface toutes les données qu’il contient."
 ],
 "Rename Stratis pool": [
  null,
  "Renommer le pool Stratis"
 ],
 "Add block devices": [
  null,
  "Ajouter des périphériques block"
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Data": [
  null,
  "Données"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "L'ajout de périphériques block nécessite le déverrouillage du pool."
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool Stratis chiffré"
 ],
 "Delete pool": [
  null,
  "Supprimer le pool"
 ],
 "Encryption tokens": [
  null,
  "Jetons de chiffrement"
 ],
 "Stratis filesystems": [
  null,
  "Systèmes de fichiers Stratis"
 ],
 "Create new filesystem": [
  null,
  "Créer un nouveau système de fichiers"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Ce pool n’utilise pas tout l'espace sur ses périphériques block."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Certains périphériques block de ce pool ont gagné en taille depuis la création du pool. Le pool peut être agrandi en toute sécurité pour utiliser le nouvel espace disponible."
 ],
 "Grow the pool to take all space": [
  null,
  "Agrandir le pool pour qu'il occupe tout l'espace"
 ],
 "This pool is in a degraded state.": [
  null,
  "Ce pool est dans un état dégradé."
 ],
 "No filesystems": [
  null,
  "Aucun système de fichiers"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool de systèmes de fichiers Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Cette phrase secrète constitue la seule manière de déverrouiller le pool et ne peut pas être enlevée."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Ce serveur de clés constitue la seule manière de déverrouiller le pool et ne peut pas être enlevé."
 ],
 "Add passphrase": [
  null,
  "Ajouter mot de passe"
 ],
 "Add keyserver": [
  null,
  "Ajouter un serveur de clés"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "Le dernier jeton ne peut pas être retiré"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Aucun espace restant pour les phrases secrètes ou les serveurs de clés."
 ],
 "Confirm": [
  null,
  "Confirmer"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "L'ajout d'une phrase secrète nécessite le déverrouillage du pool."
 ],
 "Remove passphrase?": [
  null,
  "Supprimer la phrase secrète ?"
 ],
 "Add Tang keyserver": [
  null,
  "Ajouter clé serveur Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "L'ajout d'un serveur de clés nécessite le déverrouillage du pool."
 ],
 "Remove Clevis token?": [
  null,
  "Retirer le jeton Clevis ?"
 ],
 "Metadata format": [
  null,
  "Format des métadonnées"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Les pools dont les métadonnées sont au format V1 peuvent utiliser un maximum de 1 phrase secrète et de 1 serveur de clés."
 ],
 "Overprovisioning": [
  null,
  "Surallocation"
 ],
 "Allow overprovisioning": [
  null,
  "Autoriser la surallocation"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Le système de fichiers virtuel est plus grand que le pool. La surallocation ne peut pas être désactivée."
 ],
 "Allocated": [
  null,
  "Alloué"
 ],
 "Name can not be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "A pool with this name exists already.": [
  null,
  "Un pool portant ce nom existe déjà."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un système de fichiers portant ce nom existe déjà dans ce pool."
 ],
 "Create Stratis pool": [
  null,
  "Créer un pool Stratis"
 ],
 "No block devices are available.": [
  null,
  "Aucun périphérique block n’est disponible."
 ],
 "At least one block device is needed.": [
  null,
  "Au moins un périphérique block est nécessaire."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Chiffrer les données avec une phrase secrète"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Chiffrer les données avec un serveur de clés Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Créer un instantané du système de fichiers $0"
 ],
 "Create snapshot and mount": [
  null,
  "Créer un instantané et le monter"
 ],
 "Create snapshot only": [
  null,
  "Créer un instantané uniquement"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "La suppression d’un système de fichiers entraîne la suppression de toutes les données qu’il contient."
 ],
 "Snapshot": [
  null,
  "Instantané"
 ],
 "Rename filesystem": [
  null,
  "Renommer le système de fichiers"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Définir la limite de taille du système de fichiers virtuel"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limiter la taille du système de fichiers virtuel"
 ],
 "Virtual size limit": [
  null,
  "Taille virtuelle limite"
 ],
 "Virtual size": [
  null,
  "Taille virtuelle"
 ],
 "Create RAID device": [
  null,
  "Créer Périphérique RAID"
 ],
 "RAID level": [
  null,
  "Niveau RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Bande)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Miroir)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Parité dédiée)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Parité répartie)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Double parité répartie)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Bande de miroirs)"
 ],
 "Chunk size": [
  null,
  "Taille des blocs"
 ],
 "4 KiB": [
  null,
  "4 Kio"
 ],
 "8 KiB": [
  null,
  "8 Kio"
 ],
 "16 KiB": [
  null,
  "16 Kio"
 ],
 "32 KiB": [
  null,
  "32 Kio"
 ],
 "64 KiB": [
  null,
  "64 Kio"
 ],
 "128 KiB": [
  null,
  "128 Kio"
 ],
 "512 KiB": [
  null,
  "512 Kio"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 Mio"
 ],
 "At least $0 disk is needed.": [
  null,
  "Au moins $0 disque est nécessaire.",
  "Au moins $0 disques sont nécessaires."
 ],
 "MDRAID disk": [
  null,
  "Disque MDRAID"
 ],
 "In sync": [
  null,
  "En sync"
 ],
 "Spare": [
  null,
  "De rechange"
 ],
 "Recovering": [
  null,
  "Recouvrement"
 ],
 "Write-mostly": [
  null,
  "Écriture - le plus souvent"
 ],
 "Blocked": [
  null,
  "Bloqué"
 ],
 "Unknown ($0)": [
  null,
  "Inconnu ( $0 )"
 ],
 "The MDRAID device must be running": [
  null,
  "Le périphérique MDRAID doit être en cours d'exécution"
 ],
 "MDRAID device is recovering": [
  null,
  "Le périphérique MDRAID est en cours de récupération"
 ],
 "Need a spare disk": [
  null,
  "Disque supplémentaire nécessaire"
 ],
 "Last disk can not be removed": [
  null,
  "Impossible de retirer le dernier disque"
 ],
 "MDRAID device": [
  null,
  "Périphérique MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmer l'arrêt de $0"
 ],
 "Stop device": [
  null,
  "Arrêter le périphérique"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "La suppression efface toutes les données d’un périphérique MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Le périphérique MDRAID doit être en cours d'exécution"
 ],
 "Add disk": [
  null,
  "Ajouter un disque"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ( $0 )"
 ],
 "$0 disks": [
  null,
  "$0 disques"
 ],
 "$0 chunk size": [
  null,
  "blocs de taille $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Le périphérique MDRAID est dans un état dégradé"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Ce périphérique MDRAID n'a pas de bitmap d'intention d'écriture. Une telle bitmap peut réduire les temps de synchronisation de façon significative."
 ],
 "Add a bitmap": [
  null,
  "Ajouter une bitmap"
 ],
 "No disks found": [
  null,
  "Aucun disque trouvé"
 ],
 "MDRAID disks": [
  null,
  "Disques MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "La suppression efface toutes les données d’un périphérique VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "La création de ce périphérique VDO n’est pas terminée et l’appareil ne peut pas être utilisé."
 ],
 "Remove device": [
  null,
  "Supprimer le périphérique"
 ],
 "Grow to take all space": [
  null,
  "Augmenter en vue de prendre tout l’espace"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Ce périphérique VDO n’utilise pas tout son périphérique de sauvegarde."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Seulement $0 de $1 sont utilisés."
 ],
 "Grow logical size of $0": [
  null,
  "Augmenter la taille logique de $0"
 ],
 "Physical": [
  null,
  "Physique"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 données + $1 surcharge utilisée de $2 ( $3 )"
 ],
 "Logical": [
  null,
  "Logique"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 utilisé de $1 ($2 enregistré)"
 ],
 "Index memory": [
  null,
  "Mémoire de l’index"
 ],
 "SMART self-test of $target": [
  null,
  "Autotest SMART de $target"
 ],
 "Ejecting $target": [
  null,
  "Éjecter $target"
 ],
 "Unlocking $target": [
  null,
  "Déverrouillage $target"
 ],
 "Locking $target": [
  null,
  "Verrouillage de $target"
 ],
 "Modifying $target": [
  null,
  "Modifier $target"
 ],
 "Resizing $target": [
  null,
  "Redimensionnement $target"
 ],
 "Starting swapspace $target": [
  null,
  "Démarrage de swapspace $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Arrêt de l’espace d’échange $target"
 ],
 "Mounting $target": [
  null,
  "Montage de $target"
 ],
 "Unmounting $target": [
  null,
  "Démonter $target"
 ],
 "Checking $target": [
  null,
  "Vérification $target"
 ],
 "Repairing $target": [
  null,
  "Réparer $target"
 ],
 "Erasing $target": [
  null,
  "Effacement de $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Création d’un système de fichiers sur $target"
 ],
 "Setting up loop device $target": [
  null,
  "Configuration du périphérique de boucle $target"
 ],
 "Deleting $target": [
  null,
  "Suppression de $target"
 ],
 "Creating partition $target": [
  null,
  "Création de la partition $target"
 ],
 "Cleaning up for $target": [
  null,
  "Nettoyage pour $target"
 ],
 "Securely erasing $target": [
  null,
  "Effacer en toute sécurité $target"
 ],
 "Very securely erasing $target": [
  null,
  "Effacement très sécurisé de $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Arrêt du périphérique RAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Démarrage du périphérique MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Marquage de $target comme défectueux"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Supprimer $target du périphérique MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Création d’un périphérique MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Vérification du périphérique RAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Vérification et réparation du périphérique MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Restauration du périphérique MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronisation du périphérique MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Activation de $target"
 ],
 "Deactivating $target": [
  null,
  "Désactivation de $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Création d’un instantané de $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Création du groupe de volumes LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Suppression du groupe de volumes LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Ajout d’un volume physique à $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Suppression du volume physique de $target"
 ],
 "Emptying $target": [
  null,
  "$target en cours de vidage"
 ],
 "Creating logical volume $target": [
  null,
  "Création du volume logique $target"
 ],
 "Renaming $target": [
  null,
  "Renommer $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Opération « $operation » sur $target"
 ],
 "unknown target": [
  null,
  "cible inconnue"
 ],
 "Jobs": [
  null,
  "Tâches"
 ],
 "Reading": [
  null,
  "Lecture en cours"
 ],
 "Writing": [
  null,
  "Écriture"
 ],
 "Install Stratis support": [
  null,
  "Installer la prise en charge de Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Le paquet $0 doit être installé pour pouvoir créer des pools Stratis."
 ],
 "Install NFS support": [
  null,
  "Installer la prise en charge NFS"
 ],
 "Create MDRAID device": [
  null,
  "Créer un périphérique MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Créer un groupe de volumes LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Modifier le nom de l’initiateur iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Ajouter un portail iSCSI"
 ],
 "Local storage": [
  null,
  "Stockage local"
 ],
 "Networked storage": [
  null,
  "Stockage réseau"
 ],
 "Create storage device": [
  null,
  "Créer un périphérique de stockage"
 ],
 "No storage found": [
  null,
  "Aucun stockage trouvé"
 ],
 "Server address cannot be empty.": [
  null,
  "L’adresse du serveur ne peut pas être vide."
 ],
 "Next": [
  null,
  "Suivant"
 ],
 "Invalid username or password": [
  null,
  "Nom d’utilisateur ou mot de passe non valide"
 ],
 "Unknown host name": [
  null,
  "Nom d’hôte inconnu"
 ],
 "Unable to reach server": [
  null,
  "Impossible d’atteindre le serveur"
 ],
 "Available targets on $0": [
  null,
  "Cibles disponibles sur $0"
 ],
 "Authentication required": [
  null,
  "Authentification requise"
 ],
 "iSCSI portal": [
  null,
  "Portail iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Lecteurs iSCSI"
 ],
 "No drives found": [
  null,
  "Aucun lecteur trouvé"
 ],
 "Target": [
  null,
  "Cible"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Les sauvegardes VDO ne peuvent pas être plus petits"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Les blockdevs Stratis ne peuvent pas être réduits"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Les données non reconnues ne peuvent pas être plus petites ici."
 ],
 "Unlock before resizing": [
  null,
  "Déverrouillez-le avant de le redimensionner"
 ],
 "$0 can not be resized here": [
  null,
  "$0 ne peut pas être redimensionné ici"
 ],
 "$0 can not be resized": [
  null,
  "$0 ne peut pas être redimensionné"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 impossible à réduire"
 ],
 "$0 can not be made larger": [
  null,
  "$0 ne peuvent pas être agrandis"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Les volumes physiques ne peuvent pas être redimensionnés ici"
 ],
 "Swap can not be resized here": [
  null,
  "Le swap ne peut pas être redimensionné ici"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Les données non reconnues ne peuvent pas être plus petites ici"
 ],
 "Activate before resizing": [
  null,
  "Activer avant de redimensionner"
 ],
 "Grow logical volume": [
  null,
  "Augmenter le volume logique"
 ],
 "Grow partition": [
  null,
  "Agrandir la partition"
 ],
 "grow": [
  null,
  "développer"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exactement $0 volumes physiques doivent être sélectionné"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Le redimensionnement d'un système de fichiers chiffré nécessite le déverrouillage du disque. Veuillez fournir la phrase secrète du disque actuel."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exactement $0 volumes physiques doivent être sélectionnés, un pour chaque bande du volume logique."
 ],
 "Shrink logical volume": [
  null,
  "Réduire le volume logique"
 ],
 "shrink": [
  null,
  "réduire"
 ],
 "Unformatted data": [
  null,
  "Données non formatées"
 ],
 "Block device": [
  null,
  "Périphérique block"
 ],
 "Device number": [
  null,
  "Numéro du périphérique"
 ],
 "Create partition on $0": [
  null,
  "Créer une partition sur $0"
 ],
 "Format $0": [
  null,
  "Formater $0"
 ],
 "No filesystem": [
  null,
  "Aucun système de fichiers"
 ],
 "(recommended)": [
  null,
  "(recommandé)"
 ],
 "No encryption": [
  null,
  "Aucun chiffrement"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Réutiliser le chiffrement existant ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Réutiliser le chiffrement existant"
 ],
 "format": [
  null,
  "formater"
 ],
 "Format and mount": [
  null,
  "Format et montage"
 ],
 "Format only": [
  null,
  "Format uniquement"
 ],
 "Format": [
  null,
  "Formater"
 ],
 "Create and start": [
  null,
  "Créer et démarrer"
 ],
 "Format and start": [
  null,
  "Formater et démarrer"
 ],
 "Store passphrase": [
  null,
  "Stocker la phrase secrète"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Le disque doit être déverrouillé avant le formatage. Veuillez fournir une phrase secrète existante."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Le formatage efface toutes les données d’un périphérique de stockage."
 ],
 "Unrecognized data": [
  null,
  "Données non reconnues"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Le stockage ne peut pas être géré sur ce système."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "octets"
 ]
});
