cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "ຕົວທ່ອງໄຟລ໌"
 ],
 "files": [
  null,
  "ໄຟລ໌"
 ],
 "explorer": [
  null,
  "explorer"
 ],
 "filesystem": [
  null,
  "ລະບົບໄຟລ໌"
 ]
});
