cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "eo",
  "language-direction": "ltr"
 }
});
