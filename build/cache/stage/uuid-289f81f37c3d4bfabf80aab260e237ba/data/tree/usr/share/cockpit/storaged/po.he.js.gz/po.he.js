cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "Set": [
  null,
  "הגדרה"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "Permission denied": [
  null,
  "ההרשאה נדחתה"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit דיווח את קוד השגיאה $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Dismiss": [
  null,
  "התעלמות"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "none": [
  null,
  "אין"
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Running": [
  null,
  "פועל"
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "State": [
  null,
  "מצב"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Started": [
  null,
  "הופעל"
 ],
 "Delete group": [
  null,
  "מחיקת קבוצה"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "Service": [
  null,
  "שירות"
 ],
 "Disconnect": [
  null,
  "ניתוק"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "$0 disk is missing": [
  null,
  "כונן אחד חסר",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים"
 ],
 "Location": [
  null,
  "מקום"
 ],
 "Compression": [
  null,
  "דחיסה"
 ],
 "Storage logs": [
  null,
  "יומני אחסון"
 ],
 "Name cannot be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "השם לא יכול להיות ארוך מ־127 תווים."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "השם לא יכול להכיל את התו ‚$0’."
 ],
 "Name cannot contain whitespace.": [
  null,
  "השם לא יכול להכיל רווח."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "השם לא יכול להיות ארוך מ־$0 תווים"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "השם לא יכול להיות יותר מ־$0 בתים"
 ],
 "$name (from $host)": [
  null,
  "$name (מ־$host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "מאגר לכרכים לוגיים רזים"
 ],
 "Thin logical volume": [
  null,
  "כרך לוגי צר"
 ],
 "Logical volume (snapshot)": [
  null,
  "כרך לוגי (תמונת מצב)"
 ],
 "Logical volume": [
  null,
  "כרך לוגי"
 ],
 "MDRAID device $0": [
  null,
  "התקן MDRAID‏ $0"
 ],
 "LVM2 volume group $0": [
  null,
  "קבוצת כרכים LVM2‏ $0"
 ],
 "VDO device $0": [
  null,
  "התקן VDO‏ $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "כרך לוגי מוצפן בגודל $0"
 ],
 "Encrypted partition of $0": [
  null,
  "מחיצה מוצפנת בגודל $0"
 ],
 "Logical volume of $0": [
  null,
  "כרך לוגי בגודל $0"
 ],
 "Partition of $0": [
  null,
  "מחיצה של $0"
 ],
 "Encrypted $0": [
  null,
  "$0 מוצפן"
 ],
 "unpartitioned space on $0": [
  null,
  "מקום שאינו מחיצה ב־$0"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "remove from btrfs volume": [
  null,
  "הסרה מכרך btrfs"
 ],
 "stop": [
  null,
  "עצירה"
 ],
 "remove from MDRAID": [
  null,
  "הסרה מה־MDRAID"
 ],
 "remove from LVM2": [
  null,
  "הסרה מ־LVM2"
 ],
 "btrfs volume": [
  null,
  "כרך btrfs"
 ],
 "UUID": [
  null,
  "מזהה ייחודי"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "השם לא יכול להיות ארוך מ־255 תווים."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "השם לא יכול להכיל את התו ‚/’."
 ],
 "Create and mount": [
  null,
  "יצירה ועיגון"
 ],
 "Create only": [
  null,
  "יצירה בלבד"
 ],
 "Create subvolume": [
  null,
  "יצירת תת־כרך"
 ],
 "Mount Point": [
  null,
  "נקודת עיגון"
 ],
 "delete": [
  null,
  "מחיקה"
 ],
 "Edit mount point": [
  null,
  "עריכת נקודת עיגון"
 ],
 "Unmount": [
  null,
  "ניתוק"
 ],
 "Mount": [
  null,
  "עיגון"
 ],
 "btrfs subvolume": [
  null,
  "תת־כרך btrfs"
 ],
 "Mount point": [
  null,
  "נקודת עיגון"
 ],
 "No subvolumes": [
  null,
  "אין תת־כרכים"
 ],
 "Snapshots": [
  null,
  "תמונות מצב"
 ],
 "No snapshots found": [
  null,
  "לא נמצאו תמונות מצב"
 ],
 "snapshot": [
  null,
  "תמונת מצב"
 ],
 "$0 is in use": [
  null,
  "$0 בשימוש"
 ],
 "Permanently delete $0?": [
  null,
  "למחוק את $0 לצמיתות?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "מחיקה מוחקת את כל הנתונים מכרך btrfs."
 ],
 "Delete filesystem": [
  null,
  "מחיקת מערכת קבצים"
 ],
 "Change label": [
  null,
  "החלפת תווית"
 ],
 "Filesystem is mounted read-only": [
  null,
  "מערכת הקבצים מעוגנת לקריאה בלבד"
 ],
 "Label": [
  null,
  "תווית"
 ],
 "Capacity": [
  null,
  "קיבולת"
 ],
 "No devices found": [
  null,
  "לא נמצאו התקנים"
 ],
 "Aborted": [
  null,
  "בוטל לחלוטין"
 ],
 "In progress": [
  null,
  "בתהליך"
 ],
 "Did not complete": [
  null,
  "לא הושלם"
 ],
 "Failed (Electrical)": [
  null,
  "נכשל (חשמלי)"
 ],
 "Failed (Damaged)": [
  null,
  "נכשל (נפגם)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "בוטל באופן גורף על ידי איפוס רמת בקר"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "אירעה שגיאה מהותית במהלך פעולת הבדיקה העצמית"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "Degraded": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  "גיבוי זיכרון נדיף נכשל"
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Abort test": [
  null,
  "ביטול גורף של הבדיקה"
 ],
 "Disk is failing": [
  null,
  "הכונן נכשל"
 ],
 "Disk is OK": [
  null,
  "הכונן תקין"
 ],
 "Assessment": [
  null,
  "הערכה"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "$0 hours": [
  null,
  "$0 שעות"
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Attributes failing": [
  null,
  "מאפיינים כושלים"
 ],
 "Media drive": [
  null,
  "כונן אחסון"
 ],
 "Solid State Drive": [
  null,
  ""
 ],
 "Hard Disk Drive": [
  null,
  "כונן קשיח מגנטי"
 ],
 "Drive": [
  null,
  "כונן"
 ],
 "Device health (SMART)": [
  null,
  "תקינות ההתקן (SMART)"
 ],
 "Firmware version": [
  null,
  "גרסת קושחה"
 ],
 "Serial number": [
  null,
  "מספר סידורי"
 ],
 "No media inserted": [
  null,
  "לא הוכנס אמצעי מדיה"
 ],
 "Device file": [
  null,
  "קובץ התקן"
 ],
 "Multipathed devices": [
  null,
  "התקנים מרובי־נתיבים"
 ],
 "Free space": [
  null,
  "מקום פנוי"
 ],
 "Create partition": [
  null,
  "יצירת מחיצה"
 ],
 "Extended partition": [
  null,
  "מחיצה מורחבת"
 ],
 "$0 partitions": [
  null,
  "מחיצות $0"
 ],
 "Partitions": [
  null,
  "מחיצות"
 ],
 "No partitions found": [
  null,
  "לא נמצאו מחיצות"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "מחיקת מחיצה תמחק את כל הנתונים שבה."
 ],
 "No free space after this partition": [
  null,
  "אין מקום פנוי אחרי המחיצה הזאת"
 ],
 "EFI system partition": [
  null,
  "מחיצת EFI של המערכת"
 ],
 "BIOS boot partition": [
  null,
  "מחיצת טעינה של BIOS"
 ],
 "Partition": [
  null,
  "מחיצה"
 ],
 "Shrink": [
  null,
  "כיווץ"
 ],
 "Grow": [
  null,
  "הגדלה"
 ],
 "Linux swap space": [
  null,
  "שטח החלפה של לינוקס"
 ],
 "Linux filesystem data": [
  null,
  "נתוני מערכת קבצים של לינוקס"
 ],
 "Custom": [
  null,
  "מותאם אישית"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  ""
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  ""
 ],
 "Custom type": [
  null,
  "סוג מותאם אישית"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "החלפת סוגי מחיצות עלולה למנוע את עליית המערכת."
 ],
 "Grow content": [
  null,
  "הגדלת התוכן"
 ],
 "initialize": [
  null,
  "אתחול"
 ],
 "Initialize disk $0": [
  null,
  "אתחול הכונן $0"
 ],
 "Partitioning": [
  null,
  "חלוקה למחיצות"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "תואם לכל המערכות וההתקנים (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "תואם למערכות ולכוננים חדישים > 2 ט״ב (GPT)"
 ],
 "No partitioning": [
  null,
  "אין חלוקה למחיצות"
 ],
 "Overwrite": [
  null,
  "שכתוב"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "שכתוב על נתונים קיימים באפסים (אטי יותר)"
 ],
 "Initialize": [
  null,
  "אתחול"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "אתחול מוחק את כל הנתונים בכונן."
 ],
 "Device is read-only": [
  null,
  "ההתקן הוא לקריאה בלבד"
 ],
 "Create partition table": [
  null,
  "יצירת טבלת מחיצות"
 ],
 "Size must be a number": [
  null,
  "הגודל חייב להיות מספר"
 ],
 "Size cannot be zero": [
  null,
  "הגודל לא יכול להיות אפס"
 ],
 "Size cannot be negative": [
  null,
  "הגודל לא יכול להיות שלילי"
 ],
 "Size is too large": [
  null,
  "הגודל גדול מדי"
 ],
 "Size must be at least $0": [
  null,
  "הגודל חייב להיות לפחות $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "כרך פיזי של קבוצת כרכים מסוג LVM2"
 ],
 "member of MDRAID device": [
  null,
  "חבר בהתקן MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "התקן גיבוי להתקן VDO"
 ],
 "member of Stratis pool": [
  null,
  "חבר במאגר Stratis"
 ],
 "device of btrfs volume": [
  null,
  "התקן של כרך btrfs"
 ],
 "This device is currently in use.": [
  null,
  "ההתקן הזה בשימוש כרגע."
 ],
 "Device": [
  null,
  "התקן"
 ],
 "Use": [
  null,
  "שימוש"
 ],
 "Services using the location": [
  null,
  "שירותים שמשתמשים במיקום"
 ],
 "Processes using the location": [
  null,
  "תהליכים שמשתמשים במיקום"
 ],
 "Currently in use": [
  null,
  "בשימוש כרגע"
 ],
 "(Not part of target)": [
  null,
  "(לא חלק מהיעד)"
 ],
 "These changes will be made:": [
  null,
  "אלו השינויים שיתבצעו:"
 ],
 "Action": [
  null,
  "פעולה"
 ],
 "Important data might be deleted:": [
  null,
  "נתונים חשובים עלולים להימחק:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "התהליכים והשירותים הקשורים ייעצרו בכוח."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "התהליכים הקשורים ייעצרו בכוח."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "השירותים הקשורים ייעצרו בכוח."
 ],
 "$0 used, $1 total": [
  null,
  "$0 בשימוש, $1 בסך הכול"
 ],
 "Device contains unrecognized data": [
  null,
  "ההתקן מכיל נתונים לא מזוהים"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "ארצה לאשר שהנתונים האלה יאבדו לעד"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "נקודת העיגון $0 משמשת את התהליכים האלה:"
 ],
 "PID": [
  null,
  "מזהה תהליך"
 ],
 "Command": [
  null,
  "פקודה"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "נקודת העיגון $0 משמשת את השירותים האלה:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "התהליכים והשירותים המוצגים ייעצרו בכוח."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "התהליכים המוצגים ייעצרו בכוח."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "אי אפשר לעצור בכוח את השירותים שמופיעים."
 ],
 "Sorry": [
  null,
  "מחילה"
 ],
 "Usage of $0": [
  null,
  "שימוש מתוך $0"
 ],
 "LVM2 VDO pool": [
  null,
  "מאגר LVM2 VDO"
 ],
 "Data used": [
  null,
  "נתונים בשימוש"
 ],
 "Metadata used": [
  null,
  "נתוני על בשימוש"
 ],
 "Use compression": [
  null,
  "להשתמש בדחיסה"
 ],
 "Deduplication": [
  null,
  "הסרת כפילות"
 ],
 "Use deduplication": [
  null,
  "להשתמש בהסרת כפילות"
 ],
 "Rename volume group": [
  null,
  "שינוי שם של קבוצת כרכים"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "מחיקה מוחקת את כל הנתונים בקבוצת כרכים."
 ],
 "Create snapshot": [
  null,
  "יצירת תמונת מצב"
 ],
 "Add disks": [
  null,
  "הוספת כוננים"
 ],
 "Disks": [
  null,
  "כוננים"
 ],
 "No disks are available.": [
  null,
  "אין כוננים זמינים."
 ],
 "At least one disk is needed.": [
  null,
  "נדרש כונן אחד לפחות."
 ],
 "Volume group is missing physical volumes": [
  null,
  "לקבוצת הכרכים חסרים כרכים פיזיים"
 ],
 "No free space": [
  null,
  "אין מקום פנוי"
 ],
 "LVM2 volume group": [
  null,
  "קבוצת כרכים ב־LVM2"
 ],
 "Add physical volume": [
  null,
  "הוספת כרך פיזי"
 ],
 "LVM2 logical volumes": [
  null,
  "כרכים לוגיים מסוג LVM2"
 ],
 "Create new logical volume": [
  null,
  "יצירת כרך לוגי חדש"
 ],
 "No logical volumes": [
  null,
  "אין כרכים לוגיים"
 ],
 "Remove missing physical volumes?": [
  null,
  "להסיר את הכרכים הפיזיים החסרים?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  ""
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "לא ניתן לשנות שם לקבוצת כרכים שחסרים לה כרכים פיזיים."
 ],
 "Physical volumes": [
  null,
  "כרכים פיזיים"
 ],
 "No physical volumes found": [
  null,
  "לא נמצאו כרכים פיזיים"
 ],
 "LVM2 physical volumes": [
  null,
  "כרכי LVM2 פיזיים"
 ],
 "Rename logical volume": [
  null,
  "שינוי שם של כרך פיזי"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "מחיקת כרך לוגי תמחק את כל הנתונים שבו."
 ],
 "Unable to repair logical volume $0": [
  null,
  "לא ניתן לתקן את הכרך הלוגי $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  "חובה לבחור ב־$0 נוסף"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  ""
 ],
 "Physical Volumes": [
  null,
  "כרכים פיזיים"
 ],
 "Repair": [
  null,
  ""
 ],
 "deactivate": [
  null,
  "השבתה"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "להשבית את הכרך הלוגי $0/$1?"
 ],
 "Deactivate": [
  null,
  "השבתה"
 ],
 "Not enough space to grow": [
  null,
  "אין מספיק מקום כדי לגדול"
 ],
 "LVM2 logical volume": [
  null,
  "כרך לוגי מסוג LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Mirrored (RAID 1)": [
  null,
  "שיקוף מראה (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "פיזור+זוגיות בכונן ייעודי (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "פיזור+זוגיות מפוזרת (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "פיזור+קוד ריד-סולומון (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "בכרך לוגי זה לא נעשה שימוש מלא על ידי התוכן שלו."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "גודל הכרך הוא $0. גודל התוכן הוא $1."
 ],
 "Shrink volume": [
  null,
  "כיווץ כרך"
 ],
 "Layout": [
  null,
  "פריסה"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  ""
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "$0 synchronized": [
  null,
  "$0 מסונכרן"
 ],
 "Create volume group": [
  null,
  "יצירת קבוצת כרכים"
 ],
 "LVM2 physical volume": [
  null,
  "כרך LVM2 פיזי"
 ],
 "Last cannot be removed": [
  null,
  "לא ניתן להסיר את האחרון"
 ],
 "Not enough free space": [
  null,
  "אין מספיק מקום פנוי"
 ],
 "Volume group": [
  null,
  "קבוצת כרכים"
 ],
 "Create thin volume": [
  null,
  "יצירת כרך רזה"
 ],
 "Not enough space": [
  null,
  "אין מספיק מקום"
 ],
 "Inactive logical volume": [
  null,
  "כרך לוגי לא פעיל"
 ],
 "Activate": [
  null,
  "הפעלה"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "שגיאה פנימית - הכרך הלוגי הזה מסומן כפעיל ואמור להיות משויך אליו התקן אחסון (בלוק). עם זאת, לא נמצא התקן אחסון שכזה."
 ],
 "Installing $0 would remove $1.": [
  null,
  "התקנת $0 תסיר את $1."
 ],
 "Installing packages": [
  null,
  "חבילות מותקנות"
 ],
 "Block device for filesystems": [
  null,
  "התקן בלוק למערכות הפעלה"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "מאגר לכרכים באפסנה צרה"
 ],
 "Linear": [
  null,
  "קווי"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "כרך מערכת קבצים VDO (דחיסה/הסרת כפולים)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו בכרכים הפיזיים הנבחרים באופן מתחלף כדי לשפר את הביצועים. יש לבחור לפחות שני כרכים."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו כשני עותקים ויותר בכרכים הפיזיים הנבחרים, כדי לשפר את האמינות. יש לבחור בשני כרכים לפחות."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו כשני עותקים וגם באופן מתחלף בכרכים הפיזיים הנבחרים כדי לשבר את האמינות ואת הביצועים. יש לבחור בארבעה כרכים לפחות."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "הנתונים יאוחסנו בכרכים הפיזיים הנבחרים כדי שאם אחד מהם יושבת לא תהיה השפעה על המידע. יש לבחור לפחות שלושה כרכים."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "כל $0 הכרכים הפיזיים הנבחרים נחוצים לפריסה הנבחרת."
 ],
 "Create logical volume": [
  null,
  "יצירת כרך לוגי"
 ],
 "Purpose": [
  null,
  "תכלית"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "החבילה $0 תותקן כדי ליצור התקני VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  ""
 ],
 "Logical size": [
  null,
  "גודל לוגי"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ניתן לחסוך במקום על ידי דחיסת בלוקים עם LZ4 באופן פרטני"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ניתן לחסוך במקום על ידי אחסון בלוקים עם נתונים זהים פעם אחת בלבד"
 ],
 "Creating VDO device": [
  null,
  "נוצר התקן VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "עיגון NFS זה נמצא בשימוש ואפשר לשנות רק את האפשרויות שלו."
 ],
 "NFS mount": [
  null,
  "עיגון NFS"
 ],
 "New NFS mount": [
  null,
  "עיגון NFS חדש"
 ],
 "Server address": [
  null,
  "כתובת השרת"
 ],
 "Server cannot be empty.": [
  null,
  "השרת לא יכול להיות ריק."
 ],
 "Path on server": [
  null,
  "נתיב בשרת"
 ],
 "Path on server cannot be empty.": [
  null,
  "הנתיב בשרת לא יכול להיות ריק."
 ],
 "Path on server must start with \"/\".": [
  null,
  "הנתיב בשרת חייב להתחיל ב־„/”."
 ],
 "Local mount point": [
  null,
  "נקודת עגינה מקומית"
 ],
 "Mount point cannot be empty.": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה."
 ],
 "Mount point must start with \"/\".": [
  null,
  "נקודת העיגון חייבת להתחיל ב־„/”."
 ],
 "Mount options": [
  null,
  "אפשרויות עיגון"
 ],
 "Mount at boot": [
  null,
  "לעגן בעלייה"
 ],
 "Mount read only": [
  null,
  "עיגון לקריאה בלבד"
 ],
 "Custom mount options": [
  null,
  "אפשרויות עיגון מותאמות אישית"
 ],
 "Unable to unmount filesystem": [
  null,
  "לא ניתן לנתק את מערכת הקבצים"
 ],
 "Stop and unmount": [
  null,
  "עצירה וניתוק"
 ],
 "Unable to remove mount": [
  null,
  "לא ניתן להסיר עיגון"
 ],
 "Stop and remove": [
  null,
  "עצירה והסרה"
 ],
 "(not mounted)": [
  null,
  "(לא מעוגן)"
 ],
 "Start multipath": [
  null,
  "הפעלת רב נתיבי"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "יש התקנים עם מגוון נתיבים במערכת אך שירות ריבוי הנתיבים אינו פועל."
 ],
 "Category": [
  null,
  "קטגוריה"
 ],
 "more info": [
  null,
  "פרטים נוספים"
 ],
 "Encryption": [
  null,
  "הצפנה"
 ],
 "encrypted": [
  null,
  "מוצפן"
 ],
 "Last modified: $0": [
  null,
  "שינוי אחרון: $0"
 ],
 "Stored passphrase": [
  null,
  "מילת צופן מאוחסנת"
 ],
 "Encryption options": [
  null,
  "אפשרויות הצפנה"
 ],
 "Encryption type": [
  null,
  "סוג הצפנה"
 ],
 "Cleartext device": [
  null,
  "התקן טקסט גלוי"
 ],
 "yes": [
  null,
  "כן"
 ],
 "Disk passphrase": [
  null,
  "מילת צופן לכונן"
 ],
 "Passphrase cannot be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Unlocking disk": [
  null,
  "הכונן משוחרר"
 ],
 "Checking for $0 package": [
  null,
  "מתבצע איתור של החבילה $0"
 ],
 "The $0 package must be installed.": [
  null,
  "החבילה $0 חייבת להיות מותקנת."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "החבילה $0 אינה זמינה באף מאגר."
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "מתבצעת בדיקה לאיתור תמיכה ב־NBDE ב־initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "יש לייצר את ה־initrd מחדש."
 ],
 "Regenerating initrd": [
  null,
  "initrd נוצר מחדש"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "rd.neednet=1 מתווספת לשורת הפקודה של הליבה"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "„$0” נוספת לאפשרויות מערכת הקבצים"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "„$0” נוספה לאפשרויות הצפנה"
 ],
 "Enabling $0": [
  null,
  "$0 מופעל"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "הוספת הצפנת כונן תלוית רשת"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "המערכת לא תומכת כרגע בשחרור מערכת הקבצים עם שרת מפתחות Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "המערכת לא תומכת כרגע בשחרור מערכת הקבצים עם שרת מפתחות Tang במהלך העלייה."
 ],
 "These additional steps are necessary:": [
  null,
  "הצעדים הנוספים האלו הכרחיים:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שמירת מילת צופן חדשה דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Fix NBDE support": [
  null,
  "תיקון תמיכה ב־NBDE"
 ],
 "Adding key": [
  null,
  "נוסף מפתח"
 ],
 "Key source": [
  null,
  "מקור מפתח"
 ],
 "Repeat passphrase": [
  null,
  "חזרה על מילת הצופן"
 ],
 "Passphrase": [
  null,
  "מילת צופן"
 ],
 "Tang keyserver": [
  null,
  "שרת מפתחות Tang"
 ],
 "New passphrase": [
  null,
  "מילת צופן חדשה"
 ],
 "Passphrases do not match": [
  null,
  "מילות הצופן אינן תואמות"
 ],
 "Keyserver address": [
  null,
  "כתובת שרת מפתחות"
 ],
 "Change passphrase": [
  null,
  "החלפת מילת צופן"
 ],
 "Old passphrase": [
  null,
  "מילת צופן ישנה"
 ],
 "Edit Tang keyserver": [
  null,
  "עריכת שרת מפתחות Tang"
 ],
 "Verify key": [
  null,
  "אימות מפתח"
 ],
 "Trust key": [
  null,
  "לתת אמון במפתח"
 ],
 "Passphrase can not be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "הסרת מילת הצופן עשויה למנוע את השחרור של $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "אישור הסרה עם מילת צופן חלופית"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "הסרת מילת צופן ללא אישור של מילת צופן אחרת עשוי למנוע שחרור או את ניהול המפתחות במקרה שמילות צופן נוספות נשכחו או שאבדו."
 ],
 "Passphrase from any other key slot": [
  null,
  "מילת צופן מכל משבצת מפתחות אחרת"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "להסיר את מילת הצופן מעל משבצת המפתחות $0?"
 ],
 "Remove $0?": [
  null,
  "להסיר את $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "להסיר את שרת המפתחות Tang?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "המשתמש שמחובר כרגע אינו מורשה לצפות במידע על מפתחות."
 ],
 "No keys added": [
  null,
  "לא נוספו מפתחות"
 ],
 "Slot $0": [
  null,
  "משבצת $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "עריכת מפתח דורשת משבצת פנויה"
 ],
 "The last key slot can not be removed": [
  null,
  "לא ניתן להסיר את משבצת המפתח האחרונה"
 ],
 "Keyserver": [
  null,
  "שרת מפתחות"
 ],
 "Unknown type": [
  null,
  "סוג לא ידוע"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "משבצות מפתח עם סוגים בלתי מוכרים אינן ניתנות לעריכה כאן"
 ],
 "Keys": [
  null,
  "מפתחות"
 ],
 "$0 slot remains": [
  null,
  "נותרה משבצת אחת",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות"
 ],
 "No available slots": [
  null,
  "אין משבצות פנויות"
 ],
 "No free key slots": [
  null,
  "אין משבצות מפתח פנויות"
 ],
 "Locked data": [
  null,
  "נתונים נעולים"
 ],
 "lock": [
  null,
  "נעילה"
 ],
 "Lock $0?": [
  null,
  "לנעול את $0?"
 ],
 "Address cannot be empty": [
  null,
  "הכתובת לא יכולה להיות ריקה"
 ],
 "Address is not a valid URL": [
  null,
  "הכתובת אינה תקנית"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "בדיקת גיבוב המפתח מול שרת ה־Tang."
 ],
 "How to check": [
  null,
  "איך לבדוק"
 ],
 "In a terminal, run: ": [
  null,
  "במסוף יש להריץ: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "ההעתקה ללוח הגזירים הצליחה!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "כדאי לבדוק שגיבוב ה־SHA-256 או SHA-1 מהפקודה תואם לחלונית הזאת."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  ""
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "תת־כרך btrfs‏ $0 מתוך $1"
 ],
 "Mount point cannot be empty": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה"
 ],
 "Mount point is already used for $0": [
  null,
  "נקודת העיגון כבר משמשת לטובת $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "מערכות הקבצים כבר מעוגנות תחת נקודת העיגון הזאת."
 ],
 "Please unmount them first.": [
  null,
  ""
 ],
 "read only": [
  null,
  "קריאה בלבד"
 ],
 "never mount at boot": [
  null,
  "לעולם לא לעגן בעלייה"
 ],
 "after network": [
  null,
  "לאחר הרשת"
 ],
 "ignore failure": [
  null,
  "התעלמות מכשל"
 ],
 "stop boot on failure": [
  null,
  "עצירת העלייה בעת כשל"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "למערכת הקבצים אין נקודת עגינה קבועה."
 ],
 "The filesystem is not mounted.": [
  null,
  "מערכת הקבצים אינה מעוגנת."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "מערכת ההפעלה תשוחרר ותעוגן בעלייה הבאה. יכול להיות שצריך למלא מילת צופן."
 ],
 "(no assigned mount point)": [
  null,
  "(אין נקודת עגינה מוקצית)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך תעוגן למיקום $1 עם העלייה הבאה של המערכת."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "לעגן אוטומטית אל $0 בזמן העלייה"
 ],
 "Mount on $0 now": [
  null,
  "לעגן אל $0 כעת"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "מערכת הקבצים אינה מעוגנת כעת אך היא תעוגן עם ההפעלה הבאה של המערכת."
 ],
 "Do not mount automatically on boot": [
  null,
  "לא לעגן אוטומטית עם העלייה"
 ],
 "Mount now": [
  null,
  "לעגן כעת"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת כעת אך העיגון ינותק לאחר העלייה הבאה של המערכת."
 ],
 "Mount also automatically on boot": [
  null,
  "לעגן אוטומטית גם עם העלייה"
 ],
 "Unmount now": [
  null,
  "לנתק כעת"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך לא תעוגן עם העלייה הבאה של המערכת."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "מערכת הקבצים מוגדרת להתעגן אוטומטית עם הפעלת המערכת אבל מכולת ההצפנה שלה לא תשוחרר באותו הזמן."
 ],
 "Unlock automatically on boot": [
  null,
  "לשחרר אוטומטית עם העלייה"
 ],
 "Inconsistent filesystem mount": [
  null,
  "עיגון בלתי אחיד של מערכת קבצים"
 ],
 "$0 filesystem": [
  null,
  "מערכת קבצים $0"
 ],
 "Filesystem name": [
  null,
  "שם מערכת קבצים"
 ],
 "Filesystem is locked": [
  null,
  "מערכת הקבצים נעולה"
 ],
 "Mounts before services start": [
  null,
  "מעוגן לפני הפעלת השירותים"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "מתאים לעיגונים מהותיים כגון ‎/var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "העלייה נכשלת אם מערכת הקבצים לא מעוגנת, ובכך נמנעת גישה מרחוק"
 ],
 "Mounts in parallel with services": [
  null,
  "מעוגן במקביל לשירותים"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "העלייה עדיין תצליח כאשר מערכת הקבצים לא מתעגנת"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "מעוגן במקביל לשירותים, אבל אחרי שהרשת זמינה"
 ],
 "Does not mount during boot": [
  null,
  "לא תעוגן עם העלייה"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "חיוני לעיגוני רשות או שדורשים התערבות (כמו מילת צופן)"
 ],
 "At boot": [
  null,
  "עם העלייה"
 ],
 "Mount before services start": [
  null,
  "לעגן לפני הפעלת השירותים"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "לעגן בלי להמתין, התעלמות מכשל"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "לעגן לאחר שהרשת זמינה, להתעלם מכשל"
 ],
 "Do not mount": [
  null,
  "לא לעגן"
 ],
 "Mount filesystem": [
  null,
  "עיגון מערכת קבצים"
 ],
 "Unmount filesystem $0": [
  null,
  "ניתוק מערכת הקבצים $0"
 ],
 "Mount configuration": [
  null,
  "הגדרות עיגון"
 ],
 "Swap": [
  null,
  "החלפה"
 ],
 "Used": [
  null,
  "בשימוש"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "שחרור מאגר Stratis מוצפן"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "נא לספק מילת צופן למאגר על התקני בלוק אלו:"
 ],
 "Stratis pool": [
  null,
  "מאגר Stratis‏"
 ],
 "stopped": [
  null,
  "נעצר"
 ],
 "Block devices": [
  null,
  "התקני בלוק"
 ],
 "No block devices found": [
  null,
  "לא נמצאו התקני אחסון (בלוק)"
 ],
 "cache": [
  null,
  "מטמון"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  ""
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  ""
 ],
 "Create filesystem": [
  null,
  "יצירת מערכת קבצים"
 ],
 "Limit size": [
  null,
  "הגבלת גודל"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "מחיקת מאגר Stratis תמחק את כל הנתונים שהוא מכיל."
 ],
 "Rename Stratis pool": [
  null,
  "שינוי שם למאגר Stratis"
 ],
 "Add block devices": [
  null,
  "הוספת התקני בלוק"
 ],
 "Tier": [
  null,
  "רמה"
 ],
 "Data": [
  null,
  "נתונים"
 ],
 "Cache": [
  null,
  "מכלא"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  ""
 ],
 "Encrypted Stratis pool": [
  null,
  "מאגר Stratis מוצפן"
 ],
 "Delete pool": [
  null,
  "מחיקת מאגר"
 ],
 "Create new filesystem": [
  null,
  "יצירת מערכת קבצים חדשה"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  ""
 ],
 "Grow the pool to take all space": [
  null,
  "להגדיל את המאגר על חשבון כל המקום הפנוי"
 ],
 "This pool is in a degraded state.": [
  null,
  "המאגר הזה נמצא במצב ירוד."
 ],
 "No filesystems": [
  null,
  "אין מערכות קבצים"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  ""
 ],
 "Add passphrase": [
  null,
  "הוספת מילת צופן"
 ],
 "Add keyserver": [
  null,
  "הוספת שרת מפתחות"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  ""
 ],
 "Confirm": [
  null,
  "אישור"
 ],
 "Remove passphrase?": [
  null,
  "להסיר מילת צופן?"
 ],
 "Add Tang keyserver": [
  null,
  "הוספת שרת מפתחות Tang"
 ],
 "Remove Clevis token?": [
  null,
  "להסיר אסימון Clevis?"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  ""
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Allocated": [
  null,
  "מוקצה"
 ],
 "Name can not be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "A pool with this name exists already.": [
  null,
  "כבר קיים מאגר בשם הזה."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "כבר קיימת מערכת קבצים בשם הזה במאגר הזה."
 ],
 "Create Stratis pool": [
  null,
  "יצירת מאגר Stratis"
 ],
 "No block devices are available.": [
  null,
  "אין התקני בלוק זמינים."
 ],
 "At least one block device is needed.": [
  null,
  "נדרש התקן בלוק אחד לפחות."
 ],
 "Encrypt data with a passphrase": [
  null,
  "הצפנת נתונים עם מילת צופן"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "הצפנת הנתונים עם שרת מפתחות Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "יצירת תמונת מצב של מערכת הקבצים $0"
 ],
 "Create snapshot and mount": [
  null,
  "יצירת תמונת מצב ועיגון"
 ],
 "Create snapshot only": [
  null,
  "יצירת תמונת מצב בלבד"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "מחיקת מערכת קבצים תמחק את כל הנתונים שבה."
 ],
 "Snapshot": [
  null,
  "תמונת מצב"
 ],
 "Rename filesystem": [
  null,
  "שינוי שם מערכת קבצים"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Limit virtual filesystem size": [
  null,
  "הגבלת גודל מערכת קבצים וירטואלית"
 ],
 "Virtual size": [
  null,
  "גודל וירטואלי"
 ],
 "Create RAID device": [
  null,
  "יצירת התקן RAID"
 ],
 "RAID level": [
  null,
  "רמת RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (פיזור נתונים)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (שכפול)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (פיזור עם זוגיות בכונן ייעודי)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (פיזור עם זוגיות מפוזרת)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (פיזור עם קוד ריד-סולומון)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (פיזור נתונים משוכפלים)"
 ],
 "Chunk size": [
  null,
  "גודל נתח"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "נדרש כונן אחד לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות."
 ],
 "MDRAID disk": [
  null,
  "כונן MDRAID"
 ],
 "In sync": [
  null,
  "בסנכרון"
 ],
 "Spare": [
  null,
  "עודף"
 ],
 "Recovering": [
  null,
  "מתבצע שיקום"
 ],
 "Write-mostly": [
  null,
  "בעיקר כתיבה"
 ],
 "Blocked": [
  null,
  "חסום"
 ],
 "Unknown ($0)": [
  null,
  "לא ידוע ($0)"
 ],
 "Need a spare disk": [
  null,
  "צריך כונן עודף לגיבוי"
 ],
 "Last disk can not be removed": [
  null,
  "לא ניתן להסיר את הכונן האחרון"
 ],
 "MDRAID device": [
  null,
  "התקן MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "אישור עצירת $0"
 ],
 "Stop device": [
  null,
  "עצירת התקן"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "מחיקה תמחק את כל הנתונים שעל התקן ה־MDRAID."
 ],
 "Add disk": [
  null,
  "הוספת כונן"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 כוננים"
 ],
 "$0 chunk size": [
  null,
  "גודל נתח $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "התקן ה־MDRAID נמצא במצב ירוד"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  ""
 ],
 "Add a bitmap": [
  null,
  "הוספת מפת סיביות"
 ],
 "No disks found": [
  null,
  "לא נמצאו דיסקים"
 ],
 "MDRAID disks": [
  null,
  "כונני MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "מחיקה תמחק את כל הנתונים של התקן ה־VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "יצירת התקן ה־VDO הזה לא הסתיימה ולא ניתן להשתמש בהתקן."
 ],
 "Remove device": [
  null,
  "הסרת התקן"
 ],
 "Grow to take all space": [
  null,
  "להגדיל על חשבון כל המקום הפנוי"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "התקן VDO זה אינו משתמש בכל ההתקן המגבה שלו."
 ],
 "Only $0 of $1 are used.": [
  null,
  "רק $0 מתוך $1 מנוצלים."
 ],
 "Grow logical size of $0": [
  null,
  "להגדיל לגודל לוגי של $0"
 ],
 "Physical": [
  null,
  "פיזי"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 נתונים + $1 תוספת מנוצלים מתוך $2 ($3)"
 ],
 "Logical": [
  null,
  "לוגי"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 בשימוש מתוך $1 ($2 נחסכו)"
 ],
 "Index memory": [
  null,
  "זיכרון אינדקס"
 ],
 "SMART self-test of $target": [
  null,
  "בדיקת SMART עצמית של $0"
 ],
 "Ejecting $target": [
  null,
  "$target נשלף כעת"
 ],
 "Unlocking $target": [
  null,
  "$target משוחרר"
 ],
 "Locking $target": [
  null,
  "$target ננעל"
 ],
 "Modifying $target": [
  null,
  "מתבצע שינוי ב־$target"
 ],
 "Resizing $target": [
  null,
  "הגודל של $target משתנה"
 ],
 "Starting swapspace $target": [
  null,
  "שטח ההחלפה $target מתחיל"
 ],
 "Stopping swapspace $target": [
  null,
  "שטח ההחלפה $target נעצר"
 ],
 "Mounting $target": [
  null,
  "מתבצע עיגון של $target"
 ],
 "Unmounting $target": [
  null,
  "$target מנותק"
 ],
 "Checking $target": [
  null,
  "$target בבדיקה"
 ],
 "Repairing $target": [
  null,
  "$target מתוקן"
 ],
 "Erasing $target": [
  null,
  "$target נמחק"
 ],
 "Creating filesystem on $target": [
  null,
  "נוצרת מערכת קבצים על $target"
 ],
 "Setting up loop device $target": [
  null,
  "קם התקן לולאה $target"
 ],
 "Deleting $target": [
  null,
  "$target נמחק"
 ],
 "Creating partition $target": [
  null,
  "נוצרת מחיצה $target"
 ],
 "Cleaning up for $target": [
  null,
  "מתבצע ניקוי לכבוד $target"
 ],
 "Securely erasing $target": [
  null,
  "$target נמחק בצורה מאובטחת"
 ],
 "Very securely erasing $target": [
  null,
  "$target נמחק באופן מאוד מאובטח"
 ],
 "Stopping MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target נעצר"
 ],
 "Starting MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target מתחיל"
 ],
 "Marking $target as faulty": [
  null,
  "$target מסומן כתקול"
 ],
 "Removing $target from MDRAID device": [
  null,
  "מתבצעת הסרה של $target מהתקן MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "נוצר התקן MDRAID‏ $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target נבדק"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target נבדק ומתוקן"
 ],
 "Recovering MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target עובר שיקום"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "התקן ה־MDRAID‏ $target מסונכרן"
 ],
 "Activating $target": [
  null,
  "$target מופעל"
 ],
 "Deactivating $target": [
  null,
  "מתבצעת השבתה של $target"
 ],
 "Creating snapshot of $target": [
  null,
  "נוצרת תמונת מצב של $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נוצרת"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נמחקת"
 ],
 "Adding physical volume to $target": [
  null,
  "הוספת כרך פיזי אל $target"
 ],
 "Removing physical volume from $target": [
  null,
  "מתבצעת הסרה של כרך פיזי מתוך $target"
 ],
 "Emptying $target": [
  null,
  "$target מתרוקן"
 ],
 "Creating logical volume $target": [
  null,
  "נוצר כרך לוגי על $target"
 ],
 "Renaming $target": [
  null,
  "השם של $target מוחלף"
 ],
 "Operation '$operation' on $target": [
  null,
  "המשימה ‚$operation’ על $target"
 ],
 "unknown target": [
  null,
  "יעד לא ידוע"
 ],
 "Jobs": [
  null,
  "משימות"
 ],
 "Reading": [
  null,
  "מתבצעת קריאה"
 ],
 "Writing": [
  null,
  "מתבצעת כתיבה"
 ],
 "Install Stratis support": [
  null,
  "התקנת תמיכה ב־Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "החבילה $0 חייבת להיות מותקנת כדי ליצור מאגרי Stratis."
 ],
 "Install NFS support": [
  null,
  "התקנת תמיכה ב־NFS"
 ],
 "Create MDRAID device": [
  null,
  "יצירת התקן MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "יצירת קבוצת כרכים מסוג LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "החלפת שם מאתחל ה־iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "הוספת שער גישה ל־iSCSI"
 ],
 "Local storage": [
  null,
  "אחסון מקומי"
 ],
 "Networked storage": [
  null,
  "אחסון דרך הרשת"
 ],
 "Create storage device": [
  null,
  "יצירת התקן אחסון"
 ],
 "No storage found": [
  null,
  "לא נמצא אחסון"
 ],
 "Server address cannot be empty.": [
  null,
  "כתובת השרת לא יכולה להיות ריקה."
 ],
 "Next": [
  null,
  "הבא"
 ],
 "Invalid username or password": [
  null,
  "שם משתמש או סיסמה שגויים"
 ],
 "Unknown host name": [
  null,
  "שם המארח לא ידוע"
 ],
 "Unable to reach server": [
  null,
  "לא ניתן להגיע לשרת"
 ],
 "Available targets on $0": [
  null,
  "יעדים זמינים על $0"
 ],
 "Authentication required": [
  null,
  "נדרש אימות"
 ],
 "No drives found": [
  null,
  "לא נמצאו כוננים"
 ],
 "Target": [
  null,
  "יעד"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "אין אפשרות להקטין התקני גיבוי VDO"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "לא ניתן להקטין כאן נתונים בלתי מזוהים."
 ],
 "Unlock before resizing": [
  null,
  ""
 ],
 "$0 can not be resized here": [
  null,
  "אי אפשר לשנות כאן את הגודל של $0"
 ],
 "$0 can not be resized": [
  null,
  "אי אפשר לשנות את הגודל של $0"
 ],
 "$0 can not be made smaller": [
  null,
  "אי אפשר להקטין את $0"
 ],
 "$0 can not be made larger": [
  null,
  "אי אפשר להגדיל את $0"
 ],
 "Physical volumes can not be resized here": [
  null,
  "כאן ניתן לשנות גודל של כרכים פיזיים"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "לא ניתן להקטין כאן נתונים בלתי מזוהים"
 ],
 "Activate before resizing": [
  null,
  "הפעלה לפני שינוי גודל"
 ],
 "Grow logical volume": [
  null,
  "הגדלת הכרך הלוגי"
 ],
 "Grow partition": [
  null,
  "הגדלת מחיצה"
 ],
 "grow": [
  null,
  "הגדלה"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "יש לבחור בדיוק $0 כרכים פיזיים"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שינוי גודל של מערכת קבצים מוצפנת דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "יש לבחור בדיוק ב־$0 כרכים פיזיים, אחד לכל יחידת פיזור של הכרך הלוגי."
 ],
 "Shrink logical volume": [
  null,
  "כיווץ הכרך הלוגי"
 ],
 "shrink": [
  null,
  "כיווץ"
 ],
 "Unformatted data": [
  null,
  "נתונים ללא תבנית"
 ],
 "Block device": [
  null,
  "התקן אחסון"
 ],
 "Device number": [
  null,
  "מס׳ התקן"
 ],
 "Create partition on $0": [
  null,
  "יצירת מחיצה על $0"
 ],
 "Format $0": [
  null,
  "פרמוט $0"
 ],
 "No filesystem": [
  null,
  "אין מערכת קבצים"
 ],
 "(recommended)": [
  null,
  "(מומלץ)"
 ],
 "No encryption": [
  null,
  "אין הצפנה"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "שימוש מחדש בהצפנה קיימת ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "שימוש מחדש בהצפנה קיימת"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "Format and mount": [
  null,
  "פרמוט ועגינה"
 ],
 "Format only": [
  null,
  "פרמוט בלבד"
 ],
 "Format": [
  null,
  "פרמוט"
 ],
 "Create and start": [
  null,
  "ליצור ולהתחיל"
 ],
 "Format and start": [
  null,
  "פרמוט והתחלה"
 ],
 "Store passphrase": [
  null,
  "אחסון מילת צופן"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "פרמוט ימחק את כל הנתונים בהתקן אחסון."
 ],
 "Unrecognized data": [
  null,
  "נתונים לא מזוהים"
 ],
 "Storage can not be managed on this system.": [
  null,
  "לא ניתן לנהל את האחסון במערכת הזאת."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "format-bytes\u0004bytes": [
  null,
  "בתים"
 ]
});
