cockpit.locale({
 "": {
  "plural-forms": ((n) => (n!=1)),
  "language": "kn",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
