cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman コンテナー"
 ],
 "podman": [
  null,
  "Podman"
 ],
 "container": [
  null,
  "コンテナー"
 ],
 "image": [
  null,
  "イメージ"
 ]
});
