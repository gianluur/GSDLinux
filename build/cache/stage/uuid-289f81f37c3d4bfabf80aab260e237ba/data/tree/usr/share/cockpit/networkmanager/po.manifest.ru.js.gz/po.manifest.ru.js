cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Службы"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "network": [
  null,
  "сеть"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "интерфейс"
 ],
 "bridge": [
  null,
  "мост"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "привязка"
 ],
 "team": [
  null,
  "команда"
 ],
 "port": [
  null,
  "порт"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "Межсетевой экран"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "зона"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Управление сетевыми объединениями"
 ],
 "Managing networking teams": [
  null,
  "Управление сетевыми сопряжениями"
 ],
 "Managing networking bridges": [
  null,
  "Управление сетевыми мостами"
 ],
 "Managing VLANs": [
  null,
  "Управление VLAN"
 ],
 "Managing firewall": [
  null,
  "Управление межсетевым экраном"
 ]
});
