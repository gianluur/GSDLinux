cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "unmount": [
  null,
  "إلغاء التركيب"
 ],
 "mount": [
  null,
  "ركِّب"
 ],
 "format": [
  null,
  "تَهيئة"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "نظام الملفات"
 ],
 "partition": [
  null,
  "قسم"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "تجميع الأقراص"
 ],
 "volume": [
  null,
  "وحدة تخزين"
 ],
 "disk": [
  null,
  "قرص"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "قرص صلب"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "التشفير"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "إدارة الأقسام"
 ],
 "Managing NFS mounts": [
  null,
  "إدارة عمليات تركيب NFS"
 ],
 "Managing RAIDs": [
  null,
  "إدارة وحدات RAID"
 ],
 "Managing LVMs": [
  null,
  "إدارة الـ LVMs"
 ],
 "Managing physical drives": [
  null,
  "إدراة الأقراص الفيزيائية"
 ],
 "Managing VDOs": [
  null,
  "إدارة وحدات VDO"
 ],
 "Using LUKS encryption": [
  null,
  "استخدام تشفير LUKS"
 ],
 "Using Tang server": [
  null,
  "استخدام خادم Tang"
 ]
});
