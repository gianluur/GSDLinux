cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Journal": [
  null,
  "Günlük"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Donanım bilgileri"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "active": [
  null,
  "etkin"
 ],
 "Default": [
  null,
  "Varsayılan"
 ],
 "Light": [
  null,
  "Açık"
 ],
 "Dark": [
  null,
  "Koyu"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Search": [
  null,
  "Ara"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "Permission denied": [
  null,
  "İzin reddedildi"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Yönetimsel erişim elde etmek için hiçbir yöntem mevcut değil (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit $0 hata kodunu bildirdi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Error during initialization": [
  null,
  "Başlatma sırasında hata"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Home": [
  null,
  "Giriş"
 ],
 "Downloads": [
  null,
  "İndirmeler"
 ],
 "Not a directory": [
  null,
  "Dizin değil"
 ],
 "All files": [
  null,
  "Tüm dosyalar"
 ],
 "Recent": [
  null,
  "En son"
 ],
 "No recent directories": [
  null,
  "Son dizinler yok"
 ],
 "No recent files": [
  null,
  "Son dosyalar yok"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "File chooser actions": [
  null,
  "Dosya seçici eylemleri"
 ],
 "Open in file browser": [
  null,
  "Dosya tarayıcısında aç"
 ],
 "Hide hidden files": [
  null,
  "Gizli dosyaları gizle"
 ],
 "Show hidden files": [
  null,
  "Gizli dosyaları göster"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Clear filters": [
  null,
  "Süzgeçleri temizle"
 ],
 "Directory is empty": [
  null,
  "Dizin boş"
 ],
 "Directory has no sub-directories": [
  null,
  "Dizin, alt dizinlere sahip değil"
 ],
 "This directory contains only hidden files": [
  null,
  "Bu dizin yalnızca gizli dosyaları içerir"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "Folder": [
  null,
  "Klasör"
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "$0 is not a directory": [
  null,
  "$0 bir dizin değil"
 ],
 "$0 does not exist": [
  null,
  "$0 mevcut değil"
 ],
 "Font size": [
  null,
  "Yazı tipi boyutu"
 ],
 "Decrease by one": [
  null,
  "Bir azalt"
 ],
 "Increase by one": [
  null,
  "Bir artır"
 ],
 "Appearance": [
  null,
  "Görünüm"
 ],
 "Black": [
  null,
  "Siyah"
 ],
 "White": [
  null,
  "Beyaz"
 ],
 "Reset": [
  null,
  "Sıfırla"
 ],
 "Unable to open directory": [
  null,
  "Dizin açılamıyor"
 ],
 "Running process prevents directory change": [
  null,
  "Çalışan işlem dizin değişikliğini engelliyor"
 ],
 "Change directory": [
  null,
  "Dizini değiştir"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Dizini değiştirmek, o anda çalışan işlemi zorla durduracaktır. İşlem devam etmeden önce terminalde el ile de durdurulabilir."
 ],
 "Terminal not available": [
  null,
  "Terminal kullanılabilir değil"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Bu tarayıcı WebGL2'yi desteklemiyor."
 ],
 "unknown": [
  null,
  "bilinmeyen"
 ],
 "Shutdown": [
  null,
  "Kapat"
 ],
 "running $0": [
  null,
  "$0 çalışıyor"
 ],
 "Current boot": [
  null,
  "Şu anki önyükleme"
 ],
 "Previous boot": [
  null,
  "Önceki önyükleme"
 ],
 "Last 24 hours": [
  null,
  "Son 24 saat"
 ],
 "Last 7 days": [
  null,
  "Son 7 gün"
 ],
 "Only emergency": [
  null,
  "Sadece acil durumlar"
 ],
 "Alert and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Critical and above": [
  null,
  "Kritik ve üstü"
 ],
 "Error and above": [
  null,
  "Hata ve üstü"
 ],
 "Warning and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Notice and above": [
  null,
  "Bildirim ve üstü"
 ],
 "Info and above": [
  null,
  "Bilgi ve üstü"
 ],
 "Debug and above": [
  null,
  "Hata ayıklama ve üstü"
 ],
 "Toggle filters": [
  null,
  "Süzgeçleri aç/kapat"
 ],
 "Time": [
  null,
  "Zaman"
 ],
 "Priority": [
  null,
  "Öncelik"
 ],
 "Identifier": [
  null,
  "Tanımlayıcı"
 ],
 "Filters": [
  null,
  "Süzgeçler"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Resume": [
  null,
  "Devam"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Tarih özellikleri, YYYY-MM-DD hh:mm:ss biçiminde olmalıdır. Alternatif olarak 'yesterday', 'today', 'tomorrow' dizgileri de anlaşılır. 'now' şu anki zamanı ifade eder. Son olarak, göreceli zamanlar '-' veya '+' önekleri ile belirtilebilir"
 ],
 "Since": [
  null,
  "Başlangıç"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Belirtilen tarihten daha yeni veya o tarihteki girişleri göstermeyi başlatın."
 ],
 "Until": [
  null,
  "Bitiş"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Belirtilen tarihten daha eski veya o tarihteki girişleri göstermeyi başlatın."
 ],
 "Boot": [
  null,
  "Önyükleme"
 ],
 "Show messages from a specific boot.": [
  null,
  "Belirli bir önyüklemeden gelen iletileri gösterin."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Bu, '_BOOT_ID=' için bir eşleşme ekleyecektir. Eğer belirtilmemişse, şu anki önyükleme için günlükler gösterilecektir. Eğer önyükleme kimliği atlanırsa, pozitif bir denkleştirme, günlüğün başından itibaren başlayarak önyüklemeleri arayacak ve eşit ya da sıfırdan az denkleştirme, günlüğün sonundan başlayarak önyüklemeleri arayacaktır. Böylece, 1, günlükte bulunan ilk önyükleme, 2, ikincisi ve bunun gibi; -0 son önyükleme ise, -1 sondan önceki önyükleme ve bunun gibi."
 ],
 "Unit": [
  null,
  "Birim"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Belirtilen systemd birimi için iletileri gösterin."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Bu, belirli birim için olası tüm iletileri bulmak amacıyla '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' ve 'UNIT=' için eşleşme ekleyecek. Virgülle ayrılmış daha fazla birim içerebilir."
 ],
 "Free-form search": [
  null,
  "Serbest biçimli arama"
 ],
 "Show messages containing given string.": [
  null,
  "Verilen dizgiyi içeren iletileri gösterin."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Günlük iletilerindeki herhangi bir metin dizgisi süzülebilir. Dizgi ayrıca düzenli ifade biçiminde de olabilir. Ayrıca ileti günlük alanlarına göre süzmeyi de destekler. Bunlar, değerin olası değerlerin virgülle ayrılmış listesi olabilen, FIELD=VALUE biçimindeki boşlukla ayrılmış değerlerdir."
 ],
 "journalctl manpage": [
  null,
  "journalctl kılavuz sayfası"
 ],
 "Successfully copied to clipboard": [
  null,
  "Başarılı olarak panoya kopyalandı"
 ],
 "Create timer": [
  null,
  "Zamanlayıcı oluştur"
 ],
 "Edit timer": [
  null,
  "Zamanlayıcıyı düzenle"
 ],
 "Timer creation failed": [
  null,
  "Zamanlayıcı oluşturma başarısız oldu"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Zamanlayıcının başlama koşullarını alma başarısız oldu"
 ],
 "Failed to get the timer command": [
  null,
  "Zamanlayıcı komutunu alma başarısız oldu"
 ],
 "This field cannot be empty": [
  null,
  "Bu alan boş olamaz"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sadece harfler, sayılar, : , _ , . , @ , - karakterlerine izin verilir"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Shell command": [
  null,
  "Kabuk komutu"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Bu komut /bin/sh tarafından çalıştırılacaktır."
 ],
 "Trigger": [
  null,
  "Tetikleyici"
 ],
 "At specific time": [
  null,
  "Belirli bir zamanda"
 ],
 "After system boot": [
  null,
  "Sistem önyüklemesinden sonra"
 ],
 "Seconds": [
  null,
  "Saniye"
 ],
 "Minutes": [
  null,
  "Dakika"
 ],
 "Hours": [
  null,
  "Saat"
 ],
 "Weeks": [
  null,
  "Haftalar"
 ],
 "Delay must be a number": [
  null,
  "Gecikme bir sayı olmak zorundadır"
 ],
 "Repeat": [
  null,
  "Tekrarla"
 ],
 "Don't repeat": [
  null,
  "Tekrarlama"
 ],
 "Minutely": [
  null,
  "Dakikada"
 ],
 "Hourly": [
  null,
  "Saatlik"
 ],
 "Daily": [
  null,
  "Günlük"
 ],
 "Weekly": [
  null,
  "Haftalık"
 ],
 "Monthly": [
  null,
  "Aylık"
 ],
 "Yearly": [
  null,
  "Yıllık"
 ],
 "Run at": [
  null,
  "Çalıştırma saati"
 ],
 "At second": [
  null,
  "Saniyede"
 ],
 "At minute": [
  null,
  "Dakikada"
 ],
 "Run on": [
  null,
  "Çalıştırma tarihi"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Dakikanın 0 ile 59 arasında bir sayı olması gerekir"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Saniyenin 0 ile 59 arasında bir sayı olması gerekir"
 ],
 "Repeat weekly": [
  null,
  "Her hafta tekrarla"
 ],
 "Mondays": [
  null,
  "Pazartesi günleri"
 ],
 "Tuesdays": [
  null,
  "Salı günleri"
 ],
 "Wednesdays": [
  null,
  "Çarşamba günleri"
 ],
 "Thursdays": [
  null,
  "Perşembe günleri"
 ],
 "Fridays": [
  null,
  "Cuma günleri"
 ],
 "Saturdays": [
  null,
  "Cumartesi günleri"
 ],
 "Sundays": [
  null,
  "Pazar günleri"
 ],
 "Repeat monthly": [
  null,
  "Her ay tekrarla"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Unclean shutdown": [
  null,
  "Kötü kapatma"
 ],
 "View logs": [
  null,
  "Günlükleri görüntüle"
 ],
 "Dismiss": [
  null,
  "Yoksay"
 ],
 "Scheduled poweroff at $0": [
  null,
  "$0 için kapatma zamanlandı"
 ],
 "Cancel poweroff": [
  null,
  "Kapatmayı iptal et"
 ],
 "Scheduled reboot at $0": [
  null,
  "$0 için yeniden başlatma zamanlandı"
 ],
 "Cancel reboot": [
  null,
  "Yeniden başlatmayı iptal et"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "Set hostname": [
  null,
  "Anamakine adını ayarla"
 ],
 "Configuration": [
  null,
  "Yapılandırma"
 ],
 "Hostname": [
  null,
  "Anamakine adı"
 ],
 "System time": [
  null,
  "Sistem saati"
 ],
 "Domain": [
  null,
  "Etki alanı"
 ],
 "Performance profile": [
  null,
  "Performans profili"
 ],
 "Secure shell keys": [
  null,
  "Güvenli kabuk anahtarları"
 ],
 "Show fingerprints": [
  null,
  "Parmak izlerini göster"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh anamakine anahtarlarını listeleme başarısız oldu: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH anahtarlarını yükleme başarısız oldu"
 ],
 "Error message": [
  null,
  "Hata iletisi"
 ],
 "Loading keys...": [
  null,
  "Anahtarlar yükleniyor..."
 ],
 "No host keys found.": [
  null,
  "Bulunan anamakine anahtarları yok."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Makine SSH anahtarı parmak izleri"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Gerçek anamakine adı 64 karakter veya daha kısa olmak zorundadır"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Gerçek anamakine adı sadece küçük harf, rakam, kısa çizgi ve nokta karakterlerini (doldurulmuş alt etki alanlarıyla) içerebilir"
 ],
 "Change host name": [
  null,
  "Anamakine adını değiştir"
 ],
 "Pretty host name": [
  null,
  "Okunaklı anamakine adı"
 ],
 "Real host name": [
  null,
  "Gerçek anamakine adı"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "$0 kullanıcısının şifreleme ilkelerini değiştirmesine izin verilmiyor"
 ],
 "Cryptographic policy": [
  null,
  "Şifreleme ilkesi"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Geçerli tehdit modelleri için tavsiye edilen, güvenli ayarlar."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "SHA-1 imza doğrulamasına sahip VARSAYILAN'a izin verildi."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Artan saldırı yüzeyi pahasına daha yüksek birlikte çalışabilirlik."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "Active Directory birlikte çalışabilirliğine sahip ESKİ."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS modunda önyükleme yaparken yalnızca onaylanmış ve izin verilen algoritmaları kullan."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "Daha fazla Ortak Ölçüt kısıtlamasına sahip FIPS."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Birlikte çalışabilirlik pahasına beklenen yakın vadeli gelecekteki saldırılara karşı korur."
 ],
 "Custom cryptographic policy": [
  null,
  "Özel şifreleme ilkesi"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Şifreleme İlkeleri TLS, IPSec, SSH, DNSSec ve Kerberos protokollerini kapsayan temel şifreleme alt sistemlerini yapılandıran bir sistem bileşenidir."
 ],
 "Change cryptographic policy": [
  null,
  "Şifreleme ilkesini değiştir"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Yeni ilke uygulanıyor... Bu işlem birkaç dakika sürebilir."
 ],
 "Reapply and reboot": [
  null,
  "Yeniden uygula ve yeniden başlat"
 ],
 "Apply and reboot": [
  null,
  "Uygula ve yeniden başlat"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS düzgün şekilde etkinleştirilmedi"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Şifreleme ilkesi tutarsız"
 ],
 "Review cryptographic policy": [
  null,
  "Şifreleme ilkesini gözden geçir"
 ],
 "System information": [
  null,
  "Sistem bilgileri"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Demirbaş etiketi"
 ],
 "Machine ID": [
  null,
  "Makine kimliği"
 ],
 "Up since": [
  null,
  "Çalıştığı süre"
 ],
 "View hardware details": [
  null,
  "Donanım ayrıntılarını görüntüle"
 ],
 "Last successful login:": [
  null,
  "Son başarılı oturum açma:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 başarısız oturum açma girişimi",
  "$0 başarısız oturum açma girişimi"
 ],
 "View login history": [
  null,
  "Oturum açma geçmişini görüntüle"
 ],
 "recommended": [
  null,
  "önerilir"
 ],
 "inconsistent": [
  null,
  "tutarsız"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Bir etki alanına katılmak, realmd kurulumu gerektirir"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Bu sistemde realmd mevcut olmadığından bir etki alanına katılamıyor"
 ],
 "Joining this domain is not supported": [
  null,
  "Bu etki alanına katılmak desteklenmiyor"
 ],
 "Login format": [
  null,
  "Oturum açma biçimi"
 ],
 "Server software": [
  null,
  "Sunucu yazılımı"
 ],
 "Client software": [
  null,
  "İstemci yazılımı"
 ],
 "Leave domain": [
  null,
  "Etki alanından ayrıl"
 ],
 "Leave $0": [
  null,
  "$0'dan ayrıl"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Etki alanından ayrıldıktan sonra, sadece yerel kimlik bilgilerine sahip kullanıcılar bu makinede oturum açabilecektir. DNS çözümleme ayarları ve güvenilen CA'ların listesi değişebileceğinden, bu durum diğer hizmetleri de etkileyebilir."
 ],
 "Validating address": [
  null,
  "Adres doğrulanıyor"
 ],
 "Contacted domain": [
  null,
  "İletişim kurulan etki alanı"
 ],
 "Domain could not be contacted": [
  null,
  "Etki alanıyla iletişim kurulamadı"
 ],
 "Domain is not supported": [
  null,
  "Etki alanı desteklenmiyor"
 ],
 "Domain address": [
  null,
  "Etki alanı adresi"
 ],
 "Domain administrator name": [
  null,
  "Etki alanı yöneticisi adı"
 ],
 "Domain administrator password": [
  null,
  "Etki alanı yöneticisi parolası"
 ],
 "Joining": [
  null,
  "Katılıyor"
 ],
 "Join": [
  null,
  "Katıl"
 ],
 "This may take a while": [
  null,
  "Bu biraz zaman alabilir"
 ],
 "Not permitted to configure realms": [
  null,
  "Bölgeleri yapılandırmaya izin verilmiyor"
 ],
 "Join domain": [
  null,
  "Etki alanına katıl"
 ],
 "Install realmd support": [
  null,
  "realmd desteğini kur"
 ],
 "$0 disk is failing": [
  null,
  "$0 disk bozuluyor",
  "$0 disk bozuluyor"
 ],
 "Connected to Insights": [
  null,
  "Insights'a bağlı"
 ],
 "Not connected to Insights": [
  null,
  "Insights'a bağlı değil"
 ],
 "Health": [
  null,
  "Sağlık"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU'nun",
  "$0 CPU'nun"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "View metrics and history": [
  null,
  "Ölçümleri ve geçmişi görüntüle"
 ],
 "Tuned is not available": [
  null,
  "Tuned kullanılabilir değil"
 ],
 "Tuned is not running": [
  null,
  "Tuned çalışmıyor"
 ],
 "Tuned is off": [
  null,
  "Tuned kapalı"
 ],
 "This system is using the recommended profile": [
  null,
  "Bu sistem önerilen profili kullanıyor"
 ],
 "This system is using a custom profile": [
  null,
  "Bu sistem özel bir profil kullanıyor"
 ],
 "none": [
  null,
  "yok"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned ile iletişim başarısız oldu"
 ],
 "Failed to enable tuned": [
  null,
  "tuned etkinleştirme başarısız oldu"
 ],
 "Failed to disable tuned": [
  null,
  "tuned etkisizleştirme başarısız oldu"
 ],
 "Failed to disable tuned profile": [
  null,
  "tuned profilini etkisizleştirmesi başarısız oldu"
 ],
 "Failed to switch profile": [
  null,
  "Profil değiştirme başarısız oldu"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Disable tuned": [
  null,
  "tuned'i etkisizleştir"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned başlatılamadı"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned , sisteminizi izleyen ve belirli iş yükleri altında performansı en iyi hale getiren bir hizmettir. Tuned'ın çekirdeği, sisteminizi farklı kullanım durumları için ayarlayan profillerdir."
 ],
 "Change performance profile": [
  null,
  "Performans profilini değiştir"
 ],
 "Change profile": [
  null,
  "Profili değiştir"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd'yi düzenle"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd içinde değişiklikleri kaydetme başarısız oldu"
 ],
 "Save changes": [
  null,
  "Değişiklikleri kaydet"
 ],
 "Edit motd": [
  null,
  "motd'yi düzenle"
 ],
 "Stub": [
  null,
  "Kalıntı"
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Bad setting": [
  null,
  "Hatalı ayar"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Merged": [
  null,
  "Birleştirildi"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "Reloading": [
  null,
  "Yeniden yükleniyor"
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Failed to start": [
  null,
  "Başlatılamadı"
 ],
 "Maintenance": [
  null,
  "Bakım"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Linked": [
  null,
  "Bağlantılı"
 ],
 "Alias": [
  null,
  "Kod adı"
 ],
 "Masked": [
  null,
  "Maskelendi"
 ],
 "Static": [
  null,
  "Sabit"
 ],
 "Invalid": [
  null,
  "Geçersiz"
 ],
 "Indirect": [
  null,
  "Dolaylı"
 ],
 "Generated": [
  null,
  "Oluşturuldu"
 ],
 "Transient": [
  null,
  "Geçici"
 ],
 "Bad": [
  null,
  "Hatalı"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd sinyallerine abone olma başarısız oldu: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Dbus'a bağlanma başarısız oldu: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Birimleri listeleme başarısız oldu: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 hizmet başarısız oldu",
  "$0 hizmet başarısız oldu"
 ],
 "Loading of units failed": [
  null,
  "Birimlerin yüklenmesi başarısız oldu"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Listing units": [
  null,
  "Birimleri listeleme"
 ],
 "Filter by name or description": [
  null,
  "Ada veya açıklamaya göre süz"
 ],
 "Active state": [
  null,
  "Etkin durum"
 ],
 "File state": [
  null,
  "Dosya durumu"
 ],
 "$0 filters applied": [
  null,
  "$0 süzgeç uygulandı"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "$0 kullanıcısının CPU güvenlik riski azaltmalarını değiştirmesine izin verilmiyor"
 ],
 "Mitigations": [
  null,
  "Risk azaltmaları"
 ],
 "Version": [
  null,
  "Sürüm"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS sürümü"
 ],
 "BIOS date": [
  null,
  "BIOS tarihi"
 ],
 "CPU security": [
  null,
  "CPU güvenliği"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Eşzamanlı çoklu kullanımı etkisizleştir"
 ],
 "Read more...": [
  null,
  "Devamını oku..."
 ],
 "Save and reboot": [
  null,
  "Kaydet ve yeniden başlat"
 ],
 "CPU security toggles": [
  null,
  "CPU güvenlik geçişleri"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Yazılım tabanlı geçici çözümler, CPU güvenlik sorunlarını önlemeye yardımcı olur. Bu risk azaltmaları, performansı düşürme yan etkisine sahiptir. Bu ayarları değiştirmekte sorumluluk size aittir."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Sınıf"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "Slot": [
  null,
  "Yuva"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Memory technology": [
  null,
  "Bellek teknolojisi"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Rank": [
  null,
  "Sıra"
 ],
 "Speed": [
  null,
  "Hız"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Bellek bilgilerini görüntülemek için yönetimsel erişim gerekir."
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "Failed to fetch logs": [
  null,
  "Günlükleri getirme başarısız oldu"
 ],
 "Clear all filters": [
  null,
  "Tüm süzgeçleri temizle"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Şu anki süzgeçlerin birleşimi kullanılarak herhangi bir günlük bulunamıyor."
 ],
 "No logs found": [
  null,
  "Bulunan günlükler yok"
 ],
 "Load earlier entries": [
  null,
  "Daha önceki girişleri yükle"
 ],
 "You may try to load older entries.": [
  null,
  "Daha eski girişleri yüklemeyi deneyebilirsiniz."
 ],
 "Allow running (unmask)": [
  null,
  "Çalıştırmaya izin ver (maskelemeyi kaldır)"
 ],
 "Reload": [
  null,
  "Yeniden yükle"
 ],
 "Restart": [
  null,
  "Yeniden başlat"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Başlatılamadı' hatasını temizle"
 ],
 "Mask service": [
  null,
  "Hizmeti maskele"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Hizmeti maskelemek, tüm bağımlı birimlerin çalışmasını engeller. Bunun beklenenden daha büyük etkisi olabilir. Lütfen bu birimi maskelemek istediğinizi onaylayın."
 ],
 "Disallow running (mask)": [
  null,
  "Çalıştırmaya izin verme (maskele)"
 ],
 "Unpin unit": [
  null,
  "Birimi sabitlemeyi kaldır"
 ],
 "Pin unit": [
  null,
  "Birimi sabitle"
 ],
 "Additional actions": [
  null,
  "Ek eylemler"
 ],
 "Note": [
  null,
  "Not"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Bu birim açıkça etkinleştirilecek şekilde tasarlanmadı."
 ],
 "Forbidden from running": [
  null,
  "Çalıştırılması yasak"
 ],
 "Start service": [
  null,
  "Hizmeti başlat"
 ],
 "Active since ": [
  null,
  "Etkin olma başlangıcı "
 ],
 "Required by ": [
  null,
  "Gerektiren: "
 ],
 "Read-only": [
  null,
  "Salt-okunur"
 ],
 "Requires administration access to edit": [
  null,
  "Düzenlemek için yönetim erişimi gerektirir"
 ],
 "Automatically starts": [
  null,
  "Otomatik olarak başlar"
 ],
 "Updating status...": [
  null,
  "Durum güncelleniyor..."
 ],
 "Stop and disable": [
  null,
  "Durdur ve etkisizleştir"
 ],
 "Start and enable": [
  null,
  "Başlat ve etkinleştir"
 ],
 "Failed to load unit": [
  null,
  "Birim ekleme başarısız oldu"
 ],
 "View all services": [
  null,
  "Tüm hizmetleri görüntüle"
 ],
 "Triggers": [
  null,
  "Tetikleyiciler"
 ],
 "Triggered by": [
  null,
  "Tetikleyen"
 ],
 "Requires": [
  null,
  "Gerekliler"
 ],
 "Requisite": [
  null,
  "Gereklilik"
 ],
 "Wants": [
  null,
  "İstenen"
 ],
 "Binds to": [
  null,
  "Bağlanır"
 ],
 "Part of": [
  null,
  "Parçası olduğu"
 ],
 "Required by": [
  null,
  "Gerektiren"
 ],
 "Requisite of": [
  null,
  "Gerekliliği"
 ],
 "Wanted by": [
  null,
  "İsteyen"
 ],
 "Bound by": [
  null,
  "Bağlayan"
 ],
 "Consists of": [
  null,
  "İçerir"
 ],
 "Conflicts": [
  null,
  "Çakışanlar"
 ],
 "Conflicted by": [
  null,
  "Çakışan"
 ],
 "Before": [
  null,
  "Önce"
 ],
 "After": [
  null,
  "Sonra"
 ],
 "On failure": [
  null,
  "Başarısızlık durumunda"
 ],
 "Propagates reload to": [
  null,
  "Yeniden yüklemeyi şuna yayar"
 ],
 "Reload propagated from": [
  null,
  "Yeniden yükleme şuradan yayıldı"
 ],
 "Joins namespace of": [
  null,
  "Katıldığı ait olduğu ad alanı"
 ],
 "Condition $0=$1 was not met": [
  null,
  "$0=$1 koşulu karşılanmadı"
 ],
 "Deletion will remove the following files:": [
  null,
  "Silme işlemi aşağıdaki dosyaları kaldıracak:"
 ],
 "Pinned unit": [
  null,
  "Sabitlenmiş birim"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Path": [
  null,
  "Yol"
 ],
 "Listen": [
  null,
  "Dinle"
 ],
 "Container": [
  null,
  "Kapsayıcı"
 ],
 "View Podman container": [
  null,
  "Podman kapsayıcısını görüntüle"
 ],
 "Condition failed": [
  null,
  "Koşul başarısız oldu"
 ],
 "Show more relationships": [
  null,
  "Daha fazla ilişki göster"
 ],
 "Show relationships": [
  null,
  "İlişkileri göster"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Timer deletion failed": [
  null,
  "Zamanlayıcı silme başarısız oldu"
 ],
 "Targets": [
  null,
  "Hedefler"
 ],
 "Sockets": [
  null,
  "Soketler"
 ],
 "Timers": [
  null,
  "Zamanlayıcılar"
 ],
 "Paths": [
  null,
  "Yollar"
 ],
 "Go to $0": [
  null,
  "$0 hizmetine git"
 ],
 "Journal entry not found": [
  null,
  "Günlük girişi bulunamadı"
 ],
 "Journal entry": [
  null,
  "Günlük girişi"
 ],
 "Entry at $0": [
  null,
  "$0 tarihindeki giriş"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "Loading unit failed": [
  null,
  "Birimin yüklenmesi başarısız oldu"
 ],
 "Service logs": [
  null,
  "Hizmet günlükleri"
 ],
 "No log entries": [
  null,
  "Günlük girişleri yok"
 ],
 "Systemd units": [
  null,
  "Systemd birimleri"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Süzme ölçütüyle eşleşen sonuçlar yok. Sonuçları göstermek için tüm süzgeçleri temizleyin."
 ],
 "Does not automatically start": [
  null,
  "Otomatik olarak başlamaz"
 ],
 "Cannot be enabled": [
  null,
  "Etkinleştirilemez"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web konsolu sınırlı erişim kipinde çalışıyor."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 üzerinde $0 anamakinesinden"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 anamakinesinden"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 üzerinde"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Etki alanı"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Bir etki alanına katıl"
 ]
});
