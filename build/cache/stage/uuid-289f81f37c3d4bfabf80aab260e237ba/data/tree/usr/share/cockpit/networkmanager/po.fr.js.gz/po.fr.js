cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "Firewall": [
  null,
  "Pare-feu"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Public key": [
  null,
  "Clé publique"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Select": [
  null,
  "Sélectionner"
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "Connect": [
  null,
  "Connecter"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "Disconnected": [
  null,
  "Déconnecté"
 ],
 "Permission denied": [
  null,
  "Permission refusée"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "You now have administrative access.": [
  null,
  "Vous avez l’accès administrateur."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Aucun moyen d'obtenir un accès d'administration n'est disponible (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Veuillez vous authentifier pour obtenir un accès administrateur"
 ],
 "Switch to administrative access": [
  null,
  "Passer à l’accès administrateur"
 ],
 "Authenticate": [
  null,
  "S’authentifier"
 ],
 "Administrative access": [
  null,
  "Accès administrateur"
 ],
 "Problem becoming administrator": [
  null,
  "Problème pour devenir administrateur"
 ],
 "Method": [
  null,
  "Méthode"
 ],
 "Limit access": [
  null,
  "Limiter l’accès"
 ],
 "Switch to limited access": [
  null,
  "Passer en accès limité"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Le mode accès limité restreint les privilèges d’administration. Certaines parties de la console web auront des fonctionnalités réduites."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Votre navigateur se souviendra de votre niveau d’accès d’une session à l’autre."
 ],
 "Limited access": [
  null,
  "Accès limité"
 ],
 "Turn on administrative access": [
  null,
  "Activez l’accès administrateur"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "password quality": [
  null,
  "qualité du mot de passe"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun dépôt."
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a signalé le code d’erreur $0"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Error during initialization": [
  null,
  "Erreur pendant l’initialisation"
 ],
 "Failed": [
  null,
  "Échec"
 ],
 "Home": [
  null,
  "Répertoire personnel"
 ],
 "Downloads": [
  null,
  "Téléchargements"
 ],
 "Not a directory": [
  null,
  "Pas un répertoire"
 ],
 "All files": [
  null,
  "Tous les fichiers"
 ],
 "Recent": [
  null,
  "Récent"
 ],
 "No recent directories": [
  null,
  "Aucun répertoire récent"
 ],
 "No recent files": [
  null,
  "Aucun fichier récent"
 ],
 "Type to filter": [
  null,
  "Tapez pour filtrer"
 ],
 "File chooser actions": [
  null,
  "Actions du sélecteur de fichiers"
 ],
 "Open in file browser": [
  null,
  "Ouvrir dans le navigateur de fichiers"
 ],
 "Hide hidden files": [
  null,
  "Masquer les fichiers cachés"
 ],
 "Show hidden files": [
  null,
  "Afficher les fichiers cachés"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Clear filters": [
  null,
  "Effacer les filtres"
 ],
 "Directory is empty": [
  null,
  "Le répertoire est vide"
 ],
 "Directory has no sub-directories": [
  null,
  "Le répertoire n'a aucun sous-répertoire"
 ],
 "This directory contains only hidden files": [
  null,
  "Ce répertoire contient seulement des fichiers cachés"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "Folder": [
  null,
  "Dossier"
 ],
 "File": [
  null,
  "Fichier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Priority": [
  null,
  "Priorité"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Generated": [
  null,
  "Généré"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Start service": [
  null,
  "Démarrer le service"
 ],
 "Status": [
  null,
  "État"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Not available": [
  null,
  "Indisponible"
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Preserve": [
  null,
  "Préserver"
 ],
 "Random": [
  null,
  "Aléatoire"
 ],
 "Stable": [
  null,
  "Stable"
 ],
 "Use $0": [
  null,
  "Utiliser $0"
 ],
 "Failed to save settings": [
  null,
  "Échec de l’enregistrement des paramètres"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La création de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Create it": [
  null,
  "Créez-le"
 ],
 "Invalid prefix $0": [
  null,
  "Préfixe non valide $0"
 ],
 "Invalid metric $0": [
  null,
  "Métrique non valide $0"
 ],
 "Invalid address $0": [
  null,
  "Adresse non valide $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Préfixe ou masque de réseau non valide $0"
 ],
 "Testing connection": [
  null,
  "Test de connexion"
 ],
 "Restoring connection": [
  null,
  "Restauration de la connexion"
 ],
 "Troubleshoot…": [
  null,
  "Dépannage…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager n’est pas en cours d’exécution"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager n’est pas installé"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Les périphériques réseau et les graphiques nécessitent NetworkManager"
 ],
 "Enable service": [
  null,
  "Activer le service"
 ],
 "Network interface '$0' not found": [
  null,
  "Interface réseau '$0' introuvable"
 ],
 "Return to overview page": [
  null,
  "Revenir à la vue d'ensemble"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Vous n’êtes pas autorisé à modifier le pare-feu."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Non autorisé à désactiver le pare-feu"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Non autorisé à activer le pare-feu"
 ],
 "Disable the firewall": [
  null,
  "Désactiver le pare-feu"
 ],
 "Enable the firewall": [
  null,
  "Activer le pare-feu"
 ],
 "Edit service $0": [
  null,
  "Service d'édition $0"
 ],
 "Remove service $0": [
  null,
  "Supprimer le service $0"
 ],
 "Included Services": [
  null,
  "Services inclus"
 ],
 "Additional port": [
  null,
  "Port supplémentaire"
 ],
 "Remove additional port": [
  null,
  "Retirer un port supplémentaire"
 ],
 "Remove zone $0": [
  null,
  "Supprimer la zone $0"
 ],
 "Add services to zone $0": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Add services": [
  null,
  "Ajouter des services"
 ],
 "Service": [
  null,
  "Service"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 zone"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Allowed addresses": [
  null,
  "Adresses autorisées"
 ],
 "Entire subnet": [
  null,
  "Ensemble du sous-réseau"
 ],
 "There are no active services in this zone": [
  null,
  "Il n’y a pas de services actifs dans cette zone"
 ],
 "Filter services": [
  null,
  "Services de filtrage"
 ],
 "Failed to edit service": [
  null,
  "Échec de la modification du service"
 ],
 "Failed to add port": [
  null,
  "Échec de l’ajout du port"
 ],
 "Failed to add service": [
  null,
  "Échec de l’ajout du service"
 ],
 "Unknown service name": [
  null,
  "Nom de service inconnu"
 ],
 "Invalid port number": [
  null,
  "Numéro de port invalide"
 ],
 "Invalid range": [
  null,
  "Plage invalide"
 ],
 "Range must be strictly ordered": [
  null,
  "La plage doit être strictement ordonnée"
 ],
 "Edit service": [
  null,
  "Modifier le service"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modifier le service personnalisé dans la zone $0"
 ],
 "Add ports": [
  null,
  "Ajouter des ports"
 ],
 "Add ports to $0 zone": [
  null,
  "Ajouter des ports à la zone $0"
 ],
 "Add services to $0 zone": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Custom ports": [
  null,
  "Ports personnalisés"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemple : 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Les ports, les plages et les services séparés par des virgules sont acceptés"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemple : 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "S’il est laissé vide, l’ID sera généré sur la base des services et des numéros de port associés"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Ajouter des ports personnalisés rechargera firewalld. Ce rechargement entraînera la perte de toute configuration définie pendant l’exécution !"
 ],
 "Failed to add zone": [
  null,
  "Échec de l’ajout de la zone"
 ],
 "Add zone": [
  null,
  "Ajouter une zone"
 ],
 "Trust level": [
  null,
  "Niveau de confiance"
 ],
 "Sorted from least to most trusted": [
  null,
  "Trié du moins fiable au plus fiable"
 ],
 "Custom zones": [
  null,
  "Zones personnalisées"
 ],
 "No description available": [
  null,
  "Aucune description disponible"
 ],
 "Included services": [
  null,
  "services inclus"
 ],
 "The cockpit service is automatically included": [
  null,
  "Le service de cockpit est automatiquement inclus"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Range": [
  null,
  "Gamme"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adresse IP avec préfixe de routage. Séparez les valeurs multiples par une virgule. Exemple : 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cette zone contient le service du cockpit. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "La suppression de la zone supprime tous les services qui s’y trouvent."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "La suppression du service de cockpit pourrait rendre la console Web inaccessible. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Supprimer le service $0 de la zone $1"
 ],
 "Firewall is not available": [
  null,
  "Le pare-feu n’est pas disponible"
 ],
 "Please install the $0 package": [
  null,
  "Veuillez installer le paquet $0"
 ],
 "Add a new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Add new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Les requêtes entrantes sont bloquées par défaut. Les requêtes sortantes ne sont pas bloquées."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "Le SSID ne peut pas être vide"
 ],
 "Password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "Failed to connect": [
  null,
  "Échec de la connexion"
 ],
 "Check your password.": [
  null,
  "Vérifiez votre mot de passe."
 ],
 "Connect to hidden network": [
  null,
  "Se connecter à un réseau masqué"
 ],
 "Connect to $0": [
  null,
  "Se connecter à $0"
 ],
 "Network name": [
  null,
  "Nom du réseau"
 ],
 "Security": [
  null,
  "Sécurité"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’activation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Switch on $0": [
  null,
  "Allumer $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La désactivation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Switch off $0": [
  null,
  "Éteindre $0"
 ],
 "Bond": [
  null,
  "Agrégation"
 ],
 "Team": [
  null,
  "Équipe"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Pont"
 ],
 "Unknown \"$0\"": [
  null,
  "Inconnu « $0 »"
 ],
 "Carrier": [
  null,
  "Opérateur"
 ],
 "Yes": [
  null,
  "Oui"
 ],
 "No": [
  null,
  "Non"
 ],
 "Inactive": [
  null,
  "Inactif"
 ],
 "Unknown configuration": [
  null,
  "Configuration inconnue"
 ],
 "Additional address $val": [
  null,
  "Adresse supplémentaire $val"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Gateway $gateway": [
  null,
  "Passerelle $gateway"
 ],
 "Additional DNS $val": [
  null,
  "DNS supplémentaire $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domaines de recherche DNS supplémentaires $val"
 ],
 "DNS search domains $val": [
  null,
  "Domaines de recherche DNS $val"
 ],
 "General": [
  null,
  "Général"
 ],
 "Connect automatically": [
  null,
  "Connecter automatiquement"
 ],
 "Automatic": [
  null,
  "Automatique"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "Surveillance ARP"
 ],
 "Broken configuration": [
  null,
  "Configuration endommagée"
 ],
 "Team port": [
  null,
  "Port de l’équipe"
 ],
 "Spanning tree protocol": [
  null,
  "Protocole Spanning Tree"
 ],
 "Priority $priority": [
  null,
  "Priorité $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Délai d’attente de redirection $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Bonjour $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Âge maximal du message $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Coût du chemin $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Mode Hair Pin"
 ],
 "Bridge port": [
  null,
  "Port du pont"
 ],
 "Parent $parent": [
  null,
  "Parent $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Le mot de passe du réseau n'est pas stocké. Veuillez oublier le réseau et vous y reconnecter."
 ],
 "Failed to connect to $0": [
  null,
  "Échec de la connexion à $0"
 ],
 "secured": [
  null,
  "sécurisé"
 ],
 "open": [
  null,
  "ouvert"
 ],
 "Last connected: $0": [
  null,
  "Dernière connexion : $0"
 ],
 "Signal strength": [
  null,
  "Force du signal"
 ],
 "Not permitted to disconnect network": [
  null,
  "Déconnexion du réseau non autorisée"
 ],
 "Disconnect": [
  null,
  "Déconnecter"
 ],
 "Not permitted to connect to network": [
  null,
  "Connexion au réseau non autorisée"
 ],
 "Forget": [
  null,
  "Oublier"
 ],
 "$0 hidden network": [
  null,
  "$0 réseau masqué",
  "$0 réseaux masqués"
 ],
 "Filter": [
  null,
  "Filtrer"
 ],
 "Refresh": [
  null,
  "Actualiser"
 ],
 "Available networks": [
  null,
  "Réseaux disponibles"
 ],
 "Network": [
  null,
  "Réseau"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Signal": [
  null,
  "Signal"
 ],
 "Rate": [
  null,
  "Taux"
 ],
 "Not permitted to configure network devices": [
  null,
  "Non autorisé à configurer les périphériques réseau"
 ],
 "Enable or disable the device": [
  null,
  "Activer ou désactiver le périphérique"
 ],
 "This device cannot be managed here.": [
  null,
  "Ce périphérique ne peut pas être géré ici."
 ],
 "Connection will be lost": [
  null,
  "La connexion sera perdue"
 ],
 "Keep connection": [
  null,
  "Garder la connexion"
 ],
 "Invalid IP address: $0": [
  null,
  "Adresse IP invalide : $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Adresse de destination invalide : $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Adresse de passerelle invalide : $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Adresse DNS invalide : $0"
 ],
 "Preparing": [
  null,
  "Préparation"
 ],
 "Configuring": [
  null,
  "Configuration"
 ],
 "Authenticating": [
  null,
  "Authentification"
 ],
 "Configuring IP": [
  null,
  "Configuration IP"
 ],
 "Checking IP": [
  null,
  "Vérification IP"
 ],
 "Waiting": [
  null,
  "En attente"
 ],
 "Active": [
  null,
  "Actif"
 ],
 "Deactivating": [
  null,
  "Désactivation"
 ],
 "Adhoc": [
  null,
  "Ad hoc"
 ],
 "Infra": [
  null,
  "Infra."
 ],
 "AP": [
  null,
  "Pt d’accès"
 ],
 "Mesh": [
  null,
  "Maillé"
 ],
 "No carrier": [
  null,
  "Aucun transporteur"
 ],
 "Part of $0": [
  null,
  "Intégré à $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La modification des paramètres interrompt la connexion au serveur et rend l’interface utilisateur d’administration indisponible."
 ],
 "Change the settings": [
  null,
  "Modifier les paramètres"
 ],
 "Add bridge": [
  null,
  "Ajouter un pont"
 ],
 "Edit bridge settings": [
  null,
  "Modifier les paramètres de pont"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocole Spanning Tree (STP)"
 ],
 "STP priority": [
  null,
  "Priorité STP"
 ],
 "STP forward delay": [
  null,
  "Délai de réacheminement STP"
 ],
 "STP hello time": [
  null,
  "Durée Hello STP"
 ],
 "STP maximum message age": [
  null,
  "Âge maximal de message STP"
 ],
 "Round robin": [
  null,
  "Round-robin"
 ],
 "Active backup": [
  null,
  "Sauvegarde active"
 ],
 "Load balancing": [
  null,
  "L’équilibrage de charge"
 ],
 "Broadcast": [
  null,
  "Diffuser"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passif"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "Add team": [
  null,
  "Ajouter une équipe"
 ],
 "Edit team settings": [
  null,
  "Modifier les paramètres de l'équipe"
 ],
 "Runner": [
  null,
  "Exécuteur"
 ],
 "Balancer": [
  null,
  "Répartiteur de charge"
 ],
 "Primary": [
  null,
  "Primaire"
 ],
 "Link watch": [
  null,
  "Observation du lien"
 ],
 "Link up delay": [
  null,
  "Délai d’activation de lien"
 ],
 "Link down delay": [
  null,
  "Délai de chute de lien"
 ],
 "Ping interval": [
  null,
  "Intervalle de ping"
 ],
 "Ping target": [
  null,
  "Cible de ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatique (DHCP uniquement)"
 ],
 "Link local": [
  null,
  "Lien local"
 ],
 "Manual": [
  null,
  "Manuel"
 ],
 "Shared": [
  null,
  "Partagé"
 ],
 "Prefix length or netmask": [
  null,
  "Longueur du préfixe ou masque de réseau"
 ],
 "Prefix length": [
  null,
  "Longueur du préfixe"
 ],
 "IPv4 settings": [
  null,
  "Paramètres IPv4"
 ],
 "IPv6 settings": [
  null,
  "Paramètres IPv6"
 ],
 "Addresses": [
  null,
  "Adresses"
 ],
 "Select method": [
  null,
  "Sélectionnez la méthode"
 ],
 "Add address": [
  null,
  "Ajouter une adresse"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Remove item": [
  null,
  "Retirer l’élément"
 ],
 "Gateway": [
  null,
  "Passerelle"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Ajouter le serveur DNS"
 ],
 "DNS search domains": [
  null,
  "Domaines de recherche DNS"
 ],
 "Add search domain": [
  null,
  "Ajouter un domaine de recherche"
 ],
 "Search domain": [
  null,
  "Domaine de recherche"
 ],
 "Routes": [
  null,
  "Routes"
 ],
 "Add route": [
  null,
  "Ajouter une route"
 ],
 "Metric": [
  null,
  "Métrique"
 ],
 "Enter a valid MAC address": [
  null,
  "Entrez une adresse MAC valide"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 réseau",
  "$0 réseaux"
 ],
 "Add VPN": [
  null,
  "Ajouter un VPN"
 ],
 "Add bond": [
  null,
  "Ajouter une agrégation"
 ],
 "Add VLAN": [
  null,
  "Ajouter un VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Modifier les règles et les zones"
 ],
 "$0 active zone": [
  null,
  "$0 zone active",
  "$0 zones actives"
 ],
 "Managed interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "Sending": [
  null,
  "Envoi"
 ],
 "Receiving": [
  null,
  "Réception"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "Network logs": [
  null,
  "Journaux du réseau"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Les adresses ne sont pas formatées correctement"
 ],
 "Invalid IP address '$0'": [
  null,
  "Adresse IP \"$0\" invalide"
 ],
 "wireguard-tools package is not installed": [
  null,
  "le paquet wireguard-tools n'est pas installé"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Le point de terminaison du pair n°$0 est invalide. Il doit être spécifié au format hôte:port, ex. 1.2.3.4:51820, [2001:db8::1]:51820 ou exemple.fr:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Le port de point de terminaison du pair n°$0 est invalide. Le port doit être un nombre."
 ],
 "Listen port must be a number": [
  null,
  "Le port d'écoute doit être un nombre"
 ],
 "Add WireGuard VPN": [
  null,
  "Ajouter un VPN WireGuard"
 ],
 "Edit WireGuard VPN": [
  null,
  "Modifier un VPN WireGuard"
 ],
 "Private key": [
  null,
  "Clé privée"
 ],
 "Paste existing key": [
  null,
  "Coller la clé existante"
 ],
 "Regenerate": [
  null,
  "Régénéré"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "La clé publique sera générée une fois qu'une clé privée valide aura été saisie"
 ],
 "Listen port": [
  null,
  "Port d'écoute"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Sera défini sur \"Automatique\""
 ],
 "IP addresses": [
  null,
  "Adresses IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Différentes adresses peuvent être spécifiées en utilisant des virgules ou des espaces comme séparateurs."
 ],
 "Peers": [
  null,
  "Pairs"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Les pairs sont d'autres machines se connectant à celle-ci. Les machines partageront leurs clés publiques entre elles."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Le point de terminaison agissant comme un \"serveur\" doit être spécifié au format hôte:port, sinon le champ peut être laissé vide."
 ],
 "Add peer": [
  null,
  "Ajouter un pair"
 ],
 "Endpoint": [
  null,
  "Point de terminaison"
 ],
 "Allowed IPs": [
  null,
  "IP autorisées"
 ],
 "No peers added.": [
  null,
  "Aucun pair ajouté."
 ],
 "Edit VLAN settings": [
  null,
  "Modifier les paramètres VLAN"
 ],
 "Parent": [
  null,
  "Parent"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "Transmission"
 ],
 "MTU must be a positive number": [
  null,
  "MTU doit être un nombre positif"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Set to": [
  null,
  "Mis à"
 ],
 "Team port settings": [
  null,
  "Paramètres du port de l’équipe"
 ],
 "Sticky": [
  null,
  "Persistant"
 ],
 "LACP key": [
  null,
  "Clé LACP"
 ],
 "Bridge port settings": [
  null,
  "Paramètres du port du pont"
 ],
 "Path cost": [
  null,
  "Coût du chemin"
 ],
 "Hair pin mode": [
  null,
  "Mode Hair Pin"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Répartition adaptative de la charge d’émission"
 ],
 "Adaptive load balancing": [
  null,
  "Répartition adaptative de la charge"
 ],
 "MII (recommended)": [
  null,
  "MII (recommandé)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Modifier les paramètres d’agrégation"
 ],
 "Network bond": [
  null,
  "Agrégation de réseaux"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Une agrégation réseau combine plusieurs interfaces réseau en une seule interface logique avec un débit plus élevé ou une redondance."
 ],
 "Link monitoring": [
  null,
  "Surveillance du lien"
 ],
 "Monitoring interval": [
  null,
  "Intervalle de surveillance"
 ],
 "Monitoring targets": [
  null,
  "Objectifs de surveillance"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Remove $0": [
  null,
  "Supprimer $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’ajout de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "No interfaces available": [
  null,
  "Aucune interface disponible"
 ],
 "Add member": [
  null,
  "Ajouter un membre"
 ],
 "Interface members": [
  null,
  "Membres de l’interface"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ]
});
