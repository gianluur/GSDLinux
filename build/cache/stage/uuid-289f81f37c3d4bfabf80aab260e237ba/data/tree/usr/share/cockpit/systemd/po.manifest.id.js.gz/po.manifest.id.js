cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Layanan"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Overview": [
  null,
  "Ringkasan"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "time": [
  null,
  "waktu"
 ],
 "date": [
  null,
  "tanggal"
 ],
 "restart": [
  null,
  "mulai ulang"
 ],
 "shut": [
  null,
  "tutup"
 ],
 "domain": [
  null,
  "domain"
 ],
 "machine": [
  null,
  "mesin"
 ],
 "operating system": [
  null,
  "sistem operasi"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "tag aset"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "daya"
 ],
 "version": [
  null,
  "versi"
 ],
 "host": [
  null,
  "host"
 ],
 "hardware": [
  null,
  "perangkat keras"
 ],
 "mitigation": [
  null,
  "mitigasi"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "memori"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "serial"
 ],
 "graphs": [
  null,
  "grafik"
 ],
 "metrics": [
  null,
  "metrik"
 ],
 "history": [
  null,
  "riwayat"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "disk"
 ],
 "network": [
  null,
  "jaringan"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "kinerja"
 ],
 "Configuring system settings": [
  null,
  "Mengonfigurasi pengaturan sistem"
 ],
 "service": [
  null,
  "layanan"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "target"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "timer"
 ],
 "path": [
  null,
  "jalur"
 ],
 "unit": [
  null,
  "unit"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "boot"
 ],
 "mask": [
  null,
  "mask"
 ],
 "unmask": [
  null,
  "hapus mask"
 ],
 "enable": [
  null,
  "aktifkan"
 ],
 "disable": [
  null,
  "nonaktifkan"
 ],
 "Managing services": [
  null,
  "Mengelola layanan"
 ],
 "journal": [
  null,
  "jurnal"
 ],
 "warning": [
  null,
  "peringatan"
 ],
 "error": [
  null,
  "kesalahan"
 ],
 "debug": [
  null,
  "debug"
 ],
 "crash": [
  null,
  "crash"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "Meninjau log"
 ],
 "console": [
  null,
  "konsol"
 ],
 "command": [
  null,
  "perintah"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
