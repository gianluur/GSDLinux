cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 eroare",
  "$0 erori",
  "$0 erori"
 ],
 "$0 installation": [
  null,
  "Instalare $0"
 ],
 "$0 installer": [
  null,
  "Instalare $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 este o partiție extinsă MBR care conține partiții logice. Eliminarea tuturor partițiilor logice va elimina automat partiția extinsă."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "este nevoie de $0, însă doar $1 sunt disponibili."
 ],
 "$0 warning": [
  null,
  "$0 avertisment",
  "$0 avertismente",
  "$0 avertismente"
 ],
 "$0 will be deleted": [
  null,
  "$0 va fi eliminat"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "sistemul de fișiere '$0' nu poate fi pe un dispozitiv-bloc criptat"
 ],
 "'$0' must be assigned to $1": [
  null,
  "„$0” trebuie să fie atribuit la $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "„$0” trebuie să fie pe un dispozitiv formatat ca „$1”"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' trebuie să fie pe o partiție de sistem EFI. Partiția selectată folosește un sistem de fișiere FAT, dar nu e marcată ca fiind o partiție de sistem extinsă (ESP). Setați tipul partiției la sistem EFI și activați opțiunea ESP."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "A fost detectată partiția „$0” pe dispozitivul MDRAID $1. Partițiile de tip bootloader pe dispozitive MDRAID nu sunt suportate."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Un cont de utilizator standard cu acces la privilegii administrative pentru a efectua modificări la nivel de sistem."
 ],
 "Abort installation": [
  null,
  "Anulare instalare"
 ],
 "About": [
  null,
  "Despre aplicație"
 ],
 "Account": [
  null,
  "Cont"
 ],
 "Actions": [
  null,
  "Acțiuni"
 ],
 "Add another server...": [
  null,
  "Adaugă alt server..."
 ],
 "Add mount": [
  null,
  "Adaugă montură"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Suplimente pentru mediul selectat"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Suplimente nespecifice mediului dumneavoastră"
 ],
 "Additional languages": [
  null,
  "Limbi suplimentare"
 ],
 "Additional software for the selected environment": [
  null,
  "Software suplimentar pentru mediul selectat"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Toate modificările făcute în editorul de stocare sunt aplicate imediat."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Toate dispozitivele care folosesc această parolă vor fi deblocate"
 ],
 "Anaconda Web UI": [
  null,
  "Interfața Web Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Pagina proiectului Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aplică asocierea punctului de montură și instalează"
 ],
 "Applying changes...": [
  null,
  "Se aplică modificările..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Repartizarea partițiilor la punctele de montare. Utilă pentru aranjamente pre-configurate particularizate."
 ],
 "Automatic log file upload": [
  null,
  "Upload automat al fișierului jurnal"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Setarea automată a datei și orei, folosind servere de timp"
 ],
 "Automatically set timezone": [
  null,
  "Setare automată a fusului orar"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Spațiu liber disponibil: $0. Instalarea necesită: $1."
 ],
 "Back": [
  null,
  "Înapoi"
 ],
 "Base environment": [
  null,
  "Mediu de bază"
 ],
 "Brief description of the issue": [
  null,
  "Scurtă descriere a problemei"
 ],
 "Bug report details": [
  null,
  "Detaliile raportului de eroare"
 ],
 "Bugzilla API key": [
  null,
  "Cheie API Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Prin continuarea utilizării acestui software, înțelegeți și acceptați riscurile asociate folosirii unui software care nu a fost lansat oficial, că intenționați să folosiți acest software doar pentru testare și dezvoltare și sunteți dispus(ă) să raportați orice defecte sau incidente pentru a îmbunătăți acest produs."
 ],
 "Cancel": [
  null,
  "Renunță"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Change destination": [
  null,
  "Modifică destinația"
 ],
 "Change hostname": [
  null,
  "Modifică numele calculatorului"
 ],
 "Change partition layout": [
  null,
  "Modifică aranjamentul partițiilor"
 ],
 "Change system keyboard layout": [
  null,
  "Modifică aranjamentul tastaturii de sistem"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Modificările făcute aici vor afecta sistemul imediat. Revenirea la starea anterioară nu este posibilă."
 ],
 "Checking installation configuration...": [
  null,
  "Se verifică configurația de instalare..."
 ],
 "Checking storage configuration": [
  null,
  "Se verifică configurația de stocare"
 ],
 "Clear search": [
  null,
  "Goliți caseta de căutare"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Faceți click din nou pe „Următorul” pentru a continua în pofida acestor avertismente."
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Close storage editor": [
  null,
  "Închide editorul spațiului de stocare"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Stocarea Cockpit nu a furnizat parola pentru deblocarea dispozitivul criptat."
 ],
 "Completed": [
  null,
  "Finalizat"
 ],
 "Configuration is incomplete": [
  null,
  "Configurația este incompletă"
 ],
 "Configure NTP servers": [
  null,
  "Configurează serverele NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurează serverele NTP particulare"
 ],
 "Configure network": [
  null,
  "Configurează rețeaua"
 ],
 "Configure storage": [
  null,
  "Configurează spațiul de stocare"
 ],
 "Configure storage again": [
  null,
  "Configurează din nou spațiul de stocare"
 ],
 "Confirm passphrase": [
  null,
  "Confirmă parola"
 ],
 "Continue": [
  null,
  "Continuă"
 ],
 "Continue installation": [
  null,
  "Continuă instalarea"
 ],
 "Continue installation?": [
  null,
  "Continuați instalarea?"
 ],
 "Continue with installation": [
  null,
  "Continuă cu instalarea"
 ],
 "Correct these issues before continuing.": [
  null,
  "Remediați aceste probleme înainte de a continua."
 ],
 "Create Account": [
  null,
  "Creează cont"
 ],
 "Create account": [
  null,
  "Creează cont"
 ],
 "Currently installed: $0": [
  null,
  "Instalat curent: $0"
 ],
 "Custom": [
  null,
  "Personalizat"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data și ora"
 ],
 "Delete partition": [
  null,
  "Eliminare partiție"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Ștergerea anumitor partiții poate împiedica $0 să pornească: $1"
 ],
 "Description": [
  null,
  "Descriere"
 ],
 "Destination": [
  null,
  "Destinație"
 ],
 "Destination is encrypted": [
  null,
  "Destinația este criptată"
 ],
 "Detailed description of the issue": [
  null,
  "Descriere detaliată a problemei"
 ],
 "Detected valid storage layout:": [
  null,
  "Aranjamentul de stocare valid detectat:"
 ],
 "Device": [
  null,
  "Dispozitiv"
 ],
 "Duplicate device.": [
  null,
  "Dispozitiv duplicat."
 ],
 "Duplicate mount point.": [
  null,
  "Punct de montură duplicat."
 ],
 "Enable root account": [
  null,
  "Activează contul root"
 ],
 "Encrypt my data": [
  null,
  "Criptează datele mele"
 ],
 "Encrypted": [
  null,
  "Criptat"
 ],
 "Encryption": [
  null,
  "Criptare"
 ],
 "Enter PIN": [
  null,
  "Introduceți codul PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Introduceți codul PIN pentru a accesa aplicația de instalare"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Introduceți cheia dumneavoastră pentru API-ul Bugzilla pentru a raporta o problemă. Veți putea revizui și edita detaliile problemei în pasul următor."
 ],
 "Environment": [
  null,
  "Mediu"
 ],
 "Erase data and install": [
  null,
  "Șterge datele și instalează"
 ],
 "Error details": [
  null,
  "Detalii eroare"
 ],
 "Exit to live desktop": [
  null,
  "Ieși la sesiunea live"
 ],
 "Extended partition": [
  null,
  "Partiție extinsă"
 ],
 "Failed to report issue": [
  null,
  "Raportarea incidentului a eșuat"
 ],
 "Failed to save layouts": [
  null,
  "Eșec la salvarea aranjamentelor"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux necesită cel puțin $0 spațiu disk."
 ],
 "Finalization": [
  null,
  "Finalizare"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizare: Configurarea sistemului este completă. Finalizarea instalării poate dura câteva momente."
 ],
 "Find layout": [
  null,
  "Caută aranjament"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Pentru securitate îmbunătățită, evitați utilizarea directă a contului root. În schimb, folosiți contul de mai sus pentru a gestiona sistemul."
 ],
 "Full name": [
  null,
  "Nume complet"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Numele complet nu poate conține caractere „două puncte”"
 ],
 "Helper text": [
  null,
  "Text de asistență"
 ],
 "Hide API key": [
  null,
  "Ascunde cheie API"
 ],
 "Hide PIN": [
  null,
  "Ascunde codul PIN"
 ],
 "Hide confirmed password": [
  null,
  "Ascunde confirmarea parolei"
 ],
 "Hide passphrase": [
  null,
  "Ascunde parola"
 ],
 "Hide password": [
  null,
  "Ascunde parola"
 ],
 "Hostname": [
  null,
  "Nume sistem"
 ],
 "How would you like to install?": [
  null,
  "Cum doriți să efectuați instalarea?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Înțeleg că toate datele existente vor fi șterse",
  "Înțeleg că toate datele existente vor fi șterse de pe diskurile selectate",
  "Înțeleg că toate datele existente vor fi șterse de pe diskurile selectate"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Înțeleg că o parte din datele existente vor fi șterse"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Înțeleg că unele partiții vor fi modificate"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Dacă e lăsat gol, numele sistemului nu va fi salvat și va fi setat de informațiile din rețea."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Dacă niciuna din opțiunile de mai sus nu se potrivesc, utilizați editorul spațiului de stocare pentru a crea partiții specifice înainte de a continua."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "La configurarea partițiilor sunt necesare următoarele:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Dacă nu sunteți de acord cu trimiterea automată a fișierului-jurnal, puteți să $0. Raportarea manuală vă permite să revizuiți și să atașați doar fișierele pe care le alegeți."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Dacă nu înțelegeți sau nu acceptați riscurile, vă rugăm să ieșiți din această aplicație."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Dacă incidentul dumneavoastră se potrivește cu un bug menționat mai sus, puteți să îl deschideți și să adăugați informația dumneavoastră la el în loc să creați un raport duplicat."
 ],
 "In progress": [
  null,
  "În desfășurare"
 ],
 "Initializing...": [
  null,
  "Se inițializează..."
 ],
 "Install": [
  null,
  "Instalează"
 ],
 "Installation completed": [
  null,
  "Instalare finalizată"
 ],
 "Installation failed": [
  null,
  "Instalarea a eșuat"
 ],
 "Installation method": [
  null,
  "Metoda de instalare"
 ],
 "Installation of the system failed": [
  null,
  "Instalarea sistemului a eșuat"
 ],
 "Installation of the system failed: $0": [
  null,
  "Instalarea sistemului a eșuat: $0"
 ],
 "Installation type": [
  null,
  "Tipul de instalare"
 ],
 "Installing": [
  null,
  "Se instalează"
 ],
 "Insufficient disk space": [
  null,
  "Spațiu de stocare insuficient"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Codul PIN nu este valid. Vă rugăm să încercați din nou."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "A fost detectată o configurație RAID invalidă. Dacă ați creat colecția RAID direct pe disk-uri, trebuie să creați un tabel de partiții pe colecție. Dacă ați creat colecția RAID peste partiții, colecția trebuie să conțină un singur sistem de fișiere (de ex. LVM PV). Toate partițiile existente pe această colecție vor fi ignorate."
 ],
 "Invalid hostname": [
  null,
  "Numele sistemului este invalid"
 ],
 "Jump to first incomplete step": [
  null,
  "Treci la prima etapă incompletă"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Păstrează aranjamentul curent al disk-ului și utilizează spațiul disponibil (pentru dual-boot cu alt Sistem de Operare)."
 ],
 "Keyboard": [
  null,
  "Tastatură"
 ],
 "Keyboard layout during boot": [
  null,
  "Aranjament tastatură în timpul pornirii"
 ],
 "Language": [
  null,
  "Limbă"
 ],
 "Launch storage editor": [
  null,
  "Pornește editorul spațiului de stocare"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Aflați mai multe despre accesul restricționat la configurare"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Lăsați ambele câmpuri pentru fraza de acces goale pentru a utiliza o parolă goală."
 ],
 "Location": [
  null,
  "Locație"
 ],
 "Locked devices": [
  null,
  "Dispozitive blocate"
 ],
 "Log in": [
  null,
  "Autentificare"
 ],
 "Make current": [
  null,
  "Definește ca actual"
 ],
 "Manual disk configuration": [
  null,
  "Configurare manuală disk-uri"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configurare manuală disk-uri: Asociere puncte de montură"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Poate conține litere, numere și cratime."
 ],
 "May need more free space": [
  null,
  "Poate necesita mai mult spațiu liber"
 ],
 "Medium": [
  null,
  "Mediu"
 ],
 "Minimum of $0 required": [
  null,
  "Este necesar minim $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Neconcordanță între dispozitivele părinte și copil selectate pentru reformatare."
 ],
 "Mount point": [
  null,
  "Punct de montare"
 ],
 "Mount point assignment": [
  null,
  "Atribuirea punctelor de montură"
 ],
 "Move down": [
  null,
  "Mută în jos"
 ],
 "Move up": [
  null,
  "Mută în sus"
 ],
 "Must be at least $0 characters": [
  null,
  "Trebuie să fie cel puțin $0 simboluri"
 ],
 "My issue is different, continue": [
  null,
  "Incidentul meu este diferit, continuă"
 ],
 "NTP Servers": [
  null,
  "Servere NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Needs at least $0": [
  null,
  "Necesită cel puțin $0"
 ],
 "Network": [
  null,
  "Rețea"
 ],
 "Network Configuration": [
  null,
  "Configurare rețea"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rețeaua nu este disponibilă. Configurați rețeaua în meniul din bara de sus pentru a semnala incidentul."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rețeaua nu este disponibilă. Configurați rețeaua pentru a semnala incidentul."
 ],
 "Network plugin failed": [
  null,
  "Plugin-ul pentru rețea a eșuat"
 ],
 "Next": [
  null,
  "Următorul"
 ],
 "No devices": [
  null,
  "Niciun dispozitiv"
 ],
 "No disks available": [
  null,
  "Niciun disk disponibil"
 ],
 "No disks selected": [
  null,
  "Nu au fost selectate discuri"
 ],
 "No keyboard layouts selected": [
  null,
  "Nu ați selectat niciun aranjament al tastaturii"
 ],
 "No layouts selected yet": [
  null,
  "Niciun aranjament selectat"
 ],
 "No results found": [
  null,
  "Nu a fost găsit niciun rezultat"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Nu se poate obține keymap VConsole valid pentru aranjamentul(ele) selectat(e) al(e) tastaturii. Vă rugăm să selectați alt aranjament."
 ],
 "Not enough available free space": [
  null,
  "Spațiu liber insuficient"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Spațiu liber insuficient pe disk-urile selectate."
 ],
 "Not enough space on selected disks.": [
  null,
  "Nu este suficient spațiu liber pe discurile selectate."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Avertisment: Acesta este un software în etapa de pre-lansare și este destinat folosirii doar pentru dezvoltare și testare. NU utilizați acest software pentru activități critice sau în medii de producție."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Deschide formularul Bugzilla pentru introducerea problemei"
 ],
 "Operating system": [
  null,
  "Sistem de operare"
 ],
 "Options": [
  null,
  "Opțiuni"
 ],
 "Other keyboards": [
  null,
  "Alte tastaturi"
 ],
 "Partitions (advanced)": [
  null,
  "Partiții (avansat)"
 ],
 "Passphrase": [
  null,
  "Frază secretă"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Parola nu corespunde niciunui dispozitiv blocat"
 ],
 "Passphrases must match": [
  null,
  "Parolele trebuie să fie aceleași"
 ],
 "Pending": [
  null,
  "În așteptare"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Vă rugăm atașați fișierul jurnal $0 la incident."
 ],
 "Please enter a PIN": [
  null,
  "Vă rugăm introduceți un cod PIN valid."
 ],
 "Please select at least one disk to continue": [
  null,
  "Vă rugăm să selectați cel puțin un disk pentru a continua"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Au fost identificate bug-uri potențial duplicate"
 ],
 "Powered by Anaconda": [
  null,
  "Împuternicit de Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-lansare"
 ],
 "Prefer to report manually? $0": [
  null,
  "Preferați să raportați manual? $0"
 ],
 "Proceed with installation": [
  null,
  "Continuați cu instalarea"
 ],
 "Quit": [
  null,
  "Ieșire"
 ],
 "Quit installer?": [
  null,
  "Părăsiți aplicația de instalare?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Citirea informaţiilor despre sistemul de operare a eşuat."
 ],
 "Reading information about the computer failed.": [
  null,
  "Citirea de informaţii despre calculator a eşuat."
 ],
 "Reading installer configuration failed.": [
  null,
  "Citirea configuraţiei aplicaţiei de instalare a eşuat."
 ],
 "Reading installer version information failed.": [
  null,
  "Citirea informaţiilor despre versiunea aplicaţiei de instalare a eşuat."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Numele sistemului poate conţine doar litere, cifre, cratime (dar nu la începutul și nici la sfârșitul numelui) și puncte"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Numele sistemului nu trebuie să depășească 64 de semne"
 ],
 "Reboot": [
  null,
  "Repornire"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reporniți în Windows pentru a redimensiona partițiile criptate cu BitLocker. Asigurațivă că aveți cel puțin $0 spațiu disponibil pentru instalare."
 ],
 "Reboot system?": [
  null,
  "Reporniți sistemul?"
 ],
 "Reclaim additional space": [
  null,
  "Recuperare spațiu suplimentar"
 ],
 "Reclaim space": [
  null,
  "Recuperare spațiu"
 ],
 "Reclaim space (required)": [
  null,
  "Re_cuperare spațiu (obligatoriu)"
 ],
 "Recommended": [
  null,
  "Recomandat"
 ],
 "Recommended partitions:": [
  null,
  "Partiții recomandate:"
 ],
 "Reformat": [
  null,
  "Reformatare"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstalare Fedora"
 ],
 "Remove": [
  null,
  "Elimină"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Eliminați toate partițiile de pe dispozitivele selectate împreună cu sistemele de operare."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Eliminați sau redimensionați sistemele de fișiere existente pentru a elibera spațiu pentru instalare."
 ],
 "Remove server": [
  null,
  "Eliminare server"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Eliminarea unui sistem de fișiere va șterge permanent toate datele pe care acesta le conține. Redimensionarea unei partiții poate elibera spațiu, dar nu este o operațiune lipsită de riscuri. Asigurați-vă că ați făcut copii de rezervă a datelor importante înainte de a recupera spațiu."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Înlocuiți instalarea curentă, dar păstrați fișierele în directorul /home."
 ],
 "Report Issue": [
  null,
  "Raportați incident"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Raportați un incident sau oferiți feedback deschizând formularul Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Raportați incident"
 ],
 "Reporting issue...": [
  null,
  "Raportare incident..."
 ],
 "Required": [
  null,
  "Obligatoriu"
 ],
 "Requirements": [
  null,
  "Cerințe"
 ],
 "Rescan devices": [
  null,
  "Rescanare dispozitive"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Se re-scanează discurile finalizate."
 ],
 "Resize": [
  null,
  "Redimensionare"
 ],
 "Resize partition": [
  null,
  "Redimensionare partiție"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Redimensionarea următoarelor partiții de la $0:$1"
 ],
 "Restrict access to the report": [
  null,
  "Restricționează accesul la raport"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Restricționează accesul la raport la grupul $0. $1"
 ],
 "Return to installation": [
  null,
  "Înapoi la instalare"
 ],
 "Return to storage editor": [
  null,
  "Întoarcere la editorul de stocare"
 ],
 "Review and install": [
  null,
  "Revizuiți și instalați"
 ],
 "Root account has been configured": [
  null,
  "Contul root a fost configurat"
 ],
 "Root account is enabled": [
  null,
  "Contul root este activat"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Contul root este activat, dar nu a fost configurat niciun cont de utilizator"
 ],
 "Root password has been set.": [
  null,
  "Parola root a fost setată."
 ],
 "Save": [
  null,
  "Salvează"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scanați codul QR cu telefonul sau accesați:"
 ],
 "Search for a language": [
  null,
  "Căutați o limbă"
 ],
 "Search for additional software": [
  null,
  "Căutați software suplimentar"
 ],
 "Search for an environment": [
  null,
  "Căutați un mediu"
 ],
 "Search keyboard layout": [
  null,
  "Căutați aranjament de tastatură"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Securizați-vă datele cu ajutorul criptării la nivel de disk. Se aplică doar pentru partițiile noi"
 ],
 "Select": [
  null,
  "Selectează"
 ],
 "Select a device": [
  null,
  "Selectați un dispozitiv"
 ],
 "Select city": [
  null,
  "Selectare oraș"
 ],
 "Select destination": [
  null,
  "Selectați destinația"
 ],
 "Select region": [
  null,
  "Selectați regiunea"
 ],
 "Selected (top = current)": [
  null,
  "Aranjamente selectate (cel de sus = curent)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Formatul $0 al dispozitivului selectat nu poate fi reformatat."
 ],
 "Send us feedback on your installation": [
  null,
  "Trimiteți feedback despre instalarea dumneavoastră"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server is not reachable": [
  null,
  "Serverul nu este accesibil"
 ],
 "Set custom hostname": [
  null,
  "Setați numele serverului"
 ],
 "Share disk with other operating systems": [
  null,
  "Partajați disk-ul cu alte sisteme de operare"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Partajați disk-ul cu alte sisteme de operare: $0"
 ],
 "Show AM/PM": [
  null,
  "Afișează AM/PM"
 ],
 "Show API key": [
  null,
  "Afișează cheia API"
 ],
 "Show PIN": [
  null,
  "Afișează codul PIN"
 ],
 "Show confirmed password": [
  null,
  "Afișează confirmarea parolei"
 ],
 "Show passphrase": [
  null,
  "Arată parola"
 ],
 "Show password": [
  null,
  "Arată parola"
 ],
 "Size": [
  null,
  "Dimensiune"
 ],
 "Software installation": [
  null,
  "Instalare software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalare software: Configurarea stocării este completă. Acest software este în curs de instalare pe dispozitivul dumneavoastră."
 ],
 "Software selection": [
  null,
  "Selecție software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Mai sunt câteva etape de instalare care trebuie finalizate înainte de a putea continua."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Lipsesc câteva partiții obligatorii: $0"
 ],
 "Space": [
  null,
  "Spațiu"
 ],
 "Stacktrace": [
  null,
  "Desfășurător de stivă"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Storage configuration": [
  null,
  "Configurare stocare"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configurare stocare: Stocarea este în curs de configurare."
 ],
 "Storage editor": [
  null,
  "Editor stocare"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Stocarea se bazează pe configurarea din „Modificare stocare”."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Aranjamentul de stocare este definit de fișierul kickstart. Aranjamentul planificat al partițiilor poate fi revizuit în etapa rezumat."
 ],
 "Storage plugin failed": [
  null,
  "Plugin-ul pentru stocare a eșuat"
 ],
 "Storage requirements not met": [
  null,
  "Cerințele pentru stocare nu sunt satisfăcute"
 ],
 "Strong": [
  null,
  "Puternică"
 ],
 "Successfully installed": [
  null,
  "Instalat cu succes"
 ],
 "Successfully unlocked $0.": [
  null,
  "A fost deblocat cu succes $0."
 ],
 "Suggested keyboards": [
  null,
  "Tastaturi sugerate"
 ],
 "Suggested languages": [
  null,
  "Limbi sugerate"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System configuration": [
  null,
  "Configurare sistem"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configurare sistem: Instalarea software este completă. Sistemul este în curs de configurare."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Instalarea Anaconda s-a oprit pe neașteptate."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Următoarele erori deschise ar putea avea legătură cu problema dumneavoastră. Vă rugăm să le verificați înainte de a crea un nou raport."
 ],
 "The following user will be created:": [
  null,
  "Va fi creat următorul utilizator:",
  "Vor fi creați următorii utilizatori:",
  "Vor fi creați următorii utilizatori:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Instalarea necesită $0 spațiu-disk însă capacitatea diskurilor selectate este de doar $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Instalarea nu poate continua din cauza unei erori critice."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Instalarea nu poate continua din cauza unei erori critice: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Parola introdusă conține simboluri non-ASCII. Este posibil să nu puteți schimba aranjamentul tastaturii când o veți introduce."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Aranjamentul selectat al tastaturii nu suportă simboluri ASCII. Vă rugăm să selectați un aranjament care suportă simbolurile ASCII ca implicit."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Editorul spațiului de stocare vă permite să redimensionați, eliminați și să creați partiții. Acesta poate configura LVM și multe altele. Editorul este destinat utilizării ca utilitar avansat și nu este destinat utilizării într-o instalare tipică."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Aceste fișiere-jurnal pot conține informații sensibile precum adrese IP, nume de utilizatori sau alte detalii ale sistemului."
 ],
 "This hostname can't be submitted": [
  null,
  "Acest nume de sistem nu poate fi trimis"
 ],
 "This is unstable, pre-release software": [
  null,
  "Acest software este în pre-lansare și nu este stabil"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Acest aranjament va fi folosit pentru deblocarea sistemului dumneavoastră la pornine"
 ],
 "This may take a moment": [
  null,
  "Aceasta ar putea dura ceva timp"
 ],
 "This will take a few moments": [
  null,
  "Aceasta ar putea dura câteva momente"
 ],
 "Time": [
  null,
  "Timp"
 ],
 "Timezone": [
  null,
  "Fus orar"
 ],
 "Title": [
  null,
  "Titlu"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Pentru a începe utilizarea $0, reporniți sistemul."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Pentru a continua selectați dispozitivele pe care se va efectua instalarea."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Pentru a utiliza această opțiune, redimensionați sau eliminați partițiile existente pentru a elibera cel puțin $0."
 ],
 "Type": [
  null,
  "Tip"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Nu se poate planifica ștergerea$0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Nu se poate planifica redimensionarea $0"
 ],
 "Undo last action": [
  null,
  "Anulare acțiune anterioară"
 ],
 "Unlock": [
  null,
  "Deblocare"
 ],
 "Unlock encrypted devices": [
  null,
  "Deblocați dispozitivele criptate"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Deblocați partițiile criptate pentru a păstra datele existente și pentru a afișa mai multe metode de instalare."
 ],
 "Use configured storage": [
  null,
  "Utilizează spațiul de stocare configurat"
 ],
 "Use entire disk": [
  null,
  "Folosește întregul disk"
 ],
 "Use free space": [
  null,
  "Folosește spațiul liber"
 ],
 "Use local account": [
  null,
  "Folosește utilizator local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Folosește dispozitivul RAID pentru partiționare automată"
 ],
 "User creation": [
  null,
  "Creare utilizatori"
 ],
 "User name": [
  null,
  "Nume utilizator"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Numele utilizatorului poate conține doar: litere a-z, cifre 0-9, cratimă $0, punct $1, linie de subliniere $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Numele utilizatorului nu trebuie să fie un cuvânt rezervat"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Numele utilizatorului trebuie să fie mai scurt de 33 de simboluri"
 ],
 "Validating...": [
  null,
  "În curs de validare..."
 ],
 "Weak": [
  null,
  "Slabă"
 ],
 "Welcome": [
  null,
  "Bine ați venit"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Bun venit în Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Bine ați venit. Haideți să instalăm $0 acum."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "La trimiterea acestui incident, următoarele fișiere-jurnal vor fi încărcate automat: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Partițiile Windows cu criptare BitLocker nu pot fi redimensionate"
 ],
 "You can close this browser window now.": [
  null,
  "Acum puteți închide această fereastră a navigatorului."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Puteți elibera suficient spațiu aici și să lăsați aplicația de instalare să gestioneze restul, sau să configurați manual partițiile."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Puteți genera cheia API pentru contul dumneavoastră Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Trebuie să activați contul root sau să creați un cont de utilizator local pentru a continua."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Trebuie să fiți conectați la o rețea pentru a activa configurarea automată a datei și orei."
 ],
 "Your progress will not be saved.": [
  null,
  "Progresul nu va fi salvat."
 ],
 "completed step": [
  null,
  "etapă finalizată"
 ],
 "current step": [
  null,
  "etapa curentă"
 ],
 "delete": [
  null,
  "șterge"
 ],
 "edit": [
  null,
  "modifică"
 ],
 "encrypt": [
  null,
  "criptează"
 ],
 "encrypted": [
  null,
  "criptat"
 ],
 "extended partition": [
  null,
  "partiție extinsă"
 ],
 "format as $0": [
  null,
  "formatează ca $0"
 ],
 "here": [
  null,
  "aici"
 ],
 "incomplete": [
  null,
  "incompletă"
 ],
 "mount": [
  null,
  "montează"
 ],
 "pending step": [
  null,
  "etapă în așteptare"
 ],
 "report the issue manually": [
  null,
  "raportați incidentul manual"
 ],
 "resized from $0": [
  null,
  "redimensionat de la $0"
 ],
 "shrink": [
  null,
  "micșorează"
 ],
 "shrink to $0": [
  null,
  "micșorează la $0"
 ],
 "transient, will use DHCP": [
  null,
  "temporar, se va utiliza DHCP"
 ],
 "undo": [
  null,
  "anulează"
 ]
});
