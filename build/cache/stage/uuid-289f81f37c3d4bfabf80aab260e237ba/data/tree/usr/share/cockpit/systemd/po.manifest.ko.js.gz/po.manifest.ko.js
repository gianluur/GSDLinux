cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "서비스"
 ],
 "Terminal": [
  null,
  "터미널"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Overview": [
  null,
  "개요"
 ],
 "Logs": [
  null,
  "기록"
 ],
 "time": [
  null,
  "시간"
 ],
 "date": [
  null,
  "날짜"
 ],
 "restart": [
  null,
  "재시작"
 ],
 "shut": [
  null,
  "종료"
 ],
 "domain": [
  null,
  "도메인"
 ],
 "machine": [
  null,
  "장치"
 ],
 "operating system": [
  null,
  "운영 체제"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "자산 태그"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "전원"
 ],
 "version": [
  null,
  "버전"
 ],
 "host": [
  null,
  "호스트"
 ],
 "hardware": [
  null,
  "하드웨어"
 ],
 "mitigation": [
  null,
  "완화"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "메모리"
 ],
 "cpu": [
  null,
  "중앙처리장치"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "램"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "시리얼"
 ],
 "graphs": [
  null,
  "그래프"
 ],
 "metrics": [
  null,
  "메트릭"
 ],
 "history": [
  null,
  "내역"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "디스크"
 ],
 "network": [
  null,
  "네트워크"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "성능"
 ],
 "Configuring system settings": [
  null,
  "시스템 설정 구성"
 ],
 "service": [
  null,
  "서비스"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "대상"
 ],
 "socket": [
  null,
  "소켓"
 ],
 "timer": [
  null,
  "타이머"
 ],
 "path": [
  null,
  "경로"
 ],
 "unit": [
  null,
  "단위"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "부팅"
 ],
 "mask": [
  null,
  "마스크"
 ],
 "unmask": [
  null,
  "마스크 해제"
 ],
 "enable": [
  null,
  "활성화"
 ],
 "disable": [
  null,
  "비활성화"
 ],
 "Managing services": [
  null,
  "서비스 관리"
 ],
 "journal": [
  null,
  "저널"
 ],
 "warning": [
  null,
  "경고"
 ],
 "error": [
  null,
  "오류"
 ],
 "debug": [
  null,
  "디버그"
 ],
 "crash": [
  null,
  "충돌"
 ],
 "coredump": [
  null,
  "코어 덤프"
 ],
 "Reviewing logs": [
  null,
  "로그 검토"
 ],
 "console": [
  null,
  "콘솔"
 ],
 "command": [
  null,
  "명령"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "쉘"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
