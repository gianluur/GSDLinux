cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "unmount": [
  null,
  "卸载"
 ],
 "mount": [
  null,
  "挂载"
 ],
 "format": [
  null,
  "格式"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "文件系统"
 ],
 "partition": [
  null,
  "分区"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "卷"
 ],
 "disk": [
  null,
  "磁盘"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "驱动"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "加密"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "管理分区"
 ],
 "Managing NFS mounts": [
  null,
  "管理 NFS 挂载"
 ],
 "Managing RAIDs": [
  null,
  "管理 RAID"
 ],
 "Managing LVMs": [
  null,
  "管理 LVM"
 ],
 "Managing physical drives": [
  null,
  "管理物理驱动"
 ],
 "Managing VDOs": [
  null,
  "管理 VDO"
 ],
 "Using LUKS encryption": [
  null,
  "使用 LUKS 加密"
 ],
 "Using Tang server": [
  null,
  "使用 Tang 服务器"
 ]
});
