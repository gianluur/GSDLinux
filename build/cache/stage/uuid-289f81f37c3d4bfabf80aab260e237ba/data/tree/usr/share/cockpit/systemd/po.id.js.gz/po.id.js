cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Kunci yang berubah sering kali disebabkan oleh instalasi ulang sistem operasi. Namun, perubahan yang tidak terduga dapat menunjukkan upaya pihak ketiga untuk mencegat koneksi Anda."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Untuk memastikan bahwa koneksi Anda tidak dicegat oleh pihak ketiga berbahaya, harap verifikasi sidik jari kunci host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email."
 ],
 "Password": [
  null,
  "Kata sandi"
 ],
 "Log in": [
  null,
  "Masuk"
 ],
 "Cancel": [
  null,
  "Batal"
 ],
 "Services": [
  null,
  "Layanan"
 ],
 "Journal": [
  null,
  "Jurnal"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Informasi perangkat keras"
 ],
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Type": [
  null,
  "Jenis"
 ],
 "Copy": [
  null,
  "Salin"
 ],
 "Copied": [
  null,
  "Disalin"
 ],
 "Name": [
  null,
  "Nama"
 ],
 "Details": [
  null,
  "Detail"
 ],
 "Close": [
  null,
  "Tutup"
 ],
 "Edit": [
  null,
  "Edit"
 ],
 "Remove": [
  null,
  "Hapus"
 ],
 "active": [
  null,
  "aktif"
 ],
 "Default": [
  null,
  "Default"
 ],
 "Light": [
  null,
  "Ringan"
 ],
 "Dark": [
  null,
  "Gelap"
 ],
 "Help": [
  null,
  "Bantuan"
 ],
 "Select": [
  null,
  "Pilih"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Search": [
  null,
  "Cari"
 ],
 "No results found": [
  null,
  "Tidak ada hasil ditemukan"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit tidak terpasang"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Versi Cockpit yang kompatibel tidak terinstal pada $0."
 ],
 "Add": [
  null,
  "Tambah"
 ],
 "$0 key changed": [
  null,
  "Kunci $0 telah berubah"
 ],
 "Trust and add host": [
  null,
  "Percayai dan tambahkan host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Untuk memverifikasi sidik jari, jalankan perintah berikut di $0 saat berada langsung di mesin atau melalui jaringan tepercaya:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jika sidik jari cocok, klik 'Percayai dan tambahkan host'. Jika tidak, jangan sambungkan dan hubungi administrator Anda."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Sidik jari yang dihasilkan aman untuk dibagikan melalui metode publik, termasuk email. Jika Anda meminta orang lain untuk melakukan verifikasi, mereka dapat mengirim hasilnya dengan metode apa pun."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Anda terhubung ke $0 untuk pertama kalinya."
 ],
 "Verify fingerprint": [
  null,
  "Verifikasi sidik jari"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Jalankan perintah ini melalui jaringan tepercaya atau langsung di mesin jarak jauh:"
 ],
 "The fingerprint should match:": [
  null,
  "Sidik jari harus cocok:"
 ],
 "The password can not be empty": [
  null,
  "Kata sandi tidak boleh kosong"
 ],
 "The key password can not be empty": [
  null,
  "Kata sandi kunci tidak boleh kosong"
 ],
 "The key passwords do not match": [
  null,
  "Kata sandi kunci tidak cocok"
 ],
 "Log in to $0": [
  null,
  "Masuk ke $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Tidak dapat masuk ke $0. Host tidak menerima login dengan kata sandi atau salah satu kunci SSH Anda."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi oleh kata sandi, dan host tidak mengizinkan login dengan kata sandi. Harap berikan kata sandi untuk kunci di $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kunci SSH untuk login ke $0 dilindungi. Anda dapat masuk dengan kata sandi login Anda atau dengan memberikan kata sandi untuk kunci di $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Buat kunci SSH baru dan otorisasi"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH baru di $0 akan dibuat untuk $1 di $2 dan akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Key password": [
  null,
  "Kata sandi kunci"
 ],
 "Confirm key password": [
  null,
  "Konfirmasi kata sandi kunci"
 ],
 "Authorize SSH key": [
  null,
  "Otorisasi kunci SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kunci SSH $0 dari $1 di $2 akan ditambahkan ke berkas $3 milik $4 di $5."
 ],
 "Authentication": [
  null,
  "Autentikasi"
 ],
 "SSH key": [
  null,
  "Kunci SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Kunci SSH $0 akan tersedia selama sisa sesi dan dapat digunakan untuk login ke host lain."
 ],
 "Permission denied": [
  null,
  "Izin ditolak"
 ],
 "Clear input value": [
  null,
  "Hapus nilai masukan"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format tanggal dan waktu tidak valid"
 ],
 "Invalid time format": [
  null,
  "Format waktu tidak valid"
 ],
 "Invalid date format": [
  null,
  "Format tanggal tidak valid"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tidak dapat menjadwalkan acara di masa lalu"
 ],
 "No delay": [
  null,
  "Tanpa penundaan"
 ],
 "1 minute": [
  null,
  "1 Menit"
 ],
 "5 minutes": [
  null,
  "5 menit"
 ],
 "20 minutes": [
  null,
  "20 Menit"
 ],
 "40 minutes": [
  null,
  "40 Menit"
 ],
 "60 minutes": [
  null,
  "60 Menit"
 ],
 "Specific time": [
  null,
  "Waktu tertentu"
 ],
 "Shut down": [
  null,
  "Matikan"
 ],
 "Reboot": [
  null,
  "Reboot"
 ],
 "Message to logged in users": [
  null,
  "Pesan ke pengguna yang sedang masuk"
 ],
 "Delay": [
  null,
  "Jeda"
 ],
 "Pick date": [
  null,
  "Pilih tanggal"
 ],
 "Toggle date picker": [
  null,
  "Beralih pemilih tanggal"
 ],
 "Synchronized": [
  null,
  "Tersinkronisasi"
 ],
 "Synchronized with $0": [
  null,
  "Tersinkronisasi dengan $0"
 ],
 "Synchronizing": [
  null,
  "Sedang menyinkronkan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Mencoba menyinkronkan dengan $0"
 ],
 "Not synchronized": [
  null,
  "Tidak tersinkronisasi"
 ],
 "Log messages": [
  null,
  "Pesan log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Secara manual"
 ],
 "Automatically using NTP": [
  null,
  "Secara otomatis menggunakan NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Menggunakan server NTP tambahan secara otomatis"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Menggunakan server NTP tertentu secara otomatis"
 ],
 "Time zone": [
  null,
  "Zona waktu"
 ],
 "Set time": [
  null,
  "Atur waktu"
 ],
 "Invalid timezone": [
  null,
  "Zona waktu tidak valid"
 ],
 "Need at least one NTP server": [
  null,
  "Membutuhkan setidaknya satu server NTP"
 ],
 "Change system time": [
  null,
  "Ubah Waktu Sistem"
 ],
 "Change": [
  null,
  "Ubah"
 ],
 "Path to file": [
  null,
  "Jalur ke berkas"
 ],
 "No such file or directory": [
  null,
  "Tidak ada berkas atau direktori"
 ],
 "Create $0": [
  null,
  "Buat $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Pelajari lebih lanjut"
 ],
 "You now have administrative access.": [
  null,
  "Anda sekarang memiliki akses administratif."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Tidak ada metode untuk mendapatkan akses administratif yang tersedia (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Silakan autentikasi untuk mendapatkan akses administratif"
 ],
 "Switch to administrative access": [
  null,
  "Beralih ke akses administratif"
 ],
 "Authenticate": [
  null,
  "Autentikasi"
 ],
 "Administrative access": [
  null,
  "Akses administratif"
 ],
 "Problem becoming administrator": [
  null,
  "Masalah saat menjadi administrator"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Limit access": [
  null,
  "Batasi akses"
 ],
 "Switch to limited access": [
  null,
  "Beralih ke mode akses terbatas"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Mode akses terbatas membatasi hak administratif. Beberapa bagian dari konsol web akan memiliki fungsionalitas yang terbatas."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Peramban Anda akan mengingat tingkat akses Anda di seluruh sesi."
 ],
 "Limited access": [
  null,
  "Akses terbatas"
 ],
 "Turn on administrative access": [
  null,
  "Aktifkan akses administratif"
 ],
 "$0 year": [
  null,
  "$0 tahun"
 ],
 "$0 month": [
  null,
  "$0 bulan"
 ],
 "$0 week": [
  null,
  "$0 minggu"
 ],
 "$0 day": [
  null,
  "$0 hari"
 ],
 "$0 hour": [
  null,
  "$0 jam"
 ],
 "$0 minute": [
  null,
  "$0 menit"
 ],
 "Go to now": [
  null,
  "Pergi ke sekarang"
 ],
 "1 hour": [
  null,
  "1 jam"
 ],
 "6 hours": [
  null,
  "6 jam"
 ],
 "1 day": [
  null,
  "1 hari"
 ],
 "1 week": [
  null,
  "1 minggu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Gagal mengaktifkan $0 di firewalld"
 ],
 "Visit firewall": [
  null,
  "Kunjungi firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Tambahkan $0"
 ],
 "less than a minute ago": [
  null,
  "kurang dari satu menit yang lalu"
 ],
 "in less than a minute": [
  null,
  "dalam waktu kurang dari satu menit"
 ],
 "Password is too weak": [
  null,
  "Kata sandi terlalu lemah"
 ],
 "Excellent password": [
  null,
  "Sandi bagus"
 ],
 "Password is not acceptable": [
  null,
  "Kata sandi tidak dapat diterima"
 ],
 "Strong password": [
  null,
  "Kata sandi kuat"
 ],
 "Acceptable password": [
  null,
  "Kata sandi dapat diterima"
 ],
 "Weak password": [
  null,
  "Kata sandi lemah"
 ],
 "Show password": [
  null,
  "Tampilkan kata sandi"
 ],
 "Hide password": [
  null,
  "Sembunyikan kata sandi"
 ],
 "password quality": [
  null,
  "kualitas kata sandi"
 ],
 "Show confirmation password": [
  null,
  "Tampilkan konfirmasi kata sandi"
 ],
 "Hide confirmation password": [
  null,
  "Sembunyikan konfirmasi kata sandi"
 ],
 "Additional packages:": [
  null,
  "Paket tambahan:"
 ],
 "Removals:": [
  null,
  "Penghapusan:"
 ],
 "Total size: $0": [
  null,
  "Total ukuran: $0"
 ],
 "Install software": [
  null,
  "Instal perangkat lunak"
 ],
 "$0 will be installed.": [
  null,
  "$0 akan diinstal."
 ],
 "Install": [
  null,
  "Instal"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Menunggu operasi pengelolaan perangkat lunak lain selesai"
 ],
 "Checking installed software": [
  null,
  "Memeriksa perangkat lunak yang terpasang"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 tidak tersedia dari repositori mana pun."
 ],
 "Downloading $0": [
  null,
  "Mengunduh $0"
 ],
 "Removing $0": [
  null,
  "Menghapus $0"
 ],
 "Installing $0": [
  null,
  "Memasang $0"
 ],
 "Unknown host: $0": [
  null,
  "Host tidak dikenal: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Tidak dapat masuk ke $0 menggunakan autentikasi kunci SSH. Harap berikan kata sandi."
 ],
 "SSH key login": [
  null,
  "Login dengan kunci SSH"
 ],
 "[no data]": [
  null,
  "[Tidak ada data]"
 ],
 "[binary data]": [
  null,
  "[data biner]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit berhenti secara mendadak"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit melaporkan kode kesalahan $0"
 ],
 "show less": [
  null,
  "tampilkan lebih sedikit"
 ],
 "show more": [
  null,
  "tampilkan lebih banyak"
 ],
 "Row expansion": [
  null,
  "Perluasan baris"
 ],
 "Row select": [
  null,
  "Pilih baris"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Tempel"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Kesalahan menempel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Peramban Anda tidak mengizinkan tempel dari menu konteks. Anda dapat menggunakan Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Kesalahan saat inisialisasi"
 ],
 "Failed": [
  null,
  "Gagal"
 ],
 "Home": [
  null,
  "Beranda"
 ],
 "Downloads": [
  null,
  "Unduhan"
 ],
 "Not a directory": [
  null,
  "Bukan direktori"
 ],
 "All files": [
  null,
  "Semua berkas"
 ],
 "Recent": [
  null,
  "Terbaru"
 ],
 "No recent directories": [
  null,
  "Tidak ada direktori terbaru"
 ],
 "No recent files": [
  null,
  "Tidak ada berkas terbaru"
 ],
 "Type to filter": [
  null,
  "Ketik untuk memfilter"
 ],
 "File chooser actions": [
  null,
  "Tindakan pemilih berkas"
 ],
 "Open in file browser": [
  null,
  "Buka di peramban berkas"
 ],
 "Hide hidden files": [
  null,
  "Sembunyikan berkas tersembunyi"
 ],
 "Show hidden files": [
  null,
  "Tampilkan berkas tersembunyi"
 ],
 "Filesystem": [
  null,
  "Sistem berkas"
 ],
 "Clear filters": [
  null,
  "Hapus filter"
 ],
 "Directory is empty": [
  null,
  "Direktori kosong"
 ],
 "Directory has no sub-directories": [
  null,
  "Direktori tidak memiliki subdirektori"
 ],
 "This directory contains only hidden files": [
  null,
  "Direktori ini hanya berisi berkas tersembunyi"
 ],
 "No matching results": [
  null,
  "Tidak ada hasil yang cocok"
 ],
 "Folder": [
  null,
  "Folder"
 ],
 "File": [
  null,
  "Berkas"
 ],
 "Copy to clipboard": [
  null,
  "Salin ke papan klip"
 ],
 "Automation script": [
  null,
  "Skrip otomatisasi"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Buat berkas tugas baru dengan konten ini."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentasi peran Ansible"
 ],
 "Shell script": [
  null,
  "Skrip shell"
 ],
 "No system modifications": [
  null,
  "Tidak ada modifikasi sistem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Pengguna yang masuk tidak diizinkan melihat modifikasi sistem"
 ],
 "Loading system modifications...": [
  null,
  "Memuat modifikasi sistem..."
 ],
 "View automation script": [
  null,
  "Lihat skrip otomatisasi"
 ],
 "Occurrences": [
  null,
  "Kejadian"
 ],
 "View all logs": [
  null,
  "Lihat semua log"
 ],
 "Other": [
  null,
  "Lainnya"
 ],
 "Unknown": [
  null,
  "Tidak diketahui"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop profil rendah"
 ],
 "Pizza box": [
  null,
  "Casing pipih (Pizza box)"
 ],
 "Mini tower": [
  null,
  "Menara mini"
 ],
 "Tower": [
  null,
  "Menara"
 ],
 "Portable": [
  null,
  "Portabel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Perangkat genggam"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer hemat ruang"
 ],
 "Lunch box": [
  null,
  "Casing kecil"
 ],
 "Main server chassis": [
  null,
  "Chassis server utama"
 ],
 "Expansion chassis": [
  null,
  "Chassis ekspansi"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassis ekspansi bus"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferal"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis rak mount"
 ],
 "Sealed-case PC": [
  null,
  "PC tertutup rapat"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multi-sistem"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Advanced TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Penutup pisau"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Dapat dilepas"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC Embedded"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "PC stik"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Peringkat tunggal"
 ],
 "Dual rank": [
  null,
  "Peringkat ganda"
 ],
 "Absent": [
  null,
  "Absen"
 ],
 "Present": [
  null,
  "Ada"
 ],
 "Old password not accepted": [
  null,
  "Kata sandi lama tidak diterima"
 ],
 "Failed to change password": [
  null,
  "Gagal mengubah kata sandi"
 ],
 "New password was not accepted": [
  null,
  "Kata sandi baru tidak diterima"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Permintaan melalui ssh-keygen habis waktu"
 ],
 "Not a valid private key": [
  null,
  "Bukan kunci pribadi yang valid"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Permintaan melalui ssh-add habis waktu"
 ],
 "Invalid file permissions": [
  null,
  "Izin berkas tidak valid"
 ],
 "Password not accepted": [
  null,
  "Kata sandi tidak diterima"
 ],
 "Select an option": [
  null,
  "Pilih opsi"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dihentikan dengan sinyal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 keluar dengan kode $1"
 ],
 "$0 failed": [
  null,
  "$0 gagal"
 ],
 "Your session has been terminated.": [
  null,
  "Sesi Anda telah diakhiri."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesi Anda telah kedaluwarsa. Harap login kembali."
 ],
 "Not permitted to perform this action.": [
  null,
  "Tidak diizinkan untuk melakukan tindakan ini."
 ],
 "Login failed": [
  null,
  "Login gagal"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server menolak mengautentikasi menggunakan metode apa pun yang didukung."
 ],
 "Untrusted host": [
  null,
  "Host tidak tepercaya"
 ],
 "Host key is incorrect": [
  null,
  "Kunci host salah"
 ],
 "Internal error": [
  null,
  "Kesalahan internal"
 ],
 "Connection has timed out.": [
  null,
  "Koneksi timeout."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit tidak terpasang pada sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Tidak dapat meneruskan kredensial login"
 ],
 "Server has closed the connection.": [
  null,
  "Server telah menutup koneksi."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit tidak kompatibel dengan perangkat lunak di sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit tidak dapat menghubungi host yang diberikan."
 ],
 "Too much data": [
  null,
  "Terlalu banyak data"
 ],
 "$0 is not a directory": [
  null,
  "$0 bukan direktori"
 ],
 "$0 does not exist": [
  null,
  "$0 tidak ada"
 ],
 "Font size": [
  null,
  "Ukuran font"
 ],
 "Decrease by one": [
  null,
  "Kurangi satu"
 ],
 "Increase by one": [
  null,
  "Naikkan satu"
 ],
 "Appearance": [
  null,
  "Tampilan"
 ],
 "Black": [
  null,
  "Hitam"
 ],
 "White": [
  null,
  "Putih"
 ],
 "Reset": [
  null,
  "Atur ulang"
 ],
 "Unable to open directory": [
  null,
  "Tidak dapat membuka direktori"
 ],
 "Running process prevents directory change": [
  null,
  "Proses yang berjalan mencegah perubahan direktori"
 ],
 "Change directory": [
  null,
  "Ubah direktori"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Mengubah direktori akan secara paksa menghentikan proses yang sedang berjalan. Proses juga dapat dihentikan secara manual di terminal sebelum melanjutkan."
 ],
 "Terminal not available": [
  null,
  "Terminal tidak tersedia"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Browser ini tidak mendukung WebGL2."
 ],
 "unknown": [
  null,
  "tidak diketahui"
 ],
 "Shutdown": [
  null,
  "Matikan"
 ],
 "running $0": [
  null,
  "menjalankan $0"
 ],
 "Current boot": [
  null,
  "Boot saat ini"
 ],
 "Previous boot": [
  null,
  "Boot sebelumnya"
 ],
 "Last 24 hours": [
  null,
  "24 jam terakhir"
 ],
 "Last 7 days": [
  null,
  "7 hari terakhir"
 ],
 "Only emergency": [
  null,
  "Hanya darurat"
 ],
 "Alert and above": [
  null,
  "Peringatan dan di atasnya"
 ],
 "Critical and above": [
  null,
  "Kritis dan di atasnya"
 ],
 "Error and above": [
  null,
  "Kesalahan dan di atasnya"
 ],
 "Warning and above": [
  null,
  "Peringatan dan di atasnya"
 ],
 "Notice and above": [
  null,
  "Pemberitahuan dan di atasnya"
 ],
 "Info and above": [
  null,
  "Info dan di atasnya"
 ],
 "Debug and above": [
  null,
  "Debug dan di atasnya"
 ],
 "Toggle filters": [
  null,
  "Alihkan filter"
 ],
 "Time": [
  null,
  "Waktu"
 ],
 "Priority": [
  null,
  "Prioritas"
 ],
 "Identifier": [
  null,
  "Pengidentifikasi"
 ],
 "Filters": [
  null,
  "Penyaring"
 ],
 "Pause": [
  null,
  "Jeda"
 ],
 "Resume": [
  null,
  "Lanjutkan"
 ],
 "All": [
  null,
  "Semua"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Spesifikasi tanggal harus dalam format YYYY-MM-DD hh:mm:ss. Sebagai alternatif, string 'yesterday', 'today', 'tomorrow' dikenali. 'now' mengacu pada waktu saat ini. Akhirnya, waktu relatif dapat ditentukan, diawali dengan '-' atau '+'."
 ],
 "Since": [
  null,
  "Sejak"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Mulai menampilkan entri pada atau lebih baru dari tanggal yang ditentukan."
 ],
 "Until": [
  null,
  "Hingga"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Mulai menampilkan entri pada atau lebih lama dari tanggal yang ditentukan."
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Show messages from a specific boot.": [
  null,
  "Tampilkan pesan dari boot tertentu."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Ini akan menambahkan pencocokan untuk '_BOOT_ID='. Jika tidak ditentukan, log dari boot saat ini akan ditampilkan. Jika ID boot diabaikan, offset positif akan mencari boot dari awal jurnal, dan offset nol atau negatif akan mencari dari akhir jurnal. Jadi, 1 berarti boot pertama yang ditemukan, 2 berarti yang kedua, dan seterusnya; sedangkan -0 berarti boot terakhir, -1 satu sebelum terakhir, dan seterusnya."
 ],
 "Unit": [
  null,
  "Unit"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Tampilkan pesan untuk unit systemd yang ditentukan."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Ini akan menambahkan pencocokan untuk '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' dan 'UNIT=' untuk menemukan semua pesan yang mungkin untuk unit yang diberikan. Dapat berisi beberapa unit yang dipisahkan dengan koma."
 ],
 "Free-form search": [
  null,
  "Pencarian bebas"
 ],
 "Show messages containing given string.": [
  null,
  "Tampilkan pesan yang berisi string tertentu."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Setiap string teks dalam pesan log dapat difilter. String juga dapat berupa ekspresi reguler. Juga mendukung pemfilteran berdasarkan bidang log pesan. Nilai-nilai ini dipisahkan oleh spasi dalam bentuk FIELD=VALUE, di mana nilai dapat berupa daftar nilai yang dipisahkan koma."
 ],
 "journalctl manpage": [
  null,
  "halaman manual journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Berhasil disalin ke papan klip"
 ],
 "Create timer": [
  null,
  "Buat pengatur waktu"
 ],
 "Edit timer": [
  null,
  "Edit pengatur waktu"
 ],
 "Timer creation failed": [
  null,
  "Pembuatan timer gagal"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Gagal mendapatkan kondisi awal untuk pengatur waktu"
 ],
 "Failed to get the timer command": [
  null,
  "Gagal mendapatkan perintah pengatur waktu"
 ],
 "This field cannot be empty": [
  null,
  "Kolom ini tidak boleh kosong"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Hanya alfabet, angka, :, _, ., @, - yang diizinkan"
 ],
 "Description": [
  null,
  "Deskripsi"
 ],
 "Shell command": [
  null,
  "Perintah shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Perintah ini akan dijalankan oleh /bin/sh."
 ],
 "Trigger": [
  null,
  "Pemicu"
 ],
 "At specific time": [
  null,
  "Pada waktu tertentu"
 ],
 "After system boot": [
  null,
  "Setelah boot sistem"
 ],
 "Seconds": [
  null,
  "Detik"
 ],
 "Minutes": [
  null,
  "Menit"
 ],
 "Hours": [
  null,
  "Jam"
 ],
 "Weeks": [
  null,
  "Minggu"
 ],
 "Delay must be a number": [
  null,
  "Penundaan harus berupa angka"
 ],
 "Repeat": [
  null,
  "Ulangi"
 ],
 "Don't repeat": [
  null,
  "Jangan ulangi"
 ],
 "Minutely": [
  null,
  "Setiap menit"
 ],
 "Hourly": [
  null,
  "Setiap jam"
 ],
 "Daily": [
  null,
  "Harian"
 ],
 "Weekly": [
  null,
  "Mingguan"
 ],
 "Monthly": [
  null,
  "Bulanan"
 ],
 "Yearly": [
  null,
  "Tahunan"
 ],
 "Run at": [
  null,
  "Jalankan pada"
 ],
 "At second": [
  null,
  "Pada detik"
 ],
 "At minute": [
  null,
  "Pada menit"
 ],
 "Run on": [
  null,
  "Jalankan pada"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Menit harus berupa angka antara 0–59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Detik harus berupa angka antara 0–59"
 ],
 "Repeat weekly": [
  null,
  "Ulangi setiap minggu"
 ],
 "Mondays": [
  null,
  "Setiap hari Senin"
 ],
 "Tuesdays": [
  null,
  "Setiap hari Selasa"
 ],
 "Wednesdays": [
  null,
  "Setiap hari Rabu"
 ],
 "Thursdays": [
  null,
  "Setiap hari Kamis"
 ],
 "Fridays": [
  null,
  "Setiap hari Jumat"
 ],
 "Saturdays": [
  null,
  "Setiap hari Sabtu"
 ],
 "Sundays": [
  null,
  "Setiap hari Minggu"
 ],
 "Repeat monthly": [
  null,
  "Ulangi setiap bulan"
 ],
 "1st": [
  null,
  "1"
 ],
 "2nd": [
  null,
  "2"
 ],
 "3rd": [
  null,
  "3"
 ],
 "4th": [
  null,
  "4"
 ],
 "5th": [
  null,
  "5"
 ],
 "6th": [
  null,
  "6"
 ],
 "7th": [
  null,
  "7"
 ],
 "8th": [
  null,
  "8"
 ],
 "9th": [
  null,
  "Ke-9"
 ],
 "10th": [
  null,
  "10"
 ],
 "11th": [
  null,
  "11"
 ],
 "12th": [
  null,
  "12"
 ],
 "13th": [
  null,
  "13"
 ],
 "14th": [
  null,
  "14"
 ],
 "15th": [
  null,
  "15"
 ],
 "16th": [
  null,
  "16"
 ],
 "17th": [
  null,
  "17"
 ],
 "18th": [
  null,
  "18"
 ],
 "19th": [
  null,
  "19"
 ],
 "20th": [
  null,
  "20"
 ],
 "21th": [
  null,
  "Ke-21"
 ],
 "22th": [
  null,
  "Ke-22"
 ],
 "23th": [
  null,
  "Ke-23"
 ],
 "24th": [
  null,
  "24"
 ],
 "25th": [
  null,
  "25"
 ],
 "26th": [
  null,
  "26"
 ],
 "27th": [
  null,
  "27"
 ],
 "28th": [
  null,
  "28"
 ],
 "29th": [
  null,
  "29"
 ],
 "30th": [
  null,
  "30"
 ],
 "31st": [
  null,
  "31"
 ],
 "Save": [
  null,
  "Simpan"
 ],
 "Unclean shutdown": [
  null,
  "Shutdown tidak bersih"
 ],
 "View logs": [
  null,
  "Lihat log"
 ],
 "Dismiss": [
  null,
  "Abaikan"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Pematian daya terjadwal pada $0"
 ],
 "Cancel poweroff": [
  null,
  "Batalkan pematian daya"
 ],
 "Scheduled reboot at $0": [
  null,
  "Reboot terjadwal pada $0"
 ],
 "Cancel reboot": [
  null,
  "Batalkan reboot"
 ],
 "edit": [
  null,
  "ubah"
 ],
 "Set hostname": [
  null,
  "Atur nama host"
 ],
 "Configuration": [
  null,
  "Konfigurasi"
 ],
 "Hostname": [
  null,
  "Nama host"
 ],
 "System time": [
  null,
  "Waktu sistem"
 ],
 "Domain": [
  null,
  "Domain"
 ],
 "Performance profile": [
  null,
  "Profil kinerja"
 ],
 "Secure shell keys": [
  null,
  "Kunci shell aman"
 ],
 "Show fingerprints": [
  null,
  "Tampilkan sidik jari"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "gagal menampilkan daftar kunci host ssh: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Gagal memuat kunci SSH"
 ],
 "Error message": [
  null,
  "Pesan kesalahan"
 ],
 "Loading keys...": [
  null,
  "Memuat kunci..."
 ],
 "No host keys found.": [
  null,
  "Tidak ada kunci host yang ditemukan."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Sidik jari kunci SSH mesin"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Nama host sebenarnya harus 64 karakter atau kurang"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Nama host sebenarnya hanya boleh berisi huruf kecil, angka, tanda hubung, dan titik (dengan subdomain terisi)"
 ],
 "Change host name": [
  null,
  "Ubah Nama Host"
 ],
 "Pretty host name": [
  null,
  "Nama host yang ramah"
 ],
 "Real host name": [
  null,
  "Nama host sebenarnya"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Pengguna $0 tidak diizinkan mengubah kebijakan kriptografi"
 ],
 "Cryptographic policy": [
  null,
  "Kebijakan kriptografi"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Pengaturan aman yang direkomendasikan untuk model ancaman saat ini."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT dengan verifikasi tanda tangan SHA-1 diizinkan."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Interoperabilitas lebih tinggi dengan peningkatan permukaan serangan."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY dengan interoperabilitas Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Hanya gunakan algoritma yang disetujui dan diizinkan saat boot dalam mode FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS dengan pembatasan Common Criteria tambahan."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Melindungi dari serangan jangka pendek yang diantisipasi dengan mengorbankan interoperabilitas."
 ],
 "Custom cryptographic policy": [
  null,
  "Kebijakan kriptografi kustom"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kebijakan Kriptografi adalah komponen sistem yang mengonfigurasi subsistem kriptografi inti, mencakup protokol TLS, IPSec, SSH, DNSSec, dan Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Ubah kebijakan kriptografi"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Menerapkan kebijakan baru... Ini mungkin memakan waktu beberapa menit."
 ],
 "Reapply and reboot": [
  null,
  "Terapkan ulang dan reboot"
 ],
 "Apply and reboot": [
  null,
  "Terapkan dan reboot"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS tidak diaktifkan dengan benar"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Kebijakan kriptografi tidak konsisten"
 ],
 "Review cryptographic policy": [
  null,
  "Tinjau kebijakan kriptografi"
 ],
 "System information": [
  null,
  "Informasi sistem"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Tag aset"
 ],
 "Machine ID": [
  null,
  "ID Mesin"
 ],
 "Up since": [
  null,
  "Aktif sejak"
 ],
 "View hardware details": [
  null,
  "Lihat detail perangkat keras"
 ],
 "Last successful login:": [
  null,
  "Login berhasil terakhir:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 upaya login gagal"
 ],
 "View login history": [
  null,
  "Lihat riwayat login"
 ],
 "recommended": [
  null,
  "direkomendasikan"
 ],
 "inconsistent": [
  null,
  "tidak konsisten"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Bergabung ke domain memerlukan instalasi realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Tidak dapat bergabung ke domain karena realmd tidak tersedia di sistem ini"
 ],
 "Joining this domain is not supported": [
  null,
  "Bergabung dengan domain ini tidak didukung"
 ],
 "Login format": [
  null,
  "Format login"
 ],
 "Server software": [
  null,
  "Perangkat lunak server"
 ],
 "Client software": [
  null,
  "Perangkat lunak klien"
 ],
 "Leave domain": [
  null,
  "Keluar dari domain"
 ],
 "Leave $0": [
  null,
  "Keluar dari $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Setelah keluar dari domain, hanya pengguna dengan kredensial lokal yang dapat masuk ke mesin ini. Ini juga dapat memengaruhi layanan lain karena pengaturan resolusi DNS dan daftar CA tepercaya dapat berubah."
 ],
 "Validating address": [
  null,
  "Memvalidasi alamat"
 ],
 "Contacted domain": [
  null,
  "Domain yang dihubungi"
 ],
 "Domain could not be contacted": [
  null,
  "Domain tidak dapat dihubungi"
 ],
 "Domain is not supported": [
  null,
  "Domain tidak didukung"
 ],
 "Domain address": [
  null,
  "Alamat Domain"
 ],
 "Domain administrator name": [
  null,
  "Nama administrator domain"
 ],
 "Domain administrator password": [
  null,
  "Kata sandi administrator domain"
 ],
 "Joining": [
  null,
  "Sedang bergabung"
 ],
 "Join": [
  null,
  "Bergabung"
 ],
 "This may take a while": [
  null,
  "Ini mungkin memerlukan waktu"
 ],
 "Not permitted to configure realms": [
  null,
  "Tidak diizinkan untuk mengonfigurasi realm"
 ],
 "Join domain": [
  null,
  "Bergabung dengan domain"
 ],
 "Install realmd support": [
  null,
  "Instal dukungan realmd"
 ],
 "$0 disk is failing": [
  null,
  "Disk $0 mengalami kegagalan"
 ],
 "Connected to Insights": [
  null,
  "Terhubung dengan Wawasan"
 ],
 "Not connected to Insights": [
  null,
  "Tidak terhubung ke Insights"
 ],
 "Health": [
  null,
  "Kesehatan"
 ],
 "of $0 CPU": [
  null,
  "dari $0 CPU"
 ],
 "Usage": [
  null,
  "Penggunaan"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memori"
 ],
 "View metrics and history": [
  null,
  "Lihat metrik dan riwayat"
 ],
 "Tuned is not available": [
  null,
  "Tuned tidak tersedia"
 ],
 "Tuned is not running": [
  null,
  "Tuned tidak berjalan"
 ],
 "Tuned is off": [
  null,
  "Tuned dimatikan"
 ],
 "This system is using the recommended profile": [
  null,
  "Sistem ini menggunakan profil yang direkomendasikan"
 ],
 "This system is using a custom profile": [
  null,
  "Sistem ini menggunakan profil kustom"
 ],
 "none": [
  null,
  "tidak ada"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikasi dengan tuned gagal"
 ],
 "Failed to enable tuned": [
  null,
  "Gagal mengaktifkan tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Gagal menonaktifkan tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Gagal menonaktifkan profil tuned"
 ],
 "Failed to switch profile": [
  null,
  "Gagal beralih profil"
 ],
 "None": [
  null,
  "Tidak ada"
 ],
 "Disable tuned": [
  null,
  "Nonaktifkan tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned gagal dimulai"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned adalah layanan yang memantau sistem Anda dan mengoptimalkan kinerjanya di bawah beban kerja tertentu. Inti dari Tuned adalah profil yang menyesuaikan sistem Anda untuk berbagai kasus penggunaan."
 ],
 "Change performance profile": [
  null,
  "Ubah Profil Kinerja"
 ],
 "Change profile": [
  null,
  "Ubah profil"
 ],
 "Edit /etc/motd": [
  null,
  "Edit /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Gagal menyimpan perubahan di /etc/motd"
 ],
 "Save changes": [
  null,
  "Simpan perubahan"
 ],
 "Edit motd": [
  null,
  "Edit motd"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Not found": [
  null,
  "Tidak ditemukan"
 ],
 "Bad setting": [
  null,
  "Pengaturan buruk"
 ],
 "Error": [
  null,
  "Kesalahan"
 ],
 "Merged": [
  null,
  "Digabung"
 ],
 "Running": [
  null,
  "Berjalan"
 ],
 "Reloading": [
  null,
  "Memuat ulang"
 ],
 "Not running": [
  null,
  "Tidak berjalan"
 ],
 "Failed to start": [
  null,
  "Gagal memulai"
 ],
 "Maintenance": [
  null,
  "Pemeliharaan"
 ],
 "Enabled": [
  null,
  "Diaktifkan"
 ],
 "Disabled": [
  null,
  "Dinonaktifkan"
 ],
 "Linked": [
  null,
  "Tertaut"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Tertutup (Masked)"
 ],
 "Static": [
  null,
  "Statis"
 ],
 "Invalid": [
  null,
  "Tidak valid"
 ],
 "Indirect": [
  null,
  "Tidak langsung"
 ],
 "Generated": [
  null,
  "Dihasilkan"
 ],
 "Transient": [
  null,
  "Sementara"
 ],
 "Bad": [
  null,
  "Buruk"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Gagal berlangganan sinyal systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Gagal terhubung ke dbus: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Gagal membaca daftar unit: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 service telah gagal"
 ],
 "Loading of units failed": [
  null,
  "Gagal memuat unit"
 ],
 "Loading...": [
  null,
  "Memuat..."
 ],
 "Listing units": [
  null,
  "Membaca daftar unit"
 ],
 "Filter by name or description": [
  null,
  "Saring berdasarkan nama atau deskripsi"
 ],
 "Active state": [
  null,
  "Status aktif"
 ],
 "File state": [
  null,
  "Status berkas"
 ],
 "$0 filters applied": [
  null,
  "$0 filter diterapkan"
 ],
 "User": [
  null,
  "Pengguna"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Pengguna $0 tidak diizinkan mengubah mitigasi keamanan CPU"
 ],
 "Mitigations": [
  null,
  "Mitigasi"
 ],
 "Version": [
  null,
  "Versi"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Versi BIOS"
 ],
 "BIOS date": [
  null,
  "Tanggal BIOS"
 ],
 "CPU security": [
  null,
  "Keamanan CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Nonaktifkan multithreading simultan"
 ],
 "Read more...": [
  null,
  "Baca lebih lanjut..."
 ],
 "Save and reboot": [
  null,
  "Simpan dan reboot"
 ],
 "CPU security toggles": [
  null,
  "Tombol keamanan CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Solusi berbasis perangkat lunak membantu mencegah masalah keamanan CPU. Mitigasi ini memiliki efek samping berupa pengurangan kinerja. Ubah pengaturan ini dengan risiko Anda sendiri."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Kelas"
 ],
 "Vendor": [
  null,
  "Vendor"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Teknologi memori"
 ],
 "Size": [
  null,
  "Ukuran"
 ],
 "State": [
  null,
  "Status"
 ],
 "Rank": [
  null,
  "Peringkat"
 ],
 "Speed": [
  null,
  "Kecepatan"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Melihat informasi memori memerlukan akses administratif."
 ],
 "Overview": [
  null,
  "Ringkasan"
 ],
 "Failed to fetch logs": [
  null,
  "Gagal mengambil log"
 ],
 "Clear all filters": [
  null,
  "Hapus semua filter"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Tidak dapat menemukan log apa pun menggunakan kombinasi filter saat ini."
 ],
 "No logs found": [
  null,
  "Tidak ada log ditemukan"
 ],
 "Load earlier entries": [
  null,
  "Muat entri sebelumnya"
 ],
 "You may try to load older entries.": [
  null,
  "Anda dapat mencoba memuat entri yang lebih lama."
 ],
 "Allow running (unmask)": [
  null,
  "Izinkan berjalan (hapus mask)"
 ],
 "Reload": [
  null,
  "Muat ulang"
 ],
 "Restart": [
  null,
  "Mulai ulang"
 ],
 "Stop": [
  null,
  "Hentikan"
 ],
 "Start": [
  null,
  "Mulai"
 ],
 "Delete": [
  null,
  "Hapus"
 ],
 "Clear 'Failed to start'": [
  null,
  "Hapus 'Gagal memulai'"
 ],
 "Mask service": [
  null,
  "Mask layanan"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Mem-mask layanan mencegah semua unit yang bergantung dari berjalan. Ini dapat memiliki dampak yang lebih besar dari yang diantisipasi. Harap konfirmasi bahwa Anda ingin mem-mask unit ini."
 ],
 "Disallow running (mask)": [
  null,
  "Larangan menjalankan (mask)"
 ],
 "Unpin unit": [
  null,
  "Lepas pin unit"
 ],
 "Pin unit": [
  null,
  "Pasang pin unit"
 ],
 "Additional actions": [
  null,
  "Tindakan tambahan"
 ],
 "Note": [
  null,
  "Catatan"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Unit ini tidak dirancang untuk diaktifkan secara eksplisit."
 ],
 "Forbidden from running": [
  null,
  "Dilarang berjalan"
 ],
 "Start service": [
  null,
  "Mulai layanan"
 ],
 "Active since ": [
  null,
  "Aktif sejak "
 ],
 "Required by ": [
  null,
  "Dibutuhkan oleh "
 ],
 "Read-only": [
  null,
  "Hanya-baca"
 ],
 "Requires administration access to edit": [
  null,
  "Memerlukan akses administratif untuk mengedit"
 ],
 "Automatically starts": [
  null,
  "Mulai secara otomatis"
 ],
 "Updating status...": [
  null,
  "Memperbarui status..."
 ],
 "Stop and disable": [
  null,
  "Hentikan dan nonaktifkan"
 ],
 "Start and enable": [
  null,
  "Mulai dan aktifkan"
 ],
 "Failed to load unit": [
  null,
  "Gagal memuat unit"
 ],
 "View all services": [
  null,
  "Lihat semua layanan"
 ],
 "Triggers": [
  null,
  "Pemicu"
 ],
 "Triggered by": [
  null,
  "Dipicu oleh"
 ],
 "Requires": [
  null,
  "Membutuhkan"
 ],
 "Requisite": [
  null,
  "Syarat"
 ],
 "Wants": [
  null,
  "Membutuhkan"
 ],
 "Binds to": [
  null,
  "Terikat ke"
 ],
 "Part of": [
  null,
  "Bagian dari"
 ],
 "Required by": [
  null,
  "Dibutuhkan oleh"
 ],
 "Requisite of": [
  null,
  "Syarat dari"
 ],
 "Wanted by": [
  null,
  "Dibutuhkan oleh"
 ],
 "Bound by": [
  null,
  "Terikat oleh"
 ],
 "Consists of": [
  null,
  "Terdiri dari"
 ],
 "Conflicts": [
  null,
  "Konflik"
 ],
 "Conflicted by": [
  null,
  "Bertentangan dengan"
 ],
 "Before": [
  null,
  "Sebelum"
 ],
 "After": [
  null,
  "Setelah"
 ],
 "On failure": [
  null,
  "Saat gagal"
 ],
 "Propagates reload to": [
  null,
  "Menyebarkan muat ulang ke"
 ],
 "Reload propagated from": [
  null,
  "Muat ulang disebarkan dari"
 ],
 "Joins namespace of": [
  null,
  "Bergabung dengan namespace dari"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Kondisi $0=$1 tidak terpenuhi"
 ],
 "Deletion will remove the following files:": [
  null,
  "Penghapusan akan menghapus berkas berikut:"
 ],
 "Pinned unit": [
  null,
  "Unit tersemat"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Path": [
  null,
  "Jalur"
 ],
 "Listen": [
  null,
  "Dengarkan"
 ],
 "Container": [
  null,
  "Kontainer"
 ],
 "View Podman container": [
  null,
  "Lihat kontainer Podman"
 ],
 "Condition failed": [
  null,
  "Kondisi gagal"
 ],
 "Show more relationships": [
  null,
  "Tampilkan lebih banyak hubungan"
 ],
 "Show relationships": [
  null,
  "Tampilkan hubungan"
 ],
 "Confirm deletion of $0": [
  null,
  "Konfirmasi penghapusan $0"
 ],
 "Timer deletion failed": [
  null,
  "Penghapusan timer gagal"
 ],
 "Targets": [
  null,
  "Target"
 ],
 "Sockets": [
  null,
  "Soket"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Paths": [
  null,
  "Path"
 ],
 "Go to $0": [
  null,
  "Pergi ke $0"
 ],
 "Journal entry not found": [
  null,
  "Entri jurnal tidak ditemukan"
 ],
 "Journal entry": [
  null,
  "Entri jurnal"
 ],
 "Entry at $0": [
  null,
  "Entri di $0"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Loading unit failed": [
  null,
  "Gagal memuat unit"
 ],
 "Service logs": [
  null,
  "Log layanan"
 ],
 "No log entries": [
  null,
  "Tidak ada entri log"
 ],
 "Systemd units": [
  null,
  "Unit systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Tidak ada hasil yang sesuai dengan kriteria filter. Hapus semua filter untuk menampilkan hasil."
 ],
 "Does not automatically start": [
  null,
  "Tidak mulai secara otomatis"
 ],
 "Cannot be enabled": [
  null,
  "Tidak dapat diaktifkan"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Konsol web berjalan dalam mode akses terbatas."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsol Web untuk server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit adalah manajer server yang memudahkan administrasi server Linux Anda melalui browser web. Berpindah antara terminal dan alat web tidak menjadi masalah. Layanan yang dijalankan melalui Cockpit dapat dihentikan melalui terminal. Demikian pula, jika terjadi kesalahan di terminal, hal itu dapat dilihat di antarmuka jurnal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit sempurna untuk sysadmin baru, memungkinkan mereka melakukan tugas sederhana dengan mudah seperti administrasi penyimpanan, memeriksa jurnal, serta memulai dan menghentikan layanan. Anda dapat memantau dan mengelola beberapa server sekaligus. Cukup tambahkan dengan satu klik, dan mesin Anda akan saling menjaga."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Setelah Cockpit diinstal, aktifkan dengan \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurasi Cockpit untuk NetworkManager dan Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Alat ini mengelola jaringan seperti bond, bridge, team, VLAN, dan firewall menggunakan NetworkManager dan Firewalld. NetworkManager tidak kompatibel dengan systemd-networkd bawaan Ubuntu dan skrip ifupdown milik Debian."
 ],
 "Manage storage": [
  null,
  "Kelola penyimpanan"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Alat ini mengelola penyimpanan lokal seperti sistem berkas, grup volume LVM2, dan mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kumpulkan dan kemas data diagnostik serta dukungan"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Alat ini menghasilkan arsip berisi informasi konfigurasi dan diagnostik dari sistem yang sedang berjalan. Arsip dapat disimpan secara lokal atau pusat untuk pencatatan atau pelacakan, atau dikirim ke tim dukungan teknis, pengembang, atau administrator sistem untuk membantu dalam analisis kesalahan dan debugging teknis."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfigurasi dan pemecahan masalah Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Alat ini mengonfigurasi kebijakan SELinux dan membantu memahami serta menyelesaikan pelanggaran kebijakan."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kumpulkan dump crash kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Alat ini mengonfigurasi sistem untuk menulis dump crash kernel. Ini mendukung target dump \"local\" (disk), \"ssh\", dan \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrasi dengan Konsol Web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentikasi diperlukan untuk melakukan tugas berprivileg dengan Konsol Web Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "dari $0 pada $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "dari $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "pada $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domain"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Bergabung dengan domain"
 ]
});
