cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sq",
  "language-direction": "ltr"
 }
});
