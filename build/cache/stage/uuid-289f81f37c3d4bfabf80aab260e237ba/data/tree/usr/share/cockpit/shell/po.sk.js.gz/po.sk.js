cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "User name": [
  null,
  "Meno používateľa"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Comment": [
  null,
  "Komentár"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Fingerprint": [
  null,
  "Odtlačok"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Change password": [
  null,
  "Zmeniť heslo"
 ],
 "Password changed successfully": [
  null,
  "Heslo bolo úspešne zmenené"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "Confirm password": [
  null,
  "Potvrdiť heslo"
 ],
 "Password tip": [
  null,
  "Pomôcka pre heslo"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tip: Nastavte si heslo ku kľúču rovnaké ako pre prihlasovanie a budete se voči ostatným systémom overovať automaticky."
 ],
 "Unlock key $0": [
  null,
  "Odomknúť kľúč $0"
 ],
 "Unlock": [
  null,
  "Odomknúť"
 ],
 "Add key": [
  null,
  "Pridať kĺúč"
 ],
 "SSH keys": [
  null,
  "SSH kľúče"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Pre overovanie voči ostatným systémom použiť nasledujúce kľúče"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Toggle": [
  null,
  "Prepnúť"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Public key": [
  null,
  "Verejný kľúč"
 ],
 "Use key": [
  null,
  "Použiť kľúč"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Hosts": [
  null,
  "Hostitelia"
 ],
 "Connection error": [
  null,
  "Chyba pripojenia"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Add new host": [
  null,
  "Pridať nového hostiteľa"
 ],
 "Host": [
  null,
  "Hostiteľ"
 ],
 "Stop editing hosts": [
  null,
  "Ukončiť upravovanie hostiteľov"
 ],
 "Edit hosts": [
  null,
  "Upraviť hostiteľov"
 ],
 "active": [
  null,
  "Aktívna"
 ],
 "Active pages": [
  null,
  "Aktívne stránky"
 ],
 "Page name": [
  null,
  "Názov stránky"
 ],
 "There are currently no active pages": [
  null,
  "V tejto chvíli tu nie sú žiadne aktívne stránky"
 ],
 "Close selected pages": [
  null,
  "Zatvoriť vybrané stránky"
 ],
 "$0 documentation": [
  null,
  "Dokumentácia k $0"
 ],
 "About Web Console": [
  null,
  "O webovej konzoli"
 ],
 "Style": [
  null,
  "Štýl"
 ],
 "Default": [
  null,
  "Predvolené"
 ],
 "Light": [
  null,
  "Svetlý"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Display language": [
  null,
  "Jazyk zobrazenia"
 ],
 "Log out": [
  null,
  "Odhlásiť"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Session": [
  null,
  "Sedenie"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licencované pod licenciou GNU LGPL verzie 2.1"
 ],
 "Web Console": [
  null,
  "Webová konzola"
 ],
 "Web console logo": [
  null,
  "Logo webovej konzole"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit je interaktívne rozhranie pre správu linuxových serverov."
 ],
 "Project website": [
  null,
  "Webové stránky projektu"
 ],
 "Loading packages...": [
  null,
  "Načítavam balíčky…"
 ],
 "Choose the language to be used in the application": [
  null,
  "Vyberte jazyk aplikácie"
 ],
 "Filter menu items": [
  null,
  "Filtrovať položky ponuky"
 ],
 "No languages match": [
  null,
  "Nezhoduje sa so žiadnymi jazykmi"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "Unexpected error": [
  null,
  "Neočakávaná chyba"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "V Cockpite nastala neočakávaná vnútorná chyba."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "vo väčšine prehliadačov"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Search": [
  null,
  "Hľadať"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "Clear search": [
  null,
  "Vyčistiť vyhľadávanie"
 ],
 "Contains:": [
  null,
  "Obsahuje:"
 ],
 "Apps": [
  null,
  "Aplikácie"
 ],
 "Tools": [
  null,
  "Nástroje"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Nepodarilo sa kontaktovať uvedený stroj $0. Overte, či ssh beží na porte $1 alebo zadajte v jeho adrese iný port."
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  ""
 ],
 "Connect": [
  null,
  "Pripojiť"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP adresa alebo názov stroja nemôže obsahovať prázdny znak."
 ],
 "This machine has already been added.": [
  null,
  "Tento stroj už bol pridaný."
 ],
 "Failed to add machine: $0": [
  null,
  "Nepodarilo sa pridať stroj: $0"
 ],
 "Edit host": [
  null,
  "Upraviť hostiteľa"
 ],
 "Set": [
  null,
  "Nastaviť"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Môže byť názov hostiteľa, IP adresa, alias alebo ssh:// URI"
 ],
 "When empty, connect with the current user": [
  null,
  "Ak je prázdne, pripojíte sa ako aktuálny používateľ"
 ],
 "Color": [
  null,
  "Farba"
 ],
 "Failed to edit machine: $0": [
  null,
  "Nepodarilo sa upraviť stroj: $0"
 ],
 "Could not contact $0": [
  null,
  "Nedarí sa kontaktovať $0"
 ],
 "Update": [
  null,
  "Aktualizovať"
 ],
 "Unable to contact $0.": [
  null,
  "Nedarí sa kontaktovať $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "Nie je sshd pustené na inom porte?"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "New host: $0": [
  null,
  "Nový hostiteľ: $0"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Škodlivé stránky na vzdialenom stroji môžu postihnúť ďalšie pripojené stroje"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "The new key password can not be empty": [
  null,
  "Nové heslo ku kľúču nemôže byť prázdne"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Nepodarilo sa prihlásiť k $0 pomocou overenia SSH kľúčom. Zadajte, prosím, heslo. Ak sa chcete prihlasovať automaticky, nastavte SSH kľúče."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Pre automatické prihlasovanie sa budete možno chcieť zmeniť heslo ku kľúču."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Aby v budúcnosti bolo možné prihlasovanie k $0 ako $1 bez hesla, použite prihlasovacie heslo používateľa $2 na $3 ako heslo ku kľúču alebo heslo ku kľúču nevyplňujte."
 ],
 "Change the password of $0": [
  null,
  "Zmeniť heslo kľúča $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Zmenou hesla k SSH kľúču $0 na prihlasovacie heslo používateľa $1 na $2 bude kľúč automaticky sprístupnený a na $3 sa nabudúce prihlásite už bez hesla."
 ],
 "New key password": [
  null,
  "Nové heslo ku kľúču"
 ],
 "Confirm new key password": [
  null,
  "Potvrdiť nové heslo ku kľúču"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Toto vám umožní sa nabudúce prihlásiť bez hesla."
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "Automatic login": [
  null,
  "Automatické prihlásenie"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Boli ste odhlásený z dôvodu neaktivity."
 ],
 "Connection failed": [
  null,
  "Pripojenie sa nepodarilo"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Pri pripojovaní k stroji sa vyskytla neočakávaná chyba."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Správy týkajúce sa zlyhania sa môžu nachádzať v žurnále:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Používatelia prehliadača Safari si budú musieť importovať samopodpísaný (self-signed) certifikát certifikačnej autority a nastaviť ho ako dôveryhodný:"
 ],
 "Reconnect": [
  null,
  "Znovu pripojiť"
 ],
 "Disconnected": [
  null,
  "Odpojené"
 ],
 "The machine is rebooting": [
  null,
  "Stroj sa reštartuje"
 ],
 "Connecting to the machine": [
  null,
  "Pripájam sa ku stroju"
 ],
 "Not connected to host": [
  null,
  "Nepripojené k hostiteľovi"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nie je možné sa prihlásiť k neznámemu hostiteľovi"
 ],
 "Session is about to expire": [
  null,
  "Relácia čoskoro skončí"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Budete odhlásený za $0 sekúnd."
 ],
 "Continue session": [
  null,
  "Pokračovať v relácii"
 ],
 "Skip to content": [
  null,
  "Preskočiť na bo"
 ],
 "Skip main navigation": [
  null,
  "Preskočiť hlavnú navigáciu"
 ],
 "Permission denied": [
  null,
  "Prístup odmietnutý"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "You now have administrative access.": [
  null,
  "Teraz máte prístup na úrovni správcu systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pre získanie prístupu na úrovni správcu sa prosím overte"
 ],
 "Switch to administrative access": [
  null,
  "Prepnúť na prístup pre správcu"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s prepínaním na správcu"
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Limit access": [
  null,
  "Obmedziť prístup"
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim obmedzeného prístupu obmedzuje oprávnenia pre správu. Niektoré časti webovej konzole budú poskytovať menej funkcií."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prehliadač si bude úroveň prístupu pamätať aj pre budúce spustenia."
 ],
 "Limited access": [
  null,
  "Obmedzený prístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnúť prístup na úrovni správcu"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásil chybový kód $0"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrujte písaním"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Súborový systém"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Súbor"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ]
});
