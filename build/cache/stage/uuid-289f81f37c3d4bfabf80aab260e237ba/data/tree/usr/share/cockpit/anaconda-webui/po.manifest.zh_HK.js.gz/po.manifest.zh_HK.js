cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_HK",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
