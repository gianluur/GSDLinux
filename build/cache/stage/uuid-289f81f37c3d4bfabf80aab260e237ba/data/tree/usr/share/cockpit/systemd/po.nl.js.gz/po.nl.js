cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Journal": [
  null,
  "Logboek"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Hardware informatie"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "active": [
  null,
  "actief"
 ],
 "Default": [
  null,
  "Standaard"
 ],
 "Light": [
  null,
  "Licht"
 ],
 "Dark": [
  null,
  "Donker"
 ],
 "Help": [
  null,
  "Hulp"
 ],
 "Select": [
  null,
  "Selecteren"
 ],
 "System": [
  null,
  "Systeem"
 ],
 "Search": [
  null,
  "Zoeken"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "Permission denied": [
  null,
  "Toestemming geweigerd"
 ],
 "Clear input value": [
  null,
  "Invoerwaarde wissen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "Create $0": [
  null,
  "Maak $0 aan"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "You now have administrative access.": [
  null,
  "Je hebt nu administratieve toegang."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Authenticeer om administratieve toegang te krijgen"
 ],
 "Switch to administrative access": [
  null,
  "Schakel om naar beheerderstoegang"
 ],
 "Authenticate": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Administrative access": [
  null,
  "Administratieve toegang"
 ],
 "Problem becoming administrator": [
  null,
  "Probleem om beheerder te worden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Beperk toegang"
 ],
 "Switch to limited access": [
  null,
  "Schakel over naar beperkte toegang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "De beperkte toegangsmodus beperkt de beheerdersrechten. Sommige delen van de webconsole hebben een verminderde functionaliteit."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Je browser onthoudt je toegangsniveau tijdens sessies."
 ],
 "Limited access": [
  null,
  "Beperkte toegang"
 ],
 "Turn on administrative access": [
  null,
  "Schakel beheerderstoegang in"
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "less than a minute ago": [
  null,
  "minder dan een minuut geleden"
 ],
 "in less than a minute": [
  null,
  "in minder dan een minuut"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Unknown host: $0": [
  null,
  "Onbekende host: $0"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporteerde foutcode $0"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "Row select": [
  null,
  "Selecteer rij"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Typ om te filteren"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Bestandssysteem"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Geen overeenkomende resultaten"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Bestand"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "$0 is not a directory": [
  null,
  "$0 is geen map"
 ],
 "$0 does not exist": [
  null,
  "$0 bestaat niet"
 ],
 "Font size": [
  null,
  "Lettertypegrootte"
 ],
 "Decrease by one": [
  null,
  "Verlaag met één"
 ],
 "Increase by one": [
  null,
  "Verhogen met één"
 ],
 "Appearance": [
  null,
  "Uiterlijk"
 ],
 "Black": [
  null,
  "Zwart"
 ],
 "White": [
  null,
  "Wit"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Running process prevents directory change": [
  null,
  "Het lopende proces voorkomt dat de map verandert"
 ],
 "Change directory": [
  null,
  "Wijzig map"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Het wijzigen van de directory zal het proces dat op dat moment wordt uitgevoerd, geforceerd stoppen. Het proces kan ook handmatig worden gestopt in de terminal voordat het verdergaat."
 ],
 "unknown": [
  null,
  "onbekend"
 ],
 "Shutdown": [
  null,
  "Afsluiten"
 ],
 "running $0": [
  null,
  "$0 wordt uitgevoerd"
 ],
 "Current boot": [
  null,
  "Huidige opstartprocedure"
 ],
 "Previous boot": [
  null,
  "Vorige opstart"
 ],
 "Last 24 hours": [
  null,
  "Laatste 24 uur"
 ],
 "Last 7 days": [
  null,
  "Laatste 7 dagen"
 ],
 "Only emergency": [
  null,
  "Alleen noodgevallen"
 ],
 "Alert and above": [
  null,
  "Alert en hoger"
 ],
 "Critical and above": [
  null,
  "Kritiek en hoger"
 ],
 "Error and above": [
  null,
  "Fout en hoger"
 ],
 "Warning and above": [
  null,
  "Waarschuwing en hoger"
 ],
 "Notice and above": [
  null,
  "Kennisgeving en hoger"
 ],
 "Info and above": [
  null,
  "Info en hoger"
 ],
 "Debug and above": [
  null,
  "Debug en hoger"
 ],
 "Toggle filters": [
  null,
  "Schakel filters om"
 ],
 "Time": [
  null,
  "Tijd"
 ],
 "Priority": [
  null,
  "Prioriteit"
 ],
 "Identifier": [
  null,
  "Identificatie"
 ],
 "Filters": [
  null,
  "Filters"
 ],
 "Pause": [
  null,
  "Pauze"
 ],
 "Resume": [
  null,
  "Samenvatten"
 ],
 "All": [
  null,
  "Alle"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumspecificaties moeten de notatie JJJJ-MM-DD uu:mm:ss hebben. Als alternatief worden de strings 'yesterday', 'today' en 'tomorrow' gebruikt. 'now' verwijst naar de huidige tijd. Ten slotte kunnen relatieve tijden worden opgegeven, voorafgegaan door '-' of '+'"
 ],
 "Since": [
  null,
  "Sinds"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Begin met het weergeven van ingangen op of nieuwer dan de opgegeven datum."
 ],
 "Until": [
  null,
  "Tot"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Begin met het weergeven van ingangen op of ouder dan de opgegeven datum."
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Show messages from a specific boot.": [
  null,
  "Toon berichten van een specifieke boot."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Dit voegt een overeenkomst toe voor '_BOOT_ID='. Als dit niet is opgegeven, worden de logboeken voor de huidige boot weergegeven. Als de boot-ID wordt weggelaten, zoekt een positieve offset de boots op vanaf het begin van het journaal, en een offset die gelijk is aan of kleiner is dan nul, zoekt de boots op vanaf het einde van het journaal. Dus 1 betekent de eerste boot die in chronologische volgorde in het journaal wordt gevonden, 2 de tweede enzovoort; terwijl -0 de laatste keer opstarten is, -1 de opstart voor het laatst, enzovoort."
 ],
 "Unit": [
  null,
  "Unit"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Toon berichten voor de gespecificeerde systemd unit."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Dit voegt een overeenkomst toe voor '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' en 'UNIT=' om alle mogelijke berichten voor de gegeven eenheid te vinden. Kan meer eenheden bevatten, gescheiden door komma's."
 ],
 "Free-form search": [
  null,
  "Zoeken in vrije vorm"
 ],
 "Show messages containing given string.": [
  null,
  "Toon berichten die een gegeven string bevatten."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Elke tekenreeks in de logboekberichten kan worden gefilterd. De string kan ook de vorm hebben van een reguliere expressie. Ondersteunt ook filteren op berichtlogboekvelden. Dit zijn door spaties gescheiden waarden, in de vorm FIELD=WAARDE, waarbij de waarde een door komma's gescheiden lijst van mogelijke waarden kan zijn."
 ],
 "journalctl manpage": [
  null,
  "journalctl manualpagina"
 ],
 "Successfully copied to clipboard": [
  null,
  "Succesvol naar het klembord gekopieerd"
 ],
 "Create timer": [
  null,
  "Maak timer aan"
 ],
 "Timer creation failed": [
  null,
  "Het aanmaken van de timer is mislukt"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "Dit veld mag niet leeg zijn"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Alleen letters, cijfers, : , _ , . , @ , - zijn toegestaan"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "Trigger"
 ],
 "At specific time": [
  null,
  "Op specifiek tijdstip"
 ],
 "After system boot": [
  null,
  "Na het opstarten van het systeem"
 ],
 "Seconds": [
  null,
  "Seconden"
 ],
 "Minutes": [
  null,
  "Minuten"
 ],
 "Hours": [
  null,
  "Uren"
 ],
 "Weeks": [
  null,
  "Weken"
 ],
 "Delay must be a number": [
  null,
  "Vertraging moet een getal zijn"
 ],
 "Repeat": [
  null,
  "Herhaal"
 ],
 "Don't repeat": [
  null,
  "Niet herhalen"
 ],
 "Minutely": [
  null,
  "Per minuut"
 ],
 "Hourly": [
  null,
  "Elk uur"
 ],
 "Daily": [
  null,
  "Dagelijks"
 ],
 "Weekly": [
  null,
  "Wekelijks"
 ],
 "Monthly": [
  null,
  "Maandelijks"
 ],
 "Yearly": [
  null,
  "Jaarlijks"
 ],
 "Run at": [
  null,
  "Uitvoeren op"
 ],
 "At second": [
  null,
  "Ten tweede"
 ],
 "At minute": [
  null,
  "Op minuut"
 ],
 "Run on": [
  null,
  "Uitvoeren op"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuut moet een getal tussen 0-59 zijn"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Seconde moet een getal tussen 0-59 zijn"
 ],
 "Repeat weekly": [
  null,
  "Wekelijks herhalen"
 ],
 "Mondays": [
  null,
  "maandagen"
 ],
 "Tuesdays": [
  null,
  "dinsdagen"
 ],
 "Wednesdays": [
  null,
  "woensdagen"
 ],
 "Thursdays": [
  null,
  "donderdagen"
 ],
 "Fridays": [
  null,
  "vrijdagen"
 ],
 "Saturdays": [
  null,
  "zaterdagen"
 ],
 "Sundays": [
  null,
  "zondagen"
 ],
 "Repeat monthly": [
  null,
  "Maandelijks herhalen"
 ],
 "1st": [
  null,
  "1e"
 ],
 "2nd": [
  null,
  "2e"
 ],
 "3rd": [
  null,
  "3e"
 ],
 "4th": [
  null,
  "4e"
 ],
 "5th": [
  null,
  "5e"
 ],
 "6th": [
  null,
  "6e"
 ],
 "7th": [
  null,
  "7e"
 ],
 "8th": [
  null,
  "8e"
 ],
 "9th": [
  null,
  "9de"
 ],
 "10th": [
  null,
  "10e"
 ],
 "11th": [
  null,
  "11e"
 ],
 "12th": [
  null,
  "12e"
 ],
 "13th": [
  null,
  "13e"
 ],
 "14th": [
  null,
  "14e"
 ],
 "15th": [
  null,
  "14e"
 ],
 "16th": [
  null,
  "16e"
 ],
 "17th": [
  null,
  "17e"
 ],
 "18th": [
  null,
  "18e"
 ],
 "19th": [
  null,
  "19e"
 ],
 "20th": [
  null,
  "20e"
 ],
 "21th": [
  null,
  "21e"
 ],
 "22th": [
  null,
  "22e"
 ],
 "23th": [
  null,
  "23e"
 ],
 "24th": [
  null,
  "24e"
 ],
 "25th": [
  null,
  "25e"
 ],
 "26th": [
  null,
  "26e"
 ],
 "27th": [
  null,
  "27e"
 ],
 "28th": [
  null,
  "28e"
 ],
 "29th": [
  null,
  "29e"
 ],
 "30th": [
  null,
  "30e"
 ],
 "31st": [
  null,
  "31e"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "View logs": [
  null,
  "Bekijk logboeken"
 ],
 "Dismiss": [
  null,
  "Afwijzen"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Geplande uitschakeling om $0"
 ],
 "Cancel poweroff": [
  null,
  "Uitschakelen annuleren"
 ],
 "Scheduled reboot at $0": [
  null,
  "Geplande herstart om $0"
 ],
 "Cancel reboot": [
  null,
  "Opnieuw starten annuleren"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "Set hostname": [
  null,
  "Stel hostnaam in"
 ],
 "Configuration": [
  null,
  "Configuratie"
 ],
 "Hostname": [
  null,
  "Hostnaam"
 ],
 "System time": [
  null,
  "Systeemtijd"
 ],
 "Domain": [
  null,
  "Domein"
 ],
 "Performance profile": [
  null,
  "Prestatieprofiel"
 ],
 "Secure shell keys": [
  null,
  "Veilige shell-sleutels"
 ],
 "Show fingerprints": [
  null,
  "Toon vingerafdrukken"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "kan ssh-host-sleutels niet vermelden: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Het laden van SSH-sleutels is mislukt"
 ],
 "Error message": [
  null,
  "Foutbericht"
 ],
 "Loading keys...": [
  null,
  "Sleutels laden..."
 ],
 "No host keys found.": [
  null,
  "Geen hostsleutels gevonden ."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Machine SSH-sleutel vingerafdrukken"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Echte hostnaam moet 64 tekens of minder bevatten"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Echte hostnaam mag alleen kleine letters, cijfers, streepjes en punten bevatten (met bevolkte subdomeinen)"
 ],
 "Change host name": [
  null,
  "Verander hostnaam"
 ],
 "Pretty host name": [
  null,
  "Mooie hostnaam"
 ],
 "Real host name": [
  null,
  "Echte hostnaam"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Het is gebruiker $0 niet toegestaan om crypto-beleid te wijzigen"
 ],
 "Cryptographic policy": [
  null,
  "Cryptografisch beleid"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Aanbevolen, veilige instellingen voor huidige dreigingsmodellen."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "STANDAARD met SHA-1 handtekeningverificatie toegestaan."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Hogere interoperabiliteit ten koste van een groter aanvalsoppervlak."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY met Active Directory-interoperabiliteit."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Gebruik alleen goedgekeurde en toegestane algoritmen bij het opstarten in FIPS-modus."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS met verdere Common Criteria-beperkingen."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Beschermt tegen verwachte toekomstige aanvallen op korte termijn ten koste van interoperabiliteit."
 ],
 "Custom cryptographic policy": [
  null,
  "Aangepast cryptografisch beleid"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Crypto-beleid is een systeemcomponent die de belangrijkste cryptografische subsystemen configureert, waaronder de TLS-, IPSec-, SSH-, DNSSec- en Kerberos-protocollen."
 ],
 "Change cryptographic policy": [
  null,
  "Wijzig cryptografisch beleid"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Nieuw beleid toepassen... Dit kan enkele minuten duren."
 ],
 "Reapply and reboot": [
  null,
  "Opnieuw toepassen en opnieuw opstarten"
 ],
 "Apply and reboot": [
  null,
  "Toepassen en opnieuw opstarten"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS is niet correct ingeschakeld"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Crypto-beleid is inconsistent"
 ],
 "Review cryptographic policy": [
  null,
  "Bekijk cryptografisch beleid"
 ],
 "System information": [
  null,
  "Systeeminformatie"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Asset-tag"
 ],
 "Machine ID": [
  null,
  "Machine-ID"
 ],
 "Up since": [
  null,
  "Actief sinds"
 ],
 "View hardware details": [
  null,
  "Bekijk hardwaredetails"
 ],
 "Last successful login:": [
  null,
  "Laatste succesvolle aanmelding:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 mislukte inlogpoging",
  "$0 mislukte inlogpogingen"
 ],
 "View login history": [
  null,
  "Bekijk inloggeschiedenis"
 ],
 "recommended": [
  null,
  "aanbevolen"
 ],
 "inconsistent": [
  null,
  "inconsequent"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Lid worden van een domein vereist de installatie van realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kan geen lid worden van een domein omdat realmd niet beschikbaar is op dit systeem"
 ],
 "Joining this domain is not supported": [
  null,
  "Deelnemen aan dit domein wordt niet ondersteund"
 ],
 "Login format": [
  null,
  "Inlogformaat"
 ],
 "Server software": [
  null,
  "Server software"
 ],
 "Client software": [
  null,
  "Cliënt software"
 ],
 "Leave domain": [
  null,
  "Verlaat domein"
 ],
 "Leave $0": [
  null,
  "Verlaat $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Na het verlaten van het domein kunnen alleen gebruikers met lokale referenties inloggen op deze machine. Dit kan ook andere services beïnvloeden, aangezien de DNS-resolutie-instellingen en de lijst met vertrouwde CA's kunnen veranderen."
 ],
 "Validating address": [
  null,
  "Adres valideren"
 ],
 "Contacted domain": [
  null,
  "Gecontacteerd domein"
 ],
 "Domain could not be contacted": [
  null,
  "Er kan geen contact gemaakt worden met domein"
 ],
 "Domain is not supported": [
  null,
  "Domein wordt niet ondersteund"
 ],
 "Domain address": [
  null,
  "Domeinadres"
 ],
 "Domain administrator name": [
  null,
  "Domeinbeheerdersnaam"
 ],
 "Domain administrator password": [
  null,
  "Domeinbeheerderswachtwoord"
 ],
 "Joining": [
  null,
  "Toetreden"
 ],
 "Join": [
  null,
  "Toetreden"
 ],
 "This may take a while": [
  null,
  "Dit kan een tijdje duren"
 ],
 "Not permitted to configure realms": [
  null,
  "Het is niet toegestaan om realms te configureren"
 ],
 "Join domain": [
  null,
  "Word lid van domein"
 ],
 "Install realmd support": [
  null,
  "Installeer realmd-ondersteuning"
 ],
 "$0 disk is failing": [
  null,
  "$0 schijf is defect",
  "$0 schijven zijn defect"
 ],
 "Not connected to Insights": [
  null,
  "Niet verbonden met Insights"
 ],
 "Health": [
  null,
  "Gezondheid"
 ],
 "of $0 CPU": [
  null,
  "van $0 CPU",
  "van $0 CPU's"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Geheugen"
 ],
 "View metrics and history": [
  null,
  "Bekijk statistieken en geschiedenis"
 ],
 "Tuned is not available": [
  null,
  "Tuned is niet beschikbaar"
 ],
 "Tuned is not running": [
  null,
  "Tuned is niet actief"
 ],
 "Tuned is off": [
  null,
  "Tuned is uitgeschakeld"
 ],
 "This system is using the recommended profile": [
  null,
  "Dit systeem gebruikt het aanbevolen profiel"
 ],
 "This system is using a custom profile": [
  null,
  "Dit systeem gebruikt een aangepast profiel"
 ],
 "none": [
  null,
  "geen"
 ],
 "Communication with tuned has failed": [
  null,
  "Communicatie met tuned is mislukt"
 ],
 "Failed to enable tuned": [
  null,
  "Kan tuned niet inschakelen"
 ],
 "Failed to disable tuned": [
  null,
  "Kan tuned niet uitzetten"
 ],
 "Failed to disable tuned profile": [
  null,
  "Kan tuned profiel niet uitzetten"
 ],
 "Failed to switch profile": [
  null,
  "Kan profiel niet wijzigen"
 ],
 "None": [
  null,
  "Geen"
 ],
 "Disable tuned": [
  null,
  "Schakel tuned uit"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned kan niet gestart worden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned is een service die je systeem bewaakt en de prestaties onder bepaalde werkbelastingen optimaliseert. De kern van Tuned zijn profielen, die je systeem afstemmen op verschillende gebruikssituaties."
 ],
 "Change performance profile": [
  null,
  "Verander prestatieprofiel"
 ],
 "Change profile": [
  null,
  "Verander profiel"
 ],
 "Edit /etc/motd": [
  null,
  "Bewerk /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Kan veranderingen in /etc/motd niet opslaan"
 ],
 "Save changes": [
  null,
  "Sla veranderingen op"
 ],
 "Edit motd": [
  null,
  "Bewerk motd"
 ],
 "Stub": [
  null,
  "Stuk"
 ],
 "Not found": [
  null,
  "Niet gevonden"
 ],
 "Bad setting": [
  null,
  "Slechte instelling"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Merged": [
  null,
  "Samengevoegd"
 ],
 "Running": [
  null,
  "Uitvoeren"
 ],
 "Reloading": [
  null,
  "Opnieuw laden"
 ],
 "Not running": [
  null,
  "Niet actief"
 ],
 "Failed to start": [
  null,
  "Starten mislukt"
 ],
 "Maintenance": [
  null,
  "Onderhoud"
 ],
 "Enabled": [
  null,
  "Ingeschakeld"
 ],
 "Disabled": [
  null,
  "Uitgeschakeld"
 ],
 "Linked": [
  null,
  "Gekoppeld"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Gemaskeerd"
 ],
 "Static": [
  null,
  "Statisch"
 ],
 "Invalid": [
  null,
  "Ongeldig"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Generated": [
  null,
  "Gegenereerd"
 ],
 "Transient": [
  null,
  "Kortstondig"
 ],
 "Bad": [
  null,
  "Slecht"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Abonneren op systemd-signalen is mislukt: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Verbinding met dbus mislukte: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Eenheden weergeven mislukte: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 service is mislukt",
  "$0 services zijn mislukt"
 ],
 "Loading of units failed": [
  null,
  "Het laden van eenheden mislukte"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Listing units": [
  null,
  "Eenheden weergeven"
 ],
 "Filter by name or description": [
  null,
  "Filteren op naam of beschrijving"
 ],
 "Active state": [
  null,
  "Actieve toestand"
 ],
 "File state": [
  null,
  "Bestandstatus"
 ],
 "$0 filters applied": [
  null,
  "$0 filters toegepast"
 ],
 "User": [
  null,
  "Gebruiker"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Het is gebruiker $0 niet toegestaan cpu-beveiligingsmaatregelen te wijzigen"
 ],
 "Mitigations": [
  null,
  "Beperkende factoren"
 ],
 "Version": [
  null,
  "Versie"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS versie"
 ],
 "BIOS date": [
  null,
  "BIOS datum"
 ],
 "CPU security": [
  null,
  "CPU-beveiliging"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Gelijktijdige multithreading uitschakelen"
 ],
 "Read more...": [
  null,
  "Lees meer..."
 ],
 "Save and reboot": [
  null,
  "Opslaan en opnieuw opstarten"
 ],
 "CPU security toggles": [
  null,
  "CPU-beveiliging schakelaars"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Op software gebaseerde oplossingen helpen CPU-beveiligingsproblemen te voorkomen. Deze mitigaties hebben als neveneffect dat ze de prestaties verminderen. Wijzig deze instellingen op eigen risico."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Vendor": [
  null,
  "Leverancier"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Geheugen technologie"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "State": [
  null,
  "Toestand"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Speed": [
  null,
  "Snelheid"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Voor het bekijken van geheugeninformatie is beheerderstoegang vereist."
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "Failed to fetch logs": [
  null,
  "Kan logboeken niet ophalen"
 ],
 "Clear all filters": [
  null,
  "Wis alle filters"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Kan geen logboeken vinden met de huidige combinatie van filters."
 ],
 "No logs found": [
  null,
  "Geen logs gevonden"
 ],
 "Load earlier entries": [
  null,
  "Laad eerdere ingangen"
 ],
 "You may try to load older entries.": [
  null,
  "Je kunt proberen oudere items te laden."
 ],
 "Allow running (unmask)": [
  null,
  "Sta uitvoeren toe (ontmaskeren)"
 ],
 "Reload": [
  null,
  "Opnieuw laden"
 ],
 "Restart": [
  null,
  "Opnieuw starten"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Clear 'Failed to start'": [
  null,
  "Wis 'Kan niet starten'"
 ],
 "Mask service": [
  null,
  "Masker service"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Service maskeren voorkomt dat alle afhankelijke eenheden worden uitgevoerd. Dit kan een grotere impact hebben dan verwacht. Bevestig dat je deze eenheid wilt maskeren."
 ],
 "Disallow running (mask)": [
  null,
  "Uitvoeren niet toestaan (masker)"
 ],
 "Unpin unit": [
  null,
  "Eenheid vrijgeven"
 ],
 "Pin unit": [
  null,
  "Pin-eenheid"
 ],
 "Additional actions": [
  null,
  "Extra acties"
 ],
 "Note": [
  null,
  "Notitie"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Dit apparaat is niet ontworpen om expliciet te worden ingeschakeld."
 ],
 "Forbidden from running": [
  null,
  "Uitvoeren is verboden"
 ],
 "Start service": [
  null,
  "Start service"
 ],
 "Active since ": [
  null,
  "Actief sinds "
 ],
 "Required by ": [
  null,
  "Vereist door "
 ],
 "Read-only": [
  null,
  "Alleen-lezen"
 ],
 "Requires administration access to edit": [
  null,
  "Vereist beheerdersrechten om te bewerken"
 ],
 "Automatically starts": [
  null,
  "Automatisch starten"
 ],
 "Updating status...": [
  null,
  "Status bijwerken..."
 ],
 "Stop and disable": [
  null,
  "Stop en schakel uit"
 ],
 "Start and enable": [
  null,
  "Start en schakel in"
 ],
 "Failed to load unit": [
  null,
  "Kan unit niet laden"
 ],
 "View all services": [
  null,
  "Bekijk alle services"
 ],
 "Triggers": [
  null,
  "Triggers"
 ],
 "Triggered by": [
  null,
  "Veroorzaakt door"
 ],
 "Requires": [
  null,
  "Vereisten"
 ],
 "Requisite": [
  null,
  "Vereiste"
 ],
 "Wants": [
  null,
  "Behoeften"
 ],
 "Binds to": [
  null,
  "Bindt aan"
 ],
 "Part of": [
  null,
  "Onderdeel van"
 ],
 "Required by": [
  null,
  "Vereist door"
 ],
 "Requisite of": [
  null,
  "Vereiste van"
 ],
 "Wanted by": [
  null,
  "Gezocht door"
 ],
 "Bound by": [
  null,
  "Gebonden door"
 ],
 "Consists of": [
  null,
  "Bestaat uit"
 ],
 "Conflicts": [
  null,
  "Conflicten"
 ],
 "Conflicted by": [
  null,
  "Conflict met"
 ],
 "Before": [
  null,
  "Voor"
 ],
 "After": [
  null,
  "Na"
 ],
 "On failure": [
  null,
  "Bij mislukking"
 ],
 "Propagates reload to": [
  null,
  "Propageren herladen naar"
 ],
 "Reload propagated from": [
  null,
  "Opnieuw laden gepropageerd van"
 ],
 "Joins namespace of": [
  null,
  "Word lid van de naamruimte van"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Aan conditie $0=$1 werd niet voldaan"
 ],
 "Deletion will remove the following files:": [
  null,
  "Bij verwijderen worden de volgende bestanden verwijderd:"
 ],
 "Pinned unit": [
  null,
  "Vastgezette eenheid"
 ],
 "Status": [
  null,
  "Toestand"
 ],
 "Path": [
  null,
  "Pad"
 ],
 "Listen": [
  null,
  "Luisteren"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Condition failed": [
  null,
  "Conditie mislukte"
 ],
 "Show more relationships": [
  null,
  "Toon meer relaties"
 ],
 "Show relationships": [
  null,
  "Toon relaties"
 ],
 "Confirm deletion of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Timer deletion failed": [
  null,
  "Het verwijderen de timer is mislukt"
 ],
 "Targets": [
  null,
  "Doelen"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Timers": [
  null,
  "Timers"
 ],
 "Paths": [
  null,
  "Paden"
 ],
 "Go to $0": [
  null,
  "Ga naar $0"
 ],
 "Journal entry not found": [
  null,
  "Logboekingang werd niet gevonden"
 ],
 "Journal entry": [
  null,
  "Logboekingang"
 ],
 "Entry at $0": [
  null,
  "Ingang op $0"
 ],
 "Logs": [
  null,
  "Logboeken"
 ],
 "Loading unit failed": [
  null,
  "Het laden van unit mislukte"
 ],
 "Service logs": [
  null,
  "Servicelogboeken"
 ],
 "No log entries": [
  null,
  "Geen logboekvermeldingen"
 ],
 "Systemd units": [
  null,
  "Systemd units"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Geen resultaten komen overeen met de filtercriteria. Wis alle filters om resultaten weer te geven."
 ],
 "Does not automatically start": [
  null,
  "Start niet automatisch op"
 ],
 "Cannot be enabled": [
  null,
  "Kan niet worden ingeschakeld"
 ],
 "Web console is running in limited access mode.": [
  null,
  "De webconsole wordt uitgevoerd in de beperkte toegang modus."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "van $0 op $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "van $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "op $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domein"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Word lid van een domein"
 ]
});
