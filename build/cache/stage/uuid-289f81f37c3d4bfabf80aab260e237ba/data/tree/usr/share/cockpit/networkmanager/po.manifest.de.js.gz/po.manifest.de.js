cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Dienste"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "Schnittstelle"
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "vlan": [
  null,
  "VLan"
 ],
 "bond": [
  null,
  "Bündel"
 ],
 "team": [
  null,
  "Team"
 ],
 "port": [
  null,
  "Port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "Firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "Zone"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Verwalten der Netzwerkverbindungen"
 ],
 "Managing networking teams": [
  null,
  "Verwalten der Netzwerkteams"
 ],
 "Managing networking bridges": [
  null,
  "Netzwerkbrücken verwalten"
 ],
 "Managing VLANs": [
  null,
  "VLANs verwalten"
 ],
 "Managing firewall": [
  null,
  "Firewall verwalten"
 ]
});
