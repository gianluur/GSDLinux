cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Accounts": [
  null,
  "Учётные записи"
 ],
 "user": [
  null,
  "пользователь"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "пароль"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "имя пользователя"
 ],
 "login": [
  null,
  "вход"
 ],
 "access": [
  null,
  "доступ"
 ],
 "roles": [
  null,
  "роли"
 ],
 "keys": [
  null,
  "ключи"
 ],
 "Managing user accounts": [
  null,
  "Управление учетными записями пользователей"
 ]
});
