cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 installatie"
 ],
 "$0 installer": [
  null,
  "$0 installatieprogramma"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 is een uitgebreide MBR-partitie die logische partities bevat. Het verwijderen van alle logische partities zal ook automatisch de uitgebreide partitie verwijderen."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  "$0 zal verwijderd worden"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' bestandssysteem kan niet op een versleuteld blokapparaat staan"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' moet zich bevinden op een apparaat geformatteerd naar '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "'$0' partitie op MDRAID-apparaat $1 gevonden. Bootloader-partities op MDRAID-apparaten worden niet ondersteund."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  "Over Fedora"
 ],
 "Account": [
  null,
  "Account"
 ],
 "Actions": [
  null,
  "Acties"
 ],
 "Add mount": [
  null,
  "Aankoppelingspunt toevoegen"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "Additional languages": [
  null,
  "Aanvullende talen"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Alle wijzigingen in de opslageditor worden onmiddellijk toegepast."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Alle apparaten die deze wachtwoordzin gebruiken, worden ontgrendeld"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda Web-UI"
 ],
 "Anaconda project page": [
  null,
  "Anaconda projectpagina"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aankoppelpunttoewijzing toepassen en installeren"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Partities toewijzen aan aankoppelpunten. Handig voor vooraf geconfigureerde, aangepaste indelingen."
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Beschikbare vrije ruimte: $0. Benodigd voor installatie: $1."
 ],
 "Back": [
  null,
  "Terug"
 ],
 "Base environment": [
  null,
  "Basisomgeving"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Door deze software te blijven gebruiken, begrijp en accepteert u de risico's die gepaard gaan met voorlopige versies van de software, dat u van plan bent deze alleen voor test- en ontwikkelingsdoeleinden te gebruiken en u bereid bent om eventuele bugs of problemen te melden om dit werk te verbeteren."
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Change": [
  null,
  "Veranderen"
 ],
 "Change destination": [
  null,
  "Bestemming veranderen"
 ],
 "Change hostname": [
  null,
  "Hostnaam veranderen"
 ],
 "Change system keyboard layout": [
  null,
  "Verander systeemtoetsenbordindeling"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Veranderingen die hier gemaakt worden, zullen direct toegepast worden op het systeem. Er is geen 'ongedaan maken'."
 ],
 "Checking storage configuration": [
  null,
  "Bezig met controleren van opslagconfiguratie"
 ],
 "Clear search": [
  null,
  "Zoekopdracht wissen"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit-opslag heeft geen wachtwoordzin verstrekt om het versleutelde apparaat te ontgrendelen."
 ],
 "Completed": [
  null,
  "Voltooid"
 ],
 "Configure NTP servers": [
  null,
  "Configureer NTP-servers"
 ],
 "Configure storage": [
  null,
  "Opslag configureren"
 ],
 "Configure storage again": [
  null,
  "Opslag opnieuw configureren"
 ],
 "Confirm passphrase": [
  null,
  "Bevestig wachtwoordzin"
 ],
 "Continue": [
  null,
  "Doorgaan"
 ],
 "Continue installation": [
  null,
  "Installatie vervolgen"
 ],
 "Continue with installation": [
  null,
  "Verdergaan met installatie"
 ],
 "Create Account": [
  null,
  "Account Aanmaken"
 ],
 "Create account": [
  null,
  "Account aanmaken"
 ],
 "Currently installed: $0": [
  null,
  "Momenteel geïnstalleerd: $0"
 ],
 "Custom": [
  null,
  "Aangepast"
 ],
 "Date": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Het verwijderen van bepaalde partities kan ervoor zorgen dat $0 niet opstart: $1"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Destination": [
  null,
  "Bestemming"
 ],
 "Destination is encrypted": [
  null,
  "Bestemming is versleuteld"
 ],
 "Detected valid storage layout:": [
  null,
  "Gedetecteerde geldige opslagindeling:"
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Duplicate device.": [
  null,
  "Dupliceer apparaat."
 ],
 "Duplicate mount point.": [
  null,
  "Dupliceer aankoppelpunt."
 ],
 "Enable root account": [
  null,
  "Rootaccount inschakelen"
 ],
 "Encrypt my data": [
  null,
  "Versleutel mijn data"
 ],
 "Encrypted": [
  null,
  "Versleuteld"
 ],
 "Encryption": [
  null,
  "Versleutelen"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Data wissen en installeren"
 ],
 "Error details": [
  null,
  "Foutdetails"
 ],
 "Exit to live desktop": [
  null,
  "Afsluiten naar live desktop"
 ],
 "Extended partition": [
  null,
  "Uitgebreide partitie"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux heeft minstens $0 schijfruimte nodig."
 ],
 "Finalization": [
  null,
  "Afronding"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Afronding: De systeemconfiguratie is voltooid. Het voltooien van de installatie kan even duren."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Volledige naam"
 ],
 "Full name cannot contain colon characters": [
  null,
  "De volledige naam mag geen dubbele punten bevatten"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Bevestigd wachtwoord verbergen"
 ],
 "Hide passphrase": [
  null,
  "Verberg wachtzin"
 ],
 "Hide password": [
  null,
  "Verberg wachtwoord"
 ],
 "Hostname": [
  null,
  "Hostnaam"
 ],
 "How would you like to install?": [
  null,
  "Hoe wilt u installeren?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Ik begrijp dat sommige bestaande data zal worden verwijderd"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Ik begrijp dat sommige partities worden gewijzigd"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Wanneer leeg, wordt de hostnaam tijdelijk en toegewezen op basis van de netwerkinformatie."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Wanneer u partities configureert, is het volgende vereist:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Als u de risico's niet begrijpt of accepteert, verlaat dan dit programma."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Bezig"
 ],
 "Initializing...": [
  null,
  "Initialiseren..."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Installation failed": [
  null,
  "Installatie mislukt"
 ],
 "Installation method": [
  null,
  "Installatiemethode"
 ],
 "Installation of the system failed: $0": [
  null,
  "Installatie van het systeem mislukt: $0"
 ],
 "Installation type": [
  null,
  "Installatietype"
 ],
 "Installing": [
  null,
  "Installeren"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Ongeldige RAID-configuratie gedetecteerd. Als de RAID-array direct op schijven aangemaakt is, dient er een partitietabel te worden aangemaakt op de array. Als de RAID-array aangemaakt is op de partities, dient deze één bestandssysteem of formaat te bevatten (bijv. LVM PV). Alle bestaande partities op dit array worden genegeerd."
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Behoud de huidige schijfindeling en installeer alleen in beschikbare ruimte, om te dual-booten met een ander OS."
 ],
 "Keyboard": [
  null,
  "Toetsenbord"
 ],
 "Keyboard layout during boot": [
  null,
  "Toetsenbordindeling tijdens het opstarten"
 ],
 "Language": [
  null,
  "Taal"
 ],
 "Launch storage editor": [
  null,
  "Start opslageditor"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "Locked devices": [
  null,
  "Vergrendelde apparaten"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "Handmatige schijfconfiguratie"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Handmatige schijfconfiguratie: aankoppelpunttoewijzing"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Kan letters, nummers en koppeltekens bevatten."
 ],
 "Medium": [
  null,
  "Medium"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Geen overeenkomst tussen selectie van herformattering van bovenliggend apparaat en onderliggend apparaat."
 ],
 "Mount point": [
  null,
  "Koppelpunt"
 ],
 "Mount point assignment": [
  null,
  "Aankoppelpunttoewijzing"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "Moet minimaal $0 tekens lang zijn"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Netwerk"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Netwerk niet beschikbaar. Configureer het netwerk in het bovenste balkmenu om het probleem te melden."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Netwerk niet beschikbaar. Configureer het netwerk om het probleem te melden."
 ],
 "Next": [
  null,
  "Volgende"
 ],
 "No devices": [
  null,
  "Geen apparaten"
 ],
 "No disks available": [
  null,
  "Geen schijven beschikbaar"
 ],
 "No disks selected": [
  null,
  "Geen schijven geselecteerd"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Onvoldoende vrije ruimte op de geselecteerde schijven."
 ],
 "Not enough space on selected disks.": [
  null,
  "Onvoldoende ruimte op de geselecteerde schijven."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Opmerking: dit is pre-released software die alleen bedoeld is voor ontwikkelings- en testdoeleinden. Gebruik deze software NIET voor belangrijk werk of voor productieomgevingen."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Besturingssysteem"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Other keyboards": [
  null,
  "Andere toetsenborden"
 ],
 "Partitions (advanced)": [
  null,
  "Partities (geavanceerd)"
 ],
 "Passphrase": [
  null,
  "Wachtzin"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Wachtzin komt met geen enkel vergrendeld apparaat overeen"
 ],
 "Passphrases must match": [
  null,
  "Wachtwoordzinnen moeten overeenkomen"
 ],
 "Pending": [
  null,
  "In afwachting"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Voeg het logbestand $0 toe aan het probleem."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Powered by Anaconda": [
  null,
  "Mogelijk gemaakt door Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-release"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Doorgaan met installatie"
 ],
 "Quit": [
  null,
  "Afsluiten"
 ],
 "Quit installer?": [
  null,
  "Installatieprogramma afsluiten?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Informatie over het besturingssysteem lezen is mislukt."
 ],
 "Reading information about the computer failed.": [
  null,
  "Informatie over de computer lezen mislukte."
 ],
 "Reading installer configuration failed.": [
  null,
  "De configuratie van het installatieprogramma lezen mislukte."
 ],
 "Reading installer version information failed.": [
  null,
  "Versie-informatie van het installatieprogramma lezen is mislukt."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Een echte hostnaam kan alleen letters, cijfers, koppeltekens (niet als startend of eindigend teken) en punten bevatten"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Een echte hostnaam moet 64 karakters of minder bevatten"
 ],
 "Reboot": [
  null,
  "Herstarten"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Start opnieuw op in Windows om de grootte van BitLocker-versleutelde partities te veranderen. Maak minstens $0 vrije ruimte beschikbaar voor de installatie."
 ],
 "Reboot system?": [
  null,
  "Systeem herstarten?"
 ],
 "Reclaim additional space": [
  null,
  "Aanvullende ruimte terugvorderen"
 ],
 "Reclaim space": [
  null,
  "Ruimte terugvorderen"
 ],
 "Reclaim space (required)": [
  null,
  "Ruimte terugvorderen (vereist)"
 ],
 "Recommended": [
  null,
  "Aanbevolen"
 ],
 "Recommended partitions:": [
  null,
  "Aanbevolen partities:"
 ],
 "Reformat": [
  null,
  "Opnieuw formatteren"
 ],
 "Reinstall Fedora": [
  null,
  "Fedora opnieuw installeren"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Verwijder alle partities op de geselecteerde apparaten, inclusief bestaande besturingssystemen."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Verwijder of verander de grootte van bestaande bestandssystemen om ruimte vrij te maken voor de installatie."
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Het verwijderen van een bestandssysteem zal alle bestaande data daarop permanent verwijderen. Een partitie aanpassen kan ongebruikte ruimte vrijmaken, maar is niet risicovrij. Maak backups van belangrijke bestanden alvorens de ruimte terug te vorderen."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Vervang huidige installatie, maar behoud bestanden in home-map."
 ],
 "Report Issue": [
  null,
  "Probleem melden"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Probleem melden"
 ],
 "Required": [
  null,
  "Vereist"
 ],
 "Requirements": [
  null,
  "Vereisten"
 ],
 "Rescan devices": [
  null,
  "Apparaten opnieuw scannen"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Het opnieuw scannen van de schijven mislukte."
 ],
 "Resize": [
  null,
  "Grootte veranderen"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Verander de grootte van de volgende partities van $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Terugkeren naar installatie"
 ],
 "Return to storage editor": [
  null,
  "Terug naar opslageditor"
 ],
 "Review and install": [
  null,
  "Bekijk en installeer"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  "Rootwachtwoord is ingesteld."
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scan de QR-code met de telefoon of bezoek:"
 ],
 "Search for a language": [
  null,
  "Taal zoeken"
 ],
 "Search keyboard layout": [
  null,
  "Zoek toetsenbordindeling"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Beveilig data met schijfgebaseerde versleuteling. Alleen van toepassing op nieuwe partities"
 ],
 "Select": [
  null,
  "Selecteren"
 ],
 "Select a device": [
  null,
  "Selecteer een apparaat"
 ],
 "Select destination": [
  null,
  "Bestemming selecteren"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Het geselecteerde apparaatformaat '$0' kan niet opnieuw worden geformatteerd."
 ],
 "Send us feedback on your installation": [
  null,
  "Geef ons feedback over de installatie"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "Aangepaste hostnaam instellen"
 ],
 "Show confirmed password": [
  null,
  "Toon bevestigd wachtwoord"
 ],
 "Show passphrase": [
  null,
  "Toon wachtzin"
 ],
 "Show password": [
  null,
  "Toon wachtwoord"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "Software installation": [
  null,
  "Software-installatie"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Software-installatie: Opslagconfiguratie voltooid. De software wordt nu op uw apparaat geïnstalleerd."
 ],
 "Software selection": [
  null,
  "Softwareselectie"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Een aantal vereiste partities zijn niet aanwezig: $0"
 ],
 "Space": [
  null,
  "Ruimte"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Storage configuration": [
  null,
  "Opslagconfiguratie"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Opslagconfiguratie: opslag wordt momenteel geconfigureerd."
 ],
 "Storage editor": [
  null,
  "Opslageditor"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Opslag is gebaseerd op de configuratie van 'Opslag bewerken'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Fout opgetreden in opslag-plugin"
 ],
 "Storage requirements not met": [
  null,
  "Opslag voldoet niet aan de eisen"
 ],
 "Strong": [
  null,
  "Sterk"
 ],
 "Successfully installed": [
  null,
  "Succesvol geïnstalleerd"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 met succes ontgrendeld."
 ],
 "Suggested keyboards": [
  null,
  "Voorgestelde toetsenborden"
 ],
 "Suggested languages": [
  null,
  "Voorgestelde talen"
 ],
 "System": [
  null,
  "Systeem"
 ],
 "System configuration": [
  null,
  "Systeemconfiguratie"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Systeemconfiguratie: software-installatie voltooid. Het systeem wordt nu geconfigureerd."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Het installatieprogramma kan niet doorgaan vanwege een kritieke fout."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Het installatieprogramma kan niet doorgaan vanwege een kritieke fout: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "De wachtzin die u heeft opgeven bevat niet-ASCII karakters. Het kan voorkomen dat u niet kunt omschakelen tussen toetsenbordindelingen tijdens het intypen ervan."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Met behulp van de opslageditor kunnen partities vergroot, verkleind, aangemaakt en verwijderd worden. Hiermee kan ook LVM en veel meer geconfigureerd worden. Dit is een geavanceerd hulpprogramma en niet bedoeld voor gebruik in een typische installatie."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "Deze hostnaam kan niet gebruikt worden"
 ],
 "This is unstable, pre-release software": [
  null,
  "Dit is onstabiele, pre-release software"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Deze indeling wordt gebruikt voor ontsleuteling van het systeem tijdens het opstarten"
 ],
 "This may take a moment": [
  null,
  "Dit kan heel even duren"
 ],
 "This will take a few moments": [
  null,
  "Dit kan even duren"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Herstart uw systeem om $0 te gaan gebruiken."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Selecteer de apparaten waarop u wilt installeren om door te kunnen gaan."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Om deze optie te gebruiken, verandert u de grootte van bestaande partities of u verwijdert deze om minimaal $0 vrij te maken."
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Verwijdering van $0 inplannen mislukt"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Grootte veranderen van $0 inplannen mislukt"
 ],
 "Unlock": [
  null,
  "Ontgrendelen"
 ],
 "Unlock encrypted devices": [
  null,
  "Ontgrendel versleutelde apparaten"
 ],
 "Use configured storage": [
  null,
  "Gebruik geconfigureerde opslag"
 ],
 "Use entire disk": [
  null,
  "Gebruik gehele schijf"
 ],
 "Use free space": [
  null,
  "Gebruik vrije ruimte"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Gebruik het RAID-apparaat voor automatisch partitioneren"
 ],
 "User creation": [
  null,
  "Gebruiker aanmaken"
 ],
 "User name": [
  null,
  "Gebruikersnaam"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Gebruikersnaam kan alleen het volgende bevatten: letters van a-z, cijfers 0-9, koppelteken $0, punt $1, laag streepje $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Gebruikersnaam mag geen gereserveerd woord zijn"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Gebruikersnamen moeten korter zijn dan 33 karakters"
 ],
 "Weak": [
  null,
  "Zwak"
 ],
 "Welcome": [
  null,
  "Welkom"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Welkom. Laten we nu $0 installeren."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Windows-partities met BitLocker-versleuteling kunnen niet van grootte aangepast worden"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "U kunt kiezen om genoeg vrije ruimte te maken en het installatieprogramma de rest te laten regelen, of handmatig partities te configureren."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "Je voortgang wordt niet opgeslagen."
 ],
 "completed step": [
  null,
  "voltooide stap"
 ],
 "current step": [
  null,
  "huidige stap"
 ],
 "delete": [
  null,
  "verwijderen"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "encrypt": [
  null,
  "versleutelen"
 ],
 "encrypted": [
  null,
  "versleuteld"
 ],
 "extended partition": [
  null,
  "uitgebreide partitie"
 ],
 "format as $0": [
  null,
  "formatteren als $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "pending step": [
  null,
  "stap in afwachting"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "Grootte aangepast van $0"
 ],
 "shrink": [
  null,
  "verkleinen"
 ],
 "shrink to $0": [
  null,
  "verkleinen naar $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "ongedaan maken"
 ]
});
