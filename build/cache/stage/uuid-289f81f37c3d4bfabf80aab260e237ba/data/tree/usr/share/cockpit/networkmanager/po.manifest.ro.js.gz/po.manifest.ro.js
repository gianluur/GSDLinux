cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Servicii"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "network": [
  null,
  "rețea"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interfață"
 ],
 "bridge": [
  null,
  "punte"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "legătură"
 ],
 "team": [
  null,
  "echipă"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "paravan de protecție"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zona"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Gestionarea legăturilor de rețea"
 ],
 "Managing networking teams": [
  null,
  "Gestionarea echipelor de rețea"
 ],
 "Managing networking bridges": [
  null,
  "Gestionarea punților de rețea"
 ],
 "Managing VLANs": [
  null,
  "Gestionarea VLAN-urilor"
 ],
 "Managing firewall": [
  null,
  "Gestionarea paravanului de protecție"
 ]
});
