cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Local accounts": [
  null,
  "חשבונות מקומיים"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Fingerprint": [
  null,
  "טביעת אצבע"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "Confirm password": [
  null,
  "אישור סיסמה"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "Permission denied": [
  null,
  "ההרשאה נדחתה"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit דיווח את קוד השגיאה $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete files": [
  null,
  "מחיקת קבצים"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Edit user": [
  null,
  "עריכת משתמש"
 ],
 "Log user out": [
  null,
  "הוצאת משתמש"
 ],
 "Lock account": [
  null,
  "נעילת חשבון"
 ],
 "Delete account": [
  null,
  "מחיקת חשבון"
 ],
 "Logged in": [
  null,
  "נכנסת"
 ],
 "Never logged in": [
  null,
  "מעולם לא נכנס"
 ],
 "Your account": [
  null,
  "החשבון שלך"
 ],
 "Group name": [
  null,
  "שם הקבוצה"
 ],
 "# of users": [
  null,
  "מס׳ משתמשים"
 ],
 "Accounts": [
  null,
  "חשבונות"
 ],
 "Search for name or ID": [
  null,
  "חיפוש אחר שם או מזהה"
 ],
 "Create new group": [
  null,
  "יצירת קבוצה חדשה"
 ],
 "Groups": [
  null,
  "קבוצות"
 ],
 "$0 more...": [
  null,
  "$0 נוספים…"
 ],
 "Clear filter": [
  null,
  "הסרת מסנן"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "Full name": [
  null,
  "שם מלא"
 ],
 "Last active": [
  null,
  "פעילות אחרונה"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Search for name, group or ID": [
  null,
  "חיפוש אחר שם, קבוצה או מזהה"
 ],
 "Create new account": [
  null,
  "יצירת חשבון חדש"
 ],
 "No group name specified": [
  null,
  "לא צוין שם לקבוצה"
 ],
 "A group with this name already exists": [
  null,
  "כבר קיימת קבוצה בשם הזה"
 ],
 "No ID specified": [
  null,
  "לא מוגדר מזהה"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "New name": [
  null,
  "שם חדש"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "שינוי שם של קבוצה יכולה להשפיע על sudo ועל כללים דומים"
 ],
 "Rename group $0": [
  null,
  "שינוי שם הקבוצה $0"
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Login history": [
  null,
  "היסטוריית כניסות"
 ],
 "Login history list": [
  null,
  "רשימת היסטוריית כניסות"
 ],
 "Started": [
  null,
  "הופעל"
 ],
 "Ended": [
  null,
  "הסתיים"
 ],
 "From": [
  null,
  "התחלה"
 ],
 "Prompting via passwd timed out": [
  null,
  "משך הצגת הבקשה דרך passwd תם"
 ],
 "You must wait longer to change your password": [
  null,
  "עליך להמתין זמן רב יותר כדי להחליף את הסיסמה שלך"
 ],
 "Old password": [
  null,
  "סיסמה ישנה"
 ],
 "Confirm new password": [
  null,
  "אישור סיסמה חדשה"
 ],
 "The passwords do not match": [
  null,
  "הסיסמאות אינן תואמות"
 ],
 "Password is longer than 256 characters": [
  null,
  "הסיסמה ארוכה מ־256 תווים"
 ],
 "Set password": [
  null,
  "הגדרת סיסמה"
 ],
 "Set weak password": [
  null,
  "הגדרת סיסמה חלשה"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "החשבון ‚$0’ יאולץ להחליף את הסיסמה שלו עם כניסתו הבאה למערכת"
 ],
 "Force password change": [
  null,
  "לאלץ החלפת סיסמה"
 ],
 "Reset password": [
  null,
  "איפוס סיסמה"
 ],
 "Logout $0": [
  null,
  "הוצאת $0 מהמערכת"
 ],
 "Rename group": [
  null,
  "שינוי שם של קבוצה"
 ],
 "Delete group": [
  null,
  "מחיקת קבוצה"
 ],
 "Home directory": [
  null,
  "תיקיית בית"
 ],
 "Path to directory": [
  null,
  "נתיב לתיקייה"
 ],
 "Shell": [
  null,
  "מעטפת"
 ],
 "User ID": [
  null,
  "מזהה משתמש"
 ],
 "Use password": [
  null,
  "להשתמש בסיסמה"
 ],
 "Require password change on first login": [
  null,
  "לדרוש החלפת סיסמה בכניסה הראשונה"
 ],
 "Disallow password authentication": [
  null,
  "לא לאפשר אימות בסיסמה"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "שיטות אימות אחרות עדיין זמינות אפילו כאשר אימות סיסמאות אינטראקטיבי אסור לשימוש."
 ],
 "No user name specified": [
  null,
  "לא צוין שם משתמש"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "שם המשתמש יכול להיות מורכב מהתווים a-z, ספרות, נקודות, מינוסים וקווים תחתונים."
 ],
 "This user name already exists": [
  null,
  "שם משתמש זה כבר קיים"
 ],
 "No real name specified": [
  null,
  "לא צוין שם אמתי"
 ],
 "The full name must not contain colons.": [
  null,
  "השם המלא לא יכול להכיל נקודתיים."
 ],
 "User ID must be a positive integer": [
  null,
  "מזהה המשתמש חייב להיות מספר שלם וחיובי"
 ],
 "User ID must not be lower than $0": [
  null,
  "מזהה המשתמש לא יכול להיות קטן מ־$0"
 ],
 "User ID must not be higher than $0": [
  null,
  "מזהה המשתמש לא יכול להיות גדול מ־$0"
 ],
 "User ID is already used by another user": [
  null,
  "מזהה משתמש זה כבר בשימוש על ידי משתמש אחר"
 ],
 "Empty password": [
  null,
  "סיסמה ריקה"
 ],
 "$0 is an existing file": [
  null,
  "$0 הוא קובץ קיים"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "תיקיית הבית $0 כבר קיימת. הבעלות עליה תועבר לידי המשתמש החדש."
 ],
 "Create and change ownership of home directory": [
  null,
  "יצירה ושינוי בעלות על תיקיית הבית"
 ],
 "Create account with weak password": [
  null,
  "יצירת חשבון עם סיסמה חלשה"
 ],
 "Create account with non-unique UID": [
  null,
  "יצירת חשבון עם מזהה משתמש לא ייחודי"
 ],
 "Never expire password": [
  null,
  "הסיסמה לא תפוג לעולם"
 ],
 "Password must be changed": [
  null,
  "חובה לשנות את הסיסמה"
 ],
 "Require password change on $0": [
  null,
  "לדרוש החלפת סיסמה ב־$0"
 ],
 "Never expire account": [
  null,
  "חשבון שתוקפו לא פג"
 ],
 "Expire account on $0": [
  null,
  "החשבון יפוג ב־$0"
 ],
 "Account not available or cannot be edited.": [
  null,
  "החשבון לא זמין או שאין אפשרות לערוך אותו."
 ],
 "Back to accounts": [
  null,
  "חזרה לחשבונות"
 ],
 "Never": [
  null,
  "אף פעם"
 ],
 "Terminate session": [
  null,
  "חיסול הפעלה"
 ],
 "Last login": [
  null,
  "כניסה אחרונה"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Disallow interactive password": [
  null,
  "איסור סיסמה אינטראקטיבית"
 ],
 "Force change": [
  null,
  "לאלץ החלפה"
 ],
 "change": [
  null,
  "החלפה"
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "על המשתמש לצאת ולהיכנס בחזרה למערכת כדי שההגדרות החדשות תיכנסנה לתוקף."
 ],
 "Undo": [
  null,
  "ביטול שינוי"
 ],
 "Permanently delete $0 group?": [
  null,
  "למחוק את הקבוצה $0 לצמיתות?"
 ],
 "This group is the primary group for the following users:": [
  null,
  "הקבוצה הזאת היא הקבוצה העיקרית של המשתמשים הבאים:"
 ],
 "Force delete": [
  null,
  "לאלץ מחיקה"
 ],
 "Change shell": [
  null,
  "החלפת מעטפת"
 ],
 "Expire account on": [
  null,
  "החשבון יפוג ב־"
 ],
 "Please specify an expiration date": [
  null,
  "נא לציין מועד תפוגת תוקף"
 ],
 "Invalid expiration date": [
  null,
  "מועד התפוגה שגוי"
 ],
 "Account expiration": [
  null,
  "תפוגת תוקף חשבון"
 ],
 "Require password change every $0 days": [
  null,
  "לדרוש החלפת סיסמה כל $0 ימים"
 ],
 "Invalid number of days": [
  null,
  "מספר הימים שגוי"
 ],
 "Password expiration": [
  null,
  "תפוגת סיסמה"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "עליך להדביק את תוכן קובץ מפתח ה־SSH הציבורי שלך כאן"
 ],
 "Add public key": [
  null,
  "הוספת מפתח ציבורי"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "אין לך הרשאה לצפות במפתחות ציבוריים מורשים לחשבון זה."
 ],
 "Failed to load authorized keys.": [
  null,
  "טעינת המפתחות המורשים נכשלה."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "אין מפתחות ציבוריים מורשים לחשבון זה."
 ],
 "Authorized public SSH keys": [
  null,
  "מפתחות SSH ציבוריים מורשים"
 ],
 "Unnamed": [
  null,
  "ללא שם"
 ],
 "Invalid key": [
  null,
  "מפתח שגוי"
 ],
 "Error saving authorized keys: ": [
  null,
  "שגיאה בשמירת המפתחות המורשים: "
 ],
 "The key you provided was not valid.": [
  null,
  "המפתח שסיפקת אינו תקף."
 ],
 "Lock $0": [
  null,
  "נעילת $0"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ]
});
