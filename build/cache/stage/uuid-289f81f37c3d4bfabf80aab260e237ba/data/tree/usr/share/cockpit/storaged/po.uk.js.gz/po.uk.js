cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Unlock": [
  null,
  "Розблокувати"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Select": [
  null,
  "Вибрати"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "Set": [
  null,
  "Встановити"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "Permission denied": [
  null,
  "Відмовлено у доступі"
 ],
 "Clear input value": [
  null,
  "Вилучити вхідне значення"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "You now have administrative access.": [
  null,
  "Тепер ви маєте адміністративний доступ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Немає доступних методів отримання адміністративного доступу (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Будь ласка, пройдіть розпізнавання, щоб отримати адміністративний доступ"
 ],
 "Switch to administrative access": [
  null,
  "Перемкнутися на адміністративний доступ"
 ],
 "Authenticate": [
  null,
  "Розпізнавання"
 ],
 "Administrative access": [
  null,
  "Адміністративний доступ"
 ],
 "Problem becoming administrator": [
  null,
  "Проблеми із набуттям прав адміністратора"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Обмежити доступ"
 ],
 "Switch to limited access": [
  null,
  "Перемкнутися на обмежений доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Модель із обмеженим доступом обмежує адміністративні привілеї. Функціональні можливості деяких частин вебконсолі буде суттєво зменшено."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ваш браузер запам'ятовуватиме ваш рівень доступу між сеансами."
 ],
 "Limited access": [
  null,
  "Обмежений доступ"
 ],
 "Turn on administrative access": [
  null,
  "Увімкнути адміністративний доступ"
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "Downloading $0": [
  null,
  "Отримання $0"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit повідомлено про помилку із кодом $0"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Помилка під час ініціалізації"
 ],
 "Failed": [
  null,
  "Не вдалося"
 ],
 "Home": [
  null,
  "Домівка"
 ],
 "Downloads": [
  null,
  "Отримання"
 ],
 "Not a directory": [
  null,
  "Не є каталогом"
 ],
 "All files": [
  null,
  "Усі файли"
 ],
 "Recent": [
  null,
  "Нещодавні"
 ],
 "No recent directories": [
  null,
  "Немає нещодавніх каталогів"
 ],
 "No recent files": [
  null,
  "Немає нещодавніх файлів"
 ],
 "Type to filter": [
  null,
  "Введіть щось для фільтрування"
 ],
 "File chooser actions": [
  null,
  "Дії з вибору файлів"
 ],
 "Open in file browser": [
  null,
  "Відкрити у навігаторі файловою системою"
 ],
 "Hide hidden files": [
  null,
  "Не показувати приховані файли"
 ],
 "Show hidden files": [
  null,
  "Показувати приховані файли"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Clear filters": [
  null,
  "Зняти фільтрування"
 ],
 "Directory is empty": [
  null,
  "Каталог є порожнім"
 ],
 "Directory has no sub-directories": [
  null,
  "У каталозі немає підкаталогів"
 ],
 "This directory contains only hidden files": [
  null,
  "У цьому каталозі зберігаються лише приховані файли"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "Folder": [
  null,
  "Тека"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Unknown": [
  null,
  "Невідомо"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Select an option": [
  null,
  "Виберіть варіант"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "View logs": [
  null,
  "Переглянути журнали"
 ],
 "Dismiss": [
  null,
  "Відкинути"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "none": [
  null,
  "немає"
 ],
 "Not found": [
  null,
  "Не знайдено"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "Not running": [
  null,
  "Зупинено"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Confirm deletion of $0": [
  null,
  "Підтвердьте вилучення $0"
 ],
 "Username": [
  null,
  "Користувач"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Started": [
  null,
  "Почато"
 ],
 "Delete group": [
  null,
  "Вилучити групу"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Lock": [
  null,
  "Заблокувати"
 ],
 "Use $0": [
  null,
  "Використати $0"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Disconnect": [
  null,
  "Від’єднатися"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "$0 disk is missing": [
  null,
  "Не вистачає $0 диска",
  "Не вистачає $0 дисків",
  "Не вистачає $0 дисків"
 ],
 "Location": [
  null,
  "Адреса"
 ],
 "Compression": [
  null,
  "Стискання"
 ],
 "Storage logs": [
  null,
  "Журнали зберігання"
 ],
 "Name cannot be empty.": [
  null,
  "Назва не може бути порожньою."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Назва не повинна бути довшою за 127 символів."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Назва не повинна містити символу «$0»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "У назві не повинно бути пробілів."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Назва не повинна бути довшою за $0 символів"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Назва не повинна бути довшою за $0 байтів"
 ],
 "$name (from $host)": [
  null,
  "$name (з $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Буфер для тонких логічних томів"
 ],
 "Thin logical volume": [
  null,
  "Тонкий логічний том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логічний том (знімок)"
 ],
 "Logical volume": [
  null,
  "Логічний том"
 ],
 "MDRAID device $0": [
  null,
  "Пристій MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Група томів LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Пристрій VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрований логічний том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Шифрований розділ $0"
 ],
 "Logical volume of $0": [
  null,
  "Логічний том $0"
 ],
 "Partition of $0": [
  null,
  "Розділ $0"
 ],
 "Encrypted $0": [
  null,
  "Зашифрований $0"
 ],
 "unpartitioned space on $0": [
  null,
  "нерозподілене місце на $0"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "remove from btrfs volume": [
  null,
  "вилучити з тому BTRFS"
 ],
 "stop": [
  null,
  "зупинити"
 ],
 "remove from MDRAID": [
  null,
  "вилучити з MDRAID"
 ],
 "remove from LVM2": [
  null,
  "вилучити з LVM2"
 ],
 "btrfs device": [
  null,
  "Пристрій BTRFS"
 ],
 "btrfs volume": [
  null,
  "Том BTRFS"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Назва не повинна бути довшою за 255 символів."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Назва не повинна містити символу «/»."
 ],
 "Create and mount": [
  null,
  "Створити і змонтувати"
 ],
 "Create only": [
  null,
  "Лише створити"
 ],
 "Create subvolume": [
  null,
  "Створити підтом"
 ],
 "Mount Point": [
  null,
  "Точка монтування"
 ],
 "delete": [
  null,
  "вилучити"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Остаточно вилучити підтом $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Вилучення призведе до витирання усіх даних на підтомі та його дочірніх об'єктах."
 ],
 "Edit mount point": [
  null,
  "Редагувати точку монтування"
 ],
 "Unmount": [
  null,
  "Демонтувати"
 ],
 "Mount": [
  null,
  "Змонтувати"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Має бути змонтовано принаймні один підтом"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Не можна вилучати останній змонтований підтом"
 ],
 "btrfs subvolume": [
  null,
  "Підтом btrfs"
 ],
 "Snapshot origin": [
  null,
  "Походження знімка"
 ],
 "Mount point": [
  null,
  "Точка монтування"
 ],
 "No subvolumes": [
  null,
  "Немає підтомів"
 ],
 "btrfs subvolumes": [
  null,
  "Підтоми BTRFS"
 ],
 "Snapshots": [
  null,
  "Знімки"
 ],
 "No snapshots found": [
  null,
  "Знімків не знайдено"
 ],
 "snapshot": [
  null,
  "знімок"
 ],
 "$0 is in use": [
  null,
  "$0 використовується"
 ],
 "Permanently delete $0?": [
  null,
  "Остаточно вилучити $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Вилучення призведе до витирання усіх даних на томі BTRFS."
 ],
 "Delete filesystem": [
  null,
  "Вилучити файлову систему"
 ],
 "Change label": [
  null,
  "Змінити мітку"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Файлову систему змонтовано лише для читання"
 ],
 "Label": [
  null,
  "Мітка"
 ],
 "Capacity": [
  null,
  "Місткість"
 ],
 "btrfs devices": [
  null,
  "Пристрої BTRFS"
 ],
 "No devices found": [
  null,
  "Не знайдено пристроїв"
 ],
 "btrfs filesystem": [
  null,
  "Файлова система BTRFS"
 ],
 "Successful": [
  null,
  "Успішно"
 ],
 "Aborted": [
  null,
  "Перервано"
 ],
 "In progress": [
  null,
  "Не завершено"
 ],
 "Interrupted": [
  null,
  "Перервано"
 ],
 "Did not complete": [
  null,
  "Не завершено"
 ],
 "Failed (Unknown)": [
  null,
  "Помилка (невідома)"
 ],
 "Failed (Electrical)": [
  null,
  "Помилка (електрична)"
 ],
 "Failed (Servo)": [
  null,
  "Помилка (серво)"
 ],
 "Failed (Read)": [
  null,
  "Помилка (читання)"
 ],
 "Failed (Damaged)": [
  null,
  "Помилка (пошкоджено)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Перервано скиданням на рівні контролера"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Перервано через вилучення простору назв з набору просторів назв"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Перервано через обробку команди форматування NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Під час самоперевірки сталася критична помилка"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Завершено із помилковим сегментом і помилковий сегмент є невідомим"
 ],
 "Completed with one or more failed segments": [
  null,
  "Завершено із одним або декількома помилковими сегментами"
 ],
 "Aborted for unknown reason": [
  null,
  "Перервано з невідомої причини"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Перервано через дію з супроводу"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Залишкова місткість менша порогової"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Температура поза рекомендованими пороговими значеннями"
 ],
 "Degraded": [
  null,
  "Зношено"
 ],
 "All media is in read-only mode": [
  null,
  "Усі носії даних перебувають у режимі лише читання"
 ],
 "Volatile memory backup failed": [
  null,
  "Не вдалося створити резервну копію тимчасової пам'яті"
 ],
 "Persistent memory has become read-only": [
  null,
  "Сталу пам'ять переведено у режим лише читання"
 ],
 "Run short test": [
  null,
  "Запустити скорочений тест"
 ],
 "Run extended test": [
  null,
  "Запустити розширений тест"
 ],
 "Abort test": [
  null,
  "Перервати тестування"
 ],
 "Disk is failing": [
  null,
  "Диск виходить з ладу"
 ],
 "Disk is OK": [
  null,
  "З диском усе гаразд"
 ],
 "Assessment": [
  null,
  "Оцінювання"
 ],
 "Power on hours": [
  null,
  "Години живлення"
 ],
 "$0 hours": [
  null,
  "$0 годин"
 ],
 "Self-test status": [
  null,
  "Стан самоперевірки"
 ],
 "Number of bad sectors": [
  null,
  "Кількість секторів із помилками"
 ],
 "Attributes failing": [
  null,
  "Помилка атрибутів"
 ],
 "Media drive": [
  null,
  "Мультимедійний носій"
 ],
 "Solid State Drive": [
  null,
  "Твердотільний диск"
 ],
 "Hard Disk Drive": [
  null,
  "Жорсткий диск"
 ],
 "iSCSI Drive": [
  null,
  "Диск iSCSI"
 ],
 "Drive": [
  null,
  "Диск"
 ],
 "Device health (SMART)": [
  null,
  "Працездатність пристрою (SMART)"
 ],
 "Firmware version": [
  null,
  "Версія мікропрограми"
 ],
 "Serial number": [
  null,
  "Серійний номер"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "Не виявлено носія даних"
 ],
 "Device file": [
  null,
  "Файл пристрою"
 ],
 "Multipathed devices": [
  null,
  "Пристрої із багатьма шляхами"
 ],
 "Free space": [
  null,
  "Вільне місце"
 ],
 "Create partition": [
  null,
  "Створити розділ"
 ],
 "Extended partition": [
  null,
  "Розширений розділ"
 ],
 "$0 partitions": [
  null,
  "$0 розділів"
 ],
 "Partitions": [
  null,
  "Розділи"
 ],
 "No partitions found": [
  null,
  "Розділів не знайдено"
 ],
 "Unexpected partitions": [
  null,
  "Неочікувані розділи"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Для цього блокового пристрою не передбачено розділів. Його використовують як диск для віртуальної машини — розділами має керувати операційна система усередині віртуальної машини."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Вилучення розділу призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "No free space after this partition": [
  null,
  "Після цього розділу є вільне місце"
 ],
 "EFI system partition": [
  null,
  "Системний розділ EFI"
 ],
 "BIOS boot partition": [
  null,
  "Розділ завантаження BIOS"
 ],
 "Partition": [
  null,
  "Розділ"
 ],
 "Shrink": [
  null,
  "Стиснути"
 ],
 "Grow": [
  null,
  "Збільшити"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Розділ завантаження PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "Резервна пам’ять Linux"
 ],
 "Linux filesystem data": [
  null,
  "Дані файлової системи Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Розділ засобу керування логічними томами (LVM)"
 ],
 "Custom": [
  null,
  "Нетиповий"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Тип має містити точно дві шістнадцяткові цифри (від 0 до 9 або від A до F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Назва типу може містити лише символи від 0 до 9, від A до F і «-»."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Тип слід вказувати у формі NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Встановити тип розділу $0"
 ],
 "Custom type": [
  null,
  "Нестандартний тип"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Зміна типів розділів може завадити нормальному завантаженню системи."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Місце на цьому розділі не повністю використано даними, які на ньому зберігаються."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Розмір розділу — $0. Розмір даних — $1."
 ],
 "Shrink partition": [
  null,
  "Стиснути розділ"
 ],
 "Grow content": [
  null,
  "Збільшити вміст"
 ],
 "initialize": [
  null,
  "ініціалізувати"
 ],
 "Initialize disk $0": [
  null,
  "Ініціалізувати диск $0"
 ],
 "Partitioning": [
  null,
  "Розподіл"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Сумісний із усіма системами та пристроями (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Сумісний зі сучасними системами та жорсткими дисками > 2 ТБ (GPT)"
 ],
 "No partitioning": [
  null,
  "Немає розподілу на розділи"
 ],
 "Overwrite": [
  null,
  "Перезаписати"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Перезаписати наявні дані нулями (повільно)"
 ],
 "Initialize": [
  null,
  "Ініціалізувати"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Ініціалізація призведе до знищення усіх даних, які зберігаються на диску."
 ],
 "Device is read-only": [
  null,
  "Пристрій придатний лише для читання"
 ],
 "Create partition table": [
  null,
  "Створити таблицю розділів"
 ],
 "Size must be a number": [
  null,
  "Розмір має бути вказано числом"
 ],
 "Size cannot be zero": [
  null,
  "Розмір не може бути нульовим"
 ],
 "Size cannot be negative": [
  null,
  "Розмір не може бути від’ємним"
 ],
 "Size is too large": [
  null,
  "Розмір є надто великим"
 ],
 "Size must be at least $0": [
  null,
  "Розмір має бути не меншим за $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "фізичний том групи томів LVM2"
 ],
 "member of MDRAID device": [
  null,
  "елемент пристрою MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "резервний пристрій для пристрою VDO"
 ],
 "member of Stratis pool": [
  null,
  "частина буфера Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Файлова система поза ціллю"
 ],
 "device of btrfs volume": [
  null,
  "пристрій тому BTRFS"
 ],
 "This device is currently in use.": [
  null,
  "Цей пристрій зараз перебуває у користуванні."
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Use": [
  null,
  "Використати"
 ],
 "Services using the location": [
  null,
  "Служби, що використовують це місце"
 ],
 "Processes using the location": [
  null,
  "Процеси, що використовують це місце"
 ],
 "Currently in use": [
  null,
  "Зараз використовується"
 ],
 "(Not part of target)": [
  null,
  "(Не є частиною цілі)"
 ],
 "These changes will be made:": [
  null,
  "Буде внесено такі зміни:"
 ],
 "Action": [
  null,
  "Дія"
 ],
 "Important data might be deleted:": [
  null,
  "Може бути вилучено важливі дані:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Пов'язані процеси і служби буде примусово зупинено."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Пов'язані процеси буде примусово зупинено."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Пов'язані служби буде примусово зупинено."
 ],
 "Checking filesystem usage": [
  null,
  "Перевіряємо використання файлової системи"
 ],
 "$0 used, $1 total": [
  null,
  "використано $0, загалом $1"
 ],
 "Device contains unrecognized data": [
  null,
  "На пристрої містяться нерозпізнані дані"
 ],
 "Locked encrypted device might contain data": [
  null,
  "На заблокованому зашифрованому пристрої можуть міститися дані"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Підтверджую остаточну втрату цих даних"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими процесами:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими службами:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Процеси і служби зі списку буде примусово зупинено."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Процеси зі списку буде примусово зупинено."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Служби зі списку буде примусово зупинено."
 ],
 "Sorry": [
  null,
  "Вибачте"
 ],
 "Usage of $0": [
  null,
  "Вживання $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Буфер VDO LVM2"
 ],
 "Data used": [
  null,
  "Використано даних"
 ],
 "Metadata used": [
  null,
  "Використано метаданих"
 ],
 "Use compression": [
  null,
  "Скористатися стисканням"
 ],
 "Deduplication": [
  null,
  "Скасування дублювання"
 ],
 "Use deduplication": [
  null,
  "Скористатися скасуванням дублювання"
 ],
 "Rename volume group": [
  null,
  "Перейменувати групу томів"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "У цій групі томів міститься коренева файлова система. Її перейменування може потребувати подальших змін у налаштуваннях засобу завантаження або командному рядку ядра."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Вилучення призведе до витирання усіх даних на групі томів."
 ],
 "Create snapshot": [
  null,
  "Створення знімка"
 ],
 "Add disks": [
  null,
  "Додати диски"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "No disks are available.": [
  null,
  "Немає доступних дисків."
 ],
 "At least one disk is needed.": [
  null,
  "Потрібен принаймні один диск."
 ],
 "Volume group is missing physical volumes": [
  null,
  "У групі томів пропущено фізичні томи"
 ],
 "No free space": [
  null,
  "Недостатньо вільного простору"
 ],
 "LVM2 volume group": [
  null,
  "Група томів LVM2"
 ],
 "Add physical volume": [
  null,
  "Додати фізичний том"
 ],
 "LVM2 logical volumes": [
  null,
  "Логічні томи LVM2"
 ],
 "Create new logical volume": [
  null,
  "Створити логічний том"
 ],
 "No logical volumes": [
  null,
  "Немає логічних томів"
 ],
 "Remove missing physical volumes?": [
  null,
  "Вилучити пропущені фізичні томи?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "У цій групі томів не вистачає деяких фізичних томів."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Групу томів із пропущеними фізичними томами не можна перейменовувати."
 ],
 "Physical volumes": [
  null,
  "Фізичні томи"
 ],
 "No physical volumes found": [
  null,
  "Не знайдено фізичних томів"
 ],
 "LVM2 physical volumes": [
  null,
  "Фізичні томи LVM2"
 ],
 "Rename logical volume": [
  null,
  "Перейменувати логічний том"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Остаточно вилучити логічний том $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Вилучення логічного тому призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Не вдалося полагодити логічний том $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Недостатньо місця, яким можна скористатися для того, щоб полагодити систему. Потрібно принаймні $0 на фізичний томах, які ще не використано для цього логічного тому."
 ],
 "An additional $0 must be selected": [
  null,
  "пройдіть процес відвідування синагоги $0"
 ],
 "Repair logical volume $0": [
  null,
  "Полагодити логічний том $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Виберіть фізичні томи, якими слід скористатися для того, щоб полагодити логічний том. Потрібно принаймні $0."
 ],
 "Physical Volumes": [
  null,
  "Фізичні томи"
 ],
 "Repair": [
  null,
  "Полагодити"
 ],
 "deactivate": [
  null,
  "вимкнути"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Деактивувати логічний том $0/$1?"
 ],
 "Deactivate": [
  null,
  "Вимкнути"
 ],
 "Not enough space to grow": [
  null,
  "Недостатньо місця для збільшення"
 ],
 "LVM2 logical volume": [
  null,
  "Логічний том LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Смуговий (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Віддзеркалений (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Смуговий і віддзеркалений (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Спеціальна парність (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Розподілена парність (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Подвійна розподілена парність (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Місце на цьому логічному томі не повністю використано даними, які на ньому зберігаються."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Розмір тому — $0. Розмір даних — $1."
 ],
 "Shrink volume": [
  null,
  "Стиснути том"
 ],
 "Layout": [
  null,
  "Розкладка"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Цей логічний том втратив частину його фізичних томів, ним не можна надалі користуватися. Вам слід вилучити його і створити новий, який займе його місце."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Цей логічний том втратив частину фізичних томів, але не втратив жодних даних. Вам слід полагодити його для відновлення початкової надлишковості."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Цей логічний том втратив частину своїх фізичних томів, але, ймовірно, жодних даних на ньому не втрачено. Ви, можливо, зможете його полагодити."
 ],
 "Stripes": [
  null,
  "Смуги"
 ],
 "$0 synchronized": [
  null,
  "$0 синхронізовано"
 ],
 "Create volume group": [
  null,
  "Створити групу томів"
 ],
 "LVM2 physical volume": [
  null,
  "Фізичний том LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Останній не можна вилучати"
 ],
 "Not enough free space": [
  null,
  "Недостатньо вільного місця"
 ],
 "Volume group": [
  null,
  "Група томів"
 ],
 "Create thin volume": [
  null,
  "Створити тонкий том"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Тонкі резервовані логічні томи LVM2"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Створити логічний том з тонким прогнозуванням"
 ],
 "Not enough space": [
  null,
  "Недостатньо місця"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Буфер для тонких резервованих логічних томів LVM2"
 ],
 "Inactive logical volume": [
  null,
  "Неактивний логічний том"
 ],
 "Activate": [
  null,
  "Задіяти"
 ],
 "Unsupported logical volume": [
  null,
  "Непідтримуваний логічний том"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ВНУТРІШНЯ ПОМИЛКА — цей логічний том позначено як активний, він повинен мати пов'язаний блоковий пристрій. Втім, знайти такий блоковий пристрій не вдалося."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Встановлення $0 призведе до вилучення $1."
 ],
 "Installing packages": [
  null,
  "Встановлення пакунків"
 ],
 "Block device for filesystems": [
  null,
  "Блоковий пристрій для файлових систем"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Буфер для тонких резервованих томів"
 ],
 "Linear": [
  null,
  "Лінійний"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Том файлової системи VDO (стискання/дедублікація)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Дані буде збережено на вибраних фізичних томах без будь-якої надлишковості або підвищення швидкодії."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Дані будуть зберігатися на вибраних фізичних томах у інший спосіб для підвищення швидкодії. Має бути вибрано принаймні два томи."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Дані зберігатимуться як дві або декілька копій на вибраних фізичних томах для підвищення надійності. Має бути вибрано принаймні два томи."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Дані зберігатимуться як дві копії і також у інший спосіб на вибраних фізичних томах для підвищення надійності та швидкодії. Має бути вибрано принаймні чотири томи."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, один з яких може бути втрачено без втрати даних. Має бути вибрано принаймні три томи."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, один з яких може бути втрачено без втрати даних. Дані також буде збережено в інший спосіб для підвищення швидкодії. Має бути вибрано принаймні три томи."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Дані буде збережено на вибраних фізичних томах, до двох з яких може бути одночасно втрачено без втрати даних. Дані також має бути збережено в інший спосіб для підвищення швидкодії. Має бути вибрано принаймні п'ять томів."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Для вибраного компонування потрібні усі $0 вибрані фізичні томи."
 ],
 "Create logical volume": [
  null,
  "Створити логічний том"
 ],
 "Purpose": [
  null,
  "Призначення"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Для створення пристроїв VDO буде встановлено пакунок $0."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Для RAID10 потрібна парна кількість фізичних томів"
 ],
 "Logical size": [
  null,
  "Логічний розмір"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Заощаджувати місце стисканням окремих блоків за допомогою LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Заощаджувати місце, зберігаючи ідентичні блоки даних лише раз"
 ],
 "Creating VDO device": [
  null,
  "Створення пристрою VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Це монтування NFS використовується; можна лише змінювати його параметри."
 ],
 "NFS mount": [
  null,
  "Змонтована NFS"
 ],
 "New NFS mount": [
  null,
  "Нове монтування NFS"
 ],
 "Server address": [
  null,
  "Адреса сервера"
 ],
 "Server cannot be empty.": [
  null,
  "Запис сервера не може бути порожнім."
 ],
 "Path on server": [
  null,
  "Шлях на сервері"
 ],
 "Path on server cannot be empty.": [
  null,
  "Шлях на сервері не може бути порожнім."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Шлях на сервері має починатися з «/»."
 ],
 "Local mount point": [
  null,
  "Локальна точка монтування"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка монтування не може бути порожньою."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Запис точки монтування має починатися з «/»."
 ],
 "Mount options": [
  null,
  "Параметри монтування"
 ],
 "Mount at boot": [
  null,
  "Змонтувати при завантаженні"
 ],
 "Mount read only": [
  null,
  "Змонтувати лише для читання"
 ],
 "Custom mount options": [
  null,
  "Нетипові параметри монтування"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не вдалося демонтувати файлову систему"
 ],
 "Stop and unmount": [
  null,
  "Зупинити і демонтувати"
 ],
 "Unable to remove mount": [
  null,
  "Не вдалося вилучити монтування"
 ],
 "Stop and remove": [
  null,
  "Зупинити і вилучити"
 ],
 "(not mounted)": [
  null,
  "(не змонтовано)"
 ],
 "Start multipath": [
  null,
  "Запустити Multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "У системі є пристрої із декількома шляхами доступу, але службу multipath не запущено."
 ],
 "Show all $0 rows": [
  null,
  "Показати усі $0 рядків"
 ],
 "Category": [
  null,
  "Категорія"
 ],
 "more info": [
  null,
  "докладніше"
 ],
 "Encryption": [
  null,
  "Шифрування"
 ],
 "encrypted": [
  null,
  "зашифрований"
 ],
 "Last modified: $0": [
  null,
  "Востаннє змінено: $0"
 ],
 "Stored passphrase": [
  null,
  "Збережений пароль"
 ],
 "Encryption options": [
  null,
  "Параметри шифрування"
 ],
 "Encryption type": [
  null,
  "Тип шифрування"
 ],
 "Cleartext device": [
  null,
  "Пристрій Cleartext"
 ],
 "yes": [
  null,
  "так"
 ],
 "Disk passphrase": [
  null,
  "Пароль до диска"
 ],
 "Passphrase cannot be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Unlocking disk": [
  null,
  "Розблоковуємо диск"
 ],
 "Checking for $0 package": [
  null,
  "Перевірка на пакунок $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Має бути встановлено пакунок $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Пакунка $0 немає у жодному зі сховищ."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Помилка під час спроби встановити $0: PackageKit або dnf5daemon-serverне встановлено"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Неочікувана помилка PackageManager під час встановлення $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Перевіряємо на підтримку NBDE у initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd має бути створено повторно."
 ],
 "Regenerating initrd": [
  null,
  "Повторно створюємо initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Додавання rd.neednet=1 до командного рядка ядра"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Додавання «$0» до параметрів файлової системи"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Додавання «$0» параметрів шифрування"
 ],
 "Enabling $0": [
  null,
  "Вмикаємо $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Додати шифрування диска з мережевою прив'язкоюю"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "У системі зараз не передбачено підтримки розблокування кореневої файлової системи з сервером ключів Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "У системі зараз не передбачено підтримки розблокування файлової системи з сервером ключів Tang під час завантаження."
 ],
 "These additional steps are necessary:": [
  null,
  "Потрібні такі додаткові кроки:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Збереження нового пароля потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Fix NBDE support": [
  null,
  "Виправити підтримку NBDE"
 ],
 "Adding key": [
  null,
  "Додавання ключа"
 ],
 "Key source": [
  null,
  "Джерело ключа"
 ],
 "Repeat passphrase": [
  null,
  "Повторіть пароль"
 ],
 "Passphrase": [
  null,
  "Пароль"
 ],
 "Tang keyserver": [
  null,
  "Сервер ключів Tang"
 ],
 "New passphrase": [
  null,
  "Новий пароль"
 ],
 "Passphrases do not match": [
  null,
  "Паролі не збігаються"
 ],
 "Keyserver address": [
  null,
  "Адреса сервера ключів"
 ],
 "Change passphrase": [
  null,
  "Змінити пароль"
 ],
 "Old passphrase": [
  null,
  "Старий пароль"
 ],
 "Edit Tang keyserver": [
  null,
  "Редагувати сервер ключів Tang"
 ],
 "Verify key": [
  null,
  "Перевірити ключ"
 ],
 "Trust key": [
  null,
  "Довіряти ключу"
 ],
 "Passphrase can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Вилучення пароля може завадити розблокуванню $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Підтвердьте вилучення введенням альтернативного пароля"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Вилучення пароля без підтвердження іншим паролем може закрити доступ до розблоковування або керування ключами, якщо інші паролі буде забуто або втрачено."
 ],
 "Passphrase from any other key slot": [
  null,
  "Пароль з будь-якого іншого слоту ключів"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Вилучити пароль у слоті ключів $0?"
 ],
 "Remove $0?": [
  null,
  "Вилучити $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Вилучення може завадити розблокуванню $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Вилучити сервер ключів Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Вилучити ключ у слоті ключів $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Поточний користувач, від імені якого було здійснено вхід до системи, не має права перегляду даних щодо ключів."
 ],
 "No keys added": [
  null,
  "Не додано жодного ключа"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Редагування ключа потребує вільного слоту"
 ],
 "The last key slot can not be removed": [
  null,
  "Не можна вилучати останній слот ключів"
 ],
 "Keyserver": [
  null,
  "Сервер ключів"
 ],
 "Unknown type": [
  null,
  "Невідомий тип"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Тут не можна редагувати слоти ключів із невідомими типами"
 ],
 "Keys": [
  null,
  "Ключі"
 ],
 "$0 slot remains": [
  null,
  "Лишився $0 слот",
  "Лишилося $0 слоти",
  "Лишилося $0 слотів"
 ],
 "No available slots": [
  null,
  "Немає доступних слотів"
 ],
 "No free key slots": [
  null,
  "Немає вільних слотів ключів"
 ],
 "Locked data": [
  null,
  "Заблоковані дані"
 ],
 "lock": [
  null,
  "заблокувати"
 ],
 "Lock $0?": [
  null,
  "Заблокувати $0?"
 ],
 "Address cannot be empty": [
  null,
  "Адреса не може бути порожньою"
 ],
 "Address is not a valid URL": [
  null,
  "Адреса є некоректною"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Перевірити хеш ключа за допомогою сервера Tang."
 ],
 "How to check": [
  null,
  "Як перевірити"
 ],
 "In a terminal, run: ": [
  null,
  "У терміналі віддайте таку команду: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успішно скопійовано до буфера!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Перевірте, чи збігається хеш SHA-256 або SHA-1, який отримано за допомогою команди, з наведеним у цьому вікні."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Підтом BTRFS $0 з $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтування не може бути порожньою"
 ],
 "Mount point is already used for $0": [
  null,
  "Точку монтування вже використано для $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Під цією точкою монтування вже змонтовано файлові системи."
 ],
 "Please unmount them first.": [
  null,
  "Будь ласка, спочатку демонтуйте їх."
 ],
 "read only": [
  null,
  "лише читання"
 ],
 "never mount at boot": [
  null,
  "ніколи не монтувати при завантаженні"
 ],
 "after network": [
  null,
  "після мережі"
 ],
 "ignore failure": [
  null,
  "ігнорувати помилки"
 ],
 "stop boot on failure": [
  null,
  "припинити завантаження при помилці"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "У файлової системи немає пов'язаної точки монтування."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У файлової системи немає сталої точки монтування."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файлову систему не змонтовано."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Файлову систему буде розблоковано і змонтовано під час наступного завантаження. Це може потребувати введення пароля."
 ],
 "(no assigned mount point)": [
  null,
  "(немає пов'язаної точки монтування)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її буде змонтовано до $1 під час наступного завантаження."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтувати автоматично до $0 під час завантаження"
 ],
 "Mount on $0 now": [
  null,
  "Змонтувати до $0 зараз"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файлову систему зараз не змонтовано, але її буде змонтовано під час наступного завантаження."
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтувати автоматично під час завантаження"
 ],
 "Mount now": [
  null,
  "Змонтувати зараз"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано, але її не буде змонтовано після наступного завантаження."
 ],
 "Mount also automatically on boot": [
  null,
  "Також монтувати автоматично під час завантаження"
 ],
 "Unmount now": [
  null,
  "Демонтувати зараз"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її не буде змонтовано після наступного завантаження."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Файлову систему налаштовано на автоматичне монтування при вході до системи, але її контейнер шифрування не буде розблоковано вчасно."
 ],
 "Unlock automatically on boot": [
  null,
  "Автоматично розблокувати при завантаженні"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Несумісне монтування файлових систем"
 ],
 "$0 filesystem": [
  null,
  "Файлова система $0"
 ],
 "Filesystem name": [
  null,
  "Назва файлової системи"
 ],
 "Filesystem is locked": [
  null,
  "Файлову систему заблоковано"
 ],
 "Mounts before services start": [
  null,
  "Монтується до запуску служб"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Придатне для критичних монтувань, зокрема /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Завантаження зазнає невдачі, якщо не монтується ця файлова система, заважаючи віддаленому доступу"
 ],
 "Mounts in parallel with services": [
  null,
  "Монтується паралельно зі службами"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Завантаження буде успішним, якщо файлову систему не змонтовано"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Монтується паралельно зі службами, але після того, як стане доступною мережа"
 ],
 "Does not mount during boot": [
  null,
  "Не монтується під час завантаження"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Корисно для монтувань, які є необов'язковими або потребують взаємодії (зокрема паролів)"
 ],
 "At boot": [
  null,
  "При завантаженні"
 ],
 "Mount before services start": [
  null,
  "Змонтувати до запуску служб"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Змонтувати без очікування, ігнорувати помилки"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Змонтувати після того, як стане доступною мережа, ігнорувати помилки"
 ],
 "Do not mount": [
  null,
  "Не монтувати"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Цей пристрій не можна використовувати для цілі встановлення."
 ],
 "Mount filesystem": [
  null,
  "Змонтувати файлову систему"
 ],
 "Unmount filesystem $0": [
  null,
  "Демонтувати файлову систему $0"
 ],
 "Mount configuration": [
  null,
  "Налаштування монтування"
 ],
 "Swap": [
  null,
  "Свопінґ"
 ],
 "Used": [
  null,
  "Використано"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Розблокувати зашифрований буфер Stratis"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Вкажіть пароль до буфера даних на цих блокових пристроях:"
 ],
 "Stratis pool": [
  null,
  "Буфер Stratis"
 ],
 "stopped": [
  null,
  "зупинено"
 ],
 "Block devices": [
  null,
  "Блокові пристрої"
 ],
 "No block devices found": [
  null,
  "Не знайдено блокових пристроїв"
 ],
 "Stratis block devices": [
  null,
  "Блокові пристрої Stratis"
 ],
 "Stratis block device": [
  null,
  "Блоковий пристрій Stratis"
 ],
 "data": [
  null,
  "дані"
 ],
 "cache": [
  null,
  "кеш"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Будь ласка, надайте наявний пароль до буфера."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Якщо не буде доступу до сервера ключів $0, ви можете надати наявний пароль."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Якщо не буде доступу до жодного з серверів ключів, ви можете надати наявний пароль."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Якщо не працюватиме жоден з неінтерактивних методів розблокування, ви можете надати наявний пароль."
 ],
 "Pool passphrase": [
  null,
  "Пароль до буфера"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Серве ключів у $0 має бути доступним."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Доступним має бути принаймні один сервер ключів."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Має працювати принаймні один з неінтерактивних методів розблокування."
 ],
 "Create filesystem": [
  null,
  "Створити файлову систему"
 ],
 "Stratis filesystem": [
  null,
  "Файлова система Stratis"
 ],
 "Set initial size": [
  null,
  "Встановити початковий розмір"
 ],
 "Limit size": [
  null,
  "Обмеження розміру"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Вилучення буфера Stratis призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Rename Stratis pool": [
  null,
  "Перейменувати буфер Stratis"
 ],
 "Add block devices": [
  null,
  "Додати блокові пристрої"
 ],
 "Tier": [
  null,
  "Клас"
 ],
 "Data": [
  null,
  "Дані"
 ],
 "Cache": [
  null,
  "Кеш"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Для розблокування буфера потрібне додавання блокових пристроїв."
 ],
 "Encrypted Stratis pool": [
  null,
  "Шифрований буфер Stratis"
 ],
 "Delete pool": [
  null,
  "Вилучити резерв"
 ],
 "Encryption tokens": [
  null,
  "Жетони шифрування"
 ],
 "Stratis filesystems": [
  null,
  "Файлові системи Stratis"
 ],
 "Create new filesystem": [
  null,
  "Створити файлову систему"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Цей буфер даних не використовує усе доступне місце на його блокових пристроях."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Після створення буфера зріс розмір деяких блокових пристроїв у цьому буфері. Розмір буфера можна безпечно збільшити з метою використання доданого місця."
 ],
 "Grow the pool to take all space": [
  null,
  "Збільшити буфер так, щоб використати усе місце"
 ],
 "This pool is in a degraded state.": [
  null,
  "Цей буфер перебуває у стані із погіршеними властивостями."
 ],
 "No filesystems": [
  null,
  "Немає файлових систем"
 ],
 "Stratis filesystems pool": [
  null,
  "Буфер файлових систем Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Цей пароль є єдиним способом розблокування буфера, його не можна вилучати."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Цей сервер ключів є єдиним способом розблокування буфера, його не можна вилучати."
 ],
 "Add passphrase": [
  null,
  "Додати пароль"
 ],
 "Add keyserver": [
  null,
  "Додати сервер ключів"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis «$0»"
 ],
 "Last token can not be removed": [
  null,
  "Не вдалося вилучити останній жетон"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Немає місця для паролів або серверів ключів."
 ],
 "Confirm": [
  null,
  "Підтвердити"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Потрібне надання пароля для розблокування буфера."
 ],
 "Remove passphrase?": [
  null,
  "Вилучити пароль?"
 ],
 "Add Tang keyserver": [
  null,
  "Додати сервер ключів Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Додавання сервера ключів потребує розблокування буфера."
 ],
 "Remove Clevis token?": [
  null,
  "Вилучити жетон Clevis?"
 ],
 "Metadata format": [
  null,
  "Формат метаданих"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Буфери з метаданими у форматі версії 1 обмежено не більше, ніж одним паролем і не більше, ніж одним сервером ключів."
 ],
 "Overprovisioning": [
  null,
  "Перепрогнозування"
 ],
 "Allow overprovisioning": [
  null,
  "Дозволити перепрогнозування"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Розміри віртуальних файлових систем перевищують розміри буфера. Перепрогнозування не можна вимкнути."
 ],
 "Allocated": [
  null,
  "Розподілено"
 ],
 "Name can not be empty.": [
  null,
  "Назва не повинна бути порожньою."
 ],
 "A pool with this name exists already.": [
  null,
  "Буфер із цією назвою вже існує."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "У цьому буфері вже існує файлова система із цією назвою."
 ],
 "Create Stratis pool": [
  null,
  "Створити буфер Stratis"
 ],
 "No block devices are available.": [
  null,
  "Немає доступних блокових пристроїв."
 ],
 "At least one block device is needed.": [
  null,
  "Потрібен принаймні один блоковий пристрій."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Зашифрувати дані за допомогою пароля шифрування"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Зашифрувати дані за допомогою сервера ключів Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Створити знімок файлової системи $0"
 ],
 "Create snapshot and mount": [
  null,
  "Створити знімок і змонтувати"
 ],
 "Create snapshot only": [
  null,
  "Лише створити знімок"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Вилучення файлової системи призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "Snapshot": [
  null,
  "Знімок"
 ],
 "Rename filesystem": [
  null,
  "Перейменувати файлову систему"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Встановити обмеження розміру віртуальної файлової системи"
 ],
 "Limit virtual filesystem size": [
  null,
  "Обмежити розмір віртуальної файлової системи"
 ],
 "Virtual size limit": [
  null,
  "Обмеження віртуального розміру"
 ],
 "Virtual size": [
  null,
  "Віртуальний розмір"
 ],
 "Create RAID device": [
  null,
  "Створити пристрій RAID"
 ],
 "RAID level": [
  null,
  "Рівень RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Стрічка)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Дзеркало)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Пов’язана парність)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Розподілена парність)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Подвійна розподілена парність)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Стрічка дзеркал)"
 ],
 "Chunk size": [
  null,
  "Розмір фрагмента"
 ],
 "4 KiB": [
  null,
  "4 КіБ"
 ],
 "8 KiB": [
  null,
  "8 КіБ"
 ],
 "16 KiB": [
  null,
  "16 КіБ"
 ],
 "32 KiB": [
  null,
  "32 КіБ"
 ],
 "64 KiB": [
  null,
  "64 КіБ"
 ],
 "128 KiB": [
  null,
  "128 КіБ"
 ],
 "512 KiB": [
  null,
  "512 КіБ"
 ],
 "1 MiB": [
  null,
  "1 МіБ"
 ],
 "2 MiB": [
  null,
  "2 МіБ"
 ],
 "At least $0 disk is needed.": [
  null,
  "Потрібен принаймні $0 диск.",
  "Потрібно принаймні $0 диски.",
  "Потрібно принаймні $0 дисків."
 ],
 "MDRAID disk": [
  null,
  "Диск MDRAID"
 ],
 "In sync": [
  null,
  "Синхронізовано"
 ],
 "Spare": [
  null,
  "Запас"
 ],
 "Recovering": [
  null,
  "Відновлюємо"
 ],
 "Write-mostly": [
  null,
  "Здебільшого запис"
 ],
 "Blocked": [
  null,
  "Заблоковано"
 ],
 "Unknown ($0)": [
  null,
  "Невідомий ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Пристрій MDRAID має працювати"
 ],
 "MDRAID device is recovering": [
  null,
  "Пристрій MDRAID відновлюється"
 ],
 "Need a spare disk": [
  null,
  "Потрібен резервний диск"
 ],
 "Last disk can not be removed": [
  null,
  "Не можна вилучати останній диск"
 ],
 "MDRAID device": [
  null,
  "пристрій MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Підтвердьте зупинку $0"
 ],
 "Stop device": [
  null,
  "Зупинити пристрій"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої RAID."
 ],
 "MDRAID device must be running": [
  null,
  "Пристрій MDRAID має бути запущено"
 ],
 "Add disk": [
  null,
  "Додати диск"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "Диски $0"
 ],
 "$0 chunk size": [
  null,
  "Розмір фрагмента $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Пристрій MDRAID перебуває у стані із погіршеними властивостями"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Цей пристрій MDRAID не має бітової карти призначення до запису. Така бітова карта може значно зменшити час синхронізації."
 ],
 "Add a bitmap": [
  null,
  "Додати бітову карту"
 ],
 "No disks found": [
  null,
  "Дисків не знайдено"
 ],
 "MDRAID disks": [
  null,
  "Диски MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Створення цього пристрою VDO не завершено, ним не можна користуватися."
 ],
 "Remove device": [
  null,
  "Вилучити пристрій"
 ],
 "Grow to take all space": [
  null,
  "Збільшити так, щоб використати усе місце"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Цей пристрій VDO не використовує увесь об'єм резервного пристрою."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Використано лише $0 з $1."
 ],
 "Grow logical size of $0": [
  null,
  "Збільшити логічний розмір $0"
 ],
 "Physical": [
  null,
  "Фізичний"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 даних + $1 додатково використано з $2 ($3)"
 ],
 "Logical": [
  null,
  "Логічний"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 використано з $1 ($2 заощаджено)"
 ],
 "Index memory": [
  null,
  "Пам'ять покажчика"
 ],
 "SMART self-test of $target": [
  null,
  "Самоперевірка SMART $target"
 ],
 "Ejecting $target": [
  null,
  "Видобуваємо $target"
 ],
 "Unlocking $target": [
  null,
  "Розблокуємо $target"
 ],
 "Locking $target": [
  null,
  "Блокуємо $target"
 ],
 "Modifying $target": [
  null,
  "Змінюємо $target"
 ],
 "Resizing $target": [
  null,
  "Зміна розміру $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запускаємо резервну область пам’яті $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Зупиняємо резервну область пам’яті $target"
 ],
 "Mounting $target": [
  null,
  "Монтуємо $target"
 ],
 "Unmounting $target": [
  null,
  "Демонтуємо $target"
 ],
 "Checking $target": [
  null,
  "Перевіряємо $target"
 ],
 "Repairing $target": [
  null,
  "Відновлюємо $target"
 ],
 "Erasing $target": [
  null,
  "Витираємо $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Створюємо файлову систему на $target"
 ],
 "Setting up loop device $target": [
  null,
  "Налаштовуємо петльовий пристрій $target"
 ],
 "Deleting $target": [
  null,
  "Вилучаємо $target"
 ],
 "Creating partition $target": [
  null,
  "Створюємо розділ $target"
 ],
 "Cleaning up for $target": [
  null,
  "Спорожнюємо для $target"
 ],
 "Securely erasing $target": [
  null,
  "Безпечно витираємо $target"
 ],
 "Very securely erasing $target": [
  null,
  "Дуже безпечно витираємо $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Зупиняємо пристрій MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Запускаємо пристрій MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Позначаємо $target як помилковий"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Вилучаємо $target з пристрою MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Створення пристрою MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Перевіряємо пристрій MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Перевіряємо і відновлюємо пристрій MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Відновлюємо пристрій MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Синхронізуємо пристрій MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Активуємо $target"
 ],
 "Deactivating $target": [
  null,
  "Деактивуємо $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Створюємо знімок $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Створюємо групу томів LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Вилучаємо групу томів LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Додаємо фізичний том до $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Вилучаємо фізичний том з $target"
 ],
 "Emptying $target": [
  null,
  "Спорожняємо $target"
 ],
 "Creating logical volume $target": [
  null,
  "Створюємо логічний том $target"
 ],
 "Renaming $target": [
  null,
  "Перейменовуємо $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Дія «$operation» над $target"
 ],
 "unknown target": [
  null,
  "невідоме призначення"
 ],
 "Jobs": [
  null,
  "Завдання"
 ],
 "Reading": [
  null,
  "Читання"
 ],
 "Writing": [
  null,
  "Запис"
 ],
 "Install Stratis support": [
  null,
  "Встановити підтримку Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Для створення буферів Stratis має бути встановлено пакунок $0."
 ],
 "Install NFS support": [
  null,
  "Встановити підтримку NFS"
 ],
 "Create MDRAID device": [
  null,
  "Створити пристрій MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Створити групу томів LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Змінити назву ініціатора iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Додати портал iSCSI"
 ],
 "Local storage": [
  null,
  "Локальне сховище даних"
 ],
 "Networked storage": [
  null,
  "Мережеве сховище"
 ],
 "Create storage device": [
  null,
  "Створити пристрій зберігання даних"
 ],
 "No storage found": [
  null,
  "Не знайдено сховища даних"
 ],
 "Server address cannot be empty.": [
  null,
  "Адреса сервера не може бути порожньою."
 ],
 "Next": [
  null,
  "Далі"
 ],
 "Invalid username or password": [
  null,
  "Некоректне ім’я користувача чи пароль"
 ],
 "Unknown host name": [
  null,
  "Невідома назва вузла"
 ],
 "Unable to reach server": [
  null,
  "Не вдалося досягти сервера"
 ],
 "Available targets on $0": [
  null,
  "Доступні призначення на $0"
 ],
 "Authentication required": [
  null,
  "Слід пройти розпізнавання"
 ],
 "iSCSI portal": [
  null,
  "Портал iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Диски iSCSI"
 ],
 "No drives found": [
  null,
  "Дисків не знайдено"
 ],
 "Target": [
  null,
  "Призначення"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Пристрої резервного копіювання VDO не можна звужувати"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Блокові пристрої Stratis не можна звужувати"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Тут не можна зменшити об'єм нерозпізнаних даних."
 ],
 "Unlock before resizing": [
  null,
  "Розблокуйте до зміни розмірів"
 ],
 "$0 can not be resized here": [
  null,
  "Тут не можна змінювати розмір $0"
 ],
 "$0 can not be resized": [
  null,
  "Розмір $0 не можна змінювати"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 не можна зменшувати"
 ],
 "$0 can not be made larger": [
  null,
  "$0 не можна збільшувати"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Тут не можна змінювати розміри фізичних томів"
 ],
 "Swap can not be resized here": [
  null,
  "Тут не можна змінювати розмір резервної пам'яті"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Тут не можна зменшити об'єм нерозпізнаних даних"
 ],
 "Activate before resizing": [
  null,
  "Активуйте до зміни розмірів"
 ],
 "Grow logical volume": [
  null,
  "Збільшити логічний том"
 ],
 "Grow partition": [
  null,
  "Збільшити розділ"
 ],
 "grow": [
  null,
  "збільшити"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Має бути вибрано точно $0 фізичних томів"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Зміна розмірів зашифрованої системи потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Має бути вибрано точно $0 фізичних ктомів по одному на кожну смугу логічного тому."
 ],
 "Shrink logical volume": [
  null,
  "Стиснути логічний том"
 ],
 "shrink": [
  null,
  "стиснути"
 ],
 "Unformatted data": [
  null,
  "Неформатовані дані"
 ],
 "Block device": [
  null,
  "Блоковий пристрій"
 ],
 "Device number": [
  null,
  "Номер пристрою"
 ],
 "Create partition on $0": [
  null,
  "Створити розділ на $0"
 ],
 "Format $0": [
  null,
  "Форматувати $0"
 ],
 "No filesystem": [
  null,
  "Немає файлової системи"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "No encryption": [
  null,
  "Без шифрування"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Повторно використати наявне шифрування ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Повторно використати наявне шифрування"
 ],
 "format": [
  null,
  "формат"
 ],
 "Format and mount": [
  null,
  "Форматувати і змонтувати"
 ],
 "Format only": [
  null,
  "Лише форматувати"
 ],
 "Format": [
  null,
  "Формат"
 ],
 "Create and start": [
  null,
  "Створити і запустити"
 ],
 "Format and start": [
  null,
  "Форматувати і запустити"
 ],
 "Store passphrase": [
  null,
  "Зберігати пароль"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Перед форматуванням диск має бути розблоковано. Будь ласка, надайте наявний пароль."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Форматування призведе до знищення усіх даних на пристрої для зберігання даних."
 ],
 "Unrecognized data": [
  null,
  "Нерозпізнані дані"
 ],
 "Storage can not be managed on this system.": [
  null,
  "У цій системі не можна керувати сховищем даних."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтів"
 ]
});
