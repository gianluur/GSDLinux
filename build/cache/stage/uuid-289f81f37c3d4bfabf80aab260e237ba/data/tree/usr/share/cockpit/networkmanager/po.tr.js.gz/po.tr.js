cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Firewall": [
  null,
  "Güvenlik duvarı"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Public key": [
  null,
  "Ortak anahtar"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "Unexpected error": [
  null,
  "Beklenmeyen hata"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "Connect": [
  null,
  "Bağlan"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "Disconnected": [
  null,
  "Bağlantı kesildi"
 ],
 "Permission denied": [
  null,
  "İzin reddedildi"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Yönetimsel erişim elde etmek için hiçbir yöntem mevcut değil (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit $0 hata kodunu bildirdi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Error during initialization": [
  null,
  "Başlatma sırasında hata"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Home": [
  null,
  "Giriş"
 ],
 "Downloads": [
  null,
  "İndirmeler"
 ],
 "Not a directory": [
  null,
  "Dizin değil"
 ],
 "All files": [
  null,
  "Tüm dosyalar"
 ],
 "Recent": [
  null,
  "En son"
 ],
 "No recent directories": [
  null,
  "Son dizinler yok"
 ],
 "No recent files": [
  null,
  "Son dosyalar yok"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "File chooser actions": [
  null,
  "Dosya seçici eylemleri"
 ],
 "Open in file browser": [
  null,
  "Dosya tarayıcısında aç"
 ],
 "Hide hidden files": [
  null,
  "Gizli dosyaları gizle"
 ],
 "Show hidden files": [
  null,
  "Gizli dosyaları göster"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Clear filters": [
  null,
  "Süzgeçleri temizle"
 ],
 "Directory is empty": [
  null,
  "Dizin boş"
 ],
 "Directory has no sub-directories": [
  null,
  "Dizin, alt dizinlere sahip değil"
 ],
 "This directory contains only hidden files": [
  null,
  "Bu dizin yalnızca gizli dosyaları içerir"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "Folder": [
  null,
  "Klasör"
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Priority": [
  null,
  "Öncelik"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Generated": [
  null,
  "Oluşturuldu"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Start service": [
  null,
  "Hizmeti başlat"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Delete $0": [
  null,
  "$0 sil"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Actions": [
  null,
  "Eylemler"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Not available": [
  null,
  "Mevcut değil"
 ],
 "Ignore": [
  null,
  "Yoksay"
 ],
 "Permanent": [
  null,
  "Kalıcı"
 ],
 "Preserve": [
  null,
  "Koru"
 ],
 "Random": [
  null,
  "Rastgele"
 ],
 "Stable": [
  null,
  "Kararlı"
 ],
 "Use $0": [
  null,
  "$0 kullan"
 ],
 "Failed to save settings": [
  null,
  "Ayarları kaydetme başarısız oldu"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Bu $0 oluşturmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Create it": [
  null,
  "Oluştur"
 ],
 "Invalid prefix $0": [
  null,
  "Geçersiz ön ek $0"
 ],
 "Invalid metric $0": [
  null,
  "Geçersiz ölçüm $0"
 ],
 "Invalid address $0": [
  null,
  "Geçersiz adres $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Geçersiz ön ek veya ağ maskesi $0"
 ],
 "Testing connection": [
  null,
  "Bağlantı deneniyor"
 ],
 "Restoring connection": [
  null,
  "Bağlantı geri yükleniyor"
 ],
 "Troubleshoot…": [
  null,
  "Sorun gider…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager çalışmıyor"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager kurulu değil"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Ağ aygıtları ve grafikleri için NetworkManager gerekir"
 ],
 "Enable service": [
  null,
  "Hizmeti etkinleştir"
 ],
 "Network interface '$0' not found": [
  null,
  "'$0' ağ arayüzü bulunamadı"
 ],
 "Return to overview page": [
  null,
  "Genel bakış sayfasına dön"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Güvenlik duvarını değiştirmek için yetkili değilsiniz."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Güvenlik duvarını etkisizleştirmeye yetkili değil"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Güvenlik duvarını etkinleştirmeye yetkili değil"
 ],
 "Disable the firewall": [
  null,
  "Güvenlik duvarını etkisizleştir"
 ],
 "Enable the firewall": [
  null,
  "Güvenlik duvarını etkinleştir"
 ],
 "Edit service $0": [
  null,
  "$0 hizmetini düzenle"
 ],
 "Remove service $0": [
  null,
  "$0 hizmetini kaldır"
 ],
 "Included Services": [
  null,
  "Dahil Olan Hizmetler"
 ],
 "Additional port": [
  null,
  "Ek bağlantı noktası"
 ],
 "Remove additional port": [
  null,
  "Ek bağlantı noktasını kaldır"
 ],
 "Remove zone $0": [
  null,
  "$0 bölgesini kaldır"
 ],
 "Add services to zone $0": [
  null,
  "$0 bölgesine hizmetleri ekle"
 ],
 "Add services": [
  null,
  "Hizmetleri ekle"
 ],
 "Service": [
  null,
  "Hizmet"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 bölgesi"
 ],
 "Interface": [
  null,
  "Arayüz",
  "Arayüzler"
 ],
 "Allowed addresses": [
  null,
  "İzin verilen adresler"
 ],
 "Entire subnet": [
  null,
  "Tüm alt ağ"
 ],
 "There are no active services in this zone": [
  null,
  "Bu bölgede etkin hizmetler yok"
 ],
 "Filter services": [
  null,
  "Hizmetleri süz"
 ],
 "Failed to edit service": [
  null,
  "Hizmeti düzenleme başarısız oldu"
 ],
 "Failed to add port": [
  null,
  "Bağlantı noktası ekleme başarısız oldu"
 ],
 "Failed to add service": [
  null,
  "Hizmet ekleme başarısız oldu"
 ],
 "Unknown service name": [
  null,
  "Bilinmeyen hizmet adı"
 ],
 "Invalid port number": [
  null,
  "Geçersiz bağlantı noktası numarası"
 ],
 "Invalid range": [
  null,
  "Geçersiz aralık"
 ],
 "Range must be strictly ordered": [
  null,
  "Aralık kesin bir şekilde sıralı olmalıdır"
 ],
 "Edit service": [
  null,
  "Hizmeti düzenle"
 ],
 "Edit custom service in $0 zone": [
  null,
  "$0 bölgesinde özel hizmeti düzenle"
 ],
 "Add ports": [
  null,
  "Bağlantı noktaları ekle"
 ],
 "Add ports to $0 zone": [
  null,
  "$0 bölgesine bağlantı noktaları ekle"
 ],
 "Add services to $0 zone": [
  null,
  "$0 bölgesine hizmetleri ekle"
 ],
 "Custom ports": [
  null,
  "Özel bağlantı noktaları"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Örnek: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Virgülle ayrılmış bağlantı noktaları, aralıklar ve hizmetler kabul edilir"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Örnek: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Eğer boş bırakılırsa, ilişkilendirilmiş bağlantı noktası hizmetlerine ve bağlantı noktası numaralarına dayanarak kimlik oluşturulacaktır"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Özel bağlantı noktalarının eklenmesi firewalld hizmetini yeniden yükleyecek. Yeniden yükleme, herhangi bir sadece çalışma zamanı yapılandırmasının kaybolmasına neden olacak!"
 ],
 "Failed to add zone": [
  null,
  "Bölge ekleme başarısız oldu"
 ],
 "Add zone": [
  null,
  "Bölge ekle"
 ],
 "Trust level": [
  null,
  "Güven seviyesi"
 ],
 "Sorted from least to most trusted": [
  null,
  "En azdan en çok güvenilene doğru sıralandı"
 ],
 "Custom zones": [
  null,
  "Özel bölgeler"
 ],
 "No description available": [
  null,
  "Mevcut açıklama yok"
 ],
 "Included services": [
  null,
  "Dahil olan hizmetler"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit hizmeti otomatik olarak dahil edildi"
 ],
 "Interfaces": [
  null,
  "Arayüzler"
 ],
 "Range": [
  null,
  "Aralık"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Yönlendirme ön ekiyle birlikte IP adresi. Birden çok değeri virgülle ayırın. Örnek: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "$0 kaldırılmasını onayla"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Bu bölge cockpit hizmetini içeriyor. Bu bölgenin geçerli web konsolu bağlantınıza uygulanmadığından emin olun."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Bölgenin kaldırılması, içindeki tüm hizmetleri kaldıracak."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cockpit hizmetinin kaldırılması web konsolunu erişilemez hale getirebilir. Bu bölgenin şu anki web konsolu bağlantınıza uygulanmadığından emin olun."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$0 hizmetini $1 bölgesinden kaldır"
 ],
 "Firewall is not available": [
  null,
  "Güvenlik duvarı kullanılabilir değil"
 ],
 "Please install the $0 package": [
  null,
  "Lütfen $0 paketini kurun"
 ],
 "Add a new zone": [
  null,
  "Yeni bir bölge ekle"
 ],
 "Add new zone": [
  null,
  "Yeni bölge ekle"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Gelen istekler varsayılan olarak engellenir. Giden istekler engellenmez."
 ],
 "Connected": [
  null,
  "Bağlandı"
 ],
 "Wireless": [
  null,
  "Kablosuz"
 ],
 "Wired": [
  null,
  "Kablolu"
 ],
 "No networks found": [
  null,
  "Bulunan ağlar yok"
 ],
 "No interface selected": [
  null,
  "Seçilen arayüz yok"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "Bağlantıyı yapılandırmak için bir ağ arayüzü seçin."
 ],
 "SSID can not be empty": [
  null,
  "SSID boş olamaz"
 ],
 "Password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Failed to connect": [
  null,
  "Bağlanma başarısız oldu"
 ],
 "Check your password.": [
  null,
  "Parolanızı gözden geçirin."
 ],
 "Connect to hidden network": [
  null,
  "Gizli ağa bağlan"
 ],
 "Connect to $0": [
  null,
  "$0 cihazına bağlan"
 ],
 "Network name": [
  null,
  "Ağ adı"
 ],
 "Security": [
  null,
  "Güvenlik"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Kişisel"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 silmek sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 açmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Switch on $0": [
  null,
  "$0 arayüzünü aç"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kapatmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Switch off $0": [
  null,
  "$0 arayüzünü kapat"
 ],
 "Bond": [
  null,
  "Birleştirme (Bond)"
 ],
 "Team": [
  null,
  "Takım"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Köprü"
 ],
 "Unknown \"$0\"": [
  null,
  "Bilinmeyen \"$0\""
 ],
 "Carrier": [
  null,
  "Taşıyıcı"
 ],
 "Yes": [
  null,
  "Evet"
 ],
 "No": [
  null,
  "Hayır"
 ],
 "Inactive": [
  null,
  "Etkin değil"
 ],
 "Unknown configuration": [
  null,
  "Bilinmeyen yapılandırma"
 ],
 "Additional address $val": [
  null,
  "Ek adres $val"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Gateway $gateway": [
  null,
  "$gateway ağ geçidi"
 ],
 "Additional DNS $val": [
  null,
  "Ek DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ek DNS arama etki alanları $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS arama etki alanları $val"
 ],
 "General": [
  null,
  "Genel"
 ],
 "Connect automatically": [
  null,
  "Otomatik olarak bağlan"
 ],
 "Automatic": [
  null,
  "Otomatik"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP izleme"
 ],
 "Broken configuration": [
  null,
  "Bozuk yapılandırma"
 ],
 "Team port": [
  null,
  "Takım bağlantı noktası"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protokolü"
 ],
 "Priority $priority": [
  null,
  "Öncelik $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Yönlendirme gecikmesi $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Merhaba süresi $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "En fazla ileti yaşı $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Yol maliyeti $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hairpin kipi"
 ],
 "Bridge port": [
  null,
  "Köprü bağlantı noktası"
 ],
 "Parent $parent": [
  null,
  "Üst öğe $parent"
 ],
 "ID $id": [
  null,
  "Kimlik $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Ağ parolası saklanmadı. Lütfen unutturun ve bu ağa yeniden bağlanın."
 ],
 "Failed to connect to $0": [
  null,
  "$0 cihazına bağlanma başarısız oldu"
 ],
 "secured": [
  null,
  "güvenli"
 ],
 "open": [
  null,
  "açık"
 ],
 "Last connected: $0": [
  null,
  "Son bağlanan: $0"
 ],
 "Signal strength": [
  null,
  "Sinyal gücü"
 ],
 "Not permitted to disconnect network": [
  null,
  "Ağ bağlantısını kesmeye izin verilmiyor"
 ],
 "Disconnect": [
  null,
  "Bağlantıyı kes"
 ],
 "Not permitted to connect to network": [
  null,
  "Ağa bağlanmaya izin verilmiyor"
 ],
 "Forget": [
  null,
  "Unut"
 ],
 "$0 hidden network": [
  null,
  "$0 gizli ağ",
  "$0 gizli ağ"
 ],
 "Filter": [
  null,
  "Süzgeç"
 ],
 "Refresh": [
  null,
  "Yenile"
 ],
 "Available networks": [
  null,
  "Mevcut ağlar"
 ],
 "Network": [
  null,
  "Ağ"
 ],
 "Mode": [
  null,
  "Kip"
 ],
 "Signal": [
  null,
  "Sinyal"
 ],
 "Rate": [
  null,
  "Oran"
 ],
 "Primary action": [
  null,
  "Birincil eylem"
 ],
 "Secondary actions": [
  null,
  "İkincil eylemler"
 ],
 "Not permitted to configure network devices": [
  null,
  "Ağ aygıtlarını yapılandırmaya izin verilmiyor"
 ],
 "Enable or disable the device": [
  null,
  "Aygıtı etkinleştirin veya etkisizleştirin"
 ],
 "This device cannot be managed here.": [
  null,
  "Bu aygıt burada yönetilemez."
 ],
 "Connection will be lost": [
  null,
  "Bağlantı kaybolacaktır"
 ],
 "Keep connection": [
  null,
  "Bağlantıyı koru"
 ],
 "Invalid IP address: $0": [
  null,
  "Geçersiz IP adresi: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "Geçersiz hedef adresi: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Geçersiz ağ geçidi adresi: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Geçersiz DNS adresi: $0"
 ],
 "Preparing": [
  null,
  "Hazırlanıyor"
 ],
 "Configuring": [
  null,
  "Yapılandırılıyor"
 ],
 "Authenticating": [
  null,
  "Kimlik doğrulanıyor"
 ],
 "Configuring IP": [
  null,
  "IP yapılandırma"
 ],
 "Checking IP": [
  null,
  "IP denetleniyor"
 ],
 "Waiting": [
  null,
  "Bekleniyor"
 ],
 "Active": [
  null,
  "Etkin"
 ],
 "Deactivating": [
  null,
  "Devre dışı bırakılıyor"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Altyapı"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Örgüsel"
 ],
 "No carrier": [
  null,
  "Taşıyıcı yok"
 ],
 "Part of $0": [
  null,
  "$0 parçası"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Ayarların değiştirilmesi sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Change the settings": [
  null,
  "Ayarları değiştir"
 ],
 "Add bridge": [
  null,
  "Köprü ekle"
 ],
 "Edit bridge settings": [
  null,
  "Köprü ayarlarını düzenle"
 ],
 "Ports": [
  null,
  "Bağlantı noktaları"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protokolü (STP)"
 ],
 "STP priority": [
  null,
  "STP önceliği"
 ],
 "STP forward delay": [
  null,
  "STP yönlendirme gecikmesi"
 ],
 "STP hello time": [
  null,
  "STP merhaba süresi"
 ],
 "STP maximum message age": [
  null,
  "STP en fazla ileti yaşı"
 ],
 "Round robin": [
  null,
  "Döngüsel"
 ],
 "Active backup": [
  null,
  "Etkin yedekleme"
 ],
 "Load balancing": [
  null,
  "Yük dengeleme"
 ],
 "Broadcast": [
  null,
  "Yayınlama"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Pasif"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Takım ekle"
 ],
 "Edit team settings": [
  null,
  "Takım ayarlarını düzenle"
 ],
 "Runner": [
  null,
  "Çalıştırıcı"
 ],
 "Balancer": [
  null,
  "Dengeleyici"
 ],
 "Primary": [
  null,
  "Birincil"
 ],
 "Link watch": [
  null,
  "Bağlantı izleme"
 ],
 "Link up delay": [
  null,
  "Bağlantı açılma gecikmesi"
 ],
 "Link down delay": [
  null,
  "Bağlantı kapanma gecikmesi"
 ],
 "Ping interval": [
  null,
  "Ping aralığı"
 ],
 "Ping target": [
  null,
  "Ping hedefi"
 ],
 "Automatic (DHCP only)": [
  null,
  "Otomatik (Sadece DHCP)"
 ],
 "Link local": [
  null,
  "Yerel bağlantı"
 ],
 "Manual": [
  null,
  "Elle"
 ],
 "Shared": [
  null,
  "Paylaşılan"
 ],
 "Prefix length or netmask": [
  null,
  "Ön ek uzunluğu veya ağ maskesi"
 ],
 "Prefix length": [
  null,
  "Ön ek uzunluğu"
 ],
 "IPv4 settings": [
  null,
  "IPv4 ayarları"
 ],
 "IPv6 settings": [
  null,
  "IPv6 ayarları"
 ],
 "Addresses": [
  null,
  "Adresler"
 ],
 "Select method": [
  null,
  "Yöntem seç"
 ],
 "Add address": [
  null,
  "Adres ekle"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Remove item": [
  null,
  "Öğeyi kaldır"
 ],
 "Gateway": [
  null,
  "Ağ geçidi"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "DNS sunucusu ekle"
 ],
 "DNS search domains": [
  null,
  "DNS arama etki alanları"
 ],
 "Add search domain": [
  null,
  "Arama etki alanı ekle"
 ],
 "Search domain": [
  null,
  "Etki alanını ara"
 ],
 "Routes": [
  null,
  "Yönlendirmeler"
 ],
 "Add route": [
  null,
  "Yönlendirme ekle"
 ],
 "Metric": [
  null,
  "Ölçüm"
 ],
 "Enter a valid MAC address": [
  null,
  "Geçerli bir MAC adresi girin"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC adresi"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 Ağ",
  "$0 Ağ"
 ],
 "Add VPN": [
  null,
  "VPN ekle"
 ],
 "Add bond": [
  null,
  "Birleştirme (Bond) ekle"
 ],
 "Add VLAN": [
  null,
  "VLAN ekle"
 ],
 "Edit rules and zones": [
  null,
  "Kuralları ve bölgeleri düzenle"
 ],
 "$0 active zone": [
  null,
  "$0 etkin bölge",
  "$0 etkin bölge"
 ],
 "Managed interfaces": [
  null,
  "Yönetilen arayüzler"
 ],
 "IP address": [
  null,
  "IP adresi"
 ],
 "Sending": [
  null,
  "Gönderilen"
 ],
 "Receiving": [
  null,
  "Alınan"
 ],
 "Unmanaged interfaces": [
  null,
  "Yönetilmeyen arayüzler"
 ],
 "Network logs": [
  null,
  "Ağ günlükleri"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresler doğru olarak biçimlendirilmemiş"
 ],
 "Invalid IP address '$0'": [
  null,
  "Geçersiz IP adresi: '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools paketi kurulu değil"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Kişi #$0 geçersiz uç noktaya sahip. Anamakine:b.noktası olarak belirtilmek zorundadır, örn. 1.2.3.4:51820, [2001:db8::1]:51820 veya ornek.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Kişi #$0 geçersiz uç nokta bağlantı noktasına sahip. Bağlantı noktası bir sayı olmak zorundadır."
 ],
 "Listen port must be a number": [
  null,
  "Dinlenen bağlantı noktası bir sayı olmak zorundadır"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN ekle"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN'i düzenle"
 ],
 "Private key": [
  null,
  "Özel anahtar"
 ],
 "Paste existing key": [
  null,
  "Varolan anahtarı yapıştır"
 ],
 "Regenerate": [
  null,
  "Yeniden oluştur"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Geçerli bir özel anahtar girildiğinde ortak anahtar oluşturulacaktır"
 ],
 "Listen port": [
  null,
  "Dinlenen bağlantı noktası"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "\"Otomatik\" olarak ayarlanacak"
 ],
 "IP addresses": [
  null,
  "IP adresleri"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Sınırlayıcılar olarak virgüller veya boşluklar kullanılarak birden çok adres belirtilebilir."
 ],
 "Peers": [
  null,
  "Kişiler"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Bununla bağlantı kuran kişiler diğer makinelerdir. Diğer makinelerin ortak anahtarları birbirleriyle paylaşılacaktır."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"Sunucu\" gibi davranan uç noktanın anamakine:b.noktası olarak belirtilmesi gerekir, aksi takdirde boş bırakılabilir."
 ],
 "Add peer": [
  null,
  "Kişi ekle"
 ],
 "Endpoint": [
  null,
  "Uç nokta"
 ],
 "Allowed IPs": [
  null,
  "İzin verilen IP'ler"
 ],
 "No peers added.": [
  null,
  "Eklenen kişiler yok."
 ],
 "Edit VLAN settings": [
  null,
  "VLAN ayarlarını düzenle"
 ],
 "Parent": [
  null,
  "Üst öğe"
 ],
 "VLAN ID": [
  null,
  "VLAN kimliği"
 ],
 "Transmitting": [
  null,
  "Aktarma"
 ],
 "MTU must be a positive number": [
  null,
  "MTU pozitif bir sayı olmak zorundadır"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU değeri"
 ],
 "Set to": [
  null,
  "Şuna ayarla"
 ],
 "Team port settings": [
  null,
  "Takım bağlantı noktası ayarları"
 ],
 "Sticky": [
  null,
  "Yapışkan"
 ],
 "LACP key": [
  null,
  "LACP anahtarı"
 ],
 "Bridge port settings": [
  null,
  "Köprü bağlantı noktası ayarları"
 ],
 "Path cost": [
  null,
  "Yol maliyeti"
 ],
 "Hair pin mode": [
  null,
  "Hair pin kipi"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Uyarlanabilir iletim yükü dengeleme"
 ],
 "Adaptive load balancing": [
  null,
  "Uyarlanabilir yük dengeleme"
 ],
 "MII (recommended)": [
  null,
  "MII (önerilir)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Birleştirme ayarlarını düzenle"
 ],
 "Network bond": [
  null,
  "Ağ birleştirme (bond)"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Bir ağ birleştirmesi (bond), birden çok ağ arayüzünü daha yüksek aktarım hızı veya yedeklilik ile tek bir mantıksal arayüzde birleştirir."
 ],
 "Link monitoring": [
  null,
  "Bağlantı izleme"
 ],
 "Monitoring interval": [
  null,
  "İzleme aralığı"
 ],
 "Monitoring targets": [
  null,
  "İzleme hedefleri"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kaldırmak sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "Remove $0": [
  null,
  "$0'ı kaldır"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 eklemek sunucuyla bağlantıyı kesecek ve yönetim kullanıcı arayüzünü kullanılamaz hale getirecektir."
 ],
 "No interfaces available": [
  null,
  "Mevcut arayüzler yok"
 ],
 "Add member": [
  null,
  "Üye ekle"
 ],
 "Interface members": [
  null,
  "Arayüz üyeleri"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ]
});
