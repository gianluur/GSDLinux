cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Services"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interface"
 ],
 "bridge": [
  null,
  "brug"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "binding"
 ],
 "team": [
  null,
  "team"
 ],
 "port": [
  null,
  "poort"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zone"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Netwerkbindingen beheren"
 ],
 "Managing networking teams": [
  null,
  "Netwerkteams beheren"
 ],
 "Managing networking bridges": [
  null,
  "Netwerkbruggen beheren"
 ],
 "Managing VLANs": [
  null,
  "VLAN's beheren"
 ],
 "Managing firewall": [
  null,
  "Firewall beheren"
 ]
});
