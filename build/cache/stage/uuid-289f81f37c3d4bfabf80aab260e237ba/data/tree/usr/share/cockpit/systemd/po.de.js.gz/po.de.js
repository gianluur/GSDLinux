cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Journal": [
  null,
  "Tagebuch"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Hardware-Informationen"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Light": [
  null,
  "Hell"
 ],
 "Dark": [
  null,
  "Dunkel"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "System": [
  null,
  "System"
 ],
 "Search": [
  null,
  "Suche"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "Trust and add host": [
  null,
  "Host vertrauen und hinzufügen"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Wenn der Fingerabdruck übereinstimmt, klicken Sie 'Vertrauen und Host hinzufügen'. Andernfalls lehnen Sie die Verbindung ab und kontaktieren Sie den Administrator."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Der resultierende Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden. Wenn Sie eine andere Person bitten, die Überprüfung für Sie vorzunehmen, kann diese die Ergebnisse mit einer beliebigen Methode übermitteln."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "Verify fingerprint": [
  null,
  "Fingerabdruck verifizieren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Führen Sie diesen Befehl über ein vertrauenswürdiges Netzwerk oder physisch auf dem entfernten Rechner aus:"
 ],
 "The fingerprint should match:": [
  null,
  "Der Fingerabdruck sollte übereinstimmen:"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "Permission denied": [
  null,
  "Erlaubnis verweigert"
 ],
 "Clear input value": [
  null,
  "Eingabewert löschen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit $0 zu synchronisieren"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "Create $0": [
  null,
  "$0 erstellen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Es stehen keine Methoden zur Verfügung, um Administratorrechte zu erlangen (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "less than a minute ago": [
  null,
  "vor weniger als einer Minute"
 ],
 "in less than a minute": [
  null,
  "in weniger als einer Minute"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Strong password": [
  null,
  "Starkes Passwort"
 ],
 "Acceptable password": [
  null,
  "Annehmbares Passwort"
 ],
 "Weak password": [
  null,
  "Schwaches Passwort"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Hide password": [
  null,
  "Passwort verbergen"
 ],
 "password quality": [
  null,
  "Passwortstärke"
 ],
 "Show confirmation password": [
  null,
  "Bestätigungspasswort anzeigen"
 ],
 "Hide confirmation password": [
  null,
  "Bestätigungspasswort ausblenden"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Removing $0": [
  null,
  "Entferne $0"
 ],
 "Installing $0": [
  null,
  "Installiere $0"
 ],
 "Unknown host: $0": [
  null,
  "Unbekannter Host: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort an."
 ],
 "SSH key login": [
  null,
  "SSH-Schlüssel-Anmeldung"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit hat Fehlercode gemeldet $0"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "Row expansion": [
  null,
  "Zeilenerweiterung"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Error during initialization": [
  null,
  "Fehler während der Initialisierung"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Home": [
  null,
  "Persönlicher Ordner"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Kein Verzeichnis"
 ],
 "All files": [
  null,
  "Alle Dateien"
 ],
 "Recent": [
  null,
  "Zuletzt verwendet"
 ],
 "No recent directories": [
  null,
  "Keine aktuellen Verzeichnisse"
 ],
 "No recent files": [
  null,
  "Keine aktuellen Dateien"
 ],
 "Type to filter": [
  null,
  "Zum Filtern tippen"
 ],
 "File chooser actions": [
  null,
  "Aktionen in der Dateiauswahl"
 ],
 "Open in file browser": [
  null,
  "Im Dateibrowser öffnen"
 ],
 "Hide hidden files": [
  null,
  "Versteckte Dateien ausblenden"
 ],
 "Show hidden files": [
  null,
  "Versteckte Dateien anzeigen"
 ],
 "Filesystem": [
  null,
  "Dateisystem"
 ],
 "Clear filters": [
  null,
  "Filter löschen"
 ],
 "Directory is empty": [
  null,
  "Verzeichnis ist leer"
 ],
 "Directory has no sub-directories": [
  null,
  "Verzeichnis hat keine Unterverzeichnisse"
 ],
 "This directory contains only hidden files": [
  null,
  "Dieses Verzeichnis enthält nur versteckte Dateien"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "Folder": [
  null,
  "Ordner"
 ],
 "File": [
  null,
  "Datei"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Embedded PC": [
  null,
  "Eingebetteter PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Select an option": [
  null,
  "Wählen Sie eine Option aus"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "$0 is not a directory": [
  null,
  "$0 ist kein Verzeichnis"
 ],
 "$0 does not exist": [
  null,
  "$0 existiert nicht"
 ],
 "Font size": [
  null,
  "Schriftgröße"
 ],
 "Decrease by one": [
  null,
  "Um eins verringern"
 ],
 "Increase by one": [
  null,
  "Um eins erhöhen"
 ],
 "Appearance": [
  null,
  "Erscheinungsbild"
 ],
 "Black": [
  null,
  "Schwarz"
 ],
 "White": [
  null,
  "Weiß"
 ],
 "Reset": [
  null,
  "Zurücksetzen"
 ],
 "Unable to open directory": [
  null,
  "Verzeichnis kann nicht geöffnet werden"
 ],
 "Running process prevents directory change": [
  null,
  "Laufender Prozess verhindert Verzeichniswechsel"
 ],
 "Change directory": [
  null,
  "Verzeichnis ändern"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Ein Wechsel des Verzeichnisses hält den laufenden Prozess zwangsweise an. Der Prozess kann vor dem Fortfahren auch manuell im Terminal gestoppt werden."
 ],
 "Terminal not available": [
  null,
  "Terminal nicht verfügbar"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Dieser Browser unterstützt WebGL2 nicht."
 ],
 "unknown": [
  null,
  "unbekannt"
 ],
 "Shutdown": [
  null,
  "Herunterfahren"
 ],
 "running $0": [
  null,
  "$0 wird ausgeführt"
 ],
 "Current boot": [
  null,
  "Aktueller Boot"
 ],
 "Previous boot": [
  null,
  "Vorheriger Bootvorgang"
 ],
 "Last 24 hours": [
  null,
  "Letzte 24 Stunden"
 ],
 "Last 7 days": [
  null,
  "Letzte 7 Tage"
 ],
 "Only emergency": [
  null,
  "Nur Notfall"
 ],
 "Alert and above": [
  null,
  "Alarm und oben"
 ],
 "Critical and above": [
  null,
  "Kritisch und höher"
 ],
 "Error and above": [
  null,
  "Fehler und höher"
 ],
 "Warning and above": [
  null,
  "Warnung und höher"
 ],
 "Notice and above": [
  null,
  "Hinweis und höher"
 ],
 "Info and above": [
  null,
  "Info und höher"
 ],
 "Debug and above": [
  null,
  "Debug und höher"
 ],
 "Toggle filters": [
  null,
  "Filter umschalten"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Identifier": [
  null,
  "Kennung"
 ],
 "Filters": [
  null,
  "Filter"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Resume": [
  null,
  "Fortfahren"
 ],
 "All": [
  null,
  "Alle"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumsangaben sollten im Format JJJJ-MM-TT hh:mm:ss sein. Alternativ werden auch die Begriffe 'yesterday' (gestern), 'today' (heute), 'tomorrow' (morgen) verstanden. 'now' (jetzt) bezieht sich auf die aktuelle Zeit. Es können mit den Vorzeichen '-' oder '+' auch relative Zeiten angegeben werden"
 ],
 "Since": [
  null,
  "Seit"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder nach dem angegebenen Datum liegen."
 ],
 "Until": [
  null,
  "Bis"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder vor dem angegebenen Datum liegen."
 ],
 "Boot": [
  null,
  "Booten"
 ],
 "Show messages from a specific boot.": [
  null,
  "Anzeige der Meldungen eines speziellen Bootvorgangs."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Damit wird eine Übereinstimmung für '_BOOT_ID=' hinzugefügt. Wird nichts angegeben, werden die Protokolle für den aktuellen Bootvorgang angezeigt. Wird die Boot-ID nicht angegeben, werden bei einem positiven Offset die Boote ab dem Anfang des Journals angezeigt, bei einem Offset gleich oder kleiner als Null werden die Boote ab dem Ende des Journals angezeigt. So bedeutet 1 den ersten im Journal gefundenen Boot in chronologischer Reihenfolge, 2 den zweiten usw., während -0 der letzte Boot ist, -1 der vorletzte Boot usw."
 ],
 "Unit": [
  null,
  "Einheit"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Meldungen für die angegebene systemd-Einheit anzeigen."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Dies fügt Übereinstimmungen für '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' und 'UNIT=' hinzu, um alle möglichen Meldungen für die angegebene Einheit zu finden. Kann weitere durch Komma getrennte Einheiten enthalten."
 ],
 "Free-form search": [
  null,
  "Freitext-Suche"
 ],
 "Show messages containing given string.": [
  null,
  "Meldungen mit der angegebenen Zeichenkette anzeigen."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Jede Zeichenkette in den log Nachrichten kann gefiltert werden. Die Zeichenkette kann auch die Form eines herkömmlichen Ausdrucks haben. Filtern nach log Nachrichtenfeldern wird ebenfalls unterstützt. Dies sind durch Leerzeichen getrennte Werte in der Form FELD=WERT, wobei WERT eine durch Kommata getrennte Liste von möglichen Werten sein kann."
 ],
 "journalctl manpage": [
  null,
  "journalctl Manpage"
 ],
 "Successfully copied to clipboard": [
  null,
  "Erfolgreich in die Zwischenablage kopiert"
 ],
 "Create timer": [
  null,
  "Timer erstellen"
 ],
 "Edit timer": [
  null,
  "Timer bearbeiten"
 ],
 "Timer creation failed": [
  null,
  "Timer-Erstellung fehlgeschlagen"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Fehler beim Abrufen der Startbedingungen für den Timer"
 ],
 "Failed to get the timer command": [
  null,
  "Fehler beim Abrufen des Timer-Befehls"
 ],
 "This field cannot be empty": [
  null,
  "Dieses Feld darf nicht leer sein"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Nur Alphabete, Zahlen,:, _,. , @ , - sind erlaubt"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Shell command": [
  null,
  "Shell-Befehl"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Dieser Befehl wird von /bin/sh ausgeführt."
 ],
 "Trigger": [
  null,
  "Auslöser"
 ],
 "At specific time": [
  null,
  "Zu einer bestimmten Zeit"
 ],
 "After system boot": [
  null,
  "Nach dem Systemstart"
 ],
 "Seconds": [
  null,
  "Sekunden"
 ],
 "Minutes": [
  null,
  "Minuten"
 ],
 "Hours": [
  null,
  "Stunde"
 ],
 "Weeks": [
  null,
  "Wochen"
 ],
 "Delay must be a number": [
  null,
  "Verzögerung muss eine Zahl sein"
 ],
 "Repeat": [
  null,
  "Wiederholen"
 ],
 "Don't repeat": [
  null,
  "Nicht wiederholen"
 ],
 "Minutely": [
  null,
  "Minütlich"
 ],
 "Hourly": [
  null,
  "Stündlich"
 ],
 "Daily": [
  null,
  "Täglich"
 ],
 "Weekly": [
  null,
  "Wöchentlich"
 ],
 "Monthly": [
  null,
  "Monatlich"
 ],
 "Yearly": [
  null,
  "Jährlich"
 ],
 "Run at": [
  null,
  "Ausführen um"
 ],
 "At second": [
  null,
  "Bei Sekunde"
 ],
 "At minute": [
  null,
  "Bei Minute"
 ],
 "Run on": [
  null,
  "Ausführen auf"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minute muss eine Zahl zwischen 0 und 59 sein"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunde muss eine Zahl zwischen 0 und 59 sein"
 ],
 "Repeat weekly": [
  null,
  "Wöchentlich wiederholen"
 ],
 "Mondays": [
  null,
  "Montags"
 ],
 "Tuesdays": [
  null,
  "Dienstags"
 ],
 "Wednesdays": [
  null,
  "Mittwochs"
 ],
 "Thursdays": [
  null,
  "Donnerstags"
 ],
 "Fridays": [
  null,
  "Freitags"
 ],
 "Saturdays": [
  null,
  "Samstags"
 ],
 "Sundays": [
  null,
  "Sonntags"
 ],
 "Repeat monthly": [
  null,
  "Monatlich wiederholen"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Unclean shutdown": [
  null,
  "Unsauberes Herunterfahren"
 ],
 "View logs": [
  null,
  "Protokolle ansehen"
 ],
 "Dismiss": [
  null,
  "Abweisen"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Planmäßiges Ausschalten um $0"
 ],
 "Cancel poweroff": [
  null,
  "Herunterfahren abbrechen"
 ],
 "Scheduled reboot at $0": [
  null,
  "Planmäßiger Neustart um $0"
 ],
 "Cancel reboot": [
  null,
  "Neustart abbrechen"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "Set hostname": [
  null,
  "Hostname setzen"
 ],
 "Configuration": [
  null,
  "Konfiguration"
 ],
 "Hostname": [
  null,
  "Hostname"
 ],
 "System time": [
  null,
  "Systemzeit"
 ],
 "Domain": [
  null,
  "Domain"
 ],
 "Performance profile": [
  null,
  "Leistungsprofil"
 ],
 "Secure shell keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Show fingerprints": [
  null,
  "Fingerabdrücke anzeigen"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "Kann SSH-Hostschlüssel nicht anzeigen: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Laden von SSH-Schlüsseln fehlgeschlagen"
 ],
 "Error message": [
  null,
  "Fehlermeldung"
 ],
 "Loading keys...": [
  null,
  "Schlüssel werden geladen ..."
 ],
 "No host keys found.": [
  null,
  "Es wurden keine Host-Schlüssel gefunden."
 ],
 "Machine SSH key fingerprints": [
  null,
  "SSH-Fingerabdrücke auf diesem Rechner"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Der tatsächliche Hostname darf höchstens 64 Zeichen umfassen"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Ein echter Hostname darf nur Kleinbuchstaben, Ziffern, Bindestriche und Punkte enthalten (mit ausgefüllten Unterdomänen)"
 ],
 "Change host name": [
  null,
  "Rechnernamen ändern"
 ],
 "Pretty host name": [
  null,
  "Anzeige-Rechnername"
 ],
 "Real host name": [
  null,
  "Echter Rechnername"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, kryptografische Richtlinien zu ändern"
 ],
 "Cryptographic policy": [
  null,
  "Kryptografische Richtlinie"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Empfohlene, sichere Einstellungen für aktuelle Bedrohungsmodelle."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "STANDARD mit SHA-1 Signatur erlaubt."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Höhere Interoperabilität auf Kosten einer größeren Angriffsfläche."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "ALTLAST mit Active-Directory-Interoperabilität."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Beim Booten im FIPS-Modus nur zugelassene und erlaubte Algorithmen verwenden."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS mit weiteren Einschränkungen der Common Criteria."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Schützt vor kurzfristig zu erwartenden Angriffen auf Kosten der Interoperabilität."
 ],
 "Custom cryptographic policy": [
  null,
  "Benutzerdefinierte kryptografische Richtlinie"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografische Richtlinien sind ein Systembestandteil, der die kryptografischen Kern-Subsysteme konfiguriert. Dabei deckt er das TLS, IPSec, SSH, DNSSec und Kerberos Protokoll ab."
 ],
 "Change cryptographic policy": [
  null,
  "Kryptografische Richtlinie ändern"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Neue Policy wird angewendet... Dies kann ein paar Minuten dauern."
 ],
 "Reapply and reboot": [
  null,
  "Erneut anwenden und neu starten"
 ],
 "Apply and reboot": [
  null,
  "Anwenden und Neustarten"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS wurde nicht richtig aktiviert"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Die kryptografische Richtlinie ist inkonsistent"
 ],
 "Review cryptographic policy": [
  null,
  "Überprüfung der Verschlüsselungsrichtlinie"
 ],
 "System information": [
  null,
  "Systeminformationen"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Asset tag": [
  null,
  "Asset-Tag"
 ],
 "Machine ID": [
  null,
  "Maschinen-ID"
 ],
 "Up since": [
  null,
  "Läuft seit"
 ],
 "View hardware details": [
  null,
  "Hardware-Details anzeigen"
 ],
 "Last successful login:": [
  null,
  "Letzte erfolgreiche Anmeldung:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 fehlgeschlagene Anmeldung",
  "$0 fehlgeschlagene Anmeldungen"
 ],
 "View login history": [
  null,
  "Anmeldeverlauf ansehen"
 ],
 "recommended": [
  null,
  "empfohlen"
 ],
 "inconsistent": [
  null,
  "inkonsistent"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Zum Beitritt einer Domäne wird realmd benötigt"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kann keiner Domäne beitreten, da realmd auf diesem System nicht installiert ist"
 ],
 "Joining this domain is not supported": [
  null,
  "Der Beitritt zu dieser Domain wird nicht unterstützt"
 ],
 "Login format": [
  null,
  "Login format"
 ],
 "Server software": [
  null,
  "Server-Software"
 ],
 "Client software": [
  null,
  "Client software"
 ],
 "Leave domain": [
  null,
  "Domäne verlassen"
 ],
 "Leave $0": [
  null,
  "$0 verlassen"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Nach dem Verlassen der Domain können sich nur noch Nutzer mit lokalen Zugängen an dieser Maschine anmelden. Dies betrifft auch andere Dienste wie z.B. die DNS Auflösungs Einstellungen und die Liste der vertrauenswürdigen CAs könnte sich ändern."
 ],
 "Validating address": [
  null,
  "Validiere Adresse"
 ],
 "Contacted domain": [
  null,
  "Kontaktierte Domain"
 ],
 "Domain could not be contacted": [
  null,
  "Die Domäne konnte nicht kontaktiert werden"
 ],
 "Domain is not supported": [
  null,
  "Domäne wird nicht unterstützt"
 ],
 "Domain address": [
  null,
  "Domänenadressen"
 ],
 "Domain administrator name": [
  null,
  "Name des Domain-Administrators"
 ],
 "Domain administrator password": [
  null,
  "Passwort des Domain-Administrators"
 ],
 "Joining": [
  null,
  "Beitritt"
 ],
 "Join": [
  null,
  "Beitreten"
 ],
 "This may take a while": [
  null,
  "Dies kann eine Weile dauern"
 ],
 "Not permitted to configure realms": [
  null,
  "Keine Berechtigung Realms zu konfigurieren"
 ],
 "Join domain": [
  null,
  "Einer Domain beitreten"
 ],
 "Install realmd support": [
  null,
  "realmd-Unterstützung installieren"
 ],
 "$0 disk is failing": [
  null,
  "$0 Festplatte versagt",
  "$0 Festplatten versagen"
 ],
 "Connected to Insights": [
  null,
  "Mit Insights verbunden"
 ],
 "Not connected to Insights": [
  null,
  "Nicht mit Insights verbunden"
 ],
 "Health": [
  null,
  "Meldungen"
 ],
 "of $0 CPU": [
  null,
  "von $0 CPU",
  "von $0 CPUs"
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "View metrics and history": [
  null,
  "Metriken und Verlauf ansehen"
 ],
 "Tuned is not available": [
  null,
  "Tuned ist nicht verfügbar"
 ],
 "Tuned is not running": [
  null,
  "Tuned läuft nicht"
 ],
 "Tuned is off": [
  null,
  "Tuned ist ausgeschaltet"
 ],
 "This system is using the recommended profile": [
  null,
  "Dieses System benutzt das empfohlene Profil"
 ],
 "This system is using a custom profile": [
  null,
  "Dieses System benutzt ein benutzerdefiniertes Profil"
 ],
 "none": [
  null,
  "kein"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikation mit tuned schlug fehl"
 ],
 "Failed to enable tuned": [
  null,
  "Tuned konnte nicht aktiviert werden"
 ],
 "Failed to disable tuned": [
  null,
  "Fehler beim Deaktivieren"
 ],
 "Failed to disable tuned profile": [
  null,
  "Deaktivierung des tuned-Profils ist fehlgeschlagen"
 ],
 "Failed to switch profile": [
  null,
  "Profil konnte nicht gewechselt werden"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Disable tuned": [
  null,
  "Tuned deaktivieren"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned konnte nicht gestartet werden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned ist ein Dienst, der Ihr System überwacht und die Leistung unter bestimmten Arbeitsbelastungen optimiert. Das Herzstück von Tuned sind Profile, die Ihr System für verschiedene Anwendungsfälle abstimmen."
 ],
 "Change performance profile": [
  null,
  "Leistungsprofil ändern"
 ],
 "Change profile": [
  null,
  "Profil ändern"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd bearbeiten"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Änderungen in /etc/motd konnten nicht gespeichert werden"
 ],
 "Save changes": [
  null,
  "Änderungen speichern"
 ],
 "Edit motd": [
  null,
  "motd bearbeiten"
 ],
 "Stub": [
  null,
  "Kontrollabschnitt"
 ],
 "Not found": [
  null,
  "Nicht gefunden"
 ],
 "Bad setting": [
  null,
  "Falsche Einstellung"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Merged": [
  null,
  "Zusammengeführt"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "Reloading": [
  null,
  "Wird neu geladen"
 ],
 "Not running": [
  null,
  "Läuft nicht"
 ],
 "Failed to start": [
  null,
  "Starten fehlgeschlagen"
 ],
 "Maintenance": [
  null,
  "Wartung"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Linked": [
  null,
  "Verbunden"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Maskiert"
 ],
 "Static": [
  null,
  "Statisch"
 ],
 "Invalid": [
  null,
  "Ungültig"
 ],
 "Indirect": [
  null,
  "Indirekt"
 ],
 "Generated": [
  null,
  "Generiert"
 ],
 "Transient": [
  null,
  "Vorübergehend"
 ],
 "Bad": [
  null,
  "Falsch"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Das Abonnieren von systemd-Signalen ist fehlgeschlagen: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Verbindung zum dbus fehlgeschlagen: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Auflisten der Einheiten fehlgeschlagen: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 Dienst ist fehlerhaft",
  "$0 Dienste sind fehlerhaft"
 ],
 "Loading of units failed": [
  null,
  "Laden der Einheiten fehlgeschlagen"
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "Listing units": [
  null,
  "Auflisten der Einheiten"
 ],
 "Filter by name or description": [
  null,
  "Filtere nach Name oder Beschreibung"
 ],
 "Active state": [
  null,
  "Aktiver Status"
 ],
 "File state": [
  null,
  "Dateistatus"
 ],
 "$0 filters applied": [
  null,
  "$0 Filter angewendet"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, die CPU-Sicherheitsmaßnahmen zu ändern"
 ],
 "Mitigations": [
  null,
  "Milderungen"
 ],
 "Version": [
  null,
  "Version"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS-Version"
 ],
 "BIOS date": [
  null,
  "BIOS-Datum"
 ],
 "CPU security": [
  null,
  "CPU-Sicherheit"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Simultanes Multithreading deaktivieren"
 ],
 "Read more...": [
  null,
  "Mehr lesen..."
 ],
 "Save and reboot": [
  null,
  "Sichern und Neustarten"
 ],
 "CPU security toggles": [
  null,
  "CPU-Sicherheits-Schalter"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarebasierte Umgehungen helfen, CPU-Sicherheitsprobleme zu vermeiden. Diese Abhilfemaßnahmen haben den Nebeneffekt, dass sie die Leistung verringern. Das Ändern dieser Einstellungen erfolgt auf eigene Gefahr."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Speicher-Technologie"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "State": [
  null,
  "Status"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Speed": [
  null,
  "Geschwindigkeit"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zum Ansehen der Speicherinformationen ist ein administrativer Zugriff erforderlich."
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "Failed to fetch logs": [
  null,
  "Protokolle konnten nicht abgerufen werden"
 ],
 "Clear all filters": [
  null,
  "Alle Filter entfernen"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Es konnten keine Protokolleinträge für die aktuellen Filtereinstellungen gefunden werden."
 ],
 "No logs found": [
  null,
  "Keine Protokolle gefunden"
 ],
 "Load earlier entries": [
  null,
  "Frühere Einträge laden"
 ],
 "You may try to load older entries.": [
  null,
  "Wollen sie probieren alte Einträge zu laden."
 ],
 "Allow running (unmask)": [
  null,
  "Ausführung zulassen (unmask)"
 ],
 "Reload": [
  null,
  "Neu Laden"
 ],
 "Restart": [
  null,
  "Neustarten"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Starten Fehlgeschlagen' zurücksetzen"
 ],
 "Mask service": [
  null,
  "Dienst maskieren"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Der Maskierungsdienst verhindert die Ausführung aller abhängigen Einheiten. Dies kann größere Auswirkung haben als vorhergesehen. Bitte bestätigen Sie, dass Sie diese Einheit maskieren wollen."
 ],
 "Disallow running (mask)": [
  null,
  "Verbiete die Ausführung (mask)"
 ],
 "Unpin unit": [
  null,
  "Einheit abstecken"
 ],
 "Pin unit": [
  null,
  "Einheit festlegen"
 ],
 "Additional actions": [
  null,
  "Weitere Aktionen"
 ],
 "Note": [
  null,
  "Hinweis"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Dieses Gerät kann nicht explizit aktiviert werden."
 ],
 "Forbidden from running": [
  null,
  "Ausführen verboten"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Active since ": [
  null,
  "Aktiviert seit "
 ],
 "Required by ": [
  null,
  "Benötigt von "
 ],
 "Read-only": [
  null,
  "Nur lesen"
 ],
 "Requires administration access to edit": [
  null,
  "Benötigt Administrator-Zugriff zum bearbeiten"
 ],
 "Automatically starts": [
  null,
  "Startet automatisch"
 ],
 "Updating status...": [
  null,
  "Update Status..."
 ],
 "Stop and disable": [
  null,
  "Anhalten und deaktivieren"
 ],
 "Start and enable": [
  null,
  "Starten und aktivieren"
 ],
 "Failed to load unit": [
  null,
  "Laden der Einheit fehlgeschlagen"
 ],
 "View all services": [
  null,
  "Alle Dienste ansehen"
 ],
 "Triggers": [
  null,
  "Löst aus"
 ],
 "Triggered by": [
  null,
  "Ausgelöst durch"
 ],
 "Requires": [
  null,
  "Erfordert"
 ],
 "Requisite": [
  null,
  "Requisit"
 ],
 "Wants": [
  null,
  "Will"
 ],
 "Binds to": [
  null,
  "Bindet an"
 ],
 "Part of": [
  null,
  "Teil von"
 ],
 "Required by": [
  null,
  "Benötigt von"
 ],
 "Requisite of": [
  null,
  "Erfordernis von"
 ],
 "Wanted by": [
  null,
  "Gesucht von"
 ],
 "Bound by": [
  null,
  "Gebunden"
 ],
 "Consists of": [
  null,
  "Besteht aus"
 ],
 "Conflicts": [
  null,
  "Konflikte"
 ],
 "Conflicted by": [
  null,
  "Konflikt von"
 ],
 "Before": [
  null,
  "Bevor"
 ],
 "After": [
  null,
  "Nach"
 ],
 "On failure": [
  null,
  "Bei einem Ausfall"
 ],
 "Propagates reload to": [
  null,
  "Propagiert reload to"
 ],
 "Reload propagated from": [
  null,
  "Propagiert von neu laden"
 ],
 "Joins namespace of": [
  null,
  "Tritt dem Namespace Of bei"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Bedingung $0=$1 wurde nicht erfüllt"
 ],
 "Deletion will remove the following files:": [
  null,
  "Beim Löschen werden die folgenden Dateien entfernt:"
 ],
 "Pinned unit": [
  null,
  "Festgelegte Einheit"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Path": [
  null,
  "Pfad"
 ],
 "Listen": [
  null,
  "Lauschen"
 ],
 "Container": [
  null,
  "Container"
 ],
 "View Podman container": [
  null,
  "Podman Container ansehen"
 ],
 "Condition failed": [
  null,
  "Bedingung fehlgeschlagen"
 ],
 "Show more relationships": [
  null,
  "Weitere Beziehungen anzeigen"
 ],
 "Show relationships": [
  null,
  "Beziehungen anzeigen"
 ],
 "Confirm deletion of $0": [
  null,
  "Löschen von $0 bestätigen"
 ],
 "Timer deletion failed": [
  null,
  "Timer-Löschung fehlgeschlagen"
 ],
 "Targets": [
  null,
  "Ziele"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Paths": [
  null,
  "Pfade"
 ],
 "Go to $0": [
  null,
  "Gehe zu $0"
 ],
 "Journal entry not found": [
  null,
  "Journal-Eintrag nicht gefunden"
 ],
 "Journal entry": [
  null,
  "Journal-Eintrag"
 ],
 "Entry at $0": [
  null,
  "Eintrag bei $0"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Loading unit failed": [
  null,
  "Laden der Einheit fehlgeschlagen"
 ],
 "Service logs": [
  null,
  "Serviceprotokolle"
 ],
 "No log entries": [
  null,
  "Keine Protokolleinträge"
 ],
 "Systemd units": [
  null,
  "Systemd Unit"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Keine Ergebnisse entsprechen den Filterkriterien. Löschen Sie alle Filter, um die Ergebnisse anzuzeigen."
 ],
 "Does not automatically start": [
  null,
  "Nicht automatisch starten"
 ],
 "Cannot be enabled": [
  null,
  "Kann nicht aktiviert werden"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Die Webkonsole läuft mit limitierten Berechtigungen."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Dieses Werkzeug konfiguriert das System zum Erzeugen von Kernel Crashdumps. Es unterstützt \"local\" (Festplatte), \"ssh\" und \"nfs\" als Schreibziele."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "von $0 auf $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "von $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "auf $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domäne"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Einer Domäne beitreten"
 ]
});
