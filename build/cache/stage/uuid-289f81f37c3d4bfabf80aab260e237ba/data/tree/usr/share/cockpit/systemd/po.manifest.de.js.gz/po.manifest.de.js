cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Dienste"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "time": [
  null,
  "Zeit"
 ],
 "date": [
  null,
  "Datum"
 ],
 "restart": [
  null,
  "Neustart"
 ],
 "shut": [
  null,
  "schließen"
 ],
 "domain": [
  null,
  "Domain"
 ],
 "machine": [
  null,
  "Maschine"
 ],
 "operating system": [
  null,
  "Betriebssystem"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "Asset-Tag"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "Leistung"
 ],
 "version": [
  null,
  "Version"
 ],
 "host": [
  null,
  "host"
 ],
 "hardware": [
  null,
  "Hardware"
 ],
 "mitigation": [
  null,
  "Milderung"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "Speicher"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "Arbeitsspeicher"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "Seriell"
 ],
 "graphs": [
  null,
  "Kurven"
 ],
 "metrics": [
  null,
  "Metriken"
 ],
 "history": [
  null,
  "Verlauf"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "Datenträger"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "cgroups": [
  null,
  "Cgroups"
 ],
 "performance": [
  null,
  "Leistung"
 ],
 "Configuring system settings": [
  null,
  "Konfiguriere System-Einstellungen"
 ],
 "service": [
  null,
  "Dienst"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "Ziel"
 ],
 "socket": [
  null,
  "Socket"
 ],
 "timer": [
  null,
  "Timer"
 ],
 "path": [
  null,
  "Pfad"
 ],
 "unit": [
  null,
  "Einheit"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "Start"
 ],
 "mask": [
  null,
  "Maske"
 ],
 "unmask": [
  null,
  "Freigeben"
 ],
 "enable": [
  null,
  "aktivieren"
 ],
 "disable": [
  null,
  "deaktivieren"
 ],
 "Managing services": [
  null,
  "Dienste verwalten"
 ],
 "journal": [
  null,
  "Journal"
 ],
 "warning": [
  null,
  "Warnung"
 ],
 "error": [
  null,
  "Fehler"
 ],
 "debug": [
  null,
  "Debug"
 ],
 "crash": [
  null,
  "Absturz"
 ],
 "coredump": [
  null,
  "Coredump"
 ],
 "Reviewing logs": [
  null,
  "Protokolle bewerten"
 ],
 "console": [
  null,
  "Konsole"
 ],
 "command": [
  null,
  "Kommando"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "Shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
