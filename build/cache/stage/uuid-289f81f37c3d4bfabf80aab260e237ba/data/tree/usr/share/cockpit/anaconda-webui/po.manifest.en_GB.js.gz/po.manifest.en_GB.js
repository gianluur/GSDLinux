cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "en_GB",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
