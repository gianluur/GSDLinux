cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Journal": [
  null,
  "Журнал"
 ],
 "Terminal": [
  null,
  "Термінал"
 ],
 "Hardware information": [
  null,
  "Дані щодо обладнання"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "active": [
  null,
  "активний"
 ],
 "Default": [
  null,
  "Типовий"
 ],
 "Light": [
  null,
  "Світлий"
 ],
 "Dark": [
  null,
  "Темний"
 ],
 "Help": [
  null,
  "Довідка"
 ],
 "Select": [
  null,
  "Вибрати"
 ],
 "System": [
  null,
  "Система"
 ],
 "Search": [
  null,
  "Пошук"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "Add": [
  null,
  "Додати"
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "Permission denied": [
  null,
  "Відмовлено у доступі"
 ],
 "Clear input value": [
  null,
  "Вилучити вхідне значення"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "You now have administrative access.": [
  null,
  "Тепер ви маєте адміністративний доступ."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Немає доступних методів отримання адміністративного доступу (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Будь ласка, пройдіть розпізнавання, щоб отримати адміністративний доступ"
 ],
 "Switch to administrative access": [
  null,
  "Перемкнутися на адміністративний доступ"
 ],
 "Authenticate": [
  null,
  "Розпізнавання"
 ],
 "Administrative access": [
  null,
  "Адміністративний доступ"
 ],
 "Problem becoming administrator": [
  null,
  "Проблеми із набуттям прав адміністратора"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Обмежити доступ"
 ],
 "Switch to limited access": [
  null,
  "Перемкнутися на обмежений доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Модель із обмеженим доступом обмежує адміністративні привілеї. Функціональні можливості деяких частин вебконсолі буде суттєво зменшено."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ваш браузер запам'ятовуватиме ваш рівень доступу між сеансами."
 ],
 "Limited access": [
  null,
  "Обмежений доступ"
 ],
 "Turn on administrative access": [
  null,
  "Увімкнути адміністративний доступ"
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "Downloading $0": [
  null,
  "Отримання $0"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit повідомлено про помилку із кодом $0"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Помилка під час ініціалізації"
 ],
 "Failed": [
  null,
  "Не вдалося"
 ],
 "Home": [
  null,
  "Домівка"
 ],
 "Downloads": [
  null,
  "Отримання"
 ],
 "Not a directory": [
  null,
  "Не є каталогом"
 ],
 "All files": [
  null,
  "Усі файли"
 ],
 "Recent": [
  null,
  "Нещодавні"
 ],
 "No recent directories": [
  null,
  "Немає нещодавніх каталогів"
 ],
 "No recent files": [
  null,
  "Немає нещодавніх файлів"
 ],
 "Type to filter": [
  null,
  "Введіть щось для фільтрування"
 ],
 "File chooser actions": [
  null,
  "Дії з вибору файлів"
 ],
 "Open in file browser": [
  null,
  "Відкрити у навігаторі файловою системою"
 ],
 "Hide hidden files": [
  null,
  "Не показувати приховані файли"
 ],
 "Show hidden files": [
  null,
  "Показувати приховані файли"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Clear filters": [
  null,
  "Зняти фільтрування"
 ],
 "Directory is empty": [
  null,
  "Каталог є порожнім"
 ],
 "Directory has no sub-directories": [
  null,
  "У каталозі немає підкаталогів"
 ],
 "This directory contains only hidden files": [
  null,
  "У цьому каталозі зберігаються лише приховані файли"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "Folder": [
  null,
  "Тека"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Unknown": [
  null,
  "Невідомо"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Select an option": [
  null,
  "Виберіть варіант"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "$0 is not a directory": [
  null,
  "$0 не є директорією"
 ],
 "$0 does not exist": [
  null,
  "$0 не існує"
 ],
 "Font size": [
  null,
  "Розмір шрифту"
 ],
 "Decrease by one": [
  null,
  "Зменшити на одиницю"
 ],
 "Increase by one": [
  null,
  "Збільшити на одиницю"
 ],
 "Appearance": [
  null,
  "Вигляд"
 ],
 "Black": [
  null,
  "Чорний"
 ],
 "White": [
  null,
  "Білий"
 ],
 "Reset": [
  null,
  "Скинути"
 ],
 "Unable to open directory": [
  null,
  "Неможливо відкрити каталог"
 ],
 "Running process prevents directory change": [
  null,
  "Процес, що виконується, запобігає зміні каталогу"
 ],
 "Change directory": [
  null,
  "Змінити директорію"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Зміна каталогу призведе до примусової зупинки поточного процесу. Процес також можна зупинити вручну у терміналі перед продовженням."
 ],
 "Terminal not available": [
  null,
  "Немає доступу до термінала"
 ],
 "This browser does not support WebGL2.": [
  null,
  "У цьому браузері не передбачено підтримки WebGL2."
 ],
 "unknown": [
  null,
  "невідомий"
 ],
 "Shutdown": [
  null,
  "Вимкнути"
 ],
 "running $0": [
  null,
  "запущено $0"
 ],
 "Current boot": [
  null,
  "Поточне завантаження"
 ],
 "Previous boot": [
  null,
  "Попереднє завантаження"
 ],
 "Last 24 hours": [
  null,
  "Попередні 24 години"
 ],
 "Last 7 days": [
  null,
  "Попередні 7 днів"
 ],
 "Only emergency": [
  null,
  "Лише критичне"
 ],
 "Alert and above": [
  null,
  "Тривога і вище"
 ],
 "Critical and above": [
  null,
  "Критичні і вище"
 ],
 "Error and above": [
  null,
  "Помилка і вище"
 ],
 "Warning and above": [
  null,
  "Попередження і вище"
 ],
 "Notice and above": [
  null,
  "Зауваження і вище"
 ],
 "Info and above": [
  null,
  "Інформація і вище"
 ],
 "Debug and above": [
  null,
  "Діагностика і вище"
 ],
 "Toggle filters": [
  null,
  "Перемкнути фільтри"
 ],
 "Time": [
  null,
  "Час"
 ],
 "Priority": [
  null,
  "Пріоритетність"
 ],
 "Identifier": [
  null,
  "Ідентифікатор"
 ],
 "Filters": [
  null,
  "Фільтри"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Resume": [
  null,
  "Відновити"
 ],
 "All": [
  null,
  "Всі"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Дату слід вказувати у форматі РРРР-ММ-ДД гг:хх:сс. Крім того, можна використовувати рядки «yesterday» («вчора»), «today» («сьогодні»), «tomorrow» («завтра»). Рядок «now» відповідає поточному моменту часу. Нарешті, можна вказувати відносний час за допомогою префіксів «-» і «+»"
 ],
 "Since": [
  null,
  "З"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Почати показ записів, дата яких є рівною вказаній або новішою за неї."
 ],
 "Until": [
  null,
  "До"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Показати показ записів, дата яких є рівною вказаній або старішою за неї."
 ],
 "Boot": [
  null,
  "Завантаження"
 ],
 "Show messages from a specific boot.": [
  null,
  "Показати повідомлення з вказаного завантаження."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Це додасть відповідність «_BOOT_ID=». Якщо не вказано, буде показано журнал поточного завантаження. Якщо не вказано ідентифікатор завантаження, додатний відступ призводитиме до пошуку завантажень від початку журналу, а нульовий або від'ємний відступ призводитиме до пошуку завантажень починаючи від кінця журналу. Отже, 1 означає перше завантаження, яке буде знайдено у журналі у хронологічному порядку, 2 — друге завантаження тощо; а -0 — останнє завантаження, -1 — завантаження перед останнім тощо."
 ],
 "Unit": [
  null,
  "Модуль"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Показати повідомлення для вказаного модуля systemd."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Це додасть відповідність «_SYSTEMD_UNIT=», «COREDUMP_UNIT=» та «UNIT=» для пошуку усіх можливих повідомлень для вказаного модуля. Запис може містити декілька записів модулів, які слід відокремлювати комами."
 ],
 "Free-form search": [
  null,
  "Пошук із довільним критерієм"
 ],
 "Show messages containing given string.": [
  null,
  "Показати повідомлення, які містять вказаний рядок."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Будь-який текстовий рядок у журналі можна фільтрувати. Рядок може бути також записано у формі формального виразу. Крім того, передбачено підтримку фільтрування за полями повідомлення журналу. Поля слід вказувати у формі відокремлених комами записів ПОЛЕ=ЗНАЧЕННЯ, де значенням є список відокремлених комами можливих значень."
 ],
 "journalctl manpage": [
  null,
  "сторінка підручника з journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Успішно скопійовано до буфера обміну"
 ],
 "Create timer": [
  null,
  "Створити таймер"
 ],
 "Edit timer": [
  null,
  "Змінити таймер"
 ],
 "Timer creation failed": [
  null,
  "Не вдалося створити таймер"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Не вдалося отримати початкові умови для таймера"
 ],
 "Failed to get the timer command": [
  null,
  "Не вдалося отримати команду таймера"
 ],
 "This field cannot be empty": [
  null,
  "Вміст цього поля не може бути порожнім"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Можна використовувати лише літери, цифри, : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Shell command": [
  null,
  "Команда оболонки"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Цю команду буде виконано за допомогою /bin/sh."
 ],
 "Trigger": [
  null,
  "Перемикач"
 ],
 "At specific time": [
  null,
  "У вказаний момент часу"
 ],
 "After system boot": [
  null,
  "Після завантаження системи"
 ],
 "Seconds": [
  null,
  "Секунди"
 ],
 "Minutes": [
  null,
  "Хвилини"
 ],
 "Hours": [
  null,
  "Години"
 ],
 "Weeks": [
  null,
  "Тижні"
 ],
 "Delay must be a number": [
  null,
  "Значенням затримки має бути число"
 ],
 "Repeat": [
  null,
  "Повторення"
 ],
 "Don't repeat": [
  null,
  "Не повторювати"
 ],
 "Minutely": [
  null,
  "За хвилинами"
 ],
 "Hourly": [
  null,
  "Щогодини"
 ],
 "Daily": [
  null,
  "Щодня"
 ],
 "Weekly": [
  null,
  "Щотижня"
 ],
 "Monthly": [
  null,
  "Щомісяця"
 ],
 "Yearly": [
  null,
  "Щорічно"
 ],
 "Run at": [
  null,
  "Запустити"
 ],
 "At second": [
  null,
  "У секунду"
 ],
 "At minute": [
  null,
  "За хвилину"
 ],
 "Run on": [
  null,
  "Запустити на"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Хвилини слід вказувати у форматі числа від 0 до 59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Секунди слід вказувати у форматі числа від 0 до 59"
 ],
 "Repeat weekly": [
  null,
  "Повторювати щотижня"
 ],
 "Mondays": [
  null,
  "Понеділки"
 ],
 "Tuesdays": [
  null,
  "Вівторки"
 ],
 "Wednesdays": [
  null,
  "Середи"
 ],
 "Thursdays": [
  null,
  "Четверги"
 ],
 "Fridays": [
  null,
  "П'ятниці"
 ],
 "Saturdays": [
  null,
  "Суботи"
 ],
 "Sundays": [
  null,
  "Неділі"
 ],
 "Repeat monthly": [
  null,
  "Повторювати щомісяця"
 ],
 "1st": [
  null,
  "1-е"
 ],
 "2nd": [
  null,
  "2-е"
 ],
 "3rd": [
  null,
  "3-є"
 ],
 "4th": [
  null,
  "4-е"
 ],
 "5th": [
  null,
  "5-е"
 ],
 "6th": [
  null,
  "6"
 ],
 "7th": [
  null,
  "7"
 ],
 "8th": [
  null,
  "8"
 ],
 "9th": [
  null,
  "9-е"
 ],
 "10th": [
  null,
  "10-е"
 ],
 "11th": [
  null,
  "11-е"
 ],
 "12th": [
  null,
  "12-е"
 ],
 "13th": [
  null,
  "13-е"
 ],
 "14th": [
  null,
  "14-е"
 ],
 "15th": [
  null,
  "15-е"
 ],
 "16th": [
  null,
  "16-е"
 ],
 "17th": [
  null,
  "17-е"
 ],
 "18th": [
  null,
  "18-е"
 ],
 "19th": [
  null,
  "19-е"
 ],
 "20th": [
  null,
  "20-е"
 ],
 "21th": [
  null,
  "21-е"
 ],
 "22th": [
  null,
  "22-е"
 ],
 "23th": [
  null,
  "23-е"
 ],
 "24th": [
  null,
  "24-е"
 ],
 "25th": [
  null,
  "25-е"
 ],
 "26th": [
  null,
  "26-е"
 ],
 "27th": [
  null,
  "27-е"
 ],
 "28th": [
  null,
  "28-е"
 ],
 "29th": [
  null,
  "29-е"
 ],
 "30th": [
  null,
  "30-е"
 ],
 "31st": [
  null,
  "31-е"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Unclean shutdown": [
  null,
  "Нештатне вимикання"
 ],
 "View logs": [
  null,
  "Переглянути журнали"
 ],
 "Dismiss": [
  null,
  "Відкинути"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Заплановане вимикання о $0"
 ],
 "Cancel poweroff": [
  null,
  "Скасувати вимикання"
 ],
 "Scheduled reboot at $0": [
  null,
  "Заплановане перезавантаження о $0"
 ],
 "Cancel reboot": [
  null,
  "Скасувати перезавантаження"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "Set hostname": [
  null,
  "Встановити назву вузла"
 ],
 "Configuration": [
  null,
  "Налаштування"
 ],
 "Hostname": [
  null,
  "Назва вузла"
 ],
 "System time": [
  null,
  "Системний час"
 ],
 "Domain": [
  null,
  "Домен"
 ],
 "Performance profile": [
  null,
  "Профіль швидкодії"
 ],
 "Secure shell keys": [
  null,
  "Ключі SSH"
 ],
 "Show fingerprints": [
  null,
  "Показати відбитки"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "не вдалося побудувати список ключів SSH вузла: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Не вдалося завантажити ключі SSH"
 ],
 "Error message": [
  null,
  "Повідомлення про помилку"
 ],
 "Loading keys...": [
  null,
  "Завантаження ключів…"
 ],
 "No host keys found.": [
  null,
  "Не знайдено ключів вузлів."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Відбитки ключів SSH комп’ютерів"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Назва справжнього вузла має складатися не більше ніж з 64 символів"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Назва справжнього вузла має складатися лише з літер у нижньому регістрі, цифр, дефісів та точок (із заповненими піддоменами)"
 ],
 "Change host name": [
  null,
  "Змінити назву вузла"
 ],
 "Pretty host name": [
  null,
  "Зручна назва вузла"
 ],
 "Real host name": [
  null,
  "Справжня назва вузла"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Користувачеві $0 заборонено змінювати правила шифрування"
 ],
 "Cryptographic policy": [
  null,
  "Правило шифрування"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Рекомендовано, безпечні параметри для поточних моделей загроз."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT із дозволеною перевіркою підпису SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Ширші можливості взаємодії за рахунок збільшення простору для можливих атак."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY із взаємодією з Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Використовувати лише затверджені і дозволені алгоритми при завантаженні у режимі FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS із подальшими обмеженнями загальних критеріїв."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Захищає від очікуваних у короткостроковій перспективі атак за рахунок звуження можливостей взаємодії."
 ],
 "Custom cryptographic policy": [
  null,
  "Нетипове правило шифрування"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "«Правила шифрування» (Crypto Policies) — компонент системи, який налаштовує криптографічні підсистеми, використовуючи протоколи TLS, IPSec, SSH, DNSSec і Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Змінити правила шифрування"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Застосовуємо нові правила… Застосування може тривати декілька хвилин."
 ],
 "Reapply and reboot": [
  null,
  "Повторно застосувати і перезавантажити"
 ],
 "Apply and reboot": [
  null,
  "Застосувати і перезавантажити"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS не увімкнено належним чином"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Правила шифрування є несумісними"
 ],
 "Review cryptographic policy": [
  null,
  "Переглянути правила шифрування"
 ],
 "System information": [
  null,
  "Інформація про систему"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Asset tag": [
  null,
  "Мітка активу"
 ],
 "Machine ID": [
  null,
  "Ід. комп’ютера"
 ],
 "Up since": [
  null,
  "Працює з"
 ],
 "View hardware details": [
  null,
  "Переглянути параметри обладнання"
 ],
 "Last successful login:": [
  null,
  "Останній вдалий вхід:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 помилкова спроба увійти",
  "$0 помилкових спроби увійти",
  "$0 помилкових спроб увійти"
 ],
 "View login history": [
  null,
  "Переглянути журнал входів"
 ],
 "recommended": [
  null,
  "найліпший"
 ],
 "inconsistent": [
  null,
  "несумісний"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Для долучення до домену слід встановити realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Неможливо долучитися до домену, оскільки у цій системі немає realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Підтримки долучення до цього домену не передбачено"
 ],
 "Login format": [
  null,
  "Формат входу"
 ],
 "Server software": [
  null,
  "Програмне забезпечення сервера"
 ],
 "Client software": [
  null,
  "Клієнтське програмне забезпечення"
 ],
 "Leave domain": [
  null,
  "Полишити домен"
 ],
 "Leave $0": [
  null,
  "Полишити $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Після полишення цього домену лише користувачі із локальними реєстраційними даними зможуть входити до системи на цій машині. Це також може вплинути на роботу інших служб, оскільки можуть змінитися параметри визначення адрес DNS та список довірених служб сертифікації."
 ],
 "Validating address": [
  null,
  "Перевіряємо чинність адреси"
 ],
 "Contacted domain": [
  null,
  "Пов'язаний домен"
 ],
 "Domain could not be contacted": [
  null,
  "Не вдалося встановити зв’язок із доменом"
 ],
 "Domain is not supported": [
  null,
  "Підтримки домену не передбачено"
 ],
 "Domain address": [
  null,
  "Адреса домену"
 ],
 "Domain administrator name": [
  null,
  "Ім’я адміністратора домену"
 ],
 "Domain administrator password": [
  null,
  "Пароль адміністратора домену"
 ],
 "Joining": [
  null,
  "Долучення"
 ],
 "Join": [
  null,
  "З'єднати"
 ],
 "This may take a while": [
  null,
  "Зачекайте"
 ],
 "Not permitted to configure realms": [
  null,
  "Не дозволено налаштовувати області"
 ],
 "Join domain": [
  null,
  "Долучитися до домену"
 ],
 "Install realmd support": [
  null,
  "Встановити підтримку realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 диск виходить з ладу",
  "$0 диски виходять з ладу",
  "$0 дисків виходять з ладу"
 ],
 "Connected to Insights": [
  null,
  "З'єднано з Insights"
 ],
 "Not connected to Insights": [
  null,
  "Не з'єднано із Insights"
 ],
 "Health": [
  null,
  "Здоров'я"
 ],
 "of $0 CPU": [
  null,
  "з $0 процесора",
  "з $0 процесорів",
  "з $0 процесорів"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "View metrics and history": [
  null,
  "Переглянути метрику і журнал"
 ],
 "Tuned is not available": [
  null,
  "Tuned недоступна"
 ],
 "Tuned is not running": [
  null,
  "Tuned не запущено"
 ],
 "Tuned is off": [
  null,
  "Tuned вимкнено"
 ],
 "This system is using the recommended profile": [
  null,
  "Ця система використовує рекомендований профіль"
 ],
 "This system is using a custom profile": [
  null,
  "Ця система використовує нетиповий профіль"
 ],
 "none": [
  null,
  "немає"
 ],
 "Communication with tuned has failed": [
  null,
  "Не вдалося обмінятися даними з tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Не вдалося увімкнути tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Не вдалося вимкнути tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Не вдалося вимкнути профіль tuned"
 ],
 "Failed to switch profile": [
  null,
  "Не вдалося перемкнути профіль"
 ],
 "None": [
  null,
  "Немає"
 ],
 "Disable tuned": [
  null,
  "Вимкнути tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned не вдалося запустити"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned — служба, яка стежить за вашою системою і оптимізує швидкодію за певних умов навантаження. Ядром Tuned є профілі, які налаштовують вашу систему для різних умов користування."
 ],
 "Change performance profile": [
  null,
  "Зміна профілю швидкодії"
 ],
 "Change profile": [
  null,
  "Змінити профіль"
 ],
 "Edit /etc/motd": [
  null,
  "Редагувати /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Не вдалося зберегти зміни до /etc/motd"
 ],
 "Save changes": [
  null,
  "Зберегти зміни"
 ],
 "Edit motd": [
  null,
  "Редагувати motd"
 ],
 "Stub": [
  null,
  "Затичка"
 ],
 "Not found": [
  null,
  "Не знайдено"
 ],
 "Bad setting": [
  null,
  "Помилковий параметр"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Merged": [
  null,
  "Об'єднаний"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "Reloading": [
  null,
  "Перезавантаження"
 ],
 "Not running": [
  null,
  "Зупинено"
 ],
 "Failed to start": [
  null,
  "Не вдалося запустити"
 ],
 "Maintenance": [
  null,
  "Супровід"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Linked": [
  null,
  "Пов'язаний"
 ],
 "Alias": [
  null,
  "Псевдонім"
 ],
 "Masked": [
  null,
  "Замасковано"
 ],
 "Static": [
  null,
  "Статичний"
 ],
 "Invalid": [
  null,
  "Некоректний"
 ],
 "Indirect": [
  null,
  "Опосередкований"
 ],
 "Generated": [
  null,
  "Створений"
 ],
 "Transient": [
  null,
  "Проміжний"
 ],
 "Bad": [
  null,
  "Помилковий"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Не вдалося підписатися на сигнали systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Не вдалося встановити з'єднання із dbus: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Не вдалося вивести список модулів: $0"
 ],
 "$0 service has failed": [
  null,
  "Критична помилка $0 служби",
  "Критична помилка $0 служб",
  "Критична помилка $0 служб"
 ],
 "Loading of units failed": [
  null,
  "Не вдалося завантажити модулі"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Listing units": [
  null,
  "Виведення списку модулів"
 ],
 "Filter by name or description": [
  null,
  "Фільтрувати за назвою або описом"
 ],
 "Active state": [
  null,
  "Активний стан"
 ],
 "File state": [
  null,
  "Стан файла"
 ],
 "$0 filters applied": [
  null,
  "застосовано фільтри $0"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Користувачу $0 заборонено змінювати заходи захисту процесора"
 ],
 "Mitigations": [
  null,
  "Запобіжні заходи"
 ],
 "Version": [
  null,
  "Версія"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Версія BIOS"
 ],
 "BIOS date": [
  null,
  "Дата BIOS"
 ],
 "CPU security": [
  null,
  "Захист процесора"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Вимкнути багатопотоковість"
 ],
 "Read more...": [
  null,
  "Докладніше…"
 ],
 "Save and reboot": [
  null,
  "Зберегти і перезавантажити"
 ],
 "CPU security toggles": [
  null,
  "Перемикачі захисту процесора"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Програмні заходи допомагають усунути проблеми із захистом процесора. Ці заходи мають побіжний ефект — зниження швидкодії. Змінюйте ці параметри, лише якщо повністю усвідомлюєте наслідки."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Клас"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Memory technology": [
  null,
  "Технологія пам'яті"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Rank": [
  null,
  "Ранг"
 ],
 "Speed": [
  null,
  "Швидкість"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Перегляд даних щодо пам'яті потребує адміністративного доступу."
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "Failed to fetch logs": [
  null,
  "Не вдалося отримати журнал"
 ],
 "Clear all filters": [
  null,
  "Зняти усі фільтри"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Не вдалося знайти журналів на основі поточної комбінації фільтрів."
 ],
 "No logs found": [
  null,
  "Журналів не знайдено"
 ],
 "Load earlier entries": [
  null,
  "Завантажити попередні записи"
 ],
 "You may try to load older entries.": [
  null,
  "Ви можете спробувати завантажити старіші записи."
 ],
 "Allow running (unmask)": [
  null,
  "Дозволити запуск (зняти маску)"
 ],
 "Reload": [
  null,
  "Перезавантажити"
 ],
 "Restart": [
  null,
  "Перезапустити"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Clear 'Failed to start'": [
  null,
  "Вилучити «Не вдалося запустити»"
 ],
 "Mask service": [
  null,
  "Замаскувати службу"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Маскування служби забороняє запуск усіх залежних модулів. Це може спричинити значніші наслідки, ніж ви очікуєте. Будь ласка, підтвердьте, що ви хочете замаскувати цей модуль."
 ],
 "Disallow running (mask)": [
  null,
  "Заборонити запуск (замаскувати)"
 ],
 "Unpin unit": [
  null,
  "Відшпилити модуль"
 ],
 "Pin unit": [
  null,
  "Пришпилити модуль"
 ],
 "Additional actions": [
  null,
  "Додаткові дії"
 ],
 "Note": [
  null,
  "Примітка"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Цей модуль не створено для вмикання явним чином."
 ],
 "Forbidden from running": [
  null,
  "Заборонено запускати"
 ],
 "Start service": [
  null,
  "Запустити службу"
 ],
 "Active since ": [
  null,
  "Активний з "
 ],
 "Required by ": [
  null,
  "Потрібен для "
 ],
 "Read-only": [
  null,
  "Лише читання"
 ],
 "Requires administration access to edit": [
  null,
  "Потребує адміністративного доступу для редагування"
 ],
 "Automatically starts": [
  null,
  "Запускати автоматично"
 ],
 "Updating status...": [
  null,
  "Оновлюємо стан…"
 ],
 "Stop and disable": [
  null,
  "Зупинити і вимкнути"
 ],
 "Start and enable": [
  null,
  "Запустити і увімкнути"
 ],
 "Failed to load unit": [
  null,
  "Не вдалося завантажити модуль"
 ],
 "View all services": [
  null,
  "Переглянути усі служби"
 ],
 "Triggers": [
  null,
  "Умовні зміни"
 ],
 "Triggered by": [
  null,
  "Причина вмикання"
 ],
 "Requires": [
  null,
  "Потребує"
 ],
 "Requisite": [
  null,
  "Потрібний"
 ],
 "Wants": [
  null,
  "Бажає"
 ],
 "Binds to": [
  null,
  "Пов'язано з"
 ],
 "Part of": [
  null,
  "Частина"
 ],
 "Required by": [
  null,
  "Потрібен для"
 ],
 "Requisite of": [
  null,
  "Потрібний для"
 ],
 "Wanted by": [
  null,
  "Бажаний для"
 ],
 "Bound by": [
  null,
  "Пов'язано"
 ],
 "Consists of": [
  null,
  "Складається з"
 ],
 "Conflicts": [
  null,
  "Конфліктує"
 ],
 "Conflicted by": [
  null,
  "Конфліктує за"
 ],
 "Before": [
  null,
  "До"
 ],
 "After": [
  null,
  "Після"
 ],
 "On failure": [
  null,
  "Якщо помилка"
 ],
 "Propagates reload to": [
  null,
  "Поширює перезавантаження на"
 ],
 "Reload propagated from": [
  null,
  "Поширене перезавантаження з"
 ],
 "Joins namespace of": [
  null,
  "Долучається до простору назв"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Умову $0=$1 не виконано"
 ],
 "Deletion will remove the following files:": [
  null,
  "У результаті вилучення буде усунено такі файли:"
 ],
 "Pinned unit": [
  null,
  "Пришпилений модуль"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Path": [
  null,
  "Шлях"
 ],
 "Listen": [
  null,
  "Очікувати"
 ],
 "Container": [
  null,
  "Контейнер"
 ],
 "View Podman container": [
  null,
  "Переглянути контейнер Podman"
 ],
 "Condition failed": [
  null,
  "Не виконано умову"
 ],
 "Show more relationships": [
  null,
  "Показати більше зв'язків"
 ],
 "Show relationships": [
  null,
  "Показати зв'язки"
 ],
 "Confirm deletion of $0": [
  null,
  "Підтвердьте вилучення $0"
 ],
 "Timer deletion failed": [
  null,
  "Не вдалося вилучити таймер"
 ],
 "Targets": [
  null,
  "Призначення"
 ],
 "Sockets": [
  null,
  "Сокети"
 ],
 "Timers": [
  null,
  "Таймери"
 ],
 "Paths": [
  null,
  "Шляхи"
 ],
 "Go to $0": [
  null,
  "Перейти до $0"
 ],
 "Journal entry not found": [
  null,
  "Не знайдено запису журналу"
 ],
 "Journal entry": [
  null,
  "Запис журналу"
 ],
 "Entry at $0": [
  null,
  "Запис у $0"
 ],
 "Logs": [
  null,
  "Журнали"
 ],
 "Loading unit failed": [
  null,
  "Не вдалося завантажити модуль"
 ],
 "Service logs": [
  null,
  "Журнали служб"
 ],
 "No log entries": [
  null,
  "Немає записів у журналі"
 ],
 "Systemd units": [
  null,
  "Модулі systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Не знайдено нічого, щоб відповідало критерію фільтрування. Зніміть усі фільтри, щоб переглянути результати."
 ],
 "Does not automatically start": [
  null,
  "Не запускається автоматично"
 ],
 "Cannot be enabled": [
  null,
  "Не може бути увімкнено"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Вебконсоль працює у режимі обмеженого доступу."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "з $0 на $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "з $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "на $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Домен"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Долучитися до домену"
 ]
});
