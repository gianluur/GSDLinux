cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fur",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  ""
 ],
 "$0 ($1)": [
  null,
  ""
 ],
 "$0 installation": [
  null,
  "Instalazion di $0"
 ],
 "$0 installer": [
  null,
  "Instaladôr di $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' al scugne stâ suntun dispositîf formatât come '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  "Informazions"
 ],
 "Account": [
  null,
  "Account"
 ],
 "Add mount": [
  null,
  "Zonte pont di montaç"
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  ""
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Ducj i dispositîfs che a doprin cheste passphrase a vignaran sblocâts"
 ],
 "Anaconda Web UI": [
  null,
  "IU Web di Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Pagjine dal progjet Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Apliche la assegnazion dal pont di montaç e instale"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  ""
 ],
 "Back": [
  null,
  "Indaûr"
 ],
 "Base environment": [
  null,
  "Ambient base"
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Continuant a doprâ chest software, tu capissis e tu acetis i pericui associâts al software di pre-distribuzion, che tu intindis doprâlu dome par finalitâts di prove e di disvilup e che tu desideris segnalâ cualsisei erôr o probleme par podê miorâ chest lavôr."
 ],
 "Cancel": [
  null,
  "Anule"
 ],
 "Change system keyboard layout": [
  null,
  ""
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Lis modifichis fatis achì a varan efiet diret sul sisteme. Nol sarà disponibil nissun 'disfe'."
 ],
 "Checking storage configuration": [
  null,
  "Verifiche de configurazion de memorie di archiviazion"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "Siere"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  ""
 ],
 "Completed": [
  null,
  "Completât"
 ],
 "Configure NTP servers": [
  null,
  "Configure servidôrs NTP"
 ],
 "Configure storage": [
  null,
  "Configure la memorie di archiviazion"
 ],
 "Confirm passphrase": [
  null,
  "Conferme passphrase"
 ],
 "Continue": [
  null,
  "Continue"
 ],
 "Continue installation": [
  null,
  "Continue la instalazion"
 ],
 "Create Account": [
  null,
  "Cree account"
 ],
 "Create account": [
  null,
  "Cree account"
 ],
 "Custom": [
  null,
  "Personalizade"
 ],
 "Date": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  ""
 ],
 "Description": [
  null,
  "Descrizion"
 ],
 "Destination": [
  null,
  "Destinazion"
 ],
 "Detected valid storage layout:": [
  null,
  ""
 ],
 "Device": [
  null,
  "Dispositîf"
 ],
 "Duplicate device.": [
  null,
  "Dispositîfs duplicât."
 ],
 "Duplicate mount point.": [
  null,
  "Pont di montaç duplicât."
 ],
 "Enable root account": [
  null,
  "Abilite l'account di root"
 ],
 "Encrypt my data": [
  null,
  "Cifre i miei dâts"
 ],
 "Encryption": [
  null,
  "Cifradure"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Scancele i dâts e instale"
 ],
 "Error details": [
  null,
  "Detais dal erôr"
 ],
 "Exit to live desktop": [
  null,
  ""
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux al domande almancul $0 di spazi su disc."
 ],
 "Finalization": [
  null,
  "Completament"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Completament: La configurazion dal sisteme e je completade. Il completament de instalazion al pues puartâ vie cualchi moment."
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Non complet"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Il non complet nol pues contignî il caratar doi ponts"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Plate la password confermade"
 ],
 "Hide passphrase": [
  null,
  "Plate la passphrase"
 ],
 "Hide password": [
  null,
  "Plate password"
 ],
 "How would you like to install?": [
  null,
  "Cemût desideristu instalâ?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "",
  ""
 ],
 "I understand that some existing data will be erased": [
  null,
  ""
 ],
 "I understand that some partitions will be modified": [
  null,
  ""
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  ""
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Se tu stâs configurant partizions, chestis a son necessaris:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Se no tu capissis o no tu acetis i pericui, alore par plasê jes di chest program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "In cors"
 ],
 "Initializing...": [
  null,
  "Daûr a inizializâ..."
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Installation failed": [
  null,
  "Instalazion falide"
 ],
 "Installation method": [
  null,
  "Metodi di instalazion"
 ],
 "Installation of the system failed: $0": [
  null,
  "Instalazion dal sisteme falide: $0"
 ],
 "Installation type": [
  null,
  "Gjenar di instalazion"
 ],
 "Installing": [
  null,
  "Daûr a instalâ"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Language": [
  null,
  "Lenghe"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Posizion"
 ],
 "Locked devices": [
  null,
  "Dispositîfs blocâts"
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "Configurazion manuâl dal disc"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configurazion manuâl dal disc: mape dai ponts di montaç"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "Medium": [
  null,
  "Supuart"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Corispondence falide tra la selezion di gnove formatazion dal dispositîf gjenitôr e dal dispositîf fi."
 ],
 "Mount point": [
  null,
  "Pont di montaç"
 ],
 "Mount point assignment": [
  null,
  "Assegnazion ponts di montaç"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "E scugne vê almancul $0 caratars"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "Name": [
  null,
  "Non"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Rêt"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rêt no disponibile. Configure la rêt dal menù te sbare superiôr par segnalâ il probleme."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rêt no disponibile. Configure la rêt par segnalâ il probleme."
 ],
 "Next": [
  null,
  "Indevant"
 ],
 "No devices": [
  null,
  "Nissun dispositîf"
 ],
 "No disks selected": [
  null,
  "Nissun disc selezionât"
 ],
 "No results found": [
  null,
  "Nissun risultât cjatât"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough free space on the selected disks.": [
  null,
  "No vonde spazi libar sui discs selezionâts."
 ],
 "Not enough space on selected disks.": [
  null,
  "No vonde spazi sui discs selezionâts."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Avîs: chest al è un software di pre-distribuzion che al è pensât par finalitâts di disvilup e prove. NO stait a doprâ chest software par un cualsisei lavôr critic o par ambients di produzion."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Sisteme operatîf"
 ],
 "Options": [
  null,
  "Opzions"
 ],
 "Partitions (advanced)": [
  null,
  "Partizions (avanzadis)"
 ],
 "Passphrase": [
  null,
  "Passphrase"
 ],
 "Passphrase did not match any locked device": [
  null,
  "La passphrase no corispuint a nissun dispositîf blocât"
 ],
 "Passphrases must match": [
  null,
  "Lis passphrases a scugnin corispuindi"
 ],
 "Pending": [
  null,
  "In spiete"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Par plasê, zonte il file di regjistri $0 al probleme."
 ],
 "Pool": [
  null,
  "Font comun"
 ],
 "Powered by Anaconda": [
  null,
  "Realizât cun Anaconda"
 ],
 "Pre-release": [
  null,
  "Pre-distribuzion"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Quit": [
  null,
  "Abandone"
 ],
 "Quit installer?": [
  null,
  "Bandonâ l'instaladôr?"
 ],
 "Reading information about the computer failed.": [
  null,
  "Leture des informazions sul computer falide."
 ],
 "Reading installer configuration failed.": [
  null,
  "Leture de configurazion dal instaladôr falide."
 ],
 "Reading installer version information failed.": [
  null,
  "Leture des informazions su la version dal instaladôr falide."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Torne invie"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Reboot system?": [
  null,
  "Tornâ a inviâ il sisteme?"
 ],
 "Recommended": [
  null,
  "Conseât"
 ],
 "Recommended partitions:": [
  null,
  "Partizions racomandadis:"
 ],
 "Reformat": [
  null,
  "Torne formate"
 ],
 "Remove": [
  null,
  "Gjave"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  "Segnale il probleme"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Segnale il probleme"
 ],
 "Required": [
  null,
  "Necessari"
 ],
 "Requirements": [
  null,
  "Recuisîts"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Gnove scansion dai discs falide."
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Torne ae instalazion"
 ],
 "Review and install": [
  null,
  "Revisione e instale"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Root password has been set.": [
  null,
  "La password di root e je stade configurade."
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scansione il codiç QR cul to telefon o visite:"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  ""
 ],
 "Select a device": [
  null,
  "Selezione un dispositîf"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Nol è pussibil tornâ a formatâ il formât '$0' dal dispositîf selezionât."
 ],
 "Send us feedback on your installation": [
  null,
  "Mandinus un parê su la tô instalazion"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Share disk with other operating systems": [
  null,
  ""
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Show confirmed password": [
  null,
  "Mostre la password di conferme"
 ],
 "Show passphrase": [
  null,
  "Mostre passphrase"
 ],
 "Show password": [
  null,
  "Mostre password"
 ],
 "Size": [
  null,
  ""
 ],
 "Software installation": [
  null,
  "Instalazion software"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalazion dal software: configurazion de memorie di archiviazion completade. Cumò il software al ven instalât sul dispositîf."
 ],
 "Software selection": [
  null,
  "Selezion software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  ""
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Memorie di archiviazion"
 ],
 "Storage configuration": [
  null,
  "Configurazion memorie di archiviazion"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configurazion de memorie di archiviazion: la memorie e je in cors di configurazion."
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "La memorie di archiviazion e je basade su la configurazion di 'Modifiche memorie di archiviazion'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage requirements not met": [
  null,
  ""
 ],
 "Strong": [
  null,
  "Fuarte"
 ],
 "Successfully installed": [
  null,
  "Instalât cun sucès"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 sblocât cun sucès."
 ],
 "System": [
  null,
  "Sisteme"
 ],
 "System configuration": [
  null,
  "Configurazion di sisteme"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configurazion dal sisteme: instalazion dal software completade. Cumò il sisteme al ven configurât."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "L'instaladôr nol pues continuâ par vie di un erôr critic."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "L'instaladôr nol pues continuâ par vie di un erôr critic: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "La passphrase furnide e conten caratars che no son ASCII. Al è probabil che no tu podarâs passâ di une disposizion di tastiere a chê altre, cuant che tu le scrivarâs."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This is unstable, pre-release software": [
  null,
  "Chest software al è une pre-distribuzion instabile"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "This may take a moment": [
  null,
  "Chest al podarès tirâle a dilunc"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Par scomençâ a doprâ $0, torne invie il sisteme."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Par continuâ, selezione i dispositîfs dulà lâ a instalâ."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Par doprâ cheste opzion, ridimensione o gjave lis partizions esistentis par liberâ almancul $0 di spazi."
 ],
 "Type": [
  null,
  "Gjenar"
 ],
 "Unable to schedule deletion of $0": [
  null,
  ""
 ],
 "Unable to schedule resizing of $0": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "Sbloche"
 ],
 "Unlock encrypted devices": [
  null,
  "Sbloche i dispositîfs cifrâts"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "User creation": [
  null,
  "Creazion utent"
 ],
 "User name": [
  null,
  "Non utent"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Il non utent al pues contignî dome: letaris de a ae z, numars di 0 a 9, liniute $0, pont $1, liniute basse $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Il non utent nol à di sei une peraule riservade"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "I nons utent a scugnin jessi plui curts di 33 caratars"
 ],
 "Weak": [
  null,
  "Debile"
 ],
 "Welcome": [
  null,
  "Benvignûts"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Benvignûts. Anìn a instalâ $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  ""
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Tu puedis liberâ il spazi necessari achì e lassâ che l'instaladôr al gjestissi il rest opûr configurâ a man lis partizions."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  "I progrès no vignaran salvâts."
 ],
 "completed step": [
  null,
  "passaçs completâts"
 ],
 "current step": [
  null,
  "passaç corint"
 ],
 "edit": [
  null,
  ""
 ],
 "format as $0": [
  null,
  "formate come $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "monte"
 ],
 "pending step": [
  null,
  "passaçs in spiete"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink to $0": [
  null,
  ""
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  ""
 ]
});
