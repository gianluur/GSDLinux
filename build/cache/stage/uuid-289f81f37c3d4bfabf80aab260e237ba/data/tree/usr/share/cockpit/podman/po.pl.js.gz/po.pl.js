cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Usunąć $0?"
 ],
 "Force delete": [
  null,
  "Wymuś usunięcie"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Must be a valid IP address": [
  null,
  "Musi być prawidłowym adresem IP"
 ],
 "1 to 65535": [
  null,
  "1 do 65535"
 ],
 "Container port must not be empty": [
  null,
  "Port kontenera nie może być pusty"
 ],
 "IP address": [
  null,
  "Adres IP"
 ],
 "IP address help": [
  null,
  "Pomoc adresu IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jeśli adres IP hosta jest ustawiony na 0.0.0.0 lub nie jest ustawiony, to port będzie dowiązany do wszystkich adresów IP na hoście."
 ],
 "Host port": [
  null,
  "Port hosta"
 ],
 "Host port help": [
  null,
  "Pomoc portu hosta"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jeśli port hosta nie jest ustawiony, to do portu kontenera będzie losowo przydzielany port na hoście."
 ],
 "Container port": [
  null,
  "Port kontenera"
 ],
 "Protocol": [
  null,
  "Protokół"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Usuń element"
 ],
 "Image name is required": [
  null,
  "Nazwa obrazu jest wymagana"
 ],
 "Image name is not unique": [
  null,
  "Nazwa obrazu nie jest unikalna"
 ],
 "Failed to commit container $0": [
  null,
  "Zatwierdzenie kontenera $0 się nie powiodło"
 ],
 "New image name": [
  null,
  "Nazwa nowego obrazu"
 ],
 "Tag": [
  null,
  "Etykieta"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Przykład, Imię Nazwisko <imięnazwisko@example.com>"
 ],
 "Command": [
  null,
  "Polecenie"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Pause container when creating image": [
  null,
  "Wstrzymaj kontener podczas tworzenia obrazu"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Format Docker jest przydatny podczas udostępniania obrazu za pomocą Dockera lub Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Przestarzały format Docker"
 ],
 "Commit container": [
  null,
  "Zatwierdź kontener"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Utwórz nowy obraz na podstawie obecnego stanu kontenera $0."
 ],
 "Commit": [
  null,
  "Zatwierdź"
 ],
 "Force commit": [
  null,
  "Wymuś zatwierdzenie"
 ],
 "Failed to force remove container $0": [
  null,
  "Wymuszenie usunięcia kontenera $0 się nie powiodło"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Usunięcie uruchomionego kontenera spowoduje usunięcie wszystkich zawartych na nim danych."
 ],
 "Failed to stop container $0": [
  null,
  "Zatrzymanie kontenera $0 się nie powiodło"
 ],
 "Failed to start container $0": [
  null,
  "Uruchomienie kontenera $0 się nie powiodło"
 ],
 "Failed to resume container $0": [
  null,
  "Wznowienie kontenera $0 się nie powiodło"
 ],
 "Failed to pause container $0": [
  null,
  "Wstrzymanie kontenera $0 się nie powiodło"
 ],
 "Failed to restart container $0": [
  null,
  "Ponowne uruchomienie kontenera $0 się nie powiodło"
 ],
 "Rename": [
  null,
  "Zmień nazwę"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Restart": [
  null,
  "Uruchom ponownie"
 ],
 "Force stop": [
  null,
  "Wymuś zatrzymanie"
 ],
 "Force restart": [
  null,
  "Wymuś ponowne uruchomienie"
 ],
 "Pause": [
  null,
  "Wstrzymaj"
 ],
 "Resume": [
  null,
  "Wznów"
 ],
 "Checkpoint": [
  null,
  "Punkt kontrolny"
 ],
 "Start": [
  null,
  "Uruchom"
 ],
 "Restore": [
  null,
  "Przywróć"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Healthy": [
  null,
  "Zdrowy"
 ],
 "Unhealthy": [
  null,
  "Niezdrowy"
 ],
 "Checking health": [
  null,
  "Sprawdzanie zdrowia"
 ],
 "Prune unused containers": [
  null,
  "Wyczyść nieużywane kontenery"
 ],
 "This browser does not support WebGL2.": [
  null,
  ""
 ],
 "View $0 logs": [
  null,
  ""
 ],
 "not available": [
  null,
  "niedostępne"
 ],
 "n/a": [
  null,
  "niedostępne"
 ],
 "$0% of $1 limit": [
  null,
  "$0% z limitu $1"
 ],
 "service": [
  null,
  ""
 ],
 "system": [
  null,
  "systemowa"
 ],
 "user:": [
  null,
  "użytkownik:"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Integration": [
  null,
  "Integracja"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "Console": [
  null,
  "Konsola"
 ],
 "Health check": [
  null,
  "Sprawdzanie zdrowia"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "Memory": [
  null,
  "Pamięć"
 ],
 "Click to see published ports": [
  null,
  "Kliknięcie wyświetli opublikowane porty"
 ],
 "ports": [
  null,
  "porty"
 ],
 "Click to see volumes": [
  null,
  "Kliknięcie wyświetli woluminy"
 ],
 "volumes": [
  null,
  "woluminy"
 ],
 "Container": [
  null,
  "Kontener"
 ],
 "Owner": [
  null,
  "Właściciel"
 ],
 "State": [
  null,
  "Stan"
 ],
 "No containers": [
  null,
  "Brak kontenerów"
 ],
 "No containers in this pod": [
  null,
  "Brak kontenerów w tym pojemniku"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "No containers that match the current filter": [
  null,
  "Żadne kontenery nie pasują do obecnego filtru"
 ],
 "No running containers": [
  null,
  "Brak uruchomionych kontenerów"
 ],
 "Show": [
  null,
  "Wyświetl"
 ],
 "All": [
  null,
  "Wszystko"
 ],
 "Only running": [
  null,
  "Tylko uruchomione"
 ],
 "Create pod": [
  null,
  "Utwórz pojemnik"
 ],
 "Create container": [
  null,
  "Utwórz kontener"
 ],
 "Containers": [
  null,
  "Kontenery"
 ],
 "Create container in pod": [
  null,
  "Utwórz kontener w pojemniku"
 ],
 "Failed to restore container $0": [
  null,
  "Przywrócenie kontenera $0 się nie powiodło"
 ],
 "Restore container $0": [
  null,
  "Przywróć kontener $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Przechowywanie wszystkich tymczasowych plików punktów kontrolnych"
 ],
 "Restore with established TCP connections": [
  null,
  "Przywróć z nawiązanymi połączeniami TCP"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorowanie adresu IP, jeśli jest ustawiony statycznie"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorowanie adresu MAC, jeśli jest ustawiony statycznie"
 ],
 "Pod failed to be created": [
  null,
  "Utworzenie pojemnika się nie powiodło"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Nieprawidłowe znaki. Nazwa może zawierać tylko litery, cyfry i część znaków interpunkcyjnych (_ . -)."
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Pod name": [
  null,
  "Nazwa pojemnika"
 ],
 "System": [
  null,
  "System"
 ],
 "User:": [
  null,
  "Użytkownik:"
 ],
 "No ports exposed": [
  null,
  "Brak eksponowanych portów"
 ],
 "Port mapping": [
  null,
  "Mapowanie portów"
 ],
 "Add port mapping": [
  null,
  "Dodaj mapowanie portów"
 ],
 "No volumes specified": [
  null,
  "Nie podano woluminów"
 ],
 "Volumes": [
  null,
  "Woluminy"
 ],
 "Add volume": [
  null,
  "Dodaj wolumin"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Type to filter…": [
  null,
  "Wyszukiwanie…"
 ],
 "Container path must not be empty": [
  null,
  "Ścieżka do kontenera nie może być pusta"
 ],
 "Host path": [
  null,
  "Ścieżka do hosta"
 ],
 "Container path": [
  null,
  "Ścieżka do kontenera"
 ],
 "Mode": [
  null,
  "Tryb"
 ],
 "Writable": [
  null,
  "Zapisywalny"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Brak etykiety"
 ],
 "Shared": [
  null,
  "Współdzielone"
 ],
 "Private": [
  null,
  "Prywatne"
 ],
 "Read-write access": [
  null,
  "Dostęp do odczytu i zapisu"
 ],
 "Read-only access": [
  null,
  "Dostęp tylko do odczytu"
 ],
 "Show less": [
  null,
  "Wyświetl mniej"
 ],
 "Show more": [
  null,
  "Wyświetl więcej"
 ],
 "Loading details...": [
  null,
  "Wczytywanie szczegółów…"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Environment variables": [
  null,
  "Zmienne środowiskowe"
 ],
 "Failed to download image $0:$1": [
  null,
  "Pobranie obrazu $0:$1 się nie powiodło"
 ],
 "Error message": [
  null,
  "Komunikat o błędzie"
 ],
 "unused": [
  null,
  "nieużywane"
 ],
 "$0 container": [
  null,
  "$0 kontener",
  "$0 kontenery",
  "$0 kontenerów"
 ],
 "History": [
  null,
  "Historia"
 ],
 "Image": [
  null,
  "Obraz"
 ],
 "Created": [
  null,
  "Utworzono"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "Disk space": [
  null,
  "Miejsce na dysku"
 ],
 "Used by": [
  null,
  "Używane przez"
 ],
 "No images": [
  null,
  "Brak obrazów"
 ],
 "No images that match the current filter": [
  null,
  "Żadne obrazy nie pasują do obecnego filtru"
 ],
 "Hide intermediate images": [
  null,
  "Ukryj pośrednie obrazy"
 ],
 "Show intermediate images": [
  null,
  "Wyświetl pośrednie obrazy"
 ],
 "Images": [
  null,
  "Obrazy"
 ],
 "$0 image total, $1": [
  null,
  "$0 obraz, $1",
  "$0 obrazy razem, $1",
  "$0 obrazów razem, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 nieużywany obraz, $1",
  "$0 nieużywane obrazy, $1",
  "$0 nieużywanych obrazów, $1"
 ],
 "Hide images": [
  null,
  "Ukryj obrazy"
 ],
 "Show images": [
  null,
  "Wyświetl obrazy"
 ],
 "Pulling": [
  null,
  "Pobieranie"
 ],
 "Download new image": [
  null,
  "Pobierz nowy obraz"
 ],
 "Prune unused images": [
  null,
  "Wyczyść nieużywane obrazy"
 ],
 "Exited": [
  null,
  "Zakończono"
 ],
 "systemd service": [
  null,
  ""
 ],
 "View $0": [
  null,
  ""
 ],
 "Gateway": [
  null,
  "Brama"
 ],
 "MAC address": [
  null,
  "Adres MAC"
 ],
 "Latest checkpoint": [
  null,
  "Najnowszy punkt kontrolny"
 ],
 "No containers are using this image": [
  null,
  "Żadne kontenery nie używają tego obrazu"
 ],
 "Running": [
  null,
  "Uruchomione"
 ],
 "Loading logs...": [
  null,
  "Wczytywanie dzienników…"
 ],
 "Delete unused system images:": [
  null,
  "Usunięcie nieużywanych obrazów systemowych:"
 ],
 "Failed to prune unused images": [
  null,
  "Wyczyszczenie nieużywanych obrazów się nie powiodło"
 ],
 "Pruning images": [
  null,
  "Czyszczenie obrazów"
 ],
 "Prune": [
  null,
  "Wyczyść"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Punkt kontrolny kontenera $0 się nie powiódł"
 ],
 "Checkpoint container $0": [
  null,
  "Kontener punktu kontrolnego $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Bez wyłączania po zapisaniu punktu kontrolnego na dysku"
 ],
 "Support preserving established TCP connections": [
  null,
  "Obsługa zachowywania nawiązanych połączeń TCP"
 ],
 "Failed to search for new images": [
  null,
  "Wyszukanie nowych obrazów się nie powiodło"
 ],
 "Failed to search for images: $0": [
  null,
  "Wyszukanie obrazów się nie powiodło: $0"
 ],
 "Failed to search for images.": [
  null,
  "Wyszukanie obrazów się nie powiodło."
 ],
 "Search for an image": [
  null,
  "Znajdź obraz"
 ],
 "Search for": [
  null,
  "Szukaj"
 ],
 "Search by name or description": [
  null,
  "Szukaj według nazwy lub opisu"
 ],
 "in": [
  null,
  "w"
 ],
 "All registries": [
  null,
  "Wszystkie rejestry"
 ],
 "Searching...": [
  null,
  "Wyszukiwanie…"
 ],
 "No images found": [
  null,
  "Nie odnaleziono obrazów"
 ],
 "Start typing to look for images.": [
  null,
  "Zacznij pisać, aby wyszukać obrazy."
 ],
 "No results for $0": [
  null,
  "Brak wyników dla zapytania „$0”"
 ],
 "Retry another term.": [
  null,
  "Spróbuj innych słów."
 ],
 "Download": [
  null,
  "Pobierz"
 ],
 "No action": [
  null,
  "Brak działania"
 ],
 "Container failed to be started": [
  null,
  "Uruchomienie kontenera się nie powiodło"
 ],
 "Failed to clean up container": [
  null,
  "Wyczyszczenie kontenera się nie powiodło"
 ],
 "Container failed to be created": [
  null,
  "Utworzenie kontenera się nie powiodło"
 ],
 "downloading": [
  null,
  "pobieranie"
 ],
 "Failed to run container $0": [
  null,
  "Uruchomienie kontenera $0 się nie powiodło"
 ],
 "Failed to create container $0": [
  null,
  "Utworzenie kontenera $0 się nie powiodło"
 ],
 "Failed to pull image $0": [
  null,
  "Pobranie obrazu $0 się nie powiodło"
 ],
 "Local images": [
  null,
  "Lokalne obrazy"
 ],
 "Name already in use": [
  null,
  "Nazwa jest już używana"
 ],
 "Search by registry": [
  null,
  "Szukaj według rejestru"
 ],
 "Local": [
  null,
  "Lokalne"
 ],
 "Container name": [
  null,
  "Nazwa kontenera"
 ],
 "Owner help": [
  null,
  "Pomoc na temat właściciela"
 ],
 "Ideal for running services": [
  null,
  "Doskonałe do uruchamiania usług"
 ],
 "Resource limits can be set": [
  null,
  "Można ustawić ograniczenia zasobów"
 ],
 "Checkpoint and restore support": [
  null,
  "Obsługa punktu kontrolnego i przywracania"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Można mapować porty poniżej 1024"
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "Ideal for development": [
  null,
  "Doskonałe dla programistów"
 ],
 "Restricted by user account permissions": [
  null,
  "Ograniczone przez uprawnienia konta użytkownika"
 ],
 "Image selection help": [
  null,
  "Pomoc przy wyborze obrazu"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "komputer[:port]/[użytkownik]/kontener[:etykieta]"
 ],
 "Example: $0": [
  null,
  "Przykład: $0"
 ],
 "Searching: $0": [
  null,
  "Wyszukiwanie: $0"
 ],
 "Search string or container location": [
  null,
  "Szukaj ciągu lub położenia kontenera"
 ],
 "Pull latest image": [
  null,
  "Pobierz najnowszy obraz"
 ],
 "Entrypoint": [
  null,
  "Punkt wejścia"
 ],
 "With terminal": [
  null,
  "Z terminalem"
 ],
 "Memory limit": [
  null,
  "Ograniczenie pamięci"
 ],
 "Decrease memory": [
  null,
  "Zmniejsz pamięć"
 ],
 "Increase memory": [
  null,
  "Zwiększ pamięć"
 ],
 "Memory unit": [
  null,
  "Jednostka pamięci"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Udziały procesora"
 ],
 "CPU Shares help": [
  null,
  "Pomoc udziałów procesora"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Udziały procesora ustalają priorytety uruchomionych kontenerów. Domyślny priorytet to 1024. Wyższa liczba zwiększa priorytet danego kontenera. Mniejsza liczba zmniejsza priorytet."
 ],
 "Decrease CPU shares": [
  null,
  "Zmniejsz udziały procesora"
 ],
 "Increase CPU shares": [
  null,
  "Zwiększ udziały procesora"
 ],
 "Restart policy": [
  null,
  "Zasada ponownego uruchamiania"
 ],
 "Restart policy help": [
  null,
  "Pomoc zasady ponownego uruchamiania"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Zasada ponownego uruchamiania używana podczas wyłączania kontenerów. Używanie zwlekania do automatycznego uruchamiania kontenerów może nie działać w pewnych warunkach, takich jak podczas używania eCryptfs, systemd-homed, NFS lub uwierzytelniania dwuskładnikowego na koncie użytkownika."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Zasada ponownego uruchamiania używana podczas wyłączania kontenerów."
 ],
 "No": [
  null,
  "Nie"
 ],
 "On failure": [
  null,
  "Przy niepowodzeniu"
 ],
 "Always": [
  null,
  "Zawsze"
 ],
 "Maximum retries": [
  null,
  "Maksymalna liczba ponownych prób"
 ],
 "Decrease maximum retries": [
  null,
  "Zmniejsz maksymalną liczbę ponownych prób"
 ],
 "Increase maximum retries": [
  null,
  "Zwiększ maksymalną liczbę ponownych prób"
 ],
 "No environment variables specified": [
  null,
  "Nie podano zmiennych środowiskowych"
 ],
 "Add variable": [
  null,
  "Dodaj zmienną"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Należy wkleić jeden lub więcej wierszy par klucz=wartość do dowolnego pola, aby zaimportować hurtowo"
 ],
 "Interval": [
  null,
  "Odstęp"
 ],
 "Health check interval help": [
  null,
  "Pomoc odstępów między sprawdzaniem zdrowia"
 ],
 "Interval how often health check is run.": [
  null,
  "Odstęp między wykonywaniem sprawdzania zdrowia."
 ],
 "Decrease interval": [
  null,
  "Zmniejsz odstęp"
 ],
 "Increase interval": [
  null,
  "Zwiększ odstęp"
 ],
 "seconds": [
  null,
  "s"
 ],
 "Timeout": [
  null,
  "Czas oczekiwania"
 ],
 "Health check timeout help": [
  null,
  "Pomoc czasu oczekiwania sprawdzania zdrowia"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Maksymalny dozwolony czas na ukończenie sprawdzania zdrowia, zanim odstęp jest uważany za niepomyślny."
 ],
 "Decrease timeout": [
  null,
  "Zmniejsz czas oczekiwania"
 ],
 "Increase timeout": [
  null,
  "Zwiększ czas oczekiwania"
 ],
 "Start period": [
  null,
  "Okres uruchamiania"
 ],
 "Health check start period help": [
  null,
  "Pomoc okresu uruchamiania sprawdzania zdrowia"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Czas inicjacji wymagany do uruchomienia kontenera."
 ],
 "Decrease start period": [
  null,
  "Zmniejsz okres uruchamiania"
 ],
 "Increase start period": [
  null,
  "Zwiększ okres uruchamiania"
 ],
 "Retries": [
  null,
  "Ponowne próby"
 ],
 "Health check retries help": [
  null,
  "Pomoc ponownych prób sprawdzania zdrowia"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Dozwolona liczba ponownych prób, zanim wynik sprawdzania zdrowia jest uważany za niepomyślny."
 ],
 "Decrease retries": [
  null,
  "Zmniejsz liczbę ponownych prób"
 ],
 "Increase retries": [
  null,
  "Zwiększ liczbę ponownych prób"
 ],
 "When unhealthy": [
  null,
  "Kiedy jest niezdrowy"
 ],
 "Health failure check action help": [
  null,
  "Pomoc działania niepowodzenia sprawdzania zdrowia"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Działanie podejmowane po przejściu kontenera do niezdrowego stanu."
 ],
 "Create container in $0": [
  null,
  "Utwórz kontener w $0"
 ],
 "Create and run": [
  null,
  "Utwórz i uruchom"
 ],
 "Description": [
  null,
  ""
 ],
 "Version": [
  null,
  ""
 ],
 "Links": [
  null,
  ""
 ],
 "Documentation": [
  null,
  ""
 ],
 "Tags": [
  null,
  "Etykiety"
 ],
 "Created by": [
  null,
  "Utworzony przez"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "Comments": [
  null,
  "Komentarze"
 ],
 "Unable to load image history": [
  null,
  "Nie można wczytać historii obrazu"
 ],
 "Key must not be empty": [
  null,
  "Klucz nie może być pusty"
 ],
 "Key": [
  null,
  "Klucz"
 ],
 "Value": [
  null,
  "Wartość"
 ],
 "user": [
  null,
  "użytkownika"
 ],
 "Troubleshoot": [
  null,
  "Rozwiąż problem"
 ],
 "Failed to force remove image $0": [
  null,
  "Wymuszenie usunięcia obrazu $0 się nie powiodło"
 ],
 "intermediate image": [
  null,
  "pośredni obraz"
 ],
 "Failed to remove image $0": [
  null,
  "Usunięcie obrazu $0 się nie powiodło"
 ],
 "intermediate": [
  null,
  "pośredni"
 ],
 "Delete $0 image?": [
  null,
  "Usunąć obraz $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Dla tego obrazu istnieje wiele etykiet. Proszę wybrać oznaczone obrazy do usunięcia."
 ],
 "Delete image": [
  null,
  "Usuń obraz"
 ],
 "Delete tagged images": [
  null,
  "Usuń oznaczone obrazy"
 ],
 "Container is not running": [
  null,
  "Kontener nie jest uruchomiony"
 ],
 "Error occurred while connecting console": [
  null,
  "Wystąpił błąd podczas łączenia konsoli"
 ],
 "Force delete pod $0?": [
  null,
  "Wymusić usunięcie pojemnika $0?"
 ],
 "Delete pod $0?": [
  null,
  "Usunąć pojemnik $0?"
 ],
 "An error occurred": [
  null,
  "Wystąpił błąd"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Pusty pojemnik $0 zostanie trwale usunięty."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Usunięcie tego pojemnika spowoduje usunięcie tych kontenerów:"
 ],
 "Failed to start pod $0": [
  null,
  "Uruchomienie pojemnika $0 się nie powiodło"
 ],
 "Failed to stop pod $0": [
  null,
  "Zatrzymanie pojemnika $0 się nie powiodło"
 ],
 "Failed to restart pod $0": [
  null,
  "Ponowne uruchomienie pojemnika $0 się nie powiodło"
 ],
 "Failed to resume pod $0": [
  null,
  "Wznowienie pojemnika $0 się nie powiodło"
 ],
 "Failed to pause pod $0": [
  null,
  "Wstrzymanie pojemnika $0 się nie powiodło"
 ],
 "Failed to prune unused containers": [
  null,
  "Wyczyszczenie nieużywanych kontenerów się nie powiodło"
 ],
 "Removes selected non-running containers": [
  null,
  "Usuwa zaznaczone nieuruchomione kontenery"
 ],
 "Pruning containers": [
  null,
  "Czyszczenie kontenerów"
 ],
 "Container name is required.": [
  null,
  "Wymagana jest nazwa kontenera."
 ],
 "Failed to rename container $0": [
  null,
  "Zmiana nazwy kontenera $0 się nie powiodła"
 ],
 "New container name": [
  null,
  "Nowa nazwa kontenera"
 ],
 "Rename container $0": [
  null,
  "Zmień nazwę kontenera $0"
 ],
 "Paused": [
  null,
  "Wstrzymane"
 ],
 "Stopped": [
  null,
  "Zatrzymane"
 ],
 "Removing": [
  null,
  "Usuwanie"
 ],
 "Configured": [
  null,
  "Skonfigurowane"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "$0 second": [
  null,
  "$0 sekunda",
  "$0 sekundy",
  "$0 sekund"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Failing streak": [
  null,
  "Wielokrotne niepowodzenia"
 ],
 "Failed to run health check on container $0": [
  null,
  "Wykonanie sprawdzania zdrowia na kontenerze $0 się nie powiodło"
 ],
 "Run health check": [
  null,
  "Wykonaj sprawdzanie zdrowia"
 ],
 "Last 5 runs": [
  null,
  "Ostatnie 5 razy"
 ],
 "Started at": [
  null,
  "Uruchomiono"
 ],
 "Passed health run": [
  null,
  "Pomyślny wynik sprawdzania zdrowia"
 ],
 "Failed health run": [
  null,
  "Niepomyślny wynik sprawdzania zdrowia"
 ],
 "Failed to remove container $0": [
  null,
  "Usunięcie kontenera $0 się nie powiodło"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Usunięcie kontenera spowoduje usunięcie wszystkich zawartych na nim danych."
 ]
});
