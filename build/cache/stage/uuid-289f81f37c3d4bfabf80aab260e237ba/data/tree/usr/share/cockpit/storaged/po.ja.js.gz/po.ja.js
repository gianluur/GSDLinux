cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Server": [
  null,
  "サーバー"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Add key": [
  null,
  "キーの追加"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Select": [
  null,
  "選択"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "Set": [
  null,
  "セット"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Port": [
  null,
  "ポート"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $4 の $3 ファイルに追加されました。"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "Permission denied": [
  null,
  "パーミッションが拒否されました"
 ],
 "Clear input value": [
  null,
  "入力値の消去"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "Create $0": [
  null,
  "$0 を作成"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Method": [
  null,
  "方法"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "less than a minute ago": [
  null,
  "一分以内"
 ],
 "in less than a minute": [
  null,
  "一分以内"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Unknown host: $0": [
  null,
  "不明なホスト: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 鍵認証を使用して $0 にログインできません。パスワードを入力してください。"
 ],
 "SSH key login": [
  null,
  "SSH 鍵ログイン"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit が、エラーコード $0 を報告しました"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "Row expansion": [
  null,
  "行の拡張"
 ],
 "Row select": [
  null,
  "行の選択"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "フィルターのために入力"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "ファイルシステム"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Pizza box": [
  null,
  "ピザ箱"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Select an option": [
  null,
  "オプションの選択"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Save": [
  null,
  "保存"
 ],
 "View logs": [
  null,
  "ログの表示"
 ],
 "Dismiss": [
  null,
  "解除"
 ],
 "edit": [
  null,
  "編集"
 ],
 "Model": [
  null,
  "モデル"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "none": [
  null,
  "なし"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "Not running": [
  null,
  "未実行"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Vendor": [
  null,
  "ベンダー"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "State": [
  null,
  "状態"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Username": [
  null,
  "ユーザー名"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Started": [
  null,
  "開始"
 ],
 "Delete group": [
  null,
  "グループの削除"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Lock": [
  null,
  "ロック"
 ],
 "Use $0": [
  null,
  "$0 を利用"
 ],
 "Service": [
  null,
  "サービス"
 ],
 "Disconnect": [
  null,
  "切断"
 ],
 "Address": [
  null,
  "アドレス"
 ],
 "$0 disk is missing": [
  null,
  "$0 本のディスクがありません"
 ],
 "Location": [
  null,
  "場所"
 ],
 "Compression": [
  null,
  "圧縮"
 ],
 "Storage logs": [
  null,
  "ストレージログ"
 ],
 "Name cannot be empty.": [
  null,
  "名前は空欄にすることができません。"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名前は 127 文字を超えることができません。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名前には文字 '$0' を含めることができません。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名前にはスペースを含めることができません。"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名前は、$0 文字を超えることができません"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名前は、$0 バイトを超えることができません"
 ],
 "$name (from $host)": [
  null,
  "$name ($host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "シン論理ボリューム用プール"
 ],
 "Thin logical volume": [
  null,
  "シン論理ボリューム"
 ],
 "Logical volume (snapshot)": [
  null,
  "論理ボリューム (スナップショット)"
 ],
 "Logical volume": [
  null,
  "論理ボリューム"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID デバイス $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ボリュームグループ $0"
 ],
 "VDO device $0": [
  null,
  "VDO デバイス $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "暗号化された $0 の論理ボリューム"
 ],
 "Encrypted partition of $0": [
  null,
  "暗号化された $0 のパーティション"
 ],
 "Logical volume of $0": [
  null,
  "$0 の論理ボリューム"
 ],
 "Partition of $0": [
  null,
  "$0 のパーティション"
 ],
 "Encrypted $0": [
  null,
  "暗号化された $0"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 の未パーティション領域"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "remove from btrfs volume": [
  null,
  "btrfs ボリュームの削除"
 ],
 "stop": [
  null,
  "停止"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID からの削除"
 ],
 "remove from LVM2": [
  null,
  "LVM2 からの削除"
 ],
 "btrfs device": [
  null,
  "btrfs デバイス"
 ],
 "btrfs volume": [
  null,
  "btrfs ボリューム"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "名前は 255 文字を超えることができません。"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "名前には文字 '/' を含めることができません。"
 ],
 "Create and mount": [
  null,
  "作成およびマウント"
 ],
 "Create only": [
  null,
  "作成のみ"
 ],
 "Create subvolume": [
  null,
  "サブボリュームの作成"
 ],
 "Mount Point": [
  null,
  "マウントポイント"
 ],
 "delete": [
  null,
  "削除"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "サブボリューム $0 を完全に削除しますか？"
 ],
 "Edit mount point": [
  null,
  "マウントポイントの編集"
 ],
 "Unmount": [
  null,
  "アンマウント"
 ],
 "Mount": [
  null,
  "マウント"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "少なくとも1つのサブボリュームをマウントする必要があります"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "最後にマウントされたサブボリュームは削除できません"
 ],
 "btrfs subvolume": [
  null,
  "btrfs サブボリューム"
 ],
 "Snapshot origin": [
  null,
  "スナップショット元"
 ],
 "Mount point": [
  null,
  "マウントポイント"
 ],
 "No subvolumes": [
  null,
  "サブボリュームなし"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs サブボリューム"
 ],
 "Snapshots": [
  null,
  "スナップショット"
 ],
 "No snapshots found": [
  null,
  "スナップショットを見つかりませんでした"
 ],
 "snapshot": [
  null,
  "スナップショット"
 ],
 "$0 is in use": [
  null,
  "$0 は使用されています"
 ],
 "Permanently delete $0?": [
  null,
  "$0 を完全に削除しますか？"
 ],
 "Change label": [
  null,
  "ラベルの変更"
 ],
 "Filesystem is mounted read-only": [
  null,
  "ファイルシステムは読み取り専用でマウントされています"
 ],
 "Label": [
  null,
  "ラベル"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "btrfs devices": [
  null,
  "btrfs デバイス"
 ],
 "No devices found": [
  null,
  "デバイスが見つかりません"
 ],
 "btrfs filesystem": [
  null,
  "btrfs ファイルシステム"
 ],
 "Aborted": [
  null,
  "中断しました"
 ],
 "In progress": [
  null,
  "進行中"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "Degraded": [
  null,
  ""
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Abort test": [
  null,
  ""
 ],
 "Disk is failing": [
  null,
  "ディスクで障害が発生中"
 ],
 "Disk is OK": [
  null,
  "ディスクは OK です"
 ],
 "Assessment": [
  null,
  "評価"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "Self-test status": [
  null,
  "自己テスト状況"
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Media drive": [
  null,
  "メディアドライブ"
 ],
 "Solid State Drive": [
  null,
  "ソリッドステートドライブ"
 ],
 "Hard Disk Drive": [
  null,
  "ハードディスクドライブ"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI ドライブ"
 ],
 "Drive": [
  null,
  "ドライブ"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Firmware version": [
  null,
  "ファームウェアバージョン"
 ],
 "Serial number": [
  null,
  "シリアルナンバー"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "No media inserted": [
  null,
  "メディアが挿入されていません"
 ],
 "Device file": [
  null,
  "デバイスファイル"
 ],
 "Multipathed devices": [
  null,
  "マルチパスデバイス"
 ],
 "Free space": [
  null,
  "空き領域"
 ],
 "Create partition": [
  null,
  "パーティションの作成"
 ],
 "Extended partition": [
  null,
  "拡張パーティション"
 ],
 "$0 partitions": [
  null,
  "$0 パーティション"
 ],
 "Partitions": [
  null,
  "パーティション"
 ],
 "No partitions found": [
  null,
  "パーティションが見つかりません"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "パーティションを削除すると、パーティション内のすべてのデータが削除されます。"
 ],
 "No free space after this partition": [
  null,
  "このパーティションの後に空き領域がありません"
 ],
 "EFI system partition": [
  null,
  "EFI システムパーティション"
 ],
 "BIOS boot partition": [
  null,
  "BIOS ブートパーティション"
 ],
 "Partition": [
  null,
  "パーティション"
 ],
 "Shrink": [
  null,
  "縮小"
 ],
 "Grow": [
  null,
  "増加"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP ブートパーティション"
 ],
 "Linux swap space": [
  null,
  "Linux スワップ領域"
 ],
 "Linux filesystem data": [
  null,
  "Linux ファイルシステムデータ"
 ],
 "Logical Volume Manager partition": [
  null,
  "論理ボリュームマネージャーのパーティション"
 ],
 "Custom": [
  null,
  "カスタム"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "タイプには 16 進文字 (0 から 9、A から F) が 2 つ含まれている必要があります。"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "タイプには、0 から 9、A から F、および \"-\" のみを含めることができます。"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "タイプは、NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN の形式である必要があります。"
 ],
 "Set partition type of $0": [
  null,
  "$0 のパーティションタイプの設定"
 ],
 "Custom type": [
  null,
  "カスタムタイプ"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "パーティションタイプを変更すると、システムが起動しなくなる可能性があります。"
 ],
 "This partition is not completely used by its content.": [
  null,
  "このパーティションは、コンテンツによって完全に使い切られていません。"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "パーティションサイズは $0 です。コンテンツサイズは $1 です。"
 ],
 "Shrink partition": [
  null,
  "パーティションの縮小"
 ],
 "Grow content": [
  null,
  "コンテンツを増やす"
 ],
 "initialize": [
  null,
  "初期化"
 ],
 "Initialize disk $0": [
  null,
  "ディスク $0 を初期化します"
 ],
 "Partitioning": [
  null,
  "パーティション構成"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "すべてのシステムおよびデバイスとの互換性あり (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "最新のシステムとの互換性があり、ハードディスクが 2TB よりも大きい (GPT)"
 ],
 "No partitioning": [
  null,
  "パーティションなし"
 ],
 "Overwrite": [
  null,
  "上書き"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "既存のデータをゼロで上書き (低速)"
 ],
 "Initialize": [
  null,
  "初期化"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初期化すると、ディスク上の全データが削除されます。"
 ],
 "Device is read-only": [
  null,
  "デバイスは読み取り専用です"
 ],
 "Create partition table": [
  null,
  "パーティションテーブルの作成"
 ],
 "Size must be a number": [
  null,
  "サイズは数値である必要があります"
 ],
 "Size cannot be zero": [
  null,
  "サイズはゼロにすることができません"
 ],
 "Size cannot be negative": [
  null,
  "サイズはマイナスにすることができません"
 ],
 "Size is too large": [
  null,
  "サイズが大きすぎます"
 ],
 "Size must be at least $0": [
  null,
  "サイズは $0 以上にする必要があります"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの物理ボリューム"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID デバイスのメンバー"
 ],
 "backing device for VDO device": [
  null,
  "VDO デバイスのバッキングデバイス"
 ],
 "member of Stratis pool": [
  null,
  "Stratis プールのメンバー"
 ],
 "Filesystem outside the target": [
  null,
  "ターゲット外のファイルシステム"
 ],
 "device of btrfs volume": [
  null,
  "btrfs ボリュームのデバイス"
 ],
 "This device is currently in use.": [
  null,
  "このデバイスは現在使用されています。"
 ],
 "Device": [
  null,
  "デバイス"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Services using the location": [
  null,
  "ロケーションを使用するサービス"
 ],
 "Processes using the location": [
  null,
  "ロケーションを使用するプロセス"
 ],
 "Currently in use": [
  null,
  "現在使用中"
 ],
 "(Not part of target)": [
  null,
  "(ターゲットに含まれていません)"
 ],
 "These changes will be made:": [
  null,
  "以下の変更が行われます:"
 ],
 "Action": [
  null,
  "アクション"
 ],
 "Important data might be deleted:": [
  null,
  "重要なデータが削除される可能性があります:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "関連するプロセスとサービスは強制的に停止されます。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "関連するプロセスは強制的に停止されます。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "関連するサービスは強制的に停止されます。"
 ],
 "Checking filesystem usage": [
  null,
  "ファイルシステム利用率を確認中"
 ],
 "$0 used, $1 total": [
  null,
  "利用済 $0、合計 $1"
 ],
 "Device contains unrecognized data": [
  null,
  "デバイスに識別できないデータがある"
 ],
 "Locked encrypted device might contain data": [
  null,
  "ロックされた暗号化デバイスにはデータが含まれている可能性があります"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "このデータが完全に削除されることに同意します"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "マウントポイント $0 は、以下のプロセスにより使用されています:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "マウントポイント $0 は、以下のサービスにより使用されています:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスとサービスは強制的に停止されます。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスは強制的に停止されます。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "一覧表示されたサービスは強制的に停止されます。"
 ],
 "Sorry": [
  null,
  "申し訳ございません"
 ],
 "Usage of $0": [
  null,
  "$0 の使用率"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO プール"
 ],
 "Data used": [
  null,
  "使用済みデータ"
 ],
 "Metadata used": [
  null,
  "使用済みメタデータ"
 ],
 "Use compression": [
  null,
  "圧縮の使用"
 ],
 "Deduplication": [
  null,
  "重複"
 ],
 "Use deduplication": [
  null,
  "重複排除の使用"
 ],
 "Rename volume group": [
  null,
  "ボリュームグループの名前変更"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "削除すると、ボリュームグループのデータがすべて消去されます。"
 ],
 "Create snapshot": [
  null,
  "スナップショットの作成"
 ],
 "Add disks": [
  null,
  "ディスクの追加"
 ],
 "Disks": [
  null,
  "ディスク"
 ],
 "No disks are available.": [
  null,
  "ディスクが利用できません。"
 ],
 "At least one disk is needed.": [
  null,
  "1 つ以上のディスクが必要です。"
 ],
 "Volume group is missing physical volumes": [
  null,
  "ボリュームグループに物理ボリュームがありません"
 ],
 "No free space": [
  null,
  "空き領域なし"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ボリュームグループ"
 ],
 "Add physical volume": [
  null,
  "物理ボリュームの追加"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 論理ボリューム"
 ],
 "Create new logical volume": [
  null,
  "論理ボリュームの新規作成"
 ],
 "No logical volumes": [
  null,
  "論理ボリュームなし"
 ],
 "Remove missing physical volumes?": [
  null,
  "見つからない物理ボリュームを削除しますか?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "このボリュームグループの一部の物理ボリュームがありません。"
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "物理ボリュームが欠落しているボリュームグループの名前は変更できません。"
 ],
 "Physical volumes": [
  null,
  "物理ボリューム"
 ],
 "No physical volumes found": [
  null,
  "物理ボリュームが見つかりません"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 物理ボリューム"
 ],
 "Rename logical volume": [
  null,
  "論理ボリュームの名前変更"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "論理ボリューム $0/$1 を完全に削除しますか?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "論理ボリュームを削除すると、論理ボリューム内のすべてのデータが削除されます。"
 ],
 "Unable to repair logical volume $0": [
  null,
  "論理ボリューム $0 を修復できません"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "修復に使用できる十分な領域がありません。この論理ボリューム用に使用されていない領域が、物理ボリュームに $0 以上必要です。"
 ],
 "An additional $0 must be selected": [
  null,
  "追加の $0 を選択する必要があります"
 ],
 "Repair logical volume $0": [
  null,
  "論理ボリューム $0 の修復"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "論理ボリュームの修復に使用する物理ボリュームを選択します。$0 以上が必要です。"
 ],
 "Physical Volumes": [
  null,
  "物理ボリューム"
 ],
 "Repair": [
  null,
  "修復"
 ],
 "deactivate": [
  null,
  "非アクティブ化"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "論理ボリューム $0/$1 を非アクティブ化しますか?"
 ],
 "Deactivate": [
  null,
  "解除"
 ],
 "Not enough space to grow": [
  null,
  "拡張するのに十分な領域がありません"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 論理ボリューム"
 ],
 "Striped (RAID 0)": [
  null,
  "ストライプ (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "ミラー (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "ストライプおよびミラー (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "専用パリティー (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "分散パリティー (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "ダブル分散パリティー (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "この論理ボリュームは、コンテンツによって完全には使用されていません。"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "ボリュームサイズは $0 です。コンテンツサイズは $1 です。"
 ],
 "Shrink volume": [
  null,
  "ボリュームの縮小"
 ],
 "Layout": [
  null,
  "レイアウト"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失ったため、使用できなくなりました。この論理ボリュームを削除して、代わりに新しいものを作成する必要があります。"
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失いましたが、データはまだ失われていません。元の冗長性を復元するには、この論理ボリュームを修復する必要があります。"
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失いましたが、データはまだ失われていない可能性があります。この論理ボリュームを修復できる可能性があります。"
 ],
 "Stripes": [
  null,
  "ストライプ"
 ],
 "$0 synchronized": [
  null,
  "$0 同期済み"
 ],
 "Create volume group": [
  null,
  "ボリュームグループの作成"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 物理ボリューム"
 ],
 "Last cannot be removed": [
  null,
  "最後のものは削除できません"
 ],
 "Not enough free space": [
  null,
  "十分な空き領域がありません"
 ],
 "Volume group": [
  null,
  "ボリュームグループ"
 ],
 "Create thin volume": [
  null,
  "シンボリュームの作成"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "シンプロビジョニングされた LVM2 論理ボリューム"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "シンプロビジョニングされた論理ボリュームの新規作成"
 ],
 "Not enough space": [
  null,
  "スペースが不足しています"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "シンプロビジョニングされた LVM2 論理ボリューム用プール"
 ],
 "Inactive logical volume": [
  null,
  "非アクティブな論理ボリューム"
 ],
 "Activate": [
  null,
  "有効化"
 ],
 "Unsupported logical volume": [
  null,
  "サポートされていない論理ボリューム"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "内部エラー - この論理ボリュームはアクティブとマークされており、関連付けられたブロックデバイスが必要です。しかし、そのようなブロックデバイスは見つかりません。"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 をインストールすると、$1 が削除されます。"
 ],
 "Installing packages": [
  null,
  "パッケージのインストール"
 ],
 "Block device for filesystems": [
  null,
  "ファイルシステム用ブロックデバイス"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "シンプロビジョニングされたボリューム用プール"
 ],
 "Linear": [
  null,
  "リニア"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ファイルシステムボリューム (圧縮/重複排除)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "データは選択した物理ボリュームに保存されます。冗長性やパフォーマンスの向上はありません。"
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "パフォーマンスを向上させるために、データは複数の選択した物理ボリュームに交互に保存されます。2 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "信頼性を向上させるために、データは複数の選択した物理ボリュームに 2 つ以上のコピーとして保存されます。2 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "信頼性とパフォーマンスを向上させるために、データは 2 つのコピーとして、複数の選択した物理ボリュームに交互に保存されます。4 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "物理ボリュームの 1 つが失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。3 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "物理ボリュームの 1 つが失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。また、パフォーマンスを向上させるために、データは交互に保存されます。3 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "物理ボリュームが同時に 2 つまで失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。また、パフォーマンスを向上させるために、データは交互に保存されます。5 つ以上のボリュームを選択する必要があります。"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "選択したレイアウトには、選択した $0 の物理ボリュームがすべて必要です。"
 ],
 "Create logical volume": [
  null,
  "論理ボリュームの作成"
 ],
 "Purpose": [
  null,
  "目的"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 パッケージがインストールされ、VDO デバイスを作成します。"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 には偶数個の物理ボリュームが必要です"
 ],
 "Logical size": [
  null,
  "論理サイズ"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 で個別のブロックを圧縮して空き領域を節約します"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "同一のデータブロックを 1 回だけ保存することで、空き領域を節約します"
 ],
 "Creating VDO device": [
  null,
  "VDO デバイスの作成"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "この NFS マウントは使用中で、そのオプションだけを変更できます。"
 ],
 "NFS mount": [
  null,
  "NFS マウント"
 ],
 "New NFS mount": [
  null,
  "NFS の新規マウント"
 ],
 "Server address": [
  null,
  "サーバーアドレス"
 ],
 "Server cannot be empty.": [
  null,
  "サーバーは空欄にできません。"
 ],
 "Path on server": [
  null,
  "サーバーのパス"
 ],
 "Path on server cannot be empty.": [
  null,
  "サーバーのパスは空欄にはできません。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "サーバーのパスは \"/\" で開始してください。"
 ],
 "Local mount point": [
  null,
  "ローカルマウントポイント"
 ],
 "Mount point cannot be empty.": [
  null,
  "マウントポイントは空欄にできません。"
 ],
 "Mount point must start with \"/\".": [
  null,
  "マウントポイントは \"/\" で開始してください。"
 ],
 "Mount options": [
  null,
  "マウントオプション"
 ],
 "Mount at boot": [
  null,
  "起動時にマウント"
 ],
 "Mount read only": [
  null,
  "読み取り専用でマウント"
 ],
 "Custom mount options": [
  null,
  "カスタムのマウントオプション"
 ],
 "Unable to unmount filesystem": [
  null,
  "ファイルシステムをアンマウントできません"
 ],
 "Stop and unmount": [
  null,
  "停止してアンマウント"
 ],
 "Unable to remove mount": [
  null,
  "マウントを削除できません"
 ],
 "Stop and remove": [
  null,
  "停止して削除"
 ],
 "(not mounted)": [
  null,
  "(マウントされていません)"
 ],
 "Start multipath": [
  null,
  "マルチパスの開始"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "システムに複数のパスを持つデバイスがありますが、マルチパスサービスが実行されていません。"
 ],
 "Show all $0 rows": [
  null,
  "$0 行をすべて表示"
 ],
 "Category": [
  null,
  "カテゴリー"
 ],
 "more info": [
  null,
  "詳細"
 ],
 "Encryption": [
  null,
  "暗号化"
 ],
 "encrypted": [
  null,
  "暗号化"
 ],
 "Last modified: $0": [
  null,
  "最終更新日: $0"
 ],
 "Stored passphrase": [
  null,
  "保存されたパスフレーズ"
 ],
 "Encryption options": [
  null,
  "暗号化オプション"
 ],
 "Encryption type": [
  null,
  "暗号化タイプ"
 ],
 "Cleartext device": [
  null,
  "cleartext デバイス"
 ],
 "yes": [
  null,
  "はい"
 ],
 "Disk passphrase": [
  null,
  "ディスクのパスフレーズ"
 ],
 "Passphrase cannot be empty": [
  null,
  "パスフレーズは空欄にすることができません"
 ],
 "Unlocking disk": [
  null,
  "ディスクのロック解除"
 ],
 "Checking for $0 package": [
  null,
  "$0 パッケージの確認中"
 ],
 "The $0 package must be installed.": [
  null,
  "$0 パッケージがインストールされている必要があります。"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 パッケージは、あらゆるリポジトリーから利用できません。"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "initrd での NBDE サポートの確認中"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd を再生成する必要があります。"
 ],
 "Regenerating initrd": [
  null,
  "initrd の再生成"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "カーネルコマンドラインへの rd.neednet=1 の追加"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "ファイルシステムオプションへの \"$0\" の追加"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "暗号化オプションへの \"$0\" の追加"
 ],
 "Enabling $0": [
  null,
  "$0 の有効化"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "ネットワークバウンドディスクの暗号化追加"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "現在、このシステムは Tang 鍵サーバーを使用したルートファイルシステムのロック解除をサポートしていません。"
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "現在、このシステムでは、起動時に Tang 鍵サーバーを使用したファイルシステムのロック解除をサポートしていません。"
 ],
 "These additional steps are necessary:": [
  null,
  "以下の追加手順が必要です:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "新しいパスフレーズの保存には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Fix NBDE support": [
  null,
  "NBDE サポートの修正"
 ],
 "Adding key": [
  null,
  "キーの追加"
 ],
 "Key source": [
  null,
  "キーソース"
 ],
 "Repeat passphrase": [
  null,
  "パスフレーズの繰り返し"
 ],
 "Passphrase": [
  null,
  "パスフレーズ"
 ],
 "Tang keyserver": [
  null,
  "Tang キーサーバー"
 ],
 "New passphrase": [
  null,
  "新しいパスフレーズ"
 ],
 "Passphrases do not match": [
  null,
  "パスフレーズが一致しません"
 ],
 "Keyserver address": [
  null,
  "キーサーバーのアドレス"
 ],
 "Change passphrase": [
  null,
  "パスフレーズの変更"
 ],
 "Old passphrase": [
  null,
  "古いパスフレーズ"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang キーサーバーを編集する"
 ],
 "Verify key": [
  null,
  "キーを検証します"
 ],
 "Trust key": [
  null,
  "キーを信頼します"
 ],
 "Passphrase can not be empty": [
  null,
  "パスフレーズは空欄にすることはできません"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "パスフレーズの削除で、$0 のロック解除ができない可能性があります。"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "代替のパスフレーズで削除を確認"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "別のパスフレーズの確認なしでパスフレーズを削除すると、その他のパスフレーズを忘れたり、紛失した場合に、アンロックやキー管理ができなくなることがあります。"
 ],
 "Passphrase from any other key slot": [
  null,
  "その他のキースロットのパスフレーズ"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "キースロットのパスフレーズ $0 を削除しますか？"
 ],
 "Remove $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang キーサーバーを削除しますか？"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "現在ログイン中のユーザーは、キーに関する情報を見ることを許可されていません。"
 ],
 "No keys added": [
  null,
  "追加されたキーはありません"
 ],
 "Slot $0": [
  null,
  "スロット $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "キーの編集にはフリースロットが必要です"
 ],
 "The last key slot can not be removed": [
  null,
  "最後のキースロットは削除できません"
 ],
 "Keyserver": [
  null,
  "キーサーバー"
 ],
 "Unknown type": [
  null,
  "不明なタイプ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "タイプ不明のキースロットは、ここでは編集できません"
 ],
 "Keys": [
  null,
  "キー"
 ],
 "$0 slot remains": [
  null,
  "$0 スロットが残ります"
 ],
 "No available slots": [
  null,
  "利用可能なスロットはありません"
 ],
 "No free key slots": [
  null,
  "フリーのキースロットはありません"
 ],
 "Locked data": [
  null,
  "ロックされたデータ"
 ],
 "lock": [
  null,
  "ロック"
 ],
 "Lock $0?": [
  null,
  "$0 をロックします？"
 ],
 "Address cannot be empty": [
  null,
  "アドレスは空欄にできません"
 ],
 "Address is not a valid URL": [
  null,
  "アドレスの URL は有効ではありません"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "キーハッシュを Tang サーバーで確認します。"
 ],
 "How to check": [
  null,
  "チェック方法"
 ],
 "In a terminal, run: ": [
  null,
  "ターミナルで以下を実行します: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "クリップボードにコピーしました!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "そのコマンドの SHA-256 または SHA-1 が、このダイアログに一致するかどうかを確認します。"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "$1 の btrfs サブボリューム $0"
 ],
 "Mount point cannot be empty": [
  null,
  "マウントポイントは空欄にできません"
 ],
 "Mount point is already used for $0": [
  null,
  "マウントポイントはすでに $0 で使用しています"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "このマウントポイントの下にはファイルシステムがマウント済みです。"
 ],
 "Please unmount them first.": [
  null,
  "先にアンマウントしてください。"
 ],
 "read only": [
  null,
  "読み取り専用"
 ],
 "never mount at boot": [
  null,
  "起動時にマウントしない"
 ],
 "after network": [
  null,
  "ネットワークの後"
 ],
 "ignore failure": [
  null,
  "失敗を無視"
 ],
 "stop boot on failure": [
  null,
  "失敗時にブートを停止"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "ファイルシステムにマウントポイントが割り当てられていません。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ファイルシステムには永続的なマウントポイントがありません。"
 ],
 "The filesystem is not mounted.": [
  null,
  "ファイルシステムはマウントされていません。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ファイルシステムはロック解除され、次回の起動時にマウントされます。パスフレーズの入力が必要になる場合があります。"
 ],
 "(no assigned mount point)": [
  null,
  "(マウントポイントが割り当てられていません)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート時に $1 にマウントされます。"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "起動時に自動的に $0 にマウントします"
 ],
 "Mount on $0 now": [
  null,
  "$0 に今すぐマウントします"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ファイルシステムは現在マウントされていませんが、次回のブート時にマウントされます。"
 ],
 "Do not mount automatically on boot": [
  null,
  "起動時に自動的にマウントしない"
 ],
 "Mount now": [
  null,
  "今すぐマウントします"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在マウントされていますが、次回のブート後はマウントされません。"
 ],
 "Mount also automatically on boot": [
  null,
  "起動時に自動的にもマウントします"
 ],
 "Unmount now": [
  null,
  "今すぐアンマウントします"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート後はマウントされません。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ファイルシステムは起動時に自動的にマウントされるように設定されていますが、その暗号化コンテナーはその時点ではアンロックされません。"
 ],
 "Unlock automatically on boot": [
  null,
  "システムの起動時に自動ロック解除"
 ],
 "Inconsistent filesystem mount": [
  null,
  "一貫性のないシステムマウント"
 ],
 "$0 filesystem": [
  null,
  "$0 ファイルシステム"
 ],
 "Filesystem name": [
  null,
  "ファイルシステム名"
 ],
 "Filesystem is locked": [
  null,
  "ファイルシステムがロックされています"
 ],
 "Mounts before services start": [
  null,
  "サービス起動前にマウントします"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "/var などの重要なマウントに適しています"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "ファイルシステムがマウントされず、リモートアクセスができないと、起動に失敗します"
 ],
 "Mounts in parallel with services": [
  null,
  "サービスと並行してマウントします"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "ファイルシステムがマウントされなくても、起動は成功します"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "サービスと並行してマウントしますが、ネットワークが利用可能になった後にマウントします"
 ],
 "Does not mount during boot": [
  null,
  "起動時にマウントしません"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "オプションのマウントや対話が必要なマウント (パスフレーズなど) に役立ちます"
 ],
 "At boot": [
  null,
  "起動時"
 ],
 "Mount before services start": [
  null,
  "サービス起動前にマウントします"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "待機せずにマウントし、失敗を無視します"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "ネットワークが利用可能になった後にマウントし、失敗を無視します"
 ],
 "Do not mount": [
  null,
  "マウントしない"
 ],
 "This device can not be used for the installation target.": [
  null,
  "このデバイスはインストール対象として使用できません。"
 ],
 "Mount filesystem": [
  null,
  "ファイルシステムをマウントします"
 ],
 "Unmount filesystem $0": [
  null,
  "ファイルシステム $0 のアンマウント"
 ],
 "Mount configuration": [
  null,
  "マウント設定"
 ],
 "Swap": [
  null,
  "スワップ"
 ],
 "Used": [
  null,
  "使用済み"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "暗号化 Stratis プールのロック解除"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "このブロックデバイス上のプールのパスフレーズを指定します:"
 ],
 "Stratis pool": [
  null,
  "Stratis プール"
 ],
 "stopped": [
  null,
  "停止中"
 ],
 "Block devices": [
  null,
  "ブロックデバイス"
 ],
 "No block devices found": [
  null,
  "ブロックデバイスが見つかりません"
 ],
 "Stratis block devices": [
  null,
  "Stratis ブロックデバイス"
 ],
 "Stratis block device": [
  null,
  "Stratis ブロックデバイス"
 ],
 "data": [
  null,
  "データ"
 ],
 "cache": [
  null,
  "キャッシュ"
 ],
 "Pool passphrase": [
  null,
  "プールパスフレーズ"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  ""
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  ""
 ],
 "Create filesystem": [
  null,
  "ファイルシステムの作成"
 ],
 "Stratis filesystem": [
  null,
  "Stratis ファイルシステム"
 ],
 "Set initial size": [
  null,
  "初期サイズ設定"
 ],
 "Limit size": [
  null,
  "サイズ制限"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis プールを削除すると、Stratis プールに含まれるデータがすべて消去されます。"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis プールの名前変更"
 ],
 "Add block devices": [
  null,
  "ブロックデバイスの追加"
 ],
 "Tier": [
  null,
  "階層"
 ],
 "Data": [
  null,
  "データ"
 ],
 "Cache": [
  null,
  "キャッシュ"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "ブロックデバイスを追加するには、プールのアンロックが必要です。"
 ],
 "Encrypted Stratis pool": [
  null,
  "暗号化された Stratis プール"
 ],
 "Delete pool": [
  null,
  "プールの削除"
 ],
 "Stratis filesystems": [
  null,
  "Stratis ファイルシステム"
 ],
 "Create new filesystem": [
  null,
  "ファイルシステムの新規作成"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "このプールは、プールのブロックデバイスにある領域をすべて使用していません。"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "プールの作成後に、このプールのブロックデバイスでサイズが増大したものがあります。このプールを安全に拡張するには新たに利用可能な領域を使用してください。"
 ],
 "Grow the pool to take all space": [
  null,
  "すべての領域を使用してプールを拡大する"
 ],
 "This pool is in a degraded state.": [
  null,
  "このプールは、degraded の状態にあります。"
 ],
 "No filesystems": [
  null,
  "ファイルシステムがありません"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis ファイルシステムプール"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "このパスフレーズは、プールのロックを解除するための唯一の手段であるため、削除できません。"
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "このキーサーバーは、プールのロック解除する唯一の手段であるため、削除できません。"
 ],
 "Add passphrase": [
  null,
  "パスフレーズの追加"
 ],
 "Add keyserver": [
  null,
  "キーサーバーの追加"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  ""
 ],
 "Confirm": [
  null,
  "確認"
 ],
 "Remove passphrase?": [
  null,
  "パスフレーズを削除しますか?"
 ],
 "Add Tang keyserver": [
  null,
  "Tang キーサーバーの追加"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "キーサーバーを追加するには、プールのロック解除が必要です。"
 ],
 "Remove Clevis token?": [
  null,
  "Clevisトークンを削除しますか?"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  ""
 ],
 "Overprovisioning": [
  null,
  "オーバープロビジョニング"
 ],
 "Allow overprovisioning": [
  null,
  "オーバー プロビジョンを許可"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "仮想ファイルシステムのサイズがプールよりも大きくなっています。オーバー プロビジョニングを無効にすることはできません。"
 ],
 "Allocated": [
  null,
  "割り当て済み"
 ],
 "Name can not be empty.": [
  null,
  "名前は空欄にできません。"
 ],
 "A pool with this name exists already.": [
  null,
  "この名前を持つプールはすでに存在します。"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "この名前のファイルシステムは、すでにこのプールに存在します。"
 ],
 "Create Stratis pool": [
  null,
  "Stratis プールの作成"
 ],
 "No block devices are available.": [
  null,
  "ブロックデバイスは利用できません。"
 ],
 "At least one block device is needed.": [
  null,
  "1 つ以上のブロックデバイスが必要です。"
 ],
 "Encrypt data with a passphrase": [
  null,
  "パスフレーズでデータを暗号化する"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Tang キーサーバーでデータを暗号化する"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ファイルシステム $0 のスナップショットの作成"
 ],
 "Create snapshot and mount": [
  null,
  "スナップショットの作成およびマウント"
 ],
 "Create snapshot only": [
  null,
  "スナップショットの作成のみ"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ファイルシステムを削除すると、そのファイルシステム内のすべてのデータが削除されます。"
 ],
 "Snapshot": [
  null,
  "スナップショット"
 ],
 "Rename filesystem": [
  null,
  "ファイルシステムの名前変更"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "仮想ファイルシステムのサイズを制限します"
 ],
 "Limit virtual filesystem size": [
  null,
  "仮想ファイルシステムのサイズ制限"
 ],
 "Virtual size limit": [
  null,
  "仮想サイズ制限"
 ],
 "Virtual size": [
  null,
  "仮想サイズ"
 ],
 "Create RAID device": [
  null,
  "RAID デバイスの作成"
 ],
 "RAID level": [
  null,
  "RAID レベル"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (ストライプ)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (ミラー)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (専用パリティー)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (分散パリティー)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ダブル分散パリティー)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (ミラーのストライプ)"
 ],
 "Chunk size": [
  null,
  "チャンクサイズ"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "少なくとも $0 個のディスクが必要です。"
 ],
 "MDRAID disk": [
  null,
  "MDRAID ディスク"
 ],
 "In sync": [
  null,
  "同期"
 ],
 "Spare": [
  null,
  "スペア"
 ],
 "Recovering": [
  null,
  "復旧"
 ],
 "Write-mostly": [
  null,
  "多くは書き込み"
 ],
 "Blocked": [
  null,
  "ブロック済み"
 ],
 "Unknown ($0)": [
  null,
  "不明な ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID デバイスが実行中である必要があります"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID デバイスが復旧中です"
 ],
 "Need a spare disk": [
  null,
  "スペアディスクが必要です"
 ],
 "Last disk can not be removed": [
  null,
  "最後のディスクは削除できません"
 ],
 "MDRAID device": [
  null,
  "MDRAID デバイス"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 の停止を確定する"
 ],
 "Stop device": [
  null,
  "デバイスの停止"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "削除すると、MDRAID デバイスのデータがすべて消去されます。"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID デバイスが実行中である必要があります"
 ],
 "Add disk": [
  null,
  "ディスクの追加"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 ディスク"
 ],
 "$0 chunk size": [
  null,
  "$0 チャンクサイズ"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID デバイスがデグレード状態です"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "この MDRAID デバイスには write-intent ビットマップがありません。このビットマップを使用すると、同期時間を大幅に短縮できます。"
 ],
 "Add a bitmap": [
  null,
  "bitmap の追加"
 ],
 "No disks found": [
  null,
  "ディスクが見つかりません"
 ],
 "MDRAID disks": [
  null,
  "MDRAID ディスク"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "削除すると、VDO デバイスのデータがすべて消去されます。"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "この VDO デバイスの作成は終了していないため、使用できません。"
 ],
 "Remove device": [
  null,
  "デバイスの削除"
 ],
 "Grow to take all space": [
  null,
  "すべての領域を使用して増加"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "この VDO デバイスは、そのバッキングデバイスをすべて使用していません。"
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1 のうち $0 だけが使用されています。"
 ],
 "Grow logical size of $0": [
  null,
  "$0 の論理サイズを増加"
 ],
 "Physical": [
  null,
  "物理"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 データ + $1 オーバーヘッドが $2 ($3) を使用しています"
 ],
 "Logical": [
  null,
  "論理"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 が $1 ($2 が保存) を使用しています"
 ],
 "Index memory": [
  null,
  "インデックスメモリー"
 ],
 "SMART self-test of $target": [
  null,
  "$target の SMART 自己テスト"
 ],
 "Ejecting $target": [
  null,
  "$target の取り出し中"
 ],
 "Unlocking $target": [
  null,
  "$target をロック解除中"
 ],
 "Locking $target": [
  null,
  "$target のロック中"
 ],
 "Modifying $target": [
  null,
  "$target の変更"
 ],
 "Resizing $target": [
  null,
  "$target のサイズ変更"
 ],
 "Starting swapspace $target": [
  null,
  "スワップ領域 $target の起動"
 ],
 "Stopping swapspace $target": [
  null,
  "スワップ領域 $target の停止"
 ],
 "Mounting $target": [
  null,
  "$target のマウント"
 ],
 "Unmounting $target": [
  null,
  "$target のアンマウント中"
 ],
 "Checking $target": [
  null,
  "$target の確認中"
 ],
 "Repairing $target": [
  null,
  "$target の修復"
 ],
 "Erasing $target": [
  null,
  "$target の削除中"
 ],
 "Creating filesystem on $target": [
  null,
  "$target 上でのファイルシステムの作成"
 ],
 "Setting up loop device $target": [
  null,
  "ループデバイス $target の設定"
 ],
 "Deleting $target": [
  null,
  "$target の削除中"
 ],
 "Creating partition $target": [
  null,
  "パーティション $target の作成"
 ],
 "Cleaning up for $target": [
  null,
  "$target のクリーンアップ中"
 ],
 "Securely erasing $target": [
  null,
  "$target を安全に削除"
 ],
 "Very securely erasing $target": [
  null,
  "$target を非常に安全に削除"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID デバイス $target の停止"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID $target デバイスの起動"
 ],
 "Marking $target as faulty": [
  null,
  "$target を問題があるものとしてマークする"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target を MDRAID デバイスから削除"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID デバイス $target の作成"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID デバイス $target の確認"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID デバイス $target の確認および修復"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID デバイス $target の復旧"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID デバイス $target の同期"
 ],
 "Activating $target": [
  null,
  "$target のアクティベート"
 ],
 "Deactivating $target": [
  null,
  "$target の非アクティブ化"
 ],
 "Creating snapshot of $target": [
  null,
  "$target のスナップショットの作成"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の作成"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の削除"
 ],
 "Adding physical volume to $target": [
  null,
  "$target への物理ボリュームの追加"
 ],
 "Removing physical volume from $target": [
  null,
  "$target から物理ボリュームを削除"
 ],
 "Emptying $target": [
  null,
  "$target を空にしています"
 ],
 "Creating logical volume $target": [
  null,
  "論理ボリューム $target の作成"
 ],
 "Renaming $target": [
  null,
  "$target の名前変更"
 ],
 "Operation '$operation' on $target": [
  null,
  "$target 上の操作 '$operation'"
 ],
 "unknown target": [
  null,
  "不明なターゲット"
 ],
 "Jobs": [
  null,
  "ジョブ"
 ],
 "Reading": [
  null,
  "読み取り中"
 ],
 "Writing": [
  null,
  "書き込み中"
 ],
 "Install Stratis support": [
  null,
  "Stratis サポートをインストールする"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis デバイスを作成するために $0 パッケージをインストールする必要があります。"
 ],
 "Install NFS support": [
  null,
  "NFS サポートをインストールする"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID デバイスの作成"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの作成"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI イニシエーター名の変更"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI ポータルの追加"
 ],
 "Local storage": [
  null,
  "ローカルストレージ"
 ],
 "Networked storage": [
  null,
  "ネットワークストレージ"
 ],
 "Create storage device": [
  null,
  "ストレージデバイスの作成"
 ],
 "No storage found": [
  null,
  "ストレージが見つかりません"
 ],
 "Server address cannot be empty.": [
  null,
  "サーバーアドレスは空欄にできません。"
 ],
 "Next": [
  null,
  "次へ"
 ],
 "Invalid username or password": [
  null,
  "無効なユーザー名またはパスワード"
 ],
 "Unknown host name": [
  null,
  "不明なホスト名"
 ],
 "Unable to reach server": [
  null,
  "サーバーに到達できません"
 ],
 "Available targets on $0": [
  null,
  "$0 で利用可能なターゲット"
 ],
 "Authentication required": [
  null,
  "認証が必要です"
 ],
 "iSCSI portal": [
  null,
  "iSCSI ポータル"
 ],
 "iSCSI drives": [
  null,
  "iSCSI ドライブ"
 ],
 "No drives found": [
  null,
  "ドライブが見つかりません"
 ],
 "Target": [
  null,
  "ターゲット"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO バッキングデバイスを小さくすることはできません"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs は縮小できません"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "ここでは、認識されないデータを小さくすることはできません。"
 ],
 "Unlock before resizing": [
  null,
  "サイズ変更前のロック解除"
 ],
 "$0 can not be resized here": [
  null,
  "ここでは $0 のサイズを変更できません"
 ],
 "$0 can not be resized": [
  null,
  "$0 のサイズは変更できません"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 を小さくすることはできません"
 ],
 "$0 can not be made larger": [
  null,
  "$0 を大きくすることはできません"
 ],
 "Physical volumes can not be resized here": [
  null,
  "ここでは物理ボリュームのサイズを変更できません"
 ],
 "Swap can not be resized here": [
  null,
  "ここではスワップのサイズを変更できません"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "ここでは、認識されないデータを小さくすることはできません"
 ],
 "Activate before resizing": [
  null,
  "リサイズする前に有効化"
 ],
 "Grow logical volume": [
  null,
  "論理ボリュームの増加"
 ],
 "Grow partition": [
  null,
  "パーティションの拡張"
 ],
 "grow": [
  null,
  "増加"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "$0 個の物理ボリュームを選択する必要があります"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "暗号化されたファイルシステムのサイズ変更には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "論理ボリュームのストライプごとに 1 つずつ、合計で $0 個の物理ボリュームを選択する必要があります。"
 ],
 "Shrink logical volume": [
  null,
  "論理ボリュームの縮小"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "Unformatted data": [
  null,
  "未フォーマットのデータ"
 ],
 "Block device": [
  null,
  "ブロックデバイス"
 ],
 "Device number": [
  null,
  "デバイス番号"
 ],
 "Create partition on $0": [
  null,
  "$0 上でのパーティションの作成"
 ],
 "Format $0": [
  null,
  "$0 のフォーマット"
 ],
 "No filesystem": [
  null,
  "ファイルシステムなし"
 ],
 "(recommended)": [
  null,
  "(推奨)"
 ],
 "No encryption": [
  null,
  "暗号化なし"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "既存の暗号化を再利用 ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "既存の暗号化を再利用"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "Format and mount": [
  null,
  "フォーマットおよびマウント"
 ],
 "Format only": [
  null,
  "フォーマットのみ"
 ],
 "Format": [
  null,
  "フォーマット"
 ],
 "Create and start": [
  null,
  "作成および起動"
 ],
 "Format and start": [
  null,
  "フォーマットおよび起動"
 ],
 "Store passphrase": [
  null,
  "パスフレーズの保存"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "フォーマットすると、ストレージデバイスのすべてのデータが削除されます。"
 ],
 "Unrecognized data": [
  null,
  "認識されないデータ"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ストレージは、このシステムで管理できません。"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "このツールは、システムがカーネルクラッシュダンプを書き込むように設定します。\"local\"（ディスク）、\"ssh\"、および \"nfs\" をターゲットとしてサポートしています。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "format-bytes\u0004bytes": [
  null,
  "バイト"
 ]
});
