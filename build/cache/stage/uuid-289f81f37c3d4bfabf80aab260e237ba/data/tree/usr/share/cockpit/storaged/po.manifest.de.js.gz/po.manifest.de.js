cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "de",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "unmount": [
  null,
  "Aushängen"
 ],
 "mount": [
  null,
  "Einhängen"
 ],
 "format": [
  null,
  "Formatieren"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "Dateisystem"
 ],
 "partition": [
  null,
  "Partition"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "volume": [
  null,
  "Volume"
 ],
 "disk": [
  null,
  "Datenträger"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "Speichergerät"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "Fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "Verschlüsselung"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Partitionen verwalten"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-Freigaben verwalten"
 ],
 "Managing RAIDs": [
  null,
  "RAIDs verwalten"
 ],
 "Managing LVMs": [
  null,
  "LVMs verwalten"
 ],
 "Managing physical drives": [
  null,
  "Physische Laufwerke verwalten"
 ],
 "Managing VDOs": [
  null,
  "VDOs verwalten"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS-Verschlüsselung verwenden"
 ],
 "Using Tang server": [
  null,
  "Tang-Server verwenden"
 ]
});
