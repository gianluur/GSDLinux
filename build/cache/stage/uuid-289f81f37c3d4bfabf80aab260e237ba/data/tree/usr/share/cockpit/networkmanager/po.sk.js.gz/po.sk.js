cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "sk",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "Firewall": [
  null,
  "Brána firewall"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Public key": [
  null,
  "Verejný kľúč"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "Unexpected error": [
  null,
  "Neočakávaná chyba"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "Connect": [
  null,
  "Pripojiť"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "Disconnected": [
  null,
  "Odpojené"
 ],
 "Permission denied": [
  null,
  "Prístup odmietnutý"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "You now have administrative access.": [
  null,
  "Teraz máte prístup na úrovni správcu systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pre získanie prístupu na úrovni správcu sa prosím overte"
 ],
 "Switch to administrative access": [
  null,
  "Prepnúť na prístup pre správcu"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s prepínaním na správcu"
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Limit access": [
  null,
  "Obmedziť prístup"
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim obmedzeného prístupu obmedzuje oprávnenia pre správu. Niektoré časti webovej konzole budú poskytovať menej funkcií."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prehliadač si bude úroveň prístupu pamätať aj pre budúce spustenia."
 ],
 "Limited access": [
  null,
  "Obmedzený prístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnúť prístup na úrovni správcu"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásil chybový kód $0"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Neúspešné"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrujte písaním"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Súborový systém"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Súbor"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Generated": [
  null,
  "Vytvorené"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Start service": [
  null,
  "Spustiť službu"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Delete $0": [
  null,
  "Odstrániť $0"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Actions": [
  null,
  "Akcie"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Not available": [
  null,
  "edostupné"
 ],
 "Ignore": [
  null,
  "Ignorovať"
 ],
 "Permanent": [
  null,
  "Trvalá"
 ],
 "Preserve": [
  null,
  "Zachovať"
 ],
 "Random": [
  null,
  "Náhodná"
 ],
 "Stable": [
  null,
  "Stabilná"
 ],
 "Failed to save settings": [
  null,
  "Nastavenia sa nepodarilo uložiť"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vytvorením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Create it": [
  null,
  "Vytvoriť to"
 ],
 "Invalid prefix $0": [
  null,
  "Neplatná predpona $0"
 ],
 "Invalid metric $0": [
  null,
  "Neplatná metrika $0"
 ],
 "Invalid address $0": [
  null,
  "Neplatná adresa $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Neplatná predpona alebo maska siete $0"
 ],
 "Testing connection": [
  null,
  "Testujem spojenie"
 ],
 "Restoring connection": [
  null,
  "Obnovujem spojenie"
 ],
 "Troubleshoot…": [
  null,
  "Riešiť problém…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager nebeží"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager nie je nainštalovaný"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Sieťové zariadenia a grafy vyžadujú NetworkManager"
 ],
 "Enable service": [
  null,
  "Zapnúť službu"
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nemáte oprávnenia na správu brány firewall."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nemáte oprávnenie na vypnutie brány firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nemáte oprávnenie na zapnutie brány firewall"
 ],
 "Disable the firewall": [
  null,
  "Vypnúť bránu firewall"
 ],
 "Enable the firewall": [
  null,
  "Zapnúť bránu firewall"
 ],
 "Edit service $0": [
  null,
  "Upraviť službu $0"
 ],
 "Remove service $0": [
  null,
  "Odstrániť službu $0"
 ],
 "Remove zone $0": [
  null,
  "Odstrániť zónu $0"
 ],
 "Add services to zone $0": [
  null,
  "Pridať služby do zóny $0"
 ],
 "Add services": [
  null,
  "Pridať služby"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "zóna $0"
 ],
 "Interface": [
  null,
  "Rozhranie",
  "Rozhrania",
  "Rozhraní"
 ],
 "Allowed addresses": [
  null,
  "Povolené adresy"
 ],
 "Entire subnet": [
  null,
  "Celá podsieť"
 ],
 "There are no active services in this zone": [
  null,
  "V tejto zóne sa nenachádzajú žiadne aktívne služby"
 ],
 "Filter services": [
  null,
  "Filtrovať služby"
 ],
 "Failed to edit service": [
  null,
  "Službu sa nepodarilo upraviť"
 ],
 "Failed to add port": [
  null,
  "Nepodarilo sa pridať port"
 ],
 "Failed to add service": [
  null,
  "Nepodarilo sa pridať službu"
 ],
 "Unknown service name": [
  null,
  "Neznámy názov služby"
 ],
 "Invalid port number": [
  null,
  "Neplatné číslo portu"
 ],
 "Invalid range": [
  null,
  "Neplatný rozsah"
 ],
 "Range must be strictly ordered": [
  null,
  "Je potrebné, aby rozsah bol striktne radený"
 ],
 "Edit service": [
  null,
  "Upraviť službu"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Upraviť používateľom definovanú službu v zóne $0"
 ],
 "Add ports": [
  null,
  "Pridať porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Pridať porty do zóny $0"
 ],
 "Add services to $0 zone": [
  null,
  "Pridať službu do zóny $0"
 ],
 "Custom ports": [
  null,
  "Používateľom definované porty"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Príklad: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Sú akceptované čiarkou oddelené porty, rozsahy a služby"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Príklad: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Ak nie je vyplnené, identifikátor bude vytvorený na základe súvisiacich služieb na porte a čísiel portov"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Pridaním používateľom definovaných portov dôjde k opätovnému načítaniu firewallu, čím sa stratia nastavenia, ktoré boli vytvorené počas behu a neboli uložené!"
 ],
 "Failed to add zone": [
  null,
  "Nepodarilo sa pridať zónu"
 ],
 "Add zone": [
  null,
  "Pridať zónu"
 ],
 "Trust level": [
  null,
  "Stupeň dôveryhodnosti"
 ],
 "Sorted from least to most trusted": [
  null,
  "Zoradené od najmenej po najviac dôveryhodnú"
 ],
 "Custom zones": [
  null,
  "Používateľom definované zóny"
 ],
 "No description available": [
  null,
  "Nie je k dispozícií žiaden popis"
 ],
 "Included services": [
  null,
  "Zahrnuté služby"
 ],
 "The cockpit service is automatically included": [
  null,
  "Služba cockpit je zahrnutá automaticky"
 ],
 "Interfaces": [
  null,
  "Rozhrania"
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP adresa so smerovacou predponou (prefix). Viacero hodnôt oddeľujte čiarkou. Príklad: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Potvrdiť odstránenie $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Táto zóna obsahuje službu cockpit. Overte, či sa táto zóna nevzťahuje na vaše aktuálne pripojenie k tejto webovej konzoli."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Odstránenie zóny odoberie tiež všetky služby, ktoré obsahuje."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Odstránenie služby cockpit môže viesť k tomu, že webová konzola prestane byť dostupná. Uistite sa, že sa táto zóna nevzťahuje na vaše súčasné pripojenie k tejto webovej konzoli."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Odstrániť službu $0 zo zóny $1"
 ],
 "Firewall is not available": [
  null,
  "Brána firewall nie je k dispozícii"
 ],
 "Please install the $0 package": [
  null,
  "Nainštalujte $0 balík"
 ],
 "Add a new zone": [
  null,
  "Pridať novú zónu"
 ],
 "Add new zone": [
  null,
  "Pridať novú zónu"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "V predvolenom nastavení sú prichádzajúce požiadavky blokované. Odchádzajúce blokované nie sú."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "WPA/WPA2 Personal": [
  null,
  ""
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odstránením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zapnutím $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Switch on $0": [
  null,
  "Zapnúť $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Vypnutím $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Switch off $0": [
  null,
  "Vypnúť $0"
 ],
 "Bond": [
  null,
  "Väzba"
 ],
 "Team": [
  null,
  "Teaming"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Most"
 ],
 "Unknown \"$0\"": [
  null,
  "Neznáme \"$0\""
 ],
 "Carrier": [
  null,
  "Nosný signál"
 ],
 "Yes": [
  null,
  "Áno"
 ],
 "No": [
  null,
  "Nie"
 ],
 "Inactive": [
  null,
  "Neaktívne"
 ],
 "Unknown configuration": [
  null,
  "Neznáma konfigurácia"
 ],
 "Additional address $val": [
  null,
  "Ďalšia adresa $val"
 ],
 "Address $val": [
  null,
  "Adresa $val"
 ],
 "Additional DNS $val": [
  null,
  "Ďalšie DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ďalšie DNS domény k prehľadávaniu $val"
 ],
 "DNS search domains $val": [
  null,
  "Prehľadávať DNS domény $val"
 ],
 "General": [
  null,
  "Všeobecné"
 ],
 "Connect automatically": [
  null,
  "Pripojiť sa automaticky"
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP monitoring"
 ],
 "Broken configuration": [
  null,
  "Chybné nastavenia"
 ],
 "Team port": [
  null,
  "Port pre teaming"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "Priorita $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Oneskorenie preposlania $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Oznamovací čas $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximálny vek správ $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Náklady trasy $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Režim Hair pin"
 ],
 "Bridge port": [
  null,
  "Port mostu"
 ],
 "Parent $parent": [
  null,
  "Nadradené $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  ""
 ],
 "open": [
  null,
  ""
 ],
 "Signal strength": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "Odpojiť"
 ],
 "Refresh": [
  null,
  ""
 ],
 "Network": [
  null,
  "Sieť"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Signal": [
  null,
  ""
 ],
 "Rate": [
  null,
  ""
 ],
 "Not permitted to configure network devices": [
  null,
  "Nemáte oprávnenie nastavovať sieťové zariadenia"
 ],
 "Enable or disable the device": [
  null,
  "Povoliť alebo zakázať zariadenie"
 ],
 "This device cannot be managed here.": [
  null,
  "Toto zariadenie tu nie je možné spravovať."
 ],
 "Connection will be lost": [
  null,
  "Spojenie bude zrušené"
 ],
 "Keep connection": [
  null,
  "Zachovať spojenie"
 ],
 "Preparing": [
  null,
  "Pripravujem"
 ],
 "Configuring": [
  null,
  "Nastavujem"
 ],
 "Authenticating": [
  null,
  "Overujem"
 ],
 "Configuring IP": [
  null,
  "Nastavujem IP adresu"
 ],
 "Checking IP": [
  null,
  "Kontrolujem IP adresu"
 ],
 "Waiting": [
  null,
  "Čakám"
 ],
 "Active": [
  null,
  "Aktívna"
 ],
 "Deactivating": [
  null,
  "Deaktivujem"
 ],
 "Adhoc": [
  null,
  ""
 ],
 "Infra": [
  null,
  ""
 ],
 "Mesh": [
  null,
  ""
 ],
 "No carrier": [
  null,
  "Bez signálu"
 ],
 "Part of $0": [
  null,
  "Súčasť $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zmenou nastavení sa uší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Change the settings": [
  null,
  "Zmeniť nastavenia"
 ],
 "Add bridge": [
  null,
  "Pridať sieťový most"
 ],
 "Edit bridge settings": [
  null,
  "Upraviť nastavenia mostu (bridge)"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "STP priorita"
 ],
 "STP forward delay": [
  null,
  "STP oneskorenie preposielania"
 ],
 "STP hello time": [
  null,
  "STP uvítací čas"
 ],
 "STP maximum message age": [
  null,
  "SFTP maximálny ved správy"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "Aktívna záloha"
 ],
 "Load balancing": [
  null,
  "Rozkladanie záťaže"
 ],
 "Broadcast": [
  null,
  "Vysielanie"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Pasívny"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "Pridať teaming"
 ],
 "Edit team settings": [
  null,
  "Upraviť nastavenia teamingu"
 ],
 "Runner": [
  null,
  "Spúšťač"
 ],
 "Balancer": [
  null,
  "Rozkladanie záťaže"
 ],
 "Primary": [
  null,
  "Primárny"
 ],
 "Link watch": [
  null,
  "Stráženie linky"
 ],
 "Link up delay": [
  null,
  "Oneskorenie aktívnej linky"
 ],
 "Link down delay": [
  null,
  "Oneskorenie neaktívnej linky"
 ],
 "Ping interval": [
  null,
  "Interval pre ping"
 ],
 "Ping target": [
  null,
  "Cieľ pre ping"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaticky (iba DHCP)"
 ],
 "Link local": [
  null,
  "Lokálne prepojenie"
 ],
 "Manual": [
  null,
  "Ručne"
 ],
 "Shared": [
  null,
  "Zdieľané"
 ],
 "Prefix length or netmask": [
  null,
  "Dĺžka predpony alebo maska siete"
 ],
 "Prefix length": [
  null,
  "Dĺžka eor"
 ],
 "IPv4 settings": [
  null,
  "Nastavenia IPv4"
 ],
 "IPv6 settings": [
  null,
  "Nastavenia IPv6"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Select method": [
  null,
  "Vybrať metódu"
 ],
 "Add address": [
  null,
  "Pridať adresu"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Remove item": [
  null,
  "Odstrániť položku"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Pridať DNS server"
 ],
 "DNS search domains": [
  null,
  "DNS prehľadávané domény"
 ],
 "Add search domain": [
  null,
  "Pridať prehľadávanú doménu"
 ],
 "Search domain": [
  null,
  "Prehľadávané domény"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Add route": [
  null,
  "Pridať trasu"
 ],
 "Metric": [
  null,
  "Metrika"
 ],
 "Enter a valid MAC address": [
  null,
  "Zadajte platnú MAC adresu"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "Add VPN": [
  null,
  "Pridať VPN"
 ],
 "Add bond": [
  null,
  "Pridať spojenie liniek (bond)"
 ],
 "Add VLAN": [
  null,
  "Pridať VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Upraviť pravidlá a zóny"
 ],
 "$0 active zone": [
  null,
  "$0 aktívna zóna",
  "$0 aktívne zóny",
  "$0 aktívnych zón"
 ],
 "Managed interfaces": [
  null,
  "Spravované zariadenia"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "Sending": [
  null,
  "Odchádzajúce"
 ],
 "Receiving": [
  null,
  "Prijímanie"
 ],
 "Unmanaged interfaces": [
  null,
  "Nespravované zariadenia"
 ],
 "Network logs": [
  null,
  "Záznamy udalostí siete"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresy nie sú v správnom formáte"
 ],
 "wireguard-tools package is not installed": [
  null,
  "balíček wireguard-tools nie je nainštalovaný"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Protistrana č. $0 nemá platný port koncového bodu. Port musí byť číslo."
 ],
 "Listen port must be a number": [
  null,
  "Načúvací port musí byť číslo"
 ],
 "Add WireGuard VPN": [
  null,
  "Pridať WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Upraviť WireGuard VPN"
 ],
 "Private key": [
  null,
  "Súkromný kľúč"
 ],
 "Paste existing key": [
  null,
  "Vložiť existujúci kľúč"
 ],
 "Regenerate": [
  null,
  "Znovu vytvoriť"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Verejný kľúč bude vytvorený v okamihu zadania platného súkromného kľúča"
 ],
 "Listen port": [
  null,
  "Port, na ktorom očakávať pripojenia (počúvať)"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Bude nastavené na „Automaticky“"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Je možné zadať viacero adries (oddelených čiarkami alebo medzerami)."
 ],
 "Peers": [
  null,
  "Protistrany"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Protistrany sú iné stroje, ktoré sa k tomuto stroju prihlasujú. Verejné kľúče z ostatných strojov sa medzi sebou zdieľajú."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Je potrebné zadať koncový bod slúžiaci ako „server\" v podobe stroj:port, inak je možné nechať pole nevyplnené."
 ],
 "Add peer": [
  null,
  "Pridať protistranu"
 ],
 "Endpoint": [
  null,
  "Koncový bod"
 ],
 "Allowed IPs": [
  null,
  "Povolené IP adresy"
 ],
 "No peers added.": [
  null,
  "Nepridané žiadne protistrany."
 ],
 "Edit VLAN settings": [
  null,
  "Upraviť nastavenia VLAN"
 ],
 "Parent": [
  null,
  "Rodič"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "Odosielanie"
 ],
 "MTU must be a positive number": [
  null,
  "MTU musí byť kladné číslo"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Nastaviť na"
 ],
 "Team port settings": [
  null,
  "Nastavenia portu pre teaming"
 ],
 "Sticky": [
  null,
  "Lepkavé"
 ],
 "LACP key": [
  null,
  "LACP kľúč"
 ],
 "Bridge port settings": [
  null,
  "Nastavenia portov mostu"
 ],
 "Path cost": [
  null,
  "Náklady trasy"
 ],
 "Hair pin mode": [
  null,
  "Režim Hair pin"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptívne rozkladanie prenosovej zátaže odosielania"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptívne rozkladanie zátaže"
 ],
 "MII (recommended)": [
  null,
  "MII (odporúčané)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Upraviť nastavenia spojenia (bond)"
 ],
 "Network bond": [
  null,
  "Sieťové spojenie (bond)"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Sieťové spojenie - bonding - spája viacero sieťových rozhraní do jedného logického rozhrania s vyššou priepustnosťou alebo odolnosťou voči výpadkom."
 ],
 "Link monitoring": [
  null,
  "Monitorovanie linky"
 ],
 "Monitoring interval": [
  null,
  "Interval monitorovania"
 ],
 "Monitoring targets": [
  null,
  "Ciele monitorovania"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Odstránením $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Remove $0": [
  null,
  "Odobrať $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Pridaním $0 sa preruší spojenie so serverom a zneprístupní sa tak rozhranie pre jeho správu."
 ],
 "Add member": [
  null,
  "Pridať člena"
 ],
 "Interface members": [
  null,
  "Čísla rozhraní"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ]
});
