cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pa",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "ਐਨਾਕਾਂਡਾ"
 ]
});
