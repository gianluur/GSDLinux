cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "partition": [
  null,
  "განყოფილება"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "volume": [
  null,
  "ტომი"
 ],
 "disk": [
  null,
  "დისკი"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "დისკი"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "დაშიფვრა"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "დამაყოფების მართვა"
 ],
 "Managing NFS mounts": [
  null,
  "NFS მიმაგრებების მართვა"
 ],
 "Managing RAIDs": [
  null,
  "RAID-ის მართვა"
 ],
 "Managing LVMs": [
  null,
  "LVM-ის მართვა"
 ],
 "Managing physical drives": [
  null,
  "ფიზიკური დისკების მართვა"
 ],
 "Managing VDOs": [
  null,
  "VDO-ის მართვა"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS დაშიფვრის გამოყენებით"
 ],
 "Using Tang server": [
  null,
  "Tang სერვერის გამოყენებით"
 ]
});
