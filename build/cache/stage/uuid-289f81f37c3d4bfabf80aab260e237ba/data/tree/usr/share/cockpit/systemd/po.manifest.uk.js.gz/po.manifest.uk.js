cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Служби"
 ],
 "Terminal": [
  null,
  "Термінал"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "Logs": [
  null,
  "Журнали"
 ],
 "time": [
  null,
  "time"
 ],
 "date": [
  null,
  "дата"
 ],
 "restart": [
  null,
  "перезапуск"
 ],
 "shut": [
  null,
  "вимкнути"
 ],
 "domain": [
  null,
  "домен"
 ],
 "machine": [
  null,
  "машина"
 ],
 "operating system": [
  null,
  "операційна система"
 ],
 "os": [
  null,
  "ос"
 ],
 "asset tag": [
  null,
  "мітка активу"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "живлення"
 ],
 "version": [
  null,
  "версія"
 ],
 "host": [
  null,
  "вузол"
 ],
 "hardware": [
  null,
  "обладнання"
 ],
 "mitigation": [
  null,
  "обхід"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "пам'ять"
 ],
 "cpu": [
  null,
  "процесор"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "послідовний"
 ],
 "graphs": [
  null,
  "графіки"
 ],
 "metrics": [
  null,
  "метрика"
 ],
 "history": [
  null,
  "журнал"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "диски"
 ],
 "network": [
  null,
  "мережа"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "швидкодія"
 ],
 "Configuring system settings": [
  null,
  "Налаштовування параметрів системи"
 ],
 "service": [
  null,
  "служба"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ціль"
 ],
 "socket": [
  null,
  "сокет"
 ],
 "timer": [
  null,
  "секундомір"
 ],
 "path": [
  null,
  "шлях"
 ],
 "unit": [
  null,
  "модуль"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "завантаження"
 ],
 "mask": [
  null,
  "маска"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "увімкнути"
 ],
 "disable": [
  null,
  "вимкнути"
 ],
 "Managing services": [
  null,
  "Керування службами"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "warning": [
  null,
  "попередження"
 ],
 "error": [
  null,
  "помилка"
 ],
 "debug": [
  null,
  "діагностика"
 ],
 "crash": [
  null,
  "аварія"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "Reviewing logs": [
  null,
  "Перегляд журналів"
 ],
 "console": [
  null,
  "консоль"
 ],
 "command": [
  null,
  "команда"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "оболонка"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
