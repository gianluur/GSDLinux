cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 erro",
  "$0 erros"
 ],
 "$0 installation": [
  null,
  "Instalação $0"
 ],
 "$0 installer": [
  null,
  "Instalador $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 é uma partição estendida MBR que contém partições lógicas. A remoção de todas as partições lógicas também removerá automaticamente a partição estendida."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 é necessário, mas apenas $1 está disponível."
 ],
 "$0 warning": [
  null,
  "$0 aviso",
  "$0 avisos"
 ],
 "$0 will be deleted": [
  null,
  "$0 será excluído"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "O sistema de arquivos '$0' não pode estar em um dispositivo de bloco criptografado"
 ],
 "'$0' must be assigned to $1": [
  null,
  "'$0' deve ser atribuído a $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' deve estar em um dispositivo formatado em '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' deve estar em uma partição de sistema EFI. A partição selecionada usa um sistema de arquivos FAT, mas não está marcada como ESP. Defina o tipo de partição como Sistema EFI e habilite o sinalizador esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Partição '$0' no dispositivo MDRAID $1 encontrada. Partições do carregador de inicialização em dispositivos MDRAID não são suportadas."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Uma conta de usuário padrão com acesso administrativo para fazer alterações em todo o sistema."
 ],
 "Abort installation": [
  null,
  "Abortar instalação"
 ],
 "About": [
  null,
  "Sobre"
 ],
 "Account": [
  null,
  "Conta"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Add another server...": [
  null,
  "Adicionar outro servidor..."
 ],
 "Add mount": [
  null,
  "Adicionar montagem"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Extensões para o ambiente selecionado"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Extensões não específicas para seu ambiente"
 ],
 "Additional languages": [
  null,
  "Idiomas adicionais"
 ],
 "Additional software for the selected environment": [
  null,
  "Software adicional para o ambiente selecionado"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Todas as alterações feitas no editor de armazenamento terão efeitos imediatos."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Todos os dispositivos utilizando esta senha serão desbloqueados"
 ],
 "Anaconda Web UI": [
  null,
  "Interface Web do Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Página do projeto Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Aplicar ponto de montagem e instalar"
 ],
 "Applying changes...": [
  null,
  "Aplicando alterações..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Atribuir partições a pontos de montagem. Útil para layouts pré-configurados ."
 ],
 "Automatic log file upload": [
  null,
  "Envio automático de arquivo de log"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Definir data e hora automaticamente, usando servidores de tempo"
 ],
 "Automatically set timezone": [
  null,
  "Definir fuso horário automaticamente"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Espaço livre disponível: $0. A instalação requer: $1."
 ],
 "Back": [
  null,
  "Voltar"
 ],
 "Base environment": [
  null,
  "Ambiente base"
 ],
 "Brief description of the issue": [
  null,
  "Descrição breve do problema"
 ],
 "Bug report details": [
  null,
  "Detalhes do relatório de erro"
 ],
 "Bugzilla API key": [
  null,
  "Chave de API do Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Ao continuar usando este programa, você entende e aceita os riscos associados ao programa de pré-lançamento, que pretende usá-lo apenas para fins de testes e desenvolvimento e está disposto a relatar quaisquer bugs ou problemas para aprimorar este trabalho."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change destination": [
  null,
  "Alterar destino"
 ],
 "Change hostname": [
  null,
  "Alterar hostname"
 ],
 "Change partition layout": [
  null,
  "Alterar layout de partição"
 ],
 "Change system keyboard layout": [
  null,
  "Alterar o layout do teclado do sistema"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "As mudanças feitas aqui irão afetar o sistema imediatamente. Não há 'desfazer'."
 ],
 "Checking installation configuration...": [
  null,
  "Checando configurações de instalação..."
 ],
 "Checking storage configuration": [
  null,
  "Checando configurações de armazenamento"
 ],
 "Clear search": [
  null,
  "Limpar pesquisa"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Clique \"Próximo\" novamente para prosseguir apesar destes avisos."
 ],
 "Close": [
  null,
  "Encerrar"
 ],
 "Close storage editor": [
  null,
  "Fecha o editor de armazenamento"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "O armazenamento do cockpit não forneceu a senha para desbloquear o dispositivo criptografado."
 ],
 "Completed": [
  null,
  "Terminado"
 ],
 "Configuration is incomplete": [
  null,
  "A configuração está incompleta"
 ],
 "Configure NTP servers": [
  null,
  "Configurar servidores NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Configurar servidores NTP personalizados"
 ],
 "Configure network": [
  null,
  "Configurar a rede"
 ],
 "Configure storage": [
  null,
  "Configurar o armazenamento"
 ],
 "Configure storage again": [
  null,
  "Configurar o armazenamento novamente"
 ],
 "Confirm passphrase": [
  null,
  "Confirmar frase secreta"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Continue installation": [
  null,
  "Continue a instalação"
 ],
 "Continue installation?": [
  null,
  "Continuar a instalação?"
 ],
 "Continue with installation": [
  null,
  "Continuar com a instalação"
 ],
 "Correct these issues before continuing.": [
  null,
  "Corrija essas questões antes de continuar."
 ],
 "Create Account": [
  null,
  "Criar conta"
 ],
 "Create account": [
  null,
  "Criar conta"
 ],
 "Currently installed: $0": [
  null,
  "Instalado atualmente: $0"
 ],
 "Custom": [
  null,
  "Personalizada"
 ],
 "Date": [
  null,
  "Data"
 ],
 "Date and time": [
  null,
  "Data e hora"
 ],
 "Delete partition": [
  null,
  "Excluir partição"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "A exclusão de certas partições pode impedir $0 de iniciar: $1"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Destination": [
  null,
  "Destinação"
 ],
 "Destination is encrypted": [
  null,
  "O destino está criptografado"
 ],
 "Detailed description of the issue": [
  null,
  "Descrição detalhada do problema"
 ],
 "Detected valid storage layout:": [
  null,
  "Detectado layout válido de armazenamento:"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Duplicate device.": [
  null,
  "Dispositivos duplicados."
 ],
 "Duplicate mount point.": [
  null,
  "Ponto de montagem duplicado."
 ],
 "Enable root account": [
  null,
  "Habilitar conta root"
 ],
 "Encrypt my data": [
  null,
  "Criptografar meus dados"
 ],
 "Encrypted": [
  null,
  "Criptografado"
 ],
 "Encryption": [
  null,
  "Criptografia"
 ],
 "Enter PIN": [
  null,
  "Digite a senha"
 ],
 "Enter PIN to access the installer": [
  null,
  "Digite a senha para acessar o instalador"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Insira sua chave da API do Bugzilla para criar um relatório de erro. Você poderá revisar e editar os detalhes do erro na próxima etapa."
 ],
 "Environment": [
  null,
  "Ambiente"
 ],
 "Erase data and install": [
  null,
  "Apagar dados e instalar"
 ],
 "Error details": [
  null,
  "Detalhes do erro"
 ],
 "Exit to live desktop": [
  null,
  "Voltar ao modo Live"
 ],
 "Extended partition": [
  null,
  "Partição estendida"
 ],
 "Failed to report issue": [
  null,
  "Falha ao relatar problema"
 ],
 "Failed to save layouts": [
  null,
  "Falha ao salvar layouts"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux requer pelo menos $0 de espaço em disco."
 ],
 "Finalization": [
  null,
  "Finalização"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Finalizando: a configuração do sistema está concluída. A finalização da instalação pode demorar alguns instantes."
 ],
 "Find layout": [
  null,
  "Buscar layout"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Para maior segurança, evite usar a conta root diretamente. Em vez disso, use a conta local acima para gerenciar o sistema."
 ],
 "Full name": [
  null,
  "Nome completo"
 ],
 "Full name cannot contain colon characters": [
  null,
  "O nome completo não pode conter dois pontos"
 ],
 "Helper text": [
  null,
  "Texto de ajuda"
 ],
 "Hide API key": [
  null,
  "Ocultar chave de API"
 ],
 "Hide PIN": [
  null,
  "Ocultar senha"
 ],
 "Hide confirmed password": [
  null,
  "Ocultar senha confirmada"
 ],
 "Hide passphrase": [
  null,
  "Ocultar frase secreta"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "Hostname": [
  null,
  "Hostname"
 ],
 "How would you like to install?": [
  null,
  "Como você gostaria de instalar?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Compreendo que todos os dados existentes serão apagados",
  "Compreendo que todos os dados existentes serão apagados dos discos selecionados"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Compreendo que alguns dos dados existentes serão apagados"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Compreendo que algumas partições serão modificadas"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Se vazio, o hostname será temporário e definido pelas informações de rede."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Se nenhuma das opções acima for aplicável, use o editor de armazenamento para criar um particionamento personalizado antes de prosseguir."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Se você está configurando partições, o seguinte é requerido:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Se você não concordar com o envio automático de arquivos de registro, pode usar o valor $0. O relatório manual permite que você revise e anexe arquivos de registro seletivamente."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Se você não entender ou aceitar os riscos, saia deste programa."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Se o seu problema corresponder a um dos bugs acima, você pode editá-lo e adicionar suas informações lá, em vez de criar um relatório duplicado."
 ],
 "In progress": [
  null,
  "Em progresso"
 ],
 "Initializing...": [
  null,
  "Inicializando..."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Installation completed": [
  null,
  "Instalação concluída"
 ],
 "Installation failed": [
  null,
  "A instalação falhou"
 ],
 "Installation method": [
  null,
  "Método de instalação"
 ],
 "Installation of the system failed": [
  null,
  "A instalação do sistema falhou"
 ],
 "Installation of the system failed: $0": [
  null,
  "A instalação do sistema falhou: $0"
 ],
 "Installation type": [
  null,
  "Tipo de instalação"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Insufficient disk space": [
  null,
  "Espaço de disco insuficiente"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Senha inválida. Tente novamente."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Configuração RAID inválida detectada. Se a matriz RAID for criada diretamente sobre os discos, uma tabela de partição deverá ser criada na matriz. Se sua matriz RAID for criada sobre partições, ela deve conter um único sistema de arquivos ou formato (por exemplo, LVM PV). Todas as partições existentes nesta matriz serão ignoradas."
 ],
 "Invalid hostname": [
  null,
  "Hostname inválido"
 ],
 "Jump to first incomplete step": [
  null,
  "Pular para a primeira etapa incompleta"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Mantém o layout de disco atual e somente instala no espaço disponível para dual boot com outro SO."
 ],
 "Keyboard": [
  null,
  "Teclado"
 ],
 "Keyboard layout during boot": [
  null,
  "Layout do teclado durante a inicialização"
 ],
 "Language": [
  null,
  "Idioma"
 ],
 "Launch storage editor": [
  null,
  "Editor de armazenamento"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Saiba mais sobre acesso restrito nas configurações"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Deixe os dois campos de senha vazios para usar uma senha vazia."
 ],
 "Location": [
  null,
  "Localização"
 ],
 "Locked devices": [
  null,
  "Dispositivos bloqueados"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Make current": [
  null,
  "Tornar atual"
 ],
 "Manual disk configuration": [
  null,
  "Configuração manual de disco"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Configuração manual de disco: Mapeamento de pontos de montagem"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Pode conter letras, números e traços."
 ],
 "May need more free space": [
  null,
  "Pode precisar de mais espaço livre"
 ],
 "Medium": [
  null,
  "Mídia"
 ],
 "Minimum of $0 required": [
  null,
  "Mínimo de $0 exigido"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Incompatibilidade entre o dispositivo pai e a seleção de reformatação do dispositivo filho."
 ],
 "Mount point": [
  null,
  "Ponto de montagem"
 ],
 "Mount point assignment": [
  null,
  "Atribuição de ponto de montagem"
 ],
 "Move down": [
  null,
  "Mover para baixo"
 ],
 "Move up": [
  null,
  "Mover para cima"
 ],
 "Must be at least $0 characters": [
  null,
  "Deve ter pelo menos $0 caracteres"
 ],
 "My issue is different, continue": [
  null,
  "Meu problema é diferente, continuar"
 ],
 "NTP Servers": [
  null,
  "Servidores NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Needs at least $0": [
  null,
  "Precisa de pelo menos $0"
 ],
 "Network": [
  null,
  "Rede"
 ],
 "Network Configuration": [
  null,
  "Configuração da rede"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Rede não disponível. Configure a rede no menu da barra superior para relatar o problema."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Rede não disponível. Configure a rede para relatar o problema."
 ],
 "Network plugin failed": [
  null,
  "Falha no plug-in de rede"
 ],
 "Next": [
  null,
  "Próximo"
 ],
 "No devices": [
  null,
  "Nenhum dispositivo"
 ],
 "No disks available": [
  null,
  "Nenhum disco disponível"
 ],
 "No disks selected": [
  null,
  "Nenhum disco selecionado"
 ],
 "No keyboard layouts selected": [
  null,
  "Nenhum layout de teclado selecionado"
 ],
 "No layouts selected yet": [
  null,
  "Nenhum layout selecionado ainda"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Não foi possível obter um mapeamento de teclas VConsole válido para o(s) layout(s) de teclado selecionado(s). Selecione um layout de teclado diferente."
 ],
 "Not enough available free space": [
  null,
  "Não há espaço livre suficiente"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Não há espaço em disco suficiente nos discos selecionados."
 ],
 "Not enough space on selected disks.": [
  null,
  "Não há espaço suficiente nos discos selecionados."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Atenção: este é um programa pré-lançado destinado apenas para fins de desenvolvimento e testes. NÃO use este programa para nenhum trabalho crítico ou para ambientes de produção."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Abrir o formulário de regustro de bugs do Bugzilla"
 ],
 "Operating system": [
  null,
  "Sistema Operacional"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other keyboards": [
  null,
  "Outros teclados"
 ],
 "Partitions (advanced)": [
  null,
  "Partições (avançado)"
 ],
 "Passphrase": [
  null,
  "Frase secreta"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Frase secreta não correspondeu a nenhum dispositivo bloqueado"
 ],
 "Passphrases must match": [
  null,
  "Frases secretas devem corresponder"
 ],
 "Pending": [
  null,
  "Pendente"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Por favor, anexe o arquivo de log $0 à issue."
 ],
 "Please enter a PIN": [
  null,
  "Digite uma senha"
 ],
 "Please select at least one disk to continue": [
  null,
  "Selecione pelo menos um disco para continuar"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  "Possíveis bugs duplicados encontrados"
 ],
 "Powered by Anaconda": [
  null,
  "Desenvolvido pelo Anaconda"
 ],
 "Pre-release": [
  null,
  "Pré-lançamento"
 ],
 "Prefer to report manually? $0": [
  null,
  "Prefere fazer o relatório manualmente? $0"
 ],
 "Proceed with installation": [
  null,
  "Prosseguir com a instalação"
 ],
 "Quit": [
  null,
  "Sair"
 ],
 "Quit installer?": [
  null,
  "Sair do instalador?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Não foi possível ler as informações sobre Sistema Operacional."
 ],
 "Reading information about the computer failed.": [
  null,
  "Não foi possível ler as informações sobre o computador."
 ],
 "Reading installer configuration failed.": [
  null,
  "A leitura da configuração do instalador falhou."
 ],
 "Reading installer version information failed.": [
  null,
  "A leitura das informações da versão do instalador falhou."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "O hostname real só pode conter letras, números e traços (que não podem iniciar ou finalizar o nome) e pontos"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "O hostname real precisa ter 64 caracteres ou menos"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Reinicialize no Windows para redimensionar partições criptografadas pelo BitLocker. Disponibilize pelo menos $0 de espaço livre para instalação."
 ],
 "Reboot system?": [
  null,
  "Reiniciar o sistema?"
 ],
 "Reclaim additional space": [
  null,
  "Recuperar espaço adicional"
 ],
 "Reclaim space": [
  null,
  "Recuperar espaço"
 ],
 "Reclaim space (required)": [
  null,
  "Recuperar espaço (obrigatório)"
 ],
 "Recommended": [
  null,
  "Recomendado"
 ],
 "Recommended partitions:": [
  null,
  "Partições recomendadas:"
 ],
 "Reformat": [
  null,
  "Reformatar"
 ],
 "Reinstall Fedora": [
  null,
  "Reinstalar Fedora"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Remova todas as partições dos dispositivos selecionados, incluindo sistemas operacionais existentes."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Excluir ou redimensionar sistemas de arquivos existentes para liberar espaço para a instalação."
 ],
 "Remove server": [
  null,
  "Remover servidor"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "A remoção de um sistema de arquivos excluirá permanentemente todos os dados que ele contém. Redimensionar uma partição pode liberar espaço não utilizado, mas não é isento de riscos. Certifique-se de ter backups de qualquer coisa importante antes de recuperar espaço."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Substitui a instalação atual, porém mantém os arquivos na home."
 ],
 "Report Issue": [
  null,
  "Relatar Problema"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Reporte um problema ou forneça feedback abrindo o formulário de entrada de bugs do Bugzilla $0."
 ],
 "Report issue": [
  null,
  "Relatar problema"
 ],
 "Reporting issue...": [
  null,
  "Relatando problema..."
 ],
 "Required": [
  null,
  "Obrigatório"
 ],
 "Requirements": [
  null,
  "Requisitos"
 ],
 "Rescan devices": [
  null,
  "Reexaminar dispositivos"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Reexanimação dos discos falhou."
 ],
 "Resize": [
  null,
  "Redimensionar"
 ],
 "Resize partition": [
  null,
  "Redimensionar partição"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Redimensionando as seguintes partições de$0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Acesso restrito ao relatório"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Restringe o relatório ao grupo $0. $1"
 ],
 "Return to installation": [
  null,
  "Retornar para instalação"
 ],
 "Return to storage editor": [
  null,
  "Retornar ao editor de armazenamento"
 ],
 "Review and install": [
  null,
  "Revisar e instalar"
 ],
 "Root account has been configured": [
  null,
  "Conta root foi configurada"
 ],
 "Root account is enabled": [
  null,
  "A conta root está haabilitada"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "A conta root está habilitada, mas nenhuma conta de usuário foi configurada"
 ],
 "Root password has been set.": [
  null,
  "A senha do root foi definida."
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Escaneie o código QR com seu telefone ou visite:"
 ],
 "Search for a language": [
  null,
  "Pesquisar um idioma"
 ],
 "Search for additional software": [
  null,
  "Buscar software adicional"
 ],
 "Search for an environment": [
  null,
  "Pesquisar um ambiente"
 ],
 "Search keyboard layout": [
  null,
  "Pesquisar layout de teclado"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Proteja seus dados usando criptografia de disco. Aplica-se apenas à novas partições"
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "Select a device": [
  null,
  "Selecione um dispositivo"
 ],
 "Select city": [
  null,
  "Selecionar cidade"
 ],
 "Select destination": [
  null,
  "Selecionar destino"
 ],
 "Select region": [
  null,
  "Selecionar região"
 ],
 "Selected (top = current)": [
  null,
  "Selecionado (topo = atual)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "O formato do dispositivo selecionado '$0' não pode ser reformatado."
 ],
 "Send us feedback on your installation": [
  null,
  "Envie-nos comentários sobre sua instalação"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server is not reachable": [
  null,
  "O servidor não está acessível"
 ],
 "Set custom hostname": [
  null,
  "Definir hostname personalizado"
 ],
 "Share disk with other operating systems": [
  null,
  "Compartilhar disco com outros sistemas operacionais"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Compartilhar disco com outros sistemas operacionais: $0"
 ],
 "Show AM/PM": [
  null,
  "Mostrar AM/PM"
 ],
 "Show API key": [
  null,
  "Mostrar chave de API"
 ],
 "Show PIN": [
  null,
  "Mostrar senha"
 ],
 "Show confirmed password": [
  null,
  "Mostrar senha confirmada"
 ],
 "Show passphrase": [
  null,
  "Mostrar frase secreta"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Software installation": [
  null,
  "Instalação de programas"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Instalação de programas: configuração de armazenamento concluída. Os programas estão sendo instalados no seu dispositivo."
 ],
 "Software selection": [
  null,
  "Seleção de programas"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Algumas etapas de instalação ainda precisam ser concluídas antes que você possa continuar."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Algumas partições obrigatórias estão faltando: $0"
 ],
 "Space": [
  null,
  "Espaço"
 ],
 "Stacktrace": [
  null,
  "Rastreamento de pilha (stacktrace)"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Storage configuration": [
  null,
  "Configuração de armazenamento"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Configuração de armazenamento: o armazenamento está sendo configurado no momento."
 ],
 "Storage editor": [
  null,
  "Editor de armazenamento"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "O armazenamento é baseado na configuração realizada através do 'Editor de armazenamento'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "O layout de armazenamento é definido pelo arquivo kickstart. O layout de particionamento planejado pode ser revisado na etapa de resumo."
 ],
 "Storage plugin failed": [
  null,
  "Falha no plug-in de armazenamento"
 ],
 "Storage requirements not met": [
  null,
  "Requisitos de armazenamento não atendidos"
 ],
 "Strong": [
  null,
  "Forte"
 ],
 "Successfully installed": [
  null,
  "Instalado com sucesso"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0 desbloqueado com sucesso."
 ],
 "Suggested keyboards": [
  null,
  "Teclados sugeridos"
 ],
 "Suggested languages": [
  null,
  "Idiomas sugeridos"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System configuration": [
  null,
  "Configuração do sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Configuração do sistema: instalação de programas concluída. O sistema agora está sendo configurado."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "A instalação do Anaconda parou inesperadamente."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Os seguintes bugs em aberto podem estar relacionados ao seu problema. Por favor, analise-os antes de criar um novo relatório."
 ],
 "The following user will be created:": [
  null,
  "O seguinte usuário será criado:",
  "Os seguintes usuários serão criados:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "A instalação precisa de $0 de espaço em disco; No entanto, a capacidade dos discos selecionados é de apenas $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "O instalador não pode continuar devido a um erro crítico."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "O instalador não pode continuar devido a um erro crítico: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "O layout do teclado foi alterado desde que a senha de criptografia do disco foi definida. Por favor, insira a senha novamente."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "A senha inserida contém caracteres não-ASCII. Você pode não conseguir trocar entre layouts de teclado enquanto a digita."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "O layout de teclado padrão selecionado não suporta caracteres ASCII. Escolha um layout compatível com caracteres ASCII como padrão."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "O editor de armazenamento permite redimensionar, excluir e criar partições. Ele pode configurar LVM e muito mais. Ele deve ser usado como um utilitário avançado e não se destina a ser usado em uma instalação típica."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Esses logs podem conter informações confidenciais, como endereços IP, nomes de usuário ou outros detalhes do sistema."
 ],
 "This hostname can't be submitted": [
  null,
  "Este hostname não pode ser salvo"
 ],
 "This is unstable, pre-release software": [
  null,
  "Este é um programa de pré-lançamento instável"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Este layout será usado para desbloquear seu sistema na inicialização"
 ],
 "This may take a moment": [
  null,
  "Isso pode demorar um pouco"
 ],
 "This will take a few moments": [
  null,
  "Isso vai demorar um pouco"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Timezone": [
  null,
  "Fuso horário"
 ],
 "Title": [
  null,
  "Título"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Para começar a usar o $0, reinicie o seu sistema."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Para continuar, selecione os dispositivos nos quais deseja instalar o sistema."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Para usar esta opção, redimensione ou remova as partições existentes para liberar pelo menos $0."
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Não é possível agendar a exclusão de $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Não é possível agendar o redimensionamento de $0"
 ],
 "Undo last action": [
  null,
  "Desfazer última ação"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Unlock encrypted devices": [
  null,
  "Desbloquear dispositivos criptografados"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Desbloqueie partições criptografadas para manter os dados existentes e mostrar mais métodos de instalação."
 ],
 "Use configured storage": [
  null,
  "Usar o armazenamento configurado"
 ],
 "Use entire disk": [
  null,
  "Usar todo o disco"
 ],
 "Use free space": [
  null,
  "Usar espaço livre"
 ],
 "Use local account": [
  null,
  "Usar conta local"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Usar o dispositivo RAID para particionamento automático"
 ],
 "User creation": [
  null,
  "Criação de usuários"
 ],
 "User name": [
  null,
  "Nome de usuário"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "O nome de usuário pode conter apenas: letras a-z, dígitos de 0 a 9, travessão $0, ponto final $1, sublinhado $2"
 ],
 "User name must not be a reserved word": [
  null,
  "O nome de usuário não deve ser uma palavra reservada"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Os nomes de usuários devem ser menores que 33 caracteres"
 ],
 "Validating...": [
  null,
  "Validando..."
 ],
 "Weak": [
  null,
  "Fraca"
 ],
 "Welcome": [
  null,
  "Boas-vindas"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Boas-vindas ao Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Bem-vindo. Vamos instalar o $0 agora."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Ao enviar este relatório de erro, os seguintes arquivos de log serão carregados automaticamente: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Partições do Windows que usam BitLocker não podem ser redimensionadas"
 ],
 "You can close this browser window now.": [
  null,
  "Você pode agora fechar esta janela do navegador."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Você pode liberar espaço aqui e deixar o instalador fazer o resto ou criar partições manualmente."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Você pode gerar a chave de API para sua conta Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Você tem que habilitar a conta root ou criar uma conta de usuário local para prosseguir."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Você deve estar conectado a uma rede para habilitar data e hora automáticas."
 ],
 "Your progress will not be saved.": [
  null,
  "Seu progresso não será salvo."
 ],
 "completed step": [
  null,
  "etapa concluída"
 ],
 "current step": [
  null,
  "etapa atual"
 ],
 "delete": [
  null,
  "excluir"
 ],
 "edit": [
  null,
  "editar"
 ],
 "encrypt": [
  null,
  "criptografar"
 ],
 "encrypted": [
  null,
  "criptografado"
 ],
 "extended partition": [
  null,
  "partição estendida"
 ],
 "format as $0": [
  null,
  "formatar como $0"
 ],
 "here": [
  null,
  "aqui"
 ],
 "incomplete": [
  null,
  "incompleta"
 ],
 "mount": [
  null,
  "montar"
 ],
 "pending step": [
  null,
  "Etapa pendente"
 ],
 "report the issue manually": [
  null,
  "relate o problema manualmente"
 ],
 "resized from $0": [
  null,
  "redimensionado de $0"
 ],
 "shrink": [
  null,
  "reduzir"
 ],
 "shrink to $0": [
  null,
  "reduzir para $0"
 ],
 "transient, will use DHCP": [
  null,
  "transitório, será usado o DHCP"
 ],
 "undo": [
  null,
  "desfazer"
 ]
});
