cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Accounts": [
  null,
  "Accounts"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "wachtwoord"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "gebruikersnaam"
 ],
 "login": [
  null,
  "inloggen"
 ],
 "access": [
  null,
  "toegang"
 ],
 "roles": [
  null,
  "rollen"
 ],
 "keys": [
  null,
  "sleutels"
 ],
 "Managing user accounts": [
  null,
  "Gebruikersaccounts beheren"
 ]
});
