cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ast",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  ""
 ],
 "$0 ($1)": [
  null,
  ""
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  ""
 ],
 "$0 is required, but only $1 is available.": [
  null,
  ""
 ],
 "$0 warning": [
  null,
  "",
  ""
 ],
 "$0 will be deleted": [
  null,
  ""
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  ""
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  ""
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  ""
 ],
 "About": [
  null,
  ""
 ],
 "Account": [
  null,
  ""
 ],
 "Add another server...": [
  null,
  ""
 ],
 "Add mount": [
  null,
  ""
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  ""
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  ""
 ],
 "Apply mount point assignment and install": [
  null,
  ""
 ],
 "Applying changes...": [
  null,
  ""
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  ""
 ],
 "Automatic log file upload": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  ""
 ],
 "Back": [
  null,
  ""
 ],
 "Base environment": [
  null,
  "Entornu base"
 ],
 "Brief description of the issue": [
  null,
  ""
 ],
 "Bug report details": [
  null,
  ""
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  ""
 ],
 "Change": [
  null,
  ""
 ],
 "Change hostname": [
  null,
  ""
 ],
 "Change system keyboard layout": [
  null,
  ""
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  ""
 ],
 "Clear search": [
  null,
  ""
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  ""
 ],
 "Configuration is incomplete": [
  null,
  ""
 ],
 "Correct these issues before continuing.": [
  null,
  ""
 ],
 "Create Account": [
  null,
  ""
 ],
 "Create account": [
  null,
  ""
 ],
 "Currently installed: $0": [
  null,
  ""
 ],
 "Custom": [
  null,
  ""
 ],
 "Date": [
  null,
  ""
 ],
 "Date and time": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  ""
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Detailed description of the issue": [
  null,
  ""
 ],
 "Detected valid storage layout:": [
  null,
  ""
 ],
 "Device": [
  null,
  "Preséu"
 ],
 "Enable root account": [
  null,
  ""
 ],
 "Encrypt my data": [
  null,
  ""
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Error details": [
  null,
  ""
 ],
 "Exit to live desktop": [
  null,
  ""
 ],
 "Failed to report issue": [
  null,
  ""
 ],
 "Failed to save layouts": [
  null,
  ""
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  ""
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  ""
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Nome completu"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hostname": [
  null,
  ""
 ],
 "How would you like to install?": [
  null,
  ""
 ],
 "I understand that all existing data will be erased": [
  null,
  "",
  ""
 ],
 "I understand that some existing data will be erased": [
  null,
  ""
 ],
 "I understand that some partitions will be modified": [
  null,
  ""
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  ""
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  ""
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  ""
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "Initializing...": [
  null,
  ""
 ],
 "Install": [
  null,
  ""
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  ""
 ],
 "Invalid hostname": [
  null,
  ""
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  ""
 ],
 "Keyboard layout during boot": [
  null,
  ""
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  ""
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  ""
 ],
 "Medium": [
  null,
  ""
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  ""
 ],
 "Mount point": [
  null,
  ""
 ],
 "Mount point assignment": [
  null,
  ""
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  ""
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network": [
  null,
  "Rede"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  ""
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  ""
 ],
 "Next": [
  null,
  ""
 ],
 "No disks available": [
  null,
  ""
 ],
 "No disks selected": [
  null,
  ""
 ],
 "No layouts selected yet": [
  null,
  ""
 ],
 "No results found": [
  null,
  ""
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  ""
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  ""
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  ""
 ],
 "Partitions (advanced)": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  "Fras de pasu"
 ],
 "Passphrase did not match any locked device": [
  null,
  ""
 ],
 "Pending": [
  null,
  ""
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  ""
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Pool": [
  null,
  ""
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  ""
 ],
 "Pre-release": [
  null,
  ""
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Quit": [
  null,
  ""
 ],
 "Reading information about the computer failed.": [
  null,
  ""
 ],
 "Reading installer version information failed.": [
  null,
  ""
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  ""
 ],
 "Reboot": [
  null,
  ""
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  ""
 ],
 "Reboot system?": [
  null,
  ""
 ],
 "Reclaim additional space": [
  null,
  ""
 ],
 "Reclaim space (required)": [
  null,
  ""
 ],
 "Recommended": [
  null,
  ""
 ],
 "Recommended partitions:": [
  null,
  ""
 ],
 "Reformat": [
  null,
  ""
 ],
 "Remove": [
  null,
  ""
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  ""
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  ""
 ],
 "Replace current installation, but keep files in home.": [
  null,
  ""
 ],
 "Report Issue": [
  null,
  ""
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  ""
 ],
 "Reporting issue...": [
  null,
  ""
 ],
 "Required": [
  null,
  ""
 ],
 "Requirements": [
  null,
  ""
 ],
 "Rescanning of the disks failed.": [
  null,
  ""
 ],
 "Resize": [
  null,
  ""
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  ""
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  ""
 ],
 "Search for additional software": [
  null,
  ""
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  ""
 ],
 "Selected (top = current)": [
  null,
  ""
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  ""
 ],
 "Server": [
  null,
  ""
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  ""
 ],
 "Share disk with other operating systems": [
  null,
  ""
 ],
 "Share disk with other operating systems: $0": [
  null,
  ""
 ],
 "Size": [
  null,
  ""
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  ""
 ],
 "Software selection": [
  null,
  "Esbilla de software"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  ""
 ],
 "Space": [
  null,
  ""
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  ""
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  ""
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  ""
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage requirements not met": [
  null,
  ""
 ],
 "Strong": [
  null,
  "Fuerte"
 ],
 "Successfully installed": [
  null,
  ""
 ],
 "Successfully unlocked $0.": [
  null,
  ""
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  ""
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "",
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  ""
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  ""
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  ""
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  ""
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  ""
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  ""
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  ""
 ],
 "To continue, select the devices to install to.": [
  null,
  ""
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  ""
 ],
 "Type": [
  null,
  ""
 ],
 "Unable to schedule deletion of $0": [
  null,
  ""
 ],
 "Unable to schedule resizing of $0": [
  null,
  ""
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  ""
 ],
 "Unlock encrypted devices": [
  null,
  ""
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  ""
 ],
 "Use local account": [
  null,
  ""
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  ""
 ],
 "User creation": [
  null,
  "Creación d'usuarios"
 ],
 "User name": [
  null,
  "Nome d'usuariu"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  ""
 ],
 "User name must not be a reserved word": [
  null,
  ""
 ],
 "Validating...": [
  null,
  ""
 ],
 "Weak": [
  null,
  "Feble"
 ],
 "Welcome": [
  null,
  ""
 ],
 "Welcome. Let's install $0 now.": [
  null,
  ""
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  ""
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  ""
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  ""
 ],
 "Your progress will not be saved.": [
  null,
  ""
 ],
 "current step": [
  null,
  ""
 ],
 "edit": [
  null,
  ""
 ],
 "format as $0": [
  null,
  ""
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "pending step": [
  null,
  ""
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  ""
 ],
 "shrink to $0": [
  null,
  ""
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  ""
 ]
});
