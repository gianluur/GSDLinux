cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "fa",
  "language-direction": "rtl"
 },
 "Anaconda": [
  null,
  "آناکوندا"
 ]
});
