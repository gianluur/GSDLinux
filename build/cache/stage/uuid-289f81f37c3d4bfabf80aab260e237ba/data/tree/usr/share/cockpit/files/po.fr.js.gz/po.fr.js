cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "fr",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "Répertoire personnel"
 ],
 "Unable to create bookmark directory": [
  null,
  "Impossible de créer le répertoire des marque-pages"
 ],
 "Unable to save bookmark file": [
  null,
  "Impossible d'enregistrer le fichier des marque-pages"
 ],
 "Remove from bookmarks": [
  null,
  "Supprimer des marque-pages"
 ],
 "Add to bookmarks": [
  null,
  "Ajouter aux marque-pages"
 ],
 "Bookmarks": [
  null,
  "Marque-pages"
 ],
 "Bookmarked": [
  null,
  "Ajouté aux marque-pages"
 ],
 "Not bookmarked": [
  null,
  "Non ajouté aux marque-pages"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Edit path": [
  null,
  "Modifier le chemin"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Largest size": [
  null,
  "Taille la plus grande"
 ],
 "Smallest size": [
  null,
  "Taille la plus petite"
 ],
 "Modified": [
  null,
  "Modifié"
 ],
 "First modified": [
  null,
  "Première modification"
 ],
 "Last modified": [
  null,
  "Dernière modification"
 ],
 "Owner": [
  null,
  "Propriétaire"
 ],
 "Owner ascending": [
  null,
  "Propriétaire croissant"
 ],
 "Owner descending": [
  null,
  "Propriétaire décroissant"
 ],
 "Permissions": [
  null,
  "Autorisations"
 ],
 "Most permissive": [
  null,
  "Le plus permissif"
 ],
 "Least permissive": [
  null,
  "Le moins permissif"
 ],
 "Show keyboard shortcuts": [
  null,
  "Afficher les raccourcis clavier"
 ],
 "Filter directory": [
  null,
  "Filtrer le répertoire"
 ],
 "Display as a list": [
  null,
  "Afficher sous forme de liste"
 ],
 "Display as a grid": [
  null,
  "Afficher sous forme de grille"
 ],
 "Sort": [
  null,
  "Trier"
 ],
 "Hide hidden items": [
  null,
  "Masquer les éléments masqués"
 ],
 "Show hidden items": [
  null,
  "Afficher les éléments cachés"
 ],
 "$0 files": [
  null,
  "$0 fichiers"
 ],
 "Uploaded as $0, $1": [
  null,
  "Uploadé en tant que $0,$1"
 ],
 "Replace file $0?": [
  null,
  "Remplacer le fichier $0 ?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Un fichier portant le même nom existe déjà dans \"$0\". Le remplacer écrasera son contenu."
 ],
 "New file": [
  null,
  "Nouveau fichier"
 ],
 "Original file on server": [
  null,
  "Fichier original sur le serveur"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Appliquer cette action à tous les fichiers en conflit"
 ],
 "Replace": [
  null,
  "Remplacer"
 ],
 "Keep original": [
  null,
  "Garder l'original"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Failed": [
  null,
  "Échec"
 ],
 "Upload error": [
  null,
  "Erreur d'upload"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Impossible de déplacer le fichier téléchargé vers la destination finale"
 ],
 "Cancelled": [
  null,
  "Annulé"
 ],
 "Cancelled upload of $0": [
  null,
  "Upload de $0 annulé"
 ],
 "File uploaded": [
  null,
  "Fichier uploadé"
 ],
 "Files uploaded": [
  null,
  "Fichiers uploadés"
 ],
 "Change permissions": [
  null,
  "Modifier les autorisations"
 ],
 "Uploads": [
  null,
  "Téléversements"
 ],
 "Cancel upload of $0": [
  null,
  "Annuler l'upload de $0"
 ],
 "Upload $0% completed": [
  null,
  "Upload effectué à $0 %"
 ],
 "Upload": [
  null,
  "Uploader"
 ],
 "None": [
  null,
  "Aucune"
 ],
 "Execute-only": [
  null,
  "Exécution seule"
 ],
 "Write-only": [
  null,
  "Écriture seule"
 ],
 "Write and execute": [
  null,
  "Écriture et exécution"
 ],
 "Read-only": [
  null,
  "Lecture seule"
 ],
 "Read and execute": [
  null,
  "Lecture et exécution"
 ],
 "Read and write": [
  null,
  "Lecture et écriture"
 ],
 "Read, write, and execute": [
  null,
  "Lecture, écriture et exécution"
 ],
 "Block device": [
  null,
  "Périphérique de blocs"
 ],
 "Character device": [
  null,
  "Périphérique de caractères"
 ],
 "Directory": [
  null,
  "Répertoire"
 ],
 "Named pipe": [
  null,
  "Named pipe"
 ],
 "Symbolic link": [
  null,
  "Lien symbolique"
 ],
 "Regular file": [
  null,
  "Fichier normal"
 ],
 "Socket": [
  null,
  "Socket"
 ],
 "Name cannot be empty": [
  null,
  "Le nom ne peut pas être vide"
 ],
 "Name too long": [
  null,
  "Nom trop long"
 ],
 "Name cannot include a /": [
  null,
  "Le nom ne peut pas contenir de /"
 ],
 "Filename is the same as original name": [
  null,
  "Le nom du fichier est identique au nom d'origine"
 ],
 "Directory with the same name exists": [
  null,
  "Un répertoire portant le même nom existe"
 ],
 "File exists": [
  null,
  "Le fichier existe"
 ],
 "Pasting failed": [
  null,
  "Échec du collage"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" existe, il ne sera pas écrasé par le contenu à coller."
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Create directory": [
  null,
  "Créer un répertoire"
 ],
 "Create file": [
  null,
  "Créer un fichier"
 ],
 "Edit permissions": [
  null,
  "Modifier les autorisations"
 ],
 "Open in terminal": [
  null,
  "Ouvrir dans le terminal"
 ],
 "Open text file": [
  null,
  "Ouvrir le fichier texte"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Download": [
  null,
  "Télécharger"
 ],
 "Create link": [
  null,
  "Créer un lien"
 ],
 "Drop files to upload": [
  null,
  "Déposez les fichiers à uploader"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Impossible de déposer des fichiers, un autre upload est déjà en cours"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Go up a directory": [
  null,
  "Aller au répertoire parent"
 ],
 "Go back": [
  null,
  "Précédent"
 ],
 "Go forward": [
  null,
  "Suivant"
 ],
 "Activate selected item, enter directory": [
  null,
  "Activer l'élément sélectionné, entrer dans le répertoire"
 ],
 "Rename selected file or directory": [
  null,
  "Renommer le fichier ou le répertoire sélectionné"
 ],
 "Create new directory": [
  null,
  "Créer un nouveau répertoire"
 ],
 "Copy selected file or directory": [
  null,
  "Copier le fichier ou le répertoire sélectionné"
 ],
 "Paste file or directory": [
  null,
  "Coller le fichier ou le répertoire"
 ],
 "Select all": [
  null,
  "Tout sélectionner"
 ],
 "Save current file": [
  null,
  "Enregistrer le fichier actuel"
 ],
 "Close editor": [
  null,
  "Fermer l'éditeur"
 ],
 "Keyboard shortcuts": [
  null,
  "Raccourcis clavier"
 ],
 "Navigation": [
  null,
  "Navigation"
 ],
 "Editing": [
  null,
  "Modification"
 ],
 "Editor": [
  null,
  "Éditeur"
 ],
 "Force delete $0 items": [
  null,
  "Forcer la suppression de $0 éléments"
 ],
 "Delete $0 items?": [
  null,
  "Supprimer $0 éléments ?"
 ],
 "Force delete file $0?": [
  null,
  "Forcer la suppression du fichier $0 ?"
 ],
 "Delete file $0?": [
  null,
  "Supprimer le fichier $0 ?"
 ],
 "Force delete link $0?": [
  null,
  "Forcer la suppression du lien $0 ?"
 ],
 "Delete link $0?": [
  null,
  "Supprimer le lien $0 ?"
 ],
 "Force delete directory $0?": [
  null,
  "Forcer la suppression du répertoire $0 ?"
 ],
 "Delete directory $0?": [
  null,
  "Supprimer le répertoire $0 ?"
 ],
 "Force delete $0": [
  null,
  "Forcer la suppression de $0"
 ],
 "Delete $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "No access": [
  null,
  "Pas d'accès"
 ],
 "Missing type": [
  null,
  "Type manquant"
 ],
 "Collapse": [
  null,
  "Réduire"
 ],
 "Show all files": [
  null,
  "Afficher tous les fichiers"
 ],
 "$0 permissions": [
  null,
  "Autorisations de $0"
 ],
 "Permissions for $0 files": [
  null,
  "Autorisations pour $0 fichiers"
 ],
 "Ownership": [
  null,
  "Propriété"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "Access": [
  null,
  "Accès"
 ],
 "Owner access": [
  null,
  "Accès propriétare"
 ],
 "Group access": [
  null,
  "Accès groupe"
 ],
 "Others access": [
  null,
  "Accès autres"
 ],
 "Security context": [
  null,
  "Contexte de sécurité"
 ],
 "Set executable as program": [
  null,
  "Définir l'exécutable comme programme"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change permissions for enclosed files": [
  null,
  "Modifier les autorisations pour les fichiers inclus"
 ],
 "(original owner)": [
  null,
  "(propriétaire original)"
 ],
 "keep original owners": [
  null,
  "Conserver les propriétaires d'origine"
 ],
 "Paste as owner": [
  null,
  "Coller en tant que propriétaire"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Le propriétaire des fichiers collés est différent. Par défaut, le propriétaire des fichiers sera modifié pour correspondre au répertoire de destination."
 ],
 "New owner": [
  null,
  "Nouveau propriétaire"
 ],
 "Overwrite": [
  null,
  "Écraser"
 ],
 "New filename": [
  null,
  "Nouveau nom de fichier"
 ],
 "New name": [
  null,
  "Nouveau nom"
 ],
 "Rename $0?": [
  null,
  "Renommer $0 ?"
 ],
 "link to $0": [
  null,
  "lien vers $0"
 ],
 "Create link to $0": [
  null,
  "Créer un lien vers $0"
 ],
 "Target": [
  null,
  "Cible"
 ],
 "Symlink name": [
  null,
  "Nom du lien symbolique"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolu vs relatif"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Les liens symboliques absolus sont idéals lorsqu'il s'agit de faire référence à des fichiers ou des répertoires qui ne seront pas déplacés, comme les fichiers système."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Les liens symboliques relatifs sont utiles lorsqu'un lien symbolique et sa cible sont susceptibles être déplacés en même temps, par exemple lors du renommage ou du déplacement d'un répertoire parent."
 ],
 "Absolute": [
  null,
  "Absolu"
 ],
 "Relative": [
  null,
  "Relatif"
 ],
 "The file has been removed on disk": [
  null,
  "Le fichier a été supprimé du disque"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Le fichier existant a été modifié de manière inattendue"
 ],
 "Edit $0": [
  null,
  "Modifier $0"
 ],
 "View $0": [
  null,
  "Voir $0"
 ],
 "The file has changed on disk": [
  null,
  "Le fichier a été modifié sur le disque"
 ],
 "Reload": [
  null,
  "Recharger"
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Save changes?": [
  null,
  "Enregistrer les modifications ?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Le fichier a été supprimé après son ouverture. Il sera recréé si vous l'enregistrez."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Le fichier a été modifié sur le disque depuis son ouverture"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "Des modifications de $0 ne sont pas enregistrées et seront définitivement perdues si vous les abandonnez."
 ],
 "Discard": [
  null,
  "Abandonner"
 ],
 "File name": [
  null,
  "Nom du fichier"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Cannot create file in current directory": [
  null,
  "Impossible de créer le fichier dans le répertoire actuel"
 ],
 "Permission denied": [
  null,
  "Accès refusé"
 ],
 "Directory name cannot be empty": [
  null,
  "Le nom du répertoire ne peut pas être vide"
 ],
 "Directory name too long": [
  null,
  "Nom de répertoire trop long"
 ],
 "Directory name cannot include a /": [
  null,
  "Le nom du répertoire ne peut pas contenir un /"
 ],
 "Directory name": [
  null,
  "Nom du répertoire"
 ],
 "Directory owner": [
  null,
  "Propriétaire du répertoire"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant"
 ],
 "Clear filter": [
  null,
  "Effacer le filtre"
 ],
 "Directory is empty": [
  null,
  "Le répertoire est vide"
 ],
 "$0 item is hidden": [
  null,
  "$0 élément est masqué",
  "$0 éléments sont masqués"
 ],
 "Folder": [
  null,
  "Dossier"
 ],
 "File": [
  null,
  "Fichier"
 ],
 "Others": [
  null,
  "Autres"
 ],
 "$0 files selected": [
  null,
  "$0 fichiers sélectionnés"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Le répertoire contient $0 répertoires, $1 fichiers"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Le répertoire contient $0 répertoires, $1 fichiers, $2 masqués"
 ],
 "User": [
  null,
  "Utilisateur"
 ]
});
