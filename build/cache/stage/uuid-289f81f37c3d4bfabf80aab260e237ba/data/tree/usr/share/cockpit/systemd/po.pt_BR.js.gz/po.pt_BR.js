cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Journal": [
  null,
  "Diário"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Informação de hardware"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "active": [
  null,
  "ativo"
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Você está se conectando com $0 pela primeira vez."
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Execute este comando por meio de uma rede confiável ou fisicamente na máquina remota:"
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Não foi possível efetuar login em $0. O host não aceita login por senha nem por nenhuma de suas chaves SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida por senha, e o host não permite login com senha. Por favor, forneça a senha da chave no endereço $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "A chave SSH para acessar o endereço $0 está protegida. Você pode acessar usando sua senha de login ou fornecendo a senha da chave no endereço $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "Key password": [
  null,
  "Senha da chave"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "A chave SSH $0 de $1 em $2 serão adicionadas ao arquivo $3 de $4 em $5."
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "A chave SSH $0 ficará disponível durante o restante da sessão e também poderá ser usada para fazer login em outros hosts."
 ],
 "Permission denied": [
  null,
  "Permissão negada"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Pick date": [
  null,
  "Selecionar data"
 ],
 "Toggle date picker": [
  null,
  "Alternar o seletor de data"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "You now have administrative access.": [
  null,
  "Agora você tem acesso administrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Não existem métodos disponíveis para obter acesso administrativo (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentique-se para obter acesso administrativo"
 ],
 "Switch to administrative access": [
  null,
  "Trocar para acesso administrativo"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema ao se tornar administrador"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Switch to limited access": [
  null,
  "Trocar para acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "O modo de acesso limitado restringe os privilégios administrativos. Algumas partes do console web terão funcionalidade reduzida."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Seu navegador irá memorizar seu nível de acesso entre as sessões."
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar acesso administrativo"
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Visit firewall": [
  null,
  "Visitar firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Strong password": [
  null,
  "Senha forte"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Weak password": [
  null,
  "Senha fraca"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "Show confirmation password": [
  null,
  "Mostrar a senha de confirmação"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando a conclusão de outras operações de gerenciamento de software"
 ],
 "Checking installed software": [
  null,
  "Verificando software instalado"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Não foi possível efetuar login em $0 usando autenticação por chave SSH. Por favor, forneça a senha."
 ],
 "SSH key login": [
  null,
  "Login com chave SSH"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportou código de erro $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "Row expansion": [
  null,
  "Expansão de linha"
 ],
 "Row select": [
  null,
  "Seleção de linha"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Erro de colagem"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Seu navegador não permite colar texto pelo menu de contexto. Você pode usar Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Erro durante inicialização"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Home": [
  null,
  "Pasta pessoal"
 ],
 "Downloads": [
  null,
  "Downloads"
 ],
 "Not a directory": [
  null,
  "Não é um diretório"
 ],
 "All files": [
  null,
  "Todos os arquivos"
 ],
 "Recent": [
  null,
  "Recentes"
 ],
 "No recent directories": [
  null,
  "Nenhum diretório recente"
 ],
 "No recent files": [
  null,
  "Nenhum arquivo recente"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "File chooser actions": [
  null,
  "Ações do seletor de arquivos"
 ],
 "Open in file browser": [
  null,
  "Abrir no navegador de arquivos"
 ],
 "Hide hidden files": [
  null,
  "Ocultar arquivos ocultos"
 ],
 "Show hidden files": [
  null,
  "Mostrar arquivos ocultos"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Clear filters": [
  null,
  "Limpar filtros"
 ],
 "Directory is empty": [
  null,
  "O diretório está vazio"
 ],
 "Directory has no sub-directories": [
  null,
  "O diretório não tem subdiretórios"
 ],
 "This directory contains only hidden files": [
  null,
  "Este diretório contém apenas arquivos ocultos"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "Folder": [
  null,
  "Pasta"
 ],
 "File": [
  null,
  "Arquivo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "O usuário conectado não tem permissão para visualizar as modificações do sistema"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "View automation script": [
  null,
  "Ver script de automação"
 ],
 "Occurrences": [
  null,
  "Ocorrências"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Select an option": [
  null,
  "Selecione uma opção"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Not permitted to perform this action.": [
  null,
  "Não autorizado a executar esta ação."
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Host key is incorrect": [
  null,
  "Chave de host incorreta"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "$0 is not a directory": [
  null,
  "$0 não é um diretório"
 ],
 "$0 does not exist": [
  null,
  "$0 não existe"
 ],
 "Font size": [
  null,
  "Tamanho da fonte"
 ],
 "Decrease by one": [
  null,
  "Diminuir em um"
 ],
 "Increase by one": [
  null,
  "Incrementar em um"
 ],
 "Appearance": [
  null,
  "Aparência"
 ],
 "Black": [
  null,
  "Preto"
 ],
 "White": [
  null,
  "Branco"
 ],
 "Reset": [
  null,
  "Redefinir"
 ],
 "Unable to open directory": [
  null,
  "Não foi possível abrir o diretório"
 ],
 "Running process prevents directory change": [
  null,
  "Processos em execução impedem alteração do diretório"
 ],
 "Change directory": [
  null,
  "Mudar diretório"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Alterar o diretório interromperá à força o processo em execução no momento. O processo também pode ser interrompido manualmente no terminal antes de continuar."
 ],
 "Terminal not available": [
  null,
  "Terminal não disponível"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Este navegador não suporta WebGL2."
 ],
 "unknown": [
  null,
  "desconhecido"
 ],
 "Shutdown": [
  null,
  "Desligar"
 ],
 "running $0": [
  null,
  "executando $0"
 ],
 "Current boot": [
  null,
  "Inicialização atual"
 ],
 "Previous boot": [
  null,
  "Inicialização anterior"
 ],
 "Last 24 hours": [
  null,
  "Últimas 24 horas"
 ],
 "Last 7 days": [
  null,
  "Últimos 7 dias"
 ],
 "Only emergency": [
  null,
  "Apenas emergência"
 ],
 "Alert and above": [
  null,
  "Alerta e acima"
 ],
 "Critical and above": [
  null,
  "Crítico e acima"
 ],
 "Error and above": [
  null,
  "Erro e acima"
 ],
 "Warning and above": [
  null,
  "Aviso e acima"
 ],
 "Notice and above": [
  null,
  "Observe e acima"
 ],
 "Info and above": [
  null,
  "Info e acima"
 ],
 "Debug and above": [
  null,
  "Depurar e acima"
 ],
 "Toggle filters": [
  null,
  "Alternar filtros"
 ],
 "Time": [
  null,
  "Tempo"
 ],
 "Priority": [
  null,
  "Prioridade"
 ],
 "Identifier": [
  null,
  "Identificador"
 ],
 "Filters": [
  null,
  "Filtros"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Resume": [
  null,
  "Continuar"
 ],
 "All": [
  null,
  "Todos"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "As especificações de data devem estar no formato AAAA-MM-DD hh:mm:ss. Alternativamente, as strings 'yesterday', 'today', 'tomorrow' são compreendidas. 'now' se refere ao tempo atual. Finalmente, tempos relativos podem ser especificados, prefixados com '-' ou '+'"
 ],
 "Since": [
  null,
  "Desde"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Começa a exibir as entradas iguais ou posteriores à data especificada."
 ],
 "Until": [
  null,
  "Até"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Começa a exibir as entradas iguais ou anteriores à data especificada."
 ],
 "Boot": [
  null,
  "Inicialização"
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostra mensagens de uma inicialização específica."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Isso adicionará uma correspondência para '_BOOT_ID='. Se não especificado, os logs para a inicialização atual serão exibidos. Se o ID de inicialização for omitido, um deslocamento positivo procurará as inicializações começando do início do diário, e um deslocamento igual ou menor que zero procurará as inicializações começando do final do diário. Assim, 1 significa a primeira inicialização encontrada no diário em ordem cronológica, 2 a segunda e assim por diante; enquanto -0 é a última inicialização, -1 a penúltima inicialização e assim por diante."
 ],
 "Unit": [
  null,
  "Unidade"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostra mensagens para a unidade systemd especificada."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Isso adicionará correspondência para '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' e 'UNIT=' para encontrar todas as mensagens possíveis para a unidade fornecida. Pode conter mais unidades separadas por vírgula."
 ],
 "Free-form search": [
  null,
  "Pesquisa livre"
 ],
 "Show messages containing given string.": [
  null,
  "Mostra mensagens contendo a string dada."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualquer sequência de texto nas mensagens de log pode ser filtrada. A sequência também pode estar na forma de uma expressão regular. Também suporta filtragem por campos de registro de mensagem. Esses valores são separados por espaços, no formato CAMPO=VALOR, onde o valor pode ser uma lista separada por vírgulas de valores possíveis."
 ],
 "journalctl manpage": [
  null,
  "manpage do journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiado com sucesso para a área de transferência"
 ],
 "Create timer": [
  null,
  "Criar Temporizador"
 ],
 "Edit timer": [
  null,
  "Editar temporizador"
 ],
 "Timer creation failed": [
  null,
  "Criação de temporizador falhou"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Falha ao obter as condições de inicialização para o temporizador"
 ],
 "Failed to get the timer command": [
  null,
  "Falha ao obter o comando do temporizador"
 ],
 "This field cannot be empty": [
  null,
  "Este campo não pode estar vazio"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Apenas alfabetos, números, : , _ , . , @ , - são permitidos"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Shell command": [
  null,
  "Comando shell"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Este comando será executado por /bin/sh."
 ],
 "Trigger": [
  null,
  "Gatilhos"
 ],
 "At specific time": [
  null,
  "Em tempo específico"
 ],
 "After system boot": [
  null,
  "Após a inicialização do sistema"
 ],
 "Seconds": [
  null,
  "Segundos"
 ],
 "Minutes": [
  null,
  "Minutos"
 ],
 "Hours": [
  null,
  "Horas"
 ],
 "Weeks": [
  null,
  "Semanas"
 ],
 "Delay must be a number": [
  null,
  "O atraso deve ser um número"
 ],
 "Repeat": [
  null,
  "Repetir"
 ],
 "Don't repeat": [
  null,
  "Não Repita"
 ],
 "Minutely": [
  null,
  "A cada minuto"
 ],
 "Hourly": [
  null,
  "A cada hora"
 ],
 "Daily": [
  null,
  "Diariamente"
 ],
 "Weekly": [
  null,
  "Semanalmente"
 ],
 "Monthly": [
  null,
  "Mensalmente"
 ],
 "Yearly": [
  null,
  "Anualmente"
 ],
 "Run at": [
  null,
  "Executar em"
 ],
 "At second": [
  null,
  "A cada segundo"
 ],
 "At minute": [
  null,
  "A cada minuto"
 ],
 "Run on": [
  null,
  "Executar a cada"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minutos precisam ser números entre 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Segundo precisam ser números entre 0-59"
 ],
 "Repeat weekly": [
  null,
  "Repita Semanalmente"
 ],
 "Mondays": [
  null,
  "Segundas"
 ],
 "Tuesdays": [
  null,
  "Terças"
 ],
 "Wednesdays": [
  null,
  "Quartas"
 ],
 "Thursdays": [
  null,
  "Quintas"
 ],
 "Fridays": [
  null,
  "Sextas"
 ],
 "Saturdays": [
  null,
  "Sábados"
 ],
 "Sundays": [
  null,
  "Domingos"
 ],
 "Repeat monthly": [
  null,
  "Repita Mensalmente"
 ],
 "1st": [
  null,
  "1º"
 ],
 "2nd": [
  null,
  "2º"
 ],
 "3rd": [
  null,
  "3º"
 ],
 "4th": [
  null,
  "4º"
 ],
 "5th": [
  null,
  "5º"
 ],
 "6th": [
  null,
  "6º"
 ],
 "7th": [
  null,
  "7º"
 ],
 "8th": [
  null,
  "8º"
 ],
 "9th": [
  null,
  "9º"
 ],
 "10th": [
  null,
  "10º"
 ],
 "11th": [
  null,
  "11º"
 ],
 "12th": [
  null,
  "12º"
 ],
 "13th": [
  null,
  "13º"
 ],
 "14th": [
  null,
  "14º"
 ],
 "15th": [
  null,
  "15º"
 ],
 "16th": [
  null,
  "16º"
 ],
 "17th": [
  null,
  "17º"
 ],
 "18th": [
  null,
  "18º"
 ],
 "19th": [
  null,
  "19º"
 ],
 "20th": [
  null,
  "20º"
 ],
 "21th": [
  null,
  "21º"
 ],
 "22th": [
  null,
  "22º"
 ],
 "23th": [
  null,
  "23º"
 ],
 "24th": [
  null,
  "24º"
 ],
 "25th": [
  null,
  "25º"
 ],
 "26th": [
  null,
  "26º"
 ],
 "27th": [
  null,
  "27º"
 ],
 "28th": [
  null,
  "28º"
 ],
 "29th": [
  null,
  "29º"
 ],
 "30th": [
  null,
  "30º"
 ],
 "31st": [
  null,
  "31º"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Unclean shutdown": [
  null,
  "Desligamento inadequado"
 ],
 "View logs": [
  null,
  "Ver logs"
 ],
 "Dismiss": [
  null,
  "Descartar"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Desligamento programado para $0"
 ],
 "Cancel poweroff": [
  null,
  "Cancelar desligamento"
 ],
 "Scheduled reboot at $0": [
  null,
  "Reinicialização programado para $0"
 ],
 "Cancel reboot": [
  null,
  "Cancelar reinicialização"
 ],
 "edit": [
  null,
  "editar"
 ],
 "Set hostname": [
  null,
  "Definir nome do host"
 ],
 "Configuration": [
  null,
  "Configuração"
 ],
 "Hostname": [
  null,
  "Nome do host"
 ],
 "System time": [
  null,
  "Hora do sistema"
 ],
 "Domain": [
  null,
  "Domínio"
 ],
 "Performance profile": [
  null,
  "Perfil de desempenho"
 ],
 "Secure shell keys": [
  null,
  "Chaves de Shell Seguras"
 ],
 "Show fingerprints": [
  null,
  "Mostrar impressões digitais"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "falha ao listar chaves locais de ssh: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "O carregamento das chaves SSH falhou"
 ],
 "Error message": [
  null,
  "Mensagem de erro"
 ],
 "Loading keys...": [
  null,
  "Carregando chaves..."
 ],
 "No host keys found.": [
  null,
  "Nenhuma chave de host encontrada."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Máquina de Chaves SSH e Impressões digitais"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Nome de host real deve conter 64 caracteres ou menos"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Nome de host real só pode conter caracteres minúsculos, dígitos, traços e períodos (com subdomínios preenchidos)"
 ],
 "Change host name": [
  null,
  "Alterar o Nome do Host"
 ],
 "Pretty host name": [
  null,
  "Nome de Host Bonito"
 ],
 "Real host name": [
  null,
  "Nome real de host"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "O usuário $0 não tem permissão para alterar políticas criptográficas"
 ],
 "Cryptographic policy": [
  null,
  "Política de criptografia"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Recomendado, configurações seguras para os modelos de ameaça atuais."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT com verificação de assinatura SHA-1 permitida."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Maior interoperabilidade ao custo de uma maior superfície de ataque."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY com interoperabilidade com Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Só usa algoritmos aprovados e permitidos ao inicializar em modo FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS com outras restrições de Common Criteria."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protege contra possíveis ataques futuros a curto prazo, à custa da interoperabilidade."
 ],
 "Custom cryptographic policy": [
  null,
  "Política de criptografia customizada"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Políticas criptográficas é um componente do sistema que configura os principais subsistemas criptográficos, abrangendo os protocolos TLS, IPSec, SSH, DNSSec e Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Modifique a política criptográfica"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplicando a nova política... Isso pode levar alguns minutos."
 ],
 "Reapply and reboot": [
  null,
  "Reaplicar e reiniciar"
 ],
 "Apply and reboot": [
  null,
  "Aplicar e reiniciar"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS não está habilitado corretamente"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "A política de criptografia está inconsistente"
 ],
 "Review cryptographic policy": [
  null,
  "Revisar política criptográfica"
 ],
 "System information": [
  null,
  "Informação do sistema"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Asset tag": [
  null,
  "Etiqueta de ativo"
 ],
 "Machine ID": [
  null,
  "ID de Máquina"
 ],
 "Up since": [
  null,
  "Ligado desde"
 ],
 "View hardware details": [
  null,
  "Ver detalhes do hardware"
 ],
 "Last successful login:": [
  null,
  "Último login bem-sucedido:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 tentativa de login falhou",
  "$0 tentativas de login falharam"
 ],
 "View login history": [
  null,
  "Ver histórico de login"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "A adesão a um domínio requer a instalação do realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Não é possível ingressar em um domínio porque realmd não está disponível neste sistema"
 ],
 "Joining this domain is not supported": [
  null,
  "A adesão à este domínio não é suportada"
 ],
 "Login format": [
  null,
  "Formato de Login"
 ],
 "Server software": [
  null,
  "Software de servidor"
 ],
 "Client software": [
  null,
  "Software do cliente"
 ],
 "Leave domain": [
  null,
  "Abandonar Domínio"
 ],
 "Leave $0": [
  null,
  "Abandonar $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Após sair do domínio, apenas os usuários com credenciais locais poderão fazer login nesta máquina. Isso também pode afetar outros serviços, como as configurações de resolução DNS e a lista de autoridades de certificação confiáveis."
 ],
 "Validating address": [
  null,
  "Validando endereço"
 ],
 "Contacted domain": [
  null,
  "Domínio contatado"
 ],
 "Domain could not be contacted": [
  null,
  "O Domínio não pôde ser contatado"
 ],
 "Domain is not supported": [
  null,
  "O Domínio não é suportado"
 ],
 "Domain address": [
  null,
  "Endereço do Domínio"
 ],
 "Domain administrator name": [
  null,
  "Nome do Administrador de Domínio"
 ],
 "Domain administrator password": [
  null,
  "Senha do Administrador de Domínio"
 ],
 "Joining": [
  null,
  "Juntando-se"
 ],
 "Join": [
  null,
  "Afiliar-se"
 ],
 "This may take a while": [
  null,
  "Isso pode demorar um pouco"
 ],
 "Not permitted to configure realms": [
  null,
  "Não autorizado a configurar reinos"
 ],
 "Join domain": [
  null,
  "Associar-se ao domínio"
 ],
 "Install realmd support": [
  null,
  "Instalar o suporte ao realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disco está falhando",
  "$0 discos estão falhando"
 ],
 "Connected to Insights": [
  null,
  "Conectado a Insights"
 ],
 "Not connected to Insights": [
  null,
  "Não conectado a Insights"
 ],
 "Health": [
  null,
  "Saúde"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 núcleos de CPU"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "View metrics and history": [
  null,
  "Ver métricas e histórico"
 ],
 "Tuned is not available": [
  null,
  "Tuned não está disponível"
 ],
 "Tuned is not running": [
  null,
  "Tuned não está em execução"
 ],
 "Tuned is off": [
  null,
  "Tuned está fora"
 ],
 "This system is using the recommended profile": [
  null,
  "Este sistema está usando o perfil recomendado"
 ],
 "This system is using a custom profile": [
  null,
  "Este sistema está usando um perfil personalizado"
 ],
 "none": [
  null,
  "nenhum"
 ],
 "Communication with tuned has failed": [
  null,
  "A comunicação com sintonizado falhou"
 ],
 "Failed to enable tuned": [
  null,
  "Falha ao habilitar tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Falha ao desabilitar tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Falha ao desativar o perfil do tuned"
 ],
 "Failed to switch profile": [
  null,
  "Falha ao mudar de perfil"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Disable tuned": [
  null,
  "Desabilitar tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Falha ao iniciar Tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "O Tuned é um serviço que monitora seu sistema e otimiza o desempenho sob determinadas cargas de trabalho. O núcleo do Tuned são os perfis, que ajustam seu sistema para diferentes casos de uso."
 ],
 "Change performance profile": [
  null,
  "Perfil alterar o desempenho"
 ],
 "Change profile": [
  null,
  "Alterar o perfil"
 ],
 "Edit /etc/motd": [
  null,
  "Editar /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Falha ao salvar alterações em /etc/motd"
 ],
 "Save changes": [
  null,
  "Salvar Mudanças"
 ],
 "Edit motd": [
  null,
  "Editar motd"
 ],
 "Stub": [
  null,
  "Esboço"
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Bad setting": [
  null,
  "Má configuração"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Merged": [
  null,
  "Mesclado"
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "Reloading": [
  null,
  "Carregando novamente"
 ],
 "Not running": [
  null,
  "Não está em execução"
 ],
 "Failed to start": [
  null,
  "Falha ao iniciar"
 ],
 "Maintenance": [
  null,
  "Manutenção"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Linked": [
  null,
  "Vinculado"
 ],
 "Alias": [
  null,
  "Apelido"
 ],
 "Masked": [
  null,
  "Mascarado"
 ],
 "Static": [
  null,
  "Estático"
 ],
 "Invalid": [
  null,
  "Inválido"
 ],
 "Indirect": [
  null,
  "Indireto"
 ],
 "Generated": [
  null,
  "Gerado"
 ],
 "Transient": [
  null,
  "Transitório"
 ],
 "Bad": [
  null,
  "Ruim"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Falha ao assinar aos sinais do systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Falha na conexão com dbus: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Falha na listagem de unidades: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 serviço falhou",
  "$0 serviços falharam"
 ],
 "Loading of units failed": [
  null,
  "O carregamento das unidades falhou"
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Listing units": [
  null,
  "Listando unidades"
 ],
 "Filter by name or description": [
  null,
  "Filtrar por nome ou descrição"
 ],
 "Active state": [
  null,
  "Estado ativo"
 ],
 "File state": [
  null,
  "Estado de arquivo"
 ],
 "$0 filters applied": [
  null,
  "$0 filtros aplicados"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "O usuário $0 não tem permissão para alterar as mitigações de segurança da CPU"
 ],
 "Mitigations": [
  null,
  "Mitigações"
 ],
 "Version": [
  null,
  "Versão"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS versão"
 ],
 "BIOS date": [
  null,
  "BIOS data"
 ],
 "CPU security": [
  null,
  "Segurança da CPU"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Desabilitar multithreading simultâneo"
 ],
 "Read more...": [
  null,
  "Saiba mais..."
 ],
 "Save and reboot": [
  null,
  "Salvar e reiniciar"
 ],
 "CPU security toggles": [
  null,
  "Interruptores de segurança da CPU"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Soluções alternativas baseadas em software ajudam a prevenir problemas de segurança da CPU. Essas medidas têm como efeito colateral a redução do desempenho. Alterar essas configurações é por sua conta e risco."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Tecnologia de memória"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Rank": [
  null,
  "Posição"
 ],
 "Speed": [
  null,
  "Velocidade"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Visualizar informações de memória requer acesso administrativo."
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "Failed to fetch logs": [
  null,
  "Falha ao obter os logs"
 ],
 "Clear all filters": [
  null,
  "Limpar todos os filtros"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Não é possível encontrar nenhum registro usando a combinação atual de filtros."
 ],
 "No logs found": [
  null,
  "Nenhum log encontrado"
 ],
 "Load earlier entries": [
  null,
  "Carregar logs anteriores"
 ],
 "You may try to load older entries.": [
  null,
  "Você pode tentar carregar entradas mais antigas."
 ],
 "Allow running (unmask)": [
  null,
  "Permitir a execução (desmascarar)"
 ],
 "Reload": [
  null,
  "Recarregar"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Clear 'Failed to start'": [
  null,
  "Limpar 'Falha ao iniciar'"
 ],
 "Mask service": [
  null,
  "Serviço de máscara"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "O serviço de mascaramento impede a execução de todas as unidades dependentes. Isso pode ter um impacto maior do que o previsto. Confirme que deseja mascarar esta unidade."
 ],
 "Disallow running (mask)": [
  null,
  "Não permitir execução (máscara)"
 ],
 "Unpin unit": [
  null,
  "Desafixar unidade"
 ],
 "Pin unit": [
  null,
  "Fixar unidade"
 ],
 "Additional actions": [
  null,
  "Ações adicionais"
 ],
 "Note": [
  null,
  "Nota"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Esta unidade não foi projetada para ser habilitada explicitamente."
 ],
 "Forbidden from running": [
  null,
  "Proibido executar"
 ],
 "Start service": [
  null,
  "Começar serviço"
 ],
 "Active since ": [
  null,
  "Ativo desde "
 ],
 "Required by ": [
  null,
  "Solicitado por "
 ],
 "Read-only": [
  null,
  "Somente leitura"
 ],
 "Requires administration access to edit": [
  null,
  "Requer acesso administrativo para editar"
 ],
 "Automatically starts": [
  null,
  "Inicia automaticamente"
 ],
 "Updating status...": [
  null,
  "Status das atualizações..."
 ],
 "Stop and disable": [
  null,
  "Parar e desabilitar"
 ],
 "Start and enable": [
  null,
  "Iniciar e habilitar"
 ],
 "Failed to load unit": [
  null,
  "Falha ao carregar unidade"
 ],
 "View all services": [
  null,
  "Ver todos os serviços"
 ],
 "Triggers": [
  null,
  "Disparadores"
 ],
 "Triggered by": [
  null,
  "Disparado por"
 ],
 "Requires": [
  null,
  "Requer"
 ],
 "Requisite": [
  null,
  "Requisita"
 ],
 "Wants": [
  null,
  "Deseja"
 ],
 "Binds to": [
  null,
  "Vincula a"
 ],
 "Part of": [
  null,
  "Parte de"
 ],
 "Required by": [
  null,
  "Solicitado por"
 ],
 "Requisite of": [
  null,
  "Requisitode"
 ],
 "Wanted by": [
  null,
  "Requerido por"
 ],
 "Bound by": [
  null,
  "Vinculado pela"
 ],
 "Consists of": [
  null,
  "Consiste em"
 ],
 "Conflicts": [
  null,
  "Conflita"
 ],
 "Conflicted by": [
  null,
  "Conflito por"
 ],
 "Before": [
  null,
  "Antes"
 ],
 "After": [
  null,
  "Após"
 ],
 "On failure": [
  null,
  "Em Falha"
 ],
 "Propagates reload to": [
  null,
  "Propaga Recarregar para"
 ],
 "Reload propagated from": [
  null,
  "Recarregar propagado de"
 ],
 "Joins namespace of": [
  null,
  "Junte os espaços nos nomes de"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condição $0=$1 não foi cumprida"
 ],
 "Deletion will remove the following files:": [
  null,
  "A exclusão vai remover os seguintes arquivos:"
 ],
 "Pinned unit": [
  null,
  "Unidade fixada"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Path": [
  null,
  "Caminho"
 ],
 "Listen": [
  null,
  "Ouvindo"
 ],
 "Container": [
  null,
  "Contêiner"
 ],
 "View Podman container": [
  null,
  "Ver contêiner Podman"
 ],
 "Condition failed": [
  null,
  "Condição falhou"
 ],
 "Show more relationships": [
  null,
  "Mostrar mais relações"
 ],
 "Show relationships": [
  null,
  "Mostrar relações"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmar a exclusão de $0"
 ],
 "Timer deletion failed": [
  null,
  "Exclusão de temporizador falhou"
 ],
 "Targets": [
  null,
  "Alvos"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Timers": [
  null,
  "Temporizadores"
 ],
 "Paths": [
  null,
  "Caminhos"
 ],
 "Go to $0": [
  null,
  "Ir para $0"
 ],
 "Journal entry not found": [
  null,
  "Entrada do diário não encontrada"
 ],
 "Journal entry": [
  null,
  "Entrada do diário"
 ],
 "Entry at $0": [
  null,
  "Entrada em $0"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Loading unit failed": [
  null,
  "Falha ao carregar unidade"
 ],
 "Service logs": [
  null,
  "Nenhuma entrada de log"
 ],
 "No log entries": [
  null,
  "Nenhuma entrada de log"
 ],
 "Systemd units": [
  null,
  "Unidades do systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Nenhum resultado corresponde aos critérios de filtro. Limpe todos os filtros para mostrar resultados."
 ],
 "Does not automatically start": [
  null,
  "Não inicia automaticamente"
 ],
 "Cannot be enabled": [
  null,
  "Não pode ser habilitado"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Console web está em execução no modo acesso limitado."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuração e resolução de problemas do Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "de $0 em $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "desde $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "em $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domínio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Ingressar em um domínio"
 ]
});
