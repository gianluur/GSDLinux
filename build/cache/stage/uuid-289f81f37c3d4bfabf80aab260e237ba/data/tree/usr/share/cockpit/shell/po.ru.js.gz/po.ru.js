cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Comment": [
  null,
  "Комментарий"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Fingerprint": [
  null,
  "Отпечаток"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Change password": [
  null,
  "Изменить пароль"
 ],
 "Password changed successfully": [
  null,
  "Пароль успешно изменён"
 ],
 "New password": [
  null,
  "Новый пароль"
 ],
 "Confirm password": [
  null,
  "Подтвердите пароль"
 ],
 "Password tip": [
  null,
  "Подсказка для пароля"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Совет: сделайте пароль ключа и пароль для входа в систему одинаковыми для автоматической проверки подлинности в других системах."
 ],
 "Unlock key $0": [
  null,
  "Разблокирование ключа $0"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Add private SSH key": [
  null,
  "Добавить закрытый SSH-ключ"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "SSH keys": [
  null,
  "SSH-ключи"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Используйте следующие ключи для проверки подлинности в других системах"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Toggle": [
  null,
  "Переключить"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Public key": [
  null,
  "Открытый ключ"
 ],
 "Use key": [
  null,
  "Использовать ключ"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Hosts": [
  null,
  "Узлы"
 ],
 "Connection error": [
  null,
  "Ошибка подключения"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Add new host": [
  null,
  "Добавить новый узел"
 ],
 "Host": [
  null,
  "Узел"
 ],
 "Stop editing hosts": [
  null,
  "Закончить изменение узлов"
 ],
 "Edit hosts": [
  null,
  "Изменить узлы"
 ],
 "active": [
  null,
  "активно"
 ],
 "Active pages": [
  null,
  "Активные страницы"
 ],
 "Page name": [
  null,
  "Название страницы"
 ],
 "There are currently no active pages": [
  null,
  "В настоящее время нет активных страниц"
 ],
 "Close selected pages": [
  null,
  "Закрыть выделенные страницы"
 ],
 "$0 documentation": [
  null,
  "Документация $0"
 ],
 "About Web Console": [
  null,
  "О веб-консоли"
 ],
 "Style": [
  null,
  "Внешний вид"
 ],
 "Default": [
  null,
  "По умолчанию"
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Display language": [
  null,
  "Язык интерфейса"
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Ooops!": [
  null,
  "Упс!"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Session": [
  null,
  "Сеанс"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Распространяется на условиях лицензии GNU LGPL, версия 2.1"
 ],
 "Web Console": [
  null,
  "Веб-консоль"
 ],
 "Web console logo": [
  null,
  "Логотип веб-консоли"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit — это интерактивный интерфейс администратора серверов Linux."
 ],
 "Project website": [
  null,
  "Веб-сайт проекта"
 ],
 "Loading packages...": [
  null,
  "Загрузка пакетов…"
 ],
 "Choose the language to be used in the application": [
  null,
  "Выберите язык, который будет использоваться в приложении"
 ],
 "Filter menu items": [
  null,
  "Фильтровать элементы меню"
 ],
 "No languages match": [
  null,
  "Ни один язык не подходит"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "У Cockpit произошла неожиданная внутренняя ошибка."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "in most browsers": [
  null,
  "в большинстве браузеров"
 ],
 "System": [
  null,
  "Система"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "Clear search": [
  null,
  "Сбросить поиск"
 ],
 "Contains:": [
  null,
  "Содержит:"
 ],
 "Apps": [
  null,
  "Приложения"
 ],
 "Tools": [
  null,
  "Инструменты"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Не удалось установить связь c заданным узлом $0. Убедитесь, что на порте $1 работает SSH или укажите в адресе другой порт."
 ],
 "Connect to $0?": [
  null,
  "Подключиться к $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Подключенные хосты могут полностью контролировать друг друга. Это включает в себя запуск программ, которые могут нанести вред вашей системе или похитить данные. Подключайтесь только к доверенным компьютерам."
 ],
 "Read more": [
  null,
  "Подробнее"
 ],
 "You will be reminded once per session.": [
  null,
  "Вам будет отправляться напоминание один раз за сессию."
 ],
 "Connect": [
  null,
  "Подключиться"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-адрес или имя узла не могут содержать пробелы."
 ],
 "This machine has already been added.": [
  null,
  "Этот компьютер уже добавлен."
 ],
 "Failed to add machine: $0": [
  null,
  "Не удалось добавить компьютер: $0"
 ],
 "Edit host": [
  null,
  "Изменить узел"
 ],
 "Set": [
  null,
  "Настроить"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Может быть именем узла, IP-адресом, псевдонимом или ssh:// URI"
 ],
 "When empty, connect with the current user": [
  null,
  "При отсутствии значения соединение будет осуществляться от текущего пользователя"
 ],
 "Color": [
  null,
  "Цвет"
 ],
 "Failed to edit machine: $0": [
  null,
  "Не удалось изменить компьютер: $0"
 ],
 "Could not contact $0": [
  null,
  "Не удалось связаться с $0"
 ],
 "Update": [
  null,
  "Обновить"
 ],
 "Unable to contact $0.": [
  null,
  "Не удалось установить связь с $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "Работает ли sshd на другом порту?"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "$0 key changed": [
  null,
  "Изменён $0 ключ"
 ],
 "New host: $0": [
  null,
  "Новый хост: $0"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Вредоносные страницы на удалённом компьютере могут повлиять на другие подключённые хосты"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "The new key password can not be empty": [
  null,
  "Новый пароль ключа не может быть пустым"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль. Для автоматического входа следует настроить SSH-ключи."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Может потребоваться смена пароля ключа для автоматического входа."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "В целях обеспечения дальнейшего входа без пароля на $0 как $1, можно в качестве пароля ключа использовать пароль для входа $2 на $3 или оставить поле для пароля ключа пустым."
 ],
 "Change the password of $0": [
  null,
  "Изменить пароль для $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Если изменить пароль ключа SSH $0 на пароль для входа $1 на $2, ключ будет автоматически доступен, и вы в будущем сможете входить в $3 без пароля."
 ],
 "New key password": [
  null,
  "Новый пароль ключа"
 ],
 "Confirm new key password": [
  null,
  "Подтвердите новый ключевой пароль"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "В дальнейшем это позволит выполнять вход без ввода пароля."
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "Automatic login": [
  null,
  "Автоматический вход"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Вы вышли из системы из-за неактивности."
 ],
 "Connection failed": [
  null,
  "Ошибка подключения"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Произошла непредвиденная ошибка при подключении к компьютеру."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Сообщения, связанные с ошибкой, могут быть найдены в журнале:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Пользователям Safari необходимо импортировать и установить доверие к самозаверенному сертификату центра сертификации:"
 ],
 "Reconnect": [
  null,
  "Переподключиться"
 ],
 "Disconnected": [
  null,
  "Отключено"
 ],
 "The machine is rebooting": [
  null,
  "Компьютер перезагружается"
 ],
 "Connecting to the machine": [
  null,
  "Подключение к компьютеру"
 ],
 "Not connected to host": [
  null,
  "Отсутствует подключение к узлу"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Не удаётся подключиться к неизвестному компьютеру"
 ],
 "Session is about to expire": [
  null,
  "Сессия истекает"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Вы выйдете из системы через $0 секунд."
 ],
 "Continue session": [
  null,
  "Продолжить сессию"
 ],
 "Skip to content": [
  null,
  "Перейти к содержимому"
 ],
 "Skip main navigation": [
  null,
  "Пропустить основную навигацию"
 ],
 "Permission denied": [
  null,
  "Отказано в доступе"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Create $0": [
  null,
  "Создать $0"
 ],
 "Ok": [
  null,
  "ОК"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "You now have administrative access.": [
  null,
  "Получены права администратора."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Нет доступных методов получения административного доступа (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Пройдите проверку подлинности для получения прав администратора"
 ],
 "Switch to administrative access": [
  null,
  "Переключиться на доступ с правами администратора"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Problem becoming administrator": [
  null,
  "При получении прав администратора возникли проблемы"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Ограничить доступ"
 ],
 "Switch to limited access": [
  null,
  "Переключится на ограниченный доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "В ограниченном режиме доступа ограничиваются полномочия администратора. В некоторых разделах веб-консоли будет урезаны функциональные возможности."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Браузер запоминает уровень доступа от сеанса к сеансу."
 ],
 "Limited access": [
  null,
  "Ограниченный доступ"
 ],
 "Turn on administrative access": [
  null,
  "Включить доступ с правами администратора"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "less than a minute ago": [
  null,
  "менее минуты назад"
 ],
 "in less than a minute": [
  null,
  "менее минуты"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного ПО"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Unknown host: $0": [
  null,
  "Неизвестный хост: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль."
 ],
 "SSH key login": [
  null,
  "Вход с помощью SSH-ключа"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit передал код ошибки $0"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Ошибка при инициализации"
 ],
 "Failed": [
  null,
  "Ошибка"
 ],
 "Home": [
  null,
  "Домашний каталог"
 ],
 "Downloads": [
  null,
  "Загрузки"
 ],
 "Not a directory": [
  null,
  "Не является каталогом"
 ],
 "All files": [
  null,
  "Все файлы"
 ],
 "Recent": [
  null,
  "Недавние"
 ],
 "No recent directories": [
  null,
  "Нет недавних каталогов"
 ],
 "No recent files": [
  null,
  "Нет недавних файлов"
 ],
 "Type to filter": [
  null,
  "Введите условия фильтра"
 ],
 "File chooser actions": [
  null,
  "Действия выбора файлов"
 ],
 "Open in file browser": [
  null,
  "Открыть в файловом менеджере"
 ],
 "Hide hidden files": [
  null,
  "Скрыть скрытые файлы"
 ],
 "Show hidden files": [
  null,
  "Показывать скрытые файлы"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Clear filters": [
  null,
  "Очистить фильтры"
 ],
 "Directory is empty": [
  null,
  "Каталог пуст"
 ],
 "Directory has no sub-directories": [
  null,
  "Каталог не содержит подкаталогов"
 ],
 "This directory contains only hidden files": [
  null,
  "Этот каталог содержит только скрытые файлы"
 ],
 "No matching results": [
  null,
  "Нет подходящих результатов"
 ],
 "Folder": [
  null,
  "Папка"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Select an option": [
  null,
  "Выбор опции"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск. Он поддерживает следующие цели дампа: «local» (диск), «ssh» и «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ]
});
