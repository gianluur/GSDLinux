cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : (n==0 || (n%100 > 0 && n%100 < 20)) ? 1 : 2),
  "language": "ro",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Schimbarea cheilor este adesea rezultatul reinstalării sistemului de operare. Cu toate acestea, o schimbare neașteptată poate indica o încercare a unei terțe părți de a vă intercepta conexiunea."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pentru a vă asigura că conexiunea dumneavoastră nu este interceptată de o terță parte rău intenționată, vă rugăm să verificați amprenta cheii gazdei:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică."
 ],
 "User name": [
  null,
  "Numele utilizatorului"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Conectează-te"
 ],
 "Cancel": [
  null,
  "Anulează"
 ],
 "Networking": [
  null,
  "Rețea"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Stocare"
 ],
 "Diagnostic reports": [
  null,
  "Rapoarte de diagnostic"
 ],
 "Comment": [
  null,
  "Comentariu"
 ],
 "Type": [
  null,
  "Tip"
 ],
 "Fingerprint": [
  null,
  "Amprenta digitală"
 ],
 "Copy": [
  null,
  "Copiază"
 ],
 "Copied": [
  null,
  "Copiat"
 ],
 "Change password": [
  null,
  "Schimbă parola"
 ],
 "Password changed successfully": [
  null,
  "Parola a fost schimbată cu succes"
 ],
 "New password": [
  null,
  "Parolă nouă"
 ],
 "Confirm password": [
  null,
  "Confirmă parola"
 ],
 "Password tip": [
  null,
  "Sfat privind parola"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Sfat: Asigurați-vă că parola cheii dvs. este aceeași cu parola de autentificare, pentru a vă autentifica automat în alte sisteme."
 ],
 "Unlock key $0": [
  null,
  "Cheie de deblocare $0"
 ],
 "Unlock": [
  null,
  "Deblochează"
 ],
 "Add private SSH key": [
  null,
  "Adaugă cheia privată SSH"
 ],
 "Add key": [
  null,
  "Adaugă cheie"
 ],
 "SSH keys": [
  null,
  "Chei SSH"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Utilizați următoarele chei pentru autentificarea în alte sisteme"
 ],
 "Name": [
  null,
  "Nume"
 ],
 "Toggle": [
  null,
  "Activează/dezactivează"
 ],
 "Details": [
  null,
  "Detalii"
 ],
 "Public key": [
  null,
  "Cheie publică"
 ],
 "Use key": [
  null,
  "Utilizează cheia"
 ],
 "Close": [
  null,
  "Închide"
 ],
 "Hosts": [
  null,
  "Gazde"
 ],
 "Connection error": [
  null,
  "Eroare de conexiune"
 ],
 "Edit": [
  null,
  "Editare"
 ],
 "Remove": [
  null,
  "Elimină"
 ],
 "Add new host": [
  null,
  "Adaugă o nouă gazdă"
 ],
 "Host": [
  null,
  "Gazda"
 ],
 "Stop editing hosts": [
  null,
  "Oprește editarea gazdelor"
 ],
 "Edit hosts": [
  null,
  "Editează gazdele"
 ],
 "active": [
  null,
  "activă"
 ],
 "Active pages": [
  null,
  "Pagini active"
 ],
 "Page name": [
  null,
  "Numele paginii"
 ],
 "There are currently no active pages": [
  null,
  "În prezent nu există pagini active"
 ],
 "Close selected pages": [
  null,
  "Închide paginile selectate"
 ],
 "$0 documentation": [
  null,
  "Documentație $0"
 ],
 "About Web Console": [
  null,
  "Despre consola web"
 ],
 "Style": [
  null,
  "Stil"
 ],
 "Default": [
  null,
  "Implicită"
 ],
 "Light": [
  null,
  "Luminoasă"
 ],
 "Dark": [
  null,
  "Întunecată"
 ],
 "Display language": [
  null,
  "Limba de afișare"
 ],
 "Log out": [
  null,
  "Ieșire din sesiune"
 ],
 "Ooops!": [
  null,
  "Ups!"
 ],
 "Help": [
  null,
  "Ajutor"
 ],
 "Session": [
  null,
  "Sesiune"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licențiat sub termenii GNU LGPL versiunea 2.1"
 ],
 "Web Console": [
  null,
  "Consola web"
 ],
 "Web console logo": [
  null,
  "Logo-ul consolei web"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit este o interfață interactivă de administrare a serverelor Linux."
 ],
 "Project website": [
  null,
  "Situl web al proiectului"
 ],
 "Loading packages...": [
  null,
  "Se încarcă lista pachetele..."
 ],
 "Choose the language to be used in the application": [
  null,
  "Alegeți limba care va fi utilizată în aplicație"
 ],
 "Filter menu items": [
  null,
  "Filtrează elementele din meniu"
 ],
 "No languages match": [
  null,
  "Nu s-au găsit limbi ce să coincidă"
 ],
 "Select": [
  null,
  "Selectează"
 ],
 "Unexpected error": [
  null,
  "Eroare neașteptată"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit a înregistrat o eroare internă neașteptată."
 ],
 "Ctrl-Shift-I": [
  null,
  "«Ctrl-Shift-I»"
 ],
 "in most browsers": [
  null,
  "în majoritatea navigatoarelor"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Search": [
  null,
  "Caută"
 ],
 "No results found": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Clear search": [
  null,
  "Șterge căutarea"
 ],
 "Contains:": [
  null,
  "Conține:"
 ],
 "Apps": [
  null,
  "Aplicații"
 ],
 "Tools": [
  null,
  "Instrumente"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nu este instalat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Pe $0 nu este instalată o versiune compatibilă a Cockpit."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Nu se poate stabili conexiunea cu gazda $0. Asigurați-vă că pe portul $1 rulează SSH sau specificați un alt port în adresă."
 ],
 "Connect to $0?": [
  null,
  "Conectare la $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Mașinile conectate se pot controla reciproc în totalitate. Aceasta include rularea de programe care ar putea afecta sistemul sau fura date. Conectați-vă numai la mașini de încredere."
 ],
 "Read more": [
  null,
  "Citește mai mult"
 ],
 "You will be reminded once per session.": [
  null,
  "Veți primi o notificare-memento o dată pe sesiune."
 ],
 "Connect": [
  null,
  "Conectare"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Adresa IP sau numele de gazdă nu pot conține spații."
 ],
 "This machine has already been added.": [
  null,
  "Această mașină a fost deja adăugată."
 ],
 "Failed to add machine: $0": [
  null,
  "Adăugarea mașinii a eșuat: $0"
 ],
 "Edit host": [
  null,
  "Editează gazda"
 ],
 "Set": [
  null,
  "Stabilește"
 ],
 "Add": [
  null,
  "Adaugă"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Poate fi un nume de gazdă, o adresă IP, un alias sau o adresă URI de tip ssh://"
 ],
 "When empty, connect with the current user": [
  null,
  "Când este gol, vă conectați cu utilizatorul curent"
 ],
 "Color": [
  null,
  "Culoare"
 ],
 "Failed to edit machine: $0": [
  null,
  "Editarea mașinii a eșuat: $0"
 ],
 "Could not contact $0": [
  null,
  "Nu s-a putut contacta $0"
 ],
 "Update": [
  null,
  "Actualizare"
 ],
 "Unable to contact $0.": [
  null,
  "Nu s-a putut stabili legătura cu $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "Serviciul sshd rulează pe un alt port?"
 ],
 "Port": [
  null,
  "Port"
 ],
 "$0 key changed": [
  null,
  "Cheia $0 a fost schimbată"
 ],
 "New host: $0": [
  null,
  "Gazdă nouă: $0"
 ],
 "Trust and add host": [
  null,
  "Am încredere, adaugă gazda"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pentru a verifica o amprentă digitală, executați următoarea comandă pe $0, fie fizic, de la mașină, fie printr-o rețea de încredere:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Dacă amprenta digitală se potrivește, faceți clic pe „Am încredere, adaugă gazda”. În caz contrar, nu vă conectați și contactați administratorul."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Amprenta digitală obținută poate fi partajată fără probleme prin mijloace publice, inclusiv prin poșta electronică. Dacă îi ceri altcuiva să efectueze verificarea în locul tău, acea persoană îți poate trimite rezultatele prin orice metodă."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vă conectați la $0 pentru prima dată."
 ],
 "Verify fingerprint": [
  null,
  "Verifică amprenta digitală"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Executați această comandă într-o rețea de încredere sau direct pe mașina la distanță:"
 ],
 "The fingerprint should match:": [
  null,
  "Amprenta digitală trebuie să se potrivească:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Paginile rău intenționate de pe o mașină la distanță pot afecta alte gazde conectate"
 ],
 "The password can not be empty": [
  null,
  "Parola nu poate fi goală"
 ],
 "The key password can not be empty": [
  null,
  "Parola cheii nu poate fi goală"
 ],
 "The key passwords do not match": [
  null,
  "Parolele cheii nu se potrivesc"
 ],
 "The new key password can not be empty": [
  null,
  "Parola nouă a cheii nu poate fi goală"
 ],
 "Log in to $0": [
  null,
  "Conectează-te la $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nu se poate efectua autentificarea la $0. Gazda nu acceptă autentificarea cu parolă și niciuna dintre cheile dvs. SSH."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Nu se poate efectua autentificarea pe $0 folosind autentificarea prin cheie SSH. Vă rugăm să introduceți parola. Vă recomandăm să configurați cheile SSH pentru autentificare automată."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată de o parolă, iar serverul nu permite autentificarea cu o parolă. Vă rugăm să introduceți parola cheii la $1."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Poate doriți să schimbați parola cheii pentru autentificarea automată."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Cheia SSH pentru autentificarea la $0 este protejată. Vă puteți autentifica fie folosind parola de acces, fie introducând parola cheii la $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Creează o nouă cheie SSH și-o autorizează"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se va crea o nouă cheie SSH la $0 pentru $1 pe $2, iar aceasta va fi adăugată la fișierul $3 al lui $4 pe $5."
 ],
 "Key password": [
  null,
  "Parola cheii"
 ],
 "Confirm key password": [
  null,
  "Confirmă parola cheii"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Pentru a permite în viitor autentificarea utilizatorului $0 ca $1 fără parolă, folosiți parola de autentificare a utilizatorului $2 pentru contul $3 ca parolă de acces sau lăsați câmpul pentru parola de acces necompletat."
 ],
 "Change the password of $0": [
  null,
  "Schimbă parola pentru $0"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Prin schimbarea parolei cheii SSH $0 cu parola de autentificare a contului $1 pe serverul $2, cheia va deveni automat disponibilă și, pe viitor, vă veți putea autentifica pe $3 fără parolă."
 ],
 "New key password": [
  null,
  "Parolă nouă pentru cheie"
 ],
 "Confirm new key password": [
  null,
  "Confirmă noua parolă a cheii"
 ],
 "Authorize SSH key": [
  null,
  "Autorizează cheia SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Cheia SSH $0 din $1 de pe $2 va fi adăugată la fișierul $3 din $4 de pe $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Astfel, pe viitor vă veți putea autentifica fără parolă."
 ],
 "Authentication": [
  null,
  "Autentificare"
 ],
 "SSH key": [
  null,
  "Cheie SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Cheia SSH $0 va fi disponibilă pe durata restului sesiunii și va putea fi utilizată și pentru conectarea la alte gazde."
 ],
 "Automatic login": [
  null,
  "Autentificare automată"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Ați fost deconectat din cauza inactivității."
 ],
 "Connection failed": [
  null,
  "Conectare eșuată"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "A apărut o eroare neașteptată în timpul conectării la mașină."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Mesajele legate de eroare pot fi găsite în jurnal:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Utilizatorii Safari trebuie să importe și să accepte certificatul autorității de certificare auto-semnat:"
 ],
 "Reconnect": [
  null,
  "Reconectare"
 ],
 "Disconnected": [
  null,
  "Deconectat"
 ],
 "The machine is rebooting": [
  null,
  "Mașina se repornește"
 ],
 "Connecting to the machine": [
  null,
  "Se efectuează conectarea la mașină"
 ],
 "Not connected to host": [
  null,
  "Nu este conectat la gazdă"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nu se poate stabili conexiunea cu o gazdă necunoscută"
 ],
 "Session is about to expire": [
  null,
  "Sesiunea este pe cale să expire"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Veți fi deconectat în $0 secunde."
 ],
 "Continue session": [
  null,
  "Continuă sesiunea"
 ],
 "Skip to content": [
  null,
  "Treci direct la conținut"
 ],
 "Skip main navigation": [
  null,
  "Omite navigarea principală"
 ],
 "Permission denied": [
  null,
  "Permisiune refuzată"
 ],
 "Clear input value": [
  null,
  "Șterge valoarea introdusă"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de dată incorect și format de oră incorect"
 ],
 "Invalid time format": [
  null,
  "Format de oră nevalid"
 ],
 "Invalid date format": [
  null,
  "Format de dată incorect"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nu se poate planifica un eveniment în trecut"
 ],
 "No delay": [
  null,
  "Fără întârziere"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minute"
 ],
 "20 minutes": [
  null,
  "20 de minute"
 ],
 "40 minutes": [
  null,
  "40 de minute"
 ],
 "60 minutes": [
  null,
  "60 de minute"
 ],
 "Specific time": [
  null,
  "Momentul specificat"
 ],
 "Shut down": [
  null,
  "Oprire"
 ],
 "Reboot": [
  null,
  "Repornire"
 ],
 "Message to logged in users": [
  null,
  "Mesaj pentru utilizatorii autentificați"
 ],
 "Delay": [
  null,
  "Întârziere"
 ],
 "Pick date": [
  null,
  "Alegeți data"
 ],
 "Toggle date picker": [
  null,
  "Activează/dezactivează selectorul de dată"
 ],
 "Synchronized": [
  null,
  "Sincronizat"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizat cu $0"
 ],
 "Synchronizing": [
  null,
  "Se sincronizează"
 ],
 "Trying to synchronize with $0": [
  null,
  "Se încearcă sincronizarea cu $0"
 ],
 "Not synchronized": [
  null,
  "Nu este sincronizat"
 ],
 "Log messages": [
  null,
  "Mesaje de jurnal"
 ],
 "NTP server": [
  null,
  "server NTP"
 ],
 "Manually": [
  null,
  "În mod manual"
 ],
 "Automatically using NTP": [
  null,
  "Utilizând NTP în mod automat"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilizând în mod automat servere NTP suplimentare"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizând în mod automat servere NTP specifice"
 ],
 "Time zone": [
  null,
  "Fusul orar"
 ],
 "Set time": [
  null,
  "Ajustează ora"
 ],
 "Invalid timezone": [
  null,
  "Fus orar nevalid"
 ],
 "Need at least one NTP server": [
  null,
  "Este necesar cel puțin un server NTP"
 ],
 "Change system time": [
  null,
  "Schimbă ora sistemului"
 ],
 "Change": [
  null,
  "Modifică"
 ],
 "Path to file": [
  null,
  "Ruta către fișier"
 ],
 "No such file or directory": [
  null,
  "Nu există un astfel de fișier sau director"
 ],
 "Create $0": [
  null,
  "Creează $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Află mai multe"
 ],
 "You now have administrative access.": [
  null,
  "Acum aveți acces de administrator."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nu sunt disponibile metode pentru a obține acces administrativ (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentificați-vă pentru a obține acces administrativ"
 ],
 "Switch to administrative access": [
  null,
  "Treceți la acces administrativ"
 ],
 "Authenticate": [
  null,
  "Autentifica"
 ],
 "Administrative access": [
  null,
  "Acces administrativ"
 ],
 "Problem becoming administrator": [
  null,
  "Probleme în devenirea administrator"
 ],
 "Method": [
  null,
  "Metodă"
 ],
 "Limit access": [
  null,
  "Limitează accesul"
 ],
 "Switch to limited access": [
  null,
  "Treceți la acces limitat"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Modul de acces limitat restricționează privilegiile administrative. Anumite secțiuni ale consolei web vor avea funcționalități reduse."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Navigatorul dvs. va reține nivelul dvs. de acces între sesiuni."
 ],
 "Limited access": [
  null,
  "Acces limitat"
 ],
 "Turn on administrative access": [
  null,
  "Activează accesul de administrator"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ani",
  "$0 de ani"
 ],
 "$0 month": [
  null,
  "$0 lună",
  "$0 luni",
  "$0 de luni"
 ],
 "$0 week": [
  null,
  "$0 săptămână",
  "$0 săptămâni",
  "$0 de săptămâni"
 ],
 "$0 day": [
  null,
  "$0 zi",
  "$0 zile",
  "$0 de zile"
 ],
 "$0 hour": [
  null,
  "$0 oră",
  "$0 ore",
  "$0 de ore"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minute",
  "$0 de minute"
 ],
 "Go to now": [
  null,
  "Mergi la acum"
 ],
 "1 hour": [
  null,
  "1 oră"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 zi"
 ],
 "1 week": [
  null,
  "1 săptămână"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nu s-a putut activa $0 în firewalld"
 ],
 "Visit firewall": [
  null,
  "Accedeți la paravanul de protecție"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Adaugă $0"
 ],
 "less than a minute ago": [
  null,
  "acum mai puțin de un minut"
 ],
 "in less than a minute": [
  null,
  "în mai puțin de un minut"
 ],
 "Password is too weak": [
  null,
  "Parola este prea slabă (este ușor de ghicit)"
 ],
 "Excellent password": [
  null,
  "Parolă excelentă"
 ],
 "Password is not acceptable": [
  null,
  "Parola nu este acceptabilă"
 ],
 "Strong password": [
  null,
  "Parolă puternică"
 ],
 "Acceptable password": [
  null,
  "Parolă acceptabilă"
 ],
 "Weak password": [
  null,
  "Parolă slabă (ușor de ghicit)"
 ],
 "Show password": [
  null,
  "Afișează parola"
 ],
 "Hide password": [
  null,
  "Ascunde parola"
 ],
 "password quality": [
  null,
  "calitatea parolei"
 ],
 "Show confirmation password": [
  null,
  "Afișează parola de confirmare"
 ],
 "Hide confirmation password": [
  null,
  "Ascunde parola de confirmare"
 ],
 "Additional packages:": [
  null,
  "Pachete suplimentare:"
 ],
 "Removals:": [
  null,
  "Eliminare:"
 ],
 "Total size: $0": [
  null,
  "Dimensiunea totală: $0"
 ],
 "Install software": [
  null,
  "Instalează software-ul"
 ],
 "$0 will be installed.": [
  null,
  "$0 va fi instalat."
 ],
 "Install": [
  null,
  "Instalează"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Se așteaptă finalizarea altor operații de gestionare a software-ului"
 ],
 "Checking installed software": [
  null,
  "Se verifică software-ul instalat"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nu este disponibil din niciun depozit."
 ],
 "Downloading $0": [
  null,
  "Se descarcă $0"
 ],
 "Removing $0": [
  null,
  "Se elimină $0"
 ],
 "Installing $0": [
  null,
  "Se instalează $0"
 ],
 "Unknown host: $0": [
  null,
  "Gazdă necunoscută: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nu se poate efectua autentificarea la $0 folosind autentificarea cu cheie SSH. Vă rugăm să introduceți parola."
 ],
 "SSH key login": [
  null,
  "Autentificare cu cheie SSH"
 ],
 "[no data]": [
  null,
  "[nu există date]"
 ],
 "[binary data]": [
  null,
  "[date binare]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit s-a prăbușit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit a raportat codul de eroare $0"
 ],
 "show less": [
  null,
  "afișează mai puțin"
 ],
 "show more": [
  null,
  "afișează mai mult"
 ],
 "Row expansion": [
  null,
  "Extinderea rândului"
 ],
 "Row select": [
  null,
  "Selectare rând"
 ],
 "Ctrl+Insert": [
  null,
  "«Ctrl+Insert»"
 ],
 "Paste": [
  null,
  "Lipește"
 ],
 "Shift+Insert": [
  null,
  "«Shift+Insert»"
 ],
 "Paste error": [
  null,
  "Eroare la lipire"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Navigatorul dvs. nu permite lipirea din meniul contextual. Puteți folosi combinația de taste «Shift+Insert»."
 ],
 "Error during initialization": [
  null,
  "Eroare în timpul inițializării"
 ],
 "Failed": [
  null,
  "Nu a funcționat"
 ],
 "Home": [
  null,
  "Acasă"
 ],
 "Downloads": [
  null,
  "Descărcări"
 ],
 "Not a directory": [
  null,
  "Nu este un director"
 ],
 "All files": [
  null,
  "Toate fișierele"
 ],
 "Recent": [
  null,
  "Recente"
 ],
 "No recent directories": [
  null,
  "Nu există directoare recente"
 ],
 "No recent files": [
  null,
  "Nu există fișiere recente"
 ],
 "Type to filter": [
  null,
  "Tastați pentru a filtra"
 ],
 "File chooser actions": [
  null,
  "Acțiuni ale selectorului de fișiere"
 ],
 "Open in file browser": [
  null,
  "Deschide în exploratorul de fișiere"
 ],
 "Hide hidden files": [
  null,
  "Ascunde elementele ascunse"
 ],
 "Show hidden files": [
  null,
  "Afișează fișierele ascunse"
 ],
 "Filesystem": [
  null,
  "Sistem de fișiere"
 ],
 "Clear filters": [
  null,
  "Șterge filtrele"
 ],
 "Directory is empty": [
  null,
  "Directorul este gol"
 ],
 "Directory has no sub-directories": [
  null,
  "Directorul nu conține subdirectoare"
 ],
 "This directory contains only hidden files": [
  null,
  "Acest director conține doar fișiere ascunse"
 ],
 "No matching results": [
  null,
  "Nu s-au găsit rezultate"
 ],
 "Folder": [
  null,
  "Dosar"
 ],
 "File": [
  null,
  "Fișier"
 ],
 "Copy to clipboard": [
  null,
  "Copiază în clipboard"
 ],
 "Automation script": [
  null,
  "Script de automatizare"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Creează un fișier de sarcini nou cu acest conținut."
 ],
 "Ansible roles documentation": [
  null,
  "Documentația privind rolurile Ansible"
 ],
 "Shell script": [
  null,
  "script Shell"
 ],
 "No system modifications": [
  null,
  "Nicio modificare a sistemului"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Utilizatorul conectat nu are permisiunea de a vizualiza modificările aduse sistemului"
 ],
 "Loading system modifications...": [
  null,
  "Se încarcă modificările aduse sistemului..."
 ],
 "View automation script": [
  null,
  "Vizualizează scriptul de automatizare"
 ],
 "Occurrences": [
  null,
  "Apariții"
 ],
 "View all logs": [
  null,
  "Vizualizează toate jurnalele"
 ],
 "Other": [
  null,
  "Alta"
 ],
 "Unknown": [
  null,
  "Necunoscută"
 ],
 "Desktop": [
  null,
  "Calculator de birou"
 ],
 "Low profile desktop": [
  null,
  "Calculator de birou cu profil redus"
 ],
 "Pizza box": [
  null,
  "„Pizza box”"
 ],
 "Mini tower": [
  null,
  "Mini turn"
 ],
 "Tower": [
  null,
  "Turn"
 ],
 "Portable": [
  null,
  "Portabil"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Dispozitiv de buzunar"
 ],
 "Docking station": [
  null,
  "Stație de andocare"
 ],
 "All-in-one": [
  null,
  "Toate într-unul"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Calculator compact"
 ],
 "Lunch box": [
  null,
  "„Lunch box”"
 ],
 "Main server chassis": [
  null,
  "Șasiul serverului principal"
 ],
 "Expansion chassis": [
  null,
  "Șasiu de expansiune"
 ],
 "Sub-Chassis": [
  null,
  "Sub-șasiu"
 ],
 "Bus expansion chassis": [
  null,
  "Șasiu de expansiune de magistrală"
 ],
 "Peripheral chassis": [
  null,
  "Șasiu periferic"
 ],
 "RAID chassis": [
  null,
  "Șasiu RAID"
 ],
 "Rack mount chassis": [
  null,
  "Șasiu de montare în rack"
 ],
 "Sealed-case PC": [
  null,
  "PC cu carcasă sigilată"
 ],
 "Multi-system chassis": [
  null,
  "Șasiu multi-sistem"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Advanced TCA": [
  null,
  "TCA avansat"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Servitor blade (lamă)"
 ],
 "Tablet": [
  null,
  "Tabletă"
 ],
 "Convertible": [
  null,
  "Convertibil"
 ],
 "Detachable": [
  null,
  "Detașabil (amovibil)"
 ],
 "IoT gateway": [
  null,
  "Poartă de acces IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrat"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 Gio"
 ],
 "Single rank": [
  null,
  "Rang unic"
 ],
 "Dual rank": [
  null,
  "Rang dual"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Present": [
  null,
  "Prezent"
 ],
 "Old password not accepted": [
  null,
  "Vechea parolă nu este acceptată"
 ],
 "Failed to change password": [
  null,
  "Schimbarea parolei a eșuat"
 ],
 "New password was not accepted": [
  null,
  "Noua parolă nu a fost acceptată"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "A expirat timpul de așteptare pentru generarea cheii prin ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Nu este o cheie privată validă"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A expirat timpul de așteptare pentru adăugarea prin ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Permisiuni de fișier nevalide"
 ],
 "Password not accepted": [
  null,
  "Parola nu este acceptată"
 ],
 "Select an option": [
  null,
  "Selectați o opțiune"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 a fost omorât cu semnalul $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 a ieșit cu codul $1"
 ],
 "$0 failed": [
  null,
  "$0 a eșuat"
 ],
 "Your session has been terminated.": [
  null,
  "Sesiunea dumneavoastră a fost încheiată."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesiunea dumneavoastră a expirat. Vă rugăm să vă autentificați din nou."
 ],
 "Not permitted to perform this action.": [
  null,
  "Nu este permisă efectuarea acestei acțiuni."
 ],
 "Login failed": [
  null,
  "Autentificare eșuată"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serverul a refuzat autentificarea prin orice metodă acceptată."
 ],
 "Untrusted host": [
  null,
  "Gazdă nesigură (nu este de încredere)"
 ],
 "Host key is incorrect": [
  null,
  "Cheia gazdei este incorectă"
 ],
 "Internal error": [
  null,
  "Eroare internă"
 ],
 "Connection has timed out.": [
  null,
  "Timpul de conectare a expirat."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nu este instalat în sistem."
 ],
 "Cannot forward login credentials": [
  null,
  "Nu se pot transmite datele de autentificare"
 ],
 "Server has closed the connection.": [
  null,
  "Serverul a închis conexiunea."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nu este compatibil cu software-ul din sistem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nu a putut stabili legătura cu gazda specificată."
 ],
 "Too much data": [
  null,
  "Prea multe date"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Consola web pentru servere Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit este un gestionator de servere care facilitează administrarea serverelor Linux prin intermediul unui navigator web. Trecerea de la terminal la instrumentul web și invers nu reprezintă nicio problemă. Un serviciu pornit prin Cockpit poate fi oprit prin terminal. La fel, dacă apare o eroare în terminal, aceasta poate fi vizualizată în interfața de jurnal a Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit este ideal pentru administratorii de sistem începători, permițându-le să efectueze cu ușurință sarcini simple, precum administrarea spațiului de stocare, verificarea jurnalelor și pornirea sau oprirea serviciilor. Puteți monitoriza și administra mai multe servere în același timp. Trebuie doar să le adăugați cu un singur clic, iar sistemul se va ocupa de restul."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "După ce Cockpit este instalat, activați-l cu comanda «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurarea Cockpit a NetworkManager și Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Acest instrument gestionează rețelele, cum ar fi legăturile, punțile, grupurile, rețelele VLAN și paravanele de protecție, folosind NetworkManager și Firewalld. NetworkManager nu este compatibil cu scripturile implicite systemd-networkd din Ubuntu și ifupdown din Debian."
 ],
 "Manage storage": [
  null,
  "Gestionează spațiul de stocare"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Acest instrument gestionează spațiul de stocare local, cum ar fi sistemele de fișiere, grupurile de volume LVM2 și montările NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Colectarea și organizarea datelor de diagnosticare și asistență"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Acest instrument generează un fișier de arhivă care conține informații de configurare și diagnosticare din sistemul în funcțiune. Fișierul de arhivă poate fi stocat local sau centralizat în scopuri de înregistrare sau monitorizare sau poate fi trimis reprezentanților serviciului de asistență tehnică, dezvoltatorilor sau administratorilor de sistem pentru a facilita identificarea problemelor tehnice și depanarea."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurarea și soluționarea problemelor în Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Acest instrument configurează politica SELinux și poate fi de ajutor în înțelegerea și rezolvarea încălcărilor politicii."
 ],
 "Collect kernel crash dumps": [
  null,
  "Colectarea fișierelor cu conținutul memoriei în momentul apariției unei erori fatale ale sistemului de către nucleu"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Acest instrument configurează sistemul pentru a genera fișiere cu conținutul memoriei din momentul apariției unei erori fatale de către nucleui. Acesta acceptă destinațiile de salvare „local” (pe disc), „ssh” și „nfs”."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administrare cu ajutorul consolei web Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Este necesară autentificarea pentru a efectua operații cu drepturi speciale în consola web Cockpit"
 ]
});
