cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Kontainer Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "kontainer"
 ],
 "image": [
  null,
  "image"
 ]
});
