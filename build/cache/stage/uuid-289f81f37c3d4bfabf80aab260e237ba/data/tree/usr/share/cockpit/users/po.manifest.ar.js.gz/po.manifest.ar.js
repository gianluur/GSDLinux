cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Accounts": [
  null,
  "الحسابات"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "كَلمة السر"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "اسم المستخدم"
 ],
 "login": [
  null,
  "سجل الدخول"
 ],
 "access": [
  null,
  "وصول"
 ],
 "roles": [
  null,
  "قواعد"
 ],
 "keys": [
  null,
  "مفاتيح"
 ],
 "Managing user accounts": [
  null,
  "إدارة حسابات المستخدم"
 ]
});
