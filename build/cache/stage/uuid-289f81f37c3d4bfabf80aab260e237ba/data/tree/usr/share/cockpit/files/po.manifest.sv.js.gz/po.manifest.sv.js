cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Filbläddrare"
 ],
 "files": [
  null,
  "filer"
 ],
 "explorer": [
  null,
  "utforskare"
 ],
 "filesystem": [
  null,
  "filsystem"
 ]
});
