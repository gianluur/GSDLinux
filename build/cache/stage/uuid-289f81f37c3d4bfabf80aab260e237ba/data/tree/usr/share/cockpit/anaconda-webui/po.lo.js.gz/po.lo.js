cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 ຂໍ້ຜິດພາດ"
 ],
 "$0 installation": [
  null,
  "ການຕິດຕັ້ງ $0"
 ],
 "$0 installer": [
  null,
  "ຕົວຕິດຕັ້ງ $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 ແມ່ນພາກສ່ວນຂະຫຍາຍ MBR ທີ່ບັນຈຸພາກສ່ວນຕາມຕັກກະ (logical partitions). ການລຶບທຸກພາກສ່ວນຕາມຕັກກະອອກ ຈະເປັນການລຶບພາກສ່ວນຂະຫຍາຍນຳໂດຍອັດຕະໂນມັດ."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "ຕ້ອງການ $0, ແຕ່ມີພຽງ $1 ທີ່ໃຊ້ໄດ້."
 ],
 "$0 warning": [
  null,
  "$0 ຄຳເຕືອນ"
 ],
 "$0 will be deleted": [
  null,
  "$0 ຈະຖືກລຶບ"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "ລະບົບໄຟລ໌ '$0' ບໍ່ສາມາດຢູ່ເທິງອຸປະກອນບລັອກທີ່ເຂົ້າລະຫັດໄວ້ໄດ້"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0' ຕ້ອງຢູ່ເທິງອຸປະກອນທີ່ຟໍແມັດເປັນ '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "ພົບພາກສ່ວນ '$0' ເທິງອຸປະກອນ MDRAID $1. ບໍ່ຮອງຮັບພາກສ່ວນ Bootloader ເທິງອຸປະກອນ MDRAID."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "ບັນຊີຜູ້ໃຊ້ທົ່ວໄປທີ່ມີສິດຜູ້ດູແລລະບົບ ເພື່ອທຳການປ່ຽນແປງຕ່າງໆພາຍໃນລະບົບ."
 ],
 "About": [
  null,
  "ກ່ຽວກັບ"
 ],
 "Account": [
  null,
  "ບັນຊີ"
 ],
 "Actions": [
  null,
  "ການດຳເນີນການ"
 ],
 "Add another server...": [
  null,
  "ເພີ່ມເຊີເວີອື່ນ..."
 ],
 "Add mount": [
  null,
  "ເພີ່ມຈຸດເຊື່ອມຕໍ່"
 ],
 "Add-ons for your chosen environment": [
  null,
  "ສ່ວນເສີມສຳລັບສະພາບແວດລ້ອມທີ່ທ່ານເລືອກ"
 ],
 "Add-ons not specific to your environment": [
  null,
  "ສ່ວນເສີມທີ່ບໍ່ໄດ້ກຳນົດສະເພາະສຳລັບສະພາບແວດລ້ອມຂອງທ່ານ"
 ],
 "Additional languages": [
  null,
  "ພາສາເພີ່ມເຕີມ"
 ],
 "Additional software for the selected environment": [
  null,
  "ຊອບແວເພີ່ມເຕີມສຳລັບສະພາບແວດລ້ອມທີ່ເລືອກ"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "ທຸກການປ່ຽນແປງໃນຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນຈະມີຜົນທັນທີ."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "ທຸກອຸປະກອນທີ່ໃຊ້ລະຫັດຜ່ານນີ້ຈະຖືກປົດລັອກ"
 ],
 "Anaconda Web UI": [
  null,
  "ໜ້າຈໍຜູ້ໃຊ້ເວັບ Anaconda"
 ],
 "Anaconda project page": [
  null,
  "ໜ້າໂຄງການ Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "ນຳໃຊ້ການກຳນົດຈຸດເຊື່ອມຕໍ່ ແລະ ຕິດຕັ້ງ"
 ],
 "Applying changes...": [
  null,
  "ກຳລັງນຳໃຊ້ການປ່ຽນແປງ..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "ກຳນົດພາກສ່ວນໃຫ້ກັບຈຸດເຊື່ອມຕໍ່. ມີປະໂຫຍດສຳລັບຮູບແບບທີ່ຕັ້ງຄ່າໄວ້ລ່ວງໜ້າ."
 ],
 "Automatic log file upload": [
  null,
  "ອັບໂຫຼດໄຟລ໌ບັນທຶກອັດຕະໂນມັດ"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "ຕັ້ງວັນທີ ແລະ ເວລາອັດຕະໂນມັດ ໂດຍໃຊ້ເຊີເວີເວລາ"
 ],
 "Automatically set timezone": [
  null,
  "ຕັ້ງເຂດເວລາອັດຕະໂນມັດ"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "ພື້ນທີ່ວ່າງທີ່ມີ: $0. ການຕິດຕັ້ງຕ້ອງການ: $1."
 ],
 "Back": [
  null,
  "ກັບຄືນ"
 ],
 "Base environment": [
  null,
  "ສະພາບແວດລ້ອມພື້ນຖານ"
 ],
 "Brief description of the issue": [
  null,
  "ຄຳອະທິບາຍຫຍໍ້ກ່ຽວກັບບັນຫາ"
 ],
 "Bug report details": [
  null,
  "ລາຍລະອຽດການລາຍງານບັກ"
 ],
 "Bugzilla API key": [
  null,
  "ລະຫັດ Bugzilla API key"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "ໂດຍການນຳໃຊ້ຊອບແວນີ້ຕໍ່ໄປ, ທ່ານເຂົ້າໃຈ ແລະ ຍອມຮັບຄວາມສ່ຽງທີ່ກ່ຽວຂ້ອງກັບຊອບແວລຸ້ນທົດລອງ, ທ່ານມີຈຸດປະສົງທີ່ຈະໃຊ້ມັນເພື່ອການທົດສອບ ແລະ ການພັດທະນາເທົ່ານັ້ນ ແລະ ຍິນດີທີ່ຈະລາຍງານບັກ ຫຼື ບັນຫາຕ່າງໆ ເພື່ອປັບປຸງວຽກງານນີ້."
 ],
 "Cancel": [
  null,
  "ຍົກເລີກ"
 ],
 "Change": [
  null,
  "ປ່ຽນ"
 ],
 "Change destination": [
  null,
  "ປ່ຽນປາຍທາງ"
 ],
 "Change hostname": [
  null,
  "ປ່ຽນຊື່ເຄື່ອງ"
 ],
 "Change partition layout": [
  null,
  "ປ່ຽນຮູບແບບພາກສ່ວນ"
 ],
 "Change system keyboard layout": [
  null,
  "ປ່ຽນຮູບແບບຄີບອດຂອງລະບົບ"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "ການປ່ຽນແປງຢູ່ບ່ອນນີ້ຈະມີຜົນກັບລະບົບທັນທີ. ບໍ່ສາມາດ 'ຍົກເລີກ' ໄດ້."
 ],
 "Checking installation configuration...": [
  null,
  "ກຳລັງກວດສອບການຕັ້ງຄ່າການຕິດຕັ້ງ..."
 ],
 "Checking storage configuration": [
  null,
  "ກຳລັງກວດສອບການຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Clear search": [
  null,
  "ລຶບການຄົ້ນຫາ"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "ຄລິກ 'ຕໍ່ໄປ' ອີກຄັ້ງເພື່ອດຳເນີນການຕໍ່ ເຖິງແມ່ນວ່າຈະມີຄຳເຕືອນເຫຼົ່ານີ້."
 ],
 "Close": [
  null,
  "ປິດ"
 ],
 "Close storage editor": [
  null,
  "ປິດຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit storage ບໍ່ໄດ້ໃຫ້ລະຫັດຜ່ານເພື່ອປົດລັອກອຸປະກອນທີ່ເຂົ້າລະຫັດ."
 ],
 "Completed": [
  null,
  "ສຳເລັດແລ້ວ"
 ],
 "Configuration is incomplete": [
  null,
  "ການຕັ້ງຄ່າຍັງບໍ່ທັນຄົບຖ້ວນ"
 ],
 "Configure NTP servers": [
  null,
  "ຕັ້ງຄ່າເຊີເວີ NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "ຕັ້ງຄ່າເຊີເວີ NTP ດ້ວຍຕົນເອງ"
 ],
 "Configure network": [
  null,
  "ຕັ້ງຄ່າເຄືອຂ່າຍ"
 ],
 "Configure storage": [
  null,
  "ຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Configure storage again": [
  null,
  "ຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນຄືນໃໝ່"
 ],
 "Confirm passphrase": [
  null,
  "ຢືນຢັນລະຫັດຜ່ານ"
 ],
 "Continue": [
  null,
  "ດຳເນີນການຕໍ່"
 ],
 "Continue installation": [
  null,
  "ດຳເນີນການຕິດຕັ້ງຕໍ່"
 ],
 "Continue with installation": [
  null,
  "ດຳເນີນການຕິດຕັ້ງຕໍ່ໄປ"
 ],
 "Correct these issues before continuing.": [
  null,
  "ແກ້ໄຂບັນຫາເຫຼົ່ານີ້ກ່ອນທີ່ຈະດຳເນີນການຕໍ່."
 ],
 "Create Account": [
  null,
  "ສ້າງບັນຊີ"
 ],
 "Create account": [
  null,
  "ສ້າງບັນຊີ"
 ],
 "Currently installed: $0": [
  null,
  "ຕິດຕັ້ງຢູ່ໃນປະຈຸບັນ: $0"
 ],
 "Custom": [
  null,
  "ກຳນົດເອງ"
 ],
 "Date": [
  null,
  "ວັນທີ"
 ],
 "Date and time": [
  null,
  "ວັນທີ ແລະ ເວລາ"
 ],
 "Delete partition": [
  null,
  "ລຶບພາກສ່ວນ"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "ການລຶບພາກສ່ວນໃດໜຶ່ງອາດເຮັດໃຫ້ $0 ບໍ່ສາມາດບູດໄດ້: $1"
 ],
 "Description": [
  null,
  "ຄຳອະທິບາຍ"
 ],
 "Destination": [
  null,
  "ປາຍທາງ"
 ],
 "Destination is encrypted": [
  null,
  "ປາຍທາງຖືກເຂົ້າລະຫັດໄວ້"
 ],
 "Detailed description of the issue": [
  null,
  "ຄຳອະທິບາຍລາຍລະອຽດຂອງບັນຫາ"
 ],
 "Detected valid storage layout:": [
  null,
  "ກວດພົບຮູບແບບບ່ອນເກັບຂໍ້ມູນທີ່ຖືກຕ້ອງ:"
 ],
 "Device": [
  null,
  "ອຸປະກອນ"
 ],
 "Duplicate device.": [
  null,
  "ອຸປະກອນຊ້ຳກັນ."
 ],
 "Duplicate mount point.": [
  null,
  "ຈຸດເຊື່ອມຕໍ່ຊ້ຳກັນ."
 ],
 "Enable root account": [
  null,
  "ເປີດໃຊ້ບັນຊີ root"
 ],
 "Encrypt my data": [
  null,
  "ເຂົ້າລະຫັດຂໍ້ມູນຂອງຂ້ອຍ"
 ],
 "Encrypted": [
  null,
  "ເຂົ້າລະຫັດແລ້ວ"
 ],
 "Encryption": [
  null,
  "ການເຂົ້າລະຫັດ"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "ປ້ອນລະຫັດ Bugzilla API ຂອງທ່ານເພື່ອສ້າງລາຍງານບັກ. ທ່ານຈະສາມາດກວດສອບ ແລະ ແກ້ໄຂລາຍລະອຽດຂອງບັກໃນຂັ້ນຕອນຕໍ່ໄປ."
 ],
 "Environment": [
  null,
  "ສະພາບແວດລ້ອມ"
 ],
 "Erase data and install": [
  null,
  "ລຶບຂໍ້ມູນ ແລະ ຕິດຕັ້ງ"
 ],
 "Error details": [
  null,
  "ລາຍລະອຽດຂໍ้ຜິດພາດ"
 ],
 "Exit to live desktop": [
  null,
  "ອອກໄປຫາໜ້າຈໍ Live Desktop"
 ],
 "Extended partition": [
  null,
  "ພາກສ່ວນຂະຫຍາຍ"
 ],
 "Failed to report issue": [
  null,
  "ລາຍງານບັນຫາບໍ່ສຳເລັດ"
 ],
 "Failed to save layouts": [
  null,
  "ບັນທຶກຮູບແບບບໍ່ສຳເລັດ"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux ຕ້ອງການພື້ນທີ່ດິດຢ່າງໜ້ອຍ $0."
 ],
 "Finalization": [
  null,
  "ຂັ້ນຕອນສຸດທ້າຍ"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "ກຳລັງສຳເລັດຂັ້ນຕອນສຸດທ້າຍ: ການຕັ້ງຄ່າລະບົບສຳເລັດແລ້ວ. ອາດໃຊ້ເວລາຄາວໜຶ່ງເພື່ອສຳເລັດການຕິດຕັ້ງ."
 ],
 "Find layout": [
  null,
  "ຄົ້ນຫາຮູບແບບ"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "ເພື່ອຄວາມປອດໄພທີ່ດີກວ່າ, ຫຼີກເວັ້ນການໃຊ້ບັນຊີ root ໂດຍກົງ. ແຕ່ໃຫ້ໃຊ້ບັນຊີຜູ້ໃຊ້ທ້ອງຖິ່ນຂ້າງເທິງເພື່ອຈັດການລະບົບແທນ."
 ],
 "Full name": [
  null,
  "ຊື່ເຕັມ"
 ],
 "Full name cannot contain colon characters": [
  null,
  "ຊື່ເຕັມບໍ່ສາມາດມີເຄື່ອງໝາຍຈ້ຳສອງເມັດ (colon)"
 ],
 "Helper text": [
  null,
  "ຂໍ້ຄວາມຊ່ວຍເຫຼືອ"
 ],
 "Hide API key": [
  null,
  "ເຊື່ອງລະຫັດ API"
 ],
 "Hide confirmed password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານທີ່ຢືນຢັນ"
 ],
 "Hide passphrase": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "Hide password": [
  null,
  "ເຊື່ອງລະຫັດຜ່ານ"
 ],
 "Hostname": [
  null,
  "ຊື່ເຄື່ອງ"
 ],
 "How would you like to install?": [
  null,
  "ທ່ານຕ້ອງການຕິດຕັ້ງແນວໃດ?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "ຂ້ອຍເຂົ້າໃຈວ່າຂໍ້ມູນທີ່ມີຢູ່ທັງໝົດຈະຖືກລຶບອອກຈາກດິດທີ່ເລືອກ"
 ],
 "I understand that some existing data will be erased": [
  null,
  "ຂ້ອຍເຂົ້າໃຈວ່າຂໍ້ມູນທີ່ມີຢູ່ບາງສ່ວນຈະຖືກລຶບ"
 ],
 "I understand that some partitions will be modified": [
  null,
  "ຂ້ອຍເຂົ້າໃຈວ່າບາງພາກສ່ວນຈະຖືກປ່ຽນແປງ"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "ຖ້າຫວ່າງໄວ້, ຊື່ເຄື່ອງຈະຖືກຕັ້ງຊົ່ວຄາວຕາມຂໍ້ມູນເຄືອຂ່າຍ."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "ຖ້າທ່ານກຳລັງຕັ້ງຄ່າພາກສ່ວນ, ສິ່ງຕໍ່ໄປນີ້ແມ່ນຈຳເປັນ:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "ຖ້າທ່ານບໍ່ຍິນຍອມໃຫ້ອັບໂຫຼດໄຟລ໌ບັນທຶກອັດຕະໂນມັດ, ທ່ານສາມາດ $0 ແທນໄດ້. ການລາຍງານດ້ວຍຕົນເອງຊ່ວຍໃຫ້ທ່ານສາມາດກວດສອບ ແລະ ເລືອກແນບໄຟລ໌ບັນທຶກໄດ້ດ້ວຍຕົນເອງ."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "ຖ້າທ່ານບໍ່ເຂົ້າໃຈ ຫຼື ບໍ່ຍອມຮັບຄວາມສ່ຽງ, ກະລຸນາອອກຈາກໂປຣແກຣມນີ້."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "ກຳລັງດຳເນີນການ"
 ],
 "Initializing...": [
  null,
  "ກຳລັງເລີ່ມຕົ້ນ..."
 ],
 "Install": [
  null,
  "ຕິດຕັ້ງ"
 ],
 "Installation failed": [
  null,
  "ການຕິດຕັ້ງບໍ່ສຳເລັດ"
 ],
 "Installation method": [
  null,
  "ວິທີການຕິດຕັ້ງ"
 ],
 "Installation of the system failed": [
  null,
  "ການຕິດຕັ້ງລະບົບບໍ່ສຳເລັດ"
 ],
 "Installation of the system failed: $0": [
  null,
  "ການຕິດຕັ້ງລະບົບບໍ່ສຳເລັດ: $0"
 ],
 "Installation type": [
  null,
  "ປະເພດການຕິດຕັ້ງ"
 ],
 "Installing": [
  null,
  "ກຳລັງຕິດຕັ້ງ"
 ],
 "Insufficient disk space": [
  null,
  "ພື້ນທີ່ດິດບໍ່ພຽງພໍ"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "ກວດພົບການຕັ້ງຄ່າ RAID ທີ່ບໍ່ຖືກຕ້ອງ. ຖ້າອາເຣ RAID ຂອງທ່ານຖືກສ້າງຂຶ້ນໂດຍກົງເທິງດິດ, ຕ້ອງສ້າງຕາຕະລາງພາກສ່ວນ (partition table) ເທິງອາເຣນັ້ນ. ຖ້າອາເຣ RAID ສ້າງຂຶ້ນເທິງພາກສ່ວນ, ມັນຕ້ອງມີລະບົບໄຟລ໌ ຫຼື ຟໍແມັດດຽວ (ຕົວຢ່າງ: LVM PV). ພາກສ່ວນທີ່ມີຢູ່ແລ້ວເທິງອາເຣນີ້ຈະຖືກລະເລີຍ."
 ],
 "Invalid hostname": [
  null,
  "ຊື່ເຄື່ອງບໍ່ຖືກຕ້ອງ"
 ],
 "Jump to first incomplete step": [
  null,
  "ໄປຫາຂັ້ນຕອນທຳອິດທີ່ຍັງບໍ່ສຳເລັດ"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "ຮັກສາຮູບແບບດິດປະຈຸບັນ ແລະ ໃຊ້ພື້ນທີ່ວ່າງທີ່ມີ, ເພື່ອໃຊ້ສອງລະບົບປະຕິບັດການ (dual-boot)."
 ],
 "Keyboard": [
  null,
  "ຄີບອດ"
 ],
 "Keyboard layout during boot": [
  null,
  "ຮູບແບບຄີບອດໃນລະຫວ່າງການບູດ"
 ],
 "Language": [
  null,
  "ພາສາ"
 ],
 "Launch storage editor": [
  null,
  "ເປີດຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "ຮຽນຮູ້ເພີ່ມເຕີມກ່ຽວກັບການຈຳກັດການເຂົ້າເຖິງໃນການຕັ້ງຄ່າ"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "ສະຖານທີ່"
 ],
 "Locked devices": [
  null,
  "ອຸປະກອນທີ່ຖືກລັອກ"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  "ຕັ້ງເປັນປະຈຸບັນ"
 ],
 "Manual disk configuration": [
  null,
  "ຕັ້ງຄ່າດິດດ້ວຍຕົນເອງ"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "ຕັ້ງຄ່າດິດດ້ວຍຕົນເອງ: ການກຳນົດຈຸດເຊື່ອມຕໍ່"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "ອາດປະກອບມີຕົວອັກສອນ, ຕົວເລກ ແລະ ເຄື່ອງໝາຍຂີດຕໍ່."
 ],
 "May need more free space": [
  null,
  "ອາດຕ້ອງການພື້ນທີ່ວ່າງເພີ່ມເຕີມ"
 ],
 "Medium": [
  null,
  "ປານກາງ"
 ],
 "Minimum of $0 required": [
  null,
  "ຕ້ອງການຢ່າງໜ້ອຍ $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "ການເລືອກຟໍແມັດຄືນໃໝ່ລະຫວ່າງອຸປະກອນຫຼັກ ແລະ ອຸປະກອນຍ່ອຍບໍ່ກົງກັນ."
 ],
 "Mount point": [
  null,
  "ຈຸດເຊື່ອມຕໍ່"
 ],
 "Mount point assignment": [
  null,
  "ການກຳນົດຈຸດເຊື່ອມຕໍ່"
 ],
 "Move down": [
  null,
  "ຍ້າຍລົງ"
 ],
 "Move up": [
  null,
  "ຍ້າຍຂຶ້ນ"
 ],
 "Must be at least $0 characters": [
  null,
  "ຕ້ອງມີຢ່າງໜ້ອຍ $0 ຕົວອັກສອນ"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "ເຊີເວີ NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "ຊື່"
 ],
 "Needs at least $0": [
  null,
  "ຕ້ອງການຢ່າງໜ້ອຍ $0"
 ],
 "Network": [
  null,
  ""
 ],
 "Network Configuration": [
  null,
  "ການຕັ້ງຄ່າເຄືອຂ່າຍ"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "ບໍ່ມີເຄືອຂ່າຍ. ຕັ້ງຄ່າເຄືອຂ່າຍໃນເມນູແຖບດ້ານເທິງເພື່ອລາຍງານບັນຫາ."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "ບໍ່ມີເຄືອຂ່າຍ. ຕັ້ງຄ່າເຄືອຂ່າຍເພື່ອລາຍງານບັນຫາ."
 ],
 "Network plugin failed": [
  null,
  "ປລັກອິນເຄືອຂ່າຍເຮັດວຽກຜິດພາດ"
 ],
 "Next": [
  null,
  "ຕໍ່ໄປ"
 ],
 "No devices": [
  null,
  "ບໍ່ມີອຸປະກອນ"
 ],
 "No disks available": [
  null,
  "ບໍ່ມີດິດທີ່ສາມາດໃຊ້ໄດ້"
 ],
 "No disks selected": [
  null,
  "ບໍ່ມີດິດທີ່ຖືກເລືອກ"
 ],
 "No layouts selected yet": [
  null,
  "ຍັງບໍ່ທັນເລືອກຮູບແບບ"
 ],
 "No results found": [
  null,
  "ບໍ່ພົບຜົນການຄົ້ນຫາ"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "ບໍ່ສາມາດດຶງຂໍ້ມູນ VConsole keymap ທີ່ຖືກຕ້ອງສຳລັບຮູບແບບຄີບອດທີ່ເລືອກ. ກະລຸນາເລືອກຮູບແບບຄີບອດອື່ນ."
 ],
 "Not enough available free space": [
  null,
  "ພື້ນທີ່ວ່າງທີ່ມີຢູ່ບໍ່ພຽງພໍ"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "ພື້ນທີ່ວ່າງໃນດິດທີ່ເລືອກບໍ່ພຽງພໍ."
 ],
 "Not enough space on selected disks.": [
  null,
  "ພື້ນທີ່ໃນດິດທີ່ເລືອກບໍ່ພຽງພໍ."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "ໝາຍເຫດ: ນີ້ແມ່ນຊອບແວລຸ້ນທົດລອງທີ່ມີຈຸດປະສົງເພື່ອການພັດທະນາ ແລະ ການທົດສອບເທົັ້ນນັ້ນ. ຫ້າມໃຊ້ຊອບແວນີ້ສຳລັບວຽກງານທີ່ສຳຄັນ ຫຼື ໃນສະພາບແວດລ້ອມການເຮັດວຽກຈິງ."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "ເປີດແບບຟອມແຈ້ງບັກຂອງ Bugzilla"
 ],
 "Operating system": [
  null,
  "ລະບົບປະຕິບັດການ"
 ],
 "Options": [
  null,
  "ຕົວເລືອກ"
 ],
 "Other keyboards": [
  null,
  "ຄີບອດອື່ນໆ"
 ],
 "Partitions (advanced)": [
  null,
  "ພາກສ່ວນ (ຂັ້ນສູງ)"
 ],
 "Passphrase": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "Passphrase did not match any locked device": [
  null,
  "ລະຫັດຜ່ານບໍ່ກົງກັບອຸປະກອນທີ່ຖືກລັອກໃດໆ"
 ],
 "Passphrases must match": [
  null,
  "ລະຫັດຜ່ານຕ້ອງກົງກັນ"
 ],
 "Pending": [
  null,
  "ລໍຖ້າ"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "ກະລຸນາແນບໄຟລ໌ບັນທຶກ $0 ໄປນຳ."
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "ກະລຸນາເລືອກດິດຢ່າງໜ້ອຍໜຶ່ງອັນເພື່ອດຳເນີນການຕໍ່"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "ຂັບເຄື່ອນໂດຍ Anaconda"
 ],
 "Pre-release": [
  null,
  "ລຸ້ນທົດລອງ"
 ],
 "Prefer to report manually? $0": [
  null,
  "ຕ້ອງການລາຍງານດ້ວຍຕົນເອງບໍ? $0"
 ],
 "Proceed with installation": [
  null,
  "ດຳເນີນການຕິດຕັ້ງຕໍ່"
 ],
 "Quit": [
  null,
  "ອອກ"
 ],
 "Quit installer?": [
  null,
  "ອອກຈາກຕົວຕິດຕັ້ງບໍ?"
 ],
 "Reading information about the OS failed.": [
  null,
  "ອ່ານຂໍ້ມູນກ່ຽວກັບ OS ບໍ່ສຳເລັດ."
 ],
 "Reading information about the computer failed.": [
  null,
  "ອ່ານຂໍ້ມູນກ່ຽວກັບຄອມພິວເຕີບໍ່ສຳເລັດ."
 ],
 "Reading installer configuration failed.": [
  null,
  "ອ່ານການຕັ້ງຄ່າຕົວຕິດຕັ້ງບໍ່ສຳເລັດ."
 ],
 "Reading installer version information failed.": [
  null,
  "ອ່ານຂໍ້ມູນເວີຊັນຂອງຕົວຕິດຕັ້ງບໍ່ສຳເລັດ."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "ຊື່ເຄື່ອງ (hostname) ສາມາດປະກອບມີຕົວອັກສອນ, ຕົວເລກ, ເຄື່ອງໝາຍຂີດຕໍ່ (ບໍ່ຂຶ້ນຕົ້ນ ຫຼື ລົງທ້າຍດ້ວຍຂີດຕໍ່) ແລະ ຈ້ຳ"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "ຊື່ເຄື່ອງຕ້ອງມີຄວາມຍາວບໍ່ເກີນ 64 ຕົວອັກສອນ"
 ],
 "Reboot": [
  null,
  "ເລີ່ມລະບົບໃໝ່"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "ເລີ່ມລະບົບເຂົ້າ Windows ເພື່ອປ່ຽນຂະໜາດພາກສ່ວນທີ່ເຂົ້າລະຫັດ BitLocker. ໃຫ້ມີພື້ນທີ່ວ່າງຢ່າງໜ້ອຍ $0 ສຳລັບການຕິດຕັ້ງ."
 ],
 "Reboot system?": [
  null,
  "ເລີ່ມລະບົບໃໝ່ບໍ?"
 ],
 "Reclaim additional space": [
  null,
  "ເອົາພື້ນທີ່ເພີ່ມເຕີມຄືນ"
 ],
 "Reclaim space": [
  null,
  "ເອົາພື້ນທີ່ຄືນ"
 ],
 "Reclaim space (required)": [
  null,
  "ເອົາພື້ນທີ່ຄືນ (ຈຳເປັນ)"
 ],
 "Recommended": [
  null,
  "ແນະນຳ"
 ],
 "Recommended partitions:": [
  null,
  "ພາກສ່ວນທີ່ແນະນຳ:"
 ],
 "Reformat": [
  null,
  "ຟໍແມັດໃໝ່"
 ],
 "Reinstall Fedora": [
  null,
  "ຕິດຕັ້ງ Fedora ຄືນໃໝ່"
 ],
 "Remove": [
  null,
  "ເອົາອອກ"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "ລຶບທຸກພາກສ່ວນໃນອຸປະກອນທີ່ເລືອກ, ລວມທັງລະບົບປະຕິບັດການທີ່ມີຢູ່."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "ລຶບ ຫຼື ປ່ຽນຂະໜາດລະບົບໄຟລ໌ທີ່ມີຢູ່ເພື່ອໃຫ້ມີພື້ນທີ່ວ່າງສຳລັບການຕິດຕັ້ງ."
 ],
 "Remove server": [
  null,
  "ເອົາເຊີເວີອອກ"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "ການລຶບລະບົບໄຟລ໌ຈະເປັນການລຶບຂໍ້ມູນທັງໝົດໃນນັ້ນຢ່າງຖາວອນ. ການປ່ຽນຂະໜາດພາກສ່ວນສາມາດຊ່ວຍເພີ່ມພື້ນທີ່ວ່າງໄດ້, ແຕ່ກໍມີຄວາມສ່ຽງ. ກະລຸນາສຳຮອງຂໍ້ມູນທີ່ສຳຄັນກ່ອນທຳການເອົາພື້ນທີ່ຄືນ."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "ແທນທີ່ການຕິດຕັ້ງປະຈຸບັນ, ແຕ່ຮັກສາໄຟລ໌ໃນ home ໄວ້."
 ],
 "Report Issue": [
  null,
  "ແຈ້ງບັນຫາ"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "ລາຍງານບັນຫາ ຫຼື ໃຫ້ຄຳແນະນຳໂດຍການເປີດແບບຟອມແຈ້ງບັກຂອງ Bugzilla $0."
 ],
 "Report issue": [
  null,
  "ລາຍງານບັນຫາ"
 ],
 "Reporting issue...": [
  null,
  "ກຳລັງລາຍງານບັນຫາ..."
 ],
 "Required": [
  null,
  "ຈຳເປັນ"
 ],
 "Requirements": [
  null,
  "ຂໍ້ກຳນົດ"
 ],
 "Rescan devices": [
  null,
  "ສະແກນອຸປະກອນຄືນໃໝ່"
 ],
 "Rescanning of the disks failed.": [
  null,
  "ການສະແກນດິດຄືນໃໝ່ບໍ່ສຳເລັດ."
 ],
 "Resize": [
  null,
  "ປ່ຽນຂະໜາດ"
 ],
 "Resize partition": [
  null,
  "ປ່ຽນຂະໜາດພາກສ່ວນ"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "ກຳລັງປ່ຽນຂະໜາດພາກສ່ວນຕໍ່ໄປນີ້ຈາກ $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "ຈຳກັດການເຂົ້າເຖິງການລາຍງານ"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "ຈຳກັດການລາຍງານໃຫ້ສະເພາະກຸ່ມ $0. $1"
 ],
 "Return to installation": [
  null,
  "ກັບຄືນສູ່ການຕິດຕັ້ງ"
 ],
 "Return to storage editor": [
  null,
  "ກັບຄືນສູ່ຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Review and install": [
  null,
  "ກວດສອບ ແລະ ຕິດຕັ້ງ"
 ],
 "Root account is enabled": [
  null,
  "ເປີດໃຊ້ບັນຊີ root ແລ້ວ"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "ເປີດໃຊ້ບັນຊີ root ແລ້ວ, ແຕ່ຍັງບໍ່ໄດ້ຕັ້ງຄ່າບັນຊີຜູ້ໃຊ້"
 ],
 "Root password has been set.": [
  null,
  "ຕັ້ງລະຫັດຜ່ານ root ແລ້ວ."
 ],
 "Save": [
  null,
  "ບັນທຶກ"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "ສະແກນ QR code ດ້ວຍໂທລະສັບຂອງທ່ານ ຫຼື ເຂົ້າໄປທີ່:"
 ],
 "Search for a language": [
  null,
  "ຄົ້ນຫາພາສາ"
 ],
 "Search for additional software": [
  null,
  "ຄົ້ນຫາຊອບແວເພີ່ມເຕີມ"
 ],
 "Search for an environment": [
  null,
  "ຄົ້ນຫາສະພາບແວດລ້ອມ"
 ],
 "Search keyboard layout": [
  null,
  "ຄົ້ນຫາຮູບແບບຄີບອດ"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "ຮັກສາຄວາມປອດໄພຂອງຂໍ້ມູນໂດຍການເຂົ້າລະຫັດດິດ. ໃຊ້ໄດ້ກັບພາກສ່ວນໃໝ່ເທົ່ານັ້ນ"
 ],
 "Select": [
  null,
  "ເລືອກ"
 ],
 "Select a device": [
  null,
  "ເລືອກອຸປະກອນ"
 ],
 "Select city": [
  null,
  "ເລືອກເມືອງ"
 ],
 "Select destination": [
  null,
  "ເລືອກປາຍທາງ"
 ],
 "Select region": [
  null,
  "ເລືອກພາກພື້ນ"
 ],
 "Selected (top = current)": [
  null,
  "ເລືອກແລ້ວ (ເທິງສຸດ = ປະຈຸບັນ)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "ຟໍແມັດ '$0' ຂອງອຸປະກອນທີ່ເລືອກບໍ່ສາມາດຟໍແມັດຄືນໃໝ່ໄດ້."
 ],
 "Send us feedback on your installation": [
  null,
  "ສົ່ງຄຳຄິດເຫັນກ່ຽວກັບການຕິດຕັ້ງໃຫ້ພວກເຮົາ"
 ],
 "Server": [
  null,
  "ເຊີເວີ"
 ],
 "Server is not reachable": [
  null,
  "ບໍ່ສາມາດເຊື່ອມຕໍ່ກັບເຊີເວີໄດ້"
 ],
 "Set custom hostname": [
  null,
  "ຕັ້ງຊື່ເຄື່ອງດ້ວຍຕົນເອງ"
 ],
 "Share disk with other operating systems": [
  null,
  "ແບ່ງປັນດິດກັບລະບົບປະຕິບັດການອື່ນ"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "ແບ່ງປັນດິດກັບລະບົບປະຕິບັດການອື່ນ: $0"
 ],
 "Show AM/PM": [
  null,
  "ສະແດງ AM/PM"
 ],
 "Show API key": [
  null,
  "ສະແດງລະຫັດ API"
 ],
 "Show confirmed password": [
  null,
  "ສະແດງລະຫັດຜ່ານທີ່ຢືນຢັນ"
 ],
 "Show passphrase": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Show password": [
  null,
  "ສະແດງລະຫັດຜ່ານ"
 ],
 "Size": [
  null,
  "ຂະໜາດ"
 ],
 "Software installation": [
  null,
  "ການຕິດຕັ້ງຊອບແວ"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "ການຕິດຕັ້ງຊອບແວ: ຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນສຳເລັດ. ກຳລັງຕິດຕັ້ງຊອບແວລົງໃນອຸປະກອນຂອງທ່ານ."
 ],
 "Software selection": [
  null,
  "ການເລືອກຊອບແວ"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "ຍັງມີບາງຂັ້ນຕອນການຕິດຕັ້ງທີ່ຕ້ອງເຮັດໃຫ້ສຳເລັດກ່ອນທີ່ຈະດຳເນີນການຕໍ່."
 ],
 "Some required partitions are missing: $0": [
  null,
  "ບາງພາກສ່ວນທີ່ຈຳເປັນຫາຍໄປ: $0"
 ],
 "Space": [
  null,
  "ພື້ນທີ່"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "ບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Storage configuration": [
  null,
  "ການຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "ການຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນ: ກຳລັງຕັ້ງຄ່າບ່ອນເກັບຂໍ້ມູນ."
 ],
 "Storage editor": [
  null,
  "ຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "ບ່ອນເກັບຂໍ້ມູນແມ່ນອີງຕາມການຕັ້ງຄ່າຈາກ 'ປ່ຽນແປງບ່ອນເກັບຂໍ້ມູນ'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "ຮູບແບບບ່ອນເກັບຂໍ້ມູນຖືກກຳນົດໂດຍໄຟລ໌ kickstart. ສາມາດກວດສອບຮູບແບບພາກສ່ວນທີ່ວາງແຜນໄວ້ໄດ້ໃນຂັ້ນຕອນສະຫຼຸບ."
 ],
 "Storage plugin failed": [
  null,
  "ປລັກອິນບ່ອນເກັບຂໍ້ມູນເຮັດວຽກຜິດພາດ"
 ],
 "Storage requirements not met": [
  null,
  "ບໍ່ເປັນໄປຕາມຂໍ້ກຳນົດຂອງບ່ອນເກັບຂໍ້ມູນ"
 ],
 "Strong": [
  null,
  "ແຂງແຮງ"
 ],
 "Successfully installed": [
  null,
  "ຕິດຕັ້ງສຳເລັດແລ້ວ"
 ],
 "Successfully unlocked $0.": [
  null,
  "ປົດລັອກ $0 ສຳເລັດແລ້ວ."
 ],
 "Suggested keyboards": [
  null,
  "ຄີບອດທີ່ແນະນຳ"
 ],
 "Suggested languages": [
  null,
  "ພາສາທີ່ແນະນຳ"
 ],
 "System": [
  null,
  "ລະບົບ"
 ],
 "System configuration": [
  null,
  "ການຕັ້ງຄ່າລະບົບ"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "ການຕັ້ງຄ່າລະບົບ: ການຕິດຕັ້ງຊອບແວສຳເລັດແລ້ວ. ປະຈຸບັນກຳລັງຕັ້ງຄ່າລະບົບ."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "ການຕິດຕັ້ງ Anaconda ຢຸດເຮັດວຽກໂດຍບໍ່ຄາດຄິດ."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "ຜູ້ໃຊ້ຕໍ່ໄປນີ້ຈະຖືກສ້າງຂຶ້ນ:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "ການຕິດຕັ້ງຕ້ອງການພື້ນທີ່ດິດ $0; ແຕ່ຄວາມຈຸຂອງດິດທີ່ເລືອກມີພຽງ $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "ຕົວຕິດຕັ້ງບໍ່ສາມາດດຳເນີນການຕໍ່ໄດ້ ເນື່ອງຈາກເກີດຂໍ້ຜິດພາດທີ່ຮ້າຍແຮງ."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "ຕົວຕິດຕັ້ງບໍ່ສາມາດດຳເນີນການຕໍ່ໄດ້ ເນື່ອງຈາກເກີດຂໍ້ຜິດພາດທີ່ຮ້າຍແຮງ: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "ລະຫັດຜ່ານທີ່ທ່ານຕັ້ງມີຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII. ທ່ານອາດຈະບໍ່ສາມາດປ່ຽນຮູບແບບຄີບອດໄດ້ໃນເວລາພິມລະຫັດນີ້."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "ຮູບແບບຄີບອດມາດຕະຖານທີ່ເລືອກບໍ່ຮອງຮັບຕົວອັກສອນ ASCII. ກະລຸນາເລືອກຮູບແບບທີ່ຮອງຮັບ ASCII ເປັນຄ່າເລີ່ມຕົ້ນ."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "ຕົວແກ້ໄຂບ່ອນເກັບຂໍ້ມູນຊ່ວຍໃຫ້ທ່ານປ່ຽນຂະໜາດ, ລຶບ ແລະ ສ້າງພາກສ່ວນໄດ້. ມັນສາມາດຕັ້ງຄ່າ LVM ແລະ ອື່ນໆອີກ. ມັນຖືກອອກແບບມາເພື່ອເປັນເຄື່ອງມືຂັ້ນສູງ ແລະ ບໍ່ໄດ້ມີຈຸດປະສົງສຳລັບການຕິດຕັ້ງແບບທົ່ວໄປ."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "ໄຟລ໌ບັນທຶກເຫຼົ່ານີ້ອາດມີຂໍ້ມູນທີ່ລະອຽດອ່ອນ ເຊັ່ນ: ທີ່ຢູ່ IP, ຊື່ຜູ້ໃຊ້ ຫຼື ລາຍລະອຽດອື່ນໆຂອງລະບົບ."
 ],
 "This hostname can't be submitted": [
  null,
  "ບໍ່ສາມາດສົ່ງຊື່ເຄື່ອງນີ້ໄດ້"
 ],
 "This is unstable, pre-release software": [
  null,
  "ນີ້ແມ່ນຊອບແວລຸ້ນທົດລອງທີ່ຍັງບໍ່ຄົງທີ່"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "ຮູບແບບນີ້ຈະຖືກໃຊ້ເພື່ອປົດລັອກລະບົບຂອງທ່ານໃນເວລາບູດ"
 ],
 "This may take a moment": [
  null,
  "ອາດໃຊ້ເວລາຄາວໜຶ່ງ"
 ],
 "This will take a few moments": [
  null,
  "ນີ້ຈະໃຊ້ເວລາຄາວໜຶ່ງ"
 ],
 "Time": [
  null,
  "ເວລາ"
 ],
 "Timezone": [
  null,
  "ເຂດເວລາ"
 ],
 "Title": [
  null,
  "ຫົວຂໍ້"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "ເພື່ອເລີ່ມຕົ້ນການໃຊ້ງານ $0, ໃຫ້ເລີ່ມລະບົບໃໝ່."
 ],
 "To continue, select the devices to install to.": [
  null,
  "ເພື່ອດຳເນີນການຕໍ່, ໃຫ້ເລືອກອຸປະກອນທີ່ຈະຕິດຕັ້ງ."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "ເພື່ອໃຊ້ຕົວເລືອກນີ້, ໃຫ້ປ່ຽນຂະໜາດ ຫຼື ລຶບພາກສ່ວນທີ່ມີຢູ່ເພື່ອໃຫ້ມີພື້ນທີ່ວ່າງຢ່າງໜ້ອຍ $0."
 ],
 "Type": [
  null,
  "ປະເພດ"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "ບໍ່ສາມາດກຳນົດເວລາການລຶບ $0 ໄດ້"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "ບໍ່ສາມາດກຳນົດເວລາການປ່ຽນຂະໜາດ $0 ໄດ້"
 ],
 "Undo last action": [
  null,
  "ຍົກເລີກການກະທຳຫຼ້າສຸດ"
 ],
 "Unlock": [
  null,
  "ປົດລັອກ"
 ],
 "Unlock encrypted devices": [
  null,
  "ປົດລັອກອຸປະກອນທີ່ເຂົ້າລະຫັດ"
 ],
 "Use configured storage": [
  null,
  "ໃຊ້ບ່ອນເກັບຂໍ້ມູນທີ່ຕັ້ງຄ່າໄວ້"
 ],
 "Use entire disk": [
  null,
  "ໃຊ້ດິດທັງໝົດ"
 ],
 "Use free space": [
  null,
  "ໃຊ້ພື້ນທີ່ວ່າງ"
 ],
 "Use local account": [
  null,
  "ໃຊ້ບັນຊີທ້ອງຖິ່ນ"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "ໃຊ້ອຸປະກອນ RAID ສຳລັບການແບ່ງພາກສ່ວນອັດຕະໂນມັດ"
 ],
 "User creation": [
  null,
  "ການສ້າງຜູ້ໃຊ້"
 ],
 "User name": [
  null,
  "ຊື່ຜູ້ໃຊ້"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "ຊື່ຜູ້ໃຊ້ອາດປະກອບມີພຽງແຕ່: ຕົວອັກສອນ a-z, ຕົວເລກ 0-9, ຂີດຕໍ່ $0, ຈ້ຳ $1, ຂີດກ້ອງ $2"
 ],
 "User name must not be a reserved word": [
  null,
  "ຊື່ຜູ້ໃຊ້ຕ້ອງບໍ່ແມ່ນຄຳສະຫງວນ"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "ຊື່ຜູ້ໃຊ້ຕ້ອງສັ້ນກວ່າ 33 ຕົວອັກສອນ"
 ],
 "Validating...": [
  null,
  "ກຳລັງກວດສອບຄວາມຖືກຕ້ອງ..."
 ],
 "Weak": [
  null,
  "ອ່ອນແອ"
 ],
 "Welcome": [
  null,
  "ຍິນດີຕ້ອນຮັບ"
 ],
 "Welcome to Fedora Linux": [
  null,
  "ຍິນດີຕ້ອນຮັບສູ່ Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "ຍິນດີຕ້ອນຮັບ. ມາຕິດຕັ້ງ $0 ດຽວນີ້ເລີຍ."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "ເມື່ອທ່ານສົ່ງລາຍງານບັກນີ້, ໄຟລ໌ບັນທຶກຕໍ່ໄປນີ້ຈະຖືກອັບໂຫຼດອັດຕະໂນມັດ: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "ພາກສ່ວນ Windows ທີ່ມີການເຂົ້າລະຫັດ BitLocker ບໍ່ສາມາດປ່ຽນຂະໜາດໄດ້"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "ທ່ານສາມາດເລືອກເຮັດໃຫ້ມີພື້ນທີ່ວ່າງຢູ່ບ່ອນນີ້ ແລະ ໃຫ້ຕົວຕິດຕັ້ງຈັດການສ່ວນທີ່ເຫຼືອ ຫຼື ຈະຕັ້ງຄ່າພາກສ່ວນດ້ວຍຕົນເອງກໍໄດ້."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "ທ່ານສາມາດສ້າງລະຫັດ API ສຳລັບບັນຊີ Bugzilla ຂອງທ່ານໄດ້ທີ່ $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "ທ່ານຕ້ອງເປີດໃຊ້ບັນຊີ root ຫຼື ສ້າງບັນຊີຜູ້ໃຊ້ທ້ອງຖິ່ນເພື່ອດຳເນີນການຕໍ່."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "ທ່ານຕ້ອງເຊື່ອມຕໍ່ເຄືອຂ່າຍເພື່ອເປີດໃຊ້ວັນທີ ແລະ ເວລາອັດຕະໂນມັດ."
 ],
 "Your progress will not be saved.": [
  null,
  "ສິ່ງທີ່ທ່ານເຮັດຜ່ານມາຈະບໍ່ຖືກບັນທຶກ."
 ],
 "completed step": [
  null,
  "ຂັ້ນຕອນທີ່ສຳເລັດແລ້ວ"
 ],
 "current step": [
  null,
  "ຂັ້ນຕອນປະຈຸບັນ"
 ],
 "delete": [
  null,
  "ລຶບ"
 ],
 "edit": [
  null,
  "ແກ້ໄຂ"
 ],
 "encrypt": [
  null,
  "ເຂົ້າລະຫັດ"
 ],
 "encrypted": [
  null,
  "ເຂົ້າລະຫັດແລ້ວ"
 ],
 "extended partition": [
  null,
  "ພາກສ່ວນຂະຫຍາຍ"
 ],
 "format as $0": [
  null,
  "ຟໍແມັດເປັນ $0"
 ],
 "here": [
  null,
  "ທີ່ນີ້"
 ],
 "incomplete": [
  null,
  "ບໍ່ຄົບຖ້ວນ"
 ],
 "mount": [
  null,
  "ເຊື່ອມຕໍ່"
 ],
 "pending step": [
  null,
  "ຂັ້ນຕອນທີ່ກຳລັງລໍຖ້າ"
 ],
 "report the issue manually": [
  null,
  "ລາຍງານບັນຫາດ້ວຍຕົນເອງ"
 ],
 "resized from $0": [
  null,
  "ປ່ຽນຂະໜາດຈາກ $0"
 ],
 "shrink": [
  null,
  "ຫຍໍ້"
 ],
 "shrink to $0": [
  null,
  "ຫຍໍ້ລົງເຫຼືອ $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "ຍົກເລີກ"
 ]
});
