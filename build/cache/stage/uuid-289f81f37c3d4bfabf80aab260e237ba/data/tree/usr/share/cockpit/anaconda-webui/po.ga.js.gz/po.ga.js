cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1 ? 0 : n==2 ? 1 : n<7 ? 2 : n<11 ? 3 : 4)),
  "language": "ga",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "Suiteáil $0"
 ],
 "$0 installer": [
  null,
  "Suiteálaí $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "Is críochdheighilt leathnaithe MBR é $0 ina bhfuil críochdheighiltí loighciúla. Má bhaintear na críochdheighiltí loighciúla go léir, bainfear an críochdheighilt leathnaithe go huathoibríoch freisin."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "Tá $0 ag teastáil, ach níl ach $1 ar fáil."
 ],
 "$0 warning": [
  null,
  "$0 Rabhadh",
  "$0 Rabhaidh",
  "$0 Rabhaidh",
  "$0 Rabhaidh",
  "$0 Rabhaidh"
 ],
 "$0 will be deleted": [
  null,
  "Scriosfar $0"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Ní féidir leis an gcóras comhad '$0' a bheith ar ghléas bloc criptithe"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "Caithfidh '$0' a bheith ar ghléas atá formáidithe go '$1'"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Fuarthas an chuid '$0' ar an ngléas MDRAID $1. Ní thacaítear le cuid an luchtóra tosaithe ar ghléasanna MDRAID."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Cuntas úsáideora caighdeánach le rochtain riarthóra chun athruithe a dhéanamh ar fud an chórais."
 ],
 "About": [
  null,
  "Faoi"
 ],
 "Account": [
  null,
  "Cuntas"
 ],
 "Actions": [
  null,
  "Gníomhartha"
 ],
 "Add another server...": [
  null,
  "Cuir freastalaí eile leis..."
 ],
 "Add mount": [
  null,
  "Cuir mount"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Breiseáin don timpeallacht roghnaithe agat"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Breiseáin nach bhfuil sainiúil do do thimpeallacht"
 ],
 "Additional languages": [
  null,
  "Teangacha breise"
 ],
 "Additional software for the selected environment": [
  null,
  "Bogearraí breise don timpeallacht roghnaithe"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Tagann gach athrú a dhéantar ar an eagarthóir stórála i bhfeidhm láithreach."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Díghlasálfar gach gléas a úsáideann an pasfhrása seo"
 ],
 "Anaconda Web UI": [
  null,
  "Chomhéadain Gréasáin Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Leathanach tionscadail Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Cuir sannadh pointe mount i bhfeidhm agus suiteáil"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Sann landairí chun pointí a fheistiú. Úsáideach le haghaidh leagan amach saincheaptha réamhchumraithe."
 ],
 "Automatic log file upload": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Socraigh dáta agus am go huathoibríoch, ag baint úsáide as freastalaithe ama"
 ],
 "Automatically set timezone": [
  null,
  "Socraigh crios ama go huathoibríoch"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Spás saor in aisce ar fáil: $0. Teastaíonn: $1 le suiteáil."
 ],
 "Back": [
  null,
  "Ar ais"
 ],
 "Base environment": [
  null,
  "Buntimpeallacht"
 ],
 "Brief description of the issue": [
  null,
  ""
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Trí leanúint ag baint úsáide as na bogearraí seo, tuigeann tú agus glacann tú leis na rioscaí a bhaineann le bogearraí réamheisithe, go bhfuil sé ar intinn agat é seo a úsáid chun críocha tástála agus forbartha amháin agus go bhfuil tú sásta aon fhabhtanna nó saincheisteanna a thuairisciú chun an obair seo a fheabhsú."
 ],
 "Cancel": [
  null,
  "Cealaigh"
 ],
 "Change": [
  null,
  "Athrú"
 ],
 "Change destination": [
  null,
  "Athraigh ceann scríbe"
 ],
 "Change hostname": [
  null,
  "Athraigh an t-óstainm"
 ],
 "Change partition layout": [
  null,
  "Athraigh leagan amach na críochdheighilte"
 ],
 "Change system keyboard layout": [
  null,
  "Athraigh leagan amach méarchláir an chórais"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Cuirfidh athruithe a dhéanfar anseo isteach ar an gcóras láithreach. Níl aon ‘cealaigh’."
 ],
 "Checking storage configuration": [
  null,
  "Cumraíocht stórála á seiceáil"
 ],
 "Clear search": [
  null,
  "Glan an cuardach"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Cliceáil 'Ar Aghaidh' arís le dul ar aghaidh in ainneoin na rabhaidh seo."
 ],
 "Close": [
  null,
  "Dún"
 ],
 "Close storage editor": [
  null,
  "Dún eagarthóir stórála"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Níor sholáthair stóras cockpit an pasfhrása chun gléas criptithe a dhíghlasáil."
 ],
 "Completed": [
  null,
  "Críochnaithe"
 ],
 "Configuration is incomplete": [
  null,
  ""
 ],
 "Configure NTP servers": [
  null,
  "Cumraigh freastalaithe NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Cumraigh freastalaithe NTP saincheaptha"
 ],
 "Configure storage": [
  null,
  "Cumraigh stóráil"
 ],
 "Configure storage again": [
  null,
  "Cumraigh stóras arís"
 ],
 "Confirm passphrase": [
  null,
  "Deimhnigh pasfhrása"
 ],
 "Continue": [
  null,
  "Ar Aghaidh"
 ],
 "Continue installation": [
  null,
  "Lean ar aghaidh leis an tsuiteáil"
 ],
 "Continue with installation": [
  null,
  "Lean ar aghaidh leis an tsuiteáil"
 ],
 "Correct these issues before continuing.": [
  null,
  ""
 ],
 "Create Account": [
  null,
  "Cruthaigh Cuntas"
 ],
 "Create account": [
  null,
  "Cruthaigh cuntas"
 ],
 "Currently installed: $0": [
  null,
  "Suiteáilte faoi láthair: $0"
 ],
 "Custom": [
  null,
  "Saincheaptha"
 ],
 "Date": [
  null,
  "Dáta"
 ],
 "Date and time": [
  null,
  "Dáta agus am"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Má scriostar deighiltí áirithe b'fhéidir go gcuirfí bac ar $0 a bhrú: $1"
 ],
 "Description": [
  null,
  "Cur síos"
 ],
 "Destination": [
  null,
  "Ceann Scríbe"
 ],
 "Destination is encrypted": [
  null,
  "Tá an ceann scríbe criptithe"
 ],
 "Detailed description of the issue": [
  null,
  ""
 ],
 "Detected valid storage layout:": [
  null,
  "Braitheadh leagan amach bailí stórála:"
 ],
 "Device": [
  null,
  "Gléas"
 ],
 "Duplicate device.": [
  null,
  "Gléas dúblach."
 ],
 "Duplicate mount point.": [
  null,
  "Pointe gléasta dúblach."
 ],
 "Enable root account": [
  null,
  "Cumasaigh cuntas fréimhe"
 ],
 "Encrypt my data": [
  null,
  "Criptigh mo chuid sonraí"
 ],
 "Encrypted": [
  null,
  "Criptithe"
 ],
 "Encryption": [
  null,
  "Criptiú"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "Scrios sonraí agus suiteáil"
 ],
 "Error details": [
  null,
  "Sonraí earráide"
 ],
 "Exit to live desktop": [
  null,
  "Scoir go dtí an deasc beo"
 ],
 "Extended partition": [
  null,
  "Deighilt leathnaithe"
 ],
 "Failed to save layouts": [
  null,
  "Theip ar leagan amach a shábháil"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Teastaíonn $0 ar a laghad de spás diosca ó Fedora linux."
 ],
 "Finalization": [
  null,
  "Críochnú"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Críochnú: Tá cumraíocht an chórais críochnaithe. Seans go dtógfaidh sé cúpla nóiméad an tsuiteáil a thabhairt chun críche."
 ],
 "Find layout": [
  null,
  "Aimsigh leagan amach"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Chun slándáil níos fearr a fháil, seachain an cuntas fréimhe a úsáid go díreach. Ina áit sin, bain úsáid as an gcuntas áitiúil thuas chun an córas a bhainistiú."
 ],
 "Full name": [
  null,
  "Ainm iomlán"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Ní féidir carachtair idirstad a bheith san ainm iomlán"
 ],
 "Helper text": [
  null,
  "Téacs cúnta"
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "Folaigh pasfhocal deimhnithe"
 ],
 "Hide passphrase": [
  null,
  "Folaigh pasfhrása"
 ],
 "Hide password": [
  null,
  "Folaigh pasfhocal"
 ],
 "Hostname": [
  null,
  "Óstainm"
 ],
 "How would you like to install?": [
  null,
  "Conas ba mhaith leat a shuiteáil?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Tuigim go scriosfar roinnt sonraí atá ann cheana féin"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Tuigim go ndéanfar roinnt deighiltí a mhodhnú"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Má tá sé folamh, beidh an t-óstainm neamhbhuan agus socraithe ag faisnéis líonra."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Má tá deighiltí á chumrú agat, beidh na rudaí seo a leanas ag teastáil:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Mura dtuigeann tú nó mura nglacann tú leis na rioscaí, scoir as an gclár seo."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Ar siúl"
 ],
 "Initializing...": [
  null,
  "Ag tosú..."
 ],
 "Install": [
  null,
  "Suiteáil"
 ],
 "Installation failed": [
  null,
  "Theip ar an tsuiteáil"
 ],
 "Installation method": [
  null,
  "Modh suiteála"
 ],
 "Installation of the system failed": [
  null,
  "Theip ar shuiteáil an chórais"
 ],
 "Installation of the system failed: $0": [
  null,
  "Theip ar shuiteáil an chórais: $0"
 ],
 "Installation type": [
  null,
  "Cineál suiteála"
 ],
 "Installing": [
  null,
  "Suiteáil"
 ],
 "Insufficient disk space": [
  null,
  "Easpa spáis diosca"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Braitheadh cumraíocht RAID neamhbhailí. Má chruthaítear d'eagar RAID go díreach ar bharr dioscaí, ní mór tábla deighilte a chruthú ar an eagar. Má chruthaítear d'eagar RAID ar bharr deighiltí, ní mór córas comhad nó formáid aonair a bheith ann (e.g., LVM PV). Déanfar neamhaird d'aon deighiltí atá ann cheana féin ar an eagar seo."
 ],
 "Invalid hostname": [
  null,
  "Ainm óstach neamhbhailí"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Coinnigh leagan amach reatha an diosca agus bain úsáid as an spás atá ar fáil chun dé-thosú a dhéanamh le OS eile."
 ],
 "Keyboard": [
  null,
  "Méarchlár"
 ],
 "Keyboard layout during boot": [
  null,
  "Leagan amach an mhéarchláir le linn tosaithe"
 ],
 "Language": [
  null,
  "Teanga"
 ],
 "Launch storage editor": [
  null,
  "Seoladh eagarthóir stórála"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Suíomh"
 ],
 "Locked devices": [
  null,
  "Gléasanna faoi ghlas"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  "Déan reatha"
 ],
 "Manual disk configuration": [
  null,
  "Cumraíocht diosca láimhe"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Cumraíocht diosca láimhe: mount mapáil pointe"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "D’fhéadfadh litreacha, uimhreacha agus daiseanna a bheith ann."
 ],
 "May need more free space": [
  null,
  "B’fhéidir go mbeadh níos mó spáis saor in aisce ag teastáil"
 ],
 "Medium": [
  null,
  "Mheán"
 ],
 "Minimum of $0 required": [
  null,
  "Íosmhéid $0 ag teastáil"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Mímheaitseáil idir an tuismitheoir gléas agus an rogha athfhormáidithe gléas linbh."
 ],
 "Mount point": [
  null,
  "Pointe gléasta"
 ],
 "Mount point assignment": [
  null,
  "Suiteáil pointe sannadh"
 ],
 "Move down": [
  null,
  "Bog síos"
 ],
 "Move up": [
  null,
  "Bog suas"
 ],
 "Must be at least $0 characters": [
  null,
  "$0 carachtar ar a laghad a bheith ann"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "Freastalaithe NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Ainm"
 ],
 "Needs at least $0": [
  null,
  "Teastaíonn $0 ar a laghad"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Níl an líonra ar fáil. Cumraigh an líonra sa roghchlár barra barr chun an cheist a thuairisciú."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Níl an líonra ar fáil. Cumraigh an líonra chun an cheist a thuairisciú."
 ],
 "Next": [
  null,
  "Ar aghaidh"
 ],
 "No devices": [
  null,
  "Gan feistí"
 ],
 "No disks available": [
  null,
  "Níl dioscaí ar fáil"
 ],
 "No disks selected": [
  null,
  "Níor roghnaíodh dioscaí"
 ],
 "No layouts selected yet": [
  null,
  "Níl aon leagan amach roghnaithe fós"
 ],
 "No results found": [
  null,
  "Níor aimsíodh aon torthaí"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Ní féidir aon léarscáil eochrach VConsole bailí a fháil don leagan amach méarchláir roghnaithe. Roghnaigh leagan amach méarchláir difriúil le do thoil."
 ],
 "Not enough available free space": [
  null,
  "Níl dóthain spáis saor in aisce ar fáil"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Níl go leor spáis saor in aisce ar na dioscaí roghnaithe."
 ],
 "Not enough space on selected disks.": [
  null,
  "Níl go leor spáis ar dhioscaí roghnaithe."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Fógra: Is bogearraí réamheisithe é seo atá beartaithe chun críocha forbartha agus tástála amháin. NÁ húsáid na bogearraí seo le haghaidh aon obair ríthábhachtach nó le haghaidh timpeallachtaí táirgthe."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Córas oibriucháin"
 ],
 "Options": [
  null,
  "Roghanna"
 ],
 "Other keyboards": [
  null,
  "Méarchláir eile"
 ],
 "Partitions (advanced)": [
  null,
  "Deighiltí (chun cinn)"
 ],
 "Passphrase": [
  null,
  "Pasfhocal"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Níor mheaitseáil an pasfhrása aon ghléas faoi ghlas"
 ],
 "Passphrases must match": [
  null,
  "Ní mór go mbeadh na pasfhocail ag teacht le chéile"
 ],
 "Pending": [
  null,
  "Ar feitheamh"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Ceangail an logchomhad $0 leis an gceist le do thoil."
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "Roghnaigh diosca amháin ar a laghad le leanúint ar aghaidh"
 ],
 "Pool": [
  null,
  "Linn"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Cumhachtaithe ag Anaconda"
 ],
 "Pre-release": [
  null,
  "Réamh-scaoileadh"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Lean ar aghaidh le suiteáil"
 ],
 "Quit": [
  null,
  "Scoir"
 ],
 "Quit installer?": [
  null,
  "An bhfuil fonn ort an suiteálaí a scor?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Theip ar léamh faisnéise faoin OS."
 ],
 "Reading information about the computer failed.": [
  null,
  "Theip ar léamh eolais faoin ríomhaire."
 ],
 "Reading installer configuration failed.": [
  null,
  "Theip ar léamh cumraíocht an suiteálaí."
 ],
 "Reading installer version information failed.": [
  null,
  "Theip ar léamh eolas faoin leagan suiteálaí."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Ní féidir ach carachtair, digití, daiseanna (gan carachtar a thosú nó a chríochnaíonn) agus poncanna a bheith i bhfíor-óstainm"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Caithfidh 64 carachtar nó níos lú a bheith i bhfíor-óstainm"
 ],
 "Reboot": [
  null,
  "Atosaigh"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Atosaigh Windows chun méid na ndeighiltí criptithe le BitLocker a athrú. Déan $0 ar a laghad de spás saor in aisce ar fáil don suiteáil."
 ],
 "Reboot system?": [
  null,
  "Atosaigh an córas?"
 ],
 "Reclaim additional space": [
  null,
  "Íosluchtaigh spás breise"
 ],
 "Reclaim space": [
  null,
  "Faigh spás ar ais"
 ],
 "Reclaim space (required)": [
  null,
  "Faigh spás ar ais (riachtanach)"
 ],
 "Recommended": [
  null,
  "Molta"
 ],
 "Recommended partitions:": [
  null,
  "Deighiltí molta:"
 ],
 "Reformat": [
  null,
  "Athfhormáid"
 ],
 "Reinstall Fedora": [
  null,
  "Athshuiteáil Fedora"
 ],
 "Remove": [
  null,
  "Bain"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Bain gach deighilt ar na gléasanna roghnaithe, lena n-áirítear córais oibriúcháin atá ann cheana féin."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Bain nó athraigh na córais comhad atá ann cheana féin chun spás a shaoradh don suiteáil."
 ],
 "Remove server": [
  null,
  "Bain an freastalaí"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Scriosfar go buan na sonraí go léir atá ann má bhaintear córas comhad. Is féidir le hathrú méide críochdheighilte spás neamhúsáidte a shaoradh, ach níl sé saor ó riosca. Bí cinnte go bhfuil cúltacaí agat d'aon rud tábhachtach sula n-athghabhann tú spás."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Ionadaigh an tsuiteáil reatha, ach coinnigh comhaid sa bhaile."
 ],
 "Report Issue": [
  null,
  "Eisiúint Tuairisce"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Eisiúint tuairisce"
 ],
 "Required": [
  null,
  "Ag teastáil"
 ],
 "Requirements": [
  null,
  "Riachtanais"
 ],
 "Rescan devices": [
  null,
  "Athscan feistí"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Theip ar athscanadh na dioscaí."
 ],
 "Resize": [
  null,
  "Athraigh méid"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Na deighiltí seo a leanas a athrú ó $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Fill ar an suiteáil"
 ],
 "Return to storage editor": [
  null,
  "Fill ar an eagarthóir stórála"
 ],
 "Review and install": [
  null,
  "Athbhreithniú agus a shuiteáil"
 ],
 "Root account is enabled": [
  null,
  "Tá cuntas fréimhe cumasaithe"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Tá cuntas fréimhe cumasaithe, ach níl aon chuntas úsáideora cumraithe"
 ],
 "Save": [
  null,
  "Sábháil"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Scan an cód QR le do ghuthán nó tabhair cuairt ar:"
 ],
 "Search for a language": [
  null,
  "Cuardaigh teanga"
 ],
 "Search for additional software": [
  null,
  "Cuardaigh bogearraí breise"
 ],
 "Search for an environment": [
  null,
  "Cuardaigh timpeallacht"
 ],
 "Search keyboard layout": [
  null,
  "Leagan amach méarchláir cuardaigh"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Déan do shonraí slán trí úsáid a bhaint as criptiúchán diosca-bhunaithe. Ní bhaineann ach le landairí nua"
 ],
 "Select": [
  null,
  "Roghnaigh"
 ],
 "Select a device": [
  null,
  "Roghnaigh gléas"
 ],
 "Select city": [
  null,
  "Roghnaigh cathair"
 ],
 "Select destination": [
  null,
  "Roghnaigh ceann scríbe"
 ],
 "Select region": [
  null,
  "Roghnaigh réigiún"
 ],
 "Selected (top = current)": [
  null,
  "Roghnaithe (barr = reatha)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Ní féidir formáid an ghléis roghnaithe '$0' a athfhormáidiú."
 ],
 "Send us feedback on your installation": [
  null,
  "Seol aiseolas chugainn ar do shuiteáil"
 ],
 "Server": [
  null,
  "Freastalaí"
 ],
 "Server is not reachable": [
  null,
  "Ní féidir teacht ar an bhfreastalaí"
 ],
 "Set custom hostname": [
  null,
  "Socraigh óstainm saincheaptha"
 ],
 "Share disk with other operating systems": [
  null,
  "Comhroinn diosca le córais oibriúcháin eile"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Comhroinn diosca le córais oibriúcháin eile: $0"
 ],
 "Show AM/PM": [
  null,
  "Taispeáin AM/PM"
 ],
 "Show confirmed password": [
  null,
  "Taispeáin pasfhocal deimhnithe"
 ],
 "Show passphrase": [
  null,
  "Taispeáin pasfhrása"
 ],
 "Show password": [
  null,
  "Taispeáin pasfhocal"
 ],
 "Size": [
  null,
  "Méid"
 ],
 "Software installation": [
  null,
  "Suiteáil bogearraí"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Suiteáil bogearraí: cumraíocht stórála críochnaithe. Tá na bogearraí á shuiteáil ar do ghléas anois."
 ],
 "Software selection": [
  null,
  "Rogha bogearraí"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Tá roinnt deighiltí riachtanacha in easnamh: $0"
 ],
 "Space": [
  null,
  "Spás"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Stóráil"
 ],
 "Storage configuration": [
  null,
  "Cumraíocht stórála"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Cumraíocht stórála: Tá an stóráil á chumrú faoi láthair."
 ],
 "Storage editor": [
  null,
  "Eagarthóir stórála"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Tá an stóráil bunaithe ar an gcumraíocht ó 'Modify storage'."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Theip ar an mbreiseán stórála"
 ],
 "Storage requirements not met": [
  null,
  "Níor comhlíonadh na ceanglais stórála"
 ],
 "Strong": [
  null,
  "Láidir"
 ],
 "Successfully installed": [
  null,
  "Suiteáilte go rathúil"
 ],
 "Successfully unlocked $0.": [
  null,
  "D'éirigh le díghlasáil $0."
 ],
 "Suggested keyboards": [
  null,
  "Méarchláir molta"
 ],
 "Suggested languages": [
  null,
  "Teangacha molta"
 ],
 "System": [
  null,
  "Córas"
 ],
 "System configuration": [
  null,
  "Cumraíocht an chórais"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Cumraíocht an chórais: Suiteáil bogearraí críochnaithe. Tá an córas á chumrú anois."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Ní theastaíonn $0 de spás diosca don suiteáil; áfach, níl ach $1 de chumas na ndioscaí roghnaithe."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Ní féidir leis an suiteálaí leanúint ar aghaidh mar gheall ar earráid chriticiúil."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Ní féidir leis an suiteálaí leanúint ar aghaidh mar gheall ar earráid chriticiúil: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Tá carachtair neamh-ASCII sa phasfhrása a sholáthair tú. Seans nach mbeidh tú in ann aistriú idir leagan amach méarchláir agus é á chlóscríobh."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Ní thacaíonn an leagan amach méarchláir réamhshocraithe le carachtair ASCII. Roghnaigh leagan amach atá in ann ASCII a úsáid mar an leagan réamhshocraithe."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Ligeann an t-eagarthóir stórála duit méid na gcríoch a athrú, a scriosadh agus a chruthú. Is féidir leis LVM agus i bhfad níos mó a chur ar bun. Tá sé beartaithe le húsáid mar fhóntas ardleibhéil agus níl sé beartaithe le húsáid i suiteáil tipiciúil."
 ],
 "This hostname can't be submitted": [
  null,
  "Ní féidir an t-óstainm seo a chur isteach"
 ],
 "This is unstable, pre-release software": [
  null,
  "Is bogearraí éagobhsaí, réamhscaoilte é seo"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Úsáidfear an leagan amach seo chun do chóras a dhíghlasáil ag am tosaithe"
 ],
 "This may take a moment": [
  null,
  "Féadfaidh sé seo nóiméad a ghlacadh"
 ],
 "This will take a few moments": [
  null,
  "Tógfaidh sé seo cúpla nóiméad"
 ],
 "Time": [
  null,
  "Am"
 ],
 "Timezone": [
  null,
  "Crios ama"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Chun $0 a úsáid, atosaigh do chóras."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Chun leanúint ar aghaidh, roghnaigh na feistí a shuiteáil go."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Chun an rogha seo a úsáid, athmhéadaigh nó bain na deighiltí atá ann cheana féin chun $0 ar a laghad a shaoradh."
 ],
 "Type": [
  null,
  "Cineál"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Ní féidir scriosadh $0 a sceidealú"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Ní féidir méid $0 a athrú a sceidealú"
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "Díghlasáil"
 ],
 "Unlock encrypted devices": [
  null,
  "Díghlasáil gléasanna criptithe"
 ],
 "Use configured storage": [
  null,
  "Úsáid stóras cumraithe"
 ],
 "Use entire disk": [
  null,
  "Bain úsáid as diosca iomlán"
 ],
 "Use free space": [
  null,
  "Úsáid spás saor in aisce"
 ],
 "Use local account": [
  null,
  "Úsáid cuntas áitiúil"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Úsáid an gléas RAID le haghaidh deighilt uathoibríoch"
 ],
 "User creation": [
  null,
  "Cruthú úsáideora"
 ],
 "User name": [
  null,
  "Ainm úsáideora"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Ní féidir ach na nithe seo a leanas a bheith san ainm úsáideora: litreacha ó a-z, digití 0-9, dash $0, tréimhse $1, béim ar $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Ní ceadmhach ainm úsáideora a bheith ina fhocal forchoimeádta"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Caithfidh ainmneacha úsáideoirí a bheith níos giorra ná 33 carachtar"
 ],
 "Weak": [
  null,
  "Lag"
 ],
 "Welcome": [
  null,
  "Fáilte"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Fáilte go Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Fáilte. Suiteáil $0 anois."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Ní féidir deighiltí Windows le criptiú BitLocker a athrú méid"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Is féidir leat go leor spáis a shaoradh anseo agus ligean don suiteálaí an chuid eile a láimhseáil nó landairí a shocrú de láimh."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Caithfidh tú an cuntas fréimhe a chumasú nó cuntas úsáideora áitiúil a chruthú le dul ar aghaidh."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Ní mór duit a bheith ceangailte le líonra chun dáta agus am uathoibríoch a chumasú."
 ],
 "Your progress will not be saved.": [
  null,
  "Ní shábhálfar do dhul chun cinn."
 ],
 "completed step": [
  null,
  "chéim chríochnaithe"
 ],
 "current step": [
  null,
  "céim reatha"
 ],
 "delete": [
  null,
  "scrios"
 ],
 "edit": [
  null,
  "eagar"
 ],
 "encrypt": [
  null,
  "chriptigh"
 ],
 "encrypted": [
  null,
  "criptithe"
 ],
 "extended partition": [
  null,
  "críochdheighilt leathnaithe"
 ],
 "format as $0": [
  null,
  "formáid $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "sléibhe"
 ],
 "pending step": [
  null,
  "céim ar feitheamh"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "athrú ó $0"
 ],
 "shrink": [
  null,
  "crapadh"
 ],
 "shrink to $0": [
  null,
  "Laghdaigh go $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "cealaigh"
 ]
});
