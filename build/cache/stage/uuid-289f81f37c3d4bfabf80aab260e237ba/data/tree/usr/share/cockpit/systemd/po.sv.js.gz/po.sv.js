cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Journal": [
  null,
  "Journal"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Hårdvaruinformation"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Remove": [
  null,
  "Avlägsna"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Light": [
  null,
  "Ljust"
 ],
 "Dark": [
  null,
  "Mörk"
 ],
 "Help": [
  null,
  "Hjälp"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "System": [
  null,
  "System"
 ],
 "Search": [
  null,
  "Sök"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "Permission denied": [
  null,
  "Åtkomst nekas"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Inga metoder för att få administrativ åtkomst finns tillgängliga (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Method": [
  null,
  "Metod"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Acceptable password": [
  null,
  "Godtagbart lösenord"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder ska slutföras"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "Downloading $0": [
  null,
  "Laddar ner $0"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterade felkod $0"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Error during initialization": [
  null,
  "Fel under initialisering"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Home": [
  null,
  "Hem"
 ],
 "Downloads": [
  null,
  "Hämtningar"
 ],
 "Not a directory": [
  null,
  "Inte en katalog"
 ],
 "All files": [
  null,
  "Alla filer"
 ],
 "Recent": [
  null,
  "Senaste"
 ],
 "No recent directories": [
  null,
  "Inga senaste kataloger"
 ],
 "No recent files": [
  null,
  "Inga senaste filer"
 ],
 "Type to filter": [
  null,
  "Skriv för att filtrera"
 ],
 "File chooser actions": [
  null,
  "Filväljare åtgärder"
 ],
 "Open in file browser": [
  null,
  "Öppna i filhanterare"
 ],
 "Hide hidden files": [
  null,
  "Dölj dolda filer"
 ],
 "Show hidden files": [
  null,
  "Visa dolda filer"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Clear filters": [
  null,
  "Rensa filter"
 ],
 "Directory is empty": [
  null,
  "Katalog är tom"
 ],
 "Directory has no sub-directories": [
  null,
  "Katalogen har inga underkataloger"
 ],
 "This directory contains only hidden files": [
  null,
  "Den här katalogen innehåller endast dolda filer"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "Folder": [
  null,
  "Mapp"
 ],
 "File": [
  null,
  "Arkiv"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "$0 is not a directory": [
  null,
  "$0 är inte en katalog"
 ],
 "$0 does not exist": [
  null,
  "$0 existerar inte"
 ],
 "Font size": [
  null,
  "Textstorlek"
 ],
 "Decrease by one": [
  null,
  "Minska med en"
 ],
 "Increase by one": [
  null,
  "Öka med en"
 ],
 "Appearance": [
  null,
  "Utseende"
 ],
 "Black": [
  null,
  "Svart"
 ],
 "White": [
  null,
  "Vit"
 ],
 "Reset": [
  null,
  "Återställ"
 ],
 "Unable to open directory": [
  null,
  "Misslyckades med att öppna katalog"
 ],
 "Running process prevents directory change": [
  null,
  "Körande process förhindrar katalogbyte"
 ],
 "Change directory": [
  null,
  "Byt katalog"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Om du byter katalog kommer den pågående processen att stoppas med kraft. Processen kan också stoppas manuellt i terminalen innan den fortsätter."
 ],
 "Terminal not available": [
  null,
  "Terminal är inte tillgänglig"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Den här webbläsaren stöder inte WebGL2."
 ],
 "unknown": [
  null,
  "okänd"
 ],
 "Shutdown": [
  null,
  "Stäng av"
 ],
 "running $0": [
  null,
  "kör $0"
 ],
 "Current boot": [
  null,
  "Nuvarande uppstart"
 ],
 "Previous boot": [
  null,
  "Tidigare uppstart"
 ],
 "Last 24 hours": [
  null,
  "Senaste 24 timmarna"
 ],
 "Last 7 days": [
  null,
  "Senaste 7 dagarna"
 ],
 "Only emergency": [
  null,
  "Endast nödläge"
 ],
 "Alert and above": [
  null,
  "Larm och högre"
 ],
 "Critical and above": [
  null,
  "Kritisk och högre"
 ],
 "Error and above": [
  null,
  "Fel och högre"
 ],
 "Warning and above": [
  null,
  "Varning och högre"
 ],
 "Notice and above": [
  null,
  "Notering och högre"
 ],
 "Info and above": [
  null,
  "Info och högre"
 ],
 "Debug and above": [
  null,
  "Felsökning och högre"
 ],
 "Toggle filters": [
  null,
  "Växla filter"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Identifier": [
  null,
  "Identifierare"
 ],
 "Filters": [
  null,
  "Filter"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Resume": [
  null,
  "Återuppta"
 ],
 "All": [
  null,
  "Alla"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumspecifikationen skall ha formatet ÅÅÅÅ-MM-DD hh:mm:ss. Alternativt förstås strängarna ”yesterday”, ”today”, ”tomorrow”. ”now” refererar till den aktuella tiden. Slutligen kan relativa tider anges, inledda med ”-” eller ”+”"
 ],
 "Since": [
  null,
  "Sedan"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Börja visa poster på eller nyare än det angivna datumet."
 ],
 "Until": [
  null,
  "Tills"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Börja visa poster på eller äldre än det angivna datumet."
 ],
 "Boot": [
  null,
  "Start"
 ],
 "Show messages from a specific boot.": [
  null,
  "Visa meddelanden från en specifik start."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Detta kommer lägga till en matchning av ”_BOOT_ID=”. Om det inte anges kommer den aktuella uppstarten visas. Om uppstarts-ID:t utelämnas kommer ett positivt avstånd leta efter uppstarter från början av journalen och ett lika-med-eller-mindre-än noll-avstånd leta efter uppstarter från slutet av journalen. Alltså betyder 1 den första uppstarten som finns i journalen i kronologisk ordning, 2 den andra och så vidare; medan -0 är sista uppstarten, -1 uppstarten före det, och så vidare."
 ],
 "Unit": [
  null,
  "Enhet"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Visa meddelande för den angivna systemd-enheten."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Detta lägger till matchningar för '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' och 'UNIT=' för att hitta alla möjliga meddelanden för den givna enheten. Kan innehålla fler enheter separerade med kommatecken."
 ],
 "Free-form search": [
  null,
  "Friformssökning"
 ],
 "Show messages containing given string.": [
  null,
  "Visa meddelanden som innehåller en given sträng."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Alla textsträngar i loggmeddelandena kan filtreras. Strängen kan också vara i form av ett reguljärt uttryck. Stöder även filtrering efter meddelandeloggfält. Dessa är mellanslagsseparerade värden, i formen FÄLT=VÄRDE, där värde kan vara kommaseparerad lista över möjliga värden."
 ],
 "journalctl manpage": [
  null,
  "journalctl mansida"
 ],
 "Successfully copied to clipboard": [
  null,
  "Kopierades till urklipp"
 ],
 "Create timer": [
  null,
  "Skapa en timer"
 ],
 "Edit timer": [
  null,
  "Redigera timer"
 ],
 "Timer creation failed": [
  null,
  "Att skapa en timer misslyckades"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Misslyckades med att hämta startvillkoren för timer"
 ],
 "Failed to get the timer command": [
  null,
  "Misslyckades med hämta timer kommando"
 ],
 "This field cannot be empty": [
  null,
  "Detta fält får inte vara tomt"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Endast alfabetet, siffror, :, _, ., @, - är tillåtna"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Shell command": [
  null,
  "Skal kommando"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Detta kommando kommer att köras med /bin/sh."
 ],
 "Trigger": [
  null,
  "Utlösare"
 ],
 "At specific time": [
  null,
  "Vid en specifik tidpunkt"
 ],
 "After system boot": [
  null,
  "Efter systemstart"
 ],
 "Seconds": [
  null,
  "Sekunder"
 ],
 "Minutes": [
  null,
  "Minuter"
 ],
 "Hours": [
  null,
  "Timmar"
 ],
 "Weeks": [
  null,
  "Veckor"
 ],
 "Delay must be a number": [
  null,
  "Fördröjning måste vara en siffra"
 ],
 "Repeat": [
  null,
  "Upprepa"
 ],
 "Don't repeat": [
  null,
  "Upprepa inte"
 ],
 "Minutely": [
  null,
  "Minutvis"
 ],
 "Hourly": [
  null,
  "Varje timme"
 ],
 "Daily": [
  null,
  "Dagligen"
 ],
 "Weekly": [
  null,
  "Veckovis"
 ],
 "Monthly": [
  null,
  "Månadsvis"
 ],
 "Yearly": [
  null,
  "Årligen"
 ],
 "Run at": [
  null,
  "Kör vid"
 ],
 "At second": [
  null,
  "På sekund"
 ],
 "At minute": [
  null,
  "På minut"
 ],
 "Run on": [
  null,
  "Kör på"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuterna måste vara ett tal mellan 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunder måste vara ett tal mellan 0-59"
 ],
 "Repeat weekly": [
  null,
  "Upprepa varje vecka"
 ],
 "Mondays": [
  null,
  "Måndagar"
 ],
 "Tuesdays": [
  null,
  "Tisdagar"
 ],
 "Wednesdays": [
  null,
  "Onsdagar"
 ],
 "Thursdays": [
  null,
  "Torsdagar"
 ],
 "Fridays": [
  null,
  "Fredagar"
 ],
 "Saturdays": [
  null,
  "Lördagar"
 ],
 "Sundays": [
  null,
  "Söndagar"
 ],
 "Repeat monthly": [
  null,
  "Upprepa månadsvis"
 ],
 "1st": [
  null,
  "1:a"
 ],
 "2nd": [
  null,
  "2:a"
 ],
 "3rd": [
  null,
  "3:e"
 ],
 "4th": [
  null,
  "4:e"
 ],
 "5th": [
  null,
  "5:e"
 ],
 "6th": [
  null,
  "6:e"
 ],
 "7th": [
  null,
  "7:e"
 ],
 "8th": [
  null,
  "8:e"
 ],
 "9th": [
  null,
  "9:e"
 ],
 "10th": [
  null,
  "10:e"
 ],
 "11th": [
  null,
  "11:e"
 ],
 "12th": [
  null,
  "12:e"
 ],
 "13th": [
  null,
  "13:e"
 ],
 "14th": [
  null,
  "14:e"
 ],
 "15th": [
  null,
  "15:e"
 ],
 "16th": [
  null,
  "16:e"
 ],
 "17th": [
  null,
  "17:e"
 ],
 "18th": [
  null,
  "18:e"
 ],
 "19th": [
  null,
  "19:e"
 ],
 "20th": [
  null,
  "20:e"
 ],
 "21th": [
  null,
  "21:a"
 ],
 "22th": [
  null,
  "22:a"
 ],
 "23th": [
  null,
  "23:e"
 ],
 "24th": [
  null,
  "24:e"
 ],
 "25th": [
  null,
  "25:e"
 ],
 "26th": [
  null,
  "26:e"
 ],
 "27th": [
  null,
  "27:e"
 ],
 "28th": [
  null,
  "28:e"
 ],
 "29th": [
  null,
  "29:e"
 ],
 "30th": [
  null,
  "30:e"
 ],
 "31st": [
  null,
  "31:a"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Unclean shutdown": [
  null,
  "Oren avstängning"
 ],
 "View logs": [
  null,
  "Visa loggar"
 ],
 "Dismiss": [
  null,
  "Avfärda"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Schemalagd avstängning vid $0"
 ],
 "Cancel poweroff": [
  null,
  "Avbryt avstängning"
 ],
 "Scheduled reboot at $0": [
  null,
  "Schemalagd omstart till $0"
 ],
 "Cancel reboot": [
  null,
  "Avbryt omstart"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "Set hostname": [
  null,
  "Ange värdnamn"
 ],
 "Configuration": [
  null,
  "Konfiguration"
 ],
 "Hostname": [
  null,
  "Värdnamn"
 ],
 "System time": [
  null,
  "Systemtid"
 ],
 "Domain": [
  null,
  "Domän"
 ],
 "Performance profile": [
  null,
  "Prestandaprofil"
 ],
 "Secure shell keys": [
  null,
  "Säkra skalnycklar"
 ],
 "Show fingerprints": [
  null,
  "Visa fingeravtryck"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "misslyckades att lista ssh-värdnycklar: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Inläsningen av SSH-nycklar misslyckades"
 ],
 "Error message": [
  null,
  "Felmeddelande"
 ],
 "Loading keys...": [
  null,
  "Läser in nycklar..."
 ],
 "No host keys found.": [
  null,
  "Inga värdnycklar hittade."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Maskinens SSH-nyckels fingeravtryck"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Det verkliga värdnamnet får bara vara 64 tecken eller mindre"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Det verkliga värdnamnet kan endast innehålla gemena bokstäver, siffror, bindestreck och punkter (med populerade underdomäner)"
 ],
 "Change host name": [
  null,
  "Ändra värdnamn"
 ],
 "Pretty host name": [
  null,
  "Snyggt värdnamn"
 ],
 "Real host name": [
  null,
  "Verkligt värdnamn"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Användaren $0 har inte rättighet att ändra kryptografisk policy"
 ],
 "Cryptographic policy": [
  null,
  "Kryptografisk policy"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Rekommenderade, säkra inställningar för aktuella hotmodeller."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT med verifiering av SHA-1-signatur tillåten."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Högre interoperabilitet till priset av en ökad attackyta."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY med Active Directory-interoperabilitet."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Använd endast godkända och tillåtna algoritmer vid uppstart i FIPS-läge."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS med ytterligare begränsningar av allmänna kriterier."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Skyddar mot förutsedda attacker på kort sikt på bekostnad av interoperabilitet."
 ],
 "Custom cryptographic policy": [
  null,
  "Anpassad kryptografisk policy"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografisk policy är en systemkomponent som konfigurerar de grundläggande kryptografiska undersystemen, innefattande protokollen TLS, IPSec, SSH, DNSSec och Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Ändra kryptografisk policy"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Tar ny policy i drift … Detta kan ta några minuter."
 ],
 "Reapply and reboot": [
  null,
  "Återverkställ och starta om"
 ],
 "Apply and reboot": [
  null,
  "Verkställ och starta om"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS är inte korrekt aktiverat"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Kryptografipolicyn är inkonsekvent"
 ],
 "Review cryptographic policy": [
  null,
  "Granska kryptografisk policy"
 ],
 "System information": [
  null,
  "Systeminformation"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Asset tag": [
  null,
  "MaskinID"
 ],
 "Machine ID": [
  null,
  "Maskin-ID"
 ],
 "Up since": [
  null,
  "Uppe sedan"
 ],
 "View hardware details": [
  null,
  "Visa hårdvarudetaljer"
 ],
 "Last successful login:": [
  null,
  "Senaste lyckade inloggning:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 misslyckat inloggningsförsök",
  "$0 misslyckade inloggningsförsök"
 ],
 "View login history": [
  null,
  "Visa inloggningshistorik"
 ],
 "recommended": [
  null,
  "rekommenderad"
 ],
 "inconsistent": [
  null,
  "inkonsekvent"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Att gå med i en domän kräver installation av realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kan inte ansluta till en domän eftersom realmd inte finns på detta system"
 ],
 "Joining this domain is not supported": [
  null,
  "Att gå med i denna domän stödjs inte"
 ],
 "Login format": [
  null,
  "Inloggningsformat"
 ],
 "Server software": [
  null,
  "Serverprogramvara"
 ],
 "Client software": [
  null,
  "Klientprogramvara"
 ],
 "Leave domain": [
  null,
  "Lämna domänen"
 ],
 "Leave $0": [
  null,
  "Lämna $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Om du lämnar domänen kommer bara lokala användare kunna logga in på den här datorn. Det kan också påverka andra tjänster eftersom DNS och listan av betrodda CA kan ändras."
 ],
 "Validating address": [
  null,
  "Validerar adress"
 ],
 "Contacted domain": [
  null,
  "Kontaktade domänen"
 ],
 "Domain could not be contacted": [
  null,
  "Domän kunde inte kontaktas"
 ],
 "Domain is not supported": [
  null,
  "Domän stödjs inte"
 ],
 "Domain address": [
  null,
  "Domänadress"
 ],
 "Domain administrator name": [
  null,
  "Domänadministratörens namn"
 ],
 "Domain administrator password": [
  null,
  "Domänadministratörens lösenord"
 ],
 "Joining": [
  null,
  "Går med"
 ],
 "Join": [
  null,
  "Gå med"
 ],
 "This may take a while": [
  null,
  "Detta kan ta ett tag"
 ],
 "Not permitted to configure realms": [
  null,
  "Inte tillåtet att konfigurera att ändra riken"
 ],
 "Join domain": [
  null,
  "Gå med i domän"
 ],
 "Install realmd support": [
  null,
  "Installera realmd stöd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disk är på väg att gå sönder",
  "$0 diskarna är på väg att gå sönder"
 ],
 "Connected to Insights": [
  null,
  "Ansluten till Insights"
 ],
 "Not connected to Insights": [
  null,
  "Inte ansluten till Insights"
 ],
 "Health": [
  null,
  "Hälsa"
 ],
 "of $0 CPU": [
  null,
  "av $0 CPU-kärna",
  "av $0 CPU-kärnor"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "View metrics and history": [
  null,
  "Visa mätvärden och historik"
 ],
 "Tuned is not available": [
  null,
  "Tuned är inte tillgänglig"
 ],
 "Tuned is not running": [
  null,
  "Tuned kör inte"
 ],
 "Tuned is off": [
  null,
  "Tuned är avslagen"
 ],
 "This system is using the recommended profile": [
  null,
  "Detta system använder den rekommenderade profilen"
 ],
 "This system is using a custom profile": [
  null,
  "Detta system använder en anpassad profil"
 ],
 "none": [
  null,
  "ingen"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikationen med tuned har misslyckats"
 ],
 "Failed to enable tuned": [
  null,
  "Misslyckades att aktivera tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Misslyckades att avaktivera tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Misslyckades med att avaktivera en tuned-profil"
 ],
 "Failed to switch profile": [
  null,
  "Misslyckades att byta profil"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Disable tuned": [
  null,
  "Avaktivera tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned har misslyckats med att starta"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned är en tjänst som övervakar systemet och optimerar prestandan under vissa belastningar. Kärnan av Tuned är profiler, vilka trimmar systemet för olika användningsfall."
 ],
 "Change performance profile": [
  null,
  "Ändra prestandaprofil"
 ],
 "Change profile": [
  null,
  "Ändra profil"
 ],
 "Edit /etc/motd": [
  null,
  "Redigera /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Misslyckades med att spara ändringar i /etc/motd"
 ],
 "Save changes": [
  null,
  "Spara ändringar"
 ],
 "Edit motd": [
  null,
  "Redigera motd"
 ],
 "Stub": [
  null,
  "Stubbe"
 ],
 "Not found": [
  null,
  "Finns inte"
 ],
 "Bad setting": [
  null,
  "Dålig inställning"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Merged": [
  null,
  "Sammanslagna"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "Reloading": [
  null,
  "Laddar om"
 ],
 "Not running": [
  null,
  "Kör inte"
 ],
 "Failed to start": [
  null,
  "Misslyckades att starta"
 ],
 "Maintenance": [
  null,
  "Underhåll"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Linked": [
  null,
  "Länkad"
 ],
 "Alias": [
  null,
  "alias"
 ],
 "Masked": [
  null,
  "Gömd"
 ],
 "Static": [
  null,
  "Statisk"
 ],
 "Invalid": [
  null,
  "Felaktig"
 ],
 "Indirect": [
  null,
  "Indirekt"
 ],
 "Generated": [
  null,
  "Genererad"
 ],
 "Transient": [
  null,
  "Transient"
 ],
 "Bad": [
  null,
  "Dålig"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Att prenumerera på systemd-signaler misslyckades: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Anslutningen till dbus misslyckades: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Misslyckades att lista enheter: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 tjänsten har misslyckats",
  "$0 tjänsterna har misslyckats"
 ],
 "Loading of units failed": [
  null,
  "Inläsningen av enheter misslyckades"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Listing units": [
  null,
  "Listar enheter"
 ],
 "Filter by name or description": [
  null,
  "Filtrera efter namn eller beskrivning"
 ],
 "Active state": [
  null,
  "Aktivt tillstånd"
 ],
 "File state": [
  null,
  "Filstatus"
 ],
 "$0 filters applied": [
  null,
  "$0 filter applicerade"
 ],
 "User": [
  null,
  "Användare"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Användare $0 tillåts inte ändra CPU-säkerhetsbegränsningar"
 ],
 "Mitigations": [
  null,
  "Rättningar"
 ],
 "Version": [
  null,
  "Version"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "BIOS-version"
 ],
 "BIOS date": [
  null,
  "BIOS-datum"
 ],
 "CPU security": [
  null,
  "CPU-säkerhet"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Stäng av hyperthreading"
 ],
 "Read more...": [
  null,
  "Läs mer..."
 ],
 "Save and reboot": [
  null,
  "Spara och starta om"
 ],
 "CPU security toggles": [
  null,
  "CPU-säkerhetsinställningar"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Programvarubaserade sätt att gå runt problem hjälper till att förhindra CPU-säkerhetsrisker. Dessa begränsningar har sidoeffekten att reducera prestanda. Ändra dessa inställningar på egen risk."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Klass"
 ],
 "Vendor": [
  null,
  "Leverantör"
 ],
 "Slot": [
  null,
  "Plats"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Memory technology": [
  null,
  "Minnesteknologi"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Rank": [
  null,
  "Ordning"
 ],
 "Speed": [
  null,
  "Hastighet"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Att visa minnesinformation kräver administrativ åtkomst."
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "Failed to fetch logs": [
  null,
  "Misslyckades att hämta loggar"
 ],
 "Clear all filters": [
  null,
  "Nollställ alla filter"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Hittade inga loggar med dessa filter aktiva."
 ],
 "No logs found": [
  null,
  "Inga loggar hittades"
 ],
 "Load earlier entries": [
  null,
  "Läs in tidigare poster"
 ],
 "You may try to load older entries.": [
  null,
  "Du kan försöka ladda äldre poster."
 ],
 "Allow running (unmask)": [
  null,
  "Tillåt start (göm inte)"
 ],
 "Reload": [
  null,
  "Läs om"
 ],
 "Restart": [
  null,
  "Starta om"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Clear 'Failed to start'": [
  null,
  "Nollställ \"Misslyckad start\""
 ],
 "Mask service": [
  null,
  "Göm tjänst"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Att gömma en tjänst hindrar alla tjänster som beror på den att starta. Det kan ha en större effekt än tänkt. Se till att du verkligen vill gömma denna tjänst."
 ],
 "Disallow running (mask)": [
  null,
  "Hindra körning (göm)"
 ],
 "Unpin unit": [
  null,
  "Avfäst enhet"
 ],
 "Pin unit": [
  null,
  "Fäst enhet"
 ],
 "Additional actions": [
  null,
  "Ytterligare åtgärder"
 ],
 "Note": [
  null,
  "Observera"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Denna enhet är inte gjord för att aktiveras explicit."
 ],
 "Forbidden from running": [
  null,
  "Kan ej köras"
 ],
 "Start service": [
  null,
  "Starta tjänst"
 ],
 "Active since ": [
  null,
  "Aktiv sedan "
 ],
 "Required by ": [
  null,
  "Krävs av "
 ],
 "Read-only": [
  null,
  "Skrivskyddad"
 ],
 "Requires administration access to edit": [
  null,
  "Kräver administrationsbehörighet för att redigera"
 ],
 "Automatically starts": [
  null,
  "Startar automatiskt"
 ],
 "Updating status...": [
  null,
  "Uppdaterar status..."
 ],
 "Stop and disable": [
  null,
  "Stoppa och avaktivera"
 ],
 "Start and enable": [
  null,
  "Starta och aktivera"
 ],
 "Failed to load unit": [
  null,
  "Misslyckades att ladda enhet"
 ],
 "View all services": [
  null,
  "Visa alla tjänster"
 ],
 "Triggers": [
  null,
  "Utlösare"
 ],
 "Triggered by": [
  null,
  "Utlöst av"
 ],
 "Requires": [
  null,
  "Begär"
 ],
 "Requisite": [
  null,
  "Behov"
 ],
 "Wants": [
  null,
  "Önskar"
 ],
 "Binds to": [
  null,
  "Binder till"
 ],
 "Part of": [
  null,
  "Del av"
 ],
 "Required by": [
  null,
  "Begärd av"
 ],
 "Requisite of": [
  null,
  "Behov av"
 ],
 "Wanted by": [
  null,
  "Önskat av"
 ],
 "Bound by": [
  null,
  "Bundet av"
 ],
 "Consists of": [
  null,
  "Består av"
 ],
 "Conflicts": [
  null,
  "Konflikter"
 ],
 "Conflicted by": [
  null,
  "Står i konflikt med"
 ],
 "Before": [
  null,
  "Före"
 ],
 "After": [
  null,
  "Efter"
 ],
 "On failure": [
  null,
  "Vid misslyckande"
 ],
 "Propagates reload to": [
  null,
  "Vidarebefordrar omladdning till"
 ],
 "Reload propagated from": [
  null,
  "Omläsning vidarebefordrad från"
 ],
 "Joins namespace of": [
  null,
  "Går med i namnrymden för"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Villkoret $0=$1 uppfylldes inte"
 ],
 "Deletion will remove the following files:": [
  null,
  "Radering kommer ta bort följande filer:"
 ],
 "Pinned unit": [
  null,
  "Fästa enheter"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Path": [
  null,
  "Sökväg"
 ],
 "Listen": [
  null,
  "Lyssna"
 ],
 "Container": [
  null,
  "Behållare"
 ],
 "View Podman container": [
  null,
  "Visa podman behållare"
 ],
 "Condition failed": [
  null,
  "Villkoret misslyckades"
 ],
 "Show more relationships": [
  null,
  "Visa mer relationer"
 ],
 "Show relationships": [
  null,
  "Visa relationer"
 ],
 "Confirm deletion of $0": [
  null,
  "Bekräfta raderingen av $0"
 ],
 "Timer deletion failed": [
  null,
  "Att radera en timer misslyckades"
 ],
 "Targets": [
  null,
  "Mål"
 ],
 "Sockets": [
  null,
  "Uttag"
 ],
 "Timers": [
  null,
  "Timrar"
 ],
 "Paths": [
  null,
  "Sökvägar"
 ],
 "Go to $0": [
  null,
  "Gå till $0"
 ],
 "Journal entry not found": [
  null,
  "Journalposten hittades inte"
 ],
 "Journal entry": [
  null,
  "Journalpost"
 ],
 "Entry at $0": [
  null,
  "Ingång vid $0"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "Loading unit failed": [
  null,
  "Läsa in enhet misslyckades"
 ],
 "Service logs": [
  null,
  "Tjänsteloggar"
 ],
 "No log entries": [
  null,
  "Inga loggposter"
 ],
 "Systemd units": [
  null,
  "Systemenheter"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Inga resultat matchar filterkriterierna. Rensa alla filter för att visa resultat."
 ],
 "Does not automatically start": [
  null,
  "Startar inte automatiskt"
 ],
 "Cannot be enabled": [
  null,
  "Kan inte slås på"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webbkonsolen körs i begränsad åtkomstläge."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "från $0 på $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "från $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "på $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domän"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Gå med i en domän"
 ]
});
