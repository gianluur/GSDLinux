cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "hi",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
