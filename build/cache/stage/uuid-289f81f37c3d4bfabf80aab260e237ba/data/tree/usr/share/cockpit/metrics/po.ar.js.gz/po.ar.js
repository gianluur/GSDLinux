cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Metrics and history": [
  null,
  "المقاييس والتاريخ"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Select": [
  null,
  "تحديد"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "Permission denied": [
  null,
  "الإذن مرفوض"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "You now have administrative access.": [
  null,
  "لديك الآن حق الوصول الإداري."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "الرجاء المصادقة للحصول على صلاحيات إدارية"
 ],
 "Switch to administrative access": [
  null,
  "التبديل إلى الوصول الإداري"
 ],
 "Authenticate": [
  null,
  "مصادقة"
 ],
 "Administrative access": [
  null,
  "صلاحيات المسؤول"
 ],
 "Problem becoming administrator": [
  null,
  "مشكلة في الحصول على صلاحيات المسؤول"
 ],
 "Method": [
  null,
  "الطريقة"
 ],
 "Limit access": [
  null,
  "تقييد الوصول"
 ],
 "Switch to limited access": [
  null,
  "التبديل إلى الوصول محدود الصلاحيات"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "يُقيّد وضع الوصول المقيد الصلاحيات الإدارية. ستكون بعض أجزاء لوحة التحكم عبر الويب محدودة الوظائف."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "سيتذكر متصفحك مستوى وصولك عبر الجلسات."
 ],
 "Limited access": [
  null,
  "وصول مقيَّد"
 ],
 "Turn on administrative access": [
  null,
  "فعّل الوصول الإداري"
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "أبلغت PackageKit عن رمز الخطأ $0"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "نوع عامل التصفية"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Shell script": [
  null,
  "سكريبت الصدفة"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Boot": [
  null,
  "الإقلاع"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Read more...": [
  null,
  "اقرأ المزيد..."
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "No log entries": [
  null,
  "لا إدخالات في السجل"
 ],
 "Service": [
  null,
  "خدمة"
 ],
 "Interface": [
  null,
  "الواجهة",
  "واجهة",
  "واجهتين",
  "واجهات",
  "واجهة",
  "واجهة"
 ],
 "Network": [
  null,
  "شبكة"
 ],
 "Device": [
  null,
  "جهاز"
 ],
 "Disks": [
  null,
  "الأقراص"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "تم استخدامه"
 ],
 "CPU usage": [
  null,
  "استخدام وحدة المعالجة المركزية (CPU)"
 ],
 "nice": [
  null,
  "رائع"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "sys": [
  null,
  "sys"
 ],
 "Load": [
  null,
  "حمل"
 ],
 "Memory usage": [
  null,
  "استخدام الذاكرة"
 ],
 "Swap out": [
  null,
  "استبدال"
 ],
 "$0 page": [
  null,
  "$0 لا صفحات",
  "$0 صفحة واحدة",
  "$0 صفحتان",
  "$0 صفحات",
  "$0 صفحة",
  "$0 صفحة"
 ],
 "Disk I/O": [
  null,
  "قرص I/O"
 ],
 "Network I/O": [
  null,
  "شبكة I/O"
 ],
 "pod": [
  null,
  "Pod"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman ليس مثبتاً"
 ],
 "$0 CPU": [
  null,
  "$0 وحدة معالجة مركزية",
  "$0 وحدة معالجة مركزية واحدة",
  "$0 وحدتي معالجة مركزية",
  "$0 وحدات معالجة مركزية",
  "$0 وحدة معالجة مركزية",
  "$0 وحدة معالجة مركزية"
 ],
 "$0 total": [
  null,
  "المجموع: $0"
 ],
 "$0 available": [
  null,
  "$0 متاح"
 ],
 "Core $0": [
  null,
  "نواة المعالج $0"
 ],
 "average: $0%": [
  null,
  "معدل: $0%"
 ],
 "max: $0%": [
  null,
  "الحد الأقصى: $0٪"
 ],
 "Current top CPU usage": [
  null,
  "أعلى استخدام لوحدة المعالجة المركزية (CPU) حالياً"
 ],
 "View all CPUs": [
  null,
  "عرض جميع أنوية وحدة المعالجة المركزية CPUs"
 ],
 "Read": [
  null,
  "قراءة"
 ],
 "Write": [
  null,
  "كتابة"
 ],
 "Disks usage": [
  null,
  "استعمال الأقراص"
 ],
 "View all disks": [
  null,
  "عرض جميع الأقراص"
 ],
 "View per-disk throughput": [
  null,
  "عرض الإنتاجية لكل قرص"
 ],
 "In": [
  null,
  "في"
 ],
 "Out": [
  null,
  "خارج"
 ],
 "1 min": [
  null,
  "1 د"
 ],
 "5 min": [
  null,
  "٥ د"
 ],
 "15 min": [
  null,
  "15 د"
 ],
 "Top 5 CPU services": [
  null,
  "أعلى ٥ خدمات لوحدة المعالجة المركزية (CPU)"
 ],
 "RAM": [
  null,
  "ذاكرة الوصول العشوائي RAM"
 ],
 "Top 5 memory services": [
  null,
  "أعلى ٥ خدمات استهلاكاً للذاكرة"
 ],
 "$0 free": [
  null,
  "$0 متوفر"
 ],
 "Top 5 disk usage services": [
  null,
  "أعلى ٥ خدمات استهلاكاً للقرص"
 ],
 "Network usage": [
  null,
  "استخدام الشبكة"
 ],
 "View detailed logs": [
  null,
  "عرض السجلات التفصيلية"
 ],
 "$0 spike": [
  null,
  "لا ارتفاع مفاجئ",
  "ارتفاع مفاجئ واحد",
  "ارتفاعان مفاجئان",
  "$0 ارتفاعات مفاجئة",
  "$0 ارتفاعاُ مفاجئاً",
  "$0 ارتفاعاُ مفاجئاً"
 ],
 "No events": [
  null,
  "لا أحداث"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "افتح خدمة pmproxy في الجدار النلري لمشاركة المقاييس."
 ],
 "Metrics settings": [
  null,
  "إعدادات المقاييس"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "أداة Performance Co-Pilot تقوم بجمع وتحليل مؤشرات الأداء من نظامك."
 ],
 "Failed to configure PCP": [
  null,
  "فشل في تكوينPCP"
 ],
 "Collect metrics": [
  null,
  "جمع المقاييس"
 ],
 "Export to network": [
  null,
  "تصدير إلى الشبكة"
 ],
 "PCP is missing for metrics history": [
  null,
  "PCP مفقود بالنسبة لسجل المقاييس"
 ],
 "Install PCP support": [
  null,
  "تثبيت دعم PCP"
 ],
 "pmlogger.service is not running": [
  null,
  "خدمة pmlogger.service ليست قيد العمل"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service فشلت"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "خدمة pmlogger غير قادرة على جمع البيانات"
 ],
 "Troubleshoot": [
  null,
  "استكشاف الأخطاء وإصلاحها"
 ],
 "Metrics history could not be loaded": [
  null,
  "تعذر تحميل سجل المقاييس"
 ],
 "Error has occurred": [
  null,
  "حصل خطأ"
 ],
 "No data available between $0 and $1": [
  null,
  "لا بيانات متاحة بين $0 و$1"
 ],
 "No data available": [
  null,
  "لا بيانات متاحة"
 ],
 "Today": [
  null,
  "اليوم"
 ],
 "Jump to": [
  null,
  "الانتقال إلى"
 ],
 "Graph visibility options menu": [
  null,
  "قائمة خيارات عرض الرسم البياني"
 ],
 "Graph visibility": [
  null,
  "عرض الرسم البياني"
 ],
 "CPU usage/load": [
  null,
  "استخدام/حمل وحدة المعالجة المركزية (CPU)"
 ],
 "Memory usage/swap": [
  null,
  "استخدام الذاكرة/swap"
 ],
 "Load earlier data": [
  null,
  "تحميل البيانات السابقة"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ]
});
