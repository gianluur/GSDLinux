cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Serviços"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "network": [
  null,
  "rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interface"
 ],
 "bridge": [
  null,
  "ponte"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "agregação"
 ],
 "team": [
  null,
  "equipe"
 ],
 "port": [
  null,
  "porta"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "zona"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "Gerenciando vínculos de rede"
 ],
 "Managing networking teams": [
  null,
  "Gerenciando uniões de rede"
 ],
 "Managing networking bridges": [
  null,
  "Gerenciando pontes de rede"
 ],
 "Managing VLANs": [
  null,
  "Gerenciando VLANs"
 ],
 "Managing firewall": [
  null,
  "Gerenciando firewall"
 ]
});
