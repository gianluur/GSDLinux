cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "密钥发生变化通常是因为重新安装了操作系统。但是，意外的变更也可能意味着有第三方正试图拦截您的连接。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要确保您的连接没有被恶意第三方截取，请验证主机密钥指纹："
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "结果指纹可以通过公共方法（包括电子邮件）共享。"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Server": [
  null,
  "服务器"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Firewall": [
  null,
  "防火墙"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copied": [
  null,
  "复制的"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Public key": [
  null,
  "公钥"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Select": [
  null,
  "选择"
 ],
 "Unexpected error": [
  null,
  "意外的错误"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安装"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "主机 $0 上找不到版本兼容的 Cockpit。"
 ],
 "Connect": [
  null,
  "连接"
 ],
 "Add": [
  null,
  "添加"
 ],
 "$0 key changed": [
  null,
  "已更改 $0 个密钥"
 ],
 "Trust and add host": [
  null,
  "信任并添加主机"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要验证指纹，在 $0 上运行以下内容（在实际的物理机器上本地进行，或通过一个可信任的网络进行）："
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指纹匹配，请点击“信任并添加主机”。否则，请不要连接并联系您的管理员。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成的指纹可以通过公共方法（包括电子邮件）共享。如果您需要其他人为您进行验证，他们可以使用任何方法发送结果。"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次连接到 $0。"
 ],
 "Verify fingerprint": [
  null,
  "验证指纹"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "通过一个可信网络运行这个命令，或在远程机器上运行这个命令："
 ],
 "The fingerprint should match:": [
  null,
  "指纹应匹配："
 ],
 "The password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key passwords do not match": [
  null,
  "密钥密码不匹配"
 ],
 "Log in to $0": [
  null,
  "登录到 $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "无法登录到 $0 。主机不接受密码登录，或您的任何 SSH 密钥。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受密码保护的，主机不允许使用密码登录。请在 $1 提供密钥的密码。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受保护的。您可以用您的登录密码或通过在 $1 提供密钥的密码来登录。"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "创建一个新的 SSH 密钥，并对其进行授权"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "将在 $2 上为 $1 创建位于 $0 的新 SSH 密钥，并将其添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Key password": [
  null,
  "密钥密码"
 ],
 "Confirm key password": [
  null,
  "确认密钥密码"
 ],
 "Authorize SSH key": [
  null,
  "授权 SSH 密钥"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 密钥 $0 将被添加到 $5 上 $4 的 $3 文件中。"
 ],
 "Authentication": [
  null,
  "认证"
 ],
 "SSH key": [
  null,
  "SSH 密钥"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 密钥 $0 将会在剩余的会话中可用，也可以在登录到其他主机时可用。"
 ],
 "Disconnected": [
  null,
  "已断开连接"
 ],
 "Permission denied": [
  null,
  "权限被拒绝"
 ],
 "Clear input value": [
  null,
  "清除输入值"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "Create $0": [
  null,
  "创建 $0"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "You now have administrative access.": [
  null,
  "您已经获取了管理员权限。"
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "没有可用于获取管理权限的方法 (sudo -A, pkexec)。"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "请进行身份验证以获取管理员权限"
 ],
 "Switch to administrative access": [
  null,
  "切换到管理员权限"
 ],
 "Authenticate": [
  null,
  "认证"
 ],
 "Administrative access": [
  null,
  "管理员权限"
 ],
 "Problem becoming administrator": [
  null,
  "成为管理员时出现问题"
 ],
 "Method": [
  null,
  "模式"
 ],
 "Limit access": [
  null,
  "限制访问"
 ],
 "Switch to limited access": [
  null,
  "切换到限制权限"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限制访问模式会限制管理员权限。Web 控制台部分功能将会减少。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的浏览器将会在不同会话之间记住您的访问级别。"
 ],
 "Limited access": [
  null,
  "被限制的访问"
 ],
 "Turn on administrative access": [
  null,
  "开启管理员权限"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "less than a minute ago": [
  null,
  "少于一分钟前"
 ],
 "in less than a minute": [
  null,
  "少于一分钟"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Excellent password": [
  null,
  "密码强度优秀"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Unknown host: $0": [
  null,
  "未知主机：$0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "无法使用 SSH 密钥身份验证登录到 $0。请提供密码。"
 ],
 "SSH key login": [
  null,
  "SSH 密钥登录"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit 已报告错误码 $0"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "Row expansion": [
  null,
  "行扩展"
 ],
 "Row select": [
  null,
  "行选择"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Error during initialization": [
  null,
  "初始化时出错"
 ],
 "Failed": [
  null,
  "失败"
 ],
 "Home": [
  null,
  ""
 ],
 "Not a directory": [
  null,
  "不是目录"
 ],
 "Type to filter": [
  null,
  "输入内容来过滤"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "文件系统"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "Folder": [
  null,
  "文件夹"
 ],
 "File": [
  null,
  "文件"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "当前登录的用户无权查看系统更改"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Select an option": [
  null,
  "选择一个选项"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 exited with code $1": [
  null,
  "$0 退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "$0 失败"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Server has closed the connection.": [
  null,
  "服务器已关闭了连接。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Priority": [
  null,
  "优先级"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Save": [
  null,
  "保存"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "None": [
  null,
  "无"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Generated": [
  null,
  "生成的"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Start service": [
  null,
  "启动服务"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Delete $0": [
  null,
  "删除 $0"
 ],
 "Group": [
  null,
  "组"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Not available": [
  null,
  "不可用"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Permanent": [
  null,
  "永久的"
 ],
 "Preserve": [
  null,
  "保留"
 ],
 "Random": [
  null,
  "随机"
 ],
 "Stable": [
  null,
  "稳定的"
 ],
 "Use $0": [
  null,
  "使用 $0"
 ],
 "Failed to save settings": [
  null,
  "保存设置失败"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "创建该 $0 将会中断与服务器的连接，并且将会导致管理界面不可用。"
 ],
 "Create it": [
  null,
  "创建它"
 ],
 "Invalid prefix $0": [
  null,
  "无效的前缀 $0"
 ],
 "Invalid metric $0": [
  null,
  "无效的度量 $0"
 ],
 "Invalid address $0": [
  null,
  "无效的地址 $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "无效的前缀或掩码 $0"
 ],
 "Testing connection": [
  null,
  "测试连接"
 ],
 "Restoring connection": [
  null,
  "恢复连接"
 ],
 "Troubleshoot…": [
  null,
  "检修…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager 未运行"
 ],
 "NetworkManager is not installed": [
  null,
  "未安装 NetworkManager"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "网络设备和图形需要 NetworkManager"
 ],
 "Enable service": [
  null,
  "启用服务"
 ],
 "Network interface '$0' not found": [
  null,
  "网络接口 '$0' 未找到"
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "您无权修改防火墙。"
 ],
 "Not authorized to disable the firewall": [
  null,
  "无权禁用防火墙"
 ],
 "Not authorized to enable the firewall": [
  null,
  "无权启用防火墙"
 ],
 "Disable the firewall": [
  null,
  "禁用防火墙"
 ],
 "Enable the firewall": [
  null,
  "启用防火墙"
 ],
 "Edit service $0": [
  null,
  "编辑服务 $0"
 ],
 "Remove service $0": [
  null,
  "删除服务 $0"
 ],
 "Additional port": [
  null,
  "额外端口"
 ],
 "Remove zone $0": [
  null,
  "移除区 $0"
 ],
 "Add services to zone $0": [
  null,
  "添加系统服务到安全区域 $0"
 ],
 "Add services": [
  null,
  "添加系统服务"
 ],
 "Service": [
  null,
  "服务"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 安全区域"
 ],
 "Interface": [
  null,
  "接口"
 ],
 "Allowed addresses": [
  null,
  "白名单地址"
 ],
 "Entire subnet": [
  null,
  "整个子网"
 ],
 "There are no active services in this zone": [
  null,
  "该区中没有任何活跃的服务"
 ],
 "Filter services": [
  null,
  "过滤服务"
 ],
 "Failed to edit service": [
  null,
  "编辑服务失败"
 ],
 "Failed to add port": [
  null,
  "添加端口失败"
 ],
 "Failed to add service": [
  null,
  "添加服务失败"
 ],
 "Unknown service name": [
  null,
  "未知的服务名"
 ],
 "Invalid port number": [
  null,
  "无效的端口号"
 ],
 "Invalid range": [
  null,
  "无效范围"
 ],
 "Range must be strictly ordered": [
  null,
  "范围必须排序"
 ],
 "Edit service": [
  null,
  "编辑服务"
 ],
 "Edit custom service in $0 zone": [
  null,
  "编辑 $0 区中的自定义服务"
 ],
 "Add ports": [
  null,
  "添加端口"
 ],
 "Add ports to $0 zone": [
  null,
  "添加端口到安全区域 $0"
 ],
 "Add services to $0 zone": [
  null,
  "添加系统服务到安全区域 $0"
 ],
 "Custom ports": [
  null,
  "自定义端口"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "例如: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "可以接受以逗号分割的端口、范围和服务"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "例如: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "如果为空，则将根据关联的端口服务和端口号生成 ID"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "添加自定义端口需要重启 firewalld，当前的运行时配置将会丢失！"
 ],
 "Failed to add zone": [
  null,
  "添加区域失败"
 ],
 "Add zone": [
  null,
  "添加安全区域"
 ],
 "Trust level": [
  null,
  "信任级别"
 ],
 "Sorted from least to most trusted": [
  null,
  "按最不被信任到最被信任的顺序排序"
 ],
 "Custom zones": [
  null,
  "自定义区域"
 ],
 "No description available": [
  null,
  "没有可用描述"
 ],
 "Included services": [
  null,
  "包括的服务"
 ],
 "The cockpit service is automatically included": [
  null,
  "cockpit 服务被自动包括"
 ],
 "Interfaces": [
  null,
  "接口"
 ],
 "Range": [
  null,
  "范围"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "带有路由前缀的IP地址。用逗号分隔多个值。例如：192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "确认移除 $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "这个区包括 cockpit 服务。请确认这个区不会应用到您当前的 web 控制台连接。"
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "删除区将删除其中的所有服务。"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "删除 cockpit 服务可能会导致 web 控制台无法被访问。请确认这个区不会应用到当前的 web 控制台连接。"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "从 $1 区域中删除 $0 服务"
 ],
 "Firewall is not available": [
  null,
  "防火墙不可用"
 ],
 "Please install the $0 package": [
  null,
  "请安装 $0 软件包"
 ],
 "Add a new zone": [
  null,
  "添加安全区域"
 ],
 "Add new zone": [
  null,
  "添加安全区域"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "传入请求被默认阻断。传出请求不会被阻断。"
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID 不能为空"
 ],
 "Password can not be empty": [
  null,
  "密码不能为空"
 ],
 "Failed to connect": [
  null,
  "无法连接"
 ],
 "Check your password.": [
  null,
  "请检查您的密码。"
 ],
 "Connect to hidden network": [
  null,
  "连接到隐藏网络"
 ],
 "Connect to $0": [
  null,
  "连接到 $0"
 ],
 "Network name": [
  null,
  "网络名称"
 ],
 "Security": [
  null,
  "安全性"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 个人版"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "删除 $0 将会中断与服务器的连接，并且将会导致管理界面不可用。"
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "打开 $0 将中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Switch on $0": [
  null,
  "打开 $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "关掉 $0 将中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Switch off $0": [
  null,
  "关掉 $0"
 ],
 "Bond": [
  null,
  "绑定"
 ],
 "Team": [
  null,
  "组合"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "网桥"
 ],
 "Unknown \"$0\"": [
  null,
  "未知 \"$0\""
 ],
 "Carrier": [
  null,
  "载波"
 ],
 "Yes": [
  null,
  "是"
 ],
 "No": [
  null,
  "否"
 ],
 "Inactive": [
  null,
  "未激活"
 ],
 "Unknown configuration": [
  null,
  "未知配置"
 ],
 "Additional address $val": [
  null,
  "其他地址 $val"
 ],
 "Address $val": [
  null,
  "地址： $val"
 ],
 "Gateway $gateway": [
  null,
  "网关 $gateway"
 ],
 "Additional DNS $val": [
  null,
  "备用 DNS 服务器：$val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "备用 DNS 搜索域 $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS 搜索域 $val"
 ],
 "General": [
  null,
  "通用"
 ],
 "Connect automatically": [
  null,
  "自动连接"
 ],
 "Automatic": [
  null,
  "自动"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP 监控"
 ],
 "Broken configuration": [
  null,
  "错误的配置"
 ],
 "Team port": [
  null,
  "组合端口"
 ],
 "Spanning tree protocol": [
  null,
  "生成树协议"
 ],
 "Priority $priority": [
  null,
  "优先级 $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "转发延迟 $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Hello 时间 $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "最大消息有效期 $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "路径开销 $path_cost"
 ],
 "Hairpin mode": [
  null,
  "发夹模式"
 ],
 "Bridge port": [
  null,
  "网桥端口"
 ],
 "Parent $parent": [
  null,
  "父 $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "网络密码未保存。请先忘记此网络，然后重新连接。"
 ],
 "Failed to connect to $0": [
  null,
  "连接到 $0 失败"
 ],
 "secured": [
  null,
  "已加密"
 ],
 "open": [
  null,
  "开放"
 ],
 "Last connected: $0": [
  null,
  "最后连接于： $0"
 ],
 "Signal strength": [
  null,
  "信号强度"
 ],
 "Not permitted to disconnect network": [
  null,
  "不允许断开网络连接"
 ],
 "Disconnect": [
  null,
  "断开"
 ],
 "Not permitted to connect to network": [
  null,
  "不允许连接到网络"
 ],
 "Forget": [
  null,
  "忘记"
 ],
 "$0 hidden network": [
  null,
  "$0 个隐藏网络"
 ],
 "Filter": [
  null,
  "过滤"
 ],
 "Refresh": [
  null,
  "刷新"
 ],
 "Available networks": [
  null,
  "可用网络"
 ],
 "Network": [
  null,
  "网络"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Signal": [
  null,
  "信号"
 ],
 "Rate": [
  null,
  "速率"
 ],
 "Not permitted to configure network devices": [
  null,
  "不允许配置网络设备"
 ],
 "Enable or disable the device": [
  null,
  "启用或禁用设备"
 ],
 "This device cannot be managed here.": [
  null,
  "该设备不能在这里被管理。"
 ],
 "Connection will be lost": [
  null,
  "连接将丢失"
 ],
 "Keep connection": [
  null,
  "保持连接"
 ],
 "Invalid IP address: $0": [
  null,
  "无效的IP地址: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "无效的目标地址: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "无效的网关地址: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "无效的DNS地址: $0"
 ],
 "Preparing": [
  null,
  "准备中"
 ],
 "Configuring": [
  null,
  "配置中"
 ],
 "Authenticating": [
  null,
  "正在认证"
 ],
 "Configuring IP": [
  null,
  "正在配置 IP"
 ],
 "Checking IP": [
  null,
  "正在检查 IP"
 ],
 "Waiting": [
  null,
  "等待中"
 ],
 "Active": [
  null,
  "已启用"
 ],
 "Deactivating": [
  null,
  "取消激活中"
 ],
 "Adhoc": [
  null,
  "自组网"
 ],
 "Infra": [
  null,
  "基础架构"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "网状"
 ],
 "No carrier": [
  null,
  "无载波"
 ],
 "Part of $0": [
  null,
  "$0 的部分"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "修改设置将会中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Change the settings": [
  null,
  "修改设置"
 ],
 "Add bridge": [
  null,
  "添加网桥"
 ],
 "Edit bridge settings": [
  null,
  "编辑网桥设置"
 ],
 "Ports": [
  null,
  "端口"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "生成树协议 (STP)"
 ],
 "STP priority": [
  null,
  "STP 优先级"
 ],
 "STP forward delay": [
  null,
  "STP 转发延迟"
 ],
 "STP hello time": [
  null,
  "STP Hello 时间"
 ],
 "STP maximum message age": [
  null,
  "STP 最大消息有效期"
 ],
 "Round robin": [
  null,
  "轮循"
 ],
 "Active backup": [
  null,
  "已启用的备用接口"
 ],
 "Load balancing": [
  null,
  "负载均衡"
 ],
 "Broadcast": [
  null,
  "广播"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "被动"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "添加组合"
 ],
 "Edit team settings": [
  null,
  "编辑组合设置"
 ],
 "Runner": [
  null,
  "运行者"
 ],
 "Balancer": [
  null,
  "平衡器"
 ],
 "Primary": [
  null,
  "主"
 ],
 "Link watch": [
  null,
  "侦测连接状态"
 ],
 "Link up delay": [
  null,
  "链路启用延时"
 ],
 "Link down delay": [
  null,
  "链路断开延时"
 ],
 "Ping interval": [
  null,
  "Ping 周期"
 ],
 "Ping target": [
  null,
  "Ping 目标"
 ],
 "Automatic (DHCP only)": [
  null,
  "自动 (仅 DHCP)"
 ],
 "Link local": [
  null,
  "本地链路"
 ],
 "Manual": [
  null,
  "手动"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Prefix length or netmask": [
  null,
  "前缀长度或网络掩码"
 ],
 "Prefix length": [
  null,
  "前缀长度"
 ],
 "IPv4 settings": [
  null,
  "IPv4 设置"
 ],
 "IPv6 settings": [
  null,
  "IPv6 设置"
 ],
 "Addresses": [
  null,
  "地址"
 ],
 "Select method": [
  null,
  "选择方法"
 ],
 "Add address": [
  null,
  "添加地址"
 ],
 "Address": [
  null,
  "地址"
 ],
 "Remove item": [
  null,
  "删除项目"
 ],
 "Gateway": [
  null,
  "网关"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "添加DNS服务器"
 ],
 "DNS search domains": [
  null,
  "DNS 搜索域"
 ],
 "Add search domain": [
  null,
  "添加搜索域"
 ],
 "Search domain": [
  null,
  "搜索域"
 ],
 "Routes": [
  null,
  "路由"
 ],
 "Add route": [
  null,
  "添加路由"
 ],
 "Metric": [
  null,
  "指标"
 ],
 "Enter a valid MAC address": [
  null,
  "输入有效的 MAC 地址"
 ],
 "Ethernet MAC": [
  null,
  "以太网 MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 网络"
 ],
 "Add VPN": [
  null,
  "添加 VPN"
 ],
 "Add bond": [
  null,
  "添加绑定"
 ],
 "Add VLAN": [
  null,
  "添加 VLAN"
 ],
 "Edit rules and zones": [
  null,
  "编辑规则和区域"
 ],
 "$0 active zone": [
  null,
  "$0 个已启用的安全区域"
 ],
 "Managed interfaces": [
  null,
  "管理的接口"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "Sending": [
  null,
  "发送"
 ],
 "Receiving": [
  null,
  "接收"
 ],
 "Unmanaged interfaces": [
  null,
  "未管理的接口"
 ],
 "Network logs": [
  null,
  "网络日志"
 ],
 "Addresses are not formatted correctly": [
  null,
  "地址格式不正确"
 ],
 "Invalid IP address '$0'": [
  null,
  "无效的IP地址: '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "未安装 WireGuard-tools 软件包"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "对等 #$0 有无效的端点。它需要以 host:port 的形式指定，如 1.2.3.4:51820 , [2001:db8::1]:51820 或 example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "对等 #$0 有无效的端点端口。端口必须是一个数字。"
 ],
 "Listen port must be a number": [
  null,
  "侦听端口必须是一个数字"
 ],
 "Add WireGuard VPN": [
  null,
  "添加 WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "编辑 WireGuard VPN"
 ],
 "Private key": [
  null,
  "私钥"
 ],
 "Paste existing key": [
  null,
  "粘贴现有密钥"
 ],
 "Regenerate": [
  null,
  "重新生成"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "在输入有效私钥时将生成公钥"
 ],
 "Listen port": [
  null,
  "侦听端口"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "将设置为\"Automatic\""
 ],
 "IP addresses": [
  null,
  "IP 地址"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "可以使用逗号或空格作为分隔符来指定多个地址。"
 ],
 "Peers": [
  null,
  "对等"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "对等（peer）是与这个系统连接的其他机器。来自其他机器中的公钥将相互共享。"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "作为 \"服务器\" 的端点需要指定为 host:port，或者也可以留空。"
 ],
 "Add peer": [
  null,
  "添加对等端"
 ],
 "Endpoint": [
  null,
  "端点"
 ],
 "Allowed IPs": [
  null,
  "允许的 IP 地址"
 ],
 "No peers added.": [
  null,
  "没有添加对等。"
 ],
 "Edit VLAN settings": [
  null,
  "编辑 VLAN 设置"
 ],
 "Parent": [
  null,
  "父"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "传输"
 ],
 "MTU must be a positive number": [
  null,
  "MTU 必须是正整数"
 ],
 "Ethernet MTU": [
  null,
  "以太网 MTU"
 ],
 "Set to": [
  null,
  "设置为"
 ],
 "Team port settings": [
  null,
  "组合端口设置"
 ],
 "Sticky": [
  null,
  "粘性的"
 ],
 "LACP key": [
  null,
  "LACP 密钥"
 ],
 "Bridge port settings": [
  null,
  "网桥端口设置"
 ],
 "Path cost": [
  null,
  "路径开销"
 ],
 "Hair pin mode": [
  null,
  "发夹模式"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "自适应性传输负载均衡"
 ],
 "Adaptive load balancing": [
  null,
  "自适应性负载均衡"
 ],
 "MII (recommended)": [
  null,
  "MII (推荐)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "编辑绑定设置"
 ],
 "Network bond": [
  null,
  "网络绑定"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "网络绑定会将多个网络接口组合成一个逻辑接口，以提高吞吐量或增强冗余能力。"
 ],
 "Link monitoring": [
  null,
  "链路监控"
 ],
 "Monitoring interval": [
  null,
  "监控间隔"
 ],
 "Monitoring targets": [
  null,
  "监控目标"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "删除 $0 将断开与服务器的连接，并将导致管理界面不可用。"
 ],
 "Remove $0": [
  null,
  "移除 $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "添加 $0 将中断您与服务器的连接，届时管理界面将无法使用。"
 ],
 "Add member": [
  null,
  "添加成员"
 ],
 "Interface members": [
  null,
  "接口成员"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一款服务器管理工具，可让您通过 Web 浏览器轻松管理 Linux 服务器。在终端和 Web 界面之间切换毫无障碍。通过 Cockpit 启动的服务也可以在终端中停止。同样，如果终端中出现错误，也可以在 Cockpit 的日志界面中看到。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常适合新的系统管理员使用，让他们能够轻松完成存储管理、查看日志以及启动和停止服务等简单任务。您可以同时监控和管理多台服务器。只需单击一下即可添加服务器，让这些主机协同工作。"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、组合、VLAN 和防火墙等。NetworkManager 与 Ubuntu 默认的 systemd-networkd 以及 Debian 的 ifupdown 脚本不兼容。"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具用于配置 SELinux 策略，并可帮助理解和解决策略违规问题。"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具用于将系统配置为写入内核崩溃转储。它支持“local”（磁盘）、“ssh” 和“nfs” 转储目标。"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ]
});
