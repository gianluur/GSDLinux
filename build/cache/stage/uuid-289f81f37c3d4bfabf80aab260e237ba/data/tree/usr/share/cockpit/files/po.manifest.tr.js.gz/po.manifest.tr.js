cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Dosya gezgini"
 ],
 "files": [
  null,
  "dosyalar"
 ],
 "explorer": [
  null,
  "gezgin"
 ],
 "filesystem": [
  null,
  "dosya sistemi"
 ]
});
