cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Accounts": [
  null,
  "Käyttäjätilit"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "salasana"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "käyttäjänimi"
 ],
 "login": [
  null,
  "sisäänkirjautuminen"
 ],
 "access": [
  null,
  "pääsy"
 ],
 "roles": [
  null,
  "roolit"
 ],
 "keys": [
  null,
  "avaimet"
 ],
 "Managing user accounts": [
  null,
  "Käyttäjätilien hallinta"
 ]
});
