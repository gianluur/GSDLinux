cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "服務"
 ],
 "Terminal": [
  null,
  "終端機"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "Logs": [
  null,
  "系統日誌"
 ],
 "time": [
  null,
  "時間"
 ],
 "date": [
  null,
  "日期"
 ],
 "restart": [
  null,
  "重新啟動"
 ],
 "shut": [
  null,
  "關"
 ],
 "domain": [
  null,
  "網域"
 ],
 "machine": [
  null,
  "機器"
 ],
 "operating system": [
  null,
  "作業系統"
 ],
 "os": [
  null,
  "作業系統"
 ],
 "asset tag": [
  null,
  "標籤"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "電源"
 ],
 "version": [
  null,
  "版本"
 ],
 "host": [
  null,
  "主機"
 ],
 "hardware": [
  null,
  "硬體"
 ],
 "mitigation": [
  null,
  "緩解"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "記憶體"
 ],
 "cpu": [
  null,
  "處理器"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "序號"
 ],
 "graphs": [
  null,
  "圖表"
 ],
 "metrics": [
  null,
  "指標度量"
 ],
 "history": [
  null,
  "歷史記錄"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "磁碟"
 ],
 "network": [
  null,
  "網路"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "效能"
 ],
 "Configuring system settings": [
  null,
  "調整系統設定"
 ],
 "service": [
  null,
  "服務"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "目標"
 ],
 "socket": [
  null,
  "socket"
 ],
 "timer": [
  null,
  "計時器"
 ],
 "path": [
  null,
  "路徑"
 ],
 "unit": [
  null,
  "單元"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "開機"
 ],
 "mask": [
  null,
  "遮罩"
 ],
 "unmask": [
  null,
  "解除遮罩"
 ],
 "enable": [
  null,
  "啟用"
 ],
 "disable": [
  null,
  "已停用"
 ],
 "Managing services": [
  null,
  "管理服務"
 ],
 "journal": [
  null,
  "日誌"
 ],
 "warning": [
  null,
  "警告"
 ],
 "error": [
  null,
  "錯誤"
 ],
 "debug": [
  null,
  "除錯"
 ],
 "crash": [
  null,
  "當機"
 ],
 "coredump": [
  null,
  "核心傾印"
 ],
 "Reviewing logs": [
  null,
  "正在檢視紀錄檔"
 ],
 "console": [
  null,
  "主控臺"
 ],
 "command": [
  null,
  "指令"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
