cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "User name": [
  null,
  "사용자 이름"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Local accounts": [
  null,
  "로컬 계정"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Fingerprint": [
  null,
  "지문"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Copied": [
  null,
  "복사됨"
 ],
 "New password": [
  null,
  "신규 비밀번호"
 ],
 "Confirm password": [
  null,
  "비밀번호 확인"
 ],
 "Add key": [
  null,
  "키 추가"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Log out": [
  null,
  "로그아웃"
 ],
 "Select": [
  null,
  "선택"
 ],
 "Unexpected error": [
  null,
  "예상치 못한 오류"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit이 설치되어 있지 않습니다"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "호환 가능한 Cockpit 버전이 $0 에서 설치되지 않았습니다."
 ],
 "Add": [
  null,
  "추가"
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "Trust and add host": [
  null,
  "호스트 신뢰 및 추가"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0 에서 다음을 실행합니다:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "만약 지문이 일치하면, '키 ' 호스트 신뢰 및 추가'를 눌러주세요. 그렇지 않다면, 연결하지 않고 관리자에게 문의하세요."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "결과 지문은 전자우편을 포함하는 공개 방식을 통해 공유되어도 해도 좋습니다. 만약 누군가 당신을 위해 인증하도록 요청하는 경우, 어떤 방식을 사용하든 결과를 전송 할 수 있습니다."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0 에 연결됩니다."
 ],
 "Verify fingerprint": [
  null,
  "지문 검증"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "신뢰하는 네트워크 또는 원격 장비에서 물리적으로 이와 같은 명령을 실행합니다:"
 ],
 "The fingerprint should match:": [
  null,
  "지문 표시가 일치해야 합니다:"
 ],
 "The password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "The key password can not be empty": [
  null,
  "키 비밀번호를 비워둘 수 없습니다"
 ],
 "The key passwords do not match": [
  null,
  "키 비밀번호가 일치하지 않습니다"
 ],
 "Log in to $0": [
  null,
  "$0 로 로그인"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 에 로그인 할 수 없습니다. 호스트는 비밀번호 로그인 또는 자신의 SSH 키를 허용하지 않습니다."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위한 SSH 키가 비밀번호에 의해 보호되고 있으며, 그리고 호스트는 비밀번호로 로그인을 허용 하지 않습니다. $1 에서 키의 비밀번호를 제공하세요."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위해 SSH 키가 보호되고 있습니다. 당신은 $1 에서 자신의 로그인 비밀번호에 의하거나 키의 비밀번호 제공을 통해 로그인 할 수 있습니다.."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "신규 SSH 키를 생성하고 승인합니다"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 에서 신규 SSH 키는 $1 에서($2 에 대해) 생성되고 $3 파일($4 의($5 에 대한))에 추가됩니다."
 ],
 "Key password": [
  null,
  "키 비밀번호"
 ],
 "Confirm key password": [
  null,
  "키 비밀빈호 확인"
 ],
 "Authorize SSH key": [
  null,
  "SSH 키 승인"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$1 의 SSH 키 $0 ($2 에서)는 $4 의 $3 ($5 에서)파일로 추가됩니다."
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "SSH key": [
  null,
  "SSH 키"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 키 $0 는 세션의 나머지 부분에서 사용 할 수 있고 다른 호스트에 로그인 할 때에도 사용 할 수 있습니다."
 ],
 "Permission denied": [
  null,
  "권한이 거부되었습니다"
 ],
 "Clear input value": [
  null,
  "입력 값 초기화"
 ],
 "Invalid date format and invalid time format": [
  null,
  "잘못된 날짜 형식 및 잘못된 시간 형식"
 ],
 "Invalid time format": [
  null,
  "잘못된 시간 형식"
 ],
 "Invalid date format": [
  null,
  "잘못된 날짜 형식"
 ],
 "Cannot schedule event in the past": [
  null,
  "이전 이벤트를 예약할 수 없습니다"
 ],
 "No delay": [
  null,
  "지연 없음"
 ],
 "1 minute": [
  null,
  "1 분"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "20 minutes": [
  null,
  "20분"
 ],
 "40 minutes": [
  null,
  "40 분"
 ],
 "60 minutes": [
  null,
  "60 분"
 ],
 "Specific time": [
  null,
  "특정 시간"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Message to logged in users": [
  null,
  "로그인한 사용자에게 보내는 메세지"
 ],
 "Delay": [
  null,
  "지연"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Synchronized": [
  null,
  "동기화됩니다"
 ],
 "Synchronized with $0": [
  null,
  "$0 와 동기화됩니다"
 ],
 "Synchronizing": [
  null,
  "동기화 중"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 와 동기화를 시도 중입니다"
 ],
 "Not synchronized": [
  null,
  "동기화 되어 있지 않습니다"
 ],
 "Log messages": [
  null,
  "로그 메세지"
 ],
 "NTP server": [
  null,
  "NTP 서버"
 ],
 "Manually": [
  null,
  "수동"
 ],
 "Automatically using NTP": [
  null,
  "자동으로 NTP 사용"
 ],
 "Automatically using additional NTP servers": [
  null,
  "추가 NTP 서버를 자동으로 사용"
 ],
 "Automatically using specific NTP servers": [
  null,
  "특정 NTP 서버를 자동으로 사용"
 ],
 "Time zone": [
  null,
  "시간대"
 ],
 "Set time": [
  null,
  "시간 설정"
 ],
 "Invalid timezone": [
  null,
  "잘못된 시간대"
 ],
 "Need at least one NTP server": [
  null,
  "최소 하나의 NTP 서버가 필요합니다"
 ],
 "Change system time": [
  null,
  "시스템 시간 변경"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "Create $0": [
  null,
  "$0 생성"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "You now have administrative access.": [
  null,
  "이제 관리자 접근 권한이 있습니다."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "관리자 접근을 획득 할 수 있는 방법이 없습니다 (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "관리 접근 권한을 얻으려면 인증하세요"
 ],
 "Switch to administrative access": [
  null,
  "관리자 접근으로 전환"
 ],
 "Authenticate": [
  null,
  "인증"
 ],
 "Administrative access": [
  null,
  "관리 접근"
 ],
 "Problem becoming administrator": [
  null,
  "관리자에게서 발생한 문제"
 ],
 "Method": [
  null,
  "방식"
 ],
 "Limit access": [
  null,
  "접근 제한"
 ],
 "Switch to limited access": [
  null,
  "제한된 접근으로 전환"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "제한된 접근 방식은 관리 권한을 제한합니다. 웹 콘솔의 일부 부분은 기능이 축소됩니다."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "당신의 검색기는 세션을 통해 자신의 접근 수준을 기억합니다."
 ],
 "Limited access": [
  null,
  "제한된 접근"
 ],
 "Turn on administrative access": [
  null,
  "관리자 접근 켜기"
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Zone": [
  null,
  "영역"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "less than a minute ago": [
  null,
  "1분도 채 지나지 않아"
 ],
 "in less than a minute": [
  null,
  "1분도 안되어"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Strong password": [
  null,
  "강력한 비밀번호"
 ],
 "Acceptable password": [
  null,
  "허용되는 비밀번호"
 ],
 "Weak password": [
  null,
  "취약한 비밀번호"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "Show confirmation password": [
  null,
  "비밀번호 확인을 표시합니다"
 ],
 "Hide confirmation password": [
  null,
  "확인 비밀번호 숨기기"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "$0 will be installed.": [
  null,
  "$0 가 설치됩니다."
 ],
 "Install": [
  null,
  "설치"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 는 저장소에서 사용 할 수 없습니다."
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Unknown host: $0": [
  null,
  "알 수 없는 호스트: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 키 인증을 사용하여 $0 에 로그인 할 수 없습니다. 비밀번호를 입력하세요."
 ],
 "SSH key login": [
  null,
  "SSH 키 로그인"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit가 오류 코드 $0 를 보고했습니다"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "Row expansion": [
  null,
  "행 확장"
 ],
 "Row select": [
  null,
  "행 선택"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "붙임 오류"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "당신의 검색기는 내용 메뉴에서 붙여넣기를 허용하지 않습니다. Shift+Insert를 사용 할 수 있습니다."
 ],
 "Error during initialization": [
  null,
  "초기화 중에 오류"
 ],
 "Failed": [
  null,
  "실패함"
 ],
 "Home": [
  null,
  "홈"
 ],
 "Downloads": [
  null,
  "내려받기"
 ],
 "Not a directory": [
  null,
  "디렉토리가 아닙니다"
 ],
 "All files": [
  null,
  "모든 파일"
 ],
 "Recent": [
  null,
  "최근"
 ],
 "No recent directories": [
  null,
  "최근 디렉토리 없음"
 ],
 "No recent files": [
  null,
  "최근 파일 없음"
 ],
 "Type to filter": [
  null,
  "필터 입력"
 ],
 "File chooser actions": [
  null,
  "파일 선택기 작업"
 ],
 "Open in file browser": [
  null,
  "파일 검색기에서 열기"
 ],
 "Hide hidden files": [
  null,
  "숨겨진 파일을 숨깁니다"
 ],
 "Show hidden files": [
  null,
  "숨긴 파일 표시"
 ],
 "Filesystem": [
  null,
  "파일시스템"
 ],
 "Clear filters": [
  null,
  "필터 지우기"
 ],
 "Directory is empty": [
  null,
  "디렉토리가 비어 있습니다"
 ],
 "Directory has no sub-directories": [
  null,
  "디렉토리는 하위-디렉토리가 없습니다"
 ],
 "This directory contains only hidden files": [
  null,
  "이 디렉토리는 숨겨진 파일만 포함합니다"
 ],
 "No matching results": [
  null,
  "일치하는 결과를 찾을 수 없습니다"
 ],
 "Folder": [
  null,
  "폴더"
 ],
 "File": [
  null,
  "파일"
 ],
 "Copy to clipboard": [
  null,
  "클립보드로 복사"
 ],
 "Automation script": [
  null,
  "자동 스크립트"
 ],
 "Ansible": [
  null,
  "앤서블"
 ],
 "Create new task file with this content.": [
  null,
  "이 컨텐츠로 신규 작업 파일을 만듭니다."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 역할 문서"
 ],
 "Shell script": [
  null,
  "쉘 스크립트"
 ],
 "No system modifications": [
  null,
  "시스템 수정 없음"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "로그인한 사용자는 시스템 수정 사항을 볼 수 없습니다"
 ],
 "Loading system modifications...": [
  null,
  "시스템 수정을 불러오는 중..."
 ],
 "View automation script": [
  null,
  "자동 스크립트 보기"
 ],
 "Occurrences": [
  null,
  "발생"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "Other": [
  null,
  "기타"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "Rack mount chassis": [
  null,
  "랙 적재 구조"
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Present": [
  null,
  "존재"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen을 통한 메세지 제공시간이 초과되었습니다"
 ],
 "Not a valid private key": [
  null,
  "유효한 개인 키가 없습니다"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Invalid file permissions": [
  null,
  "잘못된 파일 권한"
 ],
 "Password not accepted": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Select an option": [
  null,
  "옵션을 선택합니다"
 ],
 "$0 killed with signal $1": [
  null,
  "$1 시그널에 의해 $0 가 종료되었습니다"
 ],
 "$0 exited with code $1": [
  null,
  "$0가 코드 $1로 종료됨"
 ],
 "$0 failed": [
  null,
  "$0 실패"
 ],
 "Your session has been terminated.": [
  null,
  "세션이 종료되었습니다."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "세션이 만료되었습니다. 다시 로그인하십시오."
 ],
 "Not permitted to perform this action.": [
  null,
  "이 작업을 실행할 수 있는 권한이 없습니다."
 ],
 "Login failed": [
  null,
  "로그인 실패"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "서버가 지원되는 방법을 사용하여 인증을 거부했습니다."
 ],
 "Untrusted host": [
  null,
  "지원되지 않는 호스트"
 ],
 "Host key is incorrect": [
  null,
  "호스트 키가 잘못되었습니다"
 ],
 "Internal error": [
  null,
  "내부 오류"
 ],
 "Connection has timed out.": [
  null,
  "연결 시간 초과."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "시스템에 Cockpit이 설치되어 있지 않습니다."
 ],
 "Cannot forward login credentials": [
  null,
  "로그인 정보를 전송할 수 없습니다"
 ],
 "Server has closed the connection.": [
  null,
  "서버 연결이 종료되었습니다."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit은 시스템의 소프트웨어와 호환성이 없습니다."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit을 지정된 호스트에 연결 할 수 없습니다."
 ],
 "Too much data": [
  null,
  "데이터가 너무 많습니다"
 ],
 "edit": [
  null,
  "편집"
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete files": [
  null,
  "파일 삭제"
 ],
 "Delete $0": [
  null,
  "$0 삭제"
 ],
 "Edit user": [
  null,
  "사용자 편집"
 ],
 "Log user out": [
  null,
  "사용자 로그아웃"
 ],
 "Lock account": [
  null,
  "계정 잠금"
 ],
 "Delete account": [
  null,
  "계정 삭제"
 ],
 "Logged in": [
  null,
  "로그인 상태"
 ],
 "Never logged in": [
  null,
  "로그인 하지 않음"
 ],
 "Your account": [
  null,
  "사용자 계정"
 ],
 "Group name": [
  null,
  "그룹 이름"
 ],
 "# of users": [
  null,
  "# 사용자"
 ],
 "Accounts": [
  null,
  "계정"
 ],
 "Search for name or ID": [
  null,
  "이름 또는 ID 검색"
 ],
 "Create new group": [
  null,
  "신규 그룹 만들기"
 ],
 "Groups": [
  null,
  "그룹"
 ],
 "$0 more...": [
  null,
  "$0 더 알아보기..."
 ],
 "Clear filter": [
  null,
  "필터 지우기"
 ],
 "Username": [
  null,
  "사용자 이름"
 ],
 "Full name": [
  null,
  "성명"
 ],
 "Last active": [
  null,
  "최근 활성"
 ],
 "Group": [
  null,
  "그룹"
 ],
 "Actions": [
  null,
  "동작"
 ],
 "Search for name, group or ID": [
  null,
  "이름, 그룹 또는 ID 검색"
 ],
 "Create new account": [
  null,
  "신규 계정 만들기"
 ],
 "No group name specified": [
  null,
  "지정된 그룹 이름이 없습니다"
 ],
 "Group name can only consist of letters, digits, dots, dashes, and underscores": [
  null,
  "그룹 이름은 문자, 숫자, 점, 줄표와 밑줄만으로 구성 할 수 있습니다"
 ],
 "A group with this name already exists": [
  null,
  "이 이름으로된 그룹이 이미 존재합니다"
 ],
 "No ID specified": [
  null,
  "지정된 ID가 없습니다"
 ],
 "Group ID must be positive integer": [
  null,
  "그룹 ID는 양의 정수이어야 합니다"
 ],
 "Create": [
  null,
  "생성"
 ],
 "New name": [
  null,
  "새로운 이름"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "그룹 이름변경은 sudo 및 유사 규칙에 영향을 줍니다"
 ],
 "Group name cannot be empty": [
  null,
  "그룹 이름은 비워 둘 수 없습니다"
 ],
 "Rename group $0": [
  null,
  "그룹 $0 이름변경"
 ],
 "Rename": [
  null,
  "이름변경"
 ],
 "Login history": [
  null,
  "로그인 기록"
 ],
 "Login history list": [
  null,
  "로그인 기록 목록"
 ],
 "Started": [
  null,
  "시작됨"
 ],
 "Ended": [
  null,
  "종료됨"
 ],
 "From": [
  null,
  "에서"
 ],
 "Prompting via passwd timed out": [
  null,
  "비밀번호를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "You must wait longer to change your password": [
  null,
  "비밀번호 변경을 위해 조금 더 기다려 주십시오"
 ],
 "Old password": [
  null,
  "이전 비밀번호"
 ],
 "Confirm new password": [
  null,
  "신규 비밀번호 확인"
 ],
 "The passwords do not match": [
  null,
  "비밀번호가 일치하지 않습니다"
 ],
 "Password is longer than 256 characters": [
  null,
  "비밀번호는 256자보다 길 수 있습니다"
 ],
 "Set password": [
  null,
  "비밀번호 설정"
 ],
 "Set weak password": [
  null,
  "약한 비밀번호 설정"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "'$0' 계정은 다음 로그인 시 비밀번호를 변경해야 합니다"
 ],
 "Force password change": [
  null,
  "강제 비밀번호 변경"
 ],
 "Reset password": [
  null,
  "비밀번호 재설정"
 ],
 "Logout $0": [
  null,
  "$0 로그아웃"
 ],
 "Rename group": [
  null,
  "그룹 이름변경"
 ],
 "Delete group": [
  null,
  "그룹 삭제"
 ],
 "Home directory": [
  null,
  "홈 디렉토리"
 ],
 "Path to directory": [
  null,
  "디렉토리 경로"
 ],
 "Shell": [
  null,
  "쉘"
 ],
 "User ID": [
  null,
  "사용자 ID"
 ],
 "Use password": [
  null,
  "비밀번호 사용"
 ],
 "Require password change on first login": [
  null,
  "처음 로그인에서 비밀번호를 변경해야 합니다"
 ],
 "Disallow password authentication": [
  null,
  "비밀번호 인증을 허용하지 않습니다"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "다른 인증 방식은 대화형 비밀번호 인증이 허용되지 않을 때에 여전히 사용 할 수 있습니다."
 ],
 "No user name specified": [
  null,
  "지정된 사용자 이름이 없습니다"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "사용자 이름에는 a~z 문자, 숫자, 점, 줄표와 밑줄만 사용 할 수 있습니다."
 ],
 "This user name already exists": [
  null,
  "이 사용자 이름이 이미 존재합니다"
 ],
 "No real name specified": [
  null,
  "실제 이름이 지정되지 않았습니다"
 ],
 "The full name must not contain colons.": [
  null,
  "성명은 쌍점이 포함되지 않아야 합니다."
 ],
 "User ID must be a positive integer": [
  null,
  "사용자 ID는 양의 정수이어야 합니다"
 ],
 "User ID must not be lower than $0": [
  null,
  "사용자 ID는 $0 보다 작지 안아야만 합니다"
 ],
 "User ID must not be higher than $0": [
  null,
  "사용자 ID는 $0 보다 크지 않아야만 합니다"
 ],
 "User ID is already used by another user": [
  null,
  "사용자 ID는 이미 다른 사용자에 의해 사용되고 있습니다"
 ],
 "Empty password": [
  null,
  "빈 비밀번호"
 ],
 "$0 is an existing file": [
  null,
  "$0는 존재하는 파일입니다"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "홈 디렉토리 $0 가 이미 존재합니다. 이 소유권은 신규 사용자로 변경됩니다."
 ],
 "Create and change ownership of home directory": [
  null,
  "홈 디렉토리의 소유권 생성 및 변경"
 ],
 "Create account with weak password": [
  null,
  "약한 비밀번호로 계정 만들기"
 ],
 "Create account with non-unique UID": [
  null,
  "비-고유 UID로 계정 만들기"
 ],
 "Never expire password": [
  null,
  "비밀번호가 만료되어서는 안됩니다"
 ],
 "Password must be changed": [
  null,
  "비밀번호를 변경해야 합니다"
 ],
 "Require password change on $0": [
  null,
  "$0 에서 비밀번호를 변경해야 합니다"
 ],
 "Never expire account": [
  null,
  "계정 잠금을 하지 않습니다"
 ],
 "Expire account on $0": [
  null,
  "$0 의 계정 만료"
 ],
 "Account not available or cannot be edited.": [
  null,
  "계정을 사용할 수 없거나 편집 할 수 없습니다."
 ],
 "Back to accounts": [
  null,
  "계정으로 돌아가기"
 ],
 "Never": [
  null,
  "하지 않기"
 ],
 "Terminate session": [
  null,
  "세션 종료"
 ],
 "Last login": [
  null,
  "마지막 로그인"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Disallow interactive password": [
  null,
  "대화형 비밀번호 허용 안 함"
 ],
 "Force change": [
  null,
  "강제 변경"
 ],
 "change": [
  null,
  "변경"
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "사용자는 새로운 구성을 적용하려면 로그 아웃 했다가 다시 로그인 해야 합니다."
 ],
 "Undo": [
  null,
  "실행 취소"
 ],
 "Permanently delete $0 group?": [
  null,
  "영구적으로 $0 그룹을 삭제 할까요?"
 ],
 "This group is the primary group for the following users:": [
  null,
  "이 그룹은 다음 사용자를 위한 기본 그룹입니다:"
 ],
 "Force delete": [
  null,
  "강제 삭제"
 ],
 "Change shell": [
  null,
  "쉘 변경"
 ],
 "Expire account on": [
  null,
  "계정 만료"
 ],
 "Please specify an expiration date": [
  null,
  "만료 날짜를 지정해 주십시오"
 ],
 "Invalid expiration date": [
  null,
  "잘못된 만료 기간"
 ],
 "Account expiration": [
  null,
  "계정 만료"
 ],
 "Require password change every $0 days": [
  null,
  "$0 일 마다 비밀번호를 변경해야 합니다"
 ],
 "Invalid number of days": [
  null,
  "일 수가 잘못되었습니다"
 ],
 "Password expiration": [
  null,
  "비밀번호 만료"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "SSH 공개키 파일 내용을 여기에 붙여넣기합니다"
 ],
 "Add public key": [
  null,
  "공개 키 추가"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "이 계정에 승인된 공개 키를 표시할 수 있는 권한이 없습니다."
 ],
 "Failed to load authorized keys.": [
  null,
  "승인된 키를 불러오지 못했습니다."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "이 계정에 승인된 공개키가 없습니다."
 ],
 "Authorized public SSH keys": [
  null,
  "승인된 공개 SSH 키"
 ],
 "Unnamed": [
  null,
  "이름 없음"
 ],
 "Invalid key": [
  null,
  "잘못된 키"
 ],
 "Error saving authorized keys: ": [
  null,
  "승인된 키를 저장하는 동안 오류가 발생했습니다: "
 ],
 "The key you provided was not valid.": [
  null,
  "입력하신 키가 유효하지 않습니다."
 ],
 "Lock $0": [
  null,
  "$0 잠금"
 ],
 "Lock": [
  null,
  "잠그기"
 ],
 "user": [
  null,
  "사용자"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 및 Firewalld의 Cockpit 구성"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "이와 같은 도구는 NetworkManager 및 Firewalld를 사용하여 bonds, bridges, teams, VLAN과 방화벽과 같은 네트워킹을 관리합니다. NetworkManager는 우분투 기본 systemd-netowrkd 및 데비안의 ifupdown 스크립트와는 호환되지 않습니다."
 ],
 "Manage storage": [
  null,
  "관리 저장소"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "이와 같은 도구는 파일시스템, LVM2 볼륨 그룹, 그리고 NFS 적재와 같은 로컬 저장소를 관리합니다."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "진단 및 지원 자료 수집 및 꾸러미"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "이와 같은 도구는 동작 중인 시스템에서 구성 및 진단 정보의 아카이브를 생성합니다. 아카이브는 기록 또는 추적 목적으로 로컬 또는 집중적으로 저장되거나 기술적 오류-찾기와 디버깅을 지원하기 위해 기술 지원 담당자, 개발자 또는 시스템 관리자에게 보낼 수 있습니다."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "보안이 향상된 리눅스 구성과 문제해결"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "이와 같은 도구는 SELinux 정책을 구성하고 정책 위반을 이해하고 해결하는데 도움을 줄 수 있습니다."
 ],
 "Collect kernel crash dumps": [
  null,
  "커널 충돌 덤프 수집"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "이와 같은 도구는 커널 충돌 덤프를 작성하도록 시스템을 구성합니다. 이는 \"로컬\" (디스크), \"ssh\" 및 \"nfs\" 덤프 대상을 지원합니다."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔로 관리"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔의 권한 작업을 수행하려면 인증이 필요합니다"
 ]
});
