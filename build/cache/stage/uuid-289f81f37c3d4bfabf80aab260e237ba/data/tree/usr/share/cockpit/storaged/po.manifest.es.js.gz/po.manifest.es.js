cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Redes"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "mount": [
  null,
  "mount"
 ],
 "format": [
  null,
  "formato"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "sistema de archivos"
 ],
 "partition": [
  null,
  "partición"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "volumen"
 ],
 "disk": [
  null,
  "disco"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "disco"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "cifrado"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Gestión de particiones"
 ],
 "Managing NFS mounts": [
  null,
  "Gestión de montajes NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestión de RAIDs"
 ],
 "Managing LVMs": [
  null,
  "Gestión de LVMs"
 ],
 "Managing physical drives": [
  null,
  "Gestión de discos físicos"
 ],
 "Managing VDOs": [
  null,
  "Gestión de VDOs"
 ],
 "Using LUKS encryption": [
  null,
  "Usar cifrado LUKS"
 ],
 "Using Tang server": [
  null,
  "Usar un servidor Tang"
 ]
});
