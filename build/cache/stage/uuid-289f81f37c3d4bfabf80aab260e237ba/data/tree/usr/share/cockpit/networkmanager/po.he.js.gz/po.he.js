cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Firewall": [
  null,
  "חומת אש"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Public key": [
  null,
  "מפתח ציבורי"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "Connect": [
  null,
  "התחברות"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "Disconnected": [
  null,
  "מנותק"
 ],
 "Permission denied": [
  null,
  "ההרשאה נדחתה"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Switch to administrative access": [
  null,
  "מעבר לגישה ניהולית"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Problem becoming administrator": [
  null,
  "תקלה בהעברה לניהול"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit דיווח את קוד השגיאה $0"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "None": [
  null,
  "אין"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Generated": [
  null,
  "נוצר"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Not available": [
  null,
  "לא זמין"
 ],
 "Ignore": [
  null,
  "התעלמות"
 ],
 "Permanent": [
  null,
  "קבוע"
 ],
 "Preserve": [
  null,
  "שימור"
 ],
 "Random": [
  null,
  "אקראי"
 ],
 "Stable": [
  null,
  "יציב"
 ],
 "Failed to save settings": [
  null,
  "שמירת ההגדרות נכשלה"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "יצירת ה־$0 הזה תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Create it": [
  null,
  "ליצור אותו"
 ],
 "Invalid prefix $0": [
  null,
  "קידומת שגויה $0"
 ],
 "Invalid metric $0": [
  null,
  "מדד שגוי $0"
 ],
 "Invalid address $0": [
  null,
  "כתובת שגויה $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "קידומת או מסכת רשת שגויה $0"
 ],
 "Testing connection": [
  null,
  "החיבור נבדק"
 ],
 "Restoring connection": [
  null,
  "החיבור משוחזר"
 ],
 "Troubleshoot…": [
  null,
  "פתרון תקלות…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager אינו פעיל"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager אינו מותקן"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "התקני רשת ותרשימים דורשים NetworkManager"
 ],
 "Enable service": [
  null,
  "הפעלת שירות"
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "אין לך הרשאה לשנות את חומת האש."
 ],
 "Not authorized to disable the firewall": [
  null,
  "לא מורשה להשבית את חומת האש"
 ],
 "Not authorized to enable the firewall": [
  null,
  "לא מורשה להפעיל את חומת האש"
 ],
 "Disable the firewall": [
  null,
  "השבתת חומת האש"
 ],
 "Enable the firewall": [
  null,
  "הפעלת חומת האש"
 ],
 "Edit service $0": [
  null,
  "עריכת השירות $0"
 ],
 "Remove service $0": [
  null,
  "הסרת השירות $0"
 ],
 "Remove zone $0": [
  null,
  "הסרת האזור $0"
 ],
 "Add services to zone $0": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Add services": [
  null,
  "הוספת שירותים"
 ],
 "Service": [
  null,
  "שירות"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "אזור $0"
 ],
 "Interface": [
  null,
  "מנשק",
  "מנשקים",
  "מנשקים",
  "מנשקים"
 ],
 "Allowed addresses": [
  null,
  "כתובות מורשות"
 ],
 "Entire subnet": [
  null,
  "כל תת־הרשת"
 ],
 "There are no active services in this zone": [
  null,
  "אין שירותים פעילים באזור הזה"
 ],
 "Filter services": [
  null,
  "סינון שירותים"
 ],
 "Failed to edit service": [
  null,
  "עריכת השירות נכשלה"
 ],
 "Failed to add port": [
  null,
  "הוספת הפתחה נכשלה"
 ],
 "Failed to add service": [
  null,
  "הוספת השירות נכשל"
 ],
 "Unknown service name": [
  null,
  "שם השירות לא ידוע"
 ],
 "Invalid port number": [
  null,
  "מספר הפתחה שגוי"
 ],
 "Invalid range": [
  null,
  "טווח שגוי"
 ],
 "Range must be strictly ordered": [
  null,
  "הטווח חייב להיות מסודר בקפידה"
 ],
 "Edit service": [
  null,
  "עריכת שירות"
 ],
 "Edit custom service in $0 zone": [
  null,
  "עריכת שירות משלך באזור $0"
 ],
 "Add ports": [
  null,
  "הוספת פתחות"
 ],
 "Add ports to $0 zone": [
  null,
  "הוספת פתחות לאזור $0"
 ],
 "Add services to $0 zone": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Custom ports": [
  null,
  "פתחות מותאמות אישית"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "לדוגמה: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "פתחות, טווחים ושירותים מופרדים בפסיקים יתקבלו"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "לדוגמה: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "אם השדה נשאר ריק, המזהה יווצר אוטומטית על בסיס השירותים על הפתחה המשויכת ומספרי הפתחות"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "הוספת פתחות מותאמות אישית תטען מחדש את firewalld. טעינה מחדש תגרום לאבדן של הגדרות שנקבעו לזמן הריצה בלבד!"
 ],
 "Failed to add zone": [
  null,
  "הוספת האזור נכשלה"
 ],
 "Add zone": [
  null,
  "הוספת אזור"
 ],
 "Trust level": [
  null,
  "רמת אמון"
 ],
 "Sorted from least to most trusted": [
  null,
  "מסודר מהכי מהימן להכי פחות"
 ],
 "Custom zones": [
  null,
  "אזורים מותאמים אישית"
 ],
 "No description available": [
  null,
  "אין תיאור זמין"
 ],
 "Included services": [
  null,
  "שירותים כלולים"
 ],
 "The cockpit service is automatically included": [
  null,
  "שירות ה־cockpit נכלל אוטומטית"
 ],
 "Interfaces": [
  null,
  "מנשקים"
 ],
 "Range": [
  null,
  "טווח"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "כתובת IP עם קידומת ניתוב. יש להפריד בין ערכים בפסיק. למשל: 192.0.2.0/24, ‎2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "אישור הסרת $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "אזור זה מכיל את שירות ה־Cockpit. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "הסרת האזור תסיר את כל השירותים שבו."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "הסרת השירות cockpit עלול לגרום לקטיעת שירות המסוף המקוון. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "הסרת השירות $0 מהאזור $1"
 ],
 "Firewall is not available": [
  null,
  "חומת האש אינה זמינה"
 ],
 "Please install the $0 package": [
  null,
  "נא להתקין את החבילה $0"
 ],
 "Add a new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Add new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "בקשות נכנסות נחסמות כברירת מחדל. בקשות יוצאות לא נחסמות."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "WPA/WPA2 Personal": [
  null,
  ""
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "מחיקת $0 תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הפעלת $0 תקטע את החיבור לשרת ותגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Switch on $0": [
  null,
  "הדלקת $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "כיבוי $0 יקטע את החיבור לשרת וגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Switch off $0": [
  null,
  "כיבוי $0"
 ],
 "Bond": [
  null,
  "מאגד"
 ],
 "Team": [
  null,
  "ציוות"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "גשר"
 ],
 "Unknown \"$0\"": [
  null,
  "„$0” לא ידוע"
 ],
 "Carrier": [
  null,
  "ספקית"
 ],
 "Yes": [
  null,
  "כן"
 ],
 "No": [
  null,
  "לא"
 ],
 "Inactive": [
  null,
  "לא פעיל"
 ],
 "Unknown configuration": [
  null,
  "הגדרות לא ידועות"
 ],
 "Additional address $val": [
  null,
  "כתובת נוספת $val"
 ],
 "Address $val": [
  null,
  "כתובת $val"
 ],
 "Additional DNS $val": [
  null,
  "$val נוסף ב־DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS נוספים $val"
 ],
 "DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS‏ $val"
 ],
 "General": [
  null,
  "כללי"
 ],
 "Connect automatically": [
  null,
  "התחברות אוטומטית"
 ],
 "Automatic": [
  null,
  "אוטומטית"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "מעקב אחר ARP"
 ],
 "Broken configuration": [
  null,
  "הגדרות פגומות"
 ],
 "Team port": [
  null,
  "פתחת ציוות"
 ],
 "Spanning tree protocol": [
  null,
  "פרוטוקול העץ הפורש"
 ],
 "Priority $priority": [
  null,
  "עדיפות $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "השהיית העברה $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "זמן Hello‏ $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "גיל הודעה מרבי $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "עלות הנתיב $path_cost"
 ],
 "Hairpin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "Bridge port": [
  null,
  "פתחת גשר"
 ],
 "Parent $parent": [
  null,
  "$parent הורה"
 ],
 "ID $id": [
  null,
  "מזהה $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  ""
 ],
 "open": [
  null,
  ""
 ],
 "Signal strength": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "ניתוק"
 ],
 "Refresh": [
  null,
  ""
 ],
 "Network": [
  null,
  "רשת"
 ],
 "Mode": [
  null,
  "מצב"
 ],
 "Signal": [
  null,
  ""
 ],
 "Rate": [
  null,
  ""
 ],
 "Not permitted to configure network devices": [
  null,
  "אין הקשה להגדיר התקני רשת"
 ],
 "Enable or disable the device": [
  null,
  "להפעיל או להשבית את ההתקן"
 ],
 "This device cannot be managed here.": [
  null,
  "לא ניתן לנהל את ההתקן הזה כאן."
 ],
 "Connection will be lost": [
  null,
  "החיבור יאבד"
 ],
 "Keep connection": [
  null,
  "לשמור על החיבור"
 ],
 "Preparing": [
  null,
  "בהכנה"
 ],
 "Configuring": [
  null,
  "מתבצעת הגדרה"
 ],
 "Authenticating": [
  null,
  "מתבצע אימות"
 ],
 "Configuring IP": [
  null,
  "מוגדרת כתובת IP"
 ],
 "Checking IP": [
  null,
  "ה־IP נבדק"
 ],
 "Waiting": [
  null,
  "בהמתנה"
 ],
 "Active": [
  null,
  "פעיל"
 ],
 "Deactivating": [
  null,
  "מתבצעת השבתה"
 ],
 "Adhoc": [
  null,
  ""
 ],
 "Infra": [
  null,
  ""
 ],
 "Mesh": [
  null,
  ""
 ],
 "No carrier": [
  null,
  "אין ספקית"
 ],
 "Part of $0": [
  null,
  "חלק מתוך $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "שינוי ההגדרות יפגע בחיבור לשרת וימנע את הגישה למנשק הניהול."
 ],
 "Change the settings": [
  null,
  "שינוי ההגדרות"
 ],
 "Add bridge": [
  null,
  "הוספת גשר"
 ],
 "Edit bridge settings": [
  null,
  "עריכת הגדרות גשר"
 ],
 "Ports": [
  null,
  "פתחות"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "פרוטוקול העץ הפורש (STP)"
 ],
 "STP priority": [
  null,
  "עדיפות STP"
 ],
 "STP forward delay": [
  null,
  "השהיית העברת STP"
 ],
 "STP hello time": [
  null,
  "זמן Hello של STP"
 ],
 "STP maximum message age": [
  null,
  "גיל ההודעה המרבי של STP"
 ],
 "Round robin": [
  null,
  "ראונד-רובין"
 ],
 "Active backup": [
  null,
  "גיבוי פעיל"
 ],
 "Load balancing": [
  null,
  "איזון עומס"
 ],
 "Broadcast": [
  null,
  "שידור"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "סביל"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "פינג ARP"
 ],
 "NSNA ping": [
  null,
  "פינג מסוג NSNA"
 ],
 "Add team": [
  null,
  "הוספת צוות"
 ],
 "Edit team settings": [
  null,
  "עריכת הגדרות ציוות"
 ],
 "Runner": [
  null,
  "שליח"
 ],
 "Balancer": [
  null,
  "מאזן"
 ],
 "Primary": [
  null,
  "עיקרי"
 ],
 "Link watch": [
  null,
  "עקיבה אחר קישורים"
 ],
 "Link up delay": [
  null,
  "השהיית חיבור קישור"
 ],
 "Link down delay": [
  null,
  "השהיית קטיעת קישור"
 ],
 "Ping interval": [
  null,
  "הפרש בין פינגים"
 ],
 "Ping target": [
  null,
  "יעד פינג"
 ],
 "Automatic (DHCP only)": [
  null,
  "אוטומטית (DHCP בלבד)"
 ],
 "Link local": [
  null,
  "קישור מקומי"
 ],
 "Manual": [
  null,
  "ידני"
 ],
 "Shared": [
  null,
  "משותף"
 ],
 "Prefix length or netmask": [
  null,
  "אורך קידומת או מסכת רשת"
 ],
 "Prefix length": [
  null,
  "אורך קידומת"
 ],
 "IPv4 settings": [
  null,
  "הגדרות IPv4"
 ],
 "IPv6 settings": [
  null,
  "הגדרות IPv6"
 ],
 "Addresses": [
  null,
  "כתובות"
 ],
 "Select method": [
  null,
  "בחירת שיטה"
 ],
 "Add address": [
  null,
  "הוספת כתובת"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Remove item": [
  null,
  "הסרת פריט"
 ],
 "Gateway": [
  null,
  "שער גישה"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "הוספת שרת DNS"
 ],
 "DNS search domains": [
  null,
  "חיפוש שמות תחום DNS"
 ],
 "Add search domain": [
  null,
  "הוספת שם תחום לחיפוש"
 ],
 "Search domain": [
  null,
  "שם תחום לחיפוש"
 ],
 "Routes": [
  null,
  "ניתובים"
 ],
 "Add route": [
  null,
  "הוספת נתיב"
 ],
 "Metric": [
  null,
  "מדד (עדיפות)"
 ],
 "Enter a valid MAC address": [
  null,
  "נא למלא כתובת MAC תקנית"
 ],
 "Ethernet MAC": [
  null,
  "כתובת חומרת אתרנט"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "Add VPN": [
  null,
  "הוספת VPN"
 ],
 "Add bond": [
  null,
  "הוספת מאגד"
 ],
 "Add VLAN": [
  null,
  "הוספת VLAN"
 ],
 "Edit rules and zones": [
  null,
  "עריכת כללים ואזורים"
 ],
 "$0 active zone": [
  null,
  "אזור פעיל",
  "שני אזורים פעילים",
  "$0 אזורים פעילים",
  "$0 אזורים פעילים"
 ],
 "Managed interfaces": [
  null,
  "מנשקים מנוהלים"
 ],
 "IP address": [
  null,
  "כתובת IP"
 ],
 "Sending": [
  null,
  "שליחה"
 ],
 "Receiving": [
  null,
  "קבלה"
 ],
 "Unmanaged interfaces": [
  null,
  "מנשקים לא מנוהלים"
 ],
 "Network logs": [
  null,
  "יומני תקשורת"
 ],
 "Addresses are not formatted correctly": [
  null,
  "הכתובות אינן בתבנית נכונה"
 ],
 "wireguard-tools package is not installed": [
  null,
  "חבילת wireguard-tools לא מותקנת"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  ""
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  ""
 ],
 "Listen port must be a number": [
  null,
  "פתחת ההאזנה חייבת להיות מספר"
 ],
 "Add WireGuard VPN": [
  null,
  "הוספת VPN מסוג WireGuard"
 ],
 "Edit WireGuard VPN": [
  null,
  "עריכת VPN מסוג VPN"
 ],
 "Private key": [
  null,
  "מפתח פרטי"
 ],
 "Paste existing key": [
  null,
  "הדבקת מפתח קיים"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  ""
 ],
 "Listen port": [
  null,
  "פתחת האזנה"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "יוגדר ל„אוטומטי”"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  ""
 ],
 "Peers": [
  null,
  "עמיתים"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  ""
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "נקודת קצה שמתנהגת כ„שרת” צריך לציין בתור מארח:פתחה (host:port), אחרת אפשר להשאיר ריק."
 ],
 "Add peer": [
  null,
  "הוספת עמית"
 ],
 "Endpoint": [
  null,
  "נקודת קצה"
 ],
 "Allowed IPs": [
  null,
  "כתובות IP מורשות"
 ],
 "No peers added.": [
  null,
  "לא נוספו עמיתים."
 ],
 "Edit VLAN settings": [
  null,
  "עריכת הגדרות VLAN"
 ],
 "Parent": [
  null,
  "הורה"
 ],
 "VLAN ID": [
  null,
  "מזהה VLAN"
 ],
 "Transmitting": [
  null,
  "בהעברה"
 ],
 "MTU must be a positive number": [
  null,
  "MTU חייב להיות מספר חיובי"
 ],
 "Ethernet MTU": [
  null,
  "יחידת העברה מרבית של אתרנט"
 ],
 "Set to": [
  null,
  "הגדרה לכדי"
 ],
 "Team port settings": [
  null,
  "הגדרות פתחת ציוות"
 ],
 "Sticky": [
  null,
  "דביק"
 ],
 "LACP key": [
  null,
  "מפתח LACP"
 ],
 "Bridge port settings": [
  null,
  "הגדרות פתחת גשר"
 ],
 "Path cost": [
  null,
  "עלות נתיב"
 ],
 "Hair pin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "XOR": [
  null,
  "XOR (קסור)"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "איזון עומס העברה מסתגל"
 ],
 "Adaptive load balancing": [
  null,
  "איזון עומס מסתגל"
 ],
 "MII (recommended)": [
  null,
  "MII (מומלץ)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "עריכת הגדרות מאגד"
 ],
 "Network bond": [
  null,
  "מאגד רשת"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "מאגד רשת משלב מספר מנשקי רשת למנשק לוגי אחד עם קצב העברה גבוה יותר או יתירות."
 ],
 "Link monitoring": [
  null,
  "מעקב אחר קישורים"
 ],
 "Monitoring interval": [
  null,
  "הפרש בין דגימות מעקב"
 ],
 "Monitoring targets": [
  null,
  "יעדי מעקב"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הסרת $0 תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Remove $0": [
  null,
  "הסרת $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הוספת $0 תקטע את החיבור לשרת ותגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Add member": [
  null,
  "הוספת חבר"
 ],
 "Interface members": [
  null,
  "חברים במנשק"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ]
});
