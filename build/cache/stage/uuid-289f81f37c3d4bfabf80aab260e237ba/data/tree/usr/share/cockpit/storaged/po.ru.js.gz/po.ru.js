cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "ru",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "Set": [
  null,
  "Настроить"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "$0 key changed": [
  null,
  "Изменён $0 ключ"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "Permission denied": [
  null,
  "Отказано в доступе"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Create $0": [
  null,
  "Создать $0"
 ],
 "Ok": [
  null,
  "ОК"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "You now have administrative access.": [
  null,
  "Получены права администратора."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Нет доступных методов получения административного доступа (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Пройдите проверку подлинности для получения прав администратора"
 ],
 "Switch to administrative access": [
  null,
  "Переключиться на доступ с правами администратора"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Problem becoming administrator": [
  null,
  "При получении прав администратора возникли проблемы"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Limit access": [
  null,
  "Ограничить доступ"
 ],
 "Switch to limited access": [
  null,
  "Переключится на ограниченный доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "В ограниченном режиме доступа ограничиваются полномочия администратора. В некоторых разделах веб-консоли будет урезаны функциональные возможности."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Браузер запоминает уровень доступа от сеанса к сеансу."
 ],
 "Limited access": [
  null,
  "Ограниченный доступ"
 ],
 "Turn on administrative access": [
  null,
  "Включить доступ с правами администратора"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "less than a minute ago": [
  null,
  "менее минуты назад"
 ],
 "in less than a minute": [
  null,
  "менее минуты"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного ПО"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Unknown host: $0": [
  null,
  "Неизвестный хост: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль."
 ],
 "SSH key login": [
  null,
  "Вход с помощью SSH-ключа"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit передал код ошибки $0"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Ошибка при инициализации"
 ],
 "Failed": [
  null,
  "Ошибка"
 ],
 "Home": [
  null,
  "Домашний каталог"
 ],
 "Downloads": [
  null,
  "Загрузки"
 ],
 "Not a directory": [
  null,
  "Не является каталогом"
 ],
 "All files": [
  null,
  "Все файлы"
 ],
 "Recent": [
  null,
  "Недавние"
 ],
 "No recent directories": [
  null,
  "Нет недавних каталогов"
 ],
 "No recent files": [
  null,
  "Нет недавних файлов"
 ],
 "Type to filter": [
  null,
  "Введите условия фильтра"
 ],
 "File chooser actions": [
  null,
  "Действия выбора файлов"
 ],
 "Open in file browser": [
  null,
  "Открыть в файловом менеджере"
 ],
 "Hide hidden files": [
  null,
  "Скрыть скрытые файлы"
 ],
 "Show hidden files": [
  null,
  "Показывать скрытые файлы"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Clear filters": [
  null,
  "Очистить фильтры"
 ],
 "Directory is empty": [
  null,
  "Каталог пуст"
 ],
 "Directory has no sub-directories": [
  null,
  "Каталог не содержит подкаталогов"
 ],
 "This directory contains only hidden files": [
  null,
  "Этот каталог содержит только скрытые файлы"
 ],
 "No matching results": [
  null,
  "Нет подходящих результатов"
 ],
 "Folder": [
  null,
  "Папка"
 ],
 "File": [
  null,
  "Файл"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Select an option": [
  null,
  "Выбор опции"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "View logs": [
  null,
  "Смотреть журналы"
 ],
 "Dismiss": [
  null,
  "Закрыть"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "none": [
  null,
  "нет"
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Running": [
  null,
  "Работает"
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Vendor": [
  null,
  "Производитель"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Username": [
  null,
  "Имя пользователя"
 ],
 "Actions": [
  null,
  "Действия"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Started": [
  null,
  "Запущена"
 ],
 "Delete group": [
  null,
  "Удалить группу"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Lock": [
  null,
  "Заблокировать"
 ],
 "Use $0": [
  null,
  "Исп. $0"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Disconnect": [
  null,
  "Отключиться"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "$0 disk is missing": [
  null,
  "$0 диск отсутствует",
  "$0 диска отсутствуют",
  "$0 дисков отсутствуют"
 ],
 "Location": [
  null,
  "Расположение"
 ],
 "Compression": [
  null,
  "Сжатие"
 ],
 "Storage logs": [
  null,
  "Журналы хранения"
 ],
 "Name cannot be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Длина имени должна составлять не более 127 символов."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Имя не должно содержать знак «$0»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Имя не должно содержать пробелы."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Длина имени в символах не должна превышать $0"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Длина имени в байтах не должна превышать $0"
 ],
 "$name (from $host)": [
  null,
  "$name (от $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Пул для тонких логических томов"
 ],
 "Thin logical volume": [
  null,
  "Тонкий логический том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логический том (моментальный снимок)"
 ],
 "Logical volume": [
  null,
  "Логический том"
 ],
 "MDRAID device $0": [
  null,
  "Устройство MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Группа томов LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Устройство VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрованный логический том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Зашифрованный раздел $0"
 ],
 "Logical volume of $0": [
  null,
  "Логический том $0"
 ],
 "Partition of $0": [
  null,
  "Раздел $0"
 ],
 "Encrypted $0": [
  null,
  "Зашифрованный $0"
 ],
 "unpartitioned space on $0": [
  null,
  "неразмеченная область диска на $0"
 ],
 "unmount": [
  null,
  "размонтировать"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "remove from btrfs volume": [
  null,
  "удалить из тома BTRFS"
 ],
 "stop": [
  null,
  "остановить"
 ],
 "remove from MDRAID": [
  null,
  "удалить из MDRAID"
 ],
 "remove from LVM2": [
  null,
  "удалить из LVM2"
 ],
 "btrfs device": [
  null,
  "Устройство BTRFS"
 ],
 "btrfs volume": [
  null,
  "Том BTRFS"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Длина имени не должна превышать 255 символов."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Имя не должно содержать символ «/»."
 ],
 "Create and mount": [
  null,
  "Создать и смонтировать"
 ],
 "Create only": [
  null,
  "Только для создания"
 ],
 "Create subvolume": [
  null,
  "Создать подтом"
 ],
 "Mount Point": [
  null,
  "Точка монтирования"
 ],
 "delete": [
  null,
  "удалить"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Окончательно удалить подтом $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Удаление приведёт к уничтожению всех данных в подтоме и всех его дочерних объектах."
 ],
 "Edit mount point": [
  null,
  "Изменить точку монтирования"
 ],
 "Unmount": [
  null,
  "Отключить"
 ],
 "Mount": [
  null,
  "Подключение"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Хотя бы один подтом должен быть смонтирован"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Последний смонтированный подтом не может быть удален"
 ],
 "btrfs subvolume": [
  null,
  "Подтом BTRFS"
 ],
 "Snapshot origin": [
  null,
  "Источник снимка"
 ],
 "Mount point": [
  null,
  "Точка подключения"
 ],
 "No subvolumes": [
  null,
  "Нет подтомов"
 ],
 "btrfs subvolumes": [
  null,
  "Подтома BTRFS"
 ],
 "Snapshots": [
  null,
  "Моментальные снимки"
 ],
 "No snapshots found": [
  null,
  "Снимки не найдены"
 ],
 "snapshot": [
  null,
  "моментальный снимок"
 ],
 "$0 is in use": [
  null,
  "$0 используется"
 ],
 "Permanently delete $0?": [
  null,
  "Окончательно удалить $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Удаление приведёт к стиранию всех данных на томе btrfs."
 ],
 "Delete filesystem": [
  null,
  "Удалить файловую систему"
 ],
 "Change label": [
  null,
  "Изменить метку"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Файловая система смонтирована только для чтения"
 ],
 "Label": [
  null,
  "Метка"
 ],
 "Capacity": [
  null,
  "Ёмкость"
 ],
 "btrfs devices": [
  null,
  "Устройства BTRFS"
 ],
 "No devices found": [
  null,
  "Устройства не найдены"
 ],
 "btrfs filesystem": [
  null,
  "Файловая система BTRFS"
 ],
 "Successful": [
  null,
  "Успешно"
 ],
 "Aborted": [
  null,
  "Прерван"
 ],
 "In progress": [
  null,
  "Выполняется"
 ],
 "Interrupted": [
  null,
  "Прерван"
 ],
 "Did not complete": [
  null,
  "Не завершено"
 ],
 "Failed (Unknown)": [
  null,
  "Сбой (Неизвестно)"
 ],
 "Failed (Electrical)": [
  null,
  "Сбой (Electrical)"
 ],
 "Failed (Servo)": [
  null,
  "Сбой (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Сбой (Чтение)"
 ],
 "Failed (Damaged)": [
  null,
  "Сбой (повреждено)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Прерван сбросом уровня контроллера"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Прерван из-за удаления пространства имен из реестра пространств имен"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Прерван из-за обработки команды Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Во время операции самотестирования произошла критическая ошибка"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Завершено с сегментом, который дал сбой, и сегмент, давший сбой, неизвестен"
 ],
 "Completed with one or more failed segments": [
  null,
  "Завершено с одним или несколькими неудачными сегментами"
 ],
 "Aborted for unknown reason": [
  null,
  "Прерван по неизвестной причине"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Прерван из-за операции санации"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Свободные мощности ниже порога"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Температура за пределами рекомендуемых пороговых значений"
 ],
 "Degraded": [
  null,
  "Понижено"
 ],
 "All media is in read-only mode": [
  null,
  "Все носители находятся в режиме только для чтения"
 ],
 "Volatile memory backup failed": [
  null,
  "Сбой рез. копирования энергозависимой памяти"
 ],
 "Persistent memory has become read-only": [
  null,
  "Постоянная память стала доступна только для чтения"
 ],
 "Run short test": [
  null,
  "Запустить короткий тест"
 ],
 "Run extended test": [
  null,
  "Запустить расширенное тестирование"
 ],
 "Abort test": [
  null,
  "Прервать тест"
 ],
 "Disk is failing": [
  null,
  "Сбой диска"
 ],
 "Disk is OK": [
  null,
  "Диск в порядке"
 ],
 "Assessment": [
  null,
  "Оценка"
 ],
 "Power on hours": [
  null,
  "Часы работы"
 ],
 "$0 hours": [
  null,
  "$0 ч"
 ],
 "Self-test status": [
  null,
  "Статус самотестирования"
 ],
 "Number of bad sectors": [
  null,
  "Кол-во поврежденных секторов"
 ],
 "Attributes failing": [
  null,
  "Дающие сбой атрибуты"
 ],
 "Media drive": [
  null,
  "Медиа-носитель"
 ],
 "Solid State Drive": [
  null,
  "Твёрдотельный накопитель"
 ],
 "Hard Disk Drive": [
  null,
  "Жёсткий диск"
 ],
 "iSCSI Drive": [
  null,
  "Накопитель iSCSI"
 ],
 "Drive": [
  null,
  "Устройство"
 ],
 "Device health (SMART)": [
  null,
  "Состояние устройства (SMART)"
 ],
 "Firmware version": [
  null,
  "Версия микропрограммы"
 ],
 "Serial number": [
  null,
  "Серийный номер"
 ],
 "World wide name": [
  null,
  "WWN-имя"
 ],
 "No media inserted": [
  null,
  "Носитель не вставлен"
 ],
 "Device file": [
  null,
  "Файл устройства"
 ],
 "Multipathed devices": [
  null,
  "Многоканальные устройства"
 ],
 "Free space": [
  null,
  "свободного места"
 ],
 "Create partition": [
  null,
  "Создать раздел"
 ],
 "Extended partition": [
  null,
  "Дополнительный раздел"
 ],
 "$0 partitions": [
  null,
  "разделов: $0"
 ],
 "Partitions": [
  null,
  "Разделы"
 ],
 "No partitions found": [
  null,
  "Разделы не найдены"
 ],
 "Unexpected partitions": [
  null,
  "Неожиданные разделы"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Разделы не поддерживаются на этом блочном устройстве. Если оно используется в качестве диска для виртуальной машины, разделами должна управлять операционная система внутри виртуальной машины."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Удаление раздела приведёт к удалению всех данных в нём."
 ],
 "No free space after this partition": [
  null,
  "После этого раздела нет свободного места"
 ],
 "EFI system partition": [
  null,
  "Системный раздел"
 ],
 "BIOS boot partition": [
  null,
  "Загрузочный раздел BIOS"
 ],
 "Partition": [
  null,
  "Раздел"
 ],
 "Shrink": [
  null,
  "Сжать"
 ],
 "Grow": [
  null,
  "Расширить"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Раздел загрузки PowerPC PReP"
 ],
 "Linux swap space": [
  null,
  "Резервная память Linux"
 ],
 "Linux filesystem data": [
  null,
  "Данные файловой системы Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Раздел средства управления логическими томами"
 ],
 "Custom": [
  null,
  "Другой"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Тип должен содержать два шестнадцатеричных символа (от 0 до 9, от А до F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Тип может содержать только символы от 0 до 9, от A до F и «-»."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Тип должен иметь форму NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Установить тип раздела $0"
 ],
 "Custom type": [
  null,
  "Нестандартный тип"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Изменение типов разделов может помешать загрузке системы."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Этот раздел используется не полностью."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Размер раздела составляет $0. Содержимое занимает $1."
 ],
 "Shrink partition": [
  null,
  "Сжать раздел"
 ],
 "Grow content": [
  null,
  "Расширить содержимое"
 ],
 "initialize": [
  null,
  "инициализировать"
 ],
 "Initialize disk $0": [
  null,
  "Инициализировать диск $0"
 ],
 "Partitioning": [
  null,
  "Разбиение"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Совместимость со всеми системами и устройствами (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Совместимость с современными системами и жёсткими дисками объёмом более 2 ТБ (GPT)"
 ],
 "No partitioning": [
  null,
  "Без разбиения"
 ],
 "Overwrite": [
  null,
  "Перезаписать"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Заменить существующие данные нулями (медленно)"
 ],
 "Initialize": [
  null,
  "Инициализировать"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "При инициализации все данные на диске уничтожаются."
 ],
 "Device is read-only": [
  null,
  "Устройство доступно только для чтения"
 ],
 "Create partition table": [
  null,
  "Создать таблицу разделов"
 ],
 "Size must be a number": [
  null,
  "Размер должен быть числом"
 ],
 "Size cannot be zero": [
  null,
  "Размер не может быть равен нулю"
 ],
 "Size cannot be negative": [
  null,
  "Размер не может быть отрицательным"
 ],
 "Size is too large": [
  null,
  "Слишком большой размер"
 ],
 "Size must be at least $0": [
  null,
  "Размер должен быть не менее $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "физический том группы томов LVM2"
 ],
 "member of MDRAID device": [
  null,
  "элемент устройства MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "устройство резервного копирования для устройства VDO"
 ],
 "member of Stratis pool": [
  null,
  "участник пула Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "Файловая система за пределами цели"
 ],
 "device of btrfs volume": [
  null,
  "устройство тома BTRFS"
 ],
 "This device is currently in use.": [
  null,
  "Это устройство в данный момент используется."
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Use": [
  null,
  "Использование"
 ],
 "Services using the location": [
  null,
  "Службы, использующие это расположение"
 ],
 "Processes using the location": [
  null,
  "Процессы, использующие это расположение"
 ],
 "Currently in use": [
  null,
  "Используется в данный момент"
 ],
 "(Not part of target)": [
  null,
  "(не является частью цели)"
 ],
 "These changes will be made:": [
  null,
  "Будут внесены следующие изменения:"
 ],
 "Action": [
  null,
  "Действие"
 ],
 "Important data might be deleted:": [
  null,
  "Важные данные могут быть удалены:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Связанные процессы и службы будут принудительно остановлены."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Связанные процессы будут принудительно остановлены."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Связанные службы будут принудительно остановлены."
 ],
 "Checking filesystem usage": [
  null,
  "Проверка использования файловой системы"
 ],
 "$0 used, $1 total": [
  null,
  "Использовано: $0, всего: $1"
 ],
 "Device contains unrecognized data": [
  null,
  "Устройство содержит нераспознанные данные"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Заблокированное зашифрованное устройство может содержать данные"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Я подтверждаю, что хочу навсегда удалить эти данные"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Точка монтирования $0 используется следующими процессами:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Точка монтирования $0 используется следующими службами:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Перечисленные процессы и службы будут принудительно остановлены."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Перечисленные процессы будут принудительно остановлены."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Перечисленные службы будут принудительно остановлены."
 ],
 "Sorry": [
  null,
  "Ошибка"
 ],
 "Usage of $0": [
  null,
  "Использование $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Пул VDO LVM2"
 ],
 "Data used": [
  null,
  "Использованные данные"
 ],
 "Metadata used": [
  null,
  "Используемые метаданные"
 ],
 "Use compression": [
  null,
  "Использовать сжатие"
 ],
 "Deduplication": [
  null,
  "Дедупликация"
 ],
 "Use deduplication": [
  null,
  "Использовать дедупликацию"
 ],
 "Rename volume group": [
  null,
  "Переименование группы томов"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Эта группа томов содержит корневую файловую систему. Ее переименование может потребовать дополнительных изменений в конфигурации загрузчика или командной строке ядра."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Удаление приведёт к уничтожению всех данных, содержащихся в группе томов."
 ],
 "Create snapshot": [
  null,
  "Создание моментального снимка"
 ],
 "Add disks": [
  null,
  "Добавление дисков"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "No disks are available.": [
  null,
  "Нет доступных дисков."
 ],
 "At least one disk is needed.": [
  null,
  "Необходим хотя бы один диск."
 ],
 "Volume group is missing physical volumes": [
  null,
  "В группе томов отсутствуют физические тома"
 ],
 "No free space": [
  null,
  "Нет свободного места"
 ],
 "LVM2 volume group": [
  null,
  "Группа томов LVM2"
 ],
 "Add physical volume": [
  null,
  "Добавить физический том"
 ],
 "LVM2 logical volumes": [
  null,
  "Логические тома LVM2"
 ],
 "Create new logical volume": [
  null,
  "Создать новый логический том"
 ],
 "No logical volumes": [
  null,
  "Нет логических томов"
 ],
 "Remove missing physical volumes?": [
  null,
  "Удалить отсутствующие физические тома?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "В этой группе томов отсутствуют некоторые физические тома."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Невозможно переименовать группу томов с отсутствующими физическими томами."
 ],
 "Physical volumes": [
  null,
  "Физические тома"
 ],
 "No physical volumes found": [
  null,
  "Физические тома не найдены"
 ],
 "LVM2 physical volumes": [
  null,
  "Физические тома LVM2"
 ],
 "Rename logical volume": [
  null,
  "Переименование логического тома"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Окончательно удалить логический том $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Удаление логического тома приведёт к удалению всех данных в нём."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Не удалось восстановить логический том $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Здесь не хватает места, которое можно было бы использовать для восстановления. Требуется не менее $0 на физических томах, которые ещё не используются для этого логического тома."
 ],
 "An additional $0 must be selected": [
  null,
  "Необходимо выбрать дополнительный $0"
 ],
 "Repair logical volume $0": [
  null,
  "Исправить логический том $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Выберите физические тома, которые следует использовать для восстановления логического тома. Необходимо как минимум $0."
 ],
 "Physical Volumes": [
  null,
  "Физические тома"
 ],
 "Repair": [
  null,
  "Исправить"
 ],
 "deactivate": [
  null,
  "отключить"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Деактивировать логический том $0/$1?"
 ],
 "Deactivate": [
  null,
  "Отключить"
 ],
 "Not enough space to grow": [
  null,
  "Недостаточно места для увеличения"
 ],
 "LVM2 logical volume": [
  null,
  "Логический том LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Полосатый (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Зеркальный (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Полосатый и зеркальный (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Выделенная чётность (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Распределённая чётность (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Двойная распределённая чётность (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Логический том используется содержимым не до конца."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Размер тома составляет $0. Содержимое занимает $1."
 ],
 "Shrink volume": [
  null,
  "Сжать том"
 ],
 "Layout": [
  null,
  "Макет"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Этот логический том потерял часть своих физических томов и больше не может использоваться. Необходимо удалить его и создать новый, чтобы занять его место."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Этот логический том потерял часть своих физических томов, но не потерял данные. Его следует восстановить, чтобы вернуть первоначальное резервирование."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Этот логический том потерял часть своих физических томов, но, возможно, данные ещё не потеряны. Возможно, его удастся восстановить."
 ],
 "Stripes": [
  null,
  "Полосы"
 ],
 "$0 synchronized": [
  null,
  "$0 синхронизировано"
 ],
 "Create volume group": [
  null,
  "Создать группу томов"
 ],
 "LVM2 physical volume": [
  null,
  "Физический том LVM2"
 ],
 "Last cannot be removed": [
  null,
  "Последний не может быть удалён"
 ],
 "Not enough free space": [
  null,
  "Недостаточно свободного места"
 ],
 "Volume group": [
  null,
  "Группа томов"
 ],
 "Create thin volume": [
  null,
  "Создать тонкий том"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Тонко резервируемые логические тома LVM2"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Создать новый тонко резервируемый логический том"
 ],
 "Not enough space": [
  null,
  "Недостаточно места"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Пул для «тонко» резервируемых логических томов LVM2"
 ],
 "Inactive logical volume": [
  null,
  "Неактивный логический том"
 ],
 "Activate": [
  null,
  "Включить"
 ],
 "Unsupported logical volume": [
  null,
  "Неподдерживаемый логический том"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ВНУТРЕННЯЯ ОШИБКА — этот логический том отмечен как активный и должен иметь соответствующее блочное устройство. Однако такого блочного устройства найти не удалось."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Установка $0 приведёт к удалению $1."
 ],
 "Installing packages": [
  null,
  "Установка пакетов"
 ],
 "Block device for filesystems": [
  null,
  "Устройство блочного ввода-вывода для файловых систем"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Пул для «тонко» резервируемых томов"
 ],
 "Linear": [
  null,
  "Линейный"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Том файловой системы VDO (сжатие/дедупликация)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Данные будут храниться на выбранных физических томах без какого-либо дополнительного резервирования или повышения производительности."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах поочерёдно для повышения производительности. Необходимо выбрать как минимум два тома."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Данные будут храниться в виде двух или более копий на выбранных физических томах для повышения надёжности. Необходимо выбрать как минимум два тома."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Данные будут храниться в виде двух копий, а также поочерёдно на выбранных физических томах, чтобы повысить надёжность и производительность. Необходимо выбрать не менее четырёх томов."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах таким образом, что один из них может быть потерян без ущерба для данных. Необходимо выбрать не менее трёх томов."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах таким образом, что один из них может быть потерян без ущерба для данных. Данные также хранятся поочерёдно для повышения производительности. Необходимо выбрать не менее трёх томов."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Данные будут храниться на выбранных физических томах, так что до двух из них могут быть потеряны одновременно без ущерба для данных. Данные также хранятся поочерёдно для повышения производительности. Необходимо выбрать не менее пяти томов."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Для выбранного макета необходимы все выбранные физические тома $0."
 ],
 "Create logical volume": [
  null,
  "Создание логического тома"
 ],
 "Purpose": [
  null,
  "Назначение"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Для создания устройств VDO будет установлен пакет $0."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 требуется чётное число физических томов"
 ],
 "Logical size": [
  null,
  "Логический размер"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Экономьте место, сжимая отдельные блоки по алгоритму LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Экономьте место, сохраняя блоки идентичных данных лишь один раз"
 ],
 "Creating VDO device": [
  null,
  "Создание устройства VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Данное подключение по NFS используется. Возможно только изменение его параметров."
 ],
 "NFS mount": [
  null,
  "Подключение по NFS"
 ],
 "New NFS mount": [
  null,
  "Новое подключение по NFS"
 ],
 "Server address": [
  null,
  "Адрес сервера"
 ],
 "Server cannot be empty.": [
  null,
  "Сервер не может быть пустым."
 ],
 "Path on server": [
  null,
  "Путь на сервере"
 ],
 "Path on server cannot be empty.": [
  null,
  "Путь на сервере не может быть пустым."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Путь на сервере должен начинаться с символа «/»."
 ],
 "Local mount point": [
  null,
  "Локальная точка подключения"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка подключения не может быть пуста."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Точка подключения должна начинаться с символа «/»."
 ],
 "Mount options": [
  null,
  "Параметры подключения"
 ],
 "Mount at boot": [
  null,
  "Подключение при загрузке"
 ],
 "Mount read only": [
  null,
  "Подключение только для чтения"
 ],
 "Custom mount options": [
  null,
  "Пользовательские параметры монтирования"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не удаётся отключить файловую систему"
 ],
 "Stop and unmount": [
  null,
  "Остановить и отключить"
 ],
 "Unable to remove mount": [
  null,
  "Не удаётся удалить подключение"
 ],
 "Stop and remove": [
  null,
  "Остановить и удалить"
 ],
 "(not mounted)": [
  null,
  "(не смонтировано)"
 ],
 "Start multipath": [
  null,
  "Запустить multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "В системе есть устройства, использующие несколько путей, но служба multipath не работает."
 ],
 "Show all $0 rows": [
  null,
  "Показать все строки ($0)"
 ],
 "Category": [
  null,
  "Категория"
 ],
 "more info": [
  null,
  "доп. сведения"
 ],
 "Encryption": [
  null,
  "Шифрование"
 ],
 "encrypted": [
  null,
  "зашифрованный"
 ],
 "Last modified: $0": [
  null,
  "Время последнего изменения: $0"
 ],
 "Stored passphrase": [
  null,
  "Сохранённая парольная фраза"
 ],
 "Encryption options": [
  null,
  "Параметры шифрования"
 ],
 "Encryption type": [
  null,
  "Тип шифрования"
 ],
 "Cleartext device": [
  null,
  "Устройство с открытым текстом"
 ],
 "yes": [
  null,
  "да"
 ],
 "Disk passphrase": [
  null,
  "Парольная фраза диска"
 ],
 "Passphrase cannot be empty": [
  null,
  "Парольная фраза не может быть пустой"
 ],
 "Unlocking disk": [
  null,
  "Снятие блокировки диска"
 ],
 "Checking for $0 package": [
  null,
  "Проверка наличия пакета $0"
 ],
 "The $0 package must be installed.": [
  null,
  "Требуется установить пакет $0."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Пакет $0 недоступен в репозиториях."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Ошибка при установке $0: PackageKit или dnf5daemon-server не установлены"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Неожиданная ошибка PackageManager при установке $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Проверка наличия поддержки NBDE в initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd должен быть создан повторно."
 ],
 "Regenerating initrd": [
  null,
  "Повторное создание initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Добавление rd.neednet=1 в командную строку ядра"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Добавление «$0» в параметры файловой системы"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Добавление «$0» в параметры шифрования"
 ],
 "Enabling $0": [
  null,
  "Включение $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Добавить шифрование диска с сетевой привязкой"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "В настоящее время система не поддерживает разблокировку корневой файловой системы с помощью сервера ключей Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "В настоящее время система не поддерживает разблокировку файловой системы с сервером ключей Tang во время загрузки."
 ],
 "These additional steps are necessary:": [
  null,
  "Необходимы дополнительные шаги:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для сохранения новой парольной фразы требуется снятие блокировки диска. Укажите действующую парольную фразу диска."
 ],
 "Fix NBDE support": [
  null,
  "Исправить поддержку NBDE"
 ],
 "Adding key": [
  null,
  "Добавление ключа"
 ],
 "Key source": [
  null,
  "Источник ключа"
 ],
 "Repeat passphrase": [
  null,
  "Подтверждение парольной фразы"
 ],
 "Passphrase": [
  null,
  "Парольная фраза"
 ],
 "Tang keyserver": [
  null,
  "Сервер криптографических ключей Tang"
 ],
 "New passphrase": [
  null,
  "Новая парольная фраза"
 ],
 "Passphrases do not match": [
  null,
  "Парольные фразы не совпадают"
 ],
 "Keyserver address": [
  null,
  "Адрес сервера криптографических ключей"
 ],
 "Change passphrase": [
  null,
  "Изменить парольную фразу"
 ],
 "Old passphrase": [
  null,
  "Старая парольная фраза"
 ],
 "Edit Tang keyserver": [
  null,
  "Изменение сервера криптографических ключей Tang"
 ],
 "Verify key": [
  null,
  "Проверка ключа"
 ],
 "Trust key": [
  null,
  "Ключ доверия"
 ],
 "Passphrase can not be empty": [
  null,
  "Парольная фраза не может быть пустой"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Удаление парольной фразы может помешать разблокировке $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Подтвердите удаление с помощью альтернативной кодовой фразы"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Удаление парольной фразы без подтверждения другой парольной фразой может привести к невозможности разблокировки или запрету управления ключами, если другие парольные фразы забыты или утеряны."
 ],
 "Passphrase from any other key slot": [
  null,
  "Парольная фраза из любого другого слота для ключа"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Удалить парольную фразу в слоте ключа $0?"
 ],
 "Remove $0?": [
  null,
  "Удалить $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Удаление может помешать разблокировке $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Удалить сервер криптографических ключей Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Удалить ключ в слоте $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Текущему пользователю не разрешено просматривать сведения о ключах."
 ],
 "No keys added": [
  null,
  "Нет добавленных ключей"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Для редактирования ключа необходим свободный слот"
 ],
 "The last key slot can not be removed": [
  null,
  "Последний слот для ключа не может быть удалён"
 ],
 "Keyserver": [
  null,
  "Сервер криптографических ключей"
 ],
 "Unknown type": [
  null,
  "Неизвестный тип"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Слоты для ключей с неизвестными типами нельзя изменить здесь"
 ],
 "Keys": [
  null,
  "Ключи"
 ],
 "$0 slot remains": [
  null,
  "Остался $0 слот",
  "Осталось $0 слота",
  "Осталось $0 слотов"
 ],
 "No available slots": [
  null,
  "Нет доступных слотов"
 ],
 "No free key slots": [
  null,
  "Нет свободных слотов для ключей"
 ],
 "Locked data": [
  null,
  "Заблокированные данные"
 ],
 "lock": [
  null,
  "блокировка"
 ],
 "Lock $0?": [
  null,
  "Заблокировать $0?"
 ],
 "Address cannot be empty": [
  null,
  "Адрес не может быть пустым"
 ],
 "Address is not a valid URL": [
  null,
  "Недопустимое значение URL-адреса"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Проверьте хэш ключа с помощью сервера Tang."
 ],
 "How to check": [
  null,
  "Как проверить"
 ],
 "In a terminal, run: ": [
  null,
  "В терминале введите команду: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успешно скопировано в буфер обмена!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Проверьте, совпадает ли хэш SHA-256 или SHA-1, полученный с помощью команды, с приведённым в этом окне."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Подтом BTRFS $0 из $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтирования не может быть пустой"
 ],
 "Mount point is already used for $0": [
  null,
  "Точка монтирования уже используется для $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Файловые системы уже смонтированы под этой точкой монтирования."
 ],
 "Please unmount them first.": [
  null,
  "Сначала размонтируйте их."
 ],
 "read only": [
  null,
  "только для чтения"
 ],
 "never mount at boot": [
  null,
  "никогда не монтировать при загрузке"
 ],
 "after network": [
  null,
  "после сети"
 ],
 "ignore failure": [
  null,
  "игнорировать ошибки"
 ],
 "stop boot on failure": [
  null,
  "прекратить загрузку при ошибке"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "У этой файловой системы нет назначенной точки монтирования."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У этой файловой системы нет постоянной точки монтирования."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файловая система не смонтирована."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Файловая система будет разблокирована и смонтирована при следующей загрузке. При этом может потребоваться ввод парольной фразы."
 ],
 "(no assigned mount point)": [
  null,
  "(нет назначенной точки монтирования)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но при следующей загрузке будет монтироваться на $1."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтировать автоматически на $0 при загрузке"
 ],
 "Mount on $0 now": [
  null,
  "Монтировать на $0 сейчас"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файловая система сейчас не смонтирована, но будет монтироваться при следующей загрузке."
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтировать автоматически при загрузке"
 ],
 "Mount now": [
  null,
  "Монтировать сейчас"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована, после следующей загрузки не будет смонтирована."
 ],
 "Mount also automatically on boot": [
  null,
  "Монтировать также автоматически при загрузке"
 ],
 "Unmount now": [
  null,
  "Размонтировать сейчас"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но не будет монтироваться при следующей загрузке."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Настройка файловой системы обеспечивает автоматическое монтирование при загрузке, но к моменту монтирования контейнер шифрования не будет разблокирован."
 ],
 "Unlock automatically on boot": [
  null,
  "Автоматически снимать блокировку при загрузке"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Неправильное монтирование файловой системы"
 ],
 "$0 filesystem": [
  null,
  "Файловая система $0"
 ],
 "Filesystem name": [
  null,
  "Имя файловой системы"
 ],
 "Filesystem is locked": [
  null,
  "Файловая система заблокирована"
 ],
 "Mounts before services start": [
  null,
  "Монтируется перед запуском служб"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Подходит для критических монтирований, таких как /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Загрузка завершится с ошибкой, если файловая система не монтируется, что препятствует удалённому доступу"
 ],
 "Mounts in parallel with services": [
  null,
  "Монтируется параллельно со службами"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Загрузка всё равно завершится успешно, если файловая система не монтируется"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Монтируется параллельно со службами, но после того, как сеть станет доступной"
 ],
 "Does not mount during boot": [
  null,
  "Не монтировать при загрузке"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Полезно для монтирований, которые являются необязательными или требуют взаимодействия (например, парольные фразы)"
 ],
 "At boot": [
  null,
  "При загрузке"
 ],
 "Mount before services start": [
  null,
  "Монтировать перед запуском служб"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Монтировать без ожидания, игнорировать ошибки"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Монтировать после того, как сеть станет доступной, игнорировать ошибки"
 ],
 "Do not mount": [
  null,
  "Не монтировать"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Это устройство не может быть использовано для целей установки."
 ],
 "Mount filesystem": [
  null,
  "Монтировать файловую систему"
 ],
 "Unmount filesystem $0": [
  null,
  "Размонтирование файловой системы $0"
 ],
 "Mount configuration": [
  null,
  "Настройки монтирования"
 ],
 "Swap": [
  null,
  "Подкачка"
 ],
 "Used": [
  null,
  "Использовано"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Снятие блокировки зашифрованного пула Stratis"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Введите парольную фразу для пула этих блоковых устройств:"
 ],
 "Stratis pool": [
  null,
  "Пул Stratis"
 ],
 "stopped": [
  null,
  "остановлено"
 ],
 "Block devices": [
  null,
  "Блочные устройства"
 ],
 "No block devices found": [
  null,
  "Блочные устройства не найдены"
 ],
 "Stratis block devices": [
  null,
  "Блочные устройства Stratis"
 ],
 "Stratis block device": [
  null,
  "Блочное устройство Stratis"
 ],
 "data": [
  null,
  "данные"
 ],
 "cache": [
  null,
  "кэш"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Укажите существующий пароль для пула."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Если ключевой сервер по адресу $0 недоступен, вы можете ввести существующий пароль."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Если ни один из серверов ключей недоступен, вы можете ввести существующий пароль."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Если ни один из неинтерактивных методов разблокировки не работает, вы можете ввести существующий пароль."
 ],
 "Pool passphrase": [
  null,
  "Парольная фраза пула"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Сервер ключей по адресу $0 должен быть доступен."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Должен быть доступен хотя бы один сервер ключей."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "По крайней мере один из неинтерактивных методов разблокировки должен работать."
 ],
 "Create filesystem": [
  null,
  "Создать файловую систему"
 ],
 "Stratis filesystem": [
  null,
  "Файловая система Stratis"
 ],
 "Set initial size": [
  null,
  "Уст. начальный размер"
 ],
 "Limit size": [
  null,
  "Ограничение размера"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Удаление пула Stratis приведёт к уничтожению всех содержащихся в нём данных."
 ],
 "Rename Stratis pool": [
  null,
  "Переименование пула Stratis"
 ],
 "Add block devices": [
  null,
  "Добавить блочные устройства"
 ],
 "Tier": [
  null,
  "Уровень"
 ],
 "Data": [
  null,
  "Данные"
 ],
 "Cache": [
  null,
  "Кэш"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Для добавления блочных устройств необходимо разблокировать пул."
 ],
 "Encrypted Stratis pool": [
  null,
  "Зашифрованный пул Stratis"
 ],
 "Delete pool": [
  null,
  "Удалить пул"
 ],
 "Encryption tokens": [
  null,
  "Токены шифрования"
 ],
 "Stratis filesystems": [
  null,
  "Файловые системы Stratis"
 ],
 "Create new filesystem": [
  null,
  "Создать новую файловую систему"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Этот пул не использует всё пространство на своих блочных устройствах."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Некоторые блочные устройства этого пула увеличились в размере после его создания. Пул можно безопасно увеличить, чтобы использовать вновь освободившееся пространство."
 ],
 "Grow the pool to take all space": [
  null,
  "Расширить пул на всё пространство"
 ],
 "This pool is in a degraded state.": [
  null,
  "Этот пул находится в состоянии сбоя."
 ],
 "No filesystems": [
  null,
  "Нет файловых систем"
 ],
 "Stratis filesystems pool": [
  null,
  "Пул файловых систем Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Эта парольная фраза является единственным способом разблокировать пул и не может быть удалена."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Этот сервер ключей является единственным способом разблокировать пул и не может быть удалён."
 ],
 "Add passphrase": [
  null,
  "Добавить парольную фразу"
 ],
 "Add keyserver": [
  null,
  "Добавить сервер ключей"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis «$0»"
 ],
 "Last token can not be removed": [
  null,
  "Последний токен не может быть удалён"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Больше нет места для паролей или серверов ключей."
 ],
 "Confirm": [
  null,
  "Подтверждение"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Для добавления парольной фразы необходимо разблокировать пул."
 ],
 "Remove passphrase?": [
  null,
  "Удалить парольную фразу?"
 ],
 "Add Tang keyserver": [
  null,
  "Добавить сервер ключей Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Добавление сервера ключей требует разблокировки пула."
 ],
 "Remove Clevis token?": [
  null,
  "Удалить токен Clevis?"
 ],
 "Metadata format": [
  null,
  "Формат метаданных"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Пулы с форматом метаданных V1 ограничены максимум одним паролем и максимум одним сервером ключей."
 ],
 "Overprovisioning": [
  null,
  "Избыточное обеспечение"
 ],
 "Allow overprovisioning": [
  null,
  "Разрешить избыточное выделение ресурсов"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Размеры виртуальной файловой системы превышают размер пула. Перераспределение ресурсов нельзя отключить."
 ],
 "Allocated": [
  null,
  "Выделено"
 ],
 "Name can not be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "A pool with this name exists already.": [
  null,
  "Пул с таким названием уже существует."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Файловая система с таким именем уже существует в этом пуле."
 ],
 "Create Stratis pool": [
  null,
  "Создать пул Stratis"
 ],
 "No block devices are available.": [
  null,
  "Нет доступных блочных устройств."
 ],
 "At least one block device is needed.": [
  null,
  "Необходимо хотя бы одно блочное устройство."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Шифрование данных с помощью парольной фразы"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Шифрование данных с помощью сервера ключей Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Создать снимок файловой системы $0"
 ],
 "Create snapshot and mount": [
  null,
  "Создать снимок и смонтировать"
 ],
 "Create snapshot only": [
  null,
  "Создать только снимок"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Удаление файловой системы приведёт к уничтожению всех содержащихся в ней данных."
 ],
 "Snapshot": [
  null,
  "Моментальный снимок"
 ],
 "Rename filesystem": [
  null,
  "Переименование файловой системы"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Уст. ограничение размера вирт. файловой системы"
 ],
 "Limit virtual filesystem size": [
  null,
  "Ограничение размера вирт. файловой системы"
 ],
 "Virtual size limit": [
  null,
  "Ограничение виртуального размера"
 ],
 "Virtual size": [
  null,
  "Виртуальный размер"
 ],
 "Create RAID device": [
  null,
  "Создание RAID-устройства"
 ],
 "RAID level": [
  null,
  "Уровень RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (чередование)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (зеркалирование)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (выделенная чётность)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (распределённая чётность)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (двойная распределённая чётность)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (чередование зеркалирования)"
 ],
 "Chunk size": [
  null,
  "Размер блока"
 ],
 "4 KiB": [
  null,
  "4 КиБ"
 ],
 "8 KiB": [
  null,
  "8 КиБ"
 ],
 "16 KiB": [
  null,
  "16 КиБ"
 ],
 "32 KiB": [
  null,
  "32 КиБ"
 ],
 "64 KiB": [
  null,
  "64 КиБ"
 ],
 "128 KiB": [
  null,
  "128 КиБ"
 ],
 "512 KiB": [
  null,
  "512 КиБ"
 ],
 "1 MiB": [
  null,
  "1 МиБ"
 ],
 "2 MiB": [
  null,
  "2 МиБ"
 ],
 "At least $0 disk is needed.": [
  null,
  "Необходим хотя бы $0 диск.",
  "Необходимо хотя бы $0 диска.",
  "Необходимо хотя бы $0 дисков."
 ],
 "MDRAID disk": [
  null,
  "Диск MDRAID"
 ],
 "In sync": [
  null,
  "Синхронизировано"
 ],
 "Spare": [
  null,
  "В запасе"
 ],
 "Recovering": [
  null,
  "Восстановливается"
 ],
 "Write-mostly": [
  null,
  "В основном запись"
 ],
 "Blocked": [
  null,
  "Заблокировано"
 ],
 "Unknown ($0)": [
  null,
  "Неизвестно ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Устройство MDRAID должно быть запущено"
 ],
 "MDRAID device is recovering": [
  null,
  "Восстановление устройства MDRAID"
 ],
 "Need a spare disk": [
  null,
  "Требуется резервный диск"
 ],
 "Last disk can not be removed": [
  null,
  "Последний диск не может быть удалён"
 ],
 "MDRAID device": [
  null,
  "Устройство MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Подтвердите остановку $0"
 ],
 "Stop device": [
  null,
  "Остановить устройство"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Удаление приведёт к уничтожению всех данных на устройстве MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Устройство MDRAID должно быть запущено"
 ],
 "Add disk": [
  null,
  "Добавить диск"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "дисков: $0"
 ],
 "$0 chunk size": [
  null,
  "размер блока: $0"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Устройство MDRAID находится в состоянии сбоя"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Это устройство MDRAID не имеет растрового изображения с указанием намерений записи. Такое растровое изображение может значительно сократить время синхронизации."
 ],
 "Add a bitmap": [
  null,
  "Добавить битовую карту"
 ],
 "No disks found": [
  null,
  "Диски не найдены"
 ],
 "MDRAID disks": [
  null,
  "Диски MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Удаление приведёт к уничтожению всех данных на устройстве VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Создание данного устройства VDO не завершилось, поэтому устройство не может быть использовано."
 ],
 "Remove device": [
  null,
  "Удалить устройство"
 ],
 "Grow to take all space": [
  null,
  "Расширить на всё пространство"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Данное устройство VDO не полностью использует резервное устройство."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Используется только $0 из $1."
 ],
 "Grow logical size of $0": [
  null,
  "Расширение логического размера $0"
 ],
 "Physical": [
  null,
  "Физический размер"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 данных + $1 служебной информации использовано из $2 ($3)"
 ],
 "Logical": [
  null,
  "Логический размер"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 использовано из $1 ($2 сэкономлено)"
 ],
 "Index memory": [
  null,
  "Память индексов"
 ],
 "SMART self-test of $target": [
  null,
  "SMART самопроверка $target"
 ],
 "Ejecting $target": [
  null,
  "Извлечение $target"
 ],
 "Unlocking $target": [
  null,
  "Снятие блокировки $target"
 ],
 "Locking $target": [
  null,
  "Блокировка $target"
 ],
 "Modifying $target": [
  null,
  "Изменение $target"
 ],
 "Resizing $target": [
  null,
  "Изменение размера $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запуск области подкачки $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Остановка области подкачки $target"
 ],
 "Mounting $target": [
  null,
  "Подключение $target"
 ],
 "Unmounting $target": [
  null,
  "Отключение $target"
 ],
 "Checking $target": [
  null,
  "Проверка $target"
 ],
 "Repairing $target": [
  null,
  "Восстановление $target"
 ],
 "Erasing $target": [
  null,
  "Стирание $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Создание файловой системы на $target"
 ],
 "Setting up loop device $target": [
  null,
  "Настройка петлевого устройства $target"
 ],
 "Deleting $target": [
  null,
  "Удаление $target"
 ],
 "Creating partition $target": [
  null,
  "Создание раздела $target"
 ],
 "Cleaning up for $target": [
  null,
  "Очистка данных $target"
 ],
 "Securely erasing $target": [
  null,
  "Надёжное стирание $target"
 ],
 "Very securely erasing $target": [
  null,
  "Крайне надёжное стирание $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Остановка устройства MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Запуск устройства MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Маркировка $target как неисправного"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Удаление $target с устройства MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Создание устройства MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Проверка устройства MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Проверка и восстановление устройства MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Восстановление устройства MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Синхронизация устройства MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Включение $target"
 ],
 "Deactivating $target": [
  null,
  "Отключение $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Создание моментального снимка $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Создание группы томов LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Удаление группы томов LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Добавление физического тома в $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Удаление физического тома из $target"
 ],
 "Emptying $target": [
  null,
  "Очистка $target"
 ],
 "Creating logical volume $target": [
  null,
  "Создание логического тома $target"
 ],
 "Renaming $target": [
  null,
  "Переименование $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Операция «$operation» над $target"
 ],
 "unknown target": [
  null,
  "неизвестная цель"
 ],
 "Jobs": [
  null,
  "Задания"
 ],
 "Reading": [
  null,
  "Чтение"
 ],
 "Writing": [
  null,
  "Запись"
 ],
 "Install Stratis support": [
  null,
  "Установка поддержки Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Для создания пулов Stratis должен быть установлен пакет $0."
 ],
 "Install NFS support": [
  null,
  "Установка поддержки NFS"
 ],
 "Create MDRAID device": [
  null,
  "Создать устройство MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Создать группу томов LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Изменить имя инициатора iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Добавить портал iSCSI"
 ],
 "Local storage": [
  null,
  "Локальное хранилище"
 ],
 "Networked storage": [
  null,
  "Сетевое хранилище"
 ],
 "Create storage device": [
  null,
  "Создать устройство хранения данных"
 ],
 "No storage found": [
  null,
  "Хранилище не найдено"
 ],
 "Server address cannot be empty.": [
  null,
  "Адрес сервера не может быть пустым."
 ],
 "Next": [
  null,
  "Далее"
 ],
 "Invalid username or password": [
  null,
  "Недопустимое имя пользователя или пароль"
 ],
 "Unknown host name": [
  null,
  "Неизвестное имя узла"
 ],
 "Unable to reach server": [
  null,
  "Не удаётся связаться с сервером"
 ],
 "Available targets on $0": [
  null,
  "Доступные цели на $0"
 ],
 "Authentication required": [
  null,
  "Необходима проверка подлинности"
 ],
 "iSCSI portal": [
  null,
  "Портал iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Накопители iSCSI"
 ],
 "No drives found": [
  null,
  "Накопители не найдены"
 ],
 "Target": [
  null,
  "Цель"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Устройства резервирования VDO не могут быть уменьшены"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Блочные устройства Stratis не могут быть уменьшены"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Нераспознанные данные не могут быть уменьшены здесь."
 ],
 "Unlock before resizing": [
  null,
  "Разблокировать перед изменением размера"
 ],
 "$0 can not be resized here": [
  null,
  "Здесь невозможно изменить размер $0"
 ],
 "$0 can not be resized": [
  null,
  "Размер $0 невозможно изменить"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 невозможно уменьшить"
 ],
 "$0 can not be made larger": [
  null,
  "$0 невозможно увеличить"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Здесь невозможно изменить размер физических томов"
 ],
 "Swap can not be resized here": [
  null,
  "Здесь невозможно изменить размер резервной памяти"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Нераспознанные данные не могут быть уменьшены здесь"
 ],
 "Activate before resizing": [
  null,
  "Активировать перед изменением размера"
 ],
 "Grow logical volume": [
  null,
  "Расширение логического тома"
 ],
 "Grow partition": [
  null,
  "Расширение раздела"
 ],
 "grow": [
  null,
  "расширить"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Необходимо выбрать физических томов: $0"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для изменения размера зашифрованной файловой системы необходимо разблокировать диск. Введите парольную фразу текущего диска."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Необходимо выбрать физических томов: ровно $0, по одному для каждой полосы логического тома."
 ],
 "Shrink logical volume": [
  null,
  "Сжатие логического тома"
 ],
 "shrink": [
  null,
  "сжать"
 ],
 "Unformatted data": [
  null,
  "Неформатированные данные"
 ],
 "Block device": [
  null,
  "Блочное устройство"
 ],
 "Device number": [
  null,
  "Номер устройства"
 ],
 "Create partition on $0": [
  null,
  "Создание раздела на $0"
 ],
 "Format $0": [
  null,
  "Форматирование $0"
 ],
 "No filesystem": [
  null,
  "Нет файловой системы"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "No encryption": [
  null,
  "Без шифрования"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Повторное использование существующего шифрования ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Повторное использование существующего шифрования"
 ],
 "format": [
  null,
  "форматировать"
 ],
 "Format and mount": [
  null,
  "Форматировать и монтировать"
 ],
 "Format only": [
  null,
  "Только форматировать"
 ],
 "Format": [
  null,
  "Форматировать"
 ],
 "Create and start": [
  null,
  "Создать и запустить"
 ],
 "Format and start": [
  null,
  "Форматировать и запустить"
 ],
 "Store passphrase": [
  null,
  "Хранить парольную фразу"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Перед форматированием диск необходимо разблокировать. Введите соответствующую парольную фразу."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "При форматировании устройства хранения все данные на нём удаляются."
 ],
 "Unrecognized data": [
  null,
  "Нераспознанные данные"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Управление хранилищем недоступно в данной системе."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Этот инструмент настраивает систему для записи аварийных дампов ядра на диск. Он поддерживает следующие цели дампа: «local» (диск), «ssh» и «nfs»."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтов"
 ]
});
