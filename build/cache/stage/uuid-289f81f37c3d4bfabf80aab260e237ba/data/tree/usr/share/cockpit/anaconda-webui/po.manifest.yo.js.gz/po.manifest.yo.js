cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "yo",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
