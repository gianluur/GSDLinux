cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "it",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "Password": [
  null,
  "Password"
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Copy": [
  null,
  "copia"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Unlock": [
  null,
  "Sblocca"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Remove": [
  null,
  "Rimuovi"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "Set": [
  null,
  "Imposta"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "Trust and add host": [
  null,
  "Considera attendibile e aggiungi host"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale corrisponde, fai clic su \"Affida e aggiungi host\". Altrimenti non connetterti e contatta il tuo amministratore."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'impronta digitale risultante può essere condivisa tramite metodi pubblici, inclusa l'email. Se chiedi a qualcun altro di eseguire la verifica per te, può inviare i risultati utilizzando qualsiasi metodo."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta."
 ],
 "Verify fingerprint": [
  null,
  "Verifica impronta digitale"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Esegui questo comando su una rete affidabile o fisicamente sul computer remoto:"
 ],
 "The fingerprint should match:": [
  null,
  "L'impronta digitale dovrebbe corrispondere a:"
 ],
 "The password can not be empty": [
  null,
  "La password non può essere vuota"
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossibile accedere a $0. L'host non accetta l'accesso con password né alcuna delle tue chiavi SSH."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta da password e l'host non consente l'accesso con password. Fornire la password della chiave $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La chiave SSH per accedere a $0 è protetta. Puoi accedere con la tua password di accesso o fornendo la password della chiave $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La chiave SSH $0 di $1 su $2 verrà aggiunta al file $3 di $4 su $5."
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La chiave SSH $0 sarà resa disponibile per il resto della sessione e sarà utilizzabile anche per l'accesso ad altri host."
 ],
 "Permission denied": [
  null,
  "Permesso negato"
 ],
 "Clear input value": [
  null,
  "Cancella il valore immesso"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Shut down": [
  null,
  "Arresta"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticamente utilizzando server NTP addizionali"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Change": [
  null,
  "Modifica"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Create $0": [
  null,
  "Crea $0"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nessun metodo per ottenere l'accesso amministrativo è disponibile (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Switch to administrative access": [
  null,
  "Passa all'accesso amministrativo"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema diventando amministratore"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Impossibile abilitare firewalld$0"
 ],
 "Visit firewall": [
  null,
  "Vai al firewall"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "Add $0": [
  null,
  "Aggiungi $0"
 ],
 "less than a minute ago": [
  null,
  "meno di un minuto fa"
 ],
 "in less than a minute": [
  null,
  "in meno di un minuto"
 ],
 "Password is too weak": [
  null,
  "La password è troppo debole"
 ],
 "Excellent password": [
  null,
  "Password eccellente"
 ],
 "Password is not acceptable": [
  null,
  "La password non è accettabile"
 ],
 "Strong password": [
  null,
  "Password complessa"
 ],
 "Acceptable password": [
  null,
  "Password accettabile"
 ],
 "Weak password": [
  null,
  "Password debole"
 ],
 "Show password": [
  null,
  "Mostra la password"
 ],
 "Hide password": [
  null,
  "Nascondi la password"
 ],
 "password quality": [
  null,
  "qualità password"
 ],
 "Show confirmation password": [
  null,
  "Mostra password di conferma"
 ],
 "Hide confirmation password": [
  null,
  "Nascondi la password di conferma"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Removing $0": [
  null,
  "Rimozione di $0"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Unknown host: $0": [
  null,
  "Host sconosciuto: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossibile accedere a $0 usando l'autenticazione con chiave SSH. Fornire la password."
 ],
 "SSH key login": [
  null,
  "Accesso tramite chiave SSH"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "Row expansion": [
  null,
  "Espansione delle righe"
 ],
 "Row select": [
  null,
  "Seleziona riga"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Incolla errore"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Error during initialization": [
  null,
  "Si e verificato un errore durante l'inizializzazione"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Home": [
  null,
  "Home"
 ],
 "Downloads": [
  null,
  "Scaricati"
 ],
 "Not a directory": [
  null,
  "Non è una cartella"
 ],
 "All files": [
  null,
  "Tutti i file"
 ],
 "Recent": [
  null,
  "Recenti"
 ],
 "No recent directories": [
  null,
  "Nessuna cartella recente"
 ],
 "No recent files": [
  null,
  "Nessun file recente"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "File chooser actions": [
  null,
  "Azioni per scegliere il file"
 ],
 "Open in file browser": [
  null,
  "Aprire in un esploratore dei file"
 ],
 "Hide hidden files": [
  null,
  "Nascondi file nascosti"
 ],
 "Show hidden files": [
  null,
  "Mostra file nascosti"
 ],
 "Filesystem": [
  null,
  "File system"
 ],
 "Clear filters": [
  null,
  "Cancella filtri"
 ],
 "Directory is empty": [
  null,
  "La cartella è vuota"
 ],
 "Directory has no sub-directories": [
  null,
  "La cartella non ha sotto-cartelle"
 ],
 "This directory contains only hidden files": [
  null,
  "Questa cartella contiene soltanto file nascosti"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "Folder": [
  null,
  "Cartella"
 ],
 "File": [
  null,
  "File"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Automation script": [
  null,
  "Script di automazione"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Crea un nuovo file di attività con questo contenuto."
 ],
 "Ansible roles documentation": [
  null,
  "Documentazione sui ruoli Ansible"
 ],
 "Shell script": [
  null,
  "Script di shell"
 ],
 "No system modifications": [
  null,
  "Nessuna modifica di sistema"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L'utente che ha effettuato l'accesso non è autorizzato a visualizzare le modifiche di sistema"
 ],
 "Loading system modifications...": [
  null,
  "Caricamento modifiche del sistema..."
 ],
 "View automation script": [
  null,
  "Visualizza script di automazione"
 ],
 "Occurrences": [
  null,
  "Occorrenze"
 ],
 "View all logs": [
  null,
  "Visualizza tutti i log"
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Select an option": [
  null,
  "Seleziona un'opzione"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 terminato con codice $1"
 ],
 "$0 failed": [
  null,
  "$0 fallito"
 ],
 "Your session has been terminated.": [
  null,
  "La tua sessione e' terminata."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "La sessione è scaduta. Effettua di nuovo il login."
 ],
 "Not permitted to perform this action.": [
  null,
  "Non è consentito eseguire questa azione."
 ],
 "Login failed": [
  null,
  "Login fallito"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Il server ha rifiutato di autenticarsi utilizzando qualsiasi metodo supportato."
 ],
 "Untrusted host": [
  null,
  "Host non fidato"
 ],
 "Host key is incorrect": [
  null,
  "La chiave host non è corretta"
 ],
 "Internal error": [
  null,
  "Errore interno"
 ],
 "Connection has timed out.": [
  null,
  "Il collegamento è scaduto."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit non è installato sul sistema."
 ],
 "Cannot forward login credentials": [
  null,
  "Impossibile inoltrare le credenziali di accesso"
 ],
 "Server has closed the connection.": [
  null,
  "Il server ha chiuso la connessione."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit non è compatibile con il software del sistema."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit non ha potuto contattare l'host inserito."
 ],
 "Too much data": [
  null,
  "Troppi dati"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "View logs": [
  null,
  "Visualizza log"
 ],
 "Dismiss": [
  null,
  "Scarta"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "Not found": [
  null,
  "Non trovato"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "Not running": [
  null,
  "Non in esecuzione"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "User": [
  null,
  "Utente"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Stop": [
  null,
  "Arresta"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Confirm deletion of $0": [
  null,
  "Conferma la cancellazione di $0"
 ],
 "Username": [
  null,
  "Nome utente"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Started": [
  null,
  "Avviato"
 ],
 "Delete group": [
  null,
  "Elimina gruppo"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Lock": [
  null,
  "Blocca"
 ],
 "Use $0": [
  null,
  "Usa $0"
 ],
 "Service": [
  null,
  "Servizio"
 ],
 "Disconnect": [
  null,
  "Disconnetti"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco inesistente",
  "$0 dischi inesistenti"
 ],
 "Location": [
  null,
  "Posizione"
 ],
 "Compression": [
  null,
  "Compressione"
 ],
 "Storage logs": [
  null,
  "Log archiviazione"
 ],
 "Name cannot be empty.": [
  null,
  "Il nome non può essere vuoto."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Il nome non può essere più lungo di 127 caratteri."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Il nome non può contenere il carattere '$0''."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Il nome non può contenere spazi bianchi."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Il nome non può essere più lungo di $0 caratteri"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Il nome non può essere più lungo di $0 byte"
 ],
 "$name (from $host)": [
  null,
  "$name (da $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool per volumi logici thin"
 ],
 "Thin logical volume": [
  null,
  "Volume logico thin"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logico (snapshot)"
 ],
 "Logical volume": [
  null,
  "Volume logico"
 ],
 "MDRAID device $0": [
  null,
  "Dispositivo MDRAID $0"
 ],
 "LVM2 volume group $0": [
  null,
  "Gruppo di volumi LVM2 $0"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logico criptato di $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partizione criptata di $0"
 ],
 "Logical volume of $0": [
  null,
  "Volume logico di $0"
 ],
 "Partition of $0": [
  null,
  "Partizione di $0"
 ],
 "Encrypted $0": [
  null,
  "$0 crittografato"
 ],
 "unpartitioned space on $0": [
  null,
  "spazio non partizionato su $0"
 ],
 "unmount": [
  null,
  "smonta"
 ],
 "mount": [
  null,
  "mount"
 ],
 "remove from btrfs volume": [
  null,
  "rimuovi da volume btrfs"
 ],
 "stop": [
  null,
  "ferma"
 ],
 "remove from MDRAID": [
  null,
  "rimuovi da MDRAID"
 ],
 "remove from LVM2": [
  null,
  "rimuovere da LVM2"
 ],
 "btrfs device": [
  null,
  "dispositivo btrfs"
 ],
 "btrfs volume": [
  null,
  "volume btrfs"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Il nome non può contenere più di 255 caratteri."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Il nome non può contenere il carattere \"/\"."
 ],
 "Create and mount": [
  null,
  "Crea e monta"
 ],
 "Create only": [
  null,
  "crea soltanto"
 ],
 "Create subvolume": [
  null,
  "Crea sottovolume"
 ],
 "Mount Point": [
  null,
  "Punto di montaggio"
 ],
 "delete": [
  null,
  "elimina"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Eliminare definitivamente il sottovolume $0?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "L'eliminazione cancella tutti i dati presenti su questo sottovolume e su tutti i suoi elementi figlio."
 ],
 "Edit mount point": [
  null,
  "Modifica punto di montaggio"
 ],
 "Unmount": [
  null,
  "Smonta"
 ],
 "Mount": [
  null,
  "Monta"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "È necessario montare almeno un sottovolume"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "L'ultimo sottovolume montato non può essere eliminato"
 ],
 "btrfs subvolume": [
  null,
  "sottovolume btrfs"
 ],
 "Snapshot origin": [
  null,
  "Origine dell'istantanea"
 ],
 "Mount point": [
  null,
  "Punto di montaggio"
 ],
 "No subvolumes": [
  null,
  "Nessun sottovolume"
 ],
 "btrfs subvolumes": [
  null,
  "sottovolumi btrfs"
 ],
 "Snapshots": [
  null,
  "Istantanee"
 ],
 "No snapshots found": [
  null,
  "Nessuno snapshot trovato"
 ],
 "snapshot": [
  null,
  "snapshot"
 ],
 "$0 is in use": [
  null,
  "$0 è in uso"
 ],
 "Permanently delete $0?": [
  null,
  "Eliminare definitivamente $0?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "L'eliminazione cancella tutti i dati su un volume btrfs."
 ],
 "Delete filesystem": [
  null,
  "Elimina filesystem"
 ],
 "Change label": [
  null,
  "Cambia etichetta"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Il filesystem è montato in sola lettura"
 ],
 "Label": [
  null,
  "Etichetta"
 ],
 "Capacity": [
  null,
  "Capacità"
 ],
 "btrfs devices": [
  null,
  "dispositivi btrfs"
 ],
 "No devices found": [
  null,
  "Nessun dispositivo trovato"
 ],
 "btrfs filesystem": [
  null,
  "filesystem btrfs"
 ],
 "Successful": [
  null,
  "Riuscito"
 ],
 "Aborted": [
  null,
  "Interrotto"
 ],
 "In progress": [
  null,
  "In corso"
 ],
 "Interrupted": [
  null,
  "Interrotto"
 ],
 "Did not complete": [
  null,
  "Non completato"
 ],
 "Failed (Unknown)": [
  null,
  "Fallito (Sconosciuto)"
 ],
 "Failed (Electrical)": [
  null,
  "Fallito (Elettrico)"
 ],
 "Failed (Servo)": [
  null,
  "Fallito (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Fallito (Lettura)"
 ],
 "Failed (Damaged)": [
  null,
  "Fallito (Danneggiato)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Interrotto da un reset a livello di controller"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Interrotto a causa della rimozione di uno spazio dei nomi dall'inventario degli spazi dei nomi"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Interrotto a causa dell'elaborazione di un comando Format NVM"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Si è verificato un errore fatale durante l'operazione di autotest"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Completato con un segmento fallito e il segmento fallito non è noto"
 ],
 "Completed with one or more failed segments": [
  null,
  "Completato con uno o più segmenti falliti"
 ],
 "Aborted for unknown reason": [
  null,
  "Interrotto per motivo sconosciuto"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Interrotto a causa di un'operazione di sanificazione"
 ],
 "Spare capacity is below the threshold": [
  null,
  "La capacità di riserva è inferiore alla soglia"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatura al di fuori delle soglie raccomandate"
 ],
 "Degraded": [
  null,
  "Degradato"
 ],
 "All media is in read-only mode": [
  null,
  "Tutti i supporti sono in modalità di sola lettura"
 ],
 "Volatile memory backup failed": [
  null,
  "Backup memoria volatile fallito"
 ],
 "Persistent memory has become read-only": [
  null,
  "La memoria persistente è diventata di sola lettura"
 ],
 "Run short test": [
  null,
  "Esegui test breve"
 ],
 "Run extended test": [
  null,
  "Esegui test esteso"
 ],
 "Abort test": [
  null,
  "Interrompi test"
 ],
 "Disk is failing": [
  null,
  "Disco non funzionante"
 ],
 "Disk is OK": [
  null,
  "Il disco è OK"
 ],
 "Assessment": [
  null,
  "Valutazione"
 ],
 "Power on hours": [
  null,
  "Ore di accensione"
 ],
 "$0 hours": [
  null,
  "$0 ore"
 ],
 "Self-test status": [
  null,
  "Stato autotest"
 ],
 "Number of bad sectors": [
  null,
  "Numero di settori danneggiati"
 ],
 "Attributes failing": [
  null,
  "Attributi con errori"
 ],
 "Media drive": [
  null,
  "Unità multimediale"
 ],
 "Solid State Drive": [
  null,
  "Unità a stato solido"
 ],
 "Hard Disk Drive": [
  null,
  "Unità disco rigido"
 ],
 "iSCSI Drive": [
  null,
  "Unità iSCSI"
 ],
 "Drive": [
  null,
  "Unità"
 ],
 "Device health (SMART)": [
  null,
  "Stato del dispositivo (SMART)"
 ],
 "Firmware version": [
  null,
  "Versione del firmware"
 ],
 "Serial number": [
  null,
  "Numero di serie"
 ],
 "World wide name": [
  null,
  "World Wide Name"
 ],
 "No media inserted": [
  null,
  "Nessun supporto inserito"
 ],
 "Device file": [
  null,
  "File dispositivo"
 ],
 "Multipathed devices": [
  null,
  "Dispositivi con percorsi multipli"
 ],
 "Free space": [
  null,
  "Spazio libero"
 ],
 "Create partition": [
  null,
  "Crea partizione"
 ],
 "Extended partition": [
  null,
  "Partizione estesa"
 ],
 "$0 partitions": [
  null,
  "$0 partizioni"
 ],
 "Partitions": [
  null,
  "Partizioni"
 ],
 "No partitions found": [
  null,
  "Nessuna partizione trovata"
 ],
 "Unexpected partitions": [
  null,
  "Partizioni inaspettate"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Le partizioni non sono supportate su questo dispositivo a blocchi. Se viene utilizzato come disco per una macchina virtuale, le partizioni devono essere gestite dal sistema operativo all'interno della macchina virtuale."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "L'eliminazione di una partizione cancellerà tutti i dati in essa contenuti."
 ],
 "No free space after this partition": [
  null,
  "Nessuno spazio libero dopo questa partizione"
 ],
 "EFI system partition": [
  null,
  "Partizione di sistema EFI"
 ],
 "BIOS boot partition": [
  null,
  "Partizione di avvio del BIOS"
 ],
 "Partition": [
  null,
  "Partizione"
 ],
 "Shrink": [
  null,
  "Riduci"
 ],
 "Grow": [
  null,
  "Espandi"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partizione di avvio PReP di PowerPC"
 ],
 "Linux swap space": [
  null,
  "Spazio di scambio Linux"
 ],
 "Linux filesystem data": [
  null,
  "Dati del file system Linux"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partizione del gestore del volume logico"
 ],
 "Custom": [
  null,
  "Personalizzato"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Il tipo deve contenere esattamente due caratteri esadecimali (da 0 a 9, da A a F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Il tipo può contenere solo i caratteri da 0 a 9, da A a F e \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Il tipo deve avere la forma NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Imposta il tipo di partizione su $0"
 ],
 "Custom type": [
  null,
  "Tipo personalizzato"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "La modifica del tipo di partizione potrebbe impedire l'avvio del sistema."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Questa partizione non è completamente utilizzata dal suo contenuto."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "La dimensione della partizione è $0. La dimensione del contenuto è $1."
 ],
 "Shrink partition": [
  null,
  "Riduci la partizione"
 ],
 "Grow content": [
  null,
  "Espandi Contenuto"
 ],
 "initialize": [
  null,
  "inizializza"
 ],
 "Initialize disk $0": [
  null,
  "Inizializza il disco $0"
 ],
 "Partitioning": [
  null,
  "Partizionamento"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibile con tutti i sistemi e dispositivi (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatibile con sistemi moderni e dischi rigidi > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Nessun partizionamento"
 ],
 "Overwrite": [
  null,
  "Sovrascrivere"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Sovrascrivere i dati esistenti con zeri (lento)"
 ],
 "Initialize": [
  null,
  "Inizializzare"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "L'inizializzazione cancella tutti i dati su un disco."
 ],
 "Device is read-only": [
  null,
  "Il dispositivo è in sola lettura"
 ],
 "Create partition table": [
  null,
  "Crea tabella delle partizioni"
 ],
 "Size must be a number": [
  null,
  "La dimensione deve essere un numero"
 ],
 "Size cannot be zero": [
  null,
  "La dimensione non può essere zero"
 ],
 "Size cannot be negative": [
  null,
  "La dimensione non può essere negativa"
 ],
 "Size is too large": [
  null,
  "La dimensione è troppo grande"
 ],
 "Size must be at least $0": [
  null,
  "La dimensione deve essere almeno $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume fisico del gruppo di volumi LVM2"
 ],
 "member of MDRAID device": [
  null,
  "membro del dispositivo MDRAID"
 ],
 "backing device for VDO device": [
  null,
  "dispositivo di supporto per dispositivo VDO"
 ],
 "member of Stratis pool": [
  null,
  "membro del pool Stratis"
 ],
 "Filesystem outside the target": [
  null,
  "File system esterno alla destinazione"
 ],
 "device of btrfs volume": [
  null,
  "dispositivo del volume btrfs"
 ],
 "This device is currently in use.": [
  null,
  "Questo dispositivo è attualmente in uso."
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Use": [
  null,
  "Usa"
 ],
 "Services using the location": [
  null,
  "Servizi che utilizzano la posizione"
 ],
 "Processes using the location": [
  null,
  "Elabora utilizzando la posizione"
 ],
 "Currently in use": [
  null,
  "Attualmente in uso"
 ],
 "(Not part of target)": [
  null,
  "(Non parte del target)"
 ],
 "These changes will be made:": [
  null,
  "Verranno apportate le seguenti modifiche:"
 ],
 "Action": [
  null,
  "Azione"
 ],
 "Important data might be deleted:": [
  null,
  "I dati importanti potrebbero essere eliminati:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "I processi e i servizi correlati verranno interrotti forzatamente."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "I processi correlati verranno interrotti forzatamente."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "I servizi correlati verranno interrotti forzatamente."
 ],
 "Checking filesystem usage": [
  null,
  "Controllo dell'utilizzo del file system"
 ],
 "$0 used, $1 total": [
  null,
  "$0 usati, $1 totale"
 ],
 "Device contains unrecognized data": [
  null,
  "Il dispositivo contiene dati non riconosciuti"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Il dispositivo crittografato bloccato potrebbe contenere dati"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confermo di voler perdere questi dati per sempre"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Il punto di montaggio $0 è utilizzato da questi processi:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Il punto di montaggio $0 è utilizzato da questi servizi:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "I processi e i servizi elencati verranno interrotti forzatamente."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "I processi elencati verranno interrotti forzatamente."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "I servizi elencati verranno interrotti forzatamente."
 ],
 "Sorry": [
  null,
  "Scusa"
 ],
 "Usage of $0": [
  null,
  "Utilizzo di $0"
 ],
 "LVM2 VDO pool": [
  null,
  "Pool VDO LVM2"
 ],
 "Data used": [
  null,
  "Dati utilizzati"
 ],
 "Metadata used": [
  null,
  "Metadati utilizzati"
 ],
 "Use compression": [
  null,
  "Usa compressione"
 ],
 "Deduplication": [
  null,
  "Deduplicazione"
 ],
 "Use deduplication": [
  null,
  "Usa deduplicazione"
 ],
 "Rename volume group": [
  null,
  "Rinomina gruppo di volumi"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Questo gruppo di volumi contiene il file system root. Rinominarlo potrebbe richiedere ulteriori modifiche alla configurazione del bootloader o alla riga di comando del kernel."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "L'eliminazione cancella tutti i dati su un gruppo di volumi."
 ],
 "Create snapshot": [
  null,
  "Crea snapshot"
 ],
 "Add disks": [
  null,
  "Aggiungi dischi"
 ],
 "Disks": [
  null,
  "Dischi"
 ],
 "No disks are available.": [
  null,
  "Nessun disco disponibile."
 ],
 "At least one disk is needed.": [
  null,
  "È necessario almeno un disco."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Al gruppo di volumi mancano volumi fisici"
 ],
 "No free space": [
  null,
  "Nessuno spazio libero disponibile"
 ],
 "LVM2 volume group": [
  null,
  "Gruppo di volumi LVM2"
 ],
 "Add physical volume": [
  null,
  "Aggiungi volume fisico"
 ],
 "LVM2 logical volumes": [
  null,
  "Volumi logici LVM2"
 ],
 "Create new logical volume": [
  null,
  "Crea un nuovo volume logico"
 ],
 "No logical volumes": [
  null,
  "Nessun volume logico"
 ],
 "Remove missing physical volumes?": [
  null,
  "Rimuovere i volumi fisici mancanti?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "A questo gruppo di volumi mancano alcuni volumi fisici."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Un gruppo di volumi con volumi fisici mancanti non può essere rinominato."
 ],
 "Physical volumes": [
  null,
  "Volumi fisici"
 ],
 "No physical volumes found": [
  null,
  "Nessun volume fisico trovato"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumi fisici LVM2"
 ],
 "Rename logical volume": [
  null,
  "Rinomina il volume logico"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Eliminare definitivamente il volume logico $0/$1?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "L'eliminazione di un volume logico cancellerà tutti i dati in esso contenuti."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Impossibile riparare il volume logico $0"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Non c'è abbastanza spazio disponibile che possa essere utilizzato per una riparazione. Sono necessari almeno $0 sui volumi fisici non già utilizzati per questo volume logico."
 ],
 "An additional $0 must be selected": [
  null,
  "È necessario selezionare $0 aggiuntivi"
 ],
 "Repair logical volume $0": [
  null,
  "Riparare il volume logico $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Selezionare i volumi fisici da utilizzare per riparare il volume logico. Sono necessari almeno $0."
 ],
 "Physical Volumes": [
  null,
  "Volumi Fisici"
 ],
 "Repair": [
  null,
  "Ripara"
 ],
 "deactivate": [
  null,
  "disattiva"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Disattivare il volume logico $0/$1?"
 ],
 "Deactivate": [
  null,
  "Disattiva"
 ],
 "Not enough space to grow": [
  null,
  "Spazio insufficiente per crescere"
 ],
 "LVM2 logical volume": [
  null,
  "Volume logico LVM2"
 ],
 "Striped (RAID 0)": [
  null,
  "Striping (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Con mirroring (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Striping e mirroring (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Parità dedicata (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Parità distribuita (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Doppia parità distribuita (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Questo volume logico non è completamente utilizzato dal suo contenuto."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "La dimensione del volume è $0. La dimensione del contenuto è $1."
 ],
 "Shrink volume": [
  null,
  "Riduci il Volume"
 ],
 "Layout": [
  null,
  "Layout"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Questo volume logico ha perso alcuni dei suoi volumi fisici e non può più essere utilizzato. È necessario eliminarlo e crearne uno nuovo per sostituirlo."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Questo volume logico ha perso alcuni dei suoi volumi fisici ma non ha ancora perso dati. Dovresti ripararlo per ripristinare la sua ridondanza originale."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Questo volume logico ha perso alcuni dei suoi volumi fisici ma potrebbe non aver ancora perso dati. Potresti essere in grado di ripararlo."
 ],
 "Stripes": [
  null,
  "Stripe"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizzato"
 ],
 "Create volume group": [
  null,
  "Crea gruppo di volumi"
 ],
 "LVM2 physical volume": [
  null,
  "Volume fisico LVM2"
 ],
 "Last cannot be removed": [
  null,
  "L'ultimo non può essere rimosso"
 ],
 "Not enough free space": [
  null,
  "Spazio libero insufficiente"
 ],
 "Volume group": [
  null,
  "Gruppo di volumi"
 ],
 "Create thin volume": [
  null,
  "Crea volume thin"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volumi logici LVM2 con thin provisioning"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Crea un nuovo volume logico con thin provisioning"
 ],
 "Not enough space": [
  null,
  "Spazio insufficiente"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool per volumi logici LVM2 con thin provisioning"
 ],
 "Inactive logical volume": [
  null,
  "Volume logico inattivo"
 ],
 "Activate": [
  null,
  "Attiva"
 ],
 "Unsupported logical volume": [
  null,
  "Volume logico non supportato"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERRORE INTERNO: questo volume logico è contrassegnato come attivo e dovrebbe avere un dispositivo a blocchi associato. Tuttavia non è stato trovato alcun dispositivo a blocchi di questo tipo."
 ],
 "Installing $0 would remove $1.": [
  null,
  "L'installazione di $0 rimuoverebbe $1."
 ],
 "Installing packages": [
  null,
  "Installazione pacchetti"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo di blocco per i filesystem"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool per volumi con thin provisioning"
 ],
 "Linear": [
  null,
  "Lineare"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume del filesystem VDO (compressione/deduplicazione)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati senza alcuna ridondanza aggiuntiva o miglioramenti delle prestazioni."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno due volumi."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "I dati verranno archiviati in due o più copie sui volumi fisici selezionati, per migliorare l'affidabilità. È necessario selezionare almeno due volumi."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "I dati verranno archiviati in due copie e anche in modo alternato sui volumi fisici selezionati, per migliorare sia l'affidabilità che le prestazioni. È necessario selezionare almeno quattro volumi."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che uno di essi possa andare perso senza influire sui dati. È necessario selezionare almeno tre volumi."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che uno di essi possa andare perso senza influire sui dati. I dati vengono inoltre archiviati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno tre volumi."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "I dati verranno archiviati sui volumi fisici selezionati in modo che fino a due di essi possano andare persi contemporaneamente senza influire sui dati. I dati vengono inoltre archiviati in modo alternato per migliorare le prestazioni. È necessario selezionare almeno cinque volumi."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Tutti i volumi fisici selezionati da $0 sono necessari per il layout scelto."
 ],
 "Create logical volume": [
  null,
  "Crea un volume logico"
 ],
 "Purpose": [
  null,
  "Scopo"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Verrà installato il pacchetto $0 per creare dispositivi VDO."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 necessita di un numero pari di volumi fisici"
 ],
 "Logical size": [
  null,
  "Dimensione logica"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Risparmia spazio comprimendo i singoli blocchi con LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Risparmia spazio memorizzando blocchi di dati identici una sola volta"
 ],
 "Creating VDO device": [
  null,
  "Creazione del dispositivo VDO"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Questo supporto NFS è in uso e solo le sue opzioni possono essere modificate."
 ],
 "NFS mount": [
  null,
  "Montaggio NFS"
 ],
 "New NFS mount": [
  null,
  "Nuovo supporto NFS"
 ],
 "Server address": [
  null,
  "Indirizzo del server"
 ],
 "Server cannot be empty.": [
  null,
  "Il server non può essere vuoto."
 ],
 "Path on server": [
  null,
  "Percorso su server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Il percorso sul server non può essere vuoto."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Il percorso sul server deve iniziare con \"/\"."
 ],
 "Local mount point": [
  null,
  "Punto di montaggio locale"
 ],
 "Mount point cannot be empty.": [
  null,
  "Il punto di montaggio non può essere vuoto."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Il punto di montaggio deve iniziare con \"/\"."
 ],
 "Mount options": [
  null,
  "Opzioni di montaggio"
 ],
 "Mount at boot": [
  null,
  "Montaggio all'avvio"
 ],
 "Mount read only": [
  null,
  "Monta in sola lettura"
 ],
 "Custom mount options": [
  null,
  "Opzioni di montaggio personalizzate"
 ],
 "Unable to unmount filesystem": [
  null,
  "Impossibile smontare il file system"
 ],
 "Stop and unmount": [
  null,
  "Ferma e smonta"
 ],
 "Unable to remove mount": [
  null,
  "Impossibile rimuovere il supporto"
 ],
 "Stop and remove": [
  null,
  "Ferma e rimuovi"
 ],
 "(not mounted)": [
  null,
  "(non montato)"
 ],
 "Start multipath": [
  null,
  "Avvia Multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Ci sono dispositivi con percorsi multipli sul sistema, ma il servizio multipath non è in esecuzione."
 ],
 "Show all $0 rows": [
  null,
  "Mostra tutte le righe $0"
 ],
 "Category": [
  null,
  "Categoria"
 ],
 "more info": [
  null,
  "maggiori info"
 ],
 "Encryption": [
  null,
  "Cifratura"
 ],
 "encrypted": [
  null,
  "crittografato"
 ],
 "Last modified: $0": [
  null,
  "Ultima modifica: $0"
 ],
 "Stored passphrase": [
  null,
  "Frase di accesso memorizzata"
 ],
 "Encryption options": [
  null,
  "Opzioni di cifratura"
 ],
 "Encryption type": [
  null,
  "Tipo di crittografia"
 ],
 "Cleartext device": [
  null,
  "Dispositivo con testo in chiaro"
 ],
 "yes": [
  null,
  "si"
 ],
 "Disk passphrase": [
  null,
  "Frase di accesso del disco"
 ],
 "Passphrase cannot be empty": [
  null,
  "La frase di accesso non può essere vuota"
 ],
 "Unlocking disk": [
  null,
  "Sblocco disco"
 ],
 "Checking for $0 package": [
  null,
  "Verifica per $0 pacchetto"
 ],
 "The $0 package must be installed.": [
  null,
  "Il pacchetto $0 deve essere installato."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Il pacchetto $0 non è disponibile da nessun repository."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Errore durante l'installazione di $0: PackageKit o dnf5daemon-server non sono installati"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Errore imprevisto di PackageManager durante l'installazione di $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Verifica del supporto NBDE in initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "L'initrd deve essere rigenerato."
 ],
 "Regenerating initrd": [
  null,
  "rigenerazione del initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Aggiunta di rd.neednet=1 alla riga di comando del kernel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Aggiunta di \"$0\" alle opzioni del filesystem"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Aggiungi \"$0\" alle Opzioni di cifratura"
 ],
 "Enabling $0": [
  null,
  "Abilitazione di $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Aggiungi la crittografia dei dischi legati alla rete"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Attualmente il sistema non supporta lo sblocco del filesystem root con un keyserver Tang."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Attualmente il sistema non supporta lo sblocco di un filesystem con un keyserver Tang durante l'avvio."
 ],
 "These additional steps are necessary:": [
  null,
  "Questi passaggi aggiuntivi sono necessari:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Per salvare una nuova frase di accesso è necessario sbloccare il disco. Fornire una frase di accesso attuale del disco."
 ],
 "Fix NBDE support": [
  null,
  "Fix supporto NBDE"
 ],
 "Adding key": [
  null,
  "Aggiungo la chiave"
 ],
 "Key source": [
  null,
  "Fonte chiave"
 ],
 "Repeat passphrase": [
  null,
  "Ripeti la frase di accesso"
 ],
 "Passphrase": [
  null,
  "Frase di accesso"
 ],
 "Tang keyserver": [
  null,
  "Keyserver Tang"
 ],
 "New passphrase": [
  null,
  "Nuova frase di accesso"
 ],
 "Passphrases do not match": [
  null,
  "Le frasi di accesso non corrispondono"
 ],
 "Keyserver address": [
  null,
  "Indirizzo Key server"
 ],
 "Change passphrase": [
  null,
  "Cambiare la frase di accesso"
 ],
 "Old passphrase": [
  null,
  "Vecchia frase di accesso"
 ],
 "Edit Tang keyserver": [
  null,
  "Modifica Tang keyserver"
 ],
 "Verify key": [
  null,
  "Verifica la chiave"
 ],
 "Trust key": [
  null,
  "Chiave fidata"
 ],
 "Passphrase can not be empty": [
  null,
  "La frase di accesso non può essere vuota"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "La rimozione della frase di accesso può impedire lo sblocco $0."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Conferma la rimozione con una passphrase alternativa"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "La rimozione di una passphrase senza la conferma di un'altra passphrase può impedire lo sblocco o la gestione delle chiavi, se altre passphrase vengono dimenticate o perse."
 ],
 "Passphrase from any other key slot": [
  null,
  "Passphrase da qualsiasi altro slot per chiavi"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Rimuovere la frase di accesso in slot $0?"
 ],
 "Remove $0?": [
  null,
  "Rimuovere $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "La rimozione potrebbe impedire lo sblocco di $0."
 ],
 "Remove Tang keyserver?": [
  null,
  "Rimuovere keyserver Tang?"
 ],
 "Remove key in slot $0?": [
  null,
  "Rimuovere la chiave nello slot $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "L'utente attualmente connesso non è autorizzato a vedere le informazioni sulle chiavi."
 ],
 "No keys added": [
  null,
  "Nessuna chiave aggiunta"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "La modifica di una chiave richiede uno slot libero"
 ],
 "The last key slot can not be removed": [
  null,
  "L'ultimo slot per chiavi non può essere rimosso"
 ],
 "Keyserver": [
  null,
  "Key server"
 ],
 "Unknown type": [
  null,
  "Tipo sconosciuto"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Gli slot per chiavi con tipi sconosciuti non possono essere modificati qui"
 ],
 "Keys": [
  null,
  "Chiavi"
 ],
 "$0 slot remains": [
  null,
  "$0 slot disponibile",
  "$0 slot disponibili"
 ],
 "No available slots": [
  null,
  "Non ci sono slot disponibili"
 ],
 "No free key slots": [
  null,
  "Nessuno slot libero per le chiavi"
 ],
 "Locked data": [
  null,
  "Dati bloccati"
 ],
 "lock": [
  null,
  "blocca"
 ],
 "Lock $0?": [
  null,
  "Bloccare $0?"
 ],
 "Address cannot be empty": [
  null,
  "L'indirizzo non può essere vuoto"
 ],
 "Address is not a valid URL": [
  null,
  "L'indirizzo non è un URL valido"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Controlla l'hash della chiave con il server Tang."
 ],
 "How to check": [
  null,
  "Come controllare"
 ],
 "In a terminal, run: ": [
  null,
  "Nel terminale, esegui: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiato correttamente negli appunti!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Controlla che l'hash SHA-256 o SHA-1 del comando corrisponda a questa finestra di dialogo."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "sottovolume btrfs $0 di $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Il punto di montaggio non può essere vuoto"
 ],
 "Mount point is already used for $0": [
  null,
  "Punto di montaggio già utilizzato per $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "I filesystem sono già montati sotto questo punto di montaggio."
 ],
 "Please unmount them first.": [
  null,
  "Per favore smontali prima."
 ],
 "read only": [
  null,
  "sola lettura"
 ],
 "never mount at boot": [
  null,
  "non montare mai all'avvio"
 ],
 "after network": [
  null,
  "dopo la rete"
 ],
 "ignore failure": [
  null,
  "ignora errore"
 ],
 "stop boot on failure": [
  null,
  "interrompi avvio in caso di errore"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Al filesystem non è assegnato alcun punto di montaggio."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Il file system non ha un punto di montaggio permanente."
 ],
 "The filesystem is not mounted.": [
  null,
  "Il file system non è montato."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Il filesystem verrà sbloccato e montato all'avvio successivo. Ciò potrebbe richiedere l'immissione di una passphrase."
 ],
 "(no assigned mount point)": [
  null,
  "(nessun punto di montaggio assegnato)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Il file system è attualmente montato su $0 ma verrà montato su $1 al prossimo avvio."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Monta automaticamente su $0 all'avvio"
 ],
 "Mount on $0 now": [
  null,
  "Monta ora su $0"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Il file system non è attualmente montato ma verrà montato al prossimo avvio."
 ],
 "Do not mount automatically on boot": [
  null,
  "Non montare automaticamente all'avvio"
 ],
 "Mount now": [
  null,
  "Monta ora"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Il file system è attualmente montato ma non verrà montato al prossimo avvio."
 ],
 "Mount also automatically on boot": [
  null,
  "Monta anche automaticamente all'avvio"
 ],
 "Unmount now": [
  null,
  "Smonta adesso"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Il file system è attualmente montato su $0 ma non verrà montato dopo il prossimo avvio."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Il file system è configurato per essere montato automaticamente all'avvio, ma il suo container di crittografia non sarà sbloccato in quel momento."
 ],
 "Unlock automatically on boot": [
  null,
  "Sblocca automaticamente all'avvio"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montaggio del filesystem incoerente"
 ],
 "$0 filesystem": [
  null,
  "File system $0"
 ],
 "Filesystem name": [
  null,
  "Nome del file system"
 ],
 "Filesystem is locked": [
  null,
  "Il filesystem è bloccato"
 ],
 "Mounts before services start": [
  null,
  "Monta prima dell'avvio dei servizi"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "È appropriato per i montaggi critici, come ad esempio /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "L'avvio fallisce se il filesystem non viene montato, impedendo l'accesso remoto"
 ],
 "Mounts in parallel with services": [
  null,
  "Monta durante l'avvio dei servizi"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "L'avvio riesce comunque quando il filesystem non viene montato"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monta in parallelo con i servizi, ma dopo che la rete è disponibile"
 ],
 "Does not mount during boot": [
  null,
  "Non montare durante il boot"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Utile per i mount che sono opzionali o che necessitano di interazione (come le passphrase)"
 ],
 "At boot": [
  null,
  "all'avvio"
 ],
 "Mount before services start": [
  null,
  "Monta prima dell'avvio dei servizi"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monta senza aspettare, ignora il fallimento"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monta dopo che la rete diventa disponibile, ignora il fallimento"
 ],
 "Do not mount": [
  null,
  "Non montare"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Questo dispositivo non può essere utilizzato per la destinazione dell'installazione."
 ],
 "Mount filesystem": [
  null,
  "Monta Filesystem"
 ],
 "Unmount filesystem $0": [
  null,
  "Smonta filesystem $0"
 ],
 "Mount configuration": [
  null,
  "Configurazione di montaggio"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Usato"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Sblocca pool Stratis crittografato"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Fornisci la passphrase per il pool su questi dispositivi a blocchi:"
 ],
 "Stratis pool": [
  null,
  "Pool Stratis"
 ],
 "stopped": [
  null,
  "fermato"
 ],
 "Block devices": [
  null,
  "Dispositivi a blocchi"
 ],
 "No block devices found": [
  null,
  "Nessun dispositivo a blocchi trovato"
 ],
 "Stratis block devices": [
  null,
  "Dispositivi a blocchi Stratis"
 ],
 "Stratis block device": [
  null,
  "Dispositivo a blocchi Stratis"
 ],
 "data": [
  null,
  "dati"
 ],
 "cache": [
  null,
  "cache"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Fornire una passphrase del pool esistente."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Se il server delle chiavi in $0 non è raggiungibile, è possibile fornire una passphrase esistente."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Se nessuno dei server delle chiavi è raggiungibile, è possibile fornire una passphrase esistente."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Se nessuno dei metodi di sblocco non interattivi funziona, puoi fornire una passphrase esistente."
 ],
 "Pool passphrase": [
  null,
  "Passphrase del pool"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Il server delle chiavi a $0 deve essere raggiungibile."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Deve essere raggiungibile almeno un server delle chiavi."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Almeno uno dei metodi di sblocco non interattivi deve funzionare."
 ],
 "Create filesystem": [
  null,
  "Crea filesystem"
 ],
 "Stratis filesystem": [
  null,
  "Livelli del file system"
 ],
 "Set initial size": [
  null,
  "Imposta la dimensione iniziale"
 ],
 "Limit size": [
  null,
  "Limita dimensione"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "L'eliminazione di un pool Stratis cancellerà tutti i dati in esso contenuti."
 ],
 "Rename Stratis pool": [
  null,
  "Rinomina il pool Stratis"
 ],
 "Add block devices": [
  null,
  "Aggiungi dispositivi a blocchi"
 ],
 "Tier": [
  null,
  "Livello"
 ],
 "Data": [
  null,
  "Dati"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Per aggiungere dispositivi a blocchi è necessario sbloccare il pool."
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool Stratis crittografato"
 ],
 "Delete pool": [
  null,
  "Elimina pool"
 ],
 "Encryption tokens": [
  null,
  "Token di crittografia"
 ],
 "Stratis filesystems": [
  null,
  "filesystem Stratis"
 ],
 "Create new filesystem": [
  null,
  "Crea nuovo filesystem"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Questo pool non utilizza tutto lo spazio sui suoi dispositivi a blocchi."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Alcuni dispositivi a blocchi di questo pool sono aumentati di dimensioni dopo la creazione del pool. La piscina può essere ampliata in tutta sicurezza per utilizzare lo spazio appena disponibile."
 ],
 "Grow the pool to take all space": [
  null,
  "Fai crescere il pool per occupare tutto lo spazio"
 ],
 "This pool is in a degraded state.": [
  null,
  "Questo pool è in stato degradato."
 ],
 "No filesystems": [
  null,
  "Nessun file system"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool di filesystem Stratis"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Questa passphrase è l'unico modo per sbloccare il pool e non può essere rimossa."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Questo keyserver è l'unico modo per sbloccare il pool e non può essere rimosso."
 ],
 "Add passphrase": [
  null,
  "Aggiungi la passphrase"
 ],
 "Add keyserver": [
  null,
  "Aggiungi il server delle chiavi"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "L'ultimo token non può essere rimosso"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Non c'è più spazio per passphrase o keyserver."
 ],
 "Confirm": [
  null,
  "Conferma"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Per aggiungere una passphrase è necessario sbloccare il pool."
 ],
 "Remove passphrase?": [
  null,
  "Rimuovere la passphrase?"
 ],
 "Add Tang keyserver": [
  null,
  "Aggiungi il server delle chiavi Tang"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Per aggiungere un server delle chiavi è necessario sbloccare il pool."
 ],
 "Remove Clevis token?": [
  null,
  "Rimuovere il token Clevis?"
 ],
 "Metadata format": [
  null,
  "Formato dei metadati"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "I pool con formato metadati V1 sono limitati a un massimo di una passphrase e a un massimo di un keyserver."
 ],
 "Overprovisioning": [
  null,
  "Provisioning eccessivo"
 ],
 "Allow overprovisioning": [
  null,
  "Consenti provisioning eccessivo"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Le dimensioni virtuali dei filesystem sono maggiori del pool. L'overprovisioning non può essere disabilitato."
 ],
 "Allocated": [
  null,
  "Assegnato"
 ],
 "Name can not be empty.": [
  null,
  "Il nome non può essere vuoto."
 ],
 "A pool with this name exists already.": [
  null,
  "Esiste già un pool con questo nome."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un filesystem con questo nome esiste già in questo pool."
 ],
 "Create Stratis pool": [
  null,
  "Crea un pool Stratis"
 ],
 "No block devices are available.": [
  null,
  "Non sono disponibili dispositivi a blocchi."
 ],
 "At least one block device is needed.": [
  null,
  "È necessario almeno un dispositivo a blocchi."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Crittografare i dati con una passphrase"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Crittografa i dati con un keyserver Tang"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Crea uno snapshot del filesystem $0"
 ],
 "Create snapshot and mount": [
  null,
  "Crea snapshot e monta"
 ],
 "Create snapshot only": [
  null,
  "Crea soltanto lo snapshot"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "L'eliminazione di un filesystem cancellerà tutti i dati in esso contenuti."
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Rename filesystem": [
  null,
  "Rinominare file system"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Imposta il limite della dimensione del filesystem virtuale"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limita la dimensione del filesystem virtuale"
 ],
 "Virtual size limit": [
  null,
  "Limite dimensione virtuale"
 ],
 "Virtual size": [
  null,
  "Dimensione virtuale"
 ],
 "Create RAID device": [
  null,
  "Creare un dispositivo RAID"
 ],
 "RAID level": [
  null,
  "Livello RAID"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (mirror)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (parità dedicata)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (parità distribuita)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (doppia parità distribuita)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe di mirror)"
 ],
 "Chunk size": [
  null,
  "Dimensione chunk"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "È necessario almeno $0 disco.",
  "Sono necessari almeno $0 dischi."
 ],
 "MDRAID disk": [
  null,
  "Disco MDRAID"
 ],
 "In sync": [
  null,
  "In sincronizzazione"
 ],
 "Spare": [
  null,
  "Ricambio"
 ],
 "Recovering": [
  null,
  "Recupero"
 ],
 "Write-mostly": [
  null,
  "A prevalenza di scrittura"
 ],
 "Blocked": [
  null,
  "Bloccato"
 ],
 "Unknown ($0)": [
  null,
  "Sconosciuto ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Il dispositivo MDRAID deve essere in esecuzione"
 ],
 "MDRAID device is recovering": [
  null,
  "Il dispositivo MDRAID è in fase di ripristino"
 ],
 "Need a spare disk": [
  null,
  "Hai bisogno di un disco di riserva"
 ],
 "Last disk can not be removed": [
  null,
  "L'ultimo disco non può essere rimosso"
 ],
 "MDRAID device": [
  null,
  "Dispositivo MDRAID"
 ],
 "Confirm stopping of $0": [
  null,
  "Confermare l'arresto di $0"
 ],
 "Stop device": [
  null,
  "Ferma dispositivo"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "L'eliminazione cancella tutti i dati su un dispositivo MDRAID."
 ],
 "MDRAID device must be running": [
  null,
  "Il dispositivo MDRAID deve essere in esecuzione"
 ],
 "Add disk": [
  null,
  "Aggiungi disco"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 dischi"
 ],
 "$0 chunk size": [
  null,
  "$0 Dimensione del blocco"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Il dispositivo MDRAID è in stato degradato"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Questo dispositivo MDRAID non ha una bitmap write-intent. Tale bitmap può ridurre significativamente i tempi di sincronizzazione."
 ],
 "Add a bitmap": [
  null,
  "Aggiungi una bitmap"
 ],
 "No disks found": [
  null,
  "Nessun disco trovato"
 ],
 "MDRAID disks": [
  null,
  "Dischi MDRAID"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "L'eliminazione cancella tutti i dati su un dispositivo VDO."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "La creazione di questo dispositivo VDO non è terminata e il dispositivo non può essere utilizzato."
 ],
 "Remove device": [
  null,
  "Rimuovere il dispositivo"
 ],
 "Grow to take all space": [
  null,
  "Espandi per occupare tutto lo spazio"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Questo dispositivo VDO non utilizza tutti i suoi dispositivi di supporto."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Solo $0 di $1 sono utilizzati."
 ],
 "Grow logical size of $0": [
  null,
  "Espandi le dimensioni logiche di $0"
 ],
 "Physical": [
  null,
  "Fisico"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dati + $1 overhead utilizzato di $2 ($3)"
 ],
 "Logical": [
  null,
  "Logico"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usato di $1 ($2 salvato)"
 ],
 "Index memory": [
  null,
  "Memoria indice"
 ],
 "SMART self-test of $target": [
  null,
  "Autotest SMART di $target"
 ],
 "Ejecting $target": [
  null,
  "Espulsione $target"
 ],
 "Unlocking $target": [
  null,
  "Sbloccaggio $target"
 ],
 "Locking $target": [
  null,
  "Blocco $target"
 ],
 "Modifying $target": [
  null,
  "Modifica $target"
 ],
 "Resizing $target": [
  null,
  "Ridimensionamento $target"
 ],
 "Starting swapspace $target": [
  null,
  "Avvio dello spazio di swap $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Arresto dello spazio di swap $target"
 ],
 "Mounting $target": [
  null,
  "Monto $target"
 ],
 "Unmounting $target": [
  null,
  "Smontaggio $target"
 ],
 "Checking $target": [
  null,
  "Controllo $target"
 ],
 "Repairing $target": [
  null,
  "Riparazione $target"
 ],
 "Erasing $target": [
  null,
  "Cancellazione $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Creazione del filesystem su $target"
 ],
 "Setting up loop device $target": [
  null,
  "Impostazione del dispositivo di loop $target"
 ],
 "Deleting $target": [
  null,
  "Eliminazione $target"
 ],
 "Creating partition $target": [
  null,
  "Creazione della partizione $target"
 ],
 "Cleaning up for $target": [
  null,
  "Pulizia per $target"
 ],
 "Securely erasing $target": [
  null,
  "Cancellazione sicura di $target"
 ],
 "Very securely erasing $target": [
  null,
  "Cancellazione molto sicura di $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Arresto del dispositivo MDRAID $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Avvio del dispositivo MDRAID $target"
 ],
 "Marking $target as faulty": [
  null,
  "Marco $target come difettoso"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Rimozione di $target dal dispositivo MDRAID"
 ],
 "Creating MDRAID device $target": [
  null,
  "Creazione del dispositivo MDRAID $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Controllo del dispositivo MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Controllo e riparazione del dispositivo MDRAID $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Ripristino del dispositivo MDRAID $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Sincronizzazione del dispositivo MDRAID $target"
 ],
 "Activating $target": [
  null,
  "Attivazione $target"
 ],
 "Deactivating $target": [
  null,
  "Disattivazione $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Creazione di uno snapshot di $target"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Creazione di un gruppo di volumi LVM2 $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Eliminazione del gruppo di volumi LVM2 $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Aggiungo il volume fisico a $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Rimozione del volume fisico da $target"
 ],
 "Emptying $target": [
  null,
  "Svuotamento $target"
 ],
 "Creating logical volume $target": [
  null,
  "Creazione di un volume logico $target"
 ],
 "Renaming $target": [
  null,
  "Rinomino $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Operazione '$operation' su $target"
 ],
 "unknown target": [
  null,
  "destinazione sconosciuta"
 ],
 "Jobs": [
  null,
  "Lavori"
 ],
 "Reading": [
  null,
  "Lettura"
 ],
 "Writing": [
  null,
  "In scrittura"
 ],
 "Install Stratis support": [
  null,
  "Installa il supporto Stratis"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Per creare pool Stratis è necessario installare il pacchetto $0."
 ],
 "Install NFS support": [
  null,
  "Installa il supporto NFS"
 ],
 "Create MDRAID device": [
  null,
  "Crea il dispositivo MDRAID"
 ],
 "Create LVM2 volume group": [
  null,
  "Crea gruppo di volumi LVM2"
 ],
 "Change iSCSI initiator name": [
  null,
  "Cambia il nome dell'iniziatore iSCSI"
 ],
 "Add iSCSI portal": [
  null,
  "Aggiungi portale iSCSI"
 ],
 "Local storage": [
  null,
  "Archiviazione locale"
 ],
 "Networked storage": [
  null,
  "Archiviazione in rete"
 ],
 "Create storage device": [
  null,
  "Crea dispositivo di archiviazione"
 ],
 "No storage found": [
  null,
  "Nessun spazio di archiviazione trovato"
 ],
 "Server address cannot be empty.": [
  null,
  "L'indirizzo del server non può essere vuoto."
 ],
 "Next": [
  null,
  "Avanti"
 ],
 "Invalid username or password": [
  null,
  "Password o nome utente non valido"
 ],
 "Unknown host name": [
  null,
  "Nome host sconosciuto"
 ],
 "Unable to reach server": [
  null,
  "Impossibile raggiungere il server"
 ],
 "Available targets on $0": [
  null,
  "Target disponibili su $0"
 ],
 "Authentication required": [
  null,
  "Autenticazione necessaria"
 ],
 "iSCSI portal": [
  null,
  "portale iSCSI"
 ],
 "iSCSI drives": [
  null,
  "unità iSCSI"
 ],
 "No drives found": [
  null,
  "Nessuna unità trovata"
 ],
 "Target": [
  null,
  "Target"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "I dispositivi di supporto VDO non possono essere resi più piccoli"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Gli sviluppatori di blocchi Stratis non possono essere ridotti"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "I dati non riconosciuti non possono essere ridotti qui."
 ],
 "Unlock before resizing": [
  null,
  "Sbloccare prima di ridimensionare"
 ],
 "$0 can not be resized here": [
  null,
  "$0 non può essere ridimensionato qui"
 ],
 "$0 can not be resized": [
  null,
  "$0 non può essere ridimensionato"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 non può essere ridotto"
 ],
 "$0 can not be made larger": [
  null,
  "$0 non può essere aumentato"
 ],
 "Physical volumes can not be resized here": [
  null,
  "I volumi fisici non possono essere ridimensionati qui"
 ],
 "Swap can not be resized here": [
  null,
  "Lo Swap non può essere ridimensionato qui"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "I dati non riconosciuti non possono essere ridotti qui"
 ],
 "Activate before resizing": [
  null,
  "Attiva prima del ridimensionamento"
 ],
 "Grow logical volume": [
  null,
  "Espandi il volume logico"
 ],
 "Grow partition": [
  null,
  "Aumenta la partizione"
 ],
 "grow": [
  null,
  "Crescere"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "È necessario selezionare esattamente volumi fisici da $0"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Il ridimensionamento di un file system crittografato richiede lo sblocco del disco. Fornire la frase di accesso corrente del disco."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "È necessario selezionare esattamente volumi fisici da $0, uno per ogni stripe del volume logico."
 ],
 "Shrink logical volume": [
  null,
  "Restringi il volume logico"
 ],
 "shrink": [
  null,
  "riduci"
 ],
 "Unformatted data": [
  null,
  "Dati non formattati"
 ],
 "Block device": [
  null,
  "blocca il dispositivo"
 ],
 "Device number": [
  null,
  "Numero del dispositivo"
 ],
 "Create partition on $0": [
  null,
  "Crea partizione su $0"
 ],
 "Format $0": [
  null,
  "Formatta $0"
 ],
 "No filesystem": [
  null,
  "Nessun file system"
 ],
 "(recommended)": [
  null,
  "(consigliato)"
 ],
 "No encryption": [
  null,
  "Nessuna crittografia"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Riutilizza la crittografia esistente ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Riutilizza la crittografia esistente"
 ],
 "format": [
  null,
  "formatta"
 ],
 "Format and mount": [
  null,
  "Formatta e monta"
 ],
 "Format only": [
  null,
  "Formatta soltanto"
 ],
 "Format": [
  null,
  "Formatta"
 ],
 "Create and start": [
  null,
  "Crea e inizia"
 ],
 "Format and start": [
  null,
  "Formatta e avvia"
 ],
 "Store passphrase": [
  null,
  "Conserva la frase di accesso"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Il disco deve essere sbloccato prima della formattazione. Si prega di fornire una passphrase esistente."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "La formattazione cancellerà tutti i dati contenuti in un dispositivo di memoria."
 ],
 "Unrecognized data": [
  null,
  "Dati non riconosciuti"
 ],
 "Storage can not be managed on this system.": [
  null,
  "L'archiviazione non può essere gestita su questo sistema."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Web Console per server Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit è un gestore di server che rende facile amministrare i server Linux tramite un browser web. Cambiare tra il terminale e lo strumento web non è un problema. Un servizio avviato tramite Cockpit può essere interrotto tramite il terminale. Allo stesso modo, se si verifica un errore nel terminale, può essere visto nella sezione del registro di Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit è perfetto per i nuovi amministratori di sistema, consentendo loro di eseguire facilmente semplici operazioni come la gestione dell'archiviazione, l'ispezione del registro e l'avvio e l'arresto dei servizi. È possibile monitorare e amministrare più server allo stesso tempo. Basta aggiungerli con un solo clic e se ne prenderà subito cura."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Una volta installato Cockpit, abilitarlo con \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configurazione Cockpit del NetworkManager e del Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Questo strumento gestisce le reti, come i bond, i bridge, i team, le VLAN e i firewall utilizzando NetworkManager e Firewalld. NetworkManager è incompatibile con gli script systemd-networkd di Ubuntu e ifupdown di Debian."
 ],
 "Manage storage": [
  null,
  "Gestisci archiviazione"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Questo strumento gestisce lo storage locale, come i filesystem, i gruppi di volumi LVM2 e i mount NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Raccogliere e creare un pacchetto di dati diagnostici e di supporto"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Questo strumento genera un archivio di informazioni sulla configurazione e sulla diagnostica del sistema in esecuzione. L'archivio può essere conservato localmente o centralmente per scopi di registrazione o tracciamento oppure può essere inviato ai rappresentanti dell'assistenza tecnica, agli sviluppatori o agli amministratori di sistema per aiutarli nella ricerca di errori e nel debug."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configurazione e risoluzione dei problemi di Security Enhanced Linux"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Questo strumento configura i criteri SELinux e può aiutare a comprendere e risolvere le violazioni dei criteri."
 ],
 "Collect kernel crash dumps": [
  null,
  "Acquisisci i dump dei crash del kernel"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Questo strumento configura il sistema per scrivere i dump di crash del kernel. Supporta le destinazioni di dump \"locale\" (disco), \"ssh\" e \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Amministrazione con Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "E' necessario autenticarsi per eseguire azioni privilegiate con Cockpit Web Console"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
