cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "oc",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
