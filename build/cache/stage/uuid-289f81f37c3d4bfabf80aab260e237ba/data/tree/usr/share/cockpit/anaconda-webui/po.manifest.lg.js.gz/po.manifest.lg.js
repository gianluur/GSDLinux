cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "lg",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
