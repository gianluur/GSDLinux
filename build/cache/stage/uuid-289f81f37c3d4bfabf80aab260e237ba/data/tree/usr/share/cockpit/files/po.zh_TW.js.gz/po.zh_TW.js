cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Files"
 ],
 "Home": [
  null,
  "家"
 ],
 "Unable to create bookmark directory": [
  null,
  "無法建立書籤的存放目錄"
 ],
 "Unable to save bookmark file": [
  null,
  "無法儲存書籤的存放檔案"
 ],
 "Remove from bookmarks": [
  null,
  "從書籤移除"
 ],
 "Add to bookmarks": [
  null,
  "新增至書籤"
 ],
 "Bookmarks": [
  null,
  "書籤"
 ],
 "Filesystem": [
  null,
  "檔案系統"
 ],
 "Edit path": [
  null,
  "編輯路徑"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "A-Z": [
  null,
  "由 A 到 Z"
 ],
 "Z-A": [
  null,
  "由 Z 到 A"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Largest size": [
  null,
  "大小最大"
 ],
 "Smallest size": [
  null,
  "大小最小"
 ],
 "Modified": [
  null,
  "被修改"
 ],
 "First modified": [
  null,
  "初次修改於"
 ],
 "Last modified": [
  null,
  "最後修改於"
 ],
 "Owner": [
  null,
  "擁有者"
 ],
 "Owner ascending": [
  null,
  "擁有者遞增排序"
 ],
 "Owner descending": [
  null,
  "擁有者遞減排序"
 ],
 "Permissions": [
  null,
  "權限"
 ],
 "Most permissive": [
  null,
  "最寬鬆的權限"
 ],
 "Least permissive": [
  null,
  "最不寬鬆的權限"
 ],
 "Show keyboard shortcuts": [
  null,
  "顯示鍵盤快速鍵"
 ],
 "Filter directory": [
  null,
  "篩選目錄"
 ],
 "Display as a list": [
  null,
  "以清單顯示"
 ],
 "Display as a grid": [
  null,
  "以網格顯示"
 ],
 "Sort": [
  null,
  "排序"
 ],
 "Hide hidden items": [
  null,
  "不顯示隱藏的項目"
 ],
 "Show hidden items": [
  null,
  "顯示隱藏的項目"
 ],
 "$0 files": [
  null,
  "$0 個檔案"
 ],
 "Uploaded as $0, $1": [
  null,
  "以 $0 、 $1 上傳"
 ],
 "Replace file $0?": [
  null,
  "取代檔案 $0 ？"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "一個相同名稱的檔案已於 \"$0\" 存在。 若將其取代將覆寫其內容。"
 ],
 "New file": [
  null,
  "新的檔案"
 ],
 "Original file on server": [
  null,
  "伺服器上原有的檔案"
 ],
 "Apply this action to all conflicting files": [
  null,
  "套用此動作至所有發生衝突的檔案"
 ],
 "Replace": [
  null,
  "取代"
 ],
 "Keep original": [
  null,
  "保留原本的"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Upload error": [
  null,
  "上傳失敗"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "無法將上傳的檔案移動至目的地"
 ],
 "Cancelled": [
  null,
  "已取消"
 ],
 "Cancelled upload of $0": [
  null,
  "已取消上傳 $0"
 ],
 "File uploaded": [
  null,
  "檔案已上傳"
 ],
 "Files uploaded": [
  null,
  "多個檔案已上傳"
 ],
 "Change permissions": [
  null,
  "變更權限"
 ],
 "Uploads": [
  null,
  "上傳項目"
 ],
 "Cancel upload of $0": [
  null,
  "取消上傳 $0"
 ],
 "Upload $0% completed": [
  null,
  "上傳 $0% 完成"
 ],
 "Upload": [
  null,
  "上傳"
 ],
 "None": [
  null,
  "無"
 ],
 "Execute-only": [
  null,
  "只能執行"
 ],
 "Write-only": [
  null,
  "只能寫入"
 ],
 "Write and execute": [
  null,
  "寫入與執行"
 ],
 "Read-only": [
  null,
  "唯讀"
 ],
 "Read and execute": [
  null,
  "讀取與執行"
 ],
 "Read and write": [
  null,
  "讀取與寫入"
 ],
 "Read, write, and execute": [
  null,
  "讀取、寫入與執行"
 ],
 "Block device": [
  null,
  "區塊裝置"
 ],
 "Character device": [
  null,
  "字元裝置"
 ],
 "Directory": [
  null,
  "目錄"
 ],
 "Named pipe": [
  null,
  "Named pipe"
 ],
 "Symbolic link": [
  null,
  "符號連結"
 ],
 "Regular file": [
  null,
  "一般檔案"
 ],
 "Socket": [
  null,
  "Socket"
 ],
 "Name cannot be empty": [
  null,
  "名稱不能為空值"
 ],
 "Name too long": [
  null,
  "名稱太長"
 ],
 "Name cannot include a /": [
  null,
  "名稱不能包含 /"
 ],
 "Filename is the same as original name": [
  null,
  "檔案名稱與原本相同"
 ],
 "Directory with the same name exists": [
  null,
  "相同名稱的目錄已存在"
 ],
 "File exists": [
  null,
  "檔案已存在"
 ],
 "Pasting failed": [
  null,
  "貼上失敗"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "\"$0\" 已存在，將不會貼上以免遭覆寫。"
 ],
 "Paste": [
  null,
  "貼上"
 ],
 "Create directory": [
  null,
  "建立目錄"
 ],
 "Create file": [
  null,
  "建立檔案"
 ],
 "Edit permissions": [
  null,
  "編輯權限"
 ],
 "Open in terminal": [
  null,
  "於終端機開啟"
 ],
 "Open text file": [
  null,
  "開啟文字檔案"
 ],
 "Copy": [
  null,
  "複製"
 ],
 "Rename": [
  null,
  "重新命名"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Download": [
  null,
  "下載"
 ],
 "Create link": [
  null,
  "建立連結"
 ],
 "Drop files to upload": [
  null,
  "拖曳檔案以上傳"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "正在處理其他上傳作業，無法拖曳檔案至此"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Go up a directory": [
  null,
  "回上一層目錄"
 ],
 "Go back": [
  null,
  "返回"
 ],
 "Go forward": [
  null,
  "前進"
 ],
 "Activate selected item, enter directory": [
  null,
  "觸發所選擇的項目，進入目錄"
 ],
 "Rename selected file or directory": [
  null,
  "重新命名已選擇的檔案或目錄"
 ],
 "Create new directory": [
  null,
  "建立新目錄"
 ],
 "Copy selected file or directory": [
  null,
  "複製已選擇的檔案或目錄"
 ],
 "Paste file or directory": [
  null,
  "貼上檔案或目錄"
 ],
 "Select all": [
  null,
  "全選"
 ],
 "Close editor": [
  null,
  "關閉編輯器"
 ],
 "Keyboard shortcuts": [
  null,
  "鍵盤快速鍵"
 ],
 "Navigation": [
  null,
  "瀏覽"
 ],
 "Editing": [
  null,
  "正在編輯"
 ],
 "Editor": [
  null,
  "編輯器"
 ],
 "Force delete $0 items": [
  null,
  "強制刪除 $0 個項目"
 ],
 "Delete $0 items?": [
  null,
  "刪除 $0 個項目？"
 ],
 "Force delete file $0?": [
  null,
  "強制刪除檔案 $0 ？"
 ],
 "Delete file $0?": [
  null,
  "刪除檔案 $0 ？"
 ],
 "Force delete link $0?": [
  null,
  "強制刪除連結 $0 ？"
 ],
 "Delete link $0?": [
  null,
  "刪除連結 $0 ？"
 ],
 "Force delete directory $0?": [
  null,
  "強制刪除目錄 $0 ？"
 ],
 "Delete directory $0?": [
  null,
  "刪除目錄 $0 ？"
 ],
 "Force delete $0": [
  null,
  "強制刪除 $0"
 ],
 "Delete $0?": [
  null,
  "刪除 $0 ？"
 ],
 "No access": [
  null,
  "無存取權限"
 ],
 "Missing type": [
  null,
  "類型已遺失"
 ],
 "Collapse": [
  null,
  "收折"
 ],
 "Show all files": [
  null,
  "顯示所有檔案"
 ],
 "$0 permissions": [
  null,
  "$0 的權限"
 ],
 "Permissions for $0 files": [
  null,
  "變更 $0 個檔案的權限"
 ],
 "Ownership": [
  null,
  "所有權"
 ],
 "Group": [
  null,
  "群組"
 ],
 "Access": [
  null,
  "存取權限"
 ],
 "Owner access": [
  null,
  "擁有者存取權限"
 ],
 "Group access": [
  null,
  "群組存取權限"
 ],
 "Others access": [
  null,
  "其他人的存取權限"
 ],
 "Security context": [
  null,
  "安全性 context"
 ],
 "Set executable as program": [
  null,
  "設定為可執行的程式"
 ],
 "Change": [
  null,
  "變更"
 ],
 "Change permissions for enclosed files": [
  null,
  "變更其中檔案的權限"
 ],
 "(original owner)": [
  null,
  "（原始擁有者）"
 ],
 "keep original owners": [
  null,
  "保留原始擁有者"
 ],
 "Paste as owner": [
  null,
  "作為擁有者貼上"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "正要貼上的檔案有不同的擁有者。在預設的情況，擁有權將被變更為與目的地目錄相符。"
 ],
 "New owner": [
  null,
  "新擁有者"
 ],
 "Overwrite": [
  null,
  "覆寫"
 ],
 "New filename": [
  null,
  "新檔案名稱"
 ],
 "New name": [
  null,
  "新名稱"
 ],
 "Rename $0?": [
  null,
  "將 $0 重新命名？"
 ],
 "link to $0": [
  null,
  "連結至 $0"
 ],
 "Create link to $0": [
  null,
  "建立至 $0 的連結"
 ],
 "Target": [
  null,
  "目標"
 ],
 "Symlink name": [
  null,
  "符號連結名稱"
 ],
 "Type": [
  null,
  "類型"
 ],
 "Absolute vs. Relative": [
  null,
  "絕對 vs. 相對"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "絕對符號連結適合指向不會被移動的檔案或目錄，例如系統檔案。"
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "相對符號連結在符號連結與目標同時都可能被移動時相當有用，如重新命名或移動上層目錄時。"
 ],
 "Absolute": [
  null,
  "絕對"
 ],
 "Relative": [
  null,
  "相對"
 ],
 "The file has been removed on disk": [
  null,
  "該檔案已被從磁碟上移除"
 ],
 "The existing file changed unexpectedly": [
  null,
  "既存的檔案有意料外的變更"
 ],
 "Edit $0": [
  null,
  "編輯 $0"
 ],
 "View $0": [
  null,
  "檢視 $0"
 ],
 "The file has changed on disk": [
  null,
  "該檔案已在磁碟上被變更"
 ],
 "Reload": [
  null,
  "重新載入"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Save changes?": [
  null,
  "儲存變更?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "該檔案在開啟後已遭刪除，若進行儲存操作，系統將自動重新建立該檔案。"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 有未儲存的變更，若將其棄用，這些變更將會永久遺失。"
 ],
 "Discard": [
  null,
  "捨棄"
 ],
 "File name": [
  null,
  "檔案名稱"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Cannot create file in current directory": [
  null,
  "無法在目前的目錄建立檔案"
 ],
 "Permission denied": [
  null,
  "使用權限被拒"
 ],
 "Directory name cannot be empty": [
  null,
  "目錄名稱不能是空值"
 ],
 "Directory name too long": [
  null,
  "目錄名稱太長"
 ],
 "Directory name cannot include a /": [
  null,
  "目錄名稱不能包含 /"
 ],
 "Directory name": [
  null,
  "目錄名稱"
 ],
 "Directory owner": [
  null,
  "目錄擁有者"
 ],
 "No matching results": [
  null,
  "沒有找到相符的結果"
 ],
 "Clear filter": [
  null,
  "清除篩選器"
 ],
 "Directory is empty": [
  null,
  "目錄是空的"
 ],
 "$0 item is hidden": [
  null,
  "$0 個已隱藏的項目"
 ],
 "Folder": [
  null,
  "折疊"
 ],
 "Others": [
  null,
  "其他人"
 ],
 "$0 files selected": [
  null,
  "已選擇 $0 個檔案"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "此目錄包含 $0 個目錄、$1 個檔案"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "此目錄包含 $0 個目錄、$1 個檔案、$2 個隱藏項目"
 ],
 "User": [
  null,
  "使用者"
 ]
});
