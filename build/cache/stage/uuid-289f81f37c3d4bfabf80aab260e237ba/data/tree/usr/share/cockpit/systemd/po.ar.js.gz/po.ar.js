cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Journal": [
  null,
  "سجل اليومية"
 ],
 "Terminal": [
  null,
  "الطرفية"
 ],
 "Hardware information": [
  null,
  "معلومات العتاد المادي"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "active": [
  null,
  "نشِط"
 ],
 "Default": [
  null,
  "افتراضي"
 ],
 "Light": [
  null,
  "فاتح"
 ],
 "Dark": [
  null,
  "داكن"
 ],
 "Help": [
  null,
  "مساعدة"
 ],
 "Select": [
  null,
  "تحديد"
 ],
 "System": [
  null,
  "النظام"
 ],
 "Search": [
  null,
  "ابحث"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "Permission denied": [
  null,
  "الإذن مرفوض"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "You now have administrative access.": [
  null,
  "لديك الآن حق الوصول الإداري."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "الرجاء المصادقة للحصول على صلاحيات إدارية"
 ],
 "Switch to administrative access": [
  null,
  "التبديل إلى الوصول الإداري"
 ],
 "Authenticate": [
  null,
  "مصادقة"
 ],
 "Administrative access": [
  null,
  "صلاحيات المسؤول"
 ],
 "Problem becoming administrator": [
  null,
  "مشكلة في الحصول على صلاحيات المسؤول"
 ],
 "Method": [
  null,
  "الطريقة"
 ],
 "Limit access": [
  null,
  "تقييد الوصول"
 ],
 "Switch to limited access": [
  null,
  "التبديل إلى الوصول محدود الصلاحيات"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "يُقيّد وضع الوصول المقيد الصلاحيات الإدارية. ستكون بعض أجزاء لوحة التحكم عبر الويب محدودة الوظائف."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "سيتذكر متصفحك مستوى وصولك عبر الجلسات."
 ],
 "Limited access": [
  null,
  "وصول مقيَّد"
 ],
 "Turn on administrative access": [
  null,
  "فعّل الوصول الإداري"
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "أبلغت PackageKit عن رمز الخطأ $0"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "نوع عامل التصفية"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Shell script": [
  null,
  "سكريبت الصدفة"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "$0 is not a directory": [
  null,
  "$0 ليس مجلداً"
 ],
 "$0 does not exist": [
  null,
  "$0 غير موجود"
 ],
 "Font size": [
  null,
  "حجم الخط"
 ],
 "Decrease by one": [
  null,
  "إنقاص بمقدار واحد"
 ],
 "Increase by one": [
  null,
  "الزيادة بمقدار واحد"
 ],
 "Appearance": [
  null,
  "المظهر"
 ],
 "Black": [
  null,
  "أسود"
 ],
 "White": [
  null,
  "أبيض"
 ],
 "Reset": [
  null,
  "صفر"
 ],
 "Unable to open directory": [
  null,
  "تعذر فتح المجلد"
 ],
 "Running process prevents directory change": [
  null,
  "تشغيل العملية يمنع تغيير المجلد"
 ],
 "Change directory": [
  null,
  "غير الدليل"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "سيؤدي تغيير المجلد إلى إيقاف العملية قيد التشغيل حاليًا بالقوة. يمكن إيقاف العملية يدويًا عبر الطرفية قبل المتابعة."
 ],
 "This browser does not support WebGL2.": [
  null,
  ""
 ],
 "unknown": [
  null,
  "غير معروف"
 ],
 "Shutdown": [
  null,
  "إيقاف التشغيل"
 ],
 "running $0": [
  null,
  "قيد تشغيل $0"
 ],
 "Current boot": [
  null,
  "الإقلاع الحالي"
 ],
 "Previous boot": [
  null,
  "جلسة الإقلاع السابقة"
 ],
 "Last 24 hours": [
  null,
  "آخر ٢٤ ساعة"
 ],
 "Last 7 days": [
  null,
  "آخر ٧ أيام"
 ],
 "Only emergency": [
  null,
  "الطوارئ فقط"
 ],
 "Alert and above": [
  null,
  "تنبيه وما فوق"
 ],
 "Critical and above": [
  null,
  "حرج فما فوق ذلك"
 ],
 "Error and above": [
  null,
  "الخطأ وما فوق"
 ],
 "Warning and above": [
  null,
  "تحذير وما فوق"
 ],
 "Notice and above": [
  null,
  "ملاحظة وما فوق"
 ],
 "Info and above": [
  null,
  "معلومات وأكثر"
 ],
 "Debug and above": [
  null,
  "تصحيح الأخطاء وما فوق"
 ],
 "Toggle filters": [
  null,
  "تبديل عوامل التصفية"
 ],
 "Time": [
  null,
  "وقت"
 ],
 "Priority": [
  null,
  "الأولوية"
 ],
 "Identifier": [
  null,
  "معرّف"
 ],
 "Filters": [
  null,
  "عوامل التصفية"
 ],
 "Pause": [
  null,
  "إيقاف مؤقَّت"
 ],
 "Resume": [
  null,
  "استئناف"
 ],
 "All": [
  null,
  "الكل"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "‍يجب أن تكون مواصفات التاريخ بالصيغة YYYYY-MMM-DD hh:mm:ss. وبدلاً من ذلك، تُفهم السلاسل 'yesterday'، و'today'، و'tomorrow'. تشير كلمة 'now' إلى الوقت الحالي. أخيرًا، يمكن تحديد الأوقات النسبية، مسبوقة ب '-' أو '+'"
 ],
 "Since": [
  null,
  "منذ"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "بدء عرض الإدخالات في التاريخ المحدد أو أحدث منه."
 ],
 "Until": [
  null,
  "حتى"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "بدء عرض الإدخالات في التاريخ المحدد أو أقدم."
 ],
 "Boot": [
  null,
  "الإقلاع"
 ],
 "Show messages from a specific boot.": [
  null,
  "إظهار الرسائل من إقلاع معين."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "سيؤدي هذا إلى إضافة تطابق لـ '_BOOT_ID='. إذا لم يتم تحديده، سيتم عرض سجلات عملية الإقلاع الحالية. إذا حُذِف مُعرَّف الإقلاع (boot ID)، سيبحث الإزاحة الموجبة (positive offset) عن عمليات الإقلاع بدءًا من بداية سجلات النظام (journal)، بينما سيبحث الإزاحة المساوية للصفر أو الأقل (equal-or-less-than zero offset) عن عمليات الإقلاع بدءًا من نهاية السجل. وبالتالي: الرقم 1 يعني أول عملية إقلاع موجودة في السجل بالترتيب الزمني، 2 تعني الثانية وهكذا، بينما 0- يشير إلى آخر عملية إقلاع، و1- يشير إلى ما قبل الأخيرة، وهكذا."
 ],
 "Unit": [
  null,
  "وحدة"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "عرض رسائل وحدة systemd المحددة."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "سيؤدي ذلك إلى إضافة تطابق لـ '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' و 'UNIT=' للعثور على جميع الرسائل المحتملة لهذه الوحدة. يمكن أن تحتوي على وحدات أكثر مفصولة بفاصلة."
 ],
 "Free-form search": [
  null,
  "بحث حر البنية"
 ],
 "Show messages containing given string.": [
  null,
  "عرض الرسائل التي تحتوي على النص المحدد."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "يمكن تصفية أي سلسلة نصية في رسائل السجلات. يمكن أن تكون السلسلة أيضًا على شكل تعبير نمطي (Regular Expression). كما يدعم التصفية حسب حقول سجل الرسائل. هذه الحقول هي قيم مفصولة بمسافات، بالشكل FIELD=VALUE، حيث يمكن أن تكون القيمة قائمة مفصولة بفواصل من القيم الممكنة."
 ],
 "journalctl manpage": [
  null,
  "صفحة الدليل لأداة journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "تم النسخ بنجاح إلى الحافظة"
 ],
 "Create timer": [
  null,
  "إنشاء مؤقت"
 ],
 "Timer creation failed": [
  null,
  "فشل إنشاء المؤقِّت"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "هذا الحقل لا يمكن أن يكون فارغاً"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "فقط الحروف الهجائية، والأرقام، : ،، _، . ، @، @، - مسموح بها"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "المشغِّل"
 ],
 "At specific time": [
  null,
  "عند وقت محدد"
 ],
 "After system boot": [
  null,
  "بعد إقلاع النظام"
 ],
 "Seconds": [
  null,
  "الثواني"
 ],
 "Minutes": [
  null,
  "دقائق"
 ],
 "Hours": [
  null,
  "ساعات"
 ],
 "Weeks": [
  null,
  "أسابيع"
 ],
 "Delay must be a number": [
  null,
  "التأخير يجب أن يكون عدداً"
 ],
 "Repeat": [
  null,
  "تكرار"
 ],
 "Don't repeat": [
  null,
  "لا تكرر"
 ],
 "Minutely": [
  null,
  "بالدقيقة"
 ],
 "Hourly": [
  null,
  "كل ساعة"
 ],
 "Daily": [
  null,
  "يومياً"
 ],
 "Weekly": [
  null,
  "أسبوعياً"
 ],
 "Monthly": [
  null,
  "شهرياً"
 ],
 "Yearly": [
  null,
  "سنوياً"
 ],
 "Run at": [
  null,
  "تشغيل عند"
 ],
 "At second": [
  null,
  "عند ثانية"
 ],
 "At minute": [
  null,
  "عند الدقيقة"
 ],
 "Run on": [
  null,
  "التشغيل على"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "يجب أن تكون قيمة الدقيقة عدداً بين 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "الثواني يلزم أن تكون عددً بين ٠-٥٩"
 ],
 "Repeat weekly": [
  null,
  "التكرار أسبوعياً"
 ],
 "Mondays": [
  null,
  "أيام الإثنين"
 ],
 "Tuesdays": [
  null,
  "أيام الخميس"
 ],
 "Wednesdays": [
  null,
  "أيام الأربعاء"
 ],
 "Thursdays": [
  null,
  "أيام الخميس"
 ],
 "Fridays": [
  null,
  "أيام الجُمع"
 ],
 "Saturdays": [
  null,
  "أيام السبت"
 ],
 "Sundays": [
  null,
  "أيام الأحد"
 ],
 "Repeat monthly": [
  null,
  "التكرار شهرياً"
 ],
 "1st": [
  null,
  "الأول"
 ],
 "2nd": [
  null,
  "الثاني"
 ],
 "3rd": [
  null,
  "الثالث"
 ],
 "4th": [
  null,
  "الرابع"
 ],
 "5th": [
  null,
  "الخامس"
 ],
 "6th": [
  null,
  "السادس"
 ],
 "7th": [
  null,
  "السابع"
 ],
 "8th": [
  null,
  "الثامن"
 ],
 "9th": [
  null,
  "التاسع"
 ],
 "10th": [
  null,
  "العاشر"
 ],
 "11th": [
  null,
  "الحادي عشر"
 ],
 "12th": [
  null,
  "الثاني عشر"
 ],
 "13th": [
  null,
  "الثالث عشر"
 ],
 "14th": [
  null,
  "الرابع عشر"
 ],
 "15th": [
  null,
  "الخامس عشر"
 ],
 "16th": [
  null,
  "السادس عشر"
 ],
 "17th": [
  null,
  "السابع عشر"
 ],
 "18th": [
  null,
  "الثامن عشر"
 ],
 "19th": [
  null,
  "التاسع عشر"
 ],
 "20th": [
  null,
  "العشرون"
 ],
 "21th": [
  null,
  "الحادي والعشرون"
 ],
 "22th": [
  null,
  "الثاني والعشرون"
 ],
 "23th": [
  null,
  "الثالث والعشرون"
 ],
 "24th": [
  null,
  "الرابع والعشرون"
 ],
 "25th": [
  null,
  "الخامس والعشرون"
 ],
 "26th": [
  null,
  "السادس والعشرون"
 ],
 "27th": [
  null,
  "السابع والعشرون"
 ],
 "28th": [
  null,
  "الثامن والعشرون"
 ],
 "29th": [
  null,
  "التاسع والعشرون"
 ],
 "30th": [
  null,
  "الثلاثون"
 ],
 "31st": [
  null,
  "الواحد والثلاثون"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Unclean shutdown": [
  null,
  "إطفاء غير نظيف"
 ],
 "View logs": [
  null,
  "عرض السجلات"
 ],
 "Dismiss": [
  null,
  "استبعاد"
 ],
 "Scheduled poweroff at $0": [
  null,
  "إيقاف تشغيل مجدول عند $0"
 ],
 "Cancel poweroff": [
  null,
  "إلغاء إيقاف التشغيل"
 ],
 "Scheduled reboot at $0": [
  null,
  "إعادة تشغيل للنظام مجدولة عند $0"
 ],
 "Cancel reboot": [
  null,
  "إيقاف إعادة التشغيل"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "Set hostname": [
  null,
  "عيّن اسم المضيف"
 ],
 "Configuration": [
  null,
  "الضبط"
 ],
 "Hostname": [
  null,
  "اسم-المضيف"
 ],
 "System time": [
  null,
  "توقيت النظام"
 ],
 "Domain": [
  null,
  "نطاق"
 ],
 "Performance profile": [
  null,
  "ملف تعريف الأداء"
 ],
 "Secure shell keys": [
  null,
  "مفاتيح الصدفة الآمنة"
 ],
 "Show fingerprints": [
  null,
  "إظهار البصمات"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "فشل في سرد مفاتيح ssh للمضيف: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "تحميل مفاتيح SSH فشل"
 ],
 "Error message": [
  null,
  "رسالة خطأ"
 ],
 "Loading keys...": [
  null,
  "تحميل المفاتيح..."
 ],
 "No host keys found.": [
  null,
  "لا يوجد مفاتيح استضافة."
 ],
 "Machine SSH key fingerprints": [
  null,
  "بصمات مفتاح SSH للآلة"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "يجب أن يتكون اسم المضيف الحقيقي من ٦٤ حرفاً أو أقل"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "اسم المضيف الحقيقي يمكن أن يحتوي فقط على أحرف صغيرة وأرقام وشرطات ونقاط (مع نطاقات فرعية مأهولة)"
 ],
 "Change host name": [
  null,
  "تغيير اسم المضيف"
 ],
 "Pretty host name": [
  null,
  "الاسم الظاهر للمضيف"
 ],
 "Real host name": [
  null,
  "اسم مضيف حقيقي"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "المستخدم $0 غير مصرَّح له بتغيير سياسات التشفير"
 ],
 "Cryptographic policy": [
  null,
  "سياسة التشفير"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "الإعدادات الموصى بها والآمنة لنماذج التهديد الحالية."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT مع السماح بالتحقق من توقيع SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "توافقية أعلى على حساب زيادة المساحة المعرضة للهجوم."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY مع إمكانية التشغيل البيني لـ Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "استخدم الخوارزميات المعتمدة والمسموح بها فقط عند الإقلاع في وضع FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS مع مزيد من قيود المعايير المشتركة."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "يوفر الحماية ضد الهجمات المتوقعة في المدى القريب على حساب التوافقية."
 ],
 "Custom cryptographic policy": [
  null,
  "سياسة تشفير مخصصة"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "سياسة التشفير عبارة عن مكوّن نظام يقوم بتكوين أنظمة التشفير الفرعية الأساسية، التي تغطي بروتوكولات TLS و IPSec و SSH و DNSSec و Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "غيّر سياسة التشفير"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "يتم تطبيق السياسة الجديدة... قد يستغرق هذا بضع دقائق."
 ],
 "Reapply and reboot": [
  null,
  "إعادة التطبيق ثم إعادة التشغيل"
 ],
 "Apply and reboot": [
  null,
  "طبق وأعد التشغيل"
 ],
 "FIPS is not properly enabled": [
  null,
  "لم يتم تمكين FIPS بشكل صحيح"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "سياسة التشفير غير متسقة"
 ],
 "Review cryptographic policy": [
  null,
  "مراجعة سياسة الحماية"
 ],
 "System information": [
  null,
  "معلومات النظام"
 ],
 "Model": [
  null,
  "النموذج"
 ],
 "Asset tag": [
  null,
  "معرّف الأصل"
 ],
 "Machine ID": [
  null,
  "معرف الآلة ID"
 ],
 "Up since": [
  null,
  "منذ ذلك الحين"
 ],
 "View hardware details": [
  null,
  "عرض تفاصيل العتاد المادي"
 ],
 "Last successful login:": [
  null,
  "آخر تسجيل دخول ناجح:"
 ],
 "$0 failed login attempt": [
  null,
  "لا يوجد محاولات تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول واحدة فاشلة",
  "$0 محاولتا تسجيل دخول فاشلة",
  "$0 محاولات تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول فاشلة"
 ],
 "View login history": [
  null,
  "عرض التاريخ المسجَّل"
 ],
 "recommended": [
  null,
  "مستحسن"
 ],
 "inconsistent": [
  null,
  "غير متناسق"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "الانضمام لنطاق يتطلب تثبيت realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "لا يمكن الانضمام إلى نطاق ؛ لأن realmd غير متوفر على هذا النظام"
 ],
 "Joining this domain is not supported": [
  null,
  "الانضمام لهذا المجال غير مدعوم"
 ],
 "Login format": [
  null,
  "تهيئة تسجيل الدخول"
 ],
 "Server software": [
  null,
  "برنامج الخادم"
 ],
 "Client software": [
  null,
  "برنامج العميل"
 ],
 "Leave domain": [
  null,
  "مغادرة النطاق"
 ],
 "Leave $0": [
  null,
  "مغادرة $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "بعد إزالة الجهاز من النطاق، يقتصر تسجيل الدخول على الحسابات المحلية فقط. وقد يؤثر ذلك أيضًا على خدمات أخرى، مثل إعدادات استعلام نظام أسماء النطاقات (DNS) وقائمة شهادات الجهة المصدرة (CAs) الموثوقة."
 ],
 "Validating address": [
  null,
  "التحقق من صحة العنوان"
 ],
 "Contacted domain": [
  null,
  "النطاق المُتصَّل به"
 ],
 "Domain could not be contacted": [
  null,
  "تعذر الاتصال بالنطاق"
 ],
 "Domain is not supported": [
  null,
  "النطاق غير مدعوم"
 ],
 "Domain address": [
  null,
  "عنوان النطاق"
 ],
 "Domain administrator name": [
  null,
  "اسم نطاق مسؤول النظام"
 ],
 "Domain administrator password": [
  null,
  "كلمة سر نطاق مسؤول النظام"
 ],
 "Joining": [
  null,
  "الانضمام"
 ],
 "Join": [
  null,
  "انضم"
 ],
 "This may take a while": [
  null,
  "قد يستغرق هذا بعض الوقت"
 ],
 "Not permitted to configure realms": [
  null,
  "غير مسموح بتكوين realms"
 ],
 "Join domain": [
  null,
  "الانضمام إلى النطاق"
 ],
 "Install realmd support": [
  null,
  "تثبيت دعم realmd"
 ],
 "$0 disk is failing": [
  null,
  "لا قرص معطل",
  "القرص معطل",
  "القرصان معطلان",
  "توجد $0 أقراص معطلة",
  "يوجد $0 قرصاً معطلاً",
  "يوجد $0 قرصاً معطلاً"
 ],
 "Not connected to Insights": [
  null,
  "غير متصل بـ Insights"
 ],
 "Health": [
  null,
  "الصحة"
 ],
 "of $0 CPU": [
  null,
  "من $0 وحدة معالجة مركزية",
  "من وحدة معالجة مركزية واحدة CPU",
  "من وحدتي معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs"
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "View metrics and history": [
  null,
  "عرض المقاييس والتاريخ"
 ],
 "Tuned is not available": [
  null,
  "Tuned غير متوفر"
 ],
 "Tuned is not running": [
  null,
  "Tuned ليس قيد التشغيل"
 ],
 "Tuned is off": [
  null,
  "Tuned مطفئ"
 ],
 "This system is using the recommended profile": [
  null,
  "هذا النظام يستخدم ملف التعريف الموصى به"
 ],
 "This system is using a custom profile": [
  null,
  "هذا النظام يستخدم ملف تعريف مخصص"
 ],
 "none": [
  null,
  "لا شيء"
 ],
 "Communication with tuned has failed": [
  null,
  "تعذّر الاتصال بـ Tuned"
 ],
 "Failed to enable tuned": [
  null,
  "فشل في تمكين الضبط"
 ],
 "Failed to disable tuned": [
  null,
  "فشل في تعطيل الضبط"
 ],
 "Failed to disable tuned profile": [
  null,
  "فشل تعطيل ملف التعريف المضبوط"
 ],
 "Failed to switch profile": [
  null,
  "فشل في تبديل الملف الشخصي"
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "Disable tuned": [
  null,
  "تعطيل الضبط"
 ],
 "Tuned has failed to start": [
  null,
  "فشل الضبط في بدء التشغيل"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned هو خدمة تراقب نظامك وتحسّن أداءه تحت أعباء عمل محددة. جوهر Tuned يتمثل في التشكيلات التي تضبط نظامك ليتناسب مع حالات استخدام مختلفة."
 ],
 "Change performance profile": [
  null,
  "تغيير ملف تعريف الأداء"
 ],
 "Change profile": [
  null,
  "تغيير ملف التعريف"
 ],
 "Edit /etc/motd": [
  null,
  "تعديل /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "فشل في حفظ التغييرات في /etc/motd"
 ],
 "Save changes": [
  null,
  "احفظ التغييرات"
 ],
 "Edit motd": [
  null,
  "تعديل motd"
 ],
 "Stub": [
  null,
  "هيكل أولي"
 ],
 "Not found": [
  null,
  "غير موجود"
 ],
 "Bad setting": [
  null,
  "إعدادات سيئة"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "Merged": [
  null,
  "مدمج"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "Reloading": [
  null,
  "إعادة التحميل"
 ],
 "Not running": [
  null,
  "لا يعمل"
 ],
 "Failed to start": [
  null,
  "فشل في البدء"
 ],
 "Maintenance": [
  null,
  "الصيانة"
 ],
 "Enabled": [
  null,
  "مُفعَّل"
 ],
 "Disabled": [
  null,
  "معطّل"
 ],
 "Linked": [
  null,
  "مرتبط"
 ],
 "Alias": [
  null,
  "اسم مستعار"
 ],
 "Masked": [
  null,
  "مخفي"
 ],
 "Static": [
  null,
  "ثابت"
 ],
 "Invalid": [
  null,
  "غير صالح"
 ],
 "Indirect": [
  null,
  "غير مباشر"
 ],
 "Generated": [
  null,
  "تم توليده"
 ],
 "Transient": [
  null,
  "مؤقَّت"
 ],
 "Bad": [
  null,
  "سيء"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "فشل الاشتراك في إشارات النظام systemd: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "الاتصال بـ dbus فشل: $0"
 ],
 "Listing units failed: $0": [
  null,
  "استماع الوحدات فشل: $0"
 ],
 "$0 service has failed": [
  null,
  "لا خدمة توقفت عن العمل",
  "خدمة واحدة توقفت عن العمل",
  "خدمتان توقفتا عن العمل",
  "‎$0 خدمات توقفت عن العمل",
  "$0 خدمة توقفت عن العمل",
  "‎$0 خدمة توقفت عن العمل"
 ],
 "Loading of units failed": [
  null,
  "تحميل الوحدات فشل"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Listing units": [
  null,
  "وحدات الاستماع"
 ],
 "Filter by name or description": [
  null,
  "التصفية حسب الاسم أو الوصف"
 ],
 "Active state": [
  null,
  "حالة النشاط"
 ],
 "File state": [
  null,
  "حالة الملف"
 ],
 "$0 filters applied": [
  null,
  "تم تطبيق ‎$0 من عوامل التصفية"
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "المستخدم $0 غير مصرَّح له بتغيير إجراءات التخفيف الأمني لوحدة المعالجة المركزية (CPU)"
 ],
 "Mitigations": [
  null,
  "إجراءات التخفيف"
 ],
 "Version": [
  null,
  "الإصدار"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "إصدار الـ BIOS"
 ],
 "BIOS date": [
  null,
  "تاريخ الـ BIOS"
 ],
 "CPU security": [
  null,
  "أمان المعالج"
 ],
 "Disable simultaneous multithreading": [
  null,
  "تعطيل تعدد مؤشرات الترابط المتزامن"
 ],
 "Read more...": [
  null,
  "اقرأ المزيد..."
 ],
 "Save and reboot": [
  null,
  "حفظ ثم إعادة تشغيل النظام"
 ],
 "CPU security toggles": [
  null,
  "مفاتيح تبديل أمان المعالج"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "تساعد الحلول المستندة إلى البرامج في منع مشاكل أمان وحدة المعالجة المركزية. هذه الحلول لها تأثير جانبي يتمثل في تقليل الأداء. قم بتغيير هذه الإعدادات على مسؤوليتك الخاصة."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "الصنف"
 ],
 "Vendor": [
  null,
  "المُنتِج"
 ],
 "Slot": [
  null,
  "الفتحة"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "Memory technology": [
  null,
  "تقنية الذاكرة"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Rank": [
  null,
  "الرتبة"
 ],
 "Speed": [
  null,
  "السرعة"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "يتطلب عرض معلومات الذاكرة الوصول الإداري."
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "Failed to fetch logs": [
  null,
  "فشل في جلب السجلات"
 ],
 "Clear all filters": [
  null,
  "إزالة كل المرشحات"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "لا يمكن العثور على أي سجلات عبر مجموعة المرشحات الحالية."
 ],
 "No logs found": [
  null,
  "لا يوجد سجلات"
 ],
 "Load earlier entries": [
  null,
  "تحميل المدخلات السابقة"
 ],
 "You may try to load older entries.": [
  null,
  "يمكنك محاولة تحميل الإدخالات القديمة."
 ],
 "Allow running (unmask)": [
  null,
  "السماح بالتشغيل (إلغاء الحجب)"
 ],
 "Reload": [
  null,
  "إعادة تحميل"
 ],
 "Restart": [
  null,
  "أعد التشغيل"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Clear 'Failed to start'": [
  null,
  "المسح \"فشل في البدء\""
 ],
 "Mask service": [
  null,
  "خدمة الإخفاء"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "تمننع خدمة الإخفاء جميع الوحدات المعتمدة عليها من التشغيل. قد يكون لهذا تأثير أكبر مما هو متوقع. يرجى تأكيد رغبتك في إخفاء هذه الوحدة."
 ],
 "Disallow running (mask)": [
  null,
  "عدم السماح بالتشغيل (قناع)"
 ],
 "Unpin unit": [
  null,
  "وحدة فك التثبيت"
 ],
 "Pin unit": [
  null,
  "تعليق الوحدة"
 ],
 "Additional actions": [
  null,
  "عمليات إضافية"
 ],
 "Note": [
  null,
  "ملاحظة"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "لم يتم تصميم هذه الوحدة ليتم تمكينها بشكل صريح."
 ],
 "Forbidden from running": [
  null,
  "ممنوع من التشغيل"
 ],
 "Start service": [
  null,
  "بدء الخدمة"
 ],
 "Active since ": [
  null,
  "نشط منذ "
 ],
 "Required by ": [
  null,
  "مطلوب من قِبل "
 ],
 "Read-only": [
  null,
  "القراءة-فقط"
 ],
 "Requires administration access to edit": [
  null,
  "يتطلب صلاحيات المسؤول للتعديل"
 ],
 "Automatically starts": [
  null,
  "يبدأ تلقائيًا"
 ],
 "Updating status...": [
  null,
  "حالة التحديث..."
 ],
 "Stop and disable": [
  null,
  "إيقاف وإلغاء تفعيل"
 ],
 "Start and enable": [
  null,
  "بدء ثم تفعيل"
 ],
 "Failed to load unit": [
  null,
  "فشل في تحميل الوحدة"
 ],
 "View all services": [
  null,
  "عرض جميع الخدمات"
 ],
 "Triggers": [
  null,
  "المشغِّلات"
 ],
 "Triggered by": [
  null,
  "تم تشغيله بواسطة"
 ],
 "Requires": [
  null,
  "يتطلب"
 ],
 "Requisite": [
  null,
  "متطلب"
 ],
 "Wants": [
  null,
  "المطلوبات"
 ],
 "Binds to": [
  null,
  "مرتبط بـ"
 ],
 "Part of": [
  null,
  "جزء من"
 ],
 "Required by": [
  null,
  "مطلوب من قِبل"
 ],
 "Requisite of": [
  null,
  "متطلبات"
 ],
 "Wanted by": [
  null,
  "مطلوب من قبل"
 ],
 "Bound by": [
  null,
  "ملزم بـ"
 ],
 "Consists of": [
  null,
  "يتكون من"
 ],
 "Conflicts": [
  null,
  "تعارضات"
 ],
 "Conflicted by": [
  null,
  "متعارض مع"
 ],
 "Before": [
  null,
  "قبل"
 ],
 "After": [
  null,
  "بعد"
 ],
 "On failure": [
  null,
  "عند الفشل"
 ],
 "Propagates reload to": [
  null,
  "يُنقل أمر إعادة التحميل إلى"
 ],
 "Reload propagated from": [
  null,
  "إعادة التحميل المنتشر من"
 ],
 "Joins namespace of": [
  null,
  "ينضم إلى مساحة الأسماء الخاصة بـ"
 ],
 "Condition $0=$1 was not met": [
  null,
  "لم يتم تحقيق الشرط $0=$1"
 ],
 "Deletion will remove the following files:": [
  null,
  "سيؤدي الحذف إلى إزالة الملفات التالية:"
 ],
 "Pinned unit": [
  null,
  "الوحدة المعلَّقة"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Path": [
  null,
  "مسار"
 ],
 "Listen": [
  null,
  "استماع"
 ],
 "Container": [
  null,
  "حاوية"
 ],
 "View Podman container": [
  null,
  "عرض حاوية Podman"
 ],
 "Condition failed": [
  null,
  "الشرط لم يتحقق"
 ],
 "Show more relationships": [
  null,
  "عرض المزبد من العلاقات"
 ],
 "Show relationships": [
  null,
  "أظهر العلاقات"
 ],
 "Confirm deletion of $0": [
  null,
  "تأكيد حذف $0"
 ],
 "Timer deletion failed": [
  null,
  "فشل حذف المؤقِّت"
 ],
 "Targets": [
  null,
  "الأهداف"
 ],
 "Sockets": [
  null,
  "مقابس التوصيل"
 ],
 "Timers": [
  null,
  "المؤقتات"
 ],
 "Paths": [
  null,
  "المسارات"
 ],
 "Go to $0": [
  null,
  "‎انتقل إلى $0"
 ],
 "Journal entry not found": [
  null,
  "قيد اليوميات غير موجود"
 ],
 "Journal entry": [
  null,
  "قيد اليوميات"
 ],
 "Entry at $0": [
  null,
  "الدخول عند $0"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "Loading unit failed": [
  null,
  "تحميل الوحدة فشل"
 ],
 "Service logs": [
  null,
  "سجلات الخدمة"
 ],
 "No log entries": [
  null,
  "لا إدخالات في السجل"
 ],
 "Systemd units": [
  null,
  "وحدات Systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "لا توجد نتائج تطابق معايير التصفية. امسح جميع عوامل التصفية لإظهار النتائج."
 ],
 "Does not automatically start": [
  null,
  "لا تبدأ تلقائياً"
 ],
 "Cannot be enabled": [
  null,
  "غير قابل للتغعيل"
 ],
 "Web console is running in limited access mode.": [
  null,
  "تعمل وحدة تحكم الويب في وضع الوصول المحدود."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "من $0 على $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "من $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "على $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "نطاق"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "الانضمام إلى نطاق"
 ]
});
