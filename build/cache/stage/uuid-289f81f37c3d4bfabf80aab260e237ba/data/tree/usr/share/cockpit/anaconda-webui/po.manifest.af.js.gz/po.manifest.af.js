cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "af",
  "language-direction": "ltr"
 }
});
