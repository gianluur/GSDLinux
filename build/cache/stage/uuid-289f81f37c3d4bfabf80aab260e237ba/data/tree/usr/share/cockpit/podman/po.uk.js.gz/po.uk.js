cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "uk",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Вилучити $0?"
 ],
 "Force delete": [
  null,
  "Примусове вилучення"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Must be a valid IP address": [
  null,
  "Має бути коректною IP-адресою"
 ],
 "1 to 65535": [
  null,
  "від 1 до 65535"
 ],
 "Container port must not be empty": [
  null,
  "Порт контейнера має бути непорожнім"
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "IP address help": [
  null,
  "Довідка з IP-адреси"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Якщо встановлено IP-адресу основної системи 0.0.0.0 або адресу взагалі не встановлено, порт буде пов'язано з усіма IP в основній системі."
 ],
 "Host port": [
  null,
  "Порт основної системи"
 ],
 "Host port help": [
  null,
  "Довідка з порту основної системи"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Якщо порт в основній системі не встановлено, порт контейнера буде випадковим чином пов'язано із портом в основній системі."
 ],
 "Container port": [
  null,
  "Порт контейнера"
 ],
 "Protocol": [
  null,
  "Протокол"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Вилучити запис"
 ],
 "Image name is required": [
  null,
  "Слід вказати назву образу"
 ],
 "Image name is not unique": [
  null,
  "Назва образу не є унікальною"
 ],
 "Failed to commit container $0": [
  null,
  "Не вдалося надіслати на обробку контейнер $0"
 ],
 "New image name": [
  null,
  "Назва нового образу"
 ],
 "Tag": [
  null,
  "Мітка"
 ],
 "Author": [
  null,
  "Автор"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Приклад: Ваше Ім'я <vasheimya@example.com>"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Pause container when creating image": [
  null,
  "Призупинити роботу контейнера при створенні образу"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Формат Docker корисний, якщо ви захочете використовувати образ спільно у середовищах Docker або Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Скористатися застарілим форматом Docker"
 ],
 "Commit container": [
  null,
  "Внести контейнер"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Створити образ на основі поточного стану контейнера $0."
 ],
 "Commit": [
  null,
  "Надіслати"
 ],
 "Force commit": [
  null,
  "Примусово внести"
 ],
 "Failed to force remove container $0": [
  null,
  "Не вдалося примусово вилучити контейнер $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Вилучення запущеного контейнера призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Failed to stop container $0": [
  null,
  "Не вдалося зупинити роботу контейнера $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Не вдалося зупинити квадлет $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Не вдалося запустити квадлет $0"
 ],
 "Failed to start container $0": [
  null,
  "Не вдалося запустити роботу контейнера $0"
 ],
 "Failed to resume container $0": [
  null,
  "Не вдалося відновити роботу контейнера $0"
 ],
 "Failed to pause container $0": [
  null,
  "Не вдалося призупинити роботу контейнера $0"
 ],
 "Failed to restart container $0": [
  null,
  "Не вдалося перезапустити контейнер $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Не вдалося перезапустити квадлет $0"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Restart": [
  null,
  "Перезапустити"
 ],
 "Force stop": [
  null,
  "Примусово зупинити"
 ],
 "Force restart": [
  null,
  "Примусовий перезапуск"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Resume": [
  null,
  "Продовжити"
 ],
 "Checkpoint": [
  null,
  "Контрольна точка"
 ],
 "Start": [
  null,
  "Запустити"
 ],
 "Restore": [
  null,
  "Відновити"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Healthy": [
  null,
  "Працездатний"
 ],
 "Unhealthy": [
  null,
  "Непрацездатний"
 ],
 "Checking health": [
  null,
  "Перевіряємо працездатність"
 ],
 "Prune unused containers": [
  null,
  "Позбутися невикористаних контейнерів"
 ],
 "Terminal not available": [
  null,
  "Немає доступу до термінала"
 ],
 "This browser does not support WebGL2.": [
  null,
  "У цьому браузері не передбачено підтримки WebGL2."
 ],
 "View $0 logs": [
  null,
  "Перегляд журналу $0"
 ],
 "not available": [
  null,
  "не доступне"
 ],
 "n/a": [
  null,
  "н/д"
 ],
 "$0% of $1 limit": [
  null,
  "$0% o з обмеження у $1"
 ],
 "service": [
  null,
  "служба"
 ],
 "system": [
  null,
  "система"
 ],
 "user:": [
  null,
  "користувач:"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Integration": [
  null,
  "Інтеграція"
 ],
 "Logs": [
  null,
  "Журнал"
 ],
 "Console": [
  null,
  "Консоль"
 ],
 "Health check": [
  null,
  "Перевірка працездатності"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Click to see published ports": [
  null,
  "Натисніть, щоб переглянути оприлюднені порти"
 ],
 "ports": [
  null,
  "порти"
 ],
 "Click to see volumes": [
  null,
  "Натисніть, щоб переглянути томи"
 ],
 "volumes": [
  null,
  "томи"
 ],
 "Container": [
  null,
  "Контейнер"
 ],
 "Owner": [
  null,
  "Власник"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "No containers": [
  null,
  "Немає контейнерів"
 ],
 "No containers in this pod": [
  null,
  "У цьому коконі немає контейнерів"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "No containers that match the current filter": [
  null,
  "Немає контейнерів, які проходять поточні умови фільтрування"
 ],
 "No running containers": [
  null,
  "Немає запущених контейнерів"
 ],
 "Show": [
  null,
  "Показати"
 ],
 "All": [
  null,
  "Усі"
 ],
 "Only running": [
  null,
  "Лише запущені"
 ],
 "Create pod": [
  null,
  "Створити стручок"
 ],
 "Create container": [
  null,
  "Створити контейнер"
 ],
 "Containers": [
  null,
  "Контейнери"
 ],
 "Create container in pod": [
  null,
  "Створити контейнер у стручку"
 ],
 "pod": [
  null,
  "кокон"
 ],
 "Failed to restore container $0": [
  null,
  "Не вдалося відновити контейнер $0"
 ],
 "Restore container $0": [
  null,
  "Відновити контейнер $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Зберігати усі тимчасові файли контрольних точок"
 ],
 "Restore with established TCP connections": [
  null,
  "Відновити із встановленими з'єднаннями TCP"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ігнорувати IP-адресу, якщо її встановлено статично"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ігнорувати MAC-адресу, якщо її встановлено статично"
 ],
 "Pod failed to be created": [
  null,
  "Не вдалося створити стручок"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Некоректні символи. Назва може складатися лише з літер, цифр та деяких символів пунктуації (_ . -)."
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Pod name": [
  null,
  "Назва стручка"
 ],
 "System": [
  null,
  "Система"
 ],
 "User:": [
  null,
  "Користувач:"
 ],
 "No ports exposed": [
  null,
  "Не відкрито жодного порту"
 ],
 "Port mapping": [
  null,
  "Прив'язка портів"
 ],
 "Add port mapping": [
  null,
  "Додати прив'язку портів"
 ],
 "No volumes specified": [
  null,
  "Томів не визначено"
 ],
 "Volumes": [
  null,
  "Томи"
 ],
 "Add volume": [
  null,
  "Додати том"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Type to filter…": [
  null,
  "Введіть щось для фільтрування…"
 ],
 "Container path must not be empty": [
  null,
  "Шлях до контейнера має бути непорожнім"
 ],
 "Host path": [
  null,
  "Шлях у основній системі"
 ],
 "Container path": [
  null,
  "Шлях до контейнера"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Writable": [
  null,
  "Придатний до запису"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Немає мітки"
 ],
 "Shared": [
  null,
  "Спільний"
 ],
 "Private": [
  null,
  "Приватний"
 ],
 "Read-write access": [
  null,
  "Доступ до читання і запису"
 ],
 "Read-only access": [
  null,
  "Доступ лише до читання"
 ],
 "Show less": [
  null,
  "Стислий показ"
 ],
 "Show more": [
  null,
  "Додаткові відомості"
 ],
 "Loading details...": [
  null,
  "Завантаження подробиць…"
 ],
 "Ports": [
  null,
  "Порти"
 ],
 "Environment variables": [
  null,
  "Змінні середовища"
 ],
 "Failed to download image $0:$1": [
  null,
  "Не вдалося отримати образ $0:$1"
 ],
 "Error message": [
  null,
  "Повідомлення про помилку"
 ],
 "unused": [
  null,
  "не використано"
 ],
 "$0 container": [
  null,
  "$0 контейнер",
  "$0 контейнери",
  "$0 контейнерів"
 ],
 "History": [
  null,
  "Журнал"
 ],
 "Image": [
  null,
  "Образ"
 ],
 "Created": [
  null,
  "Створено"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Disk space": [
  null,
  "Місце на диску"
 ],
 "Used by": [
  null,
  "Використовується"
 ],
 "No images": [
  null,
  "Немає образів"
 ],
 "No images that match the current filter": [
  null,
  "Немає образів, які проходять поточні умови фільтрування"
 ],
 "Hide intermediate images": [
  null,
  "Приховати проміжні образи"
 ],
 "Show intermediate images": [
  null,
  "Показати проміжні образи"
 ],
 "Images": [
  null,
  "Образи"
 ],
 "$0 image total, $1": [
  null,
  "$0 образ загалом, $1",
  "$0 образи загалом, $1",
  "$0 образів загалом, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 невикористаний образ, $1",
  "$0 невикористані образи, $1",
  "$0 невикористаних образів, $1"
 ],
 "Hide images": [
  null,
  "Приховати образи"
 ],
 "Show images": [
  null,
  "Показати образи"
 ],
 "Pulling": [
  null,
  "Отримання даних"
 ],
 "Download new image": [
  null,
  "Отримати новий образ"
 ],
 "Pull all images": [
  null,
  "Отримати усі образи"
 ],
 "Prune unused images": [
  null,
  "Позбутися невикористаних образів"
 ],
 "Pull": [
  null,
  "Отримати"
 ],
 "Up since:": [
  null,
  "Працює з:"
 ],
 "Exited": [
  null,
  "Вийшов"
 ],
 "systemd service": [
  null,
  "служба systemd"
 ],
 "View $0": [
  null,
  "Перегляд $0"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "MAC address": [
  null,
  "MAC-адреса"
 ],
 "Latest checkpoint": [
  null,
  "Найсвіжіша контрольна точка"
 ],
 "No containers are using this image": [
  null,
  "Цей образ не використовує жоден контейнер"
 ],
 "Running": [
  null,
  "Запущено"
 ],
 "Loading logs...": [
  null,
  "Завантаження журналу…"
 ],
 "Delete unused system images:": [
  null,
  "Вилучити невикористані образи системи:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Вилучити невикористані образи користувача $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Не вдалося позбутися невикористаних образів"
 ],
 "Pruning images": [
  null,
  "Позбуваємося образів"
 ],
 "Prune": [
  null,
  "Позбутися"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Не вдалося створити контрольну точку контейнера $0"
 ],
 "Checkpoint container $0": [
  null,
  "Контрольна точка контейнера $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Лишати запущеним після запису контрольної точки на диск"
 ],
 "Support preserving established TCP connections": [
  null,
  "Підтримка збереження встановлених з'єднань TCP"
 ],
 "Failed to search for new images": [
  null,
  "Не вдалося виконати пошук нових образів"
 ],
 "Failed to search for images: $0": [
  null,
  "Не вдалося виконати пошук образів: $0"
 ],
 "Failed to search for images.": [
  null,
  "Не вдалося виконати пошук образів."
 ],
 "Search for an image": [
  null,
  "Шукати образ"
 ],
 "Search for": [
  null,
  "Шукати"
 ],
 "Search by name or description": [
  null,
  "Шукати за назвою і описом"
 ],
 "in": [
  null,
  "у"
 ],
 "All registries": [
  null,
  "Усі реєстри"
 ],
 "Searching...": [
  null,
  "Пошук…"
 ],
 "No images found": [
  null,
  "Образів не знайдено"
 ],
 "Start typing to look for images.": [
  null,
  "Почніть щось вводити, щоб виконати пошук образів."
 ],
 "No results for $0": [
  null,
  "Немає результатів, що відповідають $0"
 ],
 "Retry another term.": [
  null,
  "Повторіть спробу із іншим ключем пошуку."
 ],
 "Download": [
  null,
  "Отримати"
 ],
 "No action": [
  null,
  "Без дії"
 ],
 "Container failed to be started": [
  null,
  "Не вдалося запустити контейнер"
 ],
 "Failed to clean up container": [
  null,
  "Не вдалося очистити контейнер"
 ],
 "Container failed to be created": [
  null,
  "Не вдалося створити контейнер"
 ],
 "downloading": [
  null,
  "отримання"
 ],
 "Failed to run container $0": [
  null,
  "Не вдалося запустити контейнер $0"
 ],
 "Failed to create container $0": [
  null,
  "Не вдалося створити контейнер $0"
 ],
 "Failed to pull image $0": [
  null,
  "Не вдалося отримати образ $0"
 ],
 "Local images": [
  null,
  "Локальні образи"
 ],
 "Name already in use": [
  null,
  "Назву вже використано"
 ],
 "Search by registry": [
  null,
  "Шукати за реєстром"
 ],
 "Local": [
  null,
  "Локальний"
 ],
 "Container name": [
  null,
  "Назва контейнера"
 ],
 "Owner help": [
  null,
  "Довідка щодо власника"
 ],
 "Ideal for running services": [
  null,
  "Ідеальне для запуску служб"
 ],
 "Resource limits can be set": [
  null,
  "Можна встановлювати обмеження на ресурси"
 ],
 "Checkpoint and restore support": [
  null,
  "Підтримка контрольних точок і відновлення"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Можна прив'язувати порти нижче 1024"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "Ideal for development": [
  null,
  "Ідеальне для розробки"
 ],
 "Restricted by user account permissions": [
  null,
  "Обмежено правами доступу до облікового запису користувача"
 ],
 "Image selection help": [
  null,
  "Довідка щодо вибору образу"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "вузол[:порт]/[користувач]/контейнер[:мітка]"
 ],
 "Example: $0": [
  null,
  "Приклад: $0"
 ],
 "Searching: $0": [
  null,
  "Шукаємо: $0"
 ],
 "Search string or container location": [
  null,
  "Рядок для пошуку або розташування контейнера"
 ],
 "Pull latest image": [
  null,
  "Отримати найсвіжіший образ"
 ],
 "Entrypoint": [
  null,
  "Точка входження"
 ],
 "With terminal": [
  null,
  "За допомогою термінала"
 ],
 "Memory limit": [
  null,
  "Обмеження пам’яті"
 ],
 "Decrease memory": [
  null,
  "Зменшити пам'ять"
 ],
 "Increase memory": [
  null,
  "Збільшити пам'ять"
 ],
 "Memory unit": [
  null,
  "Одиниця пам’яті"
 ],
 "KB": [
  null,
  "кБ"
 ],
 "MB": [
  null,
  "МБ"
 ],
 "GB": [
  null,
  "ГБ"
 ],
 "CPU shares": [
  null,
  "Спільне використання процесора"
 ],
 "CPU Shares help": [
  null,
  "Довідка щодо спільних процесорів"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Спільні процесори визначають пріоритетність запуску контейнерів. Типовою пріоритетністю є 1024. Більші числа роблять контейнер пріоритетнішим. Менші числа зменшують пріоритетність."
 ],
 "Decrease CPU shares": [
  null,
  "Зменшити спільне використання процесора"
 ],
 "Increase CPU shares": [
  null,
  "Збільшити спільне використання процесора"
 ],
 "Restart policy": [
  null,
  "Правила перезапуску"
 ],
 "Restart policy help": [
  null,
  "Довідка щодо правил перезапуску"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Перезапускати правила після виходу з контейнерів. Використання очікування для автозапуску контейнерів може за певних обставин не працювати, зокрема воно не працює, якщо для облікового запису користувача використано ecryptfs, systemd-homed, NFS або 2FA."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Правила перезапуску, які слід виконувати при виході з контейнерів."
 ],
 "No": [
  null,
  "Ні"
 ],
 "On failure": [
  null,
  "При помилці"
 ],
 "Always": [
  null,
  "Завжди"
 ],
 "Maximum retries": [
  null,
  "Максимум повторних спроб"
 ],
 "Decrease maximum retries": [
  null,
  "Зменшити максимум повторних спроб"
 ],
 "Increase maximum retries": [
  null,
  "Збільшити максимум повторних спроб"
 ],
 "No environment variables specified": [
  null,
  "Змінних середовища не визначено"
 ],
 "Add variable": [
  null,
  "Додати змінну"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Вставте один або декілька рядків у форматі парт «ключ=значення» до будь-якого поля для пакетного імпортування"
 ],
 "Interval": [
  null,
  "Інтервал"
 ],
 "Health check interval help": [
  null,
  "Довідка з інтервалу перевірки працездатності"
 ],
 "Interval how often health check is run.": [
  null,
  "Частота запуску перевірки працездатності."
 ],
 "Decrease interval": [
  null,
  "Зменшити інтервал"
 ],
 "Increase interval": [
  null,
  "Збільшити інтервал"
 ],
 "seconds": [
  null,
  "секунд"
 ],
 "Timeout": [
  null,
  "Час очікування"
 ],
 "Health check timeout help": [
  null,
  "Довідка з часу очікування перевірки працездатності"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Максимальний припустимий час для завершення перевірки працездатності до моменту реєстрації помилки."
 ],
 "Decrease timeout": [
  null,
  "Зменшити час очікування"
 ],
 "Increase timeout": [
  null,
  "Збільшити час очікування"
 ],
 "Start period": [
  null,
  "Початковий період"
 ],
 "Health check start period help": [
  null,
  "Довідка із початкового періоду перевірки працездатності"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Час ініціалізації, потрібний контейнеру для самозапуску."
 ],
 "Decrease start period": [
  null,
  "Зменшити період запуску"
 ],
 "Increase start period": [
  null,
  "Збільшити початковий період"
 ],
 "Retries": [
  null,
  "Повторні спроби"
 ],
 "Health check retries help": [
  null,
  "Довідка з повторних спроб перевірки працездатності"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Кількість повторних спроб, якими можна скористатися, доки перевірка працездатності вважатиметься непройденою."
 ],
 "Decrease retries": [
  null,
  "Зменшити кількість повторних спроб"
 ],
 "Increase retries": [
  null,
  "Збільшити кількість повторних спроб"
 ],
 "When unhealthy": [
  null,
  "Якщо непрацездатні"
 ],
 "Health failure check action help": [
  null,
  "Довідка щодо дії при перевірці небезпечності стану"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Дія, яку слід виконати після переходу контейнера у небезпечний стан."
 ],
 "Create container in $0": [
  null,
  "Створити контейнер у $0"
 ],
 "Create and run": [
  null,
  "Створити і запустити"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Version": [
  null,
  "Версія"
 ],
 "Links": [
  null,
  "Посилання"
 ],
 "Documentation": [
  null,
  "Документація"
 ],
 "Tags": [
  null,
  "Мітки"
 ],
 "Created by": [
  null,
  "Створено"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Comments": [
  null,
  "Коментарі"
 ],
 "Unable to load image history": [
  null,
  "Не вдалося завантажити журнал образу"
 ],
 "Key must not be empty": [
  null,
  "Ключ має бути непорожнім"
 ],
 "Key must not begin with a digit": [
  null,
  "Ключ не повинен починатися з цифри"
 ],
 "Key contains invalid characters": [
  null,
  "Ключ містить некоректні символи"
 ],
 "Key": [
  null,
  "Ключ"
 ],
 "Value": [
  null,
  "Значення"
 ],
 "user": [
  null,
  "користувач"
 ],
 "Podman service failed": [
  null,
  "Помилка служби Podman"
 ],
 "Troubleshoot": [
  null,
  "Діагностика проблем"
 ],
 "Failed to force remove image $0": [
  null,
  "Не вдалося примусово вилучити образ $0"
 ],
 "intermediate image": [
  null,
  "проміжний образ"
 ],
 "Failed to remove image $0": [
  null,
  "Не вдалося вилучити образ $0"
 ],
 "intermediate": [
  null,
  "проміжний"
 ],
 "Delete $0 image?": [
  null,
  "Вилучити образ $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Для цього образу існує декілька міток. Виберіть позначені міткою образи для вилучення."
 ],
 "Delete image": [
  null,
  "Вилучити образ"
 ],
 "Delete tagged images": [
  null,
  "Вилучити позначені міткою образи"
 ],
 "Container is not running": [
  null,
  "Контейнер не запущено"
 ],
 "Error occurred while connecting console": [
  null,
  "Під час спроби встановити з'єднання з консоллю сталася помилка"
 ],
 "Force delete pod $0?": [
  null,
  "Примусово вилучити кокон $0?"
 ],
 "Delete pod $0?": [
  null,
  "Вилучити кокон $0?"
 ],
 "An error occurred": [
  null,
  "Сталася помилка"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Порожній кокон $0 буде остаточно вилучено."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Вилучення цього кокону призведе до вилучення таких контейнерів:"
 ],
 "Failed to start pod $0": [
  null,
  "Не вдалося запустити кокон $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Не вдалося зупинити кокон $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Не вдалося перезапустити кокон $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Не вдалося відновити кокон $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Не вдалося призупинити кокон $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Не вдалося позбутися невикористаних контейнерів"
 ],
 "Removes selected non-running containers": [
  null,
  "Вилучає позначені незапущені контейнери"
 ],
 "Pruning containers": [
  null,
  "Очищуємо контейнери"
 ],
 "Container name is required.": [
  null,
  "Слід вказати назву контейнера."
 ],
 "Failed to rename container $0": [
  null,
  "Не вдалося перейменувати контейнер $0"
 ],
 "New container name": [
  null,
  "Назва нового контейнера"
 ],
 "Rename container $0": [
  null,
  "Перейменувати контейнер $0"
 ],
 "Paused": [
  null,
  "Призупинено"
 ],
 "Stopped": [
  null,
  "Зупинено"
 ],
 "Removing": [
  null,
  "Вилучення"
 ],
 "Configured": [
  null,
  "Налаштовано"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "$0 second": [
  null,
  "$0 секунда",
  "$0 секунди",
  "$0 секунд"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Failing streak": [
  null,
  "Помилкова смужка"
 ],
 "Failed to run health check on container $0": [
  null,
  "Не вдалося запустити перевірку працездатності контейнера $0"
 ],
 "Run health check": [
  null,
  "Виконати перевірку працездатності"
 ],
 "Last 5 runs": [
  null,
  "Останні 5 запусків"
 ],
 "Started at": [
  null,
  "Запущено"
 ],
 "Passed health run": [
  null,
  "Перевірку працездатності пройдено"
 ],
 "Failed health run": [
  null,
  "Не вдалося запустити перевірку працездатності"
 ],
 "Failed to remove container $0": [
  null,
  "Не вдалося вилучити контейнер $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Вилучення контейнера призведе до витирання усіх даних, що на ньому зберігаються."
 ]
});
