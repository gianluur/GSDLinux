cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "User name": [
  null,
  "Käyttäjänimi"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Comment": [
  null,
  "Kommentti"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Fingerprint": [
  null,
  "Sormenjälki"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Change password": [
  null,
  "Vaihda salasana"
 ],
 "Password changed successfully": [
  null,
  "Salasanan vaihtaminen onnistui"
 ],
 "New password": [
  null,
  "Uusi salasana"
 ],
 "Confirm password": [
  null,
  "Vahvista salasana"
 ],
 "Password tip": [
  null,
  "Salasanan vihje"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Vinkki: Aseta avaimesi salasana samaksi kuin käyttäjätunnuksesi salasana, jotta voit automaattisesti tunnistautua muita järjestelmiä kohden."
 ],
 "Unlock key $0": [
  null,
  "Avaa avaimen $0 lukitus"
 ],
 "Unlock": [
  null,
  "Avaa"
 ],
 "Add private SSH key": [
  null,
  "Lisää SSH-avain"
 ],
 "Add key": [
  null,
  "Lisää avain"
 ],
 "SSH keys": [
  null,
  "SSH-avaimet"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Käytä seuraavia avaimia todentamaan muita järjestelmiä kohden"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Toggle": [
  null,
  "Vaihda"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Public key": [
  null,
  "Julkinen avain"
 ],
 "Use key": [
  null,
  "Käytä avainta"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Hosts": [
  null,
  "Koneet"
 ],
 "Connection error": [
  null,
  "Yhteysvirhe"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Add new host": [
  null,
  "Lisää uusi kone"
 ],
 "Host": [
  null,
  "Kone"
 ],
 "Stop editing hosts": [
  null,
  "Lopeta koneiden muokkaaminen"
 ],
 "Edit hosts": [
  null,
  "Muokkaa koneita"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "Active pages": [
  null,
  "Aktiiviset sivut"
 ],
 "Page name": [
  null,
  "Sivun nimi"
 ],
 "There are currently no active pages": [
  null,
  "Tällä hetkellä ei ole aktiivisia sivuja"
 ],
 "Close selected pages": [
  null,
  "Sulje valitut sivut"
 ],
 "$0 documentation": [
  null,
  "$0 -dokumentaatio"
 ],
 "About Web Console": [
  null,
  "Tietoja Verkkokonsolista"
 ],
 "Style": [
  null,
  "Tyyli"
 ],
 "Default": [
  null,
  "Oletus"
 ],
 "Light": [
  null,
  "Vaalea"
 ],
 "Dark": [
  null,
  "Tumma"
 ],
 "Display language": [
  null,
  "Käytettävä kieli"
 ],
 "Log out": [
  null,
  "Kirjaudu ulos"
 ],
 "Ooops!": [
  null,
  "Hups!"
 ],
 "Help": [
  null,
  "Ohje"
 ],
 "Session": [
  null,
  "Istunto"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Käytetään GNU LGPL -versio 2.1 lisenssiä"
 ],
 "Web Console": [
  null,
  "Verkkokonsoli"
 ],
 "Web console logo": [
  null,
  "Verkkokonsolilogo"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit on vuorovaikutteinen Linux-palvelimen ylläpitäjän käyttöliittymä."
 ],
 "Project website": [
  null,
  "Projektin verkkosivusto"
 ],
 "Loading packages...": [
  null,
  "Ladataan paketteja..."
 ],
 "Choose the language to be used in the application": [
  null,
  "Valitse sovelluksessa käytettävä kieli"
 ],
 "Filter menu items": [
  null,
  "Suodata valikkokohteita"
 ],
 "No languages match": [
  null,
  "Ei hakua vastaavia kieliä"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "Unexpected error": [
  null,
  "Odottamaton virhe"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpitissa oli odottamaton sisäinen virhe."
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Vaihto-I"
 ],
 "in most browsers": [
  null,
  "useimmissa selaimissa"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "Search": [
  null,
  "Haku"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "Clear search": [
  null,
  "Tyhjennä haku"
 ],
 "Contains:": [
  null,
  "Sisältää:"
 ],
 "Apps": [
  null,
  "Sovellukset"
 ],
 "Tools": [
  null,
  "Työkalut"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Annettuun koneeseen $0 ei voida ottaa yhteyttä. Varmista, että ssh on käynnissä portissa $1, tai määritä toinen portti osoitteeseen."
 ],
 "Connect to $0?": [
  null,
  "Yhdistetäänkö $0:aan?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Yhdistetyt isännät voivat hallita toisiaan täysin. Tämä sisältää sellaisten ohjelmien suorittamisen, jotka voivat vahingoittaa järjestelmääsi tai varastaa tietoja. Yhdistä vain luotettuihin koneisiin."
 ],
 "Read more": [
  null,
  "Lue lisää"
 ],
 "You will be reminded once per session.": [
  null,
  "Saat muistutuksen kerran istuntoa kohden."
 ],
 "Connect": [
  null,
  "Yhdistä"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-osoite tai konenimi ei voi sisältää välilyöntiä."
 ],
 "This machine has already been added.": [
  null,
  "Tämä kone on jo lisätty."
 ],
 "Failed to add machine: $0": [
  null,
  "Ei voitu lisätä konetta: $0"
 ],
 "Edit host": [
  null,
  "Muokkaa konetta"
 ],
 "Set": [
  null,
  "Aseta"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Voi olla konenimi, IP-osoite, aliaksen nimi tai ssh:// URI"
 ],
 "When empty, connect with the current user": [
  null,
  "Tyhjänä ollessa, muodosta yhteys nykyisenä käyttäjänä"
 ],
 "Color": [
  null,
  "Väri"
 ],
 "Failed to edit machine: $0": [
  null,
  "Koneen muokkaaminen epäonnistui: $0"
 ],
 "Could not contact $0": [
  null,
  "Ei saatu yhteyttä kohteeseen $0"
 ],
 "Update": [
  null,
  "Päivitä"
 ],
 "Unable to contact $0.": [
  null,
  "Ei saada yhteyttä kohteeseen $0."
 ],
 "Is sshd running on a different port?": [
  null,
  "Onko sshd käynnissä eri portissa?"
 ],
 "Port": [
  null,
  "Portti"
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "New host: $0": [
  null,
  "Uusi isäntä: $0"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Etäkoneen haitalliset sivut voivat vaikuttaa muihin yhdistettyihin isänteihin"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "The new key password can not be empty": [
  null,
  "Uuden avaimen salasana ei voi olla tyhjä"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Ei voida kirjautua sisään koneelle $0 SSH-avaimella. Anna salasana. Haluat ehkä määrittää SSH-avaimesi automaattista kirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Haluat ehkä vaihtaa avaimen salasanan automaattista sisäänkirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Jos haluat sallia sisäänkirjautumisen koneelle $0 käyttäjänä $1 ilman salasanaa tulevaisuudessa, käytä käyttäjän $2 sisäänkirjautumissalasanaa koneen $3 avainsalasanana tai jätä avaimen salasana tyhjäksi."
 ],
 "Change the password of $0": [
  null,
  "Vaihda avaimen $0 salasana"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Vaihtamalla SSH-avaimen $0 salasanan käyttäjän $1 kirjautumissalasanaksi koneella $2, avain tulee automaattisesti saataville ja voit kirjautua sisään koneelle $3 jatkossa ilman salasanaa."
 ],
 "New key password": [
  null,
  "Uuden avaimen salasana"
 ],
 "Confirm new key password": [
  null,
  "Vahvista uusi avaimen salasana"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Tämän avulla voit tulevaisuudessa kirjautua sisään ilman salasanaa."
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "Automatic login": [
  null,
  "Automaattinen sisäänkirjautuminen"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sinut on kirjautunut ulos toimimattomuuden vuoksi."
 ],
 "Connection failed": [
  null,
  "Yhteys epäonnistui"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Laitteeseen yhdistämisessä tapahtui odottamaton virhe."
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Virheeseen liittyvät viestit saattavat löytyä päiväkirjasta:"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safarin käyttäjien on tuotava itse allekirjoittavan varmentajan varmenne ja luotettava siihen:"
 ],
 "Reconnect": [
  null,
  "Yhdistä uudelleen"
 ],
 "Disconnected": [
  null,
  "Katkaistu"
 ],
 "The machine is rebooting": [
  null,
  "Kone käynnistyy uudelleen"
 ],
 "Connecting to the machine": [
  null,
  "Yhdistetään koneeseen"
 ],
 "Not connected to host": [
  null,
  "Ei yhdistetty koneeseen"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Ei voida yhdistää tuntemattomaan koneeseen"
 ],
 "Session is about to expire": [
  null,
  "Istunto on päättymässä"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Sinut kirjataan ulos $0 sekunnin kuluttua."
 ],
 "Continue session": [
  null,
  "Jatka istuntoa"
 ],
 "Skip to content": [
  null,
  "Siirry sisältöön"
 ],
 "Skip main navigation": [
  null,
  "Ohita päävalikko"
 ],
 "Permission denied": [
  null,
  "Käyttö estetty"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Hallinnollisen pääsyn saamiseksi ei ole käytettävissä menetelmiä ('sudo -A', 'pkexec')."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit raportoi virhekoodin $0"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Error during initialization": [
  null,
  "Virhe alustuksen aikana"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Home": [
  null,
  "Koti"
 ],
 "Downloads": [
  null,
  "Lataukset"
 ],
 "Not a directory": [
  null,
  "Ei ole hakemisto"
 ],
 "All files": [
  null,
  "Kaikki tiedostot"
 ],
 "Recent": [
  null,
  "Viimeaikaiset"
 ],
 "No recent directories": [
  null,
  "Ei hiljattain käytettyjä hakemistoja"
 ],
 "No recent files": [
  null,
  "Ei hiljattain käytettyjä tiedostoja"
 ],
 "Type to filter": [
  null,
  "Kirjoita suodattaaksesi"
 ],
 "File chooser actions": [
  null,
  "Tiedostonvalitsimen toiminnot"
 ],
 "Open in file browser": [
  null,
  "Avaa tiedostoselaimessa"
 ],
 "Hide hidden files": [
  null,
  "Piilota piilotetut tiedostot"
 ],
 "Show hidden files": [
  null,
  "Näytä piilotetut tiedostot"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Clear filters": [
  null,
  "Tyhjennä suodattimet"
 ],
 "Directory is empty": [
  null,
  "Hakemisto on tyhjä"
 ],
 "Directory has no sub-directories": [
  null,
  "Hakemistossa ei ole alihakemistoja"
 ],
 "This directory contains only hidden files": [
  null,
  "Tämä hakemisto sisältää vain piilotiedostoja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "Folder": [
  null,
  "Kansio"
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ]
});
