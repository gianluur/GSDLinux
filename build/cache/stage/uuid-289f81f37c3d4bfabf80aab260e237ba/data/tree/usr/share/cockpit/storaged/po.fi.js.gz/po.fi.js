cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Server": [
  null,
  "Palvelin"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Unlock": [
  null,
  "Avaa"
 ],
 "Add key": [
  null,
  "Lisää avain"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "Set": [
  null,
  "Aseta"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Port": [
  null,
  "Portti"
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "Permission denied": [
  null,
  "Käyttö estetty"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Hallinnollisen pääsyn saamiseksi ei ole käytettävissä menetelmiä ('sudo -A', 'pkexec')."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit raportoi virhekoodin $0"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Error during initialization": [
  null,
  "Virhe alustuksen aikana"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Home": [
  null,
  "Koti"
 ],
 "Downloads": [
  null,
  "Lataukset"
 ],
 "Not a directory": [
  null,
  "Ei ole hakemisto"
 ],
 "All files": [
  null,
  "Kaikki tiedostot"
 ],
 "Recent": [
  null,
  "Viimeaikaiset"
 ],
 "No recent directories": [
  null,
  "Ei hiljattain käytettyjä hakemistoja"
 ],
 "No recent files": [
  null,
  "Ei hiljattain käytettyjä tiedostoja"
 ],
 "Type to filter": [
  null,
  "Kirjoita suodattaaksesi"
 ],
 "File chooser actions": [
  null,
  "Tiedostonvalitsimen toiminnot"
 ],
 "Open in file browser": [
  null,
  "Avaa tiedostoselaimessa"
 ],
 "Hide hidden files": [
  null,
  "Piilota piilotetut tiedostot"
 ],
 "Show hidden files": [
  null,
  "Näytä piilotetut tiedostot"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Clear filters": [
  null,
  "Tyhjennä suodattimet"
 ],
 "Directory is empty": [
  null,
  "Hakemisto on tyhjä"
 ],
 "Directory has no sub-directories": [
  null,
  "Hakemistossa ei ole alihakemistoja"
 ],
 "This directory contains only hidden files": [
  null,
  "Tämä hakemisto sisältää vain piilotiedostoja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "Folder": [
  null,
  "Kansio"
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "View logs": [
  null,
  "Katso lokit"
 ],
 "Dismiss": [
  null,
  "Hylkää"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "Model": [
  null,
  "Malli"
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "Not found": [
  null,
  "Ei löytynyt"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "Not running": [
  null,
  "Ei käynnissä"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "Vendor": [
  null,
  "Toimittaja"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Confirm deletion of $0": [
  null,
  "Vahvista kohteen $0 poistaminen"
 ],
 "Username": [
  null,
  "Käyttäjätunnus"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Started": [
  null,
  "Aloitettu"
 ],
 "Delete group": [
  null,
  "Poista ryhmä"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Lock": [
  null,
  "Lukitse"
 ],
 "Use $0": [
  null,
  "Käytä $0:a"
 ],
 "Service": [
  null,
  "Palvelu"
 ],
 "Disconnect": [
  null,
  "Katkaise yhteys"
 ],
 "Address": [
  null,
  "Osoite"
 ],
 "$0 disk is missing": [
  null,
  "$0 levyä ei löydy",
  "$0 levyjä ei löydy"
 ],
 "Location": [
  null,
  "Sijainti"
 ],
 "Compression": [
  null,
  "Pakkaus"
 ],
 "Storage logs": [
  null,
  "Tallennustilan lokit"
 ],
 "Name cannot be empty.": [
  null,
  "Nimi ei voi olla tyhjä."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nimi voi sisältää enintään 127 merkkiä."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nimi ei voi sisältää merkkiä '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nimi ei voi sisältää välilyöntiä."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nimi voi sisältää enintään $0 merkkiä"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nimi voi olla enintään $0 tavua pitkä"
 ],
 "$name (from $host)": [
  null,
  "$name (kohteesta $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Varanto ohuita loogisia taltioita varten"
 ],
 "Thin logical volume": [
  null,
  "Ohut looginen taltio"
 ],
 "Logical volume (snapshot)": [
  null,
  "Looginen taltio (tilannevedos)"
 ],
 "Logical volume": [
  null,
  "Looginen taltio"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID-laite $0"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2-taltioryhmä $0"
 ],
 "VDO device $0": [
  null,
  "VDO-laite $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Salattu looginen taltio $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Salattu osio $0"
 ],
 "Logical volume of $0": [
  null,
  "$0:n looginen taltio"
 ],
 "Partition of $0": [
  null,
  "$0:n osio"
 ],
 "Encrypted $0": [
  null,
  "Salattu $0"
 ],
 "unpartitioned space on $0": [
  null,
  "osioimaton tila levyllä $0"
 ],
 "unmount": [
  null,
  "irrota"
 ],
 "mount": [
  null,
  "liitos"
 ],
 "remove from btrfs volume": [
  null,
  "poista btrfstaltiosta"
 ],
 "stop": [
  null,
  "pysäytä"
 ],
 "remove from MDRAID": [
  null,
  "poista MDRAID:ista"
 ],
 "remove from LVM2": [
  null,
  "poista LVM2:sta"
 ],
 "btrfs device": [
  null,
  "btrfs-laite"
 ],
 "btrfs volume": [
  null,
  "Btrfs-taltio"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Nimi voi sisältää enintään 255 merkkiä."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Nimi ei voi sisältää merkkiä '/'."
 ],
 "Create and mount": [
  null,
  "Luo ja liitä"
 ],
 "Create only": [
  null,
  "Vain luominen"
 ],
 "Create subvolume": [
  null,
  "Luo alitaltio"
 ],
 "Mount Point": [
  null,
  "Liitoskohta"
 ],
 "delete": [
  null,
  "pyyhki pois"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Poistetaanko alitaltio $0 pysyvästi?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Poistaminen tyhjentää kaikki tämän alitaltion tiedot ja kaikki sen lapset."
 ],
 "Edit mount point": [
  null,
  "Muokkaa liitoskohtaa"
 ],
 "Unmount": [
  null,
  "Irroita"
 ],
 "Mount": [
  null,
  "Liitos"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Ainakin yksi alitaltio on liitettävä"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Viimeksi liitettyä alitaltiota ei voida poistaa"
 ],
 "btrfs subvolume": [
  null,
  "Btrfs-alataltio"
 ],
 "Snapshot origin": [
  null,
  "Tilannevedoksen alkuperä"
 ],
 "Mount point": [
  null,
  "Liitoskohta"
 ],
 "No subvolumes": [
  null,
  "Ei alitaltioita"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs-alitaltiot"
 ],
 "Snapshots": [
  null,
  "Tilannevedokset"
 ],
 "No snapshots found": [
  null,
  "Tilannevedoksia ei löytynyt"
 ],
 "snapshot": [
  null,
  "tilannevedos"
 ],
 "$0 is in use": [
  null,
  "$0 on käytössä"
 ],
 "Permanently delete $0?": [
  null,
  "Poista $0 pysyvästi?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Pyyhkiminen poistaa kaikki btrfs-taltiossa olevat tiedot."
 ],
 "Delete filesystem": [
  null,
  "Poista tiedostojärjestelmä"
 ],
 "Change label": [
  null,
  "Vaihda nimiö"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Tiedostojärjestelmä on liitetty vain luku -tilassa"
 ],
 "Label": [
  null,
  "Nimiö"
 ],
 "Capacity": [
  null,
  "Koko"
 ],
 "btrfs devices": [
  null,
  "btrfs-laitteet"
 ],
 "No devices found": [
  null,
  "Laitteita ei löytynyt"
 ],
 "btrfs filesystem": [
  null,
  "btrfs-tiedostojärjestelmä"
 ],
 "Successful": [
  null,
  "Onnistui"
 ],
 "Aborted": [
  null,
  "Keskeytetty"
 ],
 "In progress": [
  null,
  "Meneillään"
 ],
 "Interrupted": [
  null,
  "Keskeytetty"
 ],
 "Did not complete": [
  null,
  "Ei suoritettu loppuun"
 ],
 "Failed (Unknown)": [
  null,
  "Epäonnistui (tuntematon)"
 ],
 "Failed (Electrical)": [
  null,
  "Epäonnistui (sähköinen)"
 ],
 "Failed (Servo)": [
  null,
  "Epäonnistui (servo)"
 ],
 "Failed (Read)": [
  null,
  "Epäonnistui (Luku)"
 ],
 "Failed (Damaged)": [
  null,
  "Epäonnistui (vaurioitunut)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Keskeytetty ohjaimen tason nollauksella"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Keskeytetty nimitilan poistamisen vuoksi nimitilan inventaariosta"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Keskeytetty Format NVM -komennon käsittelyn vuoksi"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Tapahtui vakava virhe itsetestauksen toiminnan aikana"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Valmistui epäonnistuneella segmentillä ja epäonnistunutta segmenttiä ei tunneta"
 ],
 "Completed with one or more failed segments": [
  null,
  "Täydennetty yhdellä tai useammalla epäonnistuneella segmentillä"
 ],
 "Aborted for unknown reason": [
  null,
  "Keskeytetty tuntemattomasta syystä"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Keskeytetty puhdistustoimenpiteen vuoksi"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Varakapasiteetti on alle kynnyksen"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Lämpötila suositeltujen kynnysten ulkopuolella"
 ],
 "Degraded": [
  null,
  "Huonontunut"
 ],
 "All media is in read-only mode": [
  null,
  "Koko media on vain luku -tilassa"
 ],
 "Volatile memory backup failed": [
  null,
  "Haihtuvan muistin varmuuskopioiminen epäonnistui"
 ],
 "Persistent memory has become read-only": [
  null,
  "Pysyvästä muistista on tullut vain luku"
 ],
 "Run short test": [
  null,
  "Suorita lyhyt testi"
 ],
 "Run extended test": [
  null,
  "Suorita laajennettu testi"
 ],
 "Abort test": [
  null,
  "Peru testi"
 ],
 "Disk is failing": [
  null,
  "Levy on rikkoutumassa"
 ],
 "Disk is OK": [
  null,
  "Levy on kunnossa"
 ],
 "Assessment": [
  null,
  "Arviointi"
 ],
 "Power on hours": [
  null,
  "Käynnissäolotunnit"
 ],
 "$0 hours": [
  null,
  "$0 tuntia"
 ],
 "Self-test status": [
  null,
  "Itsetestauksen tila"
 ],
 "Number of bad sectors": [
  null,
  "Viallisten sektorien määrä"
 ],
 "Attributes failing": [
  null,
  "Attribuutit epäonnistuvat"
 ],
 "Media drive": [
  null,
  "Media-asema"
 ],
 "Solid State Drive": [
  null,
  "Solid State Drive -levy"
 ],
 "Hard Disk Drive": [
  null,
  "Kiintolevyasema"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI-asema"
 ],
 "Drive": [
  null,
  "Asema"
 ],
 "Device health (SMART)": [
  null,
  "Laitteen kunto (SMART)"
 ],
 "Firmware version": [
  null,
  "Laiteohjelmiston versio"
 ],
 "Serial number": [
  null,
  "Sarjanumero"
 ],
 "World wide name": [
  null,
  "Maailmanlaajuinen nimi"
 ],
 "No media inserted": [
  null,
  "Ei välinettä asetettuna"
 ],
 "Device file": [
  null,
  "Laitetiedosto"
 ],
 "Multipathed devices": [
  null,
  "Monipolkuiset laitteet"
 ],
 "Free space": [
  null,
  "Vapaa tila"
 ],
 "Create partition": [
  null,
  "Luo osio"
 ],
 "Extended partition": [
  null,
  "Laajennettu osio"
 ],
 "$0 partitions": [
  null,
  "$0 osiota"
 ],
 "Partitions": [
  null,
  "Osiot"
 ],
 "No partitions found": [
  null,
  "Osioita ei löytynyt"
 ],
 "Unexpected partitions": [
  null,
  "Odottamattomat osiot"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Tässä lohkolaitteessa ei tueta osioita. Jos sitä käytetään virtuaalikoneen levynä, käyttöjärjestelmän on hallittava osioita virtuaalikoneen sisällä."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Osion poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "No free space after this partition": [
  null,
  "Ei vapaata tilaa tämän osion jälkeen"
 ],
 "EFI system partition": [
  null,
  "EFI-järjestelmäosio"
 ],
 "BIOS boot partition": [
  null,
  "BIOS-käynnistysosio"
 ],
 "Partition": [
  null,
  "Osio"
 ],
 "Shrink": [
  null,
  "Kutista"
 ],
 "Grow": [
  null,
  "Kasvata"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP -käynnistysosio"
 ],
 "Linux swap space": [
  null,
  "Linuxin sivutuksen tila"
 ],
 "Linux filesystem data": [
  null,
  "Linuxin tiedostojärjestelmän tiedot"
 ],
 "Logical Volume Manager partition": [
  null,
  "Loogisen taltion hallinta (LVM)-osio"
 ],
 "Custom": [
  null,
  "Mukautettu"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tyypin tulee sisältää täsmälleen kaksi heksadesimaalimerkkiä (0–9, A–F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tyyppi voi sisältää vain merkkejä 0–9, A–F ja \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tyypin on oltava muotoa NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Set partition type of $0": [
  null,
  "Aseta osion tyypiksi $0"
 ],
 "Custom type": [
  null,
  "Mukautettu tyyppi"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Osiotyyppien muuttaminen saattaa estää järjestelmää käynnistymästä."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Sisältö ei käytä tätä osiota kokonaan."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Osion koko on $0. Sisällön koko on $1."
 ],
 "Shrink partition": [
  null,
  "Kutista osio"
 ],
 "Grow content": [
  null,
  "Kasvata sisältöä"
 ],
 "initialize": [
  null,
  "alusta"
 ],
 "Initialize disk $0": [
  null,
  "Alusta levy $0"
 ],
 "Partitioning": [
  null,
  "Osiointi"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Yhteensopiva kaikkien järjestelmien ja laitteiden kanssa (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Yhteensopiva modernien järjestelmien ja kovalevyjen kanssa > 2 Tt (GPT)"
 ],
 "No partitioning": [
  null,
  "Ei osiointia"
 ],
 "Overwrite": [
  null,
  "Korvaa"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Korvaa olemassa olevat tiedot nollilla (hitaampi)"
 ],
 "Initialize": [
  null,
  "Alusta"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Taltion alustaminen tuhoaa kaikki sillä olevat tiedot."
 ],
 "Device is read-only": [
  null,
  "Laite on vain-luku-muotoa"
 ],
 "Create partition table": [
  null,
  "Luo osiotaulukko"
 ],
 "Size must be a number": [
  null,
  "Koon on oltava numero"
 ],
 "Size cannot be zero": [
  null,
  "Koko ei voi olla nolla"
 ],
 "Size cannot be negative": [
  null,
  "Koko ei voi olla negatiivinen"
 ],
 "Size is too large": [
  null,
  "Koko on liian suuri"
 ],
 "Size must be at least $0": [
  null,
  "Koon tulee olla vähintään $0"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2-taltioryhmän fyysinen taltio"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID-laitteen jäsen"
 ],
 "backing device for VDO device": [
  null,
  "taustalaite VDO-laitteelle"
 ],
 "member of Stratis pool": [
  null,
  "Stratis-varannon jäsen"
 ],
 "Filesystem outside the target": [
  null,
  "Tiedostojärjestelmä kohteen ulkopuolella"
 ],
 "device of btrfs volume": [
  null,
  "btrfs-taltion laite"
 ],
 "This device is currently in use.": [
  null,
  "Tämä laite on tällä hetkellä käytössä."
 ],
 "Device": [
  null,
  "Laite"
 ],
 "Use": [
  null,
  "Käytä"
 ],
 "Services using the location": [
  null,
  "Palvelut, jotka käyttävät sijaintia"
 ],
 "Processes using the location": [
  null,
  "Prosessit, jotka käyttävät sijaintia"
 ],
 "Currently in use": [
  null,
  "Tällä hetkellä käytössä"
 ],
 "(Not part of target)": [
  null,
  "(Ei osa kohdetta)"
 ],
 "These changes will be made:": [
  null,
  "Nämä muutokset tullaan tekemään:"
 ],
 "Action": [
  null,
  "Toiminto"
 ],
 "Important data might be deleted:": [
  null,
  "Tärkeitä tietoja saatetaan poistaa:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Liittyvät prosessit ja palvelut lopetetaan väkisin."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Liittyvät prosessit lopetetaan väkisin."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Liittyvät palvelut lopetetaan väkisin."
 ],
 "Checking filesystem usage": [
  null,
  "Tarkistetaan tiedostojärjestelmän käyttöä"
 ],
 "$0 used, $1 total": [
  null,
  "$0 käytetty, $1 yhteensä"
 ],
 "Device contains unrecognized data": [
  null,
  "Laite sisältää tuntemattomia tietoja"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Lukittu salattu laite saattaa sisältää tietoja"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Vahvistan, että haluan menettää nämä tiedot lopullisesti"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Liitoskohta $0 on näiden prosessien käytössä:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Liitoskohta $0 on näiden palveluiden käytössä:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Listatut prosessit ja palvelut lopetetaan väkisin."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Listatut palvelut lopetetaan väkisin."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Listatut palvelut lopetetaan väkisin."
 ],
 "Sorry": [
  null,
  "Pahoittelut"
 ],
 "Usage of $0": [
  null,
  "$0 käyttö"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO -varanto"
 ],
 "Data used": [
  null,
  "Dataa käytetty"
 ],
 "Metadata used": [
  null,
  "Metadataa käytetty"
 ],
 "Use compression": [
  null,
  "Käytä pakkausta"
 ],
 "Deduplication": [
  null,
  "Päällekkäisyyden poisto"
 ],
 "Use deduplication": [
  null,
  "Käytä päällekkäisyyden poistoa"
 ],
 "Rename volume group": [
  null,
  "Nimeä uudelleen taltioryhmä"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Tämä taltioryhmä sisältää juuritiedostojärjestelmän. Sen uudelleennimeäminen saattaa vaatia lisämuutoksia käynnistyslataimen asetuksiin tai ytimen komentoriville."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Poistaminen poistaa kaikki taltioryhmässä olevat tiedot."
 ],
 "Create snapshot": [
  null,
  "Luo tilannevedos"
 ],
 "Add disks": [
  null,
  "Lisää levyjä"
 ],
 "Disks": [
  null,
  "Levyt"
 ],
 "No disks are available.": [
  null,
  "Levyjä ei ole saatavilla."
 ],
 "At least one disk is needed.": [
  null,
  "Vähintään yksi levy tarvitaan."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Taltioryhmästä puuttuu fyysisiä taltioita"
 ],
 "No free space": [
  null,
  "Ei vapaata tilaa"
 ],
 "LVM2 volume group": [
  null,
  "LVM-taltioryhmä"
 ],
 "Add physical volume": [
  null,
  "Lisää fyysinen taltio"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 loogiset taltiot"
 ],
 "Create new logical volume": [
  null,
  "Luo uusi looginen taltio"
 ],
 "No logical volumes": [
  null,
  "Ei loogisia taltioita"
 ],
 "Remove missing physical volumes?": [
  null,
  "Poistetaanko puuttuvat fyysiset taltiot?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Tästä taltioryhmästä puuttuu joitain fyysisiä taltioita."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Taltioryhmää, josta puuttuu fyysisiä asemia, ei voi nimetä uudelleen."
 ],
 "Physical volumes": [
  null,
  "Fyysiset taltiot"
 ],
 "No physical volumes found": [
  null,
  "Fyysisiä taltioita ei löytynyt"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fyysiset taltiot"
 ],
 "Rename logical volume": [
  null,
  "Nimeä uudelleen looginen taltio"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Poistetaanko looginen taltio $0/$1 pysyvästi?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Loogisen taltion poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Loogista asemaa $0 ei voida korjata"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Ei ole tarpeeksi tilaa, jota voitaisiin käyttää korjaukseen. Vähintään $0 tarvitaan fyysisille taltioille, joita ei vielä käytetä tälle loogiselle taltiolle."
 ],
 "An additional $0 must be selected": [
  null,
  "Ylimääräinen $0 on valittava"
 ],
 "Repair logical volume $0": [
  null,
  "Korjaa looginen taltio $0"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Valitse fyysiset taltiot, joita tulee käyttää loogisen taltion korjaamiseen. Vähintään $0 tarvitaan."
 ],
 "Physical Volumes": [
  null,
  "Fyysiset taltiot"
 ],
 "Repair": [
  null,
  "Korjaa"
 ],
 "deactivate": [
  null,
  "Deaktivoi"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Poistetaanko loogisen taltion $0/$1 käytöstä?"
 ],
 "Deactivate": [
  null,
  "Deaktivoi"
 ],
 "Not enough space to grow": [
  null,
  "Ei tarpeeksi tilaa kasvaa"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 looginen taltio"
 ],
 "Striped (RAID 0)": [
  null,
  "Raidallinen (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Peilattu (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Raidallinen ja peilattu (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Varattu pariteetti (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Hajautettu pariteetti (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Kaksoishajautettu pariteetti (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Sisältö ei käytä tätä loogista taltiota kokonaan."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Taltion koko on $0. Sisällön koko on $1."
 ],
 "Shrink volume": [
  null,
  "Kutista taltio"
 ],
 "Layout": [
  null,
  "Asettelu"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Tämä looginen taltio on menettänyt osan fyysisistä taltioistaan, eikä sitä voi enää käyttää. Sinun on poistettava se ja luotava uusi tilalle."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Tämä looginen taltio on menettänyt osan fyysisistä taltioistaan mutta ei ole vielä menettänyt mitään tietoja. Sinun tulee korjata se alkuperäisen redundanssin palauttamiseksi."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Tämä looginen taltio on menettänyt osan fyysisistä taltioistaan mutta ei ehkä ole vielä menettänyt mitään tietoja. Voit ehkä korjata sen."
 ],
 "Stripes": [
  null,
  "Raidat"
 ],
 "$0 synchronized": [
  null,
  "$0 synkronisoitu"
 ],
 "Create volume group": [
  null,
  "Luo taltioryhmä"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fyysinen taltio"
 ],
 "Last cannot be removed": [
  null,
  "Viimeistä ei voida poistaa"
 ],
 "Not enough free space": [
  null,
  "Ei tarpeeksi levytilaa vapaana"
 ],
 "Volume group": [
  null,
  "Taltioryhmä"
 ],
 "Create thin volume": [
  null,
  "Luo ohut taltio"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Ohuesti varustetut loogiset LVM2-taltiot"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Luo uusi ohuesti varusteltu looginen taltio"
 ],
 "Not enough space": [
  null,
  "Ei tarpeeksi tilaa"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Varanto ohuesti varustetuille LVM2-loogisille taltioille"
 ],
 "Inactive logical volume": [
  null,
  "Ei-aktiivinen looginen taltio"
 ],
 "Activate": [
  null,
  "Aktivoi"
 ],
 "Unsupported logical volume": [
  null,
  "Ei-tuettu looginen taltio"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "SISÄINEN VIRHE - Tämä looginen taltio on merkitty aktiiviseksi ja siihen pitäisi liittyä estolaite. Tällaista lohkolaitetta ei kuitenkaan löytynyt."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Paketin $0 asentaminen poistaa paketin $1."
 ],
 "Installing packages": [
  null,
  "Asennetaan paketit"
 ],
 "Block device for filesystems": [
  null,
  "Lohkolaite tiedostojärjestelmille"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Varanto ohuesti varattuja taltioita varten"
 ],
 "Linear": [
  null,
  "Lineaarinen"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-tiedostojärjestelmän taltio (pakkaus/kopioiden poisto)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Tiedot tallennetaan valituille fyysisille taltioille ilman ylimääräisiä redundanssia tai suorituskyvyn parannuksia."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Tiedot tallennetaan valituille fyysisille taltioille vuorotellen suorituskyvyn parantamiseksi. Vähintään kaksi taltiota on valittava."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Tiedot tallennetaan kahtena tai useampana kopiona valituille fyysisille taltioille luotettavuuden parantamiseksi. Vähintään kaksi taltiota on valittava."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Tiedot tallennetaan kahtena kopiona ja myös vuorotellen valituille fyysisille määrille luotettavuuden ja suorituskyvyn parantamiseksi. Vähintään neljä taltiota on valittava."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Tiedot tallennetaan valituille fyysisille taltioille, jotta yksi niistä voidaan menettää vaikuttamatta tietoihin. Vähintään kolme taltiota on valittava."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Tiedot tallennetaan valituille fyysisille taltioille, jotta yksi niistä voidaan menettää vaikuttamatta tietoihin. Tietoja tallennetaan myös vuorotellen suorituskyvyn parantamiseksi. Vähintään kolme taltiota on valittava."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Tiedot tallennetaan valituille fyysisille taltioille, jotta niistä voidaan menettää jopa kaksi samanaikaisesti vaikuttamatta tietoihin. Tietoja tallennetaan myös vuorotellen suorituskyvyn parantamiseksi. Vähintään viisi taltiota on valittava."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Kaikki $0 valitut fyysiset taltiot tarvitaan valittuun asetteluun."
 ],
 "Create logical volume": [
  null,
  "Luo looginen taltio"
 ],
 "Purpose": [
  null,
  "Tarkoitus"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paketti $0 asennetaan VDO-laitteiden luomiseksi."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 tarvitsee parillisen määrän fyysisiä taltioita"
 ],
 "Logical size": [
  null,
  "Looginen koko"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Säästä tilaa pakkaamalla yksittäisiä lohkoja LZ4:llä"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Säästä tilaa tallentamalla identtiset tietolohkot vain kerran"
 ],
 "Creating VDO device": [
  null,
  "Luodaan VDO-laitetta"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Tämä NFS-liitos on käytössä ja vain sen valintoja on mahdollista muokata."
 ],
 "NFS mount": [
  null,
  "NFS-liitos"
 ],
 "New NFS mount": [
  null,
  "Uusi NFS-liitos"
 ],
 "Server address": [
  null,
  "Palvelimen osoite"
 ],
 "Server cannot be empty.": [
  null,
  "Palvelin ei voi olla tyhjä."
 ],
 "Path on server": [
  null,
  "Polku palvelimella"
 ],
 "Path on server cannot be empty.": [
  null,
  "Polku palvelimella ei voi olla tyhjä."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Polun palvelimella täytyy alkaa \"/\"."
 ],
 "Local mount point": [
  null,
  "Paikallinen liitoskohta"
 ],
 "Mount point cannot be empty.": [
  null,
  "Liitoskohta ei voi olla tyhjä."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Liitoskohdan täytyy alkaa \"/\":lla."
 ],
 "Mount options": [
  null,
  "Liitosvalinnat"
 ],
 "Mount at boot": [
  null,
  "Liitä käynnistyksen yhteydessä"
 ],
 "Mount read only": [
  null,
  "Liitä vain luku -tilassa"
 ],
 "Custom mount options": [
  null,
  "Mukautetut liitosvalinnat"
 ],
 "Unable to unmount filesystem": [
  null,
  "Tiedostojärjestelmää ei voi irrottaa"
 ],
 "Stop and unmount": [
  null,
  "Pysäytä ja irrota"
 ],
 "Unable to remove mount": [
  null,
  "Liitosta ei voi poistaa"
 ],
 "Stop and remove": [
  null,
  "Pysäytä ja poista"
 ],
 "(not mounted)": [
  null,
  "(ei liitetty)"
 ],
 "Start multipath": [
  null,
  "Käynnistä monipolku"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Järjestelmässä on laitteita, joilla on useita polkuja, mutta monitiepalvelu ei ole käynnissä."
 ],
 "Show all $0 rows": [
  null,
  "Näytä kaikki $0 riviä"
 ],
 "Category": [
  null,
  "Luokka"
 ],
 "more info": [
  null,
  "lisätietoja"
 ],
 "Encryption": [
  null,
  "Salaus"
 ],
 "encrypted": [
  null,
  "salattu"
 ],
 "Last modified: $0": [
  null,
  "Viimeksi muokattu: $0 sitten"
 ],
 "Stored passphrase": [
  null,
  "Tallennettu tunnuslause"
 ],
 "Encryption options": [
  null,
  "Salauksen valinnat"
 ],
 "Encryption type": [
  null,
  "Salauksen tyyppi"
 ],
 "Cleartext device": [
  null,
  "Selkotekstilaite"
 ],
 "yes": [
  null,
  "kyllä"
 ],
 "Disk passphrase": [
  null,
  "Levyn tunnuslause"
 ],
 "Passphrase cannot be empty": [
  null,
  "Tunnuslause ei voi olla tyhjä"
 ],
 "Unlocking disk": [
  null,
  "Avataan levyn lukitus"
 ],
 "Checking for $0 package": [
  null,
  "Etsitään $0 pakettia"
 ],
 "The $0 package must be installed.": [
  null,
  "Paketti $0 on asennettava."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 paketti ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "Virhe asennettaessa $0:a: PackageKit- tai dnf5daemon-server-palvelinta ei ole asennettu"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "Odottamaton PackageManager-virhe asennuksen aikana $0: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Tarkistetaan NBDE-tukea initrd:ssä"
 ],
 "The initrd must be regenerated.": [
  null,
  "Initrd on luotava uudelleen."
 ],
 "Regenerating initrd": [
  null,
  "Luodaan uudelleen initrd"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Lisätään rd.neednet=1 kernelin komentoriville"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Lisätään \"$0\" tiedostojärjestelmän asetuksiin"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Lisätään \"$0\" salauksen valintoihin"
 ],
 "Enabling $0": [
  null,
  "Otetaan käyttöön $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Lisää verkkoon sidottu levyn salaus"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Järjestelmä ei tällä hetkellä tue root-tiedostojärjestelmän lukituksen avaamista Tang-avainpalvelimella."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Järjestelmä ei tällä hetkellä tue tiedostojärjestelmän lukituksen avaamista Tang-avainpalvelimella käynnistyksen aikana."
 ],
 "These additional steps are necessary:": [
  null,
  "Nämä lisävaiheet ovat välttämättömiä:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Uuden salasanan tallentaminen edellyttää levyn lukituksen avaamista. Anna nykyinen levyn tunnuslause."
 ],
 "Fix NBDE support": [
  null,
  "Korjaa NBDE-tuki"
 ],
 "Adding key": [
  null,
  "Avainta lisätään"
 ],
 "Key source": [
  null,
  "Avainlähde"
 ],
 "Repeat passphrase": [
  null,
  "Toista tunnuslause"
 ],
 "Passphrase": [
  null,
  "Tunnuslause"
 ],
 "Tang keyserver": [
  null,
  "Tang-avainpalvelin"
 ],
 "New passphrase": [
  null,
  "Uusi tunnuslause"
 ],
 "Passphrases do not match": [
  null,
  "Tunnuslauseet eivät täsmää"
 ],
 "Keyserver address": [
  null,
  "Avainpalvelimen osoite"
 ],
 "Change passphrase": [
  null,
  "Vaihda tunnuslause"
 ],
 "Old passphrase": [
  null,
  "Vanha tunnuslause"
 ],
 "Edit Tang keyserver": [
  null,
  "Muokkaa Tang-avainpalvelinta"
 ],
 "Verify key": [
  null,
  "Vahvista avain"
 ],
 "Trust key": [
  null,
  "Luottamusavain"
 ],
 "Passphrase can not be empty": [
  null,
  "Tunnuslause ei voi olla tyhjä"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Salalauseen poisto voi estää laitteen $0 lukituksen avaamisen."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Vahvista poisto vaihtoehtoisella tunnuslauseella"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Salasanan poistaminen ilman toisen salasanan vahvistamista saattaa estää lukituksen avaamisen tai avaimen hallinnan, jos muut salasanat unohdetaan tai menetetään."
 ],
 "Passphrase from any other key slot": [
  null,
  "Tunnuslause mistä tahansa muusta avainpaikasta"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Poista tunnuslause avainpaikasta $0?"
 ],
 "Remove $0?": [
  null,
  "Poistetaanko $0?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Poistaminen saattaa estää $0:n lukituksen avaamisen."
 ],
 "Remove Tang keyserver?": [
  null,
  "Poista Tang-avainpalvelin?"
 ],
 "Remove key in slot $0?": [
  null,
  "Poistetaanko avain paikasta $0?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Tällä hetkellä kirjautuneena oleva käyttäjä ei saa nähdä tietoja avaimista."
 ],
 "No keys added": [
  null,
  "Ei avaimia lisätty"
 ],
 "Slot $0": [
  null,
  "Paikka $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Avaimen muokkaaminen vaatii vapaan paikan"
 ],
 "The last key slot can not be removed": [
  null,
  "Viimeistä avaimen paikkaa ei voida poistaa"
 ],
 "Keyserver": [
  null,
  "Avainpalvelin"
 ],
 "Unknown type": [
  null,
  "Tuntematon tyyppi"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Avainpaikkoja tuntemattomilla tyypeillä ei voi muokata täällä"
 ],
 "Keys": [
  null,
  "Avaimet"
 ],
 "$0 slot remains": [
  null,
  "$0 paikka on jäljellä",
  "$0 paikkaa on jäljellä"
 ],
 "No available slots": [
  null,
  "Ei käytettävissä olevia paikkoja"
 ],
 "No free key slots": [
  null,
  "Ei vapaita avainpaikkoja"
 ],
 "Locked data": [
  null,
  "Lukitut tiedot"
 ],
 "lock": [
  null,
  "lukko"
 ],
 "Lock $0?": [
  null,
  "Lukitse $0?"
 ],
 "Address cannot be empty": [
  null,
  "Osoite ei voi olla tyhjä"
 ],
 "Address is not a valid URL": [
  null,
  "Osoite ei ole kelvollinen URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Tarkasta avaimen tarkistussumma käyttäen Tang-palvelinta."
 ],
 "How to check": [
  null,
  "Kuinka tarkastaa"
 ],
 "In a terminal, run: ": [
  null,
  "Suorita päätteessä: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Kopioi leikepöydälle!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Tarkasta että komennon tuottama SHA-256- tai SHA-1-tarkistesumma vastaa tätä ikkunaa."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs-alitaltio $0 / $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Liitoskohta ei voi olla tyhjä"
 ],
 "Mount point is already used for $0": [
  null,
  "Liitoskohta on jo käytetty lohkolaitetta $0 varten"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Tiedostojärjestelmät ovat jo liitetty tämän liitoskohdan alapuolelle."
 ],
 "Please unmount them first.": [
  null,
  "Ole hyvä ja irrota ne ensin."
 ],
 "read only": [
  null,
  "luku-vain"
 ],
 "never mount at boot": [
  null,
  "Älä koskaan liitä käynnistyksen yhteydessä"
 ],
 "after network": [
  null,
  "verkon jälkeen"
 ],
 "ignore failure": [
  null,
  "jätä virhe huomiotta"
 ],
 "stop boot on failure": [
  null,
  "pysäyttä käynnistyksen epäonnistuessa"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Tiedostojärjestelmälle ei ole määritetty liitoskohtaa."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Tiedostojärjestelmällä ei ole pysyvää liitoskohtaa."
 ],
 "The filesystem is not mounted.": [
  null,
  "Tiedostojärjestelmä ei ole liitettynä."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Tiedostojärjestelmän lukitus avataan ja se liitetään järjestelmään seuraavassa käynnistyksessä. Tämä saattaa edellyttää salasanan syöttämistä."
 ],
 "(no assigned mount point)": [
  null,
  "(ei määritettyä liitoskohtaa)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä hakemistoon $0, mutta se liitetään seuraavan käynnistyksen jälkeen hakemistoon $1."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Liitä automaattisesti $0:een käynnistyksessä"
 ],
 "Mount on $0 now": [
  null,
  "Liitä hakemistoon $0 nyt"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Tiedostojärjestelmä ei tällä hetkellä ole liitettynä, mutta se liitetään seuraavan käynnistyksen jälkeen."
 ],
 "Do not mount automatically on boot": [
  null,
  "Älä liitä automaattisesti käynnistyksen yhteydessä"
 ],
 "Mount now": [
  null,
  "Liitä nyt"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä, mutta sitä ei liitetä seuraavan käynnistyksen jälkeen."
 ],
 "Mount also automatically on boot": [
  null,
  "Liitä myös automaattisesti käynnistyksessä"
 ],
 "Unmount now": [
  null,
  "Irrota nyt"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Tiedostojärjestelmä on tällä hetkellä liitettynä hakemistoon $0, mutta sitä ei liitetä seuraavan käynnistyksen jälkeen."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Tiedostojärjestelmä on määritetty asennettavaksi automaattisesti käynnistykseen, mutta sen salauskontin lukitusta ei avata silloin."
 ],
 "Unlock automatically on boot": [
  null,
  "Avaa lukitus automaattisesti käynnistyksessä"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Epäjohdonmukainen tiedostojärjestelmän liitos"
 ],
 "$0 filesystem": [
  null,
  "$0-tiedostojärjestelmä"
 ],
 "Filesystem name": [
  null,
  "Tiedostojärjestelmän nimi"
 ],
 "Filesystem is locked": [
  null,
  "Tiedostojärjestelmä on lukittu"
 ],
 "Mounts before services start": [
  null,
  "Liittyy ennen palveluiden aloittamista"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Soveltuu kriittisiin liitoksiin, kuten /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Käynnistys epäonnistuu, jos tiedostojärjestelmä ei liity, mikä estää etäkäytön"
 ],
 "Mounts in parallel with services": [
  null,
  "Liittyy yhtäaikaa palveluiden aloittamisten kanssa"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Käynnistys onnistuu vaikka tiedostojärjestelmä ei liity"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Liittyy yhtäaikaa palveluiden aloittamisten kanssa, mutta sen jälkeen, kun verkko on käytettävissä"
 ],
 "Does not mount during boot": [
  null,
  "Ei liitetä käynnistyksen yhteydessä"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Hyödyllinen liitoksille, jotka ovat valinnaisia tai tarvitsevat vuorovaikutusta (kuten tunnuslauseita)"
 ],
 "At boot": [
  null,
  "Käynnistyksen yhteydessä"
 ],
 "Mount before services start": [
  null,
  "Liitä ennen palveluiden aloittamista"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Liitä odottamatta, jätä vika huomiotta"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Liitä, kun verkko tulee saataville, jätä vika huomiotta"
 ],
 "Do not mount": [
  null,
  "Älä liitä"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Tätä laitetta ei voi käyttää asennuskohteeseen."
 ],
 "Mount filesystem": [
  null,
  "Liitoksen tiedostojärjestelmä"
 ],
 "Unmount filesystem $0": [
  null,
  "Irrota tiedostojärjestelmä $0"
 ],
 "Mount configuration": [
  null,
  "Liitoksen kokoonpano"
 ],
 "Swap": [
  null,
  "Sivutus"
 ],
 "Used": [
  null,
  "Käytetty"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Avaa salattu Stratis-varanto"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Anna tunnuslause näiden lohkolaitteiden varannolle:"
 ],
 "Stratis pool": [
  null,
  "Stratis-varanto"
 ],
 "stopped": [
  null,
  "pysäytetty"
 ],
 "Block devices": [
  null,
  "Lohkolaitteet"
 ],
 "No block devices found": [
  null,
  "Lohkolaitetta ei löytynyt"
 ],
 "Stratis block devices": [
  null,
  "Stratis-lohkolaiteet"
 ],
 "Stratis block device": [
  null,
  "Stratis-lohkolaite"
 ],
 "data": [
  null,
  "tiedot"
 ],
 "cache": [
  null,
  "välimuisti"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Syötä olemassa oleva resurssien altaan salalause."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Jos sijainnissa $0 oleva avainpalvelin ei ole tavoitettavissa, voit antaa olemassa olevan salalauseen."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Jos mikään avainpalvelimista ei ole tavoitettavissa, voit antaa olemassa olevan salalauseen."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Jos mikään ei-vuorovaikutteisista lukituksen avausmenetelmistä ei toimi, voit ilmoittaa olemassa olevan salalauseen."
 ],
 "Pool passphrase": [
  null,
  "Varannon tunnuslause"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "Sijainnissa $0 olevan avainpalvelimen on oltava tavoitettavissa."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "Vähintään yhden avainpalvelimen on oltava tavoitettavissa."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Vähintään yhden ei-vuorovaikutteisista lukituksen avausmenetelmistä on toimittava."
 ],
 "Create filesystem": [
  null,
  "Luo tiedostojärjestelmä"
 ],
 "Stratis filesystem": [
  null,
  "Stratis-tiedostojärjestelmä"
 ],
 "Set initial size": [
  null,
  "Aseta alkuperäinen koko"
 ],
 "Limit size": [
  null,
  "Rajoita kokoa"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratisvarannon poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Rename Stratis pool": [
  null,
  "Nimeä uudelleen Stratisvaranto"
 ],
 "Add block devices": [
  null,
  "Lisää lohkolaitteita"
 ],
 "Tier": [
  null,
  "Kerros"
 ],
 "Data": [
  null,
  "Tiedot"
 ],
 "Cache": [
  null,
  "Välimuisti"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Lohkolaitteiden lisääminen edellyttää resurssien altaan lukituksen avaamista."
 ],
 "Encrypted Stratis pool": [
  null,
  "Salattu Stratisvaranto"
 ],
 "Delete pool": [
  null,
  "Poista varanto"
 ],
 "Encryption tokens": [
  null,
  "Salauspoletit"
 ],
 "Stratis filesystems": [
  null,
  "Stratis-tiedostojärjestelmät"
 ],
 "Create new filesystem": [
  null,
  "Luo uusi tiedostojärjestelmä"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Tämä varanto ei käytä kaikkea lohkolaitteidensa tilaa."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Joidenkin tämän varannon lohkolaitteiden koko on kasvanut varannon luomisen jälkeen. Varantoa voidaan turvallisesti kasvattaa hyödyntämään nyt vapaana olevaa tilaa."
 ],
 "Grow the pool to take all space": [
  null,
  "Kasvata resurssienryhmä niin, että se vie kaiken tilan"
 ],
 "This pool is in a degraded state.": [
  null,
  "Varanto on heikentyneessä tilassa."
 ],
 "No filesystems": [
  null,
  "Ei tiedostojärjestelmää"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis-tiedostojärjestelmien varanto"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Tämä salalause on ainoa tapa avata varannon lukitus, eikä sitä voi poistaa."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Tämä avainpalvelin on ainoa tapa avata varannon lukitus, eikä sitä voi poistaa."
 ],
 "Add passphrase": [
  null,
  "Lisää tunnuslause"
 ],
 "Add keyserver": [
  null,
  "Lisää avainpalvelin"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "Viimeistä polettia ei voi poistaa"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Ei enää tilaa salalauseille tai avainpalvelimille."
 ],
 "Confirm": [
  null,
  "Vahvista"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Salalauseen lisääminen edellyttää resurssien altaan lukituksen avaamista."
 ],
 "Remove passphrase?": [
  null,
  "Poista tunnuslause?"
 ],
 "Add Tang keyserver": [
  null,
  "Lisää Tang-avainpalvelin"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Avainpalvelimen lisääminen edellyttää resurssien altaan lukituksen avaamista."
 ],
 "Remove Clevis token?": [
  null,
  "Poistetaanko Clevis-poletti?"
 ],
 "Metadata format": [
  null,
  "Metatietojen muoto"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Metatietomuotoa V1 käyttävät resurssien altaat on rajoitettu enintään yhteen salalauseen ja enintään yhteen avainpalvelimeen."
 ],
 "Overprovisioning": [
  null,
  "Ylivarustaminen"
 ],
 "Allow overprovisioning": [
  null,
  "Salli ylivarustaminen"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Virtuaalisen tiedostojärjestelmän koot ovat varantoa suurempia. Ylivarustusta ei voi poistaa käytöstä."
 ],
 "Allocated": [
  null,
  "Varattu"
 ],
 "Name can not be empty.": [
  null,
  "Nimi ei voi olla tyhjä."
 ],
 "A pool with this name exists already.": [
  null,
  "Tämän niminen varanto on jo olemassa."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Tämänniminen tiedostojärjestelmä on jo tässä varannossa."
 ],
 "Create Stratis pool": [
  null,
  "Luo stratisvaranto"
 ],
 "No block devices are available.": [
  null,
  "Lohkolaitteita ei ole saatavilla."
 ],
 "At least one block device is needed.": [
  null,
  "Vähintään yksi lohkolaite tarvitaan."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Salaa tiedot tunnuslauseella"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Salaa tiedot Tang-avainpalvelimella"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Luodaan tilannevedos tiedostojärjestelmästä $0"
 ],
 "Create snapshot and mount": [
  null,
  "Luo tilannevedos ja liitä"
 ],
 "Create snapshot only": [
  null,
  "Luo vain tilannevedos"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Tiedostojärjestelmän poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Snapshot": [
  null,
  "Tilannevedos"
 ],
 "Rename filesystem": [
  null,
  "Nimeä uudelleen tiedostojärjestelmä"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Aseta virtuaalisen tiedostojärjestelmän koon raja"
 ],
 "Limit virtual filesystem size": [
  null,
  "Rajoita virtuaalisen tiedostojärjestelmän kokoa"
 ],
 "Virtual size limit": [
  null,
  "Virtuaalinen kokoraja"
 ],
 "Virtual size": [
  null,
  "Virtuaalinen koko"
 ],
 "Create RAID device": [
  null,
  "Luo RAID-laite"
 ],
 "RAID level": [
  null,
  "RAID-taso"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (raita)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (peili)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (omistettu pariteetti)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (hajautettu pariteetti)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (kaksinkertainen hajautettu pariteetti)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (peilien raita)"
 ],
 "Chunk size": [
  null,
  "Palan koko"
 ],
 "4 KiB": [
  null,
  "4 Kit"
 ],
 "8 KiB": [
  null,
  "8 Kit"
 ],
 "16 KiB": [
  null,
  "16 Kit"
 ],
 "32 KiB": [
  null,
  "32 Kit"
 ],
 "64 KiB": [
  null,
  "64 Kit"
 ],
 "128 KiB": [
  null,
  "128 Kit"
 ],
 "512 KiB": [
  null,
  "512 Kit"
 ],
 "1 MiB": [
  null,
  "1 Mit"
 ],
 "2 MiB": [
  null,
  "2 Mit"
 ],
 "At least $0 disk is needed.": [
  null,
  "Vähintään $0 levy tarvitaan.",
  "Vähintään $0 levyä tarvitaan."
 ],
 "MDRAID disk": [
  null,
  "MDRAID-levy"
 ],
 "In sync": [
  null,
  "Synkronoitu"
 ],
 "Spare": [
  null,
  "Varaosa"
 ],
 "Recovering": [
  null,
  "Palautetaan"
 ],
 "Write-mostly": [
  null,
  "Kirjoitus-enimmäkseen"
 ],
 "Blocked": [
  null,
  "Estetty"
 ],
 "Unknown ($0)": [
  null,
  "Tuntematon ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID-laitteen on oltava käynnissä"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID-laite on palautumassa"
 ],
 "Need a spare disk": [
  null,
  "Tarvitaan varalevy"
 ],
 "Last disk can not be removed": [
  null,
  "Viimeistä levyä ei voida poistaa"
 ],
 "MDRAID device": [
  null,
  "MDRAID-laite"
 ],
 "Confirm stopping of $0": [
  null,
  "Vahvista kohteen $0 pysäyttäminen"
 ],
 "Stop device": [
  null,
  "Pysäytä laite"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Poistaminen tuhoaa kaiken MDRAID-laitteella olevan datan."
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID-laitteen on oltava käynnissä"
 ],
 "Add disk": [
  null,
  "Lisää levy"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 levyt"
 ],
 "$0 chunk size": [
  null,
  "$0 palan koko"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID-laite on heikentyneessä tilassa"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Tällä MDRAID-laitteella ei ole kirjoitustarkoituksen mukaista bittikarttaa. Tällainen bittikartta voi lyhentää synkronointiaikoja merkittävästi."
 ],
 "Add a bitmap": [
  null,
  "Lisää bittikartta"
 ],
 "No disks found": [
  null,
  "Levyjä ei löytynyt"
 ],
 "MDRAID disks": [
  null,
  "MDRAID-levyt"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "VDO-laitteen poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Tämän VDO-laitteen luominen ei päättynyt eikä laitetta voida käyttää."
 ],
 "Remove device": [
  null,
  "Poista laite"
 ],
 "Grow to take all space": [
  null,
  "Kasvata viemään koko tilan"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Tämä VDO-laite ei käytä kaikkia sen tukilaitetta."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Vain $0 ja $1 ovat käytössä."
 ],
 "Grow logical size of $0": [
  null,
  "Kasvata loogista kokoa $0"
 ],
 "Physical": [
  null,
  "Fyysinen"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 ylikäyttö $2 ($3)"
 ],
 "Logical": [
  null,
  "Looginen"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 käytetty kohteesta $1 ($2 tallennettu)"
 ],
 "Index memory": [
  null,
  "Indeksin muisti"
 ],
 "SMART self-test of $target": [
  null,
  "Levyn $target SMART-itsetesti"
 ],
 "Ejecting $target": [
  null,
  "Työnnetään $target ulos"
 ],
 "Unlocking $target": [
  null,
  "Avataan $target"
 ],
 "Locking $target": [
  null,
  "Lukitaan $target"
 ],
 "Modifying $target": [
  null,
  "Muokataan $target"
 ],
 "Resizing $target": [
  null,
  "Muutetaan $target kokoa"
 ],
 "Starting swapspace $target": [
  null,
  "Aloitetaan sivutustila $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Lopetetaan sivutustilan $target"
 ],
 "Mounting $target": [
  null,
  "Liitetään $target"
 ],
 "Unmounting $target": [
  null,
  "Irrotetaan $target"
 ],
 "Checking $target": [
  null,
  "Tarkistetaan $target"
 ],
 "Repairing $target": [
  null,
  "Korjataan $target"
 ],
 "Erasing $target": [
  null,
  "Tyhjennetään $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Luodaan tiedostojärjestelmää $target:een"
 ],
 "Setting up loop device $target": [
  null,
  "Silmukkalaitteen $target asettaminen"
 ],
 "Deleting $target": [
  null,
  "Poistetaan $target"
 ],
 "Creating partition $target": [
  null,
  "Luodaan osiota $target"
 ],
 "Cleaning up for $target": [
  null,
  "Siivotaan kohteelle $target"
 ],
 "Securely erasing $target": [
  null,
  "Poistaa turvallisesti $target"
 ],
 "Very securely erasing $target": [
  null,
  "Poistetaan hyvin turvallisesti $target"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Pysäytetään MDRAID-laite $target"
 ],
 "Starting MDRAID device $target": [
  null,
  "Käynnistetään MDRAID-laite $target"
 ],
 "Marking $target as faulty": [
  null,
  "Merkitään $target virheelliseksi"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target poistetaan MDRAID-laitteesta"
 ],
 "Creating MDRAID device $target": [
  null,
  "Luodaan MDRAID-laite $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Tarkistetaan MDRAID-laite $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Tarkistetaan ja korjataan MDRAID-laite $target"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Palautetaan MDRAID-laite $target"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synkronoidaan MDRAID-laitetta $target"
 ],
 "Activating $target": [
  null,
  "Aktivoidaan $target"
 ],
 "Deactivating $target": [
  null,
  "Deaktivoidaan $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Luodaan tilannevedos $target:sta"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Luodaan LVM2 taltioryhmä $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Tuhotaan LVM2 taltioryhmä $target"
 ],
 "Adding physical volume to $target": [
  null,
  "Lisätään fyysinen taltio $target:een"
 ],
 "Removing physical volume from $target": [
  null,
  "Fyysinen taltio poistetaan $target:sta"
 ],
 "Emptying $target": [
  null,
  "Tyhjennetään $target"
 ],
 "Creating logical volume $target": [
  null,
  "Luodan loogista taltiota $target"
 ],
 "Renaming $target": [
  null,
  "Nimetään uudelleen $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Toimi '$operation' $target:lla"
 ],
 "unknown target": [
  null,
  "tuntematon kohde"
 ],
 "Jobs": [
  null,
  "Työt"
 ],
 "Reading": [
  null,
  "Luetaan"
 ],
 "Writing": [
  null,
  "Kirjoitetaan"
 ],
 "Install Stratis support": [
  null,
  "Asenna Stratis-tuki"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paketti $0 on asennettava Stratis-varannon luomiseen."
 ],
 "Install NFS support": [
  null,
  "Asenna NFS-tuki"
 ],
 "Create MDRAID device": [
  null,
  "Luo MDRAID-laite"
 ],
 "Create LVM2 volume group": [
  null,
  "Luo LVM2-taltioryhmä"
 ],
 "Change iSCSI initiator name": [
  null,
  "Vaihda iSCSI-aloittajan nimi"
 ],
 "Add iSCSI portal": [
  null,
  "Lisää iSCSI-portaali"
 ],
 "Local storage": [
  null,
  "Paikallinen tallennustila"
 ],
 "Networked storage": [
  null,
  "Verkotettu tallennustila"
 ],
 "Create storage device": [
  null,
  "Luo tallennuslaite"
 ],
 "No storage found": [
  null,
  "Tallennustilaa ei löytynyt"
 ],
 "Server address cannot be empty.": [
  null,
  "Palvelimen osoite ei voi olla tyhjä."
 ],
 "Next": [
  null,
  "Seuraava"
 ],
 "Invalid username or password": [
  null,
  "Virheellinen käyttäjätunnus tai salasana"
 ],
 "Unknown host name": [
  null,
  "Tuntematon konenimi"
 ],
 "Unable to reach server": [
  null,
  "Palvelimeen ei saada yhteyttä"
 ],
 "Available targets on $0": [
  null,
  "Käytettävät kohteet osoitteessa $0"
 ],
 "Authentication required": [
  null,
  "Tunnistautuminen vaaditaan"
 ],
 "iSCSI portal": [
  null,
  "iSCSI-portaali"
 ],
 "iSCSI drives": [
  null,
  "iSCSI-asemat"
 ],
 "No drives found": [
  null,
  "Asemia ei löytynyt"
 ],
 "Target": [
  null,
  "Kohde"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-taustalaitteita ei voi tehdä pienemmiksi"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdeveja ei voi tehdä pienemmiksi"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Tunnistamatonta dataa ei voi pienentää täällä."
 ],
 "Unlock before resizing": [
  null,
  "Avaa lukitus ennen koon muuttamista"
 ],
 "$0 can not be resized here": [
  null,
  "$0:n kokoa ei voi muuttaa tässä"
 ],
 "$0 can not be resized": [
  null,
  "$0:n kokoa ei voi muuttaa"
 ],
 "$0 can not be made smaller": [
  null,
  "$0:ta ei voi tehdä pienemmäksi"
 ],
 "$0 can not be made larger": [
  null,
  "$0:ta ei voi tehdä suuremmaksi"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Fyysisten taltioiden kokoja ei voida muuttaa tässä"
 ],
 "Swap can not be resized here": [
  null,
  "Sivutuksen kokoa ei voi muuttaa täällä"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Tunnistamatonta dataa ei voi pienentää täällä"
 ],
 "Activate before resizing": [
  null,
  "Aktivoi ennen koon muuttamista"
 ],
 "Grow logical volume": [
  null,
  "Kasvata loogista taltiota"
 ],
 "Grow partition": [
  null,
  "Kasvata osio"
 ],
 "grow": [
  null,
  "kasvata"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Täsmälleen $0 fyysistä taltiota on valittava"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salatun tiedostojärjestelmän koon muuttaminen edellyttää levyn lukituksen avaamista. Anna nykyinen levyn tunnuslause."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Täsmälleen $0 fyysistä taltiota on valittava, yksi kutakin loogisen taltion kaistaa kohti."
 ],
 "Shrink logical volume": [
  null,
  "Kutista looginen taltio"
 ],
 "shrink": [
  null,
  "kutista"
 ],
 "Unformatted data": [
  null,
  "Alustamattomat tiedot"
 ],
 "Block device": [
  null,
  "lohkolaite"
 ],
 "Device number": [
  null,
  "Laitenumero"
 ],
 "Create partition on $0": [
  null,
  "Luo osio $0:een"
 ],
 "Format $0": [
  null,
  "Alusta $0"
 ],
 "No filesystem": [
  null,
  "Ei tiedostojärjestelmää"
 ],
 "(recommended)": [
  null,
  "(suositeltu)"
 ],
 "No encryption": [
  null,
  "Ei salausta"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Käytä olemassa olevaa salausta uudelleen ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Käytä olemassa olevaa salausta uudelleen"
 ],
 "format": [
  null,
  "alusta"
 ],
 "Format and mount": [
  null,
  "Alusta ja liitä"
 ],
 "Format only": [
  null,
  "Vain alustus"
 ],
 "Format": [
  null,
  "Alusta"
 ],
 "Create and start": [
  null,
  "Luo ja käynnistä"
 ],
 "Format and start": [
  null,
  "Alusta ja käynnistä"
 ],
 "Store passphrase": [
  null,
  "Tallenna tunnuslause"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Levyn lukitus on avattava ennen alustusta. Syötä olemassa oleva salalause."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Talletuslaitteen alustaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Unrecognized data": [
  null,
  "Tunnistamaton data"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Tallennustilaa ei voida hallita tässä järjestelmässä."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "format-bytes\u0004bytes": [
  null,
  "tavua"
 ]
});
