cockpit.locale({
 "": {
  "plural-forms": ((n) => (n != 1)),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Serviços"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "time": [
  null,
  "hora"
 ],
 "date": [
  null,
  "data"
 ],
 "restart": [
  null,
  "reiniciar"
 ],
 "shut": [
  null,
  "encerrar"
 ],
 "domain": [
  null,
  "domínio"
 ],
 "machine": [
  null,
  "máquina"
 ],
 "operating system": [
  null,
  "sistema operacional"
 ],
 "os": [
  null,
  "so"
 ],
 "asset tag": [
  null,
  "etiqueta de ativo"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "corrente"
 ],
 "version": [
  null,
  "versão"
 ],
 "host": [
  null,
  "host"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "mitigation": [
  null,
  "mitigação"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "memória"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "série"
 ],
 "graphs": [
  null,
  "gráficos"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "history": [
  null,
  "histórico"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "discos"
 ],
 "network": [
  null,
  "rede"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "desempenho"
 ],
 "Configuring system settings": [
  null,
  "Configurando as definições do sistema"
 ],
 "service": [
  null,
  "serviço"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "alvo"
 ],
 "socket": [
  null,
  "soquete"
 ],
 "timer": [
  null,
  "temporizador"
 ],
 "path": [
  null,
  "caminho"
 ],
 "unit": [
  null,
  "unidade"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "inicialização"
 ],
 "mask": [
  null,
  "máscara"
 ],
 "unmask": [
  null,
  "desmascarar"
 ],
 "enable": [
  null,
  "habilitar"
 ],
 "disable": [
  null,
  "desabilitado"
 ],
 "Managing services": [
  null,
  "Gerenciando serviços"
 ],
 "journal": [
  null,
  "registro do log"
 ],
 "warning": [
  null,
  "aviso"
 ],
 "error": [
  null,
  "erro"
 ],
 "debug": [
  null,
  "depurar"
 ],
 "crash": [
  null,
  "crash"
 ],
 "coredump": [
  null,
  "despejo de memória"
 ],
 "Reviewing logs": [
  null,
  "Revisando logs"
 ],
 "console": [
  null,
  "console"
 ],
 "command": [
  null,
  "comando"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "shell"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
