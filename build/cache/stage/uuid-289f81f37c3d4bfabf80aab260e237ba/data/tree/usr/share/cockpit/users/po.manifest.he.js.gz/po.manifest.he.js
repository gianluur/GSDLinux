cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Accounts": [
  null,
  "חשבונות"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "סיסמה"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "שם משתמש"
 ],
 "login": [
  null,
  "כניסה"
 ],
 "access": [
  null,
  "גישה"
 ],
 "roles": [
  null,
  "תפקידים"
 ],
 "keys": [
  null,
  "מפתחות"
 ],
 "Managing user accounts": [
  null,
  "ניהול חשבונות משתמשים"
 ]
});
