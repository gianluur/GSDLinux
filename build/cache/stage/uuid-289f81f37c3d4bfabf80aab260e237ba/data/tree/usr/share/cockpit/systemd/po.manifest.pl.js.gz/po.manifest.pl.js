cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Usługi"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "time": [
  null,
  "czas"
 ],
 "date": [
  null,
  "data"
 ],
 "restart": [
  null,
  "uruchom ponownie"
 ],
 "shut": [
  null,
  "wyłącz"
 ],
 "domain": [
  null,
  "domena"
 ],
 "machine": [
  null,
  "komputer"
 ],
 "operating system": [
  null,
  "system operacyjny"
 ],
 "os": [
  null,
  "system operacyjny"
 ],
 "asset tag": [
  null,
  "etykieta zasobu"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "power": [
  null,
  "zasilanie"
 ],
 "version": [
  null,
  "wersja"
 ],
 "host": [
  null,
  "gospodarz"
 ],
 "hardware": [
  null,
  "sprzęt"
 ],
 "mitigation": [
  null,
  "poprawka zmniejszająca ryzyko"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "memory": [
  null,
  "pamięć"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "dimm": [
  null,
  "DIMM"
 ],
 "serial": [
  null,
  "szeregowe"
 ],
 "graphs": [
  null,
  "wykresy"
 ],
 "metrics": [
  null,
  "statystyki"
 ],
 "history": [
  null,
  "historia"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "dyski"
 ],
 "network": [
  null,
  "sieć"
 ],
 "cgroups": [
  null,
  "CGroups"
 ],
 "performance": [
  null,
  "wydajność"
 ],
 "Configuring system settings": [
  null,
  "Konfigurowanie ustawień systemu"
 ],
 "service": [
  null,
  "usługa"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cel"
 ],
 "socket": [
  null,
  "gniazdo"
 ],
 "timer": [
  null,
  "licznik"
 ],
 "path": [
  null,
  "ścieżka"
 ],
 "unit": [
  null,
  "jednostka"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "uruchom"
 ],
 "mask": [
  null,
  "maska"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "włącz"
 ],
 "disable": [
  null,
  "wyłącz"
 ],
 "Managing services": [
  null,
  "Zarządzanie usługami"
 ],
 "journal": [
  null,
  "dziennik"
 ],
 "warning": [
  null,
  "ostrzeżenie"
 ],
 "error": [
  null,
  "błąd"
 ],
 "debug": [
  null,
  "debuguj"
 ],
 "crash": [
  null,
  "awaria"
 ],
 "coredump": [
  null,
  "zrzut core"
 ],
 "Reviewing logs": [
  null,
  "Przeglądanie dzienników"
 ],
 "console": [
  null,
  "konsola"
 ],
 "command": [
  null,
  "polecenie"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "powłoka"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
