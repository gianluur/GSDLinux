cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nb",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 feil",
  "$0 feil"
 ],
 "$0 installation": [
  null,
  "$0-Installasjon"
 ],
 "$0 installer": [
  null,
  "$0-installerer"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 er en MBR-utvidet partisjon som inneholder logiske partisjoner. Å fjerne alle logiske partisjoner skal også automatisk fjerne den utvidede partisjonen."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 kreves, men bare $1 er tilgjengelig."
 ],
 "$0 warning": [
  null,
  "$0 advarsel",
  "$0 advarsler"
 ],
 "$0 will be deleted": [
  null,
  "$0 skal fjernes"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "«$0»-filsystemet kan ikke være på en kryptert blokkenhet"
 ],
 "'$0' must be assigned to $1": [
  null,
  "«$0» må være tilegnet «$1»"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "«$0» må være på en enhet formatert som «$1»"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "«$0»-partisjon på MSDRAID-enhet «$1» funnet. Oppstartslasterpartisjoner på MDRAID-enheter støttes ikke."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "En standardbrukerkonto med administratortilgang for å gjøre systemomfattende endringer."
 ],
 "Abort installation": [
  null,
  "Avbryt installasjon"
 ],
 "About": [
  null,
  "Om"
 ],
 "Account": [
  null,
  "Konto"
 ],
 "Actions": [
  null,
  "Handlinger"
 ],
 "Add another server...": [
  null,
  "Legg til en ny server…"
 ],
 "Add mount": [
  null,
  "Legg til monteringspunkt"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Tillegg for ditt valgte miljø"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Tillegg som ikke er spesifikke for ditt miljø"
 ],
 "Additional languages": [
  null,
  "Ytterligere språk"
 ],
 "Additional software for the selected environment": [
  null,
  "Ekstra programvare for valgt miljø"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Alle endringer gjort i lagringsredigereren, trer umiddelbart i kraft."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Alle enheter som bruker denne passfrasen, vil bli opplåst"
 ],
 "Anaconda Web UI": [
  null,
  "Nettbrukergrensesnitts-Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Anacondas prosjektside"
 ],
 "Apply mount point assignment and install": [
  null,
  "Appliker monteringspunktstildelingen og installer"
 ],
 "Applying changes...": [
  null,
  "Tar i bruk endringer …"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Tildel partisjoner til monteringspunkter. Nyttig for forhåndskonfigurerte, tilpassede oppsett."
 ],
 "Automatic log file upload": [
  null,
  "Automatisk opplasting av loggfil"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Angi dato og klokkeslett automatisk ved å bruke tidsservere"
 ],
 "Automatically set timezone": [
  null,
  "Angi tidssone automatisk"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Tilgjengelig lagringsplass: $0. Installasjon krever: $1."
 ],
 "Back": [
  null,
  "Tilbake"
 ],
 "Base environment": [
  null,
  "Basismiljø"
 ],
 "Brief description of the issue": [
  null,
  "Kort beskrivelse av problemet"
 ],
 "Bug report details": [
  null,
  "Detaljert feilrapport"
 ],
 "Bugzilla API key": [
  null,
  "API-nøkkel for Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Ved å fortsette å bruke denne programvaren, forstår og godtar du risikoene tilknyttet til forhåndsutgitt programvare, forstår at du mener å bruke dette kun for prøving og utvikling og er villig til å rapportere noen som helst feil som oppstår i programvaren for å forbedre dette verket."
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change destination": [
  null,
  "Endre destinasjon"
 ],
 "Change hostname": [
  null,
  "Endre vertsnavn"
 ],
 "Change partition layout": [
  null,
  "Endre partisjonsutforming"
 ],
 "Change system keyboard layout": [
  null,
  "Endre systemtastaturoppsett"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Endringer gjort her, vil umiddelbart påvirke systemet. Det er INGEN «Angre»-knapp."
 ],
 "Checking installation configuration...": [
  null,
  "Sjekker konfigurasjon av installasjon …"
 ],
 "Checking storage configuration": [
  null,
  "Sjekker lagringskonfigurasjon"
 ],
 "Clear search": [
  null,
  "Tøm søk"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Klikk «Neste» igjen for å fortsette på tross av disse advarslene."
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Close storage editor": [
  null,
  "Lukk lagringsredigering"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit-lagring oppga ikke passfrasen som trenges for å låse opp den krypterte enheten."
 ],
 "Completed": [
  null,
  "Fullført!"
 ],
 "Configuration is incomplete": [
  null,
  "Konfigurasjonen er ufullstendig"
 ],
 "Configure NTP servers": [
  null,
  "Konfigurer NTP-tjenere"
 ],
 "Configure custom NTP servers": [
  null,
  "Konfigurer tilpassede NTP-tjenere"
 ],
 "Configure network": [
  null,
  "Konfigurer nettverk"
 ],
 "Configure storage": [
  null,
  "Konfigurer lagring"
 ],
 "Configure storage again": [
  null,
  "Konfigurer lagring igjen"
 ],
 "Confirm passphrase": [
  null,
  "Bekreft passfrase"
 ],
 "Continue": [
  null,
  "Fortsett"
 ],
 "Continue installation": [
  null,
  "Fortsett med installasjonen"
 ],
 "Continue installation?": [
  null,
  "Fortsett med installasjonen?"
 ],
 "Continue with installation": [
  null,
  "Fortsett med installasjonen"
 ],
 "Correct these issues before continuing.": [
  null,
  "Rett opp disse problemene før du fortsetter."
 ],
 "Create Account": [
  null,
  "Opprett konto"
 ],
 "Create account": [
  null,
  "Opprett konto"
 ],
 "Currently installed: $0": [
  null,
  "Nåværende installasjon på disk: $0"
 ],
 "Custom": [
  null,
  "Egendefinert"
 ],
 "Date": [
  null,
  "Dato"
 ],
 "Date and time": [
  null,
  "Dato og tid"
 ],
 "Delete partition": [
  null,
  "Slett partisjon"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Å fjerne visse partisjoner kan hindre $0 i å starte opp: $1"
 ],
 "Description": [
  null,
  "Beskrivelse"
 ],
 "Destination": [
  null,
  "Destinasjon"
 ],
 "Destination is encrypted": [
  null,
  "Destinasjonen er kryptert"
 ],
 "Detailed description of the issue": [
  null,
  "Detaljert beskrivelse av problemet"
 ],
 "Detected valid storage layout:": [
  null,
  "Oppdaget gyldig lagringsoppsett:"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Duplicate device.": [
  null,
  "Duplikat enhet."
 ],
 "Duplicate mount point.": [
  null,
  "Duplikat monteringspunkt."
 ],
 "Enable root account": [
  null,
  "Slå på rotkonto"
 ],
 "Encrypt my data": [
  null,
  "Krypter mine data"
 ],
 "Encrypted": [
  null,
  "Kryptert"
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "Enter PIN": [
  null,
  "Oppgi PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Oppgi PIN for å aksessere installasjonsprogrammet"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Environment": [
  null,
  "Miljø"
 ],
 "Erase data and install": [
  null,
  "Fjern dataene og installer"
 ],
 "Error details": [
  null,
  "Feildetaljer"
 ],
 "Exit to live desktop": [
  null,
  "Avslutt til live-skrivebord"
 ],
 "Extended partition": [
  null,
  "Utvidet partisjon"
 ],
 "Failed to report issue": [
  null,
  "Klarte ikke å rapporter feilen"
 ],
 "Failed to save layouts": [
  null,
  "Klarte ikke å lagre utformingene"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora krever minst $0 med lagringsplass."
 ],
 "Finalization": [
  null,
  "Sluttføring"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Sluttføring: Systemoppsettet er fullført. Det kan ta en stund å sluttføre installasjonen."
 ],
 "Find layout": [
  null,
  "Finn utforming"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "For bedre sikkerhet, unngå å bruke root-kontoen direkte. Bruk i stedet den lokale kontoen ovenfor for å administrere systemet."
 ],
 "Full name": [
  null,
  "Fullnavn"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Fullnavnet kan ikke inneholde en kolon"
 ],
 "Helper text": [
  null,
  "Hjelpetekst"
 ],
 "Hide API key": [
  null,
  "Skjul API-nøkkel"
 ],
 "Hide PIN": [
  null,
  "Skjul PIN"
 ],
 "Hide confirmed password": [
  null,
  "Skjul bekreftet passord"
 ],
 "Hide passphrase": [
  null,
  "Skjul passfrase"
 ],
 "Hide password": [
  null,
  "Skjul passord"
 ],
 "Hostname": [
  null,
  "Vertsnavn"
 ],
 "How would you like to install?": [
  null,
  "Hvordan vil du installere systemet?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Jeg forstår at alle nåværende data på disken skal slettes",
  "Jeg forstår at alle nåværende data fra valgte disker skal slettes"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Jeg forstår at noen nåværende data på disken skal slettes"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Jeg forstår at noen partisjoner skal endres"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Dersom dette er tomt, vil vertsnavnet være flyktig og bli stilt inn av nettverksinformasjon."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Dersom du setter opp partisjoner, kreves det følgende:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Dersom du ikke forstår eller godtar risikoene, vennligst forlat dette programmet."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "I gang"
 ],
 "Initializing...": [
  null,
  "Starter…"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Installation failed": [
  null,
  "Installasjon mislyktes"
 ],
 "Installation method": [
  null,
  "Installasjonsmetode"
 ],
 "Installation of the system failed": [
  null,
  "Installering av systemet mislyktes"
 ],
 "Installation of the system failed: $0": [
  null,
  "Installering av systemet mislyktes: $0"
 ],
 "Installation type": [
  null,
  "Installasjonstype"
 ],
 "Installing": [
  null,
  "Installerer"
 ],
 "Insufficient disk space": [
  null,
  "Ikke nok diskplass"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Ugyldig PIN. Vennligst prøv igjen."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Ugyldig RAID-oppsett oppdaget. Dersom RAID-tabellen er skapt rett oppå disker, må en partisjonstabell skapes på disktabellen. Dersom RAID-tabellen er skapt oppå partisjoner, må den inneholde ett eneste filsystem eller format (t.d. LVM PV). Alle nåværende partisjoner på denne tabellen skal ignoreres."
 ],
 "Invalid hostname": [
  null,
  "Ugyldig vertsnavn"
 ],
 "Jump to first incomplete step": [
  null,
  "Gå til første ufullstendige trinn"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Behold nåværende diskoppsett og bruk tilgjengelig lagringsplass for å dobbeltoppstarte med et annet operativsystem."
 ],
 "Keyboard": [
  null,
  "Tastatur"
 ],
 "Keyboard layout during boot": [
  null,
  "Tastaturoppsett under oppstart"
 ],
 "Language": [
  null,
  "Språk"
 ],
 "Launch storage editor": [
  null,
  "Lanser lagringsredigerer"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "La begge passordfrasefeltene være tomme for å bruke et tomt passord."
 ],
 "Location": [
  null,
  "Plass"
 ],
 "Locked devices": [
  null,
  "Låste enheter"
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Make current": [
  null,
  "Gjør gjeldende"
 ],
 "Manual disk configuration": [
  null,
  "Manuell diskkonfigurasjon"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manuell diskkonfigurasjon: Monteringspunktavbilding"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Kan inneholde bokstaver (uten æ, ø og å), tall og bindestrek."
 ],
 "May need more free space": [
  null,
  "Trenger kanskje mer ledig plass"
 ],
 "Medium": [
  null,
  "Medie"
 ],
 "Minimum of $0 required": [
  null,
  "Minimum $0 kreves"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Gjenformateringsvalgene for forelderenheten og barneenheten samsvarer ikke."
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "Mount point assignment": [
  null,
  "Monteringspunkttildeling"
 ],
 "Move down": [
  null,
  "Flytt ned"
 ],
 "Move up": [
  null,
  "Flytt opp"
 ],
 "Must be at least $0 characters": [
  null,
  "Må være minst $0 tegn langt"
 ],
 "My issue is different, continue": [
  null,
  "Mitt problem er et annet. Fortsett"
 ],
 "NTP Servers": [
  null,
  "NTP-tjenere"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Needs at least $0": [
  null,
  "Trenger minst $0"
 ],
 "Network": [
  null,
  "Nettverk"
 ],
 "Network Configuration": [
  null,
  "Nettverkskonfigurasjon"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Nettverksforbindelse ikke tilgjengelig. Vennligst konfigurer nettverksforbindelsen i menyen i det øverste feltet for å rapportere feilen."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Nettverksforbindelse ikke tilgjengelig. Vennligst konfigurer nettverksforbindelsen for å rapportere feilen."
 ],
 "Network plugin failed": [
  null,
  "Nettverkstillegg mislyktes"
 ],
 "Next": [
  null,
  "Neste"
 ],
 "No devices": [
  null,
  "Ingen enheter"
 ],
 "No disks available": [
  null,
  "Ingen tilgjengelige disker"
 ],
 "No disks selected": [
  null,
  "Ingen disker valgt"
 ],
 "No keyboard layouts selected": [
  null,
  "Ingen tastaturutforminger valgt"
 ],
 "No layouts selected yet": [
  null,
  "Ingen utforming valgt ennå"
 ],
 "No results found": [
  null,
  "Ingen treff"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "Ikke nok ledig plass tilgjengelig"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Ikke nok ledig lagringsplass på de valgte diskene."
 ],
 "Not enough space on selected disks.": [
  null,
  "Ikke nok lagringsplass på de valgte diskene."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "NB: Dette er forhåndutgitt programvare som er kun ment for prøving og utvikling. Ikke bruk dette for noe som helst kritisk arbeid eller for produksjonsmiljøer."
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "Operativsystem"
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Other keyboards": [
  null,
  "Andre tastatur"
 ],
 "Partitions (advanced)": [
  null,
  "Partisjoner (avansert)"
 ],
 "Passphrase": [
  null,
  "Passfrase"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Passfrase stemte ikke overens med noen som helst låst enhet"
 ],
 "Passphrases must match": [
  null,
  "Passfrasene må samsvare"
 ],
 "Pending": [
  null,
  "Ventende"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Vennligst tilføy loggfilen $0 til feilrapporteringen."
 ],
 "Please enter a PIN": [
  null,
  "Oppgi en PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Vennligst velg minst en disk for å fortsette"
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "Drevet av Anaconda"
 ],
 "Pre-release": [
  null,
  "Forhåndsutgivelse"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "Fortsett med installasjonen"
 ],
 "Quit": [
  null,
  "Avslutt"
 ],
 "Quit installer?": [
  null,
  "Avslutt installerer?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Mislyktes i å lese informasjon om operativsystemet."
 ],
 "Reading information about the computer failed.": [
  null,
  "Mislyktes i å lese informasjon om datamaskinen."
 ],
 "Reading installer configuration failed.": [
  null,
  "Mislyktes i å lese installererkonfigurasjon."
 ],
 "Reading installer version information failed.": [
  null,
  "Mislyktes i å lese installererutgivelsesinformasjon."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Ekte vertsnavn kan kun inneholde bokstaver (uten æ, ø og å), grunntall, bindestrek (ikke på starten eller slutten) og punktum"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Ekte vertsnavn må være 64 tegn lang eller mindre"
 ],
 "Reboot": [
  null,
  "Start på nytt"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Start på nytt i Windows for å endre størrelsen på BitLocker-krypterte partisjoner. Frigjør minst $0 med lagringsplass for installasjonen."
 ],
 "Reboot system?": [
  null,
  "Start system på nytt?"
 ],
 "Reclaim additional space": [
  null,
  "Gjenvinn ytterligere lagringsplass"
 ],
 "Reclaim space": [
  null,
  "Gjenvinn lagringplass"
 ],
 "Reclaim space (required)": [
  null,
  "Gjenvinn lagringsplass (påkrevd)"
 ],
 "Recommended": [
  null,
  "Anbefalt"
 ],
 "Recommended partitions:": [
  null,
  "Anbefalte partisjoner:"
 ],
 "Reformat": [
  null,
  "Gjenformater"
 ],
 "Reinstall Fedora": [
  null,
  "Installer Fedora på nytt"
 ],
 "Remove": [
  null,
  "Slett"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Slett alle partisjoner på de valgte enhetene, inkludert eksisterende operativsystem."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Slett eller endre størrelsen på eksisterende filsystem for å frigjøre lagringsplass for installasjonen."
 ],
 "Remove server": [
  null,
  "Fjern tjener"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Å slette et filsystem vil permanent slette alle data på filsystemet. Å endre størrelsen på en partisjon kan frigjøre ubrukt lagringsplass, men det kommer ikke uten risikoer. Sørg for at du har sikkerhetskopieringer av alt som er viktig før du frigjør lagringsplass."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Erstatt nåværende installasjon, men behold filene i hjemmemappen."
 ],
 "Report Issue": [
  null,
  "Rapporter feil"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "Rapporter feil"
 ],
 "Reporting issue...": [
  null,
  "Rapporterer feil …"
 ],
 "Required": [
  null,
  "Påkrevd"
 ],
 "Requirements": [
  null,
  "Krav"
 ],
 "Rescan devices": [
  null,
  "Skanner enheter på nytt"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Mislyktes i å skannere diskene på nytt."
 ],
 "Resize": [
  null,
  "Endre størrelsen"
 ],
 "Resize partition": [
  null,
  "Endre størrelse på partisjon"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Endrer størrelsen på de følgende partisjonene fra $0: $1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "Gå tilbake til installasjon"
 ],
 "Return to storage editor": [
  null,
  "Gå tilbake til lagringsredigereren"
 ],
 "Review and install": [
  null,
  "Gjennomgå og installer"
 ],
 "Root account has been configured": [
  null,
  "Root-konto er konfigurert"
 ],
 "Root account is enabled": [
  null,
  "Root-konto er aktivert"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root-kontoen er aktivert, men ingen brukerkonto er konfigurert"
 ],
 "Root password has been set.": [
  null,
  "Passord for root er satt."
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Skanner QR-koden med telefonen din eller besøk:"
 ],
 "Search for a language": [
  null,
  "Søk etter et språk"
 ],
 "Search for additional software": [
  null,
  "Søk etter ekstra programvare"
 ],
 "Search for an environment": [
  null,
  "Søk etter et miljø"
 ],
 "Search keyboard layout": [
  null,
  "Søk etter tastaturutforming"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Trygg dataene dine ved hjelp av diskbasert kryptering. Gjelder kun nye partisjoner"
 ],
 "Select": [
  null,
  "Velg"
 ],
 "Select a device": [
  null,
  "Velg en enhet"
 ],
 "Select city": [
  null,
  "Velg by"
 ],
 "Select destination": [
  null,
  "Velg destinasjon"
 ],
 "Select region": [
  null,
  "Velg region"
 ],
 "Selected (top = current)": [
  null,
  "Valgt (øverst = gjeldende)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Den valgte enhetens format «$0» kan ikke formateres på nytt."
 ],
 "Send us feedback on your installation": [
  null,
  "Send oss tilbakemeldinger om installasjonen din"
 ],
 "Server": [
  null,
  "Tjener"
 ],
 "Server is not reachable": [
  null,
  "Tjeneren er ikke tilgjengelig"
 ],
 "Set custom hostname": [
  null,
  "Still inn tilpasset vertsnavn"
 ],
 "Share disk with other operating systems": [
  null,
  "Del disken med andre operativsystemer"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Del disken med andre operativsystemer: $0"
 ],
 "Show AM/PM": [
  null,
  "Vis AM/PM"
 ],
 "Show API key": [
  null,
  "Vis API-nøkkel"
 ],
 "Show PIN": [
  null,
  "Vis PIN"
 ],
 "Show confirmed password": [
  null,
  "Vis bekreftet passord"
 ],
 "Show passphrase": [
  null,
  "Vis passfrase"
 ],
 "Show password": [
  null,
  "Vis passord"
 ],
 "Size": [
  null,
  "Størrelse"
 ],
 "Software installation": [
  null,
  "Programvareinstallasjon"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Programvareinstallasjon: Lagringskonfigurasjon fullført. Programvaren blir nå installert på enheten din."
 ],
 "Software selection": [
  null,
  "Valg av programvare"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Noen installasjonssteg må fullføres før du kan fortsette."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Noen påkrevde partisjoner mangler: $0"
 ],
 "Space": [
  null,
  "Lagringsplass"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Lagringsplass"
 ],
 "Storage configuration": [
  null,
  "Lagringsplasskonfigurasjon"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Lagringsplasskonfigurasjon: Lagringsplassen blir nå konfigurert."
 ],
 "Storage editor": [
  null,
  "Lagringsredigerer"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Lagringskonfigurasjonen er basert på konfigurasjonen fra «Endre lagring»."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "Lagringstillegg mislyktes"
 ],
 "Storage requirements not met": [
  null,
  "Lagringskrav er ikke oppfylte"
 ],
 "Strong": [
  null,
  "Sterkt"
 ],
 "Successfully installed": [
  null,
  "Installasjon lyktes!"
 ],
 "Successfully unlocked $0.": [
  null,
  "Lyktes i å låse opp $0."
 ],
 "Suggested keyboards": [
  null,
  "Forslag til tastatur"
 ],
 "Suggested languages": [
  null,
  "Tilrådde språk"
 ],
 "System": [
  null,
  "System"
 ],
 "System configuration": [
  null,
  "Systemoppsett"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Systemoppsett: Programvareinstallasjon fullført. Systemet blir nå konfigurert."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anaconda installasjonen har stoppet på uventet vis."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Følgende bruker vil bli laget:",
  "Følgende brukere vil bli laget:"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Installereren kan ikke fortsette grunnet en kritisk feil."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Installereren kan ikke fortsette grunnet en kritisk feil: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Passfrasen du har oppgitt, inneholder tegn som ikke inkluderes i ASCII (disse tegnene er mest sannsynlig æ, ø eller å). Det kan hende at du ikke kan bytte tastaturoppsett når du skriver den inn."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Det valgte standard tastaturoppsettet støtter ikke ASCII-tegn. Vennligst velg et tastaturoppsett som støtter ASCII som standard."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Lagringsredigereren tillater deg å endre størrelsen på, slett og opprett partisjoner. Den kan opprette LVM og mye mer. Den er ment til å brukes som et avansert verktøy og ikke for bruk i en vanlig installasjon."
 ],
 "This hostname can't be submitted": [
  null,
  "Dette vertsnavnet kan ikke brukes"
 ],
 "This is unstable, pre-release software": [
  null,
  "Dette er ustabil, forhåndsutgitt programvare"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Dette oppsettet skal brukes for å låse opp systemet ditt ved oppstart"
 ],
 "This may take a moment": [
  null,
  "Dette kan ta en stund"
 ],
 "This will take a few moments": [
  null,
  "Dette kan ta en stund"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Timezone": [
  null,
  "Tidssone"
 ],
 "Title": [
  null,
  "Tittel"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "For å begynne med å bruke $0, start systemet ditt på nytt."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Velg enhetene du skal installere på for å fortsette."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Endre størrelsen på eller fjerne eksisterende partisjoner for å frigjøre $0 med lagringsplass for å bruke denne opsjonen."
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Mislyktes i å planlegge sletting av $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Mislyktes i å planlegge størrelsesendring av $0"
 ],
 "Undo last action": [
  null,
  "Angre siste handling"
 ],
 "Unlock": [
  null,
  "Lås opp"
 ],
 "Unlock encrypted devices": [
  null,
  "Lås opp krypterte enheter"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Lås opp krypterte partisjoner for å beholde nåværende data og for å vise flere installasjonsmetoder."
 ],
 "Use configured storage": [
  null,
  "Bruk konfigurert lagring"
 ],
 "Use entire disk": [
  null,
  "Bruk hele disken"
 ],
 "Use free space": [
  null,
  "Bruk ledig plass"
 ],
 "Use local account": [
  null,
  "Bruk lokal konto"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Bruk RAID-enheten for automatisk opprettelse av partisjoner"
 ],
 "User creation": [
  null,
  "Opprette bruker"
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Brukernavn kan kun inneholde bokstaver fra a til z, grunntallene 0-9, bindestrek $0, punktum $1 og understrek $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Brukernavnet kan ikke være et reservert ord"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Brukernavn må være kortere enn 33 tegn"
 ],
 "Validating...": [
  null,
  "Validerer …"
 ],
 "Weak": [
  null,
  "Svakt"
 ],
 "Welcome": [
  null,
  "Velkommen"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Velkommen til Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Velkommen! La oss installere $0 nå."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Størrelsen på Windows-partisjoner med BitLocker-kryptering kan ikke endres"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Du kan enten frigjøre nok lagringsplass her og la installereren håndtere resten eller sette opp partisjoner manuelt."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Du må aktivere root-kontoen eller opprette en lokal brukerkonto for å fortsette."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Du må være tilkoblet et nettverk for å aktivere automatisk dato og klokkeslett."
 ],
 "Your progress will not be saved.": [
  null,
  "Framskrittet ditt skal ikke lagres."
 ],
 "completed step": [
  null,
  "fullført trinn"
 ],
 "current step": [
  null,
  "nåværende trinn"
 ],
 "delete": [
  null,
  "slett"
 ],
 "edit": [
  null,
  "rediger"
 ],
 "encrypt": [
  null,
  "krypter"
 ],
 "encrypted": [
  null,
  "kryptert"
 ],
 "extended partition": [
  null,
  "utvidet partisjon"
 ],
 "format as $0": [
  null,
  "formater som $0"
 ],
 "here": [
  null,
  "her"
 ],
 "incomplete": [
  null,
  "ufullstendig"
 ],
 "mount": [
  null,
  "monter"
 ],
 "pending step": [
  null,
  "ventende trinn"
 ],
 "report the issue manually": [
  null,
  "rapporter feilen manuelt"
 ],
 "resized from $0": [
  null,
  "endret størrelsen fra $0"
 ],
 "shrink": [
  null,
  "krymp"
 ],
 "shrink to $0": [
  null,
  "krymp til $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "angre"
 ]
});
