cockpit.locale({
 "": {
  "plural-forms": ((n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3))),
  "language": "he",
  "language-direction": "rtl"
 },
 "Services": [
  null,
  "שירותים"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "time": [
  null,
  "זמן"
 ],
 "date": [
  null,
  "תאריך"
 ],
 "restart": [
  null,
  "הפעלה מחדש"
 ],
 "shut": [
  null,
  "לסגור"
 ],
 "domain": [
  null,
  "שם תחום"
 ],
 "machine": [
  null,
  "מכונה"
 ],
 "operating system": [
  null,
  "מערכת הפעלה"
 ],
 "os": [
  null,
  "מערכת הפעלה"
 ],
 "asset tag": [
  null,
  "תג נכס"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "חשמל"
 ],
 "version": [
  null,
  "גרסה"
 ],
 "host": [
  null,
  "מארח"
 ],
 "hardware": [
  null,
  "חומרה"
 ],
 "mitigation": [
  null,
  "אפחות"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "זיכרון"
 ],
 "cpu": [
  null,
  "מעבד"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "זיכרון"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "טורי"
 ],
 "graphs": [
  null,
  "תרשימים"
 ],
 "metrics": [
  null,
  "מדדים"
 ],
 "history": [
  null,
  "היסטוריה"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "כוננים"
 ],
 "network": [
  null,
  "רשת"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "ביצועים"
 ],
 "Configuring system settings": [
  null,
  "הגדרות המערכת מוגדרות"
 ],
 "service": [
  null,
  "שירות"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "יעד"
 ],
 "socket": [
  null,
  "שקע"
 ],
 "timer": [
  null,
  "קוצב זמן"
 ],
 "path": [
  null,
  "נתיב"
 ],
 "unit": [
  null,
  "יחידה"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "עלייה"
 ],
 "mask": [
  null,
  "מסכה"
 ],
 "unmask": [
  null,
  "הסרת מיסוך"
 ],
 "enable": [
  null,
  "הפעלה"
 ],
 "disable": [
  null,
  "השבתה"
 ],
 "Managing services": [
  null,
  "ניהול שירותים"
 ],
 "journal": [
  null,
  "ז׳ורנל"
 ],
 "warning": [
  null,
  "אזהרה"
 ],
 "error": [
  null,
  "שגיאה"
 ],
 "debug": [
  null,
  "ניפוי שגיאות"
 ],
 "crash": [
  null,
  "קריסה"
 ],
 "coredump": [
  null,
  "היטל ליבה"
 ],
 "Reviewing logs": [
  null,
  "היומנים נסקרים"
 ],
 "console": [
  null,
  "מסוף"
 ],
 "command": [
  null,
  "פקודה"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "מעטפת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
