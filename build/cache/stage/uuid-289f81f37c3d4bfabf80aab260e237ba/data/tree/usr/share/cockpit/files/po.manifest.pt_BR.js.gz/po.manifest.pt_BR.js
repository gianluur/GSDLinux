cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "File browser": [
  null,
  "Navegador de arquivos"
 ],
 "files": [
  null,
  "arquivos"
 ],
 "explorer": [
  null,
  "explorador"
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ]
});
