cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ko",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "네트워킹"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "unmount": [
  null,
  "적재 해제"
 ],
 "mount": [
  null,
  "적재"
 ],
 "format": [
  null,
  "포맷"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "파일 시스템"
 ],
 "partition": [
  null,
  "파티션"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "레이드"
 ],
 "volume": [
  null,
  "볼륨"
 ],
 "disk": [
  null,
  "디스크"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "드라이브"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "암호화"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "파티션 관리"
 ],
 "Managing NFS mounts": [
  null,
  "NFS 적재 관리하기"
 ],
 "Managing RAIDs": [
  null,
  "레이드 관리"
 ],
 "Managing LVMs": [
  null,
  "LVM 관리"
 ],
 "Managing physical drives": [
  null,
  "물리적 드라이브 관리"
 ],
 "Managing VDOs": [
  null,
  "VDO 관리"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 암호화 사용 중"
 ],
 "Using Tang server": [
  null,
  "Tang 서버 사용 중"
 ]
});
