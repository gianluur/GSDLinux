cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "ລະບົບເຄືອຂ່າຍ"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Storage": [
  null,
  "ບ່ອນຈັດເກັບຂໍ້ມູນ"
 ],
 "Diagnostic reports": [
  null,
  "ລາຍງານການກວດສອບບັນຫາ"
 ],
 "Accounts": [
  null,
  "ບັນຊີ"
 ],
 "user": [
  null,
  "ຜູ້ໃຊ້"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "ລະຫັດຜ່ານ"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "ຊື່ຜູ້ໃຊ້"
 ],
 "login": [
  null,
  "ເຂົ້າສູ່ລະບົບ"
 ],
 "access": [
  null,
  "ການເຂົ້າເຖິງ"
 ],
 "roles": [
  null,
  "ບົດບາດ (roles)"
 ],
 "keys": [
  null,
  "ຄີ"
 ],
 "Managing user accounts": [
  null,
  "ການຈັດການບັນຊີຜູ້ໃຊ້"
 ]
});
