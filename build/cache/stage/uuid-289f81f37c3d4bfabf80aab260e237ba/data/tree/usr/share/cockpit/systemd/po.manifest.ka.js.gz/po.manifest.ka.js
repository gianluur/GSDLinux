cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "სერვისები"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "time": [
  null,
  "დრო"
 ],
 "date": [
  null,
  "თარიღი"
 ],
 "restart": [
  null,
  "რესტარტი"
 ],
 "shut": [
  null,
  "გათიშვა"
 ],
 "domain": [
  null,
  "დომენი"
 ],
 "machine": [
  null,
  "მანქანა"
 ],
 "operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "os": [
  null,
  "ოპერაციული სისტემა"
 ],
 "asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "კვება"
 ],
 "version": [
  null,
  "ვერსია"
 ],
 "host": [
  null,
  "ჰოსტი"
 ],
 "hardware": [
  null,
  "აპარატურა"
 ],
 "mitigation": [
  null,
  "შემოვლა"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "მეხსიერება"
 ],
 "cpu": [
  null,
  "პროცესორი"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "მიმდევრობითი"
 ],
 "graphs": [
  null,
  "გრაფიკები"
 ],
 "metrics": [
  null,
  "მეტრიკები"
 ],
 "history": [
  null,
  "ისტორია"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "დისკები"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "წარმადობა"
 ],
 "Configuring system settings": [
  null,
  "სისტემის პარამეტრების მორგება"
 ],
 "service": [
  null,
  "სერვისი"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "მიზანი"
 ],
 "socket": [
  null,
  "სოკეტი"
 ],
 "timer": [
  null,
  "ტაიმერი"
 ],
 "path": [
  null,
  "ბილიკი"
 ],
 "unit": [
  null,
  "მოდული"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "ჩატვირთვა"
 ],
 "mask": [
  null,
  "ნიღაბი"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "enable": [
  null,
  "ჩართვა"
 ],
 "disable": [
  null,
  "გამორთვა"
 ],
 "Managing services": [
  null,
  "სერვისების მართვა"
 ],
 "journal": [
  null,
  "ჟურნალი"
 ],
 "warning": [
  null,
  "გაფრთხილება"
 ],
 "error": [
  null,
  "შეცდომა"
 ],
 "debug": [
  null,
  "შეცდომების მოძებნა"
 ],
 "crash": [
  null,
  "ავარია"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "ჟურნალის გადახედვა"
 ],
 "console": [
  null,
  "კონსოლი"
 ],
 "command": [
  null,
  "ბრძანება"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "გარსი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
