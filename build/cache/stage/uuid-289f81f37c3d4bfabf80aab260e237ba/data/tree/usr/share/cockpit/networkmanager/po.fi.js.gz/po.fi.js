cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Server": [
  null,
  "Palvelin"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "Firewall": [
  null,
  "Palomuuri"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Public key": [
  null,
  "Julkinen avain"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "Unexpected error": [
  null,
  "Odottamaton virhe"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "Connect": [
  null,
  "Yhdistä"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "Disconnected": [
  null,
  "Katkaistu"
 ],
 "Permission denied": [
  null,
  "Käyttö estetty"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Hallinnollisen pääsyn saamiseksi ei ole käytettävissä menetelmiä ('sudo -A', 'pkexec')."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit raportoi virhekoodin $0"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Error during initialization": [
  null,
  "Virhe alustuksen aikana"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Home": [
  null,
  "Koti"
 ],
 "Downloads": [
  null,
  "Lataukset"
 ],
 "Not a directory": [
  null,
  "Ei ole hakemisto"
 ],
 "All files": [
  null,
  "Kaikki tiedostot"
 ],
 "Recent": [
  null,
  "Viimeaikaiset"
 ],
 "No recent directories": [
  null,
  "Ei hiljattain käytettyjä hakemistoja"
 ],
 "No recent files": [
  null,
  "Ei hiljattain käytettyjä tiedostoja"
 ],
 "Type to filter": [
  null,
  "Kirjoita suodattaaksesi"
 ],
 "File chooser actions": [
  null,
  "Tiedostonvalitsimen toiminnot"
 ],
 "Open in file browser": [
  null,
  "Avaa tiedostoselaimessa"
 ],
 "Hide hidden files": [
  null,
  "Piilota piilotetut tiedostot"
 ],
 "Show hidden files": [
  null,
  "Näytä piilotetut tiedostot"
 ],
 "Filesystem": [
  null,
  "Tiedostojärjestelmä"
 ],
 "Clear filters": [
  null,
  "Tyhjennä suodattimet"
 ],
 "Directory is empty": [
  null,
  "Hakemisto on tyhjä"
 ],
 "Directory has no sub-directories": [
  null,
  "Hakemistossa ei ole alihakemistoja"
 ],
 "This directory contains only hidden files": [
  null,
  "Tämä hakemisto sisältää vain piilotiedostoja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "Folder": [
  null,
  "Kansio"
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Priority": [
  null,
  "Prioriteetti"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "Enabled": [
  null,
  "Käytössä"
 ],
 "Disabled": [
  null,
  "Ei käytössä"
 ],
 "Generated": [
  null,
  "Luotu"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Start service": [
  null,
  "Käynnistä palvelu"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Delete $0": [
  null,
  "Poista $0"
 ],
 "Group": [
  null,
  "Ryhmä"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Not available": [
  null,
  "Ei saatavilla"
 ],
 "Ignore": [
  null,
  "Ohita"
 ],
 "Permanent": [
  null,
  "Pysyvä"
 ],
 "Preserve": [
  null,
  "Säilytä"
 ],
 "Random": [
  null,
  "Satunnainen"
 ],
 "Stable": [
  null,
  "Vakaa"
 ],
 "Use $0": [
  null,
  "Käytä $0:a"
 ],
 "Failed to save settings": [
  null,
  "Asetusten tallentaminen epäonnistui"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Kohteen $0 luominen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Create it": [
  null,
  "Luo se"
 ],
 "Invalid prefix $0": [
  null,
  "Virheellinen etuliite $0"
 ],
 "Invalid metric $0": [
  null,
  "Virheellinen metriikka $0"
 ],
 "Invalid address $0": [
  null,
  "Ei kelvollinen osoite $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Virheellinen etuliite tai verkkopeite $0"
 ],
 "Testing connection": [
  null,
  "Testataan yhteyttä"
 ],
 "Restoring connection": [
  null,
  "Palautetaan yhteys"
 ],
 "Troubleshoot…": [
  null,
  "Vianetsintä…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager ei ole käynnissä"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ei ole asennettu"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Verkkolaitteet ja kaaviot vaativat NetworkManagerin"
 ],
 "Enable service": [
  null,
  "Ota palvelu käyttöön"
 ],
 "Network interface '$0' not found": [
  null,
  "Verkkoliitäntää '$0' ei löytynyt"
 ],
 "Return to overview page": [
  null,
  "Palaa yleiskatsaussivulle"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Sinulla ei ole valtuuksia muokata palomuuria."
 ],
 "Not authorized to disable the firewall": [
  null,
  "Ei oikeutta poistaa palomuuri käytöstä"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Ei oikeutta ottaa käyttöön palomuuria"
 ],
 "Disable the firewall": [
  null,
  "Poista palomuuri käytöstä"
 ],
 "Enable the firewall": [
  null,
  "Ota palomuuri käyttöön"
 ],
 "Edit service $0": [
  null,
  "Muokkaa palvelua $0"
 ],
 "Remove service $0": [
  null,
  "Poista palvelu $0"
 ],
 "Included Services": [
  null,
  "Mukana olevat palvelut"
 ],
 "Additional port": [
  null,
  "Ylimääräinen portti"
 ],
 "Remove additional port": [
  null,
  "Poista lisäportti"
 ],
 "Remove zone $0": [
  null,
  "Poista vyöhyke $0"
 ],
 "Add services to zone $0": [
  null,
  "Lisää palveluja vyöhykkeeseen $0"
 ],
 "Add services": [
  null,
  "Lisää palveluja"
 ],
 "Service": [
  null,
  "Palvelu"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 -vyöhyke"
 ],
 "Interface": [
  null,
  "Liitäntä",
  "Liitännät"
 ],
 "Allowed addresses": [
  null,
  "Sallitut osoitteet"
 ],
 "Entire subnet": [
  null,
  "Koko aliverkko"
 ],
 "There are no active services in this zone": [
  null,
  "Tällä vyöhykkeellä ei ole aktiivisia palveluja"
 ],
 "Filter services": [
  null,
  "Suodata palveluja"
 ],
 "Failed to edit service": [
  null,
  "Palvelun muokkaaminen epäonnistui"
 ],
 "Failed to add port": [
  null,
  "Portin lisääminen epäonnistui"
 ],
 "Failed to add service": [
  null,
  "Palvelun lisääminen epäonnistui"
 ],
 "Unknown service name": [
  null,
  "Tuntematon palvelun nimi"
 ],
 "Invalid port number": [
  null,
  "Virheellinen porttinumero"
 ],
 "Invalid range": [
  null,
  "Ei kelvollinen alue"
 ],
 "Range must be strictly ordered": [
  null,
  "Alueen on oltava tiukasti järjestetty"
 ],
 "Edit service": [
  null,
  "Muokkaa palvelua"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Muokkaa mukautettua palvelua $0-vyöhykkeellä"
 ],
 "Add ports": [
  null,
  "Lisää portit"
 ],
 "Add ports to $0 zone": [
  null,
  "Lisää portteja vyöhykkeeseen $0"
 ],
 "Add services to $0 zone": [
  null,
  "Lisää palveluja vyöhykkeeseen $0"
 ],
 "Custom ports": [
  null,
  "Mukautetut portit"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Esimerkki: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Pilkuilla erotetut portit, alueet ja palvelut hyväksytään"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Esimerkki: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Jos tämä jätetään tyhjäksi, tunniste generoidaan porttien palveluiden ja porttinumeroiden perusteella"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Mukautettujen porttien lisääminen lataa firewalld:n uudelleen. Uudelleenlataus johtaa kaikkien vain-ajonaikaisen kokoonpanon menetykseen!"
 ],
 "Failed to add zone": [
  null,
  "Vyöhykkeen lisääminen epäonnistui"
 ],
 "Add zone": [
  null,
  "Lisää vyöhyke"
 ],
 "Trust level": [
  null,
  "Luottamustaso"
 ],
 "Sorted from least to most trusted": [
  null,
  "Lajiteltu vähiten luotettavista luotetuimpiin"
 ],
 "Custom zones": [
  null,
  "Mukautetut vyöhykkeet"
 ],
 "No description available": [
  null,
  "Ei kuvausta saatavilla"
 ],
 "Included services": [
  null,
  "Mukana olevat palvelut"
 ],
 "The cockpit service is automatically included": [
  null,
  "Palvelu cockpit sisältyy automaattisesti"
 ],
 "Interfaces": [
  null,
  "Liitännät"
 ],
 "Range": [
  null,
  "Alue"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-osoite reitityksen etuliitteellä. Erota useita arvoja pilkulla. Esimerkki: 192.0.2.0/24, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "Vahvista $0:n poisto"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Tämä vyöhyke sisältää cockpit-palvelun. Varmista, että tämä vyöhyke ei koske nykyistä verkkokonsoliyhteyttäsi."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Vyöhykkeen poistaminen poistaa kaikki sen sisäiset palvelut."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "cockpit-palvelun poistaminen voi johtaa siihen, että verkkokonsoli ei ole tavoitettavissa. Varmista, että tämä vyöhyke ei koske nykyistä verkkokonsoliyhteyttäsi."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Poista palvelu $0 vyöhykkeeltä $1"
 ],
 "Firewall is not available": [
  null,
  "Palomuuri ei ole saatavilla"
 ],
 "Please install the $0 package": [
  null,
  "Asenna $0-paketti"
 ],
 "Add a new zone": [
  null,
  "Lisää uusi vyöhyke"
 ],
 "Add new zone": [
  null,
  "Lisää uusi vyöhyke"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Saapuvat pyynnöt estetään oletuksena. Lähteviä pyyntöjä ei estetä."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "SSID can not be empty": [
  null,
  "SSID ei voi olla tyhjä"
 ],
 "Password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "Failed to connect": [
  null,
  "Yhteyden muodostaminen epäonnistui"
 ],
 "Check your password.": [
  null,
  "Tarkista salasanasi."
 ],
 "Connect to hidden network": [
  null,
  "Yhdistä piilotettuun verkkoon"
 ],
 "Connect to $0": [
  null,
  "Yhdistä $0:aan"
 ],
 "Network name": [
  null,
  "Verkon nimi"
 ],
 "Security": [
  null,
  "Turvallisuus"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Kohteen $0 poistaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Laitteen $0 kytkeminen päälle katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Switch on $0": [
  null,
  "Kytke $0 päälle"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kytkeminen pois päältä katkaisee yhteyden palvelimeen ja tekee hallinnon käyttöliittymän ei saataville."
 ],
 "Switch off $0": [
  null,
  "Kytke $0 pois päältä"
 ],
 "Bond": [
  null,
  "Side"
 ],
 "Team": [
  null,
  "Joukkue"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "Silta"
 ],
 "Unknown \"$0\"": [
  null,
  "Tuntematon \"$0\""
 ],
 "Carrier": [
  null,
  "Kuljetin"
 ],
 "Yes": [
  null,
  "Kyllä"
 ],
 "No": [
  null,
  "Ei"
 ],
 "Inactive": [
  null,
  "Epäaktiivinen"
 ],
 "Unknown configuration": [
  null,
  "Tuntematon konfiguraatio"
 ],
 "Additional address $val": [
  null,
  "Ylimääräinen osoite $val"
 ],
 "Address $val": [
  null,
  "Osoite $val"
 ],
 "Gateway $gateway": [
  null,
  "Yhdyskäytävä $gateway"
 ],
 "Additional DNS $val": [
  null,
  "Ylimääräinen DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Lisä DNS-hakutoimialueita $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS-hakutoimialueet $val"
 ],
 "General": [
  null,
  "Yleinen"
 ],
 "Connect automatically": [
  null,
  "Yhdistä automaattisesti"
 ],
 "Automatic": [
  null,
  "Automaattinen"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP-monitorointi"
 ],
 "Broken configuration": [
  null,
  "Rikkinäinen kokoonpano"
 ],
 "Team port": [
  null,
  "Joukkueen portti"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree -protokolla"
 ],
 "Priority $priority": [
  null,
  "Prioriteetti $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "Edelleenohjauksen viive $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "Tervehdysaika $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "Viestin enimmäisikä $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "Polun kustannus $path_cost"
 ],
 "Hairpin mode": [
  null,
  "Hairpin-tila"
 ],
 "Bridge port": [
  null,
  "Sillan portti"
 ],
 "Parent $parent": [
  null,
  "$parent-vanhempi"
 ],
 "ID $id": [
  null,
  "Tunnus $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "Verkon salasanaa ei ole tallennettu. Unohda se ja yhdistä tähän verkkoon uudelleen."
 ],
 "Failed to connect to $0": [
  null,
  "Yhteyden muodostaminen $0:aan epäonnistui"
 ],
 "secured": [
  null,
  "suojattu"
 ],
 "open": [
  null,
  "avoinna"
 ],
 "Last connected: $0": [
  null,
  "Viimeksi yhdistetty: $0"
 ],
 "Signal strength": [
  null,
  "Signaalin voimakkuus"
 ],
 "Not permitted to disconnect network": [
  null,
  "Verkkoyhteyden katkaiseminen ei sallittu"
 ],
 "Disconnect": [
  null,
  "Katkaise yhteys"
 ],
 "Not permitted to connect to network": [
  null,
  "Yhdistäminen verkkoon ei sallittu"
 ],
 "Forget": [
  null,
  "Unohda"
 ],
 "$0 hidden network": [
  null,
  "$0 piilotettu verkko",
  "$0 piilotettua verkkoa"
 ],
 "Filter": [
  null,
  "Suodata"
 ],
 "Refresh": [
  null,
  "Virkistä"
 ],
 "Available networks": [
  null,
  "Käytettävissä olevat verkot"
 ],
 "Network": [
  null,
  "Verkko"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Signal": [
  null,
  "Signaali"
 ],
 "Rate": [
  null,
  "Nopeus"
 ],
 "Not permitted to configure network devices": [
  null,
  "Verkkolaitteiden määrittäminen ei sallittu"
 ],
 "Enable or disable the device": [
  null,
  "Ota laite käyttöön tai poista se käytöstä"
 ],
 "This device cannot be managed here.": [
  null,
  "Tätä laitetta ei voida hallita täällä."
 ],
 "Connection will be lost": [
  null,
  "Yhteys tulee katoamaan"
 ],
 "Keep connection": [
  null,
  "Pidä yhteys"
 ],
 "Invalid IP address: $0": [
  null,
  "Ei kelvollinen IP-osoite '$0'"
 ],
 "Invalid destination address: $0": [
  null,
  "Ei kelvollinen kohdeosoite $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "Ei kelvollinen yhdyskäytävän osoite $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "Ei kelvollinen DNS-osoite $0"
 ],
 "Preparing": [
  null,
  "Valmistellaan"
 ],
 "Configuring": [
  null,
  "Asetetaan"
 ],
 "Authenticating": [
  null,
  "Tunnistaudutaan"
 ],
 "Configuring IP": [
  null,
  "Asetetaan IP"
 ],
 "Checking IP": [
  null,
  "Tarkistetaan IP"
 ],
 "Waiting": [
  null,
  "Odotetaan"
 ],
 "Active": [
  null,
  "Aktiivinen"
 ],
 "Deactivating": [
  null,
  "Deaktivoidaan"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "Infra"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "Mesh"
 ],
 "No carrier": [
  null,
  "Ei kantajaa"
 ],
 "Part of $0": [
  null,
  "Osa kokonaisuudesta $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Asetuksien vaihtaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Change the settings": [
  null,
  "Vaihda asetuksia"
 ],
 "Add bridge": [
  null,
  "Lisää silta"
 ],
 "Edit bridge settings": [
  null,
  "Muokkaa silta-asetuksia"
 ],
 "Ports": [
  null,
  "Portit"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree -protokolla (STP)"
 ],
 "STP priority": [
  null,
  "STP:n prioriteetti"
 ],
 "STP forward delay": [
  null,
  "STP-ohjauksen viive"
 ],
 "STP hello time": [
  null,
  "STP-hello-aika"
 ],
 "STP maximum message age": [
  null,
  "STP-viestin enimmäisikä"
 ],
 "Round robin": [
  null,
  "kiertovuorottelu"
 ],
 "Active backup": [
  null,
  "Aktiivinen varmennus"
 ],
 "Load balancing": [
  null,
  "Kuormantasaus"
 ],
 "Broadcast": [
  null,
  "Yleislähetys"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "Passiivinen"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP:n ping"
 ],
 "NSNA ping": [
  null,
  "NSNA:n ping"
 ],
 "Add team": [
  null,
  "Lisää joukkue"
 ],
 "Edit team settings": [
  null,
  "Muokkaa joukkueen asetuksia"
 ],
 "Runner": [
  null,
  "Suorittaja"
 ],
 "Balancer": [
  null,
  "Tasapainottaja"
 ],
 "Primary": [
  null,
  "Ensisijainen"
 ],
 "Link watch": [
  null,
  "Linkin seuranta"
 ],
 "Link up delay": [
  null,
  "Linkki ylös -viive"
 ],
 "Link down delay": [
  null,
  "Linkki alas -viive"
 ],
 "Ping interval": [
  null,
  "Ping-väli"
 ],
 "Ping target": [
  null,
  "Pingin kohteet"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaattinen (vain DHCP)"
 ],
 "Link local": [
  null,
  "Yksityisosoite"
 ],
 "Manual": [
  null,
  "Käsikirja"
 ],
 "Shared": [
  null,
  "Jaettu"
 ],
 "Prefix length or netmask": [
  null,
  "Etuliitteen pituus tai verkkopeite"
 ],
 "Prefix length": [
  null,
  "Etuliitteen pituus"
 ],
 "IPv4 settings": [
  null,
  "IPv4-asetukset"
 ],
 "IPv6 settings": [
  null,
  "IPv6-asetukset"
 ],
 "Addresses": [
  null,
  "Osoitteet"
 ],
 "Select method": [
  null,
  "Valitse menetelmä"
 ],
 "Add address": [
  null,
  "Lisää osoite"
 ],
 "Address": [
  null,
  "Osoite"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Gateway": [
  null,
  "Yhdyskäytävä"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "Lisää DNS-palvelin"
 ],
 "DNS search domains": [
  null,
  "DNS-hakutoimialueet"
 ],
 "Add search domain": [
  null,
  "Lisää hakutoimialue"
 ],
 "Search domain": [
  null,
  "Etsi verkkoaluetta"
 ],
 "Routes": [
  null,
  "Reitit"
 ],
 "Add route": [
  null,
  "Lisää reitti"
 ],
 "Metric": [
  null,
  "Mittarit"
 ],
 "Enter a valid MAC address": [
  null,
  "Anna kelvollinen MAC-osoite"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 verkko",
  "$0 verkkoa"
 ],
 "Add VPN": [
  null,
  "Lisää VPN"
 ],
 "Add bond": [
  null,
  "Lisää sidos"
 ],
 "Add VLAN": [
  null,
  "Lisää VLAN"
 ],
 "Edit rules and zones": [
  null,
  "Muokkaa sääntöjä ja vyöhykkeitä"
 ],
 "$0 active zone": [
  null,
  "$0 aktiivinen vyöhyke",
  "$0 aktiivista vyöhykettä"
 ],
 "Managed interfaces": [
  null,
  "Hallitut liitännät"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "Sending": [
  null,
  "Lähetetään"
 ],
 "Receiving": [
  null,
  "Vastaanotetaan"
 ],
 "Unmanaged interfaces": [
  null,
  "Hallitsemattomat liitännät"
 ],
 "Network logs": [
  null,
  "Verkkolokit"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Osoitteet eivät ole oikein muotoiltuja"
 ],
 "Invalid IP address '$0'": [
  null,
  "Ei kelvollinen IP-osoite '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools-pakettia ei ole asennettu"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Vertaislaitteella #$0 on virheellinen päätepiste. Se on määritettävä muodossa isäntä:portti, esim. 1.2.3.4:51820, [2001:db8::1]:51820 tai esimerkiksi.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Vertaisella #$0 on virheellinen päätepisteportti. Portin on oltava numero."
 ],
 "Listen port must be a number": [
  null,
  "Kuunteluportin on oltava numero"
 ],
 "Add WireGuard VPN": [
  null,
  "Lisää WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Muokkaa WireGuard VPN:ia"
 ],
 "Private key": [
  null,
  "Yksityinen avain"
 ],
 "Paste existing key": [
  null,
  "Liitä olemassa oleva avain"
 ],
 "Regenerate": [
  null,
  "Luo uudelleen"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Julkinen avain luodaan, kun kelvollinen yksityinen avain välitetään"
 ],
 "Listen port": [
  null,
  "Kuunteluportti"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Asetetaan \"Automaattinen\""
 ],
 "IP addresses": [
  null,
  "IP-osoitteet"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Useita osoitteita voidaan määrittää käyttämällä pilkkuja tai välilyöntejä erottimina."
 ],
 "Peers": [
  null,
  "Osapuolet"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Vertaiset ovat muita koneita, jotka muodostavat yhteyden tähän koneeseen. Muiden koneiden julkiset avaimet jaetaan toistensa kanssa."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"Palvelimena\" toimiva päätepiste on määritettävä 'isäntä:portti':na, muuten se voidaan jättää tyhjäksi."
 ],
 "Add peer": [
  null,
  "Lisää vertainen"
 ],
 "Endpoint": [
  null,
  "Päätepiste"
 ],
 "Allowed IPs": [
  null,
  "Sallitut IP-osoitteet"
 ],
 "No peers added.": [
  null,
  "Ei lisätty vertaisia."
 ],
 "Edit VLAN settings": [
  null,
  "Muokkaa VLAN-asetuksia"
 ],
 "Parent": [
  null,
  "Vanhemmat"
 ],
 "VLAN ID": [
  null,
  "VLAN-tunnus"
 ],
 "Transmitting": [
  null,
  "Lähetetään"
 ],
 "MTU must be a positive number": [
  null,
  "MTU:n tulee olla positiivinen numero"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Set to": [
  null,
  "Aseta tähän"
 ],
 "Team port settings": [
  null,
  "Joukkueen portin asetukset"
 ],
 "Sticky": [
  null,
  "Tahmea"
 ],
 "LACP key": [
  null,
  "LACP-avain"
 ],
 "Bridge port settings": [
  null,
  "Sillan porttiasetukset"
 ],
 "Path cost": [
  null,
  "Polun kustannus"
 ],
 "Hair pin mode": [
  null,
  "Hair Pin -tila"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Mukautuva lähtevän kuorman tasaus"
 ],
 "Adaptive load balancing": [
  null,
  "Mukautuva kuormantasaus"
 ],
 "MII (recommended)": [
  null,
  "MII (suositeltu)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Muokkaa sidosasetuksia"
 ],
 "Network bond": [
  null,
  "Verkkosidos"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Verkkosidos yhdistää useita verkkoliitäntöjä yhdeksi loogiseksi liitännäksi, jolla on korkeampi suorituskyky tai redundanssi."
 ],
 "Link monitoring": [
  null,
  "Linkin valvonta"
 ],
 "Monitoring interval": [
  null,
  "Monitorointiväli"
 ],
 "Monitoring targets": [
  null,
  "Kohteiden seuranta"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Verkkoliitännän $0 poistaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Remove $0": [
  null,
  "Poista $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0:n lisääminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "No interfaces available": [
  null,
  "Ei saatavilla olevia rajapintoja"
 ],
 "Add member": [
  null,
  "Lisää jäsen"
 ],
 "Interface members": [
  null,
  "Liitännän jäsenet"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ]
});
