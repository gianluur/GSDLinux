cockpit.locale({
 "": {
  "plural-forms": ((n) => n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3),
  "language": "sl",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 napak",
  "$0 napaka",
  "$0 napaki",
  "$0 napake"
 ],
 "$0 installation": [
  null,
  "Namestitev $0"
 ],
 "$0 installer": [
  null,
  "Namestilnik $0"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 je razširjen razdelek MBR, ki vsebuje logične razdelke. Odstranjevanje vseh logičnih razdelkov bo samodejno odstranilo tudi razširjeni razdelek."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 je zahtevan, a samo $1 je na voljo."
 ],
 "$0 warning": [
  null,
  "$0 opozoril",
  "$0 opozorilo",
  "$0 opozorili",
  "$0 opozorila"
 ],
 "$0 will be deleted": [
  null,
  "$0 bo izbrisano"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Datotečni sistem »$0« ne more biti na šifrirani bločni napravi"
 ],
 "'$0' must be assigned to $1": [
  null,
  "»$0« mora biti dodeljeno $1"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "»$0« mora biti na napravi, ki je formatirana na »$1«"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "'$0' mora biti na sistemskem razdelku EFI. Izbrani razdelek uporablja datotečni sistem FAT, vendar ni označen kot ESP. Nastavite vrsto razdelka na sistemski EFI in omogočite zastavico esp."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Najden razdelek '$0' na napravi MDRAID $1. Razdelki zagonskega nalagalnika na napravah MDRAID niso podprti."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Standardni uporabniški račun s skrbniškim dostopom za spremembe na ravni celega sistema."
 ],
 "Abort installation": [
  null,
  "Prekini namestitev"
 ],
 "About": [
  null,
  "O programu"
 ],
 "Account": [
  null,
  "Račun"
 ],
 "Actions": [
  null,
  "Dejanja"
 ],
 "Add another server...": [
  null,
  "Dodaj drug strežnik..."
 ],
 "Add mount": [
  null,
  "Dodaj nosilec"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Dodatki za vaše izbrano okolje"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Splošni dodatki, ne le za vaše okolje"
 ],
 "Additional languages": [
  null,
  "Dodatni jeziki"
 ],
 "Additional software for the selected environment": [
  null,
  "Dodatno programje za izbrano okolje"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Vse spremembe v urejevalniku hrambe začnejo veljati takoj."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Vse naprave, ki uporabljajo to šifrirno geslo, bodo odklenjene"
 ],
 "Anaconda Web UI": [
  null,
  "Spletni vmesnik Anaconda"
 ],
 "Anaconda project page": [
  null,
  "Stran projekta Anaconda"
 ],
 "Apply mount point assignment and install": [
  null,
  "Uveljavi dodelitev točke priklopa in namesti"
 ],
 "Applying changes...": [
  null,
  "Uveljavljanje sprememb..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Dodeli razdelke na priklopne točke. Uporabno za vnaprej prilagojene postavitve po meri."
 ],
 "Automatic log file upload": [
  null,
  "Samodejno nalaganje datoteke dnevnika"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Samodejno določi datum in čas s pomočjo časovnih strežnikov"
 ],
 "Automatically set timezone": [
  null,
  "Samodejno določi časovni pas"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Prostor na voljo: $0. Zahtevano za namestitev: $1."
 ],
 "Back": [
  null,
  "Nazaj"
 ],
 "Base environment": [
  null,
  "Osnovno okolje"
 ],
 "Brief description of the issue": [
  null,
  "Kratek opis težave"
 ],
 "Bug report details": [
  null,
  "Podrobnosti poročila o napaki"
 ],
 "Bugzilla API key": [
  null,
  "Ključ API-ja Bugzilla"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Če nadaljujete z uporabo te programske opreme, razumete in sprejemate tveganja, povezana s pred-izdajo programske opreme, jo nameravate uporabiti samo za namene testiranja in razvoja in ste pripravljeni prijaviti napake ali težave za izboljšanje tega dela."
 ],
 "Cancel": [
  null,
  "Prekliči"
 ],
 "Change": [
  null,
  "Spremeni"
 ],
 "Change destination": [
  null,
  "Spremeni cilj"
 ],
 "Change hostname": [
  null,
  "Spremeni ime gostitelja"
 ],
 "Change partition layout": [
  null,
  "Spremeni postavitev particije"
 ],
 "Change system keyboard layout": [
  null,
  "Spremeni sistemsko postavitev tipkovnice"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Spremembe, ki opravljene tukaj, bodo takoj vplivale na sistem. Ni »razveljavitve«."
 ],
 "Checking installation configuration...": [
  null,
  "Preverjanje prilagoditev namestitve ..."
 ],
 "Checking storage configuration": [
  null,
  "Preverjanje prilagoditve hrambe"
 ],
 "Clear search": [
  null,
  "Počisti iskanje"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Kliknite znova Naprej za nadaljevanje tem opozorilom navkljub."
 ],
 "Close": [
  null,
  "Zapri"
 ],
 "Close storage editor": [
  null,
  "Zapri urejevalnik hrambe"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Shramba ni zagotovila šifrirnega gesla za odklepanje šifrirane naprave."
 ],
 "Completed": [
  null,
  "Zaključeno"
 ],
 "Configuration is incomplete": [
  null,
  "Prilagoditev ni dokončana"
 ],
 "Configure NTP servers": [
  null,
  "Prilagodi strežnike NTP"
 ],
 "Configure custom NTP servers": [
  null,
  "Prilagodi strežnike NTP po meri"
 ],
 "Configure network": [
  null,
  "Konfiguriraj omrežje"
 ],
 "Configure storage": [
  null,
  "Prilagodi hrambo"
 ],
 "Configure storage again": [
  null,
  "Znova prilagodi hrambo"
 ],
 "Confirm passphrase": [
  null,
  "Potrdi šifrirno geslo"
 ],
 "Continue": [
  null,
  "Nadaljuj"
 ],
 "Continue installation": [
  null,
  "Nadaljuj z namestitvijo"
 ],
 "Continue installation?": [
  null,
  "Ali želite nadaljevati z namestitvijo?"
 ],
 "Continue with installation": [
  null,
  "Nadaljuj z namestitvijo"
 ],
 "Correct these issues before continuing.": [
  null,
  "Odpravite te težave pred nadaljevanjem."
 ],
 "Create Account": [
  null,
  "Ustvari račun"
 ],
 "Create account": [
  null,
  "Ustvari račun"
 ],
 "Currently installed: $0": [
  null,
  "Trenutno nameščeno: $0"
 ],
 "Custom": [
  null,
  "Po meri"
 ],
 "Date": [
  null,
  "Datum"
 ],
 "Date and time": [
  null,
  "Datum in čas"
 ],
 "Delete partition": [
  null,
  "Izbriši razdelek"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Brisanje določenih razdelkov lahko prepreči zagon $0: $1"
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Destination": [
  null,
  "Cilj"
 ],
 "Destination is encrypted": [
  null,
  "Cilj je šifriran"
 ],
 "Detailed description of the issue": [
  null,
  "Podrobni opis težave"
 ],
 "Detected valid storage layout:": [
  null,
  "Zaznana veljavna postavitev hrambe:"
 ],
 "Device": [
  null,
  "Naprava"
 ],
 "Duplicate device.": [
  null,
  "Podvoji napravo."
 ],
 "Duplicate mount point.": [
  null,
  "Podvoji priklopno točko."
 ],
 "Enable root account": [
  null,
  "Omogoči korenski račun"
 ],
 "Encrypt my data": [
  null,
  "Šifriraj moje podatke"
 ],
 "Encrypted": [
  null,
  "Šifrirano"
 ],
 "Encryption": [
  null,
  "Šifriranje"
 ],
 "Enter PIN": [
  null,
  "Vnesite PIN"
 ],
 "Enter PIN to access the installer": [
  null,
  "Vnesite PIN, da lahko dostopate do namestilnika"
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Vnesite svoj ključ API-ja Bugzilla, da ustvarite poročilo o napaki. Podrobnosti o napaki boste lahko pregledali in uredili v naslednjem koraku."
 ],
 "Environment": [
  null,
  "Okolje"
 ],
 "Erase data and install": [
  null,
  "Izbriši podatke in namesti"
 ],
 "Error details": [
  null,
  "Podrobnosti napake"
 ],
 "Exit to live desktop": [
  null,
  "Izhod v živo namizje"
 ],
 "Extended partition": [
  null,
  "Razširjen razdelek"
 ],
 "Failed to report issue": [
  null,
  "Neuspela prijava težave"
 ],
 "Failed to save layouts": [
  null,
  "Neuspelo shranjevanje postavitev"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux zahteva vsaj $0 prostora na disku."
 ],
 "Finalization": [
  null,
  "Zaključevanje"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Zaključevanje: Konfiguranje sistema končano. Zaključevanje nameščanja lahko traja še nekaj trenutkov."
 ],
 "Find layout": [
  null,
  "Najdi postavitev"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Za večjo varnost se izogibajte neposredni rabi korenskega računa. Namesto tega uporabite zgornji krajevni račun za ravnanje s sistemom."
 ],
 "Full name": [
  null,
  "Polno ime"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Polno ime ne sme vsebovati dvopičij"
 ],
 "Helper text": [
  null,
  "Besedilo pomoči"
 ],
 "Hide API key": [
  null,
  "Skrij ključ API"
 ],
 "Hide PIN": [
  null,
  "Skrij PIN"
 ],
 "Hide confirmed password": [
  null,
  "Skrij potrjeno geslo"
 ],
 "Hide passphrase": [
  null,
  "Skrij šifrirno geslo"
 ],
 "Hide password": [
  null,
  "Skrij geslo"
 ],
 "Hostname": [
  null,
  "Ime gostitelja"
 ],
 "How would you like to install?": [
  null,
  "Kako želite namestiti?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Razumem, da bodo vsi obstoječi podatki izbrisani iz izbranih diskov",
  "Razumem, da bodo vsi obstoječi podatki izbrisani",
  "Razumem, da bodo vsi obstoječi podatki izbrisani iz izbranih diskov",
  "Razumem, da bodo vsi obstoječi podatki izbrisani iz izbranih diskov"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Razumem, da bodo nekateri obstoječi podatki izbrisani"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Razumem, da bodo nekateri razdelki spremenjeni"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Če je prazno, bo ime gostitelja prehodno in nastavljeno z informacijami o omrežju."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  "Če ni uporabna nobena od zgornjih možnosti, uporabite urejevalnik hrambe, da pred nadaljevanjem ustvarite particije po meri."
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Če prilagajate razdelke, potrebujete naslednje:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Če ne soglašate s samodejnim nalaganjem datotek dnevnika, lahko $0 namesto tega. Ročno poročanje vam omogoča, da sami pregledate in selektivno priložite datoteke dnevnika."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Če ne razumete ali sprejemate tveganj, prosimo da zapustite ta program."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  "Če se vaša težava ujema z eno od zgornjih napak, jo lahko odprete in dodate svoje podatke tam, namesto da ustvarite podvojeno poročilo."
 ],
 "In progress": [
  null,
  "V postopku"
 ],
 "Initializing...": [
  null,
  "Inicializacija ..."
 ],
 "Install": [
  null,
  "Namesti"
 ],
 "Installation completed": [
  null,
  "Nameščanje dokončano"
 ],
 "Installation failed": [
  null,
  "Nameščanje ni uspelo"
 ],
 "Installation method": [
  null,
  "Način namestitve"
 ],
 "Installation of the system failed": [
  null,
  "Namestitev sistema ni uspela"
 ],
 "Installation of the system failed: $0": [
  null,
  "Namestitev sistema ni uspela: $0"
 ],
 "Installation type": [
  null,
  "Vrsta namestitve"
 ],
 "Installing": [
  null,
  "Nameščanje"
 ],
 "Insufficient disk space": [
  null,
  "Nezadosten prostor na disku"
 ],
 "Invalid PIN. Please try again.": [
  null,
  "Neveljaven PIN. Poskusite znova."
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Zaznana je neveljavna prilagoditev RAID-a. Če je vaše polje RAID ustvarjeno neposredno na diskih, je treba na polju ustvariti tabelo razdelkov. Če je vaše polje RAID ustvarjeno na razdelkih, mora vsebovati en sam datotečni sistem ali format (npr. LVM PV). Vsi obstoječi razdelki na tem polju bodo prezrti."
 ],
 "Invalid hostname": [
  null,
  "Neveljavno ime gostitelja"
 ],
 "Jump to first incomplete step": [
  null,
  "Skoči na prvi nezaključen korak"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Ohrani trenutno postavitev diska in uporabi razpoložljiv prostor za dvojni zagon z drugim OS."
 ],
 "Keyboard": [
  null,
  "Tipkovnica"
 ],
 "Keyboard layout during boot": [
  null,
  "Postavitev tipkovnice med zagonom"
 ],
 "Language": [
  null,
  "Jezik"
 ],
 "Launch storage editor": [
  null,
  "Zaženi urejevalnik hrambe"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Poučite se več o omejenem dostopu v konfiguraciji"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Pustite obe polji šifrirnega gesla prazni, da uporabite prazno geslo."
 ],
 "Location": [
  null,
  "Lokacija"
 ],
 "Locked devices": [
  null,
  "Zaklenjene naprave"
 ],
 "Log in": [
  null,
  "Prijava"
 ],
 "Make current": [
  null,
  "Naredi trenutno"
 ],
 "Manual disk configuration": [
  null,
  "Ročna konfiguracija diska"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Ročna konfiguracija diska: preslikava priklopnih točk"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Lahko vsebuje črke, števke in pomišljaje."
 ],
 "May need more free space": [
  null,
  "Bo morda potreboval več praznega prostora"
 ],
 "Medium": [
  null,
  "Medij"
 ],
 "Minimum of $0 required": [
  null,
  "Potrebnih je najmanj $0"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Neusklajenost med izbiro ponovnega formatiranja nadrejene naprave in podrejene naprave."
 ],
 "Mount point": [
  null,
  "Točka priklopa"
 ],
 "Mount point assignment": [
  null,
  "Dodelitev priklopne točke"
 ],
 "Move down": [
  null,
  "Premakni navzdol"
 ],
 "Move up": [
  null,
  "Premakni navzgor"
 ],
 "Must be at least $0 characters": [
  null,
  "Imeti mora vsaj $0 znakov"
 ],
 "My issue is different, continue": [
  null,
  "Moja težava je drugačna, nadaljujte"
 ],
 "NTP Servers": [
  null,
  "Strežniki NTP"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Ime"
 ],
 "Needs at least $0": [
  null,
  "Potrebuje vsaj $0"
 ],
 "Network": [
  null,
  "Omrežje"
 ],
 "Network Configuration": [
  null,
  "Konfiguracija omrežja"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Omrežje ni na voljo. Prilagodite omrežje v meniju zgornje vrstice, da prijavite težavo."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Omrežje ni na voljo. Prilagodite omrežje za prijavo težave."
 ],
 "Network plugin failed": [
  null,
  "Omrežni vtičnik ni uspel"
 ],
 "Next": [
  null,
  "Naprej"
 ],
 "No devices": [
  null,
  "Ni naprav"
 ],
 "No disks available": [
  null,
  "Noben disk ni na voljo"
 ],
 "No disks selected": [
  null,
  "Ni izbranih diskov"
 ],
 "No keyboard layouts selected": [
  null,
  "Nobena postavitev tipkovnice še ni izbrana"
 ],
 "No layouts selected yet": [
  null,
  "Nobena postavitev še ni izbrana"
 ],
 "No results found": [
  null,
  "Ni zadetkov"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Za izbrane postavitve tipkovnic ni možno pridobiti veljavnih preslikav tipk VConsole. Izberite drugo postavitev tipkovnice."
 ],
 "Not enough available free space": [
  null,
  "Ni dovolj razpoložljivega prostega prostora"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Na izbranih diskih ni dovolj prostega prostora."
 ],
 "Not enough space on selected disks.": [
  null,
  "Premalo prostora na izbranih diskih."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Obvestilo: To je predhodna izdaja programske opreme, ki je namenjena zgolj razvoju in testiranju. *Ne* uporabljajte te programske opreme za kakršnokoli kritično delo ali v produkcijskem okolju."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Odpri obrazec za prijavo napak v Bugzilli"
 ],
 "Operating system": [
  null,
  "operacijski sistem"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Other keyboards": [
  null,
  "Druge tipkovnice"
 ],
 "Partitions (advanced)": [
  null,
  "Razdelki (napredno)"
 ],
 "Passphrase": [
  null,
  "Geselna fraza"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Šifrirno geslo se ni ujemalo z nobeno zaklenjeno napravo"
 ],
 "Passphrases must match": [
  null,
  "Šifrirna gesla se morajo ujemati"
 ],
 "Pending": [
  null,
  "V teku"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Priložite zapisniško datoteko $0 k prijavi."
 ],
 "Please enter a PIN": [
  null,
  "Vnesite PIN"
 ],
 "Please select at least one disk to continue": [
  null,
  "Izberite vsaj en disk za nadaljevanje"
 ],
 "Pool": [
  null,
  "Nabor"
 ],
 "Potential duplicate bugs found": [
  null,
  "Najdeni potencialni dvojni napaki"
 ],
 "Powered by Anaconda": [
  null,
  "Poganja Anaconda"
 ],
 "Pre-release": [
  null,
  "Pred-izdaja"
 ],
 "Prefer to report manually? $0": [
  null,
  "Bi raje poročali ročno? $0"
 ],
 "Proceed with installation": [
  null,
  "Nadaljuj z namestitvijo"
 ],
 "Quit": [
  null,
  "Zapusti"
 ],
 "Quit installer?": [
  null,
  "Želite zapustiti namestilnik?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Branje informacij o operacijskem sistemu ni uspelo."
 ],
 "Reading information about the computer failed.": [
  null,
  "Branje informacij o računalniku ni uspelo."
 ],
 "Reading installer configuration failed.": [
  null,
  "Branje prilagoditve namestitvenega programa ni uspelo."
 ],
 "Reading installer version information failed.": [
  null,
  "Branje informacij o različici namestitvenega programa ni uspelo."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Pravo ime gostitelja lahko vsebuje samo znake, števke, pomišljaje (ne kot začetek ali konec znaka) in pike"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Pravo ime gostitelja mora biti dolgo 64 znakov ali manj"
 ],
 "Reboot": [
  null,
  "Ponovni zagon"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Znova zaženite sistem Windows, da spremenite velikost razdelkov, šifriranih z BitLockerjem. Za namestitev sprostite vsaj $0 prostora."
 ],
 "Reboot system?": [
  null,
  "Želite ponovno zagnati sistem?"
 ],
 "Reclaim additional space": [
  null,
  "Pridobite dodaten prostor"
 ],
 "Reclaim space": [
  null,
  "Zahtevaj prostor nazaj"
 ],
 "Reclaim space (required)": [
  null,
  "Povrni prostor (obvezno)"
 ],
 "Recommended": [
  null,
  "Priporočeno"
 ],
 "Recommended partitions:": [
  null,
  "Priporočeni razdelki:"
 ],
 "Reformat": [
  null,
  "Ponovno formatiraj"
 ],
 "Reinstall Fedora": [
  null,
  "Ponovno namesti Fedoro"
 ],
 "Remove": [
  null,
  "Odstrani"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Odstranite vse razdelke na izbranih napravah, vključno z obstoječimi operacijskimi sistemi."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Odstranite ali spremenite velikost obstoječih datotečnih sistemov, da sprostite prostor za namestitev."
 ],
 "Remove server": [
  null,
  "Odstrani strežnik"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Odstranjevanje datotečnega sistema bo trajno izbrisalo vse hranjene podatke. S spreminjanjem velikosti razdelka lahko sicer sprostite prostor, vendar to ni brez tveganja. Preverite, da imate varnostne kopije vseh pomembnih podatkov, preden prevzamete prostor."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Zamenjaj trenutno namestitev, vendar ohrani datoteke v domači mapi (home)."
 ],
 "Report Issue": [
  null,
  "Poročaj o težavi"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Prijavite težavo ali podajte povratne informacije tako, da odprete obrazec za prijavo napak v Bugzilli $0."
 ],
 "Report issue": [
  null,
  "Poročaj o težavi"
 ],
 "Reporting issue...": [
  null,
  "Poročanje o težavi..."
 ],
 "Required": [
  null,
  "Obvezno"
 ],
 "Requirements": [
  null,
  "Zahteve"
 ],
 "Rescan devices": [
  null,
  "Ponovno prečeši naprave"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Ponovno pregledovanje diskov ni uspelo."
 ],
 "Resize": [
  null,
  "Spremeni velikost"
 ],
 "Resize partition": [
  null,
  "Spremeni velikost razdelka"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Spreminjanje velikosti naslednjih razdelkov z $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Omeji dostop do poročila"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Omeji poročilo na skupino $0. $1"
 ],
 "Return to installation": [
  null,
  "Nazaj na namestitev"
 ],
 "Return to storage editor": [
  null,
  "Nazaj v urejevalnik hrambe"
 ],
 "Review and install": [
  null,
  "Pregled in nameščanje"
 ],
 "Root account has been configured": [
  null,
  "Korenski račun je bil prilagojen"
 ],
 "Root account is enabled": [
  null,
  "Korenski račun je omogočen"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Korenski račun je omogočen, vendar noben uporabniški račun ni bil nastavljen"
 ],
 "Root password has been set.": [
  null,
  "Korensko geslo je bilo nastavljeno."
 ],
 "Save": [
  null,
  "Shrani"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Optično preberite QR-kodo s telefonom ali obiščite:"
 ],
 "Search for a language": [
  null,
  "Poiščite jezik"
 ],
 "Search for additional software": [
  null,
  "Poiščite dodatno programje"
 ],
 "Search for an environment": [
  null,
  "Poiščite okolje"
 ],
 "Search keyboard layout": [
  null,
  "Išči postavitev tipkovnice"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Zavarujte svoje podatke z uporabo šifriranja na ravni diska. Velja le za nove razdelke"
 ],
 "Select": [
  null,
  "Izberi"
 ],
 "Select a device": [
  null,
  "Izberite napravo"
 ],
 "Select city": [
  null,
  "Izberite mesto"
 ],
 "Select destination": [
  null,
  "Izberite cilj"
 ],
 "Select region": [
  null,
  "Izberite pokrajino"
 ],
 "Selected (top = current)": [
  null,
  "Izbrana (vrhnja = trenutna)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Oblike zapisa izbrane naprave »$0« ni mogoče preoblikovati."
 ],
 "Send us feedback on your installation": [
  null,
  "Pošljite nam povratne informacije o namestitvi"
 ],
 "Server": [
  null,
  "Strežnik"
 ],
 "Server is not reachable": [
  null,
  "Strežnik ni dosegljiv"
 ],
 "Set custom hostname": [
  null,
  "Določite ime gostitelja po meri"
 ],
 "Share disk with other operating systems": [
  null,
  "Deli disk z drugimi operacijskimi sistemi"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Deli disk z drugim operacijskim sistemom: $0"
 ],
 "Show AM/PM": [
  null,
  "Pokaži dop/pop"
 ],
 "Show API key": [
  null,
  "Pokaži ključ API"
 ],
 "Show PIN": [
  null,
  "Pokaži PIN"
 ],
 "Show confirmed password": [
  null,
  "Pokaži potrjeno geslo"
 ],
 "Show passphrase": [
  null,
  "Pokaži šifrirno geslo"
 ],
 "Show password": [
  null,
  "Pokaži geslo"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Software installation": [
  null,
  "Nameščanje programja"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Nameščanje programja: Konfiguracija hrambe končana. Programje se zdaj namešča na vašo napravo."
 ],
 "Software selection": [
  null,
  "Izbira programja"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Pred nadaljevanjem morate dokončati še nekatere korake namestitve."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Manjkajo nekateri zahtevani razdelki: $0"
 ],
 "Space": [
  null,
  "Prostor"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Shramba"
 ],
 "Storage configuration": [
  null,
  "Konfiguracija hrambe"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Konfiguracija hrambe: Hramba se trenutno konfigurira."
 ],
 "Storage editor": [
  null,
  "Urejevalnik hrambe"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Shranjevanje temelji na nastavitvah iz »Spremeni shrambo«."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Razpored prostora na disku je določen v datoteki kickstart. Načrtovano razporeditev razdelkov si lahko ogledate v koraku s povzetkom."
 ],
 "Storage plugin failed": [
  null,
  "Vstavek za hrambo ni uspel"
 ],
 "Storage requirements not met": [
  null,
  "Zahteve za shrambo niso izpolnjene"
 ],
 "Strong": [
  null,
  "Močno"
 ],
 "Successfully installed": [
  null,
  "Uspešno nameščeno"
 ],
 "Successfully unlocked $0.": [
  null,
  "Uspešno odklenjeno: $0."
 ],
 "Suggested keyboards": [
  null,
  "Predlagane tipkovnice"
 ],
 "Suggested languages": [
  null,
  "Predlagani jeziki"
 ],
 "System": [
  null,
  "Sistemski"
 ],
 "System configuration": [
  null,
  "Konfiguracija sistema"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Konfiguracija sistema: Nameščanje programja končano. Sistem se zdaj konfigurira."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Namestitev Anaconde se je nepričakovano ustavila."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  "Naslednje odprte napake so lahko povezane z vašo težavo. Prosimo, da jih pregledate, preden ustvarite novo poročilo."
 ],
 "The following user will be created:": [
  null,
  "Naslednji uporabniki bodo ustvarjeni:",
  "Naslednji uporabnik bo ustvarjen:",
  "Naslednja uporabnika bosta ustvarjena:",
  "Naslednji uporabniki bodo ustvarjeni:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Za namestitev je potrebnega $0 prostora, kapaciteta izbranih diskov je zgolj $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Namestilnik ne more nadaljevati zaradi kritične napake."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Namestilnik ne more nadaljevati zaradi kritične napake: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  "Razporeditev tipkovnice se je spremenila, odkar je bilo nastavljeno geslo za šifriranje diska. Ponovno vnesite geslo."
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Dana geselna fraza geslo vsebuje znake, ki niso iz nabora ASCII. Pri tipkanju morda ne boste mogli preklopiti med postavitvami tipkovnice."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Dejavna postavitev tipkovnice ne podpira znakov ASCII. Kot privzeto postavitev izberite takšno, ki podpira ASCII."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Urejevalnik shrambe vam omogoča spremeniti velikost, izbrisati in ustvarjati razdelke. Vzpostavi lahko LVM in še več. Namenjen je rabi kot napredno orodje in ne za tipične namestitve."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Te dnevniške datoteke lahko vsebujejo občutljive podatke, kot so naslovi IP, uporabniška imena ali druge sistemske podrobnosti."
 ],
 "This hostname can't be submitted": [
  null,
  "Tega imena gostitelja ni mogoče poslati"
 ],
 "This is unstable, pre-release software": [
  null,
  "To je nestabilno programje pred izdajo"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Ta postavitev bo uporabljena za odklepanje vašega sistema ob zagonu"
 ],
 "This may take a moment": [
  null,
  "To utegne nekaj časa trajati"
 ],
 "This will take a few moments": [
  null,
  "To utegne trajati nekaj časa"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Timezone": [
  null,
  "Časovni pas"
 ],
 "Title": [
  null,
  "Naslov"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Če želite začeti uporabljati $0, znova zaženite sistem."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Če želite nadaljevati, izberite naprave, v katere želite nameščati."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Če želite uporabiti to možnost, spremenite velikost ali odstranite obstoječe razdelke, da sprostite vsaj $0."
 ],
 "Type": [
  null,
  "Vrsta"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Ni mogoče načrtovati brisanja $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Ni mogoče načrtovati spreminjanja velikosti $0"
 ],
 "Undo last action": [
  null,
  "Razveljavi zadnje dejanje"
 ],
 "Unlock": [
  null,
  "Odkleni"
 ],
 "Unlock encrypted devices": [
  null,
  "Odkleni šifrirane naprave"
 ],
 "Unlock encrypted partitions to keep existing data and show more installation methods.": [
  null,
  "Odklenite šifrirane razdelke, da ohranite obstoječe podatke in pokažete več metod namestitve."
 ],
 "Use configured storage": [
  null,
  "Uporabi nastavljeno hrambo"
 ],
 "Use entire disk": [
  null,
  "Uporabi celoten disk"
 ],
 "Use free space": [
  null,
  "Uporabi prosti prostor"
 ],
 "Use local account": [
  null,
  "Ustvari krajevni račun"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Uporabi napravo RAID za samodejno particioniranje"
 ],
 "User creation": [
  null,
  "Kreiranje uporabnika"
 ],
 "User name": [
  null,
  "Uporabniško ime"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Uporabniško ime lahko vsebuje samo: črke od a do z, števke 0-9, pomišljaj $0, piko $1, podčrtaj $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Uporabniško ime ne sme biti rezervirana beseda"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Uporabniška imena morajo biti krajša od 33 znakov"
 ],
 "Validating...": [
  null,
  "Potrjevanje..."
 ],
 "Weak": [
  null,
  "Šibko"
 ],
 "Welcome": [
  null,
  "Dobrodošli"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Dobrodošli v Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Dobrodošli. Namestimo $0 zdaj."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Ko oddate to poročilo o napaki, bodo samodejno naložene naslednje datoteke dnevnika: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Velikosti razdelkov sistema Windows s šifriranjem BitLocker ni mogoče spremeniti"
 ],
 "You can close this browser window now.": [
  null,
  "Zdaj lahko zaprete to okno brskalnika."
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Tukaj lahko sprostite dovolj prostora in pustite, da namestitveni program poskrbi za ostalo ali ročno nastavite razdelke."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Lahko generirate ključ API za svoj račun Bugzilla $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Morate omogočiti korenski račun ali kreirati lokalni uporabniški račun za nadaljevanje."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Povezani morate biti v omrežje, da omogočite samodejno določanje datuma in časa."
 ],
 "Your progress will not be saved.": [
  null,
  "Vaš napredek ne bo shranjen."
 ],
 "completed step": [
  null,
  "zaključen korak"
 ],
 "current step": [
  null,
  "trenutni korak"
 ],
 "delete": [
  null,
  "izbriši"
 ],
 "edit": [
  null,
  "uredi"
 ],
 "encrypt": [
  null,
  "šifriraj"
 ],
 "encrypted": [
  null,
  "šifrirano"
 ],
 "extended partition": [
  null,
  "razširjen razdelek"
 ],
 "format as $0": [
  null,
  "formatiraj kot $0"
 ],
 "here": [
  null,
  "tukaj"
 ],
 "incomplete": [
  null,
  "nedokončano"
 ],
 "mount": [
  null,
  "priklop"
 ],
 "pending step": [
  null,
  "korak v teku"
 ],
 "report the issue manually": [
  null,
  "ročno prijavite težavo"
 ],
 "resized from $0": [
  null,
  "spremenjena velikost iz $0"
 ],
 "shrink": [
  null,
  "skrči"
 ],
 "shrink to $0": [
  null,
  "skrči na $0"
 ],
 "transient, will use DHCP": [
  null,
  "prehodno, uporabljen bo DHCP"
 ],
 "undo": [
  null,
  "razveljavi"
 ]
});
