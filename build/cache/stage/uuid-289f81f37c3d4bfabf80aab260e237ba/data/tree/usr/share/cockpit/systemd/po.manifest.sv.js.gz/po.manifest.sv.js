cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "sv",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Tjänster"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "time": [
  null,
  "tid"
 ],
 "date": [
  null,
  "datum"
 ],
 "restart": [
  null,
  "starta om"
 ],
 "shut": [
  null,
  "stäng"
 ],
 "domain": [
  null,
  "domän"
 ],
 "machine": [
  null,
  "maskin"
 ],
 "operating system": [
  null,
  "operativsystem"
 ],
 "os": [
  null,
  "os"
 ],
 "asset tag": [
  null,
  "tillgångstagg"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "power": [
  null,
  "ström"
 ],
 "version": [
  null,
  "version"
 ],
 "host": [
  null,
  "värd"
 ],
 "hardware": [
  null,
  "hårdvara"
 ],
 "mitigation": [
  null,
  "rättningar"
 ],
 "pci": [
  null,
  "pci"
 ],
 "memory": [
  null,
  "minne"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "bios": [
  null,
  "bios"
 ],
 "ram": [
  null,
  "ram"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "serial": [
  null,
  "seriell"
 ],
 "graphs": [
  null,
  "grafer"
 ],
 "metrics": [
  null,
  "mått"
 ],
 "history": [
  null,
  "historik"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "disks": [
  null,
  "diskar"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "performance": [
  null,
  "prestanda"
 ],
 "Configuring system settings": [
  null,
  "Konfigurerar systeminställningar"
 ],
 "service": [
  null,
  "tjänst"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "mål"
 ],
 "socket": [
  null,
  "uttag"
 ],
 "timer": [
  null,
  "timer"
 ],
 "path": [
  null,
  "sökväg"
 ],
 "unit": [
  null,
  "enhet"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "boot": [
  null,
  "start"
 ],
 "mask": [
  null,
  "mask"
 ],
 "unmask": [
  null,
  "avmaskera"
 ],
 "enable": [
  null,
  "aktivera"
 ],
 "disable": [
  null,
  "avaktivera"
 ],
 "Managing services": [
  null,
  "Hantera tjänster"
 ],
 "journal": [
  null,
  "journal"
 ],
 "warning": [
  null,
  "varning"
 ],
 "error": [
  null,
  "fel"
 ],
 "debug": [
  null,
  "felsök"
 ],
 "crash": [
  null,
  "krasch"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "Reviewing logs": [
  null,
  "Granska loggar"
 ],
 "console": [
  null,
  "konsol"
 ],
 "command": [
  null,
  "kommando"
 ],
 "bash": [
  null,
  "bash"
 ],
 "shell": [
  null,
  "skal"
 ],
 "SELinux": [
  null,
  "SELinux"
 ]
});
