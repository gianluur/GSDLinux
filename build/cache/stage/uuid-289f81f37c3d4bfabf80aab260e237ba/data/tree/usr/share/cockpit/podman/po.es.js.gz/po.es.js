cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "es",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "¿Eliminar $0?"
 ],
 "Force delete": [
  null,
  "Forzar el borrado"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Must be a valid IP address": [
  null,
  "Debe ser una dirección IP válida"
 ],
 "1 to 65535": [
  null,
  "1 a 65535"
 ],
 "Container port must not be empty": [
  null,
  "El puerto de contenedores no debe estar vacío"
 ],
 "IP address": [
  null,
  "Dirección IP"
 ],
 "IP address help": [
  null,
  "Ayuda de dirección IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Si IP del host se fija a 0.0.0.0 o no se fija nada, el puerto estará vinculado a todas las IP del host."
 ],
 "Host port": [
  null,
  "Puerto host"
 ],
 "Host port help": [
  null,
  "Ayuda del puerto host"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Si no se asigna el puerto del host, el puerto del contenedor se asignará a un puerto aleatorio del host."
 ],
 "Container port": [
  null,
  "Puerto del contenedor"
 ],
 "Protocol": [
  null,
  "Protocolo"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Eliminar elemento"
 ],
 "Image name is required": [
  null,
  "Se requiere un nombre para la imagen"
 ],
 "Image name is not unique": [
  null,
  "El nombre de la imagen no es único"
 ],
 "Failed to commit container $0": [
  null,
  "Falló hacer el commit en el contenedor $0"
 ],
 "New image name": [
  null,
  "Nombre de la nueva imagen"
 ],
 "Tag": [
  null,
  "Etiqueta"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Por ejemplo, Tu Nombre <tunombre@ejemplo.es>"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Pause container when creating image": [
  null,
  "Pausar el contenedor cuando se cree la imagen"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "El formato Docker es útil para compartir la imagen con Docker o Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Usar el formato heredado Docker"
 ],
 "Commit container": [
  null,
  "Confirmar contenedor"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crear una imagen nueva basada en el estado actual del contenedor $0."
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Force commit": [
  null,
  "Forzar commit"
 ],
 "Failed to force remove container $0": [
  null,
  "Falló al forzar el borrado del contenedor $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Eliminando un contenedor en ejecución borrará toda la información que haya en él."
 ],
 "Failed to stop container $0": [
  null,
  "Falló al parar el contenedor $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "No se puede detener $0 cuatrillizo"
 ],
 "Failed to start quadlet $0": [
  null,
  "No se puede iniciar $0 cuatrillizo"
 ],
 "Failed to start container $0": [
  null,
  "Falló al iniciar el contenedor $0"
 ],
 "Failed to resume container $0": [
  null,
  "Fallo al reanudar el contenedor $0"
 ],
 "Failed to pause container $0": [
  null,
  "Fallo al pausar el contenedor $0"
 ],
 "Failed to restart container $0": [
  null,
  "Falló al reiniciar el contenedor $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "No se puede reiniciar $0 cuatrillizo"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Stop": [
  null,
  "Parar"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Force stop": [
  null,
  "Forzar la parada"
 ],
 "Force restart": [
  null,
  "Forzar el reinicio"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Resume": [
  null,
  "Reanudar"
 ],
 "Checkpoint": [
  null,
  "Punto comprobante"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Restore": [
  null,
  "Restaurar"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Healthy": [
  null,
  "Buen estado de salud"
 ],
 "Unhealthy": [
  null,
  "Mal estado de salud"
 ],
 "Checking health": [
  null,
  "Comprobando estado de salud"
 ],
 "Prune unused containers": [
  null,
  "Eliminar contenedores no utilizados"
 ],
 "Terminal not available": [
  null,
  "Terminal no está disponible"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Este navegador no soporta WebGL2."
 ],
 "View $0 logs": [
  null,
  "Ver $0 bitácoras"
 ],
 "not available": [
  null,
  "no disponible"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "$0% of $1 limit": [
  null,
  "$0% de $1 límite"
 ],
 "service": [
  null,
  "servicio"
 ],
 "system": [
  null,
  "sistema"
 ],
 "user:": [
  null,
  "usuario:"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Integration": [
  null,
  "Integración"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "Console": [
  null,
  "Consola"
 ],
 "Health check": [
  null,
  "Comprobación del estado de salud"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Click to see published ports": [
  null,
  "Pulse para ver los puertos publicados"
 ],
 "ports": [
  null,
  "puertos"
 ],
 "Click to see volumes": [
  null,
  "Pulse para ver los volúmenes"
 ],
 "volumes": [
  null,
  "volúmenes"
 ],
 "Container": [
  null,
  "Contenedor"
 ],
 "Owner": [
  null,
  "Propietario"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Actions": [
  null,
  "Acciones"
 ],
 "No containers": [
  null,
  "No hay contenedores"
 ],
 "No containers in this pod": [
  null,
  "No hay contenedores en este pod"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "No containers that match the current filter": [
  null,
  "No hay contenedores relacionados con los criterios de búsqueda"
 ],
 "No running containers": [
  null,
  "No hay contenedores ejecutándose"
 ],
 "Show": [
  null,
  "Mostrar"
 ],
 "All": [
  null,
  "Todo"
 ],
 "Only running": [
  null,
  "Sólo los que se están ejecutando"
 ],
 "Create pod": [
  null,
  "Crear pod"
 ],
 "Create container": [
  null,
  "Crear contenedor"
 ],
 "Containers": [
  null,
  "Contenedores"
 ],
 "Create container in pod": [
  null,
  "Crear un contenedor en el pod"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Fallo al restaurar el contenedor $0"
 ],
 "Restore container $0": [
  null,
  "Restaurar el contenedor $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Mantener todos los archivos temporales de checkpoint"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurar con las conexiones TCP establecidas"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorar la dirección IP si se ha configurado de forma estática"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorar la dirección MAC si se ha configurado de forma estática"
 ],
 "Pod failed to be created": [
  null,
  "Pod fallado al ser creado"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Carácteres inválidos. El nombre sólo puede contener letras, números y ciertos signos de puntuación (_ . -)."
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Pod name": [
  null,
  "Nombre del pod"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "User:": [
  null,
  "Usuario:"
 ],
 "No ports exposed": [
  null,
  "No hay puertos expuestos"
 ],
 "Port mapping": [
  null,
  "Mapeo de puertos"
 ],
 "Add port mapping": [
  null,
  "Añadir mapeo de puertos"
 ],
 "No volumes specified": [
  null,
  "No se han especificado volúmenes"
 ],
 "Volumes": [
  null,
  "Volúmenes"
 ],
 "Add volume": [
  null,
  "Añadir volumen"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Type to filter…": [
  null,
  "Escriba para establecer un criterio de búsqueda…"
 ],
 "Container path must not be empty": [
  null,
  "La ruta del contenedor no debe estar vacía"
 ],
 "Host path": [
  null,
  "Ruta del anfitrión"
 ],
 "Container path": [
  null,
  "Ruta del contenedor"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Writable": [
  null,
  "Puede escribirse"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Sin etiqueta"
 ],
 "Shared": [
  null,
  "Compartido"
 ],
 "Private": [
  null,
  "Privado"
 ],
 "Read-write access": [
  null,
  "Acceso de lectura y escritura"
 ],
 "Read-only access": [
  null,
  "Acceso de sólo lectura"
 ],
 "Show less": [
  null,
  "Mostrar menos"
 ],
 "Show more": [
  null,
  "Mostrar más"
 ],
 "Loading details...": [
  null,
  "Cargando detalles..."
 ],
 "Ports": [
  null,
  "Puertos"
 ],
 "Environment variables": [
  null,
  "Variables de entorno"
 ],
 "Failed to download image $0:$1": [
  null,
  "Fallo al descargar la imagen $0:$1"
 ],
 "Error message": [
  null,
  "Mensaje de error"
 ],
 "unused": [
  null,
  "sin utilizar"
 ],
 "$0 container": [
  null,
  "$0 contenedor",
  "$0 contenedores"
 ],
 "History": [
  null,
  "Historial"
 ],
 "Image": [
  null,
  "Imagen"
 ],
 "Created": [
  null,
  "Creado"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Tamaño en disco"
 ],
 "Used by": [
  null,
  "Usado por"
 ],
 "No images": [
  null,
  "No hay imágenes"
 ],
 "No images that match the current filter": [
  null,
  "No hay imágenes relacionadas con el criterio de búsqueda"
 ],
 "Hide intermediate images": [
  null,
  "Ocultar imágenes intermedias"
 ],
 "Show intermediate images": [
  null,
  "Mostrar imágenes intermedias"
 ],
 "Images": [
  null,
  "Imágenes"
 ],
 "$0 image total, $1": [
  null,
  "$0 imagen, $1",
  "$0 imágenes en total, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 imagen sin usar, $1",
  "$0 imágenes sin usar, $1"
 ],
 "Hide images": [
  null,
  "Ocultar imágenes"
 ],
 "Show images": [
  null,
  "Mostrar imágenes"
 ],
 "Pulling": [
  null,
  "Obteniendo"
 ],
 "Download new image": [
  null,
  "Descargar nueva imagen"
 ],
 "Pull all images": [
  null,
  "Sacar todas las imágenes"
 ],
 "Prune unused images": [
  null,
  "Eliminar imágenes no utilizadas"
 ],
 "Pull": [
  null,
  "Empujar"
 ],
 "Up since:": [
  null,
  "Levantado desde:"
 ],
 "Exited": [
  null,
  "Finalizado"
 ],
 "systemd service": [
  null,
  "servicio systemd"
 ],
 "View $0": [
  null,
  "Ver $0"
 ],
 "Gateway": [
  null,
  "Puerta de enlace"
 ],
 "MAC address": [
  null,
  "Dirección MAC"
 ],
 "Latest checkpoint": [
  null,
  "Último punto comprobante"
 ],
 "No containers are using this image": [
  null,
  "No hay contenedores que utilicen esta imagen"
 ],
 "Running": [
  null,
  "Ejecutándose"
 ],
 "Loading logs...": [
  null,
  "Cargando registros..."
 ],
 "Delete unused system images:": [
  null,
  "Eliminar imágenes del sistema sin usar:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Elimina imágenes inusuales del usuario $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Fallo al eliminar las imágenes no usadas"
 ],
 "Pruning images": [
  null,
  "Eliminando imágenes no utilizadas"
 ],
 "Prune": [
  null,
  "Eliminar"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Falló hacer el checkpoint del contenedor $0"
 ],
 "Checkpoint container $0": [
  null,
  "Crear checkpoint del contenedor $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Seguir ejecutando tras escribir el punto comprobante en disco"
 ],
 "Support preserving established TCP connections": [
  null,
  "Habilitar la preservación de las conexiones TCP establecidas"
 ],
 "Failed to search for new images": [
  null,
  "Falló al buscar nuevas imágenes"
 ],
 "Failed to search for images: $0": [
  null,
  "Fallo al buscar las imágenes: $0"
 ],
 "Failed to search for images.": [
  null,
  "Fallo al buscar imágenes."
 ],
 "Search for an image": [
  null,
  "Buscar una imagen"
 ],
 "Search for": [
  null,
  "Buscar"
 ],
 "Search by name or description": [
  null,
  "Buscar por nombre o descripción"
 ],
 "in": [
  null,
  "en"
 ],
 "All registries": [
  null,
  "Todos los registros"
 ],
 "Searching...": [
  null,
  "Buscando…"
 ],
 "No images found": [
  null,
  "No se han encontrado imágenes"
 ],
 "Start typing to look for images.": [
  null,
  "Comience a escribir para buscar imágenes."
 ],
 "No results for $0": [
  null,
  "No hay resultados para $0"
 ],
 "Retry another term.": [
  null,
  "Pruebe con otro término."
 ],
 "Download": [
  null,
  "Descargar"
 ],
 "No action": [
  null,
  "Ninguna acción"
 ],
 "Container failed to be started": [
  null,
  "El contenedor no pudo ser iniciado"
 ],
 "Failed to clean up container": [
  null,
  "Falló al limpiar el contenedor"
 ],
 "Container failed to be created": [
  null,
  "El contenedor no pudo ser creado"
 ],
 "downloading": [
  null,
  "descargando"
 ],
 "Failed to run container $0": [
  null,
  "Fallo al ejecutar el contenedor $0"
 ],
 "Failed to create container $0": [
  null,
  "Falló al crear el contenedor $0"
 ],
 "Failed to pull image $0": [
  null,
  "Fallo al obtener la imagen $0"
 ],
 "Local images": [
  null,
  "Imágenes locales"
 ],
 "Name already in use": [
  null,
  "Nombre ya en uso"
 ],
 "Search by registry": [
  null,
  "Buscar por registro"
 ],
 "Local": [
  null,
  "Local"
 ],
 "Container name": [
  null,
  "Nombre de contenedor"
 ],
 "Owner help": [
  null,
  "Ayuda sobre el propietario"
 ],
 "Ideal for running services": [
  null,
  "Idóneo para ejecutar servicios"
 ],
 "Resource limits can be set": [
  null,
  "Se pueden establecer límites sobre los recursos"
 ],
 "Checkpoint and restore support": [
  null,
  "Soporte para checkpoint y restauración"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Se pueden mapear puertos inferiores a 1024"
 ],
 "User": [
  null,
  "Usuario"
 ],
 "Ideal for development": [
  null,
  "Idóneo para entornos de desarrollo"
 ],
 "Restricted by user account permissions": [
  null,
  "Restringido por los permisos de la cuenta de usuario"
 ],
 "Image selection help": [
  null,
  "Ayuda sobre la selección de imagen"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:puerto]/[usuario]/contenedor[:etiqueta]"
 ],
 "Example: $0": [
  null,
  "Por ejemplo: $0"
 ],
 "Searching: $0": [
  null,
  "Buscando: $0"
 ],
 "Search string or container location": [
  null,
  "Buscar cadena o ubicación de contenedor"
 ],
 "Pull latest image": [
  null,
  "Obtener la última imagen"
 ],
 "Entrypoint": [
  null,
  "Punto de entrada"
 ],
 "With terminal": [
  null,
  "Con terminal"
 ],
 "Memory limit": [
  null,
  "Límite de memoria"
 ],
 "Decrease memory": [
  null,
  "Reducir la cantidad de memoria"
 ],
 "Increase memory": [
  null,
  "Incrementar la cantidad de memoria"
 ],
 "Memory unit": [
  null,
  "Unidad de medida de memoria"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Shares de CPU"
 ],
 "CPU Shares help": [
  null,
  "Ayuda sobre shares de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Los shares de CPU determinan la prioridad de ejecución de contenedores. La prioridad por defecto es 1024. Un número mayor prioriza este contenedor. Un número menor reduce la prioridad."
 ],
 "Decrease CPU shares": [
  null,
  "Reducir shares de CPU"
 ],
 "Increase CPU shares": [
  null,
  "Incrementar shares de CPU"
 ],
 "Restart policy": [
  null,
  "Normativa de reinicio"
 ],
 "Restart policy help": [
  null,
  "Ayuda sobre la política de reinicio"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Política de reinicio a seguir cuando los contenedores finalicen. Utilizar linger para iniciar contenedores automáticamente puede no funcionar bajo ciertas circunstancias, como cuando se emplean ecryptfs, systemd-homed, NFS o 2FA en una cuenta de usuario."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Política de reinicio a seguir cuando se cierren contenedores."
 ],
 "No": [
  null,
  "No"
 ],
 "On failure": [
  null,
  "En caso de fallo"
 ],
 "Always": [
  null,
  "Siempre"
 ],
 "Maximum retries": [
  null,
  "Número máximo de reintentos"
 ],
 "Decrease maximum retries": [
  null,
  "Reducir el número máximo de reintentos"
 ],
 "Increase maximum retries": [
  null,
  "Incrementar el número máximo de reintentos"
 ],
 "No environment variables specified": [
  null,
  "No se han especificado variables de entorno"
 ],
 "Add variable": [
  null,
  "Añadir variable"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Pegue una o más líneas de pares clave=valor en cualquier campo para importar en masa"
 ],
 "Interval": [
  null,
  "Intervalo"
 ],
 "Health check interval help": [
  null,
  "Ayuda sobre el intervalo de comprobación del estado de salud"
 ],
 "Interval how often health check is run.": [
  null,
  "Cada cuánto se ejecuta la comprobación del estado de salud."
 ],
 "Decrease interval": [
  null,
  "Reducir intervalo"
 ],
 "Increase interval": [
  null,
  "Incrementar el intervalo"
 ],
 "seconds": [
  null,
  "segundos"
 ],
 "Timeout": [
  null,
  "Tiempo de espera"
 ],
 "Health check timeout help": [
  null,
  "Ayuda sobre el tiempo de espera de comprobación del estado de salud"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "El máximo tiempo permitido para completar una comprobación de estado de salud antes de que se considere fallada."
 ],
 "Decrease timeout": [
  null,
  "Reducir el tiempo de espera"
 ],
 "Increase timeout": [
  null,
  "Incrementar el tiempo de espera"
 ],
 "Start period": [
  null,
  "Periodo de arranque"
 ],
 "Health check start period help": [
  null,
  "Ayuda sobre el periodo de arranque de comprobación del estado de salud"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "El tiempo de inicialización necesario para que un contenedor arranque."
 ],
 "Decrease start period": [
  null,
  "Reducir el periodo de arranque"
 ],
 "Increase start period": [
  null,
  "Incrementar el periodo de arranque"
 ],
 "Retries": [
  null,
  "Número de reintentos"
 ],
 "Health check retries help": [
  null,
  "Ayuda sobre el número de reintentos de comprobación del estado de salud"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "El máximo número de reintentos permitidos antes de que se considere un mal estado de salud."
 ],
 "Decrease retries": [
  null,
  "Reducir el número de reintentos"
 ],
 "Increase retries": [
  null,
  "Incrementar el número de reintentos"
 ],
 "When unhealthy": [
  null,
  "En caso de mal estado de salud"
 ],
 "Health failure check action help": [
  null,
  "Ayuda sobre la acción al fallo al comprobar el estado de salud"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Acción a tomar una vez que el contenedor pase a un mal estado de salud."
 ],
 "Create container in $0": [
  null,
  "Crear contenedor en $0"
 ],
 "Create and run": [
  null,
  "Crear y ejecutar"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Version": [
  null,
  "Versión"
 ],
 "Links": [
  null,
  "Enlaces"
 ],
 "Documentation": [
  null,
  "Documentación"
 ],
 "Tags": [
  null,
  "Etiquetas"
 ],
 "Created by": [
  null,
  "Creada por"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Comments": [
  null,
  "Comentarios"
 ],
 "Unable to load image history": [
  null,
  "No se pudo cargar el historial de imágenes"
 ],
 "Key must not be empty": [
  null,
  "La clave no debe estar vacía"
 ],
 "Key must not begin with a digit": [
  null,
  "La clave no debe empezar con un digito"
 ],
 "Key contains invalid characters": [
  null,
  "La lave contiene caracteres no válidos"
 ],
 "Key": [
  null,
  "Clave"
 ],
 "Value": [
  null,
  "Valor"
 ],
 "user": [
  null,
  "usuario"
 ],
 "Podman service failed": [
  null,
  "El servicio Podman falló"
 ],
 "Troubleshoot": [
  null,
  "Solución de errores"
 ],
 "Failed to force remove image $0": [
  null,
  "Fallo al forzar el borrado de la imagen $0"
 ],
 "intermediate image": [
  null,
  "imagen intermedia"
 ],
 "Failed to remove image $0": [
  null,
  "Fallo al eliminar la imagen $0"
 ],
 "intermediate": [
  null,
  "intermedia"
 ],
 "Delete $0 image?": [
  null,
  "¿Eliminar imagen de $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Existen múltiples etiquetas para esta imagen. Seleccione las imágenes etiquetadas a eliminar."
 ],
 "Delete image": [
  null,
  "Borrar imagen"
 ],
 "Delete tagged images": [
  null,
  "Eliminar imágenes etiquetadas"
 ],
 "Container is not running": [
  null,
  "El contenedor no se está ejecutando"
 ],
 "Error occurred while connecting console": [
  null,
  "Hubo un error al conectar la consola"
 ],
 "Force delete pod $0?": [
  null,
  "¿Forzar la eliminación del pod $0?"
 ],
 "Delete pod $0?": [
  null,
  "¿Eliminar pod $0?"
 ],
 "An error occurred": [
  null,
  "Ocurrió un error"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "El pod $0, vacío, será eliminado permanentemente."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Eliminando este pod eliminará los siguientes contenedores:"
 ],
 "Failed to start pod $0": [
  null,
  "Fallo al iniciar el pod $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Fallo al parar el pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Fallo al reiniciar el pod $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Fallo al reanudar el pod $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Fallo al pausar el pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Fallo al eliminar los contenedores no utilizados"
 ],
 "Removes selected non-running containers": [
  null,
  "Elimina los contenedores seleccionados que no se están ejecutando"
 ],
 "Pruning containers": [
  null,
  "Eliminando contenedores"
 ],
 "Container name is required.": [
  null,
  "Se requiere un nombre para el contenedor."
 ],
 "Failed to rename container $0": [
  null,
  "Fallo al renombrar el contenedor $0"
 ],
 "New container name": [
  null,
  "Nuevo nombre del contenedor"
 ],
 "Rename container $0": [
  null,
  "Renombrar el contenedor $0"
 ],
 "Paused": [
  null,
  "Pausado"
 ],
 "Stopped": [
  null,
  "Detenido"
 ],
 "Removing": [
  null,
  "Eliminándose"
 ],
 "Configured": [
  null,
  "Configurado"
 ],
 "Error": [
  null,
  "Error"
 ],
 "$0 second": [
  null,
  "$0 segundo",
  "$0 segundos"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Failing streak": [
  null,
  "Racha de fallos"
 ],
 "Failed to run health check on container $0": [
  null,
  "Fallo al comprobar el estado de salud del contenedor $0"
 ],
 "Run health check": [
  null,
  "Ejecutar comprobación de estado de salud"
 ],
 "Last 5 runs": [
  null,
  "Últimas 5 comprobaciones"
 ],
 "Started at": [
  null,
  "Comenzó"
 ],
 "Passed health run": [
  null,
  "Comprobación de estado de salud superada"
 ],
 "Failed health run": [
  null,
  "Comprobación de estado de salud fallada"
 ],
 "Failed to remove container $0": [
  null,
  "Falló al eliminar el contenedor $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Eliminando un contenedor se borrará toda la información que hay en él."
 ]
});
