cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "服务"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "network": [
  null,
  "网络"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "接口"
 ],
 "bridge": [
  null,
  "网桥"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "绑定"
 ],
 "team": [
  null,
  "组合"
 ],
 "port": [
  null,
  "端口"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "防火墙"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "区"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "管理网络绑定"
 ],
 "Managing networking teams": [
  null,
  "管理网络组合"
 ],
 "Managing networking bridges": [
  null,
  "管理网络桥接"
 ],
 "Managing VLANs": [
  null,
  "管理 VLAN"
 ],
 "Managing firewall": [
  null,
  "管理防火墙"
 ]
});
