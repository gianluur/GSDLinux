cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Unlock": [
  null,
  "Kilidi aç"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Select": [
  null,
  "Seç"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "Set": [
  null,
  "Ayarla"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "Permission denied": [
  null,
  "İzin reddedildi"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Yönetimsel erişim elde etmek için hiçbir yöntem mevcut değil (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit $0 hata kodunu bildirdi"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Error during initialization": [
  null,
  "Başlatma sırasında hata"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Home": [
  null,
  "Giriş"
 ],
 "Downloads": [
  null,
  "İndirmeler"
 ],
 "Not a directory": [
  null,
  "Dizin değil"
 ],
 "All files": [
  null,
  "Tüm dosyalar"
 ],
 "Recent": [
  null,
  "En son"
 ],
 "No recent directories": [
  null,
  "Son dizinler yok"
 ],
 "No recent files": [
  null,
  "Son dosyalar yok"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "File chooser actions": [
  null,
  "Dosya seçici eylemleri"
 ],
 "Open in file browser": [
  null,
  "Dosya tarayıcısında aç"
 ],
 "Hide hidden files": [
  null,
  "Gizli dosyaları gizle"
 ],
 "Show hidden files": [
  null,
  "Gizli dosyaları göster"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Clear filters": [
  null,
  "Süzgeçleri temizle"
 ],
 "Directory is empty": [
  null,
  "Dizin boş"
 ],
 "Directory has no sub-directories": [
  null,
  "Dizin, alt dizinlere sahip değil"
 ],
 "This directory contains only hidden files": [
  null,
  "Bu dizin yalnızca gizli dosyaları içerir"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "Folder": [
  null,
  "Klasör"
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "View logs": [
  null,
  "Günlükleri görüntüle"
 ],
 "Dismiss": [
  null,
  "Yoksay"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "none": [
  null,
  "yok"
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Username": [
  null,
  "Kullanıcı adı"
 ],
 "Actions": [
  null,
  "Eylemler"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Started": [
  null,
  "Başlatıldı"
 ],
 "Delete group": [
  null,
  "Grubu sil"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Lock": [
  null,
  "Kilitle"
 ],
 "Use $0": [
  null,
  "$0 kullan"
 ],
 "Service": [
  null,
  "Hizmet"
 ],
 "Disconnect": [
  null,
  "Bağlantıyı kes"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk eksik",
  "$0 disk eksik"
 ],
 "Location": [
  null,
  "Konum"
 ],
 "Compression": [
  null,
  "Sıkıştırma"
 ],
 "Storage logs": [
  null,
  "Depolama günlükleri"
 ],
 "Name cannot be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Ad 127 karakterden uzun olamaz."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Ad '$0' karakterini içeremez."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Ad boşluk karakterleri içeremez."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Ad $0 karakterden uzun olamaz"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Ad $0 bayt'tan uzun olamaz"
 ],
 "$name (from $host)": [
  null,
  "$name ($host cihazından)"
 ],
 "Pool for thin logical volumes": [
  null,
  "İnce mantıksal birimler için havuz"
 ],
 "Thin logical volume": [
  null,
  "İnce mantıksal birim"
 ],
 "Logical volume (snapshot)": [
  null,
  "Mantıksal birim (anlık görüntü)"
 ],
 "Logical volume": [
  null,
  "Mantıksal birim"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID aygıtı $0"
 ],
 "LVM2 volume group $0": [
  null,
  "$0 LVM2 birim grubu"
 ],
 "VDO device $0": [
  null,
  "VDO aygıtı $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 aygıtının şifrelenmiş mantıksal birimi"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 aygıtının şifrelenmiş bölümü"
 ],
 "Logical volume of $0": [
  null,
  "$0 bölümünün mantıksal birimi"
 ],
 "Partition of $0": [
  null,
  "$0'ın bölümü"
 ],
 "Encrypted $0": [
  null,
  "Şifrelenmiş $0"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 üzerinde bölümlendirilmemiş alan"
 ],
 "unmount": [
  null,
  "bağlantıyı kaldır"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "remove from btrfs volume": [
  null,
  "btrfs biriminden kaldır"
 ],
 "stop": [
  null,
  "durdur"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID'den kaldır"
 ],
 "remove from LVM2": [
  null,
  "LVM2'den kaldır"
 ],
 "btrfs device": [
  null,
  "btrfs aygıtı"
 ],
 "btrfs volume": [
  null,
  "btrfs birimi"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Ad 255 karakterden uzun olamaz."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Ad '/' karakterini içeremez."
 ],
 "Create and mount": [
  null,
  "Oluştur ve bağla"
 ],
 "Create only": [
  null,
  "Sadece oluştur"
 ],
 "Create subvolume": [
  null,
  "Alt birim oluştur"
 ],
 "Mount Point": [
  null,
  "Bağlama Noktası"
 ],
 "delete": [
  null,
  "sil"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "$0 alt birimi kalıcı olarak silinsin mi?"
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Silme, bu alt birimdeki tüm verileri ve alt birimlerinin tümünü siler."
 ],
 "Edit mount point": [
  null,
  "Bağlama noktasını düzenle"
 ],
 "Unmount": [
  null,
  "Bağlantıyı kaldır"
 ],
 "Mount": [
  null,
  "Bağla"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "En az bir alt birimin bağlanması gerekir"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Son bağlanan alt birim silinemez"
 ],
 "btrfs subvolume": [
  null,
  "btrfs alt birimi"
 ],
 "Snapshot origin": [
  null,
  "Anlık görüntü kaynağı"
 ],
 "Mount point": [
  null,
  "Bağlama noktası"
 ],
 "No subvolumes": [
  null,
  "Alt birimler yok"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs alt birimi"
 ],
 "Snapshots": [
  null,
  "Anlık görüntüler"
 ],
 "No snapshots found": [
  null,
  "Bulunan anlık görüntüler yok"
 ],
 "snapshot": [
  null,
  "anlık görüntü"
 ],
 "$0 is in use": [
  null,
  "$0 kullanımda"
 ],
 "Permanently delete $0?": [
  null,
  "$0 aygıtı kalıcı olarak silinsin mi?"
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Silme, bir btrfs birimi üzerindeki tüm verileri siler."
 ],
 "Delete filesystem": [
  null,
  "Dosya sistemini sil"
 ],
 "Change label": [
  null,
  "Etiketi değiştir"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Dosya sistemi salt okunur olarak bağlanmış"
 ],
 "Label": [
  null,
  "Etiket"
 ],
 "Capacity": [
  null,
  "Kapasite"
 ],
 "btrfs devices": [
  null,
  "btrfs aygıtı"
 ],
 "No devices found": [
  null,
  "Bulunan aygıtlar yok"
 ],
 "btrfs filesystem": [
  null,
  "btrfs dosya sistemi"
 ],
 "Successful": [
  null,
  "Başarılı"
 ],
 "Aborted": [
  null,
  "İptal edildi"
 ],
 "In progress": [
  null,
  "Sürüyor"
 ],
 "Interrupted": [
  null,
  "Kesilmiş"
 ],
 "Did not complete": [
  null,
  "Tamamlanmadı"
 ],
 "Failed (Unknown)": [
  null,
  "Başarısız oldu (Bilinmiyor)"
 ],
 "Failed (Electrical)": [
  null,
  "Başarısız oldu (Elektriksel)"
 ],
 "Failed (Servo)": [
  null,
  "Başarısız oldu (Servo)"
 ],
 "Failed (Read)": [
  null,
  "Başarısız oldu (Okuma)"
 ],
 "Failed (Damaged)": [
  null,
  "Başarısız oldu (Hasarlı)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Bir Denetleyici Seviyesi Sıfırlama ile iptal edildi"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Ad alanı envanterinden bir ad alanının kaldırılmasından dolayı iptal edildi"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Bir NVM Biçimlendirme komutunun işlenmesinden dolayı iptal edildi"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Kendi kendine deneme işlemi sırasında önemli bir hata meydana geldi"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Başarısız olan bir bölüm ile tamamlandı ve başarısız olan bölüm bilinmiyor"
 ],
 "Completed with one or more failed segments": [
  null,
  "Bir veya daha fazla başarısız olan bölümle tamamlandı"
 ],
 "Aborted for unknown reason": [
  null,
  "Bilinmeyen bir nedenden dolayı iptal edildi"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Bir sterilize işleminden dolayı iptal edildi"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Yedek kapasite eşiğin altında"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Önerilen eşiklerin dışındaki sıcaklık"
 ],
 "Degraded": [
  null,
  "Bozulmuş"
 ],
 "All media is in read-only mode": [
  null,
  "Tüm ortam salt okunur modda"
 ],
 "Volatile memory backup failed": [
  null,
  "Değişken belleği yedekleme başarısız oldu"
 ],
 "Persistent memory has become read-only": [
  null,
  "Kalıcı bellek salt okunur hale geldi"
 ],
 "Run short test": [
  null,
  "Kısa deneme çalıştır"
 ],
 "Run extended test": [
  null,
  "Genişletilmiş deneme çalıştır"
 ],
 "Abort test": [
  null,
  "Denemeyi iptal et"
 ],
 "Disk is failing": [
  null,
  "Disk bozuluyor"
 ],
 "Disk is OK": [
  null,
  "Disk TAMAM"
 ],
 "Assessment": [
  null,
  "Değerlendirme"
 ],
 "Power on hours": [
  null,
  "Saatlerde güç"
 ],
 "$0 hours": [
  null,
  "$0 saat"
 ],
 "Self-test status": [
  null,
  "Kendi kendine deneme durumu"
 ],
 "Number of bad sectors": [
  null,
  "Kötü sektör sayısı"
 ],
 "Attributes failing": [
  null,
  "Öznitelikler hatası"
 ],
 "Media drive": [
  null,
  "Ortam sürücüsü"
 ],
 "Solid State Drive": [
  null,
  "Katı Hal Sürücüsü"
 ],
 "Hard Disk Drive": [
  null,
  "Sabit Disk Sürücüsü"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI Sürücüsü"
 ],
 "Drive": [
  null,
  "Sürücü"
 ],
 "Device health (SMART)": [
  null,
  "Aygıt sağlığı (SMART)"
 ],
 "Firmware version": [
  null,
  "Donanım yazılımı sürümü"
 ],
 "Serial number": [
  null,
  "Seri numarası"
 ],
 "World wide name": [
  null,
  "Dünya çapında ad"
 ],
 "No media inserted": [
  null,
  "Takılı ortam yok"
 ],
 "Device file": [
  null,
  "Aygıt dosyası"
 ],
 "Multipathed devices": [
  null,
  "Çok yollu aygıtlar"
 ],
 "Free space": [
  null,
  "Boş alan"
 ],
 "Create partition": [
  null,
  "Bölüm oluştur"
 ],
 "Extended partition": [
  null,
  "Genişletilmiş bölüm"
 ],
 "$0 partitions": [
  null,
  "$0 bölümleri"
 ],
 "Partitions": [
  null,
  "Bölümler"
 ],
 "No partitions found": [
  null,
  "Bulunan bölümler yok"
 ],
 "Unexpected partitions": [
  null,
  "Beklenmedik bölümler"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Bu blok cihazda bölümler desteklenmiyor. Eğer sanal bir makine için bir disk olarak kullanılıyorsa, bölümler sanal makinenin içindeki işletim sistemi tarafından yönetilmek zorundadır."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Bir bölümü silmek, içindeki tüm verileri silecektir."
 ],
 "No free space after this partition": [
  null,
  "Bu bölümden sonra boş alan yok"
 ],
 "EFI system partition": [
  null,
  "EFI sistem bölümü"
 ],
 "BIOS boot partition": [
  null,
  "BIOS önyükleme bölümü"
 ],
 "Partition": [
  null,
  "Bölüm"
 ],
 "Shrink": [
  null,
  "Küçült"
 ],
 "Grow": [
  null,
  "Büyüt"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP önyükleme bölümü"
 ],
 "Linux swap space": [
  null,
  "Linux takas alanı"
 ],
 "Linux filesystem data": [
  null,
  "Linux dosya sistemi verileri"
 ],
 "Logical Volume Manager partition": [
  null,
  "Mantıksal Birim Yöneticisi bölümü"
 ],
 "Custom": [
  null,
  "Özel"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tür tam olarak iki onaltılık karakter içermek zorundadır (0 - 9, A - F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tür yalnızca 0 - 9, A - F ve \"-\" karakterlerini içerebilir."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tür NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN biçiminde olmak zorundadır."
 ],
 "Set partition type of $0": [
  null,
  "Bölüm türünü $0 olarak ayarla"
 ],
 "Custom type": [
  null,
  "Özel tür"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Bölüm türlerinin değiştirilmesi sistemin önyüklemesini engelleyebilir."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Bu bölüm, içeriği tarafından tamamen kullanılmıyor."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Bölüm boyutu $0. İçerik boyutu $1."
 ],
 "Shrink partition": [
  null,
  "Bölümü küçült"
 ],
 "Grow content": [
  null,
  "İçeriği büyüt"
 ],
 "initialize": [
  null,
  "başlat"
 ],
 "Initialize disk $0": [
  null,
  "$0 diskini başlat"
 ],
 "Partitioning": [
  null,
  "Bölümlendirme"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Tüm sistem ve aygıtlarla uyumlu (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Modern sistem ve 2TB'tan büyük sabit disklerle uyumlu (GPT)"
 ],
 "No partitioning": [
  null,
  "Bölümlendirme yok"
 ],
 "Overwrite": [
  null,
  "Üzerine yaz"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Varolan verilerin üzerine sıfırlarla yaz (daha yavaş)"
 ],
 "Initialize": [
  null,
  "Başlat"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Başlatma, disk üzerindeki tüm verileri siler."
 ],
 "Device is read-only": [
  null,
  "Aygıt salt-okunur"
 ],
 "Create partition table": [
  null,
  "Bölüm tablosu oluştur"
 ],
 "Size must be a number": [
  null,
  "Boyut bir sayı olmak zorundadır"
 ],
 "Size cannot be zero": [
  null,
  "Boyut sıfır olamaz"
 ],
 "Size cannot be negative": [
  null,
  "Boyut sıfırdan küçük olamaz"
 ],
 "Size is too large": [
  null,
  "Boyut çok büyük"
 ],
 "Size must be at least $0": [
  null,
  "Boyut en az $0 olmak zorundadır"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 birim grubunun fiziksel birimi"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID aygıtı üyesi"
 ],
 "backing device for VDO device": [
  null,
  "VDO aygıtı için aygıt yedekleniyor"
 ],
 "member of Stratis pool": [
  null,
  "Stratis havuzu üyesi"
 ],
 "Filesystem outside the target": [
  null,
  "Hedefin dışındaki dosya sistemi"
 ],
 "device of btrfs volume": [
  null,
  "btrfs birimi aygıtı"
 ],
 "This device is currently in use.": [
  null,
  "Bu aygıt şu anda kullanımda."
 ],
 "Device": [
  null,
  "Aygıt"
 ],
 "Use": [
  null,
  "Kullan"
 ],
 "Services using the location": [
  null,
  "Konumu kullanan hizmetler"
 ],
 "Processes using the location": [
  null,
  "Konumu kullanan işlemler"
 ],
 "Currently in use": [
  null,
  "Şu an kullanımda"
 ],
 "(Not part of target)": [
  null,
  "(Hedefin bir parçası değil)"
 ],
 "These changes will be made:": [
  null,
  "Şu değişiklikler yapılacaktır:"
 ],
 "Action": [
  null,
  "Eylem"
 ],
 "Important data might be deleted:": [
  null,
  "Önemli veriler silinebilir:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "İlgili işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "İlgili işlemler zorla durdurulacaktır."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "İlgili hizmetler zorla durdurulacaktır."
 ],
 "Checking filesystem usage": [
  null,
  "Dosya sistemi kullanımı denetleniyor"
 ],
 "$0 used, $1 total": [
  null,
  "$0 kullanılan, $1 toplam"
 ],
 "Device contains unrecognized data": [
  null,
  "Cihaz tanınmayan veriler içeriyor"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Kilitli şifreli cihaz veri içerebilir"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Bu verileri sonsuza kadar kaybetmek istediğimi onaylıyorum"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "$0 bağlama noktası şu işlemler tarafından kullanılmakta:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "$0 bağlama noktası şu hizmetler tarafından kullanılmakta:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Listelenen işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Listelenen işlemler zorla durdurulacaktır."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Listelenen hizmetler zorla durdurulacaktır."
 ],
 "Sorry": [
  null,
  "Üzgünüz"
 ],
 "Usage of $0": [
  null,
  "$0 kullanımı"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO havuzu"
 ],
 "Data used": [
  null,
  "Kullanılan veri"
 ],
 "Metadata used": [
  null,
  "Kullanılan üst veri"
 ],
 "Use compression": [
  null,
  "Sıkıştırma kullan"
 ],
 "Deduplication": [
  null,
  "Tekilleştirme"
 ],
 "Use deduplication": [
  null,
  "Tekilleştirme kullan"
 ],
 "Rename volume group": [
  null,
  "Birim grubunu yeniden adlandır"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Bu birim grubu kök dosya sistemini içerir. Yeniden adlandırma bootloader yapılandırmasında veya çekirdek komut satırında daha fazla değişiklik gerektirebilir."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Silme, bir birim grubu üzerindeki tüm verileri siler."
 ],
 "Create snapshot": [
  null,
  "Anlık görüntü oluştur"
 ],
 "Add disks": [
  null,
  "Diskleri ekle"
 ],
 "Disks": [
  null,
  "Diskler"
 ],
 "No disks are available.": [
  null,
  "Kullanılabilir diskler yok."
 ],
 "At least one disk is needed.": [
  null,
  "En az bir disk gerekli."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Birim grubunda fiziksel birimler eksik"
 ],
 "No free space": [
  null,
  "Boş alan yok"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 birim grubu"
 ],
 "Add physical volume": [
  null,
  "Fiziksel birim ekle"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 mantıksal birimleri"
 ],
 "Create new logical volume": [
  null,
  "Yeni mantıksal birim oluştur"
 ],
 "No logical volumes": [
  null,
  "Mantıksal birimler yok"
 ],
 "Remove missing physical volumes?": [
  null,
  "Eksik fiziksel birimler kaldırılsın mı?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Bu birim grubunda bazı fiziksel birimler eksik."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Eksik fiziksel birimlere sahip bir birim grubu yeniden adlandırılamaz."
 ],
 "Physical volumes": [
  null,
  "Fiziksel birimler"
 ],
 "No physical volumes found": [
  null,
  "Bulunan fiziksel birimler yok"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fiziksel birimleri"
 ],
 "Rename logical volume": [
  null,
  "Mantıksal birimi yeniden adlandır"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Mantıksal birim $0/$1 kalıcı olarak silinsin mi?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Mantıksal bir birimi silmek, içindeki tüm verileri silecektir."
 ],
 "Unable to repair logical volume $0": [
  null,
  "$0 mantıksal birimi onarılamıyor"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Onarım için kullanılabilecek yeterli alan yok. Bu mantıksal birim için zaten kullanılmayan fiziksel birimlerde en az $0 gereklidir."
 ],
 "An additional $0 must be selected": [
  null,
  "Bir ek $0 seçilmek zorundadır"
 ],
 "Repair logical volume $0": [
  null,
  "$0 mantıksal birimini onar"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Mantıksal birimi onarmak için kullanılması gereken fiziksel birimleri seçin. En az $0 ihtiyaç vardır."
 ],
 "Physical Volumes": [
  null,
  "Fiziksel Birimler"
 ],
 "Repair": [
  null,
  "Onar"
 ],
 "deactivate": [
  null,
  "devre dışı bırak"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Mantıksal birim $0/$1 devre dışı bırakılsın mı?"
 ],
 "Deactivate": [
  null,
  "Devre dışı bırak"
 ],
 "Not enough space to grow": [
  null,
  "Büyütmek için yeterli alan yok"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 mantıksal birimi"
 ],
 "Striped (RAID 0)": [
  null,
  "Şeritlenmiş (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Yansıtılmış (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Şeritlenmiş ve yansıtılmış (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Adanmış eşlik (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Adanmış eşlik (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Çift dağıtılmış eşlik (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Bu mantıksal birim, içeriği tarafından tamamen kullanılmıyor."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Birim boyutu $0. İçerik boyutu $1."
 ],
 "Shrink volume": [
  null,
  "Birimi küçült"
 ],
 "Layout": [
  null,
  "Düzen"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ve artık kullanılamaz. Bunu silip yerine yenisini oluşturmanız gerekiyor."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ancak henüz herhangi bir veri kaybetmemiş. Orijinal yedekliliğini geri yüklemek için onarmalısınız."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ancak henüz herhangi bir veri kaybetmemiş olabilir. Belki onarabilirsiniz."
 ],
 "Stripes": [
  null,
  "Şeritlemeler"
 ],
 "$0 synchronized": [
  null,
  "$0 eşitlendi"
 ],
 "Create volume group": [
  null,
  "Birim grubu oluştur"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fiziksel birimi"
 ],
 "Last cannot be removed": [
  null,
  "Sonuncusu kaldırılamaz"
 ],
 "Not enough free space": [
  null,
  "Yeterli boş alan yok"
 ],
 "Volume group": [
  null,
  "Birim grubu"
 ],
 "Create thin volume": [
  null,
  "İnce birim oluştur"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Ölçülü kaynak sağlanan LVM2 mantıksal birimleri"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Yeni ölçülü kaynak sağlanan mantıksal birim oluştur"
 ],
 "Not enough space": [
  null,
  "Yeterli alan yok"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Ölçülü kaynak sağlanan LVM2 mantıksal birimleri için havuz"
 ],
 "Inactive logical volume": [
  null,
  "Etkin olmayan mantıksal birim"
 ],
 "Activate": [
  null,
  "Etkinleştir"
 ],
 "Unsupported logical volume": [
  null,
  "Desteklenmeyen mantıksal birim"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "DAHİLİ HATA - Bu mantıksal birim etkin olarak işaretlendi ve ilişkilendirilmiş bir blok aygıta sahip olmalıdır. Ancak böyle bir blok aygıt bulunamadı."
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 paketini kurmak $1 paketini kaldırır."
 ],
 "Installing packages": [
  null,
  "Paketler kuruluyor"
 ],
 "Block device for filesystems": [
  null,
  "Dosya sistemleri için blok aygıtı"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Ölçülü kaynak sağlanan birimler için havuz"
 ],
 "Linear": [
  null,
  "Doğrusal"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO dosya sistemi birimi (sıkıştırma/kopyaları kaldırma)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Veriler, herhangi bir ek yedeklilik veya performans iyileştirmesi olmaksızın seçilen fiziksel birimlerde depolanacaktır."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Veriler, performansı artırmak için seçilen fiziksel birimlerde dönüşümlü olarak depolanacaktır. En az iki birim seçilmesi gerekir."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Veriler, güvenilirliği artırmak için seçilen fiziksel birimlerde iki veya daha fazla kopya halinde depolanacaktır. En az iki birimin seçilmesi gerekir."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Veriler, hem güvenilirliği hem de performansı artırmak için seçilen fiziksel birimlerde iki kopya halinde ve ayrıca dönüşümlü olarak depolanacaktır. En az dört birimin seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak ve böylece veriler etkilenmeden bunlardan biri kaybedilebilecektir. En az üç birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak ve böylece veriler etkilenmeden bunlardan biri kaybedilebilecektir. Performansı artırmak için veriler ayrıca dönüşümlü olarak depolanır. En az üç birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak, böylece veriler etkilenmeden aynı anda en fazla iki tanesi kaybedilebilecektir. Performansı artırmak için veriler ayrıca dönüşümlü olarak depolanır. En az beş birim seçilmesi gerekir."
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Seçilen düzen için seçilen tüm $0 fiziksel birim gereklidir."
 ],
 "Create logical volume": [
  null,
  "Mantıksal birim oluştur"
 ],
 "Purpose": [
  null,
  "Amaç"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO aygıtları oluşturmak için $0 paketi kurulacak."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 çift sayıda fiziksel birime ihtiyaç duyar"
 ],
 "Logical size": [
  null,
  "Mantıksal boyut"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 ile ayrı blokları sıkıştırarak alandan tasarruf edin"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Aynı veri bloklarını sadece bir kez depolayarak alandan tasarruf edin"
 ],
 "Creating VDO device": [
  null,
  "VDO aygıtı oluşturuluyor"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Bu NFS bağlama noktası kullanımda ve sadece seçenekleri değiştirilebilir."
 ],
 "NFS mount": [
  null,
  "NFS bağlama noktası"
 ],
 "New NFS mount": [
  null,
  "Yeni NFS bağlama noktası"
 ],
 "Server address": [
  null,
  "Sunucu adresi"
 ],
 "Server cannot be empty.": [
  null,
  "Sunucu boş olamaz."
 ],
 "Path on server": [
  null,
  "Sunucu üzerindeki yol"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sunucu üzerindeki yol boş olamaz."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sunucu üzerindeki yol \"/\" ile başlamak zorundadır."
 ],
 "Local mount point": [
  null,
  "Yerel bağlama noktası"
 ],
 "Mount point cannot be empty.": [
  null,
  "Bağlama noktası boş olamaz."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Bağlama noktası \"/\" ile başlamak zorundadır."
 ],
 "Mount options": [
  null,
  "Bağlama seçenekleri"
 ],
 "Mount at boot": [
  null,
  "Önyüklemede bağla"
 ],
 "Mount read only": [
  null,
  "Salt okunur bağla"
 ],
 "Custom mount options": [
  null,
  "Özel bağlama seçenekleri"
 ],
 "Unable to unmount filesystem": [
  null,
  "Dosya sisteminin bağlantısı kaldırılamıyor"
 ],
 "Stop and unmount": [
  null,
  "Durdur ve bağlantısını kaldır"
 ],
 "Unable to remove mount": [
  null,
  "Bağlama noktası kaldırılamıyor"
 ],
 "Stop and remove": [
  null,
  "Durdur ve kaldır"
 ],
 "(not mounted)": [
  null,
  "(bağlanmadı)"
 ],
 "Start multipath": [
  null,
  "Multipath hizmetini başlat"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Sistemde birden çok yola sahip aygıtlar var, ancak multipath hizmeti çalışmıyor."
 ],
 "Show all $0 rows": [
  null,
  "Tüm $0 satırı göster"
 ],
 "Category": [
  null,
  "Kategori"
 ],
 "more info": [
  null,
  "daha fazla bilgi"
 ],
 "Encryption": [
  null,
  "Şifreleme"
 ],
 "encrypted": [
  null,
  "şifrelenmiş"
 ],
 "Last modified: $0": [
  null,
  "Son değiştirilme: $0"
 ],
 "Stored passphrase": [
  null,
  "Saklanmış parola"
 ],
 "Encryption options": [
  null,
  "Şifreleme seçenekleri"
 ],
 "Encryption type": [
  null,
  "Şifreleme türü"
 ],
 "Cleartext device": [
  null,
  "Metin temizleme aygıtı"
 ],
 "yes": [
  null,
  "evet"
 ],
 "Disk passphrase": [
  null,
  "Disk parolası"
 ],
 "Passphrase cannot be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Unlocking disk": [
  null,
  "Disk kilidi açılıyor"
 ],
 "Checking for $0 package": [
  null,
  "$0 paketi denetleniyor"
 ],
 "The $0 package must be installed.": [
  null,
  "$0 paketi kurulmak zorundadır."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 paketi hiçbir depoda yok."
 ],
 "Error installing $0: PackageKit or dnf5daemon-server is not installed": [
  null,
  "$0 kurulurken hata oldu: PackageKit veya dnf5daemon-server kurulu değil"
 ],
 "Unexpected PackageManager error during installation of $0: $1": [
  null,
  "$0 kurulumu sırasında beklenmeyen PackageManager hatası: $1"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "initrd'de NBDE desteği denetleniyor"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd yeniden oluşturulmak zorundadır."
 ],
 "Regenerating initrd": [
  null,
  "initrd yeniden oluşturuluyor"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Çekirdek komut satırına rd.neednet=1 ekleniyor"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Dosya sistemi seçeneklerine \"$0\" ekleniyor"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Şifreleme seçeneklerine \"$0\" ekleniyor"
 ],
 "Enabling $0": [
  null,
  "$0 etkinleştiriliyor"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Ağa Bağlı Disk Şifrelemesi ekle"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Sistem şu anda bir Tang anahtar sunucusuyla kök dosya sisteminin kilidini açmayı desteklemiyor."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Sistem şu anda önyükleme sırasında bir dosya sisteminin bir Tang anahtar sunucusuyla kilidinin açılmasını desteklemiyor."
 ],
 "These additional steps are necessary:": [
  null,
  "Şu ek adımlar gereklidir:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Yeni bir parola kaydetmek, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Fix NBDE support": [
  null,
  "NBDE desteğini düzelt"
 ],
 "Adding key": [
  null,
  "Anahtar ekleniyor"
 ],
 "Key source": [
  null,
  "Anahtar kaynağı"
 ],
 "Repeat passphrase": [
  null,
  "Parolayı tekrarla"
 ],
 "Passphrase": [
  null,
  "Parola"
 ],
 "Tang keyserver": [
  null,
  "Tang anahtar sunucusu"
 ],
 "New passphrase": [
  null,
  "Yeni parola"
 ],
 "Passphrases do not match": [
  null,
  "Parolalar eşleşmiyor"
 ],
 "Keyserver address": [
  null,
  "Anahtar sunucusu adresi"
 ],
 "Change passphrase": [
  null,
  "Parolayı değiştir"
 ],
 "Old passphrase": [
  null,
  "Eski parola"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang anahtar sunucusunu düzenle"
 ],
 "Verify key": [
  null,
  "Anahtarı doğrula"
 ],
 "Trust key": [
  null,
  "Güvenilen anahtar"
 ],
 "Passphrase can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Parolayı kaldırma, $0 kilidini açmayı engelleyebilir."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Kaldırmayı alternatif bir parola ile onayla"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Başka bir parolayı onaylamadan bir parolayı kaldırmak, diğer parolalar unutulur veya kaybolursa, kilit açma veya anahtar yönetimini önleyebilir."
 ],
 "Passphrase from any other key slot": [
  null,
  "Başka bir anahtar yuvasından gelen parola"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "$0 anahtar yuvası içindeki parola kaldırılsın mı?"
 ],
 "Remove $0?": [
  null,
  "$0 kaldırılsın mı?"
 ],
 "Removal may prevent unlocking $0.": [
  null,
  "Kaldırma işlemi, $0 kilidini açmayı engelleyebilir."
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang anahtar sunucusu kaldırılsın mı?"
 ],
 "Remove key in slot $0?": [
  null,
  "$0 yuvasındaki anahtar kaldırılsın mı?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Şu anda oturum açmış olan kullanıcının anahtarlar hakkındaki bilgileri görmesine izin verilmiyor."
 ],
 "No keys added": [
  null,
  "Eklenen anahtarlar yok"
 ],
 "Slot $0": [
  null,
  "Yuva $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Bir anahtarı düzenlemek, boş bir yuva gerektirir"
 ],
 "The last key slot can not be removed": [
  null,
  "Son anahtar yuvası kaldırılamaz"
 ],
 "Keyserver": [
  null,
  "Anahtar sunucusu"
 ],
 "Unknown type": [
  null,
  "Bilinmeyen tür"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Bilinmeyen türlere sahip anahtar yuvaları burada düzenlenemez"
 ],
 "Keys": [
  null,
  "Anahtarlar"
 ],
 "$0 slot remains": [
  null,
  "$0 yuva kaldı",
  "$0 yuva kaldı"
 ],
 "No available slots": [
  null,
  "Kullanılabilir yuvalar yok"
 ],
 "No free key slots": [
  null,
  "Boş anahtar yuvaları yok"
 ],
 "Locked data": [
  null,
  "Kilitli veriler"
 ],
 "lock": [
  null,
  "kilitle"
 ],
 "Lock $0?": [
  null,
  "$0 kilitlensin mi?"
 ],
 "Address cannot be empty": [
  null,
  "Adres boş olamaz"
 ],
 "Address is not a valid URL": [
  null,
  "Adres geçerli bir URL değil"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Anahtar adreslemesini Tang sunucusuyla denetleyin."
 ],
 "How to check": [
  null,
  "Nasıl denetlenir"
 ],
 "In a terminal, run: ": [
  null,
  "Bir terminalde şunu çalıştırın: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Başarılı olarak panoya kopyalandı!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Komuttan SHA-256 veya SHA-1 adreslemesinin bu ileti öğesiyle eşleştiğini denetleyin."
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "$0 / $1 btrfs alt birimi"
 ],
 "Mount point cannot be empty": [
  null,
  "Bağlama noktası boş olamaz"
 ],
 "Mount point is already used for $0": [
  null,
  "Bağlama noktası zaten $0 için kullanılıyor"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Dosya sistemi zaten bu bağlama noktasının altına bağlanmış."
 ],
 "Please unmount them first.": [
  null,
  "Lütfen önce bunların bağlantısını kaldırın."
 ],
 "read only": [
  null,
  "salt okunur"
 ],
 "never mount at boot": [
  null,
  "önyüklemede asla bağlama"
 ],
 "after network": [
  null,
  "ağdan sonra"
 ],
 "ignore failure": [
  null,
  "hatayı yoksay"
 ],
 "stop boot on failure": [
  null,
  "hatada önyüklemeyi durdur"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Dosya sisteminin atanmış bir bağlama noktası yok."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Dosya sisteminin kalıcı bir bağlama noktası yok."
 ],
 "The filesystem is not mounted.": [
  null,
  "Dosya sistemi bağlanmadı."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Dosya sisteminin kilidi açılacak ve bir sonraki önyüklemeye bağlanacaktır. Bu bir parola girmeyi gerektirebilir."
 ],
 "(no assigned mount point)": [
  null,
  "(atanmış bağlama noktası yok)"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemede $1 noktasında bağlanacak."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Önyüklemede $0 noktasına otomatik olarak bağla"
 ],
 "Mount on $0 now": [
  null,
  "Şimdi $0 noktasına bağla"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış değil ancak bir sonraki önyüklemede bağlanacak."
 ],
 "Do not mount automatically on boot": [
  null,
  "Önyüklemede otomatik olarak bağlama"
 ],
 "Mount now": [
  null,
  "Şimdi bağla"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "Mount also automatically on boot": [
  null,
  "Önyüklemede de otomatik olarak bağla"
 ],
 "Unmount now": [
  null,
  "Şimdi bağlantıyı kaldır"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Dosya sistemi önyüklemede otomatik olarak bağlanacak şekilde yapılandırıldı ancak şifreleme kapsayıcısının kilidi o anda açılmayacaktır."
 ],
 "Unlock automatically on boot": [
  null,
  "Önyüklemede kilidi otomatik olarak aç"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Tutarsız dosya sistemi bağlama"
 ],
 "$0 filesystem": [
  null,
  "$0 dosya sistemi"
 ],
 "Filesystem name": [
  null,
  "Dosya sistemi adı"
 ],
 "Filesystem is locked": [
  null,
  "Dosya sistemi kilitli"
 ],
 "Mounts before services start": [
  null,
  "Hizmetler başlamadan önce bağlar"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "/var gibi önemli bağlamalar için uygun"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Dosya sistemi bağlanmazsa önyükleme başarısız olur ve uzaktan erişim önlenir"
 ],
 "Mounts in parallel with services": [
  null,
  "Hizmetlerle paralel olarak bağlar"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Dosya sistemi bağlanmadığında önyükleme hala başarılı olur"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Hizmetlerle paralel olarak bağlar, ancak ağ kullanılabilir olduktan sonra"
 ],
 "Does not mount during boot": [
  null,
  "Önyükleme sırasında bağlamaz"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "İsteğe bağlı olan veya etkileşim gerektiren bağlamalar için kullanışlıdır (parolalar gibi)"
 ],
 "At boot": [
  null,
  "Önyüklemede"
 ],
 "Mount before services start": [
  null,
  "Hizmetler başlamadan önce bağla"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Beklemeden bağla, hatayı yoksay"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Ağ kullanılabilir hale geldikten sonra bağla, hatayı yoksay"
 ],
 "Do not mount": [
  null,
  "Bağlama"
 ],
 "This device can not be used for the installation target.": [
  null,
  "Bu aygıt kurulum hedefi için kullanılamaz."
 ],
 "Mount filesystem": [
  null,
  "Dosya sistemini bağla"
 ],
 "Unmount filesystem $0": [
  null,
  "$0 dosya sistemi bağlantısını kaldır"
 ],
 "Mount configuration": [
  null,
  "Bağlama yapılandırması"
 ],
 "Swap": [
  null,
  "Takas"
 ],
 "Used": [
  null,
  "Kullanılan"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Şifrelenmiş Stratis havuzu kilidini aç"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Şu blok aygıtlarda havuz için parolayı sağlayın:"
 ],
 "Stratis pool": [
  null,
  "Stratis havuzu"
 ],
 "stopped": [
  null,
  "durduruldu"
 ],
 "Block devices": [
  null,
  "Blok aygıtlar"
 ],
 "No block devices found": [
  null,
  "Bulunan blok aygıtlar yok"
 ],
 "Stratis block devices": [
  null,
  "Stratis blok aygıtları"
 ],
 "Stratis block device": [
  null,
  "Stratis blok aygıtı"
 ],
 "data": [
  null,
  "veri"
 ],
 "cache": [
  null,
  "önbellek"
 ],
 "Please provide an existing pool passphrase.": [
  null,
  "Lütfen varolan bir havuz parolası verin."
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Eğer $0 adresindeki anahtar sunucusu ulaşılabilir değilse, varolan bir parola verebilirsiniz."
 ],
 "If none of the keyservers is reachable, you can provide an existing passphrase.": [
  null,
  "Eğer anahtar sunucularının hiçbirine ulaşılamazsa, varolan bir parola verebilirsiniz."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Eğer etkileşimli olmayan kilitleme yöntemlerinin hiçbiri işe yaramazsa, varolan bir parola verebilirsiniz."
 ],
 "Pool passphrase": [
  null,
  "Havuz parolası"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "$0 adresindeki anahtar sunucusu ulaşılabilir olmak zorundadır."
 ],
 "At least one keyserver must be reachable.": [
  null,
  "En az bir anahtar sunucusu ulaşılabilir olmak zorundadır."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Etkileşimli olmayan kilit açma yöntemlerinden en az biri çalışmak zorundadır."
 ],
 "Create filesystem": [
  null,
  "Dosya sistemi oluştur"
 ],
 "Stratis filesystem": [
  null,
  "Stratis dosya sistemi"
 ],
 "Set initial size": [
  null,
  "Başlangıç boyutunu ayarla"
 ],
 "Limit size": [
  null,
  "Boyutu sınırla"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Bir Stratis havuzunu silmek içerdiği tüm verileri silecek."
 ],
 "Rename Stratis pool": [
  null,
  "Stratis havuzunu yeniden adlandır"
 ],
 "Add block devices": [
  null,
  "Blok aygıtlarını ekle"
 ],
 "Tier": [
  null,
  "Katman"
 ],
 "Data": [
  null,
  "Veri"
 ],
 "Cache": [
  null,
  "Önbellek"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Blok aygıtları eklemek, havuzun kilidinin açılmasını gerektirir."
 ],
 "Encrypted Stratis pool": [
  null,
  "Şifrelenmiş Stratis havuzu"
 ],
 "Delete pool": [
  null,
  "Havuzu sil"
 ],
 "Encryption tokens": [
  null,
  "Şifreleme belirteçleri"
 ],
 "Stratis filesystems": [
  null,
  "Stratis dosya sistemleri"
 ],
 "Create new filesystem": [
  null,
  "Yeni dosya sistemi oluştur"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Bu havuz, blok aygıtlardaki alanın tümünü kullanmaz."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Bu havuzun bazı blok aygıtları, havuz oluşturulduktan sonra boyut olarak büyüdü. Havuz, yeni mevcut alanı kullanmak üzere güvenli bir şekilde büyütülebilir."
 ],
 "Grow the pool to take all space": [
  null,
  "Tüm alanı kaplayacak şekilde havuzu büyüt"
 ],
 "This pool is in a degraded state.": [
  null,
  "Bu havuz bozulmuş bir durumda."
 ],
 "No filesystems": [
  null,
  "Dosya sistemleri yok"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis dosya sistemleri havuzu"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Bu parola, havuzun kilidini açmanın tek yoludur ve kaldırılamaz."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Bu anahtar sunucusu, havuzun kilidini açmanın tek yoludur ve kaldırılamaz."
 ],
 "Add passphrase": [
  null,
  "Parola ekle"
 ],
 "Add keyserver": [
  null,
  "Anahtar sunucusu ekle"
 ],
 "Clevis \"$0\"": [
  null,
  "Clevis \"$0\""
 ],
 "Last token can not be removed": [
  null,
  "Son belirteç kaldırılamaz"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Parolalar veya anahtar sunucuları için daha fazla alan yok."
 ],
 "Confirm": [
  null,
  "Onayla"
 ],
 "Adding a passphrase requires unlocking the pool.": [
  null,
  "Bir parola eklemek, havuzun kilidinin açılmasını gerektirir."
 ],
 "Remove passphrase?": [
  null,
  "Parola kaldırılsın mı?"
 ],
 "Add Tang keyserver": [
  null,
  "Tang anahtar sunucusu ekle"
 ],
 "Adding a keyserver requires unlocking the pool.": [
  null,
  "Bir anahtar sunucusu eklemek, havuzun kilidinin açılmasını gerektirir."
 ],
 "Remove Clevis token?": [
  null,
  "Clevis belirteci kaldırılsın mı?"
 ],
 "Metadata format": [
  null,
  "Üstveri biçimi"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Üstveri biçimi V1'e sahip havuzlar, en fazla bir parola ve en fazla bir anahtar sunucusu ile sınırlıdır."
 ],
 "Overprovisioning": [
  null,
  "Aşırı sağlama"
 ],
 "Allow overprovisioning": [
  null,
  "Aşırı sağlamaya izin ver"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Sanal dosya sistemi boyutları havuzdan daha büyük. Aşırı sağlama etkisizleştirildi."
 ],
 "Allocated": [
  null,
  "Ayrıldı"
 ],
 "Name can not be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "A pool with this name exists already.": [
  null,
  "Bu adda bir havuz zaten var."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Bu havuzda bu adda bir dosya sistemi zaten var."
 ],
 "Create Stratis pool": [
  null,
  "Stratis havuzu oluştur"
 ],
 "No block devices are available.": [
  null,
  "Kullanılabilir blok aygıtlar yok."
 ],
 "At least one block device is needed.": [
  null,
  "En az bir blok aygıtı gerekli."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Verileri bir parolayla şifrele"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Verileri Tang anahtar sunucusuyla şifrele"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "$0 dosya sistemi için anlık görüntü oluştur"
 ],
 "Create snapshot and mount": [
  null,
  "Anlık görüntü oluştur ve bağla"
 ],
 "Create snapshot only": [
  null,
  "Sadece anlık görüntü oluştur"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Bir dosya sistemini silmek, içindeki tüm verileri silecek."
 ],
 "Snapshot": [
  null,
  "Anlık görüntü"
 ],
 "Rename filesystem": [
  null,
  "Dosya sistemini yeniden adlandır"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Sanal dosya sistemi boyutunun sınırını ayarla"
 ],
 "Limit virtual filesystem size": [
  null,
  "Sanal dosya sistemi boyutunu sınırla"
 ],
 "Virtual size limit": [
  null,
  "Sanal boyut sınırı"
 ],
 "Virtual size": [
  null,
  "Sanal boyut"
 ],
 "Create RAID device": [
  null,
  "RAID aygıtı oluştur"
 ],
 "RAID level": [
  null,
  "RAID seviyesi"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (şeritleme)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (yansıtma)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (adanmış eşlik)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (dağıtılmış eşlik)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (çift dağıtılmış eşlik)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (yansıtmaları şeritleme)"
 ],
 "Chunk size": [
  null,
  "Öbek boyutu"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "En az $0 disk gerekli.",
  "En az $0 disk gerekli."
 ],
 "MDRAID disk": [
  null,
  "MDRAID diski"
 ],
 "In sync": [
  null,
  "Eşitleme durumunda"
 ],
 "Spare": [
  null,
  "Yedek"
 ],
 "Recovering": [
  null,
  "Kurtarılıyor"
 ],
 "Write-mostly": [
  null,
  "Çoğunlukla yazma"
 ],
 "Blocked": [
  null,
  "Engellendi"
 ],
 "Unknown ($0)": [
  null,
  "Bilinmeyen ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID aygıtı çalışıyor olmak zorundadır"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID aygıtı kurtarılıyor"
 ],
 "Need a spare disk": [
  null,
  "Yedek diske ihtiyaç var"
 ],
 "Last disk can not be removed": [
  null,
  "Son disk kaldırılamaz"
 ],
 "MDRAID device": [
  null,
  "MDRAID aygıtı"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 aygıtının durdurulmasını onaylayın"
 ],
 "Stop device": [
  null,
  "Aygıtı durdur"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Silme, bir MDRAID aygıtı üzerindeki tüm verileri siler."
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID aygıtı çalışıyor olmak zorundadır"
 ],
 "Add disk": [
  null,
  "Disk ekle"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 disk"
 ],
 "$0 chunk size": [
  null,
  "$0 parça boyutu"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID aygıtı bozulmuş bir durumda"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Bu MDRAID aygıtının yazma amaçlı bit eşlemi yoktur. Böyle bir bit eşlem, eşitleme sürelerini önemli ölçüde azaltabilir."
 ],
 "Add a bitmap": [
  null,
  "Bit eşlem ekle"
 ],
 "No disks found": [
  null,
  "Bulunan diskler yok"
 ],
 "MDRAID disks": [
  null,
  "MDRAID diskleri"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Silme, bir VDO aygıtı üzerindeki tüm verileri siler."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Bu VDO aygıtının oluşturulması tamamlanmadı ve aygıt kullanılamaz."
 ],
 "Remove device": [
  null,
  "Aygıtı kaldır"
 ],
 "Grow to take all space": [
  null,
  "Tüm alanı kaplayacak şekilde büyüt"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Bu VDO aygıtı, yedek aygıtlarının tümünü kullanmıyor."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Sadece $0 / $1 kullanılıyor."
 ],
 "Grow logical size of $0": [
  null,
  "$0'ın mantıksal boyutunu büyüt"
 ],
 "Physical": [
  null,
  "Fiziksel"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 veri + $1 ek yük kullanıldı, toplam $2 ($3)"
 ],
 "Logical": [
  null,
  "Mantıksal"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 kullanıldı, toplam $1 ($2 tasarruf edildi)"
 ],
 "Index memory": [
  null,
  "İndeks belleği"
 ],
 "SMART self-test of $target": [
  null,
  "$target aygıtının SMART kendi kendini denemesi"
 ],
 "Ejecting $target": [
  null,
  "$target çıkarılıyor"
 ],
 "Unlocking $target": [
  null,
  "$target kilidi açılıyor"
 ],
 "Locking $target": [
  null,
  "$target kilitleniyor"
 ],
 "Modifying $target": [
  null,
  "$target değiştiriliyor"
 ],
 "Resizing $target": [
  null,
  "$target yeniden boyutlandırılıyor"
 ],
 "Starting swapspace $target": [
  null,
  "Takas alanı $target başlatılıyor"
 ],
 "Stopping swapspace $target": [
  null,
  "Takas alanı $target durduruluyor"
 ],
 "Mounting $target": [
  null,
  "$target bağlanıyor"
 ],
 "Unmounting $target": [
  null,
  "$target bağlantısı kaldırılıyor"
 ],
 "Checking $target": [
  null,
  "$target denetleniyor"
 ],
 "Repairing $target": [
  null,
  "$target onarılıyor"
 ],
 "Erasing $target": [
  null,
  "$target siliniyor"
 ],
 "Creating filesystem on $target": [
  null,
  "$target üzerinde dosya sistemi oluşturuluyor"
 ],
 "Setting up loop device $target": [
  null,
  "Döngü aygıtı $target ayarlanıyor"
 ],
 "Deleting $target": [
  null,
  "$target siliniyor"
 ],
 "Creating partition $target": [
  null,
  "$target bölümü oluşturuluyor"
 ],
 "Cleaning up for $target": [
  null,
  "$target temizleniyor"
 ],
 "Securely erasing $target": [
  null,
  "$target güvenli bir şekilde siliniyor"
 ],
 "Very securely erasing $target": [
  null,
  "$target çok güvenli bir şekilde siliniyor"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID aygıtı $target durduruluyor"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID aygıtı $target başlatılıyor"
 ],
 "Marking $target as faulty": [
  null,
  "$target hatalı olarak işaretleniyor"
 ],
 "Removing $target from MDRAID device": [
  null,
  "MDRAID aygıtından $target kaldırılıyor"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID aygıtı $target oluşturuluyor"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID aygıtı $target denetleniyor"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID aygıtı $target denetleniyor ve onarılıyor"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID aygıtı $target kurtarılıyor"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID aygıtı $target eşitleniyor"
 ],
 "Activating $target": [
  null,
  "$target etkinleştiriliyor"
 ],
 "Deactivating $target": [
  null,
  "$target devre dışı bırakılıyor"
 ],
 "Creating snapshot of $target": [
  null,
  "$target için anlık görüntü oluşturuluyor"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu oluşturuluyor"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu siliniyor"
 ],
 "Adding physical volume to $target": [
  null,
  "$target aygıtına fiziksel birim ekleniyor"
 ],
 "Removing physical volume from $target": [
  null,
  "$target aygıtından fiziksel birim kaldırılıyor"
 ],
 "Emptying $target": [
  null,
  "$target boşaltılıyor"
 ],
 "Creating logical volume $target": [
  null,
  "$target mantıksal birimi oluşturuluyor"
 ],
 "Renaming $target": [
  null,
  "$target yeniden adlandırılıyor"
 ],
 "Operation '$operation' on $target": [
  null,
  "$target üzerinde '$operation' işlemi"
 ],
 "unknown target": [
  null,
  "bilinmeyen hedef"
 ],
 "Jobs": [
  null,
  "İşler"
 ],
 "Reading": [
  null,
  "Okunuyor"
 ],
 "Writing": [
  null,
  "Yazma"
 ],
 "Install Stratis support": [
  null,
  "Stratis desteğini kur"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis havuzları oluşturmak için $0 paketi kurulmak zorundadır."
 ],
 "Install NFS support": [
  null,
  "NFS desteğini kur"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID aygıtı oluştur"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 birim grubu oluştur"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI başlatıcı adını değiştir"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI portalı ekle"
 ],
 "Local storage": [
  null,
  "Yerel depolama"
 ],
 "Networked storage": [
  null,
  "Ağa bağlı depolama"
 ],
 "Create storage device": [
  null,
  "Depolama aygıtı oluştur"
 ],
 "No storage found": [
  null,
  "Bulunan depolama yok"
 ],
 "Server address cannot be empty.": [
  null,
  "Sunucu adresi boş olamaz."
 ],
 "Next": [
  null,
  "Sonraki"
 ],
 "Invalid username or password": [
  null,
  "Geçersiz kullanıcı adı veya parola"
 ],
 "Unknown host name": [
  null,
  "Bilinmeyen anamakine adı"
 ],
 "Unable to reach server": [
  null,
  "Sunucuya ulaşılamıyor"
 ],
 "Available targets on $0": [
  null,
  "$0 üzerindeki kullanılabilir hedefler"
 ],
 "Authentication required": [
  null,
  "Kimlik doğrulaması gerekli"
 ],
 "iSCSI portal": [
  null,
  "iSCSI portalı"
 ],
 "iSCSI drives": [
  null,
  "iSCSI sürücüleri"
 ],
 "No drives found": [
  null,
  "Bulunan sürücüler yok"
 ],
 "Target": [
  null,
  "Hedef"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO yedek aygıtları küçültülemez"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdev'leri küçültülemez"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Tanınmayan veriler burada küçültülemez."
 ],
 "Unlock before resizing": [
  null,
  "Yeniden boyutlandırmadan önce kilidini aç"
 ],
 "$0 can not be resized here": [
  null,
  "$0 burada yeniden boyutlandırılamaz"
 ],
 "$0 can not be resized": [
  null,
  "$0 yeniden boyutlandırılamaz"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 daha küçültülemez"
 ],
 "$0 can not be made larger": [
  null,
  "$0 daha büyütülemez"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Fiziksel birimler burada yeniden boyutlandırılamaz"
 ],
 "Swap can not be resized here": [
  null,
  "Takas burada yeniden boyutlandırılamaz"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Tanınmayan veriler burada küçültülemez"
 ],
 "Activate before resizing": [
  null,
  "Yeniden boyutlandırmadan önce etkinleştir"
 ],
 "Grow logical volume": [
  null,
  "Mantıksal birimi büyüt"
 ],
 "Grow partition": [
  null,
  "Bölümü büyüt"
 ],
 "grow": [
  null,
  "büyüt"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Tam olarak $0 fiziksel birim seçilmek zorundadır"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Şifrelenmiş bir dosya sistemini yeniden boyutlandırmak, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Mantıksal birimin her şeritlemesi için bir tane olmak üzere tam olarak $0 fiziksel birimin seçilmesi gerekir."
 ],
 "Shrink logical volume": [
  null,
  "Mantıksal birimi küçült"
 ],
 "shrink": [
  null,
  "küçült"
 ],
 "Unformatted data": [
  null,
  "Biçimlendirilmemiş veriler"
 ],
 "Block device": [
  null,
  "Blok aygıt"
 ],
 "Device number": [
  null,
  "Aygıt numarası"
 ],
 "Create partition on $0": [
  null,
  "$0 üzerinde bölüm oluştur"
 ],
 "Format $0": [
  null,
  "$0 biçimlendir"
 ],
 "No filesystem": [
  null,
  "Dosya sistemi yok"
 ],
 "(recommended)": [
  null,
  "(önerilir)"
 ],
 "No encryption": [
  null,
  "Şifreleme yok"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Varolan şifrelemeyi yeniden kullan ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Varolan şifrelemeyi yeniden kullan"
 ],
 "format": [
  null,
  "biçim"
 ],
 "Format and mount": [
  null,
  "Biçimlendir ve bağla"
 ],
 "Format only": [
  null,
  "Sadece biçimlendir"
 ],
 "Format": [
  null,
  "Biçimlendir"
 ],
 "Create and start": [
  null,
  "Oluştur ve başlat"
 ],
 "Format and start": [
  null,
  "Biçimlendir ve başlat"
 ],
 "Store passphrase": [
  null,
  "Parolayı sakla"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Biçimlendirmeden önce diskin kilidinin açılması gerekir. Lütfen varolan bir parola verin."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Biçimlendirme, depolama aygıtı üzerindeki tüm verileri siler."
 ],
 "Unrecognized data": [
  null,
  "Tanınmayan veri"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Bu sistemde depolama yönetilemez."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bayt"
 ]
});
