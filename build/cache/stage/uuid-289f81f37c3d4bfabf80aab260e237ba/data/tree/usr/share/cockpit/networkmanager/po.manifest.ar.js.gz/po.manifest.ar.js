cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Services": [
  null,
  "الخدمات"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "network": [
  null,
  "الشَبكة"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "الواجهة"
 ],
 "bridge": [
  null,
  "جسر"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "bond": [
  null,
  "رابط شبكي"
 ],
 "team": [
  null,
  "فريق"
 ],
 "port": [
  null,
  "منفذ"
 ],
 "mac": [
  null,
  "mac"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "firewall": [
  null,
  "الجِدار النّاري"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "منطقة"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "إدارة الوصلات الشبكية المجمَّعة"
 ],
 "Managing networking teams": [
  null,
  "إدارة فرق الشبكات"
 ],
 "Managing networking bridges": [
  null,
  "إدارة جسور الشبكات"
 ],
 "Managing VLANs": [
  null,
  "إدارة الشبكات المحلية الافتراضية (VLANs)"
 ],
 "Managing firewall": [
  null,
  "إدارة الجدار الناري"
 ]
});
