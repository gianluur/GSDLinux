cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "Hardware information": [
  null,
  "Informace o hardware"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "Default": [
  null,
  "Výchozí"
 ],
 "Light": [
  null,
  "Světlý"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Help": [
  null,
  "Nápověda"
 ],
 "Select": [
  null,
  "Vybrat"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Search": [
  null,
  "Hledat"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "Permission denied": [
  null,
  "Přístup zamítnut"
 ],
 "Clear input value": [
  null,
  "Vymazat vstupní hodnotu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky pomocí NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticky pomocí dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky pomocí konkrétních NTP serverů"
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "Create $0": [
  null,
  "Vytvořit $0"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "Nejsou k dispozici žádné metody pro získání přístupu pro správu (sudo -A, pkexec)."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "$0 will be installed.": [
  null,
  "Bude nainstalováno $0."
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásilo chybový kód $0"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Error during initialization": [
  null,
  "Chyba při inicializaci"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Home": [
  null,
  "Domovská složka"
 ],
 "Downloads": [
  null,
  "Stahování"
 ],
 "Not a directory": [
  null,
  "Nejedná se o složku"
 ],
 "All files": [
  null,
  "Všechny soubory"
 ],
 "Recent": [
  null,
  "Nedávné"
 ],
 "No recent directories": [
  null,
  "Žádné nedávné složky"
 ],
 "No recent files": [
  null,
  "Žádné nedávné soubory"
 ],
 "Type to filter": [
  null,
  "Filtrujte psaním"
 ],
 "File chooser actions": [
  null,
  "Akce dialogu výběru souboru"
 ],
 "Open in file browser": [
  null,
  "Otevřít v procházení souborů"
 ],
 "Hide hidden files": [
  null,
  "Nezobrazovat skryté soubory"
 ],
 "Show hidden files": [
  null,
  "Zobrazit skryté soubory"
 ],
 "Filesystem": [
  null,
  "Souborový systém"
 ],
 "Clear filters": [
  null,
  "Vyčistit filtry"
 ],
 "Directory is empty": [
  null,
  "Složka je prázdná"
 ],
 "Directory has no sub-directories": [
  null,
  "Složka nemá žádné podsložky"
 ],
 "This directory contains only hidden files": [
  null,
  "Tato složka obsahuje pouze skryté soubory"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "Folder": [
  null,
  "Složka"
 ],
 "File": [
  null,
  "Soubor"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Select an option": [
  null,
  "Vyberte možnost"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "$0 is not a directory": [
  null,
  "$0 není složka"
 ],
 "$0 does not exist": [
  null,
  "$0 neexistuje"
 ],
 "Font size": [
  null,
  "Velikost písmen"
 ],
 "Decrease by one": [
  null,
  "Snížit o jedno"
 ],
 "Increase by one": [
  null,
  "Navýšit o jednu"
 ],
 "Appearance": [
  null,
  "Vzhled"
 ],
 "Black": [
  null,
  "Černý"
 ],
 "White": [
  null,
  "Bílý"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Unable to open directory": [
  null,
  "Složku není možné otevřít"
 ],
 "Running process prevents directory change": [
  null,
  "Spuštěný proces brání ve změně složky"
 ],
 "Change directory": [
  null,
  "Změnit složku"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Změna složky vynuceně ukončí právě spuštěný proces. Proces je také možné před pokračováním zastavit ručně v terminálu."
 ],
 "Terminal not available": [
  null,
  "Terminál není k dispozici"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Tento prohlíčeč nepodporuje WebGL2."
 ],
 "unknown": [
  null,
  "neznámý"
 ],
 "Shutdown": [
  null,
  "Vypnout"
 ],
 "running $0": [
  null,
  "provozováno na $0"
 ],
 "Current boot": [
  null,
  "Od tohoto spuštění systému"
 ],
 "Previous boot": [
  null,
  "Předchozí spuštění systému"
 ],
 "Last 24 hours": [
  null,
  "Uplynulých 24 hodin"
 ],
 "Last 7 days": [
  null,
  "Uplynulých 7 dnů"
 ],
 "Only emergency": [
  null,
  "Pouze nouzové"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnější"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnější"
 ],
 "Error and above": [
  null,
  "Chyba a závažnější"
 ],
 "Warning and above": [
  null,
  "Varování a závažnější"
 ],
 "Notice and above": [
  null,
  "Oznámení a závažnější"
 ],
 "Info and above": [
  null,
  "Informace a závažnější"
 ],
 "Debug and above": [
  null,
  "Ladící a závažnější"
 ],
 "Toggle filters": [
  null,
  "Přepnout filtry"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "Filters": [
  null,
  "Filtry"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Resume": [
  null,
  "Pokračovat"
 ],
 "All": [
  null,
  "Vše"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Zadání datumů by mělo být ve formátu RRRR-MM-DD hh:mm:ss. Alternativně je možné použít ještě řetězce „yesterday“ (včera), „today“ (dnes), „tomorrow“ (zítra). „now“ (nyní) odkazuje na aktuální dobu. Dále je možné zadávat vztažené (relativní) časy, předeslané předponou „-“ nebo „+“"
 ],
 "Since": [
  null,
  "Od"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data výše."
 ],
 "Until": [
  null,
  "Do"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data dál do minulosti."
 ],
 "Boot": [
  null,
  "Start systému"
 ],
 "Show messages from a specific boot.": [
  null,
  "Zobrazit zprávy z konkrétního startu systému."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Toto přidá shodu pro „_BOOT_ID=“. Pokud není určeno, budou zobrazeny záznamy událostí pro stávající start systému. Pokud je identifikátor startu vynechán, kladný posun prohledá starty počínaje od začátku žurnálu a posun rovný nebo menší než nula prohledá starty počínaje od konce žurnálu. Proto 1 znamená první start, nalezený v žurnálu v chronologickém pořadí, 2 druhý a tak dále; zatímco -0 je poslední start, -1 start před tím posledním, a tak dále."
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Zobrazit zprávy pro zadanou systemd jednotku."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Toto přidá shodu pro „_SYSTEMD_UNIT=“, „COREDUMP_UNIT=“ a „UNIT=“ a pomůže tak nalezení všech případných zpráv pro danou jednotku. Může obsahovat vícero jednotek, oddělovaných čárkou."
 ],
 "Free-form search": [
  null,
  "Vyhledávání volnou formou"
 ],
 "Show messages containing given string.": [
  null,
  "Zobrazit zprávy obsahující daný řetězec."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "V hlášeních v záznamu událostí (log) je možné filtrovat podle libovolného textového řetězce. Řetězec také může mít podobu regulárního výrazu. Také je podporováno filtrování podle kolonek zprávy záznamu událostí. Zde se jedná o mezerami oddělované hodnoty v podobě KOLONKA=HODNOTA, kde hodnota může být čárkou oddělovaný seznam možných hodnot."
 ],
 "journalctl manpage": [
  null,
  "manuálová stránka k journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Úspěšně zkopírováno do schránky"
 ],
 "Create timer": [
  null,
  "Vytvořit časovač"
 ],
 "Edit timer": [
  null,
  "Upravit časovač"
 ],
 "Timer creation failed": [
  null,
  "Vytvoření časovače se nezdařilo"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  "Nepodařilo se získat podmínky startu časovače"
 ],
 "Failed to get the timer command": [
  null,
  "Nepodařilo se získat příkaz časovače"
 ],
 "This field cannot be empty": [
  null,
  "Tuto kolonku je třeba vyplnit"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Dovolena jsou pouze písmena a číslice, dále ještě znaky : , _ , . , @ , -"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Shell command": [
  null,
  "Příkaz shellu"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  "Tento příkaz bude vykonán pomocí /bin/sh."
 ],
 "Trigger": [
  null,
  "Spouštěč"
 ],
 "At specific time": [
  null,
  "V uvedený čas"
 ],
 "After system boot": [
  null,
  "Po startu systému"
 ],
 "Seconds": [
  null,
  "Sekund"
 ],
 "Minutes": [
  null,
  "Minut"
 ],
 "Hours": [
  null,
  "Hodin"
 ],
 "Weeks": [
  null,
  "Týdny"
 ],
 "Delay must be a number": [
  null,
  "Je třeba, aby prodleva byla číslo"
 ],
 "Repeat": [
  null,
  "Opakovat"
 ],
 "Don't repeat": [
  null,
  "Neopakovat"
 ],
 "Minutely": [
  null,
  "Po minutách"
 ],
 "Hourly": [
  null,
  "Každou hodinu"
 ],
 "Daily": [
  null,
  "Denně"
 ],
 "Weekly": [
  null,
  "Každý týden"
 ],
 "Monthly": [
  null,
  "Každý měsíc"
 ],
 "Yearly": [
  null,
  "Každý rok"
 ],
 "Run at": [
  null,
  "Spustit v"
 ],
 "At second": [
  null,
  "V sekundě"
 ],
 "At minute": [
  null,
  "V minutě"
 ],
 "Run on": [
  null,
  "Spustit na"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Je třeba, aby minuta bylo číslo z rozmezí 0-59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Je třeba, aby sekunda bylo číslo z rozmezí 0-59"
 ],
 "Repeat weekly": [
  null,
  "Opakovat každý týden"
 ],
 "Mondays": [
  null,
  "Pondělky"
 ],
 "Tuesdays": [
  null,
  "Úterky"
 ],
 "Wednesdays": [
  null,
  "Středy"
 ],
 "Thursdays": [
  null,
  "Čtvrtky"
 ],
 "Fridays": [
  null,
  "Pátky"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Sundays": [
  null,
  "Neděle"
 ],
 "Repeat monthly": [
  null,
  "Opakovat každý měsíc"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Unclean shutdown": [
  null,
  "Nekorektně vypnout"
 ],
 "View logs": [
  null,
  "Zobrazit záznamy událostí"
 ],
 "Dismiss": [
  null,
  "Zahodit"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Naplánované vypnutí v $0"
 ],
 "Cancel poweroff": [
  null,
  "Zrušit vypínání"
 ],
 "Scheduled reboot at $0": [
  null,
  "Naplánovaný restart v $0"
 ],
 "Cancel reboot": [
  null,
  "Zrušit restartování"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "Set hostname": [
  null,
  "Nastavit název stroje"
 ],
 "Configuration": [
  null,
  "Nastavení"
 ],
 "Hostname": [
  null,
  "Název stroje"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Performance profile": [
  null,
  "Výkonnostní profil"
 ],
 "Secure shell keys": [
  null,
  "Klíče zabezpečeného shellu"
 ],
 "Show fingerprints": [
  null,
  "Zobrazit otisky"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nepodařilo se vypsat ssh klíče stroje: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Načítání SSH klíčů se nezdařilo"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "Loading keys...": [
  null,
  "Načítání klíčů…"
 ],
 "No host keys found.": [
  null,
  "Nenalezeny žádné klíče stroje."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Otisky SSH klíče stroje"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Je třeba, aby skutečný název stroje byl nanejvýš 64 znaků dlouhý"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutečný název stroje může obsahovat pouze malá písmena (bez diakritiky), číslice, spojovníky a tečky (u použitých subdomén)"
 ],
 "Change host name": [
  null,
  "Změnit název stroje"
 ],
 "Pretty host name": [
  null,
  "Hezký název stroje"
 ],
 "Real host name": [
  null,
  "Skutečný název stroje"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Uživatel $0 nemá oprávnění měnit pravidla pro šifrování"
 ],
 "Cryptographic policy": [
  null,
  "Zásady pro šifrování"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Doporučeno, bezpečné nastavení pro stávající modely ohrožení."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "VÝCHOZÍ s umožněným ověřování SHA-1 podpisu."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Výborná interoperabilita na úkor zvýšeného vystavení se útokům."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "PŮVODNÍ s interoperabilitou s Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Při startu systému ve FIPS režimu použít pouze schválené a povolené algoritmy."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS s dalšími omezeními běžnými kritérii."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chrání před očekávanými nedalekými budoucími útoky za cenu horší interoperability."
 ],
 "Custom cryptographic policy": [
  null,
  "Uživatelsky určené zásady pro šifrování"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografické zásady je systémová součást, která nastavuje hlavní kryptografické podsystémy – pokrývá protokoly TLS, IPSec, SSH, DNSSec a Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Změnit zásady pro šifrování"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Uplatňování nových zásad… Toto může zabrat několik minut."
 ],
 "Reapply and reboot": [
  null,
  "Znovu uplatnit a restartovat"
 ],
 "Apply and reboot": [
  null,
  "Použít a restartovat"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS není řádně zapnuté"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Zásady pro šifrování nejsou konzistentní"
 ],
 "Review cryptographic policy": [
  null,
  "Zkontrolovat zásady pro šifrování"
 ],
 "System information": [
  null,
  "Informace o systému"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Inventární štítek"
 ],
 "Machine ID": [
  null,
  "Identif. stroje"
 ],
 "Up since": [
  null,
  "Zapnuto před"
 ],
 "View hardware details": [
  null,
  "Zobrazit podrobnosti o hardware"
 ],
 "Last successful login:": [
  null,
  "Poslední úspěšné přihlášení:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 nepodařený pokus o přihlášení",
  "$0 nepodařené pokusy o přihlášení",
  "$0 nepodařených pokusů o přihlášení"
 ],
 "View login history": [
  null,
  "Zobrazit historii přihlášení"
 ],
 "recommended": [
  null,
  "doporučeno"
 ],
 "inconsistent": [
  null,
  "nekonzistentní"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Přidání do domény vyžaduje instalaci nástroje realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nelze přidat do domény, protože na tomto systému chybí nástroj realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Přidání do této domény není podporováno"
 ],
 "Login format": [
  null,
  "Formát přihlašování"
 ],
 "Server software": [
  null,
  "Serverový software"
 ],
 "Client software": [
  null,
  "Klientský software"
 ],
 "Leave domain": [
  null,
  "Opustit doménu"
 ],
 "Leave $0": [
  null,
  "Opustit $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opuštění domény se do tohoto stroje budou moci přihlásit jen ti uživatelé, kteří mají účet přímo na něm. Může to postihnout také ostatní služby, jako je nastavení DNS překladu a může se změnit seznam důvěryhodných cert. autorit."
 ],
 "Validating address": [
  null,
  "Ověřuje se adresa"
 ],
 "Contacted domain": [
  null,
  "Připojená doména"
 ],
 "Domain could not be contacted": [
  null,
  "Doménu se nedaří kontaktovat"
 ],
 "Domain is not supported": [
  null,
  "Doména není podporována"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Uživatelské jméno správce domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správce domény"
 ],
 "Joining": [
  null,
  "Přidává se"
 ],
 "Join": [
  null,
  "Spojit"
 ],
 "This may take a while": [
  null,
  "Toto může chvíli trvat"
 ],
 "Not permitted to configure realms": [
  null,
  "Nemáte oprávnění nastavovat realmy"
 ],
 "Join domain": [
  null,
  "Přidat do domény"
 ],
 "Install realmd support": [
  null,
  "Nainstalovat podporu pro realmd"
 ],
 "$0 disk is failing": [
  null,
  "$0 disk selhává",
  "$0 disky selhávají",
  "$0 disků selhává"
 ],
 "Connected to Insights": [
  null,
  "Připojeno k Insights"
 ],
 "Not connected to Insights": [
  null,
  "Nepřipojeno k Insights"
 ],
 "Health": [
  null,
  "Celkový stav"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "ze $0 procesorů",
  "z $0 procesorů"
 ],
 "Usage": [
  null,
  "Využití"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "View metrics and history": [
  null,
  "Zobrazit metriky a jejich historii"
 ],
 "Tuned is not available": [
  null,
  "Tuned není k dispozici"
 ],
 "Tuned is not running": [
  null,
  "Tuned není spuštěné"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používá doporučený profil"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používá uživatelsky určený profil"
 ],
 "none": [
  null,
  "nic"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikace s procesem služby tuned se nezdařila"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodařilo se zapnout tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodařilo se zakázat proces služby tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Nepodařilo se vypnout tuned profil"
 ],
 "Failed to switch profile": [
  null,
  "Nepodařilo se přepnout profil"
 ],
 "None": [
  null,
  "Žádné"
 ],
 "Disable tuned": [
  null,
  "Zakázat proces služby tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Spuštění procesu služby tuned se nezdařilo"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba která monitoruje váš systém a optimalizuje jeho výkon pod určitými zátěžemi. Jádrem Tuned jsou profily, který ladí váš systém pro různé případy použití."
 ],
 "Change performance profile": [
  null,
  "Změnit výkonnostní profil"
 ],
 "Change profile": [
  null,
  "Změnit profil"
 ],
 "Edit /etc/motd": [
  null,
  "Upravit soubor /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodařilo se uložit změny v /etc/motd"
 ],
 "Save changes": [
  null,
  "Uložit změny"
 ],
 "Edit motd": [
  null,
  "Upravit motd"
 ],
 "Stub": [
  null,
  "Pahýl"
 ],
 "Not found": [
  null,
  "Nenalezeno"
 ],
 "Bad setting": [
  null,
  "Chybné nastavení"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Merged": [
  null,
  "Sloučeno"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "Reloading": [
  null,
  "Opětovné načítání"
 ],
 "Not running": [
  null,
  "Není spuštěné"
 ],
 "Failed to start": [
  null,
  "Nepodařilo se spustit"
 ],
 "Maintenance": [
  null,
  "Údržba"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Linked": [
  null,
  "Odkazováno"
 ],
 "Alias": [
  null,
  "Alternativní název"
 ],
 "Masked": [
  null,
  "Maskováno"
 ],
 "Static": [
  null,
  "Statické"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Indirect": [
  null,
  "Nepřímé"
 ],
 "Generated": [
  null,
  "Vytvořeno"
 ],
 "Transient": [
  null,
  "Přechodné"
 ],
 "Bad": [
  null,
  "Chybné"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Přihlášení se k odběru systemd signálů se nezdařilo: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Připojení k dbus se nezdařilo: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Vypsání jednotek se nezdařilo: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 služba zhavarovala",
  "$0 služby zhavarovaly",
  "$0 služeb zhavarovalo"
 ],
 "Loading of units failed": [
  null,
  "Načítání jednotek se nezdařilo"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Listing units": [
  null,
  "Vypisují se jednotky (unit)"
 ],
 "Filter by name or description": [
  null,
  "Filtrovat podle názvu nebo popisu"
 ],
 "Active state": [
  null,
  "Aktivní stav"
 ],
 "File state": [
  null,
  "Stav souboru"
 ],
 "$0 filters applied": [
  null,
  "$0 filtrů uplatněno"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Uživatel $0 není oprávněn měnit zmírňování dopadu chyb zabezpečení procesoru"
 ],
 "Mitigations": [
  null,
  "Zmírnění dopadu zranitelností"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "BIOS": [
  null,
  "BIOS/UEFI"
 ],
 "BIOS version": [
  null,
  "Verze BIOS/UEFI"
 ],
 "BIOS date": [
  null,
  "Datum vydání BIOS/UEFI"
 ],
 "CPU security": [
  null,
  "Zabezpečení procesoru"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnout souběžné vícevláknové zpracovávání (SMT)"
 ],
 "Read more...": [
  null,
  "Zjistit více…"
 ],
 "Save and reboot": [
  null,
  "Uložit a restartovat"
 ],
 "CPU security toggles": [
  null,
  "Přepínače zabezpečení procesoru"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarová ošetření problémů zabezpečení procesoru, snižující riziko jejich zneužití. Mají negativní dopad na výkonnost. Nastavení měníte na vlastní nebezpeční."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Třída"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Memory technology": [
  null,
  "Technologie paměti"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Speed": [
  null,
  "Rychlost"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zobrazování informaci o paměti vyžaduje oprávnění na úrovni správy systému."
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Failed to fetch logs": [
  null,
  "Nepodařilo se získat záznamy událostí"
 ],
 "Clear all filters": [
  null,
  "Vyčistit všechny filtry"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Při použití stávající kombinace filtrů se nedaří nalézt žádné záznamy událostí."
 ],
 "No logs found": [
  null,
  "Nenalezeny žádné záznamy událostí"
 ],
 "Load earlier entries": [
  null,
  "Načíst dřívější položky"
 ],
 "You may try to load older entries.": [
  null,
  "Můžete zkusit načíst starší položky."
 ],
 "Allow running (unmask)": [
  null,
  "Umožnit spouštění (odmaskovat)"
 ],
 "Reload": [
  null,
  "Načíst znovu"
 ],
 "Restart": [
  null,
  "Restartovat"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistit „Nepodařilo se spustit“"
 ],
 "Mask service": [
  null,
  "Maskovat službu"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskování služby zabrání všem závislým jednotkám ve spouštění. To může mít větší dopad, než zamýšleno. Potvrďte, že chcete tuto jednotku maskovat."
 ],
 "Disallow running (mask)": [
  null,
  "Nepovolit spuštění (maskovat)"
 ],
 "Unpin unit": [
  null,
  "Zrušit připnutí jednotky"
 ],
 "Pin unit": [
  null,
  "Připnout jednotku"
 ],
 "Additional actions": [
  null,
  "Další akce"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Tato jednotka není navržena k tomu, aby byla výslovně zapnuta."
 ],
 "Forbidden from running": [
  null,
  "Spuštění zakázáno"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Active since ": [
  null,
  "Aktivní od "
 ],
 "Required by ": [
  null,
  "Vyžadováno "
 ],
 "Read-only": [
  null,
  "Pouze pro čtení"
 ],
 "Requires administration access to edit": [
  null,
  "Pro úpravu jsou vyžadována oprávnění správce systému"
 ],
 "Automatically starts": [
  null,
  "Spouští se automaticky"
 ],
 "Updating status...": [
  null,
  "Aktualizace stavu…"
 ],
 "Stop and disable": [
  null,
  "Zastavit a vypnout"
 ],
 "Start and enable": [
  null,
  "Spustit a zapnout"
 ],
 "Failed to load unit": [
  null,
  "Jednotku (unit) se nepodařilo načíst"
 ],
 "View all services": [
  null,
  "Zobrazit všechny služby"
 ],
 "Triggers": [
  null,
  "Spouštěče"
 ],
 "Triggered by": [
  null,
  "Spuštěno na základě"
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requisite": [
  null,
  "Závislost"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Binds to": [
  null,
  "Navazuje se na"
 ],
 "Part of": [
  null,
  "Součástí"
 ],
 "Required by": [
  null,
  "Vyžadováno"
 ],
 "Requisite of": [
  null,
  "Závislost pro"
 ],
 "Wanted by": [
  null,
  "Vyžadováno"
 ],
 "Bound by": [
  null,
  "Spojeno"
 ],
 "Consists of": [
  null,
  "Sestává se z"
 ],
 "Conflicts": [
  null,
  "Konflikty"
 ],
 "Conflicted by": [
  null,
  "V konfliktu s"
 ],
 "Before": [
  null,
  "Před"
 ],
 "After": [
  null,
  "Po"
 ],
 "On failure": [
  null,
  "Při nezdaru"
 ],
 "Propagates reload to": [
  null,
  "Propaguje načíst znovu k"
 ],
 "Reload propagated from": [
  null,
  "Znovu načíst propagated z"
 ],
 "Joins namespace of": [
  null,
  "Připojuje jmenný prostor od"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmínka $0=$1 nebyla splněna"
 ],
 "Deletion will remove the following files:": [
  null,
  "Smazání odebere následující soubory:"
 ],
 "Pinned unit": [
  null,
  "Připnutá jednotka"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Path": [
  null,
  "Popis umístění"
 ],
 "Listen": [
  null,
  "Očekávat spojení"
 ],
 "Container": [
  null,
  "Kontejner"
 ],
 "View Podman container": [
  null,
  "Zobrazit Podman kontejner"
 ],
 "Condition failed": [
  null,
  "Podmínka nebyla úspěšná"
 ],
 "Show more relationships": [
  null,
  "Zobrazit další vztahy"
 ],
 "Show relationships": [
  null,
  "Zobrazit vztahy"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte smazání $0"
 ],
 "Timer deletion failed": [
  null,
  "Smazání časovače se nezdařilo"
 ],
 "Targets": [
  null,
  "Cíle"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "Paths": [
  null,
  "Popisy umístění"
 ],
 "Go to $0": [
  null,
  "Jít na $0"
 ],
 "Journal entry not found": [
  null,
  "Položka žurnálu nenalezena"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Entry at $0": [
  null,
  "Položka na $0"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Loading unit failed": [
  null,
  "Načítání jednotek se nezdařilo"
 ],
 "Service logs": [
  null,
  "Záznamy událostí služby"
 ],
 "No log entries": [
  null,
  "Žádné položky záznamu událostí"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Kritériím filtru neodpovídají žádné výsledky. Pro zobrazení výsledků vyčistěte veškeré filtry."
 ],
 "Does not automatically start": [
  null,
  "Nespouštět automaticky"
 ],
 "Cannot be enabled": [
  null,
  "Není možné zapnout"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzole je spuštěná v režimu omezeného přístupu."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Doména"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Přidat do domény"
 ]
});
