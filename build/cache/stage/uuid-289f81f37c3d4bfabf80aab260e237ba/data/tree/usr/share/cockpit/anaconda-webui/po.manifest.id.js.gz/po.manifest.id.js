cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  "Anaconda"
 ]
});
