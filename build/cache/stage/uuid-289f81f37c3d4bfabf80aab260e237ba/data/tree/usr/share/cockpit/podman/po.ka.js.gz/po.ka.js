cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "წავშალო $0?"
 ],
 "Force delete": [
  null,
  "ძალით წაშლა"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Must be a valid IP address": [
  null,
  "უნდა იყოს სწორი IP მისამართი"
 ],
 "1 to 65535": [
  null,
  "1-დან 65535-მდე"
 ],
 "Container port must not be empty": [
  null,
  "კონტეინერის პორტი არ შეიძლება ცარიელი იყოს"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "IP address help": [
  null,
  "IP მისამართის დახმარება"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "თუ ჰოსტის IP დაყენებულია 0.0.0.0-ზე, ან დაყენებული არაა, პორტი ჰოსტზე არსებულ ყველა IP-ზე იქნება მიმაგრებული."
 ],
 "Host port": [
  null,
  "ჰოსტის პორტი"
 ],
 "Host port help": [
  null,
  "ჰოსტის პორტის დახმარება"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "თუ ჰოსტის პორტი დაყენებული არაა, კონტეინერის პორტი ჰოსტზე შემთხვევითად იქნება არჩეული."
 ],
 "Container port": [
  null,
  "კონტეინერის პორტი"
 ],
 "Protocol": [
  null,
  "პროტოკოლი"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "ელემენტის წაშლა"
 ],
 "Image name is required": [
  null,
  "ასლის სახელი აუცილებელია"
 ],
 "Image name is not unique": [
  null,
  "ასლის სახელი უნიკალური არაა"
 ],
 "Failed to commit container $0": [
  null,
  "კონტეინერის ($0) გადაცემის შეცდომა"
 ],
 "New image name": [
  null,
  "ახალი გამოსახულების სახელი"
 ],
 "Tag": [
  null,
  "ჭდე"
 ],
 "Author": [
  null,
  "ავტორი"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "მაგ. თქვენი სახელი <yourname@example.com>"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Options": [
  null,
  "მორგება"
 ],
 "Pause container when creating image": [
  null,
  "კონტეინერის შეჩერება გამოსახულების შექმნისას"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-ის ფორმატი ძალიან სასარგებლოა გამოსახულების Docker-თან ან Moby Engline-სთან გაზიარებისთვის"
 ],
 "Use legacy Docker format": [
  null,
  "Docker-ის ძველი ფორმატის გამოყენება"
 ],
 "Commit container": [
  null,
  "კონტეინერის გაგზავნა"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "კონტეინერის ($0) მდგომარეობაზე დამყარებული ახალი გამოსახულების შექმნა."
 ],
 "Commit": [
  null,
  "გადაცემა"
 ],
 "Force commit": [
  null,
  "ძალით გადაგზავნა"
 ],
 "Failed to force remove container $0": [
  null,
  "კონტეინერის ($0) წაშლის შეცდომა"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "გაშვებული კონტეინერის წაშლა მასში ყველა მონაცემს წაშლის."
 ],
 "Failed to stop container $0": [
  null,
  "კონტეინერის ($0) გაჩერების შეცდომა"
 ],
 "Failed to stop quadlet $0": [
  null,
  "quadlet-ის ($0) გაჩერების შეცდომა"
 ],
 "Failed to start quadlet $0": [
  null,
  "quadlet-ს ($0) გაშვების შეცდომა"
 ],
 "Failed to start container $0": [
  null,
  "კონტეინერის ($0) გაშვების შეცდომა"
 ],
 "Failed to resume container $0": [
  null,
  "კონტეინერის ($0) გაგრძელების შეცდომა"
 ],
 "Failed to pause container $0": [
  null,
  "კონტეინერის ($0) შეჩერების შეცდომა"
 ],
 "Failed to restart container $0": [
  null,
  "კონტეინერის ($0) რესტარტის შეცდომა"
 ],
 "Failed to restart quadlet $0": [
  null,
  "quadlet-ის ($0) რესტარტის შეცდომა"
 ],
 "Rename": [
  null,
  "გადარქმევა"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Restart": [
  null,
  "გადატვირთვა"
 ],
 "Force stop": [
  null,
  "ძალით გაჩერება"
 ],
 "Force restart": [
  null,
  "ძალით რესტარტი"
 ],
 "Pause": [
  null,
  "პაუზა"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "Checkpoint": [
  null,
  "საკონტროლო წერტილი"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Restore": [
  null,
  "აღდგენა"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Healthy": [
  null,
  "ჯანმრთელი"
 ],
 "Unhealthy": [
  null,
  "ჯანმრთელი არაა"
 ],
 "Checking health": [
  null,
  "ჯანმრთელობის შემოწმება"
 ],
 "Prune unused containers": [
  null,
  "გამოუყენებელი კონტეინერების წაკვეთა"
 ],
 "Terminal not available": [
  null,
  "ტერმინალი ხელმისაწვდომი არაა"
 ],
 "This browser does not support WebGL2.": [
  null,
  "ამ ბრაუზერს WebGL2-ის მხარდაჭერა არ აქვს."
 ],
 "View $0 logs": [
  null,
  "$0-ის ჟურნალის ნახვა"
 ],
 "not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "n/a": [
  null,
  "ა/მ"
 ],
 "$0% of $1 limit": [
  null,
  "$0% o $1-დან ლიმიტი"
 ],
 "service": [
  null,
  "სერვისი"
 ],
 "system": [
  null,
  "სისტემა"
 ],
 "user:": [
  null,
  "მომხმარებელი:"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Integration": [
  null,
  "ინტეგრაცია"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Console": [
  null,
  "კონსოლი"
 ],
 "Health check": [
  null,
  "ჯანმრთელობის შემოწმება"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Click to see published ports": [
  null,
  "დააწკაპუნეთ გამოჩენილი პორტების სანახავად"
 ],
 "ports": [
  null,
  "პორტები"
 ],
 "Click to see volumes": [
  null,
  "დააწკაპუნეთ ტომების სანახავად"
 ],
 "volumes": [
  null,
  "ტომები"
 ],
 "Container": [
  null,
  "კონტეინერი"
 ],
 "Owner": [
  null,
  "მფლობელი"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Actions": [
  null,
  "ქმედებები"
 ],
 "No containers": [
  null,
  "კონტეიენერების გარეშე"
 ],
 "No containers in this pod": [
  null,
  "ამ Pod-ში კონტეინერები არაა"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "No containers that match the current filter": [
  null,
  "მიმდინარე ფილტრს არცერთი კონტეინერი არ შეესაბამება"
 ],
 "No running containers": [
  null,
  "გაშვებული კონტეინერების გარეშე"
 ],
 "Show": [
  null,
  "ჩვენება"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "Only running": [
  null,
  "მხოლოდ გაშვებული"
 ],
 "Create pod": [
  null,
  "pod-ის შექმნა"
 ],
 "Create container": [
  null,
  "კონტეინერის შექმნა"
 ],
 "Containers": [
  null,
  "კონტეინერები"
 ],
 "Create container in pod": [
  null,
  "pod-ში კონტეინერის შექმნა"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "კონტეინერის ($0) აღდგენის შეცდომა"
 ],
 "Restore container $0": [
  null,
  "კონტეინერის აღდგენა ($0)"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "საკონტროლო წერტილის ყველა დროებითი ფაილის შენახვა"
 ],
 "Restore with established TCP connections": [
  null,
  "დამყარებული TCP კავშირებით აღდგენა"
 ],
 "Ignore IP address if set statically": [
  null,
  "სტატიკურად მინიჭებული IP მისამართის იგნორი"
 ],
 "Ignore MAC address if set statically": [
  null,
  "სტატიკურად მინიჭებული MAC მისამართის იგნორი"
 ],
 "Pod failed to be created": [
  null,
  "Pod-ის შექმნის შეცდომა"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "არასწორი სიმბოლოები. სახელი მხოლოდ ასოებს, ციფრებს და ზოგიერთ პუნქტუაციის ნიშანს (_,-) შეიძლება შეიცავდეს."
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Pod name": [
  null,
  "Pod-ის სახელი"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "User:": [
  null,
  "მომხმარებელი:"
 ],
 "No ports exposed": [
  null,
  "პორტები გამოტანილი არაა"
 ],
 "Port mapping": [
  null,
  "პორტების ასახვა"
 ],
 "Add port mapping": [
  null,
  "პორტის ასახვის დამატება"
 ],
 "No volumes specified": [
  null,
  "საცავი მითითებული არაა"
 ],
 "Volumes": [
  null,
  "საცავები"
 ],
 "Add volume": [
  null,
  "საცავის დამატება"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Type to filter…": [
  null,
  "გაფილტვრისთვის აკრიფეთ…"
 ],
 "Container path must not be empty": [
  null,
  "კონტეინერის ბილიკი არ შეიძლება ცარიელი იყოს"
 ],
 "Host path": [
  null,
  "ჰოსტის ბილიკი"
 ],
 "Container path": [
  null,
  "კონტეინერის ბილიკი"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Writable": [
  null,
  "ჩაწერადი"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "ჭდეების გარეშე"
 ],
 "Shared": [
  null,
  "გაზიარებული"
 ],
 "Private": [
  null,
  "პირადი"
 ],
 "Read-write access": [
  null,
  "ჩაწერა/წაკითხვის წვდომა"
 ],
 "Read-only access": [
  null,
  "მხოლოდ-კითხვის წვდომა"
 ],
 "Show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "Show more": [
  null,
  "მეტის ჩვენება"
 ],
 "Loading details...": [
  null,
  "დეტალების ჩატვირთვა..."
 ],
 "Ports": [
  null,
  "პორტები"
 ],
 "Environment variables": [
  null,
  "გარემოს ცვლადები"
 ],
 "Failed to download image $0:$1": [
  null,
  "გამოსახულების ($0) გადმოწერის შეცდომა: $1"
 ],
 "Error message": [
  null,
  "შეცდომის შეტყობინება"
 ],
 "unused": [
  null,
  "გამოუყენებელი"
 ],
 "$0 container": [
  null,
  "$0 ცალი კონტეინერი",
  "$0 კონტეინერი"
 ],
 "History": [
  null,
  "ისტორია"
 ],
 "Image": [
  null,
  "გამოსახულება"
 ],
 "Created": [
  null,
  "შექმნილია"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "ადგილი დისკზე"
 ],
 "Used by": [
  null,
  "გამოიყენება"
 ],
 "No images": [
  null,
  "გამოსახულებების გარეშე"
 ],
 "No images that match the current filter": [
  null,
  "მიმდინარე ფილტრს არცერთი გამოსახულება არ შეესაბამება"
 ],
 "Hide intermediate images": [
  null,
  "შუალედური გამოსახულებების დამალვა"
 ],
 "Show intermediate images": [
  null,
  "შუალედური გამოსახულებების ჩვენება"
 ],
 "Images": [
  null,
  "გამოსახულებები"
 ],
 "$0 image total, $1": [
  null,
  "$0 ცალი გამოსახულება, $1",
  "$0 გამოსახულება, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 ცალი გამოუყენებელი გამოსახულება, $1",
  "$0 გამოუყენებელი გამოსახულება, $1"
 ],
 "Hide images": [
  null,
  "გამოსახულებების დამალვა"
 ],
 "Show images": [
  null,
  "გამოსახულებების ჩვენება"
 ],
 "Pulling": [
  null,
  "გამოწევა"
 ],
 "Download new image": [
  null,
  "ახალი გამოსახულების გადმოწერა"
 ],
 "Pull all images": [
  null,
  "ყველა დისკის ასლის პული"
 ],
 "Prune unused images": [
  null,
  "გამოუყენებელი გამოსახულებების წაკვეთა"
 ],
 "Pull": [
  null,
  "გამოწევა"
 ],
 "Up since:": [
  null,
  "აქტიურია საიდან:"
 ],
 "Exited": [
  null,
  "გამოსული"
 ],
 "systemd service": [
  null,
  "systemd-ის სერვისი"
 ],
 "View $0": [
  null,
  "$0-ის ნახვა"
 ],
 "Gateway": [
  null,
  "ნაგულისხმები რაუტერი"
 ],
 "MAC address": [
  null,
  "MAC მისამართი"
 ],
 "Latest checkpoint": [
  null,
  "უახლესი საკონტროლო წერტილი"
 ],
 "No containers are using this image": [
  null,
  "ამ გამოსახულებას არცერთი კონტეინერი არ იყენებს"
 ],
 "Running": [
  null,
  "გაშვებულია"
 ],
 "Loading logs...": [
  null,
  "ჟურნალის ჩატვირთვა..."
 ],
 "Delete unused system images:": [
  null,
  "სისტემის გამოუყენებელი გამოსახულებების წაშლა:"
 ],
 "Delete unused images of user $0:": [
  null,
  "გამოუყენებელი ასლის ფაილების წაშლა მომხმარებლისთვის $0:"
 ],
 "Failed to prune unused images": [
  null,
  "გამოუყენებელი გამოსახულებების წაკვეთის შეცდომა"
 ],
 "Pruning images": [
  null,
  "გამოსახულებების წაკვეთა"
 ],
 "Prune": [
  null,
  "შეკვეცა"
 ],
 "Failed to checkpoint container $0": [
  null,
  "კონტეინერის ($0) საკონტროლო წერტილის შეცდომა"
 ],
 "Checkpoint container $0": [
  null,
  "საკონტროლო წერტილის კონტეინერი ($0)"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "საკონტროლო წერტილის დისკზე ჩაწერის შემდეგ გაშვებულად დატოვება"
 ],
 "Support preserving established TCP connections": [
  null,
  "დამყარებული TCP კავშირების შენარჩუნების მხარდაჭერა"
 ],
 "Failed to search for new images": [
  null,
  "ახალი გამოსახულებების ძებნის შეცდომა"
 ],
 "Failed to search for images: $0": [
  null,
  "გამოსახულების ძებნის შეცდომა: $0"
 ],
 "Failed to search for images.": [
  null,
  "გამოსახულებების ძებნის შეცდომა."
 ],
 "Search for an image": [
  null,
  "გამოსახულების ძებნა"
 ],
 "Search for": [
  null,
  "ძებნა"
 ],
 "Search by name or description": [
  null,
  "სახელით ან აღწერით ძებნა"
 ],
 "in": [
  null,
  "-ში"
 ],
 "All registries": [
  null,
  "ყველა რეგისტრები"
 ],
 "Searching...": [
  null,
  "ძებნა..."
 ],
 "No images found": [
  null,
  "გამოსახულებების გარეშე"
 ],
 "Start typing to look for images.": [
  null,
  "გამოსახულებების მოსაძებნად დაიწყეთ მისი სახელის კრეფა."
 ],
 "No results for $0": [
  null,
  "პასუხების გარეშე $0-თვის"
 ],
 "Retry another term.": [
  null,
  "სხვა სიტყვა სცადეთ."
 ],
 "Download": [
  null,
  "გადმოწერა"
 ],
 "No action": [
  null,
  "ქმედების გარეშე"
 ],
 "Container failed to be started": [
  null,
  "კონტეინერის გაშვების შეცდომა"
 ],
 "Failed to clean up container": [
  null,
  "კონტეინერის გასუფთავების შეცდომა"
 ],
 "Container failed to be created": [
  null,
  "კონტეინერის შექმნის შეცდომა"
 ],
 "downloading": [
  null,
  "გადმოწერა"
 ],
 "Failed to run container $0": [
  null,
  "კონტეინერის ($0) გაშვების შეცდომა"
 ],
 "Failed to create container $0": [
  null,
  "კონტეინერის ($0) შექმნის შეცდომა"
 ],
 "Failed to pull image $0": [
  null,
  "გამოსახულების ($0) გამოთხოვნის შეცდომა"
 ],
 "Local images": [
  null,
  "ლოკალური გამოსახულებები"
 ],
 "Name already in use": [
  null,
  "სახელი უკვე გამოიყენება"
 ],
 "Search by registry": [
  null,
  "რეგისტრის ძებნა"
 ],
 "Local": [
  null,
  "ლოკალური"
 ],
 "Container name": [
  null,
  "კონტეინერის სახელი"
 ],
 "Owner help": [
  null,
  "მფლობელის დახმარება"
 ],
 "Ideal for running services": [
  null,
  "იდეალურია სერვისების გასაშვებად"
 ],
 "Resource limits can be set": [
  null,
  "შეგიძლიათ ლიმიტების დაყენება"
 ],
 "Checkpoint and restore support": [
  null,
  "საკონტროლო წერტილის და აღდგენის მხარდაჭერა"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "შეგიძლიათ 1024-ზე ნაკლები ნომრის მქონე პორტის მიბმა"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Ideal for development": [
  null,
  "იდეალურია პროგრამირებისთვის"
 ],
 "Restricted by user account permissions": [
  null,
  "შეზღუდულია მომხმარებლის ანგარიშის წვდომებით"
 ],
 "Image selection help": [
  null,
  "დახმარება გამოსახულების არჩევის შესახებ"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "ჰოსტი[:პორტი]/[მომხმარებელი]/კონტეინერი[:ჭდე]"
 ],
 "Example: $0": [
  null,
  "მაგალითად: $0"
 ],
 "Searching: $0": [
  null,
  "ძებნა: $0"
 ],
 "Search string or container location": [
  null,
  "სტრიქონის ან კონტეინერის მდებარეობის ძებნა"
 ],
 "Pull latest image": [
  null,
  "უახლესი გამოსახულების წამოღება"
 ],
 "Entrypoint": [
  null,
  "შესავალი წერტილი"
 ],
 "With terminal": [
  null,
  "ტერმინალით"
 ],
 "Memory limit": [
  null,
  "მეხსიერების ლიმიტი"
 ],
 "Decrease memory": [
  null,
  "მეხსიერების შემცირება"
 ],
 "Increase memory": [
  null,
  "მეხსიერების გაზრდა"
 ],
 "Memory unit": [
  null,
  "მეხსიერების ერთეული"
 ],
 "KB": [
  null,
  "კბ"
 ],
 "MB": [
  null,
  "მბ"
 ],
 "GB": [
  null,
  "გბ"
 ],
 "CPU shares": [
  null,
  "CPU გაზიარება"
 ],
 "CPU Shares help": [
  null,
  "პროცესორის გაზიარების დახმარება"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-ის ზიარები განსაზღვრავენ გაშვებულიკონტეინერების პრიორიტეტს. ნაგულისხმები პრიორიტეტი 1024-ის ტოლია. რაც მეტია რიცხვი, მით მეტია პრიორიტეტი; რაც ნაკლები -ნაკლები."
 ],
 "Decrease CPU shares": [
  null,
  "CPU გაზიარებების შემცირება"
 ],
 "Increase CPU shares": [
  null,
  "CPU გაზიარებების გაზრდა"
 ],
 "Restart policy": [
  null,
  "რესტარტის წესები"
 ],
 "Restart policy help": [
  null,
  "დახმარება რესტარტის წესების შესახებ"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "კონტეინერების მუშაობის დასრულებისას მისაყოლი გადატვირთის პოლიტიკა. კონტეინერების ავტომატური გაშვებისთვის linger-მა ყოველთვის შეიძლება არ იმუშაოს. მაგალითად, თუ მომხმარებელზე enccryptfs, systemd-homed, NFS ან 2FA გამოიყენება."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "კონტეინერების მუშაობის დასასრულისას რესტარტის წესები."
 ],
 "No": [
  null,
  "არა"
 ],
 "On failure": [
  null,
  "შეცდომისას"
 ],
 "Always": [
  null,
  "ყველთვის"
 ],
 "Maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობა"
 ],
 "Decrease maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობის შემცირება"
 ],
 "Increase maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობის გაზრდა"
 ],
 "No environment variables specified": [
  null,
  "გარემოს ცვლადი მითითებული არაა"
 ],
 "Add variable": [
  null,
  "ცვლადის დამატება"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "მრავალი შემოტანისთვის ველებში ჩასვით ერთი ან მეტი გასაღები=მნიშვნელობა-ის ტიპის წყვილები"
 ],
 "Interval": [
  null,
  "ინტერვალი"
 ],
 "Health check interval help": [
  null,
  "ჯანმრთელობის შემოწმების ინტერვალის დახმარება"
 ],
 "Interval how often health check is run.": [
  null,
  "ჯანმრთელობის შემოწმების გაშვების ინტერვალი."
 ],
 "Decrease interval": [
  null,
  "ინტერვალის შემცირება"
 ],
 "Increase interval": [
  null,
  "ინტერვალის გაზრდა"
 ],
 "seconds": [
  null,
  "წამი"
 ],
 "Timeout": [
  null,
  "დროის ამოწურვა"
 ],
 "Health check timeout help": [
  null,
  "ჯანმრთელობის შემოწმების ვადის დახმარება"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "მაქსიმალური დრო ჯანმრთელობის შესამოწმებლად. ამ ინტერვალის გასვლის შემდეგ შემოწმება შეცდომის მქონედ ითვლება."
 ],
 "Decrease timeout": [
  null,
  "მოლოდინის დროის შემცირება"
 ],
 "Increase timeout": [
  null,
  "მოლოდინის დროის გაზრდა"
 ],
 "Start period": [
  null,
  "გაშვების პერიოდი"
 ],
 "Health check start period help": [
  null,
  "ჯანმრთელობის შემოწმების გაშვების პერიოდის დახმარება"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "კონტეინერის მოსარგებად საჭირო ინიციალიზაციის დრო."
 ],
 "Decrease start period": [
  null,
  "გაშვების პერიოდის შემცირება"
 ],
 "Increase start period": [
  null,
  "გაშვების პერიოდის გაზრდა"
 ],
 "Retries": [
  null,
  "თავიდან ცდები"
 ],
 "Health check retries help": [
  null,
  "ჯანმრთელობის შემოწმების ცდების რაოდენობის დახმარება"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "ცდების რაოდენობა, რის შემდეგაც ჯანმრთელობის შემოწმება ავარიულად ითვლება."
 ],
 "Decrease retries": [
  null,
  "ცდების რაოდენობის შემცირება"
 ],
 "Increase retries": [
  null,
  "ცდების რაოდენობის გაზრდა"
 ],
 "When unhealthy": [
  null,
  "როცა ჯანმრთელი არაა"
 ],
 "Health failure check action help": [
  null,
  "ჯანმრთელობის შემოწმების ქმედების დახმარება"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "ქმედება, რომელიც კონტეინერის არაჯანმრთელ მდომარეობაში გადასვლისას შესრულდება."
 ],
 "Create container in $0": [
  null,
  "$0-ში კონტეინერის შექმნა"
 ],
 "Create and run": [
  null,
  "შექმნა და გაშვება"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "Links": [
  null,
  "ბმულები"
 ],
 "Documentation": [
  null,
  "დოკუმენტაცია"
 ],
 "Tags": [
  null,
  "ჭდეები"
 ],
 "Created by": [
  null,
  "ავტორი"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Comments": [
  null,
  "კომენტარები"
 ],
 "Unable to load image history": [
  null,
  "გამოსახულების ისტორიის ჩატვირთვის შეცდომა"
 ],
 "Key must not be empty": [
  null,
  "გასაღები არ შეიძლება, ცარიელი იყოს"
 ],
 "Key must not begin with a digit": [
  null,
  "გასაღები ციფრით არ უნდა იწყებოდეს"
 ],
 "Key contains invalid characters": [
  null,
  "გასაღები არასწორ სიმბოლოებს შეიცავს"
 ],
 "Key": [
  null,
  "გასაღები"
 ],
 "Value": [
  null,
  "მნიშვნელობა"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "Podman service failed": [
  null,
  "Podman-ის სერვისი ჩავარდა"
 ],
 "Troubleshoot": [
  null,
  "პრობლემების პოვნა"
 ],
 "Failed to force remove image $0": [
  null,
  "გამოსახულების ($0) ძალით წაშლა შეუძლებელია"
 ],
 "intermediate image": [
  null,
  "შუალედური დისკის ასლი"
 ],
 "Failed to remove image $0": [
  null,
  "გამოსახულების ($0) წაშლის შეცდომა"
 ],
 "intermediate": [
  null,
  "შუალედური"
 ],
 "Delete $0 image?": [
  null,
  "წავშალო $0 დისკის ასლი?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "ამ გამოსახულებას მრავალი ჭდე გააჩნია. წასაშლელად მონიშნეთ ჭდეებიანი გამოსახულებები."
 ],
 "Delete image": [
  null,
  "დისკის ასლის წაშლა"
 ],
 "Delete tagged images": [
  null,
  "ჭდეებიანი გამოსახულებების წაშლა"
 ],
 "Container is not running": [
  null,
  "კონტეინერი გაშვებული არაა"
 ],
 "Error occurred while connecting console": [
  null,
  "კონსოლთან დაკავშირების შეცდომა"
 ],
 "Force delete pod $0?": [
  null,
  "წავშლო ძალით პოდი $0?"
 ],
 "Delete pod $0?": [
  null,
  "წავშალო პოდი $0?"
 ],
 "An error occurred": [
  null,
  "აღმოჩენილია შეცდომა"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "ცარიელი პოდი $0 სამუდამოდ წაიშლება."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "ამ Pod-ის წაშლა ასევე წაშლის შემდეგ კონტეინერებს:"
 ],
 "Failed to start pod $0": [
  null,
  "pod-ს ($0) გაშვების შეცდომა"
 ],
 "Failed to stop pod $0": [
  null,
  "pod-ის ($0) გაჩერების შეცდომა"
 ],
 "Failed to restart pod $0": [
  null,
  "Pod-ის ($0) რესტარტის შეცდომა"
 ],
 "Failed to resume pod $0": [
  null,
  "Pod-ის ($0) გაგრძელების შეცდომა"
 ],
 "Failed to pause pod $0": [
  null,
  "Pod-ის ($0) შეჩერების შეცდომა"
 ],
 "Failed to prune unused containers": [
  null,
  "გამოუყენებელი კონტეინერების წაკვეთის შეცდომა"
 ],
 "Removes selected non-running containers": [
  null,
  "მონიშნული არა-გაშვებული კონტეინერების წაშლა"
 ],
 "Pruning containers": [
  null,
  "კონტეინერების წაკვეთა"
 ],
 "Container name is required.": [
  null,
  "კონტეინერის სახელი აუცილებელია."
 ],
 "Failed to rename container $0": [
  null,
  "კონტეინერის ($0) სახელის გადარქმევის შეცდომა"
 ],
 "New container name": [
  null,
  "ახალი კონტეინერის სახელი"
 ],
 "Rename container $0": [
  null,
  "კონტეინერის სახელის გადარქმევა ($0)"
 ],
 "Paused": [
  null,
  "შეჩერებულია"
 ],
 "Stopped": [
  null,
  "გაჩერებულია"
 ],
 "Removing": [
  null,
  "წაშლა"
 ],
 "Configured": [
  null,
  "მორგებულია"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "$0 second": [
  null,
  "$0 წამი",
  "$0 წამი"
 ],
 "Status": [
  null,
  "სტატუსი"
 ],
 "Failing streak": [
  null,
  "მრავალჯერადი წარუმატებლობა"
 ],
 "Failed to run health check on container $0": [
  null,
  "კონტეინერის ($0) ჯანმრთელობის შემოწმების შეცდომა"
 ],
 "Run health check": [
  null,
  "ჯანმრთელობის შემოწმების გაშვება"
 ],
 "Last 5 runs": [
  null,
  "ბოლო 5 გაშვება"
 ],
 "Started at": [
  null,
  "გაშვების დრო"
 ],
 "Passed health run": [
  null,
  "ჯანმრთელობის შემოწმება წარმატებულია"
 ],
 "Failed health run": [
  null,
  "ჯანმრთელობის შემოწმების შეცდომა"
 ],
 "Failed to remove container $0": [
  null,
  "კონტეინერის ($0) წაშლის შეცდომა"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "კონტეინერის წაშლა მასში ყველა მონაცემს წაშლის."
 ]
});
