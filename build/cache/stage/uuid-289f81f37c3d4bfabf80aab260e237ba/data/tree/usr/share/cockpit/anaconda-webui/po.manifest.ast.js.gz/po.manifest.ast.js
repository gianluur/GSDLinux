cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ast",
  "language-direction": "ltr"
 }
});
