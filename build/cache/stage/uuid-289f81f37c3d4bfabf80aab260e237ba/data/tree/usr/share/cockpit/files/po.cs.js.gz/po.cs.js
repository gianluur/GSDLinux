cockpit.locale({
 "": {
  "plural-forms": ((n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2),
  "language": "cs",
  "language-direction": "ltr"
 },
 "Cockpit Files": [
  null,
  "Cockpit Soubory"
 ],
 "Home": [
  null,
  "Domovská složka"
 ],
 "Unable to create bookmark directory": [
  null,
  "Nepodařilo se vytvořit složku záložek"
 ],
 "Unable to save bookmark file": [
  null,
  "Nepodařilo se uložit soubor se záložkami"
 ],
 "Remove from bookmarks": [
  null,
  "Odstranit ze záložek"
 ],
 "Add to bookmarks": [
  null,
  "Přidat do záložek"
 ],
 "Bookmarks": [
  null,
  "Záložky"
 ],
 "Bookmarked": [
  null,
  "Přidáno do záložek"
 ],
 "Not bookmarked": [
  null,
  "Nepřidáno do záložek"
 ],
 "Filesystem": [
  null,
  "Souborový systém"
 ],
 "Edit path": [
  null,
  "Upravit popis umístění"
 ],
 "Name": [
  null,
  "Název"
 ],
 "A-Z": [
  null,
  "A-Z"
 ],
 "Z-A": [
  null,
  "Z-A"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Largest size": [
  null,
  "Největší velikost"
 ],
 "Smallest size": [
  null,
  "Nejnižší velikost"
 ],
 "Modified": [
  null,
  "Změněno"
 ],
 "First modified": [
  null,
  "Poprvé upraveno"
 ],
 "Last modified": [
  null,
  "Naposledy změněno"
 ],
 "Owner": [
  null,
  "Vlastník"
 ],
 "Owner ascending": [
  null,
  "Podle vlastníka vzestupně"
 ],
 "Owner descending": [
  null,
  "Podle vlastníka sestupně"
 ],
 "Permissions": [
  null,
  "Oprávnění"
 ],
 "Most permissive": [
  null,
  "Nejpřístupnější"
 ],
 "Least permissive": [
  null,
  "Nejméně přístupné"
 ],
 "Show keyboard shortcuts": [
  null,
  "Zobrazit klávesové zkratky"
 ],
 "Filter directory": [
  null,
  "Filtrovat složku"
 ],
 "Display as a list": [
  null,
  "Zobrazit jako seznam"
 ],
 "Display as a grid": [
  null,
  "Zobrazit jako mřížku"
 ],
 "Sort": [
  null,
  "Seřadit"
 ],
 "Hide hidden items": [
  null,
  "Skrýt skryté položky"
 ],
 "Show hidden items": [
  null,
  "Zobrazit skryté položky"
 ],
 "$0 files": [
  null,
  "$0 souborů"
 ],
 "Uploaded as $0, $1": [
  null,
  "Nahráno jako $0,$1"
 ],
 "Replace file $0?": [
  null,
  "Nahradit soubor $0?"
 ],
 "A file with the same name already exists in \"$0\". Replacing it will overwrite its content.": [
  null,
  "Stejně nazvaný soubor už v „$0“ existuje. Nahrazením bude jeho obsah přepsán."
 ],
 "New file": [
  null,
  "Nový soubor"
 ],
 "Original file on server": [
  null,
  "Původní soubor na serveru"
 ],
 "Apply this action to all conflicting files": [
  null,
  "Použít tuto akci na veškeré kolidující soubory"
 ],
 "Replace": [
  null,
  "Nahradit"
 ],
 "Keep original": [
  null,
  "Ponechat původní"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Failed": [
  null,
  "Nezdařilo se"
 ],
 "Upload error": [
  null,
  "Chyba nahrávání"
 ],
 "Unable to move uploaded file to final destination": [
  null,
  "Nebylo možné přesunout nahrané soubory do konečného umístění"
 ],
 "Cancelled": [
  null,
  "Zrušeno"
 ],
 "Cancelled upload of $0": [
  null,
  "Zrušeno nahrávání $0"
 ],
 "File uploaded": [
  null,
  "Soubor nahrán"
 ],
 "Files uploaded": [
  null,
  "Soubory nahrány"
 ],
 "Change permissions": [
  null,
  "Změnit oprávnění"
 ],
 "Uploads": [
  null,
  "Nahrání"
 ],
 "Cancel upload of $0": [
  null,
  "Zrušit nahrávání $0"
 ],
 "Upload $0% completed": [
  null,
  "Nahrávání z $0% dokončeno"
 ],
 "Upload": [
  null,
  "Nahrát"
 ],
 "None": [
  null,
  "Žádné"
 ],
 "Execute-only": [
  null,
  "Pouze spouštět"
 ],
 "Write-only": [
  null,
  "Pouze zápis"
 ],
 "Write and execute": [
  null,
  "Zápis a spouštění"
 ],
 "Read-only": [
  null,
  "Pouze pro čtení"
 ],
 "Read and execute": [
  null,
  "Číst a spouštět"
 ],
 "Read and write": [
  null,
  "Číst a zapisovat"
 ],
 "Read, write, and execute": [
  null,
  "Číst, zapisovat a spouštět"
 ],
 "Block device": [
  null,
  "Blokové zařízení"
 ],
 "Character device": [
  null,
  "Znakové zařízení"
 ],
 "Directory": [
  null,
  "Složka"
 ],
 "Named pipe": [
  null,
  "Pojmenovaná roura"
 ],
 "Symbolic link": [
  null,
  "Symbolický odkaz"
 ],
 "Regular file": [
  null,
  "Obyčejný soubor"
 ],
 "Socket": [
  null,
  "Soket"
 ],
 "Name cannot be empty": [
  null,
  "Název je třeba vyplnit"
 ],
 "Name too long": [
  null,
  "Název je příliš dlouhý"
 ],
 "Name cannot include a /": [
  null,
  "Název nemůže obsahovat /"
 ],
 "Filename is the same as original name": [
  null,
  "Tento název souboru je stejný jako ten předchozí"
 ],
 "Directory with the same name exists": [
  null,
  "Složka s tímto názvem zde už existuje"
 ],
 "File exists": [
  null,
  "Soubor existuje"
 ],
 "Pasting failed": [
  null,
  "Vkládání se nezdařilo"
 ],
 "\"$0\" exists, not overwriting with paste.": [
  null,
  "„$0“ existuje – vložením nebude přepsáno."
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Create directory": [
  null,
  "Vytvořit složku"
 ],
 "Create file": [
  null,
  "Vytvořit soubor"
 ],
 "Edit permissions": [
  null,
  "Upravit oprávnění"
 ],
 "Open in terminal": [
  null,
  "Otevřít v terminálu"
 ],
 "Open text file": [
  null,
  "Otevřít textový soubor"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Download": [
  null,
  "Stáhnout"
 ],
 "Create link": [
  null,
  "Vytvořit odkaz"
 ],
 "Drop files to upload": [
  null,
  "Soubory nahrajete jejich přetažením sem"
 ],
 "Cannot drop files, another upload is already in progress": [
  null,
  "Není možné přetáhnout soubory – v tuto chvíli probíhá ještě jiné nahrání"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Go up a directory": [
  null,
  "Do nadřazené složky"
 ],
 "Go back": [
  null,
  "Přejít zpět"
 ],
 "Go forward": [
  null,
  "Přejít vpřed"
 ],
 "Activate selected item, enter directory": [
  null,
  "Aktivovat označenou položku, vstoupit do složky"
 ],
 "Rename selected file or directory": [
  null,
  "Přejmenovat označený soubor či složku"
 ],
 "Create new directory": [
  null,
  "Vytvořit novou složku"
 ],
 "Copy selected file or directory": [
  null,
  "Zkopírovat označený soubor či složku"
 ],
 "Paste file or directory": [
  null,
  "Vložit soubor nebo složku"
 ],
 "Select all": [
  null,
  "Vybrat vše"
 ],
 "Save current file": [
  null,
  "Odebrat stávající soubor"
 ],
 "Close editor": [
  null,
  "Zavřít editor"
 ],
 "Keyboard shortcuts": [
  null,
  "Klávesové zkratky"
 ],
 "Navigation": [
  null,
  "Navigace"
 ],
 "Editing": [
  null,
  "Upravování"
 ],
 "Editor": [
  null,
  "Editor"
 ],
 "Force delete $0 items": [
  null,
  "Vynutit smazání $0 položek"
 ],
 "Delete $0 items?": [
  null,
  "Smazat $0 položek?"
 ],
 "Force delete file $0?": [
  null,
  "Vynutit smazání souboru $0?"
 ],
 "Delete file $0?": [
  null,
  "Smazat soubor $0?"
 ],
 "Force delete link $0?": [
  null,
  "Vynutit smazání odkazu $0?"
 ],
 "Delete link $0?": [
  null,
  "Smazat odkaz $0?"
 ],
 "Force delete directory $0?": [
  null,
  "Vynutit smazání složky $0?"
 ],
 "Delete directory $0?": [
  null,
  "Smazat složku $0?"
 ],
 "Force delete $0": [
  null,
  "Vynutit smazání $0"
 ],
 "Delete $0?": [
  null,
  "Smazat $0?"
 ],
 "No access": [
  null,
  "Žádný přístup"
 ],
 "Missing type": [
  null,
  "Chybí typ"
 ],
 "Collapse": [
  null,
  "Sbalit"
 ],
 "Show all files": [
  null,
  "Zobrazit veškeré soubory"
 ],
 "$0 permissions": [
  null,
  "oprávnění $0"
 ],
 "Permissions for $0 files": [
  null,
  "Oprávnění pro $0 souborů"
 ],
 "Ownership": [
  null,
  "Vlastnictví"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Access": [
  null,
  "Přístup"
 ],
 "Owner access": [
  null,
  "Přístup pro vlastníka"
 ],
 "Group access": [
  null,
  "Přístup pro skupinu"
 ],
 "Others access": [
  null,
  "Přístup pro ostatní"
 ],
 "Security context": [
  null,
  "Kontext zabezpečení"
 ],
 "Set executable as program": [
  null,
  "Nastavit spustitelné jako program"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change permissions for enclosed files": [
  null,
  "Změnit oprávnění pro obsažené soubory"
 ],
 "(original owner)": [
  null,
  "(původní vlastník)"
 ],
 "keep original owners": [
  null,
  "Ponechat původní vlastníky"
 ],
 "Paste as owner": [
  null,
  "Vložit jako vlastník"
 ],
 "Files being pasted have a different owner. By default, ownership will be changed to match the destination directory.": [
  null,
  "Vkládané soubory mají jiného vlastníka. Ve výchozím stavu bude vlastnictví změněno tak, aby odpovídalo cílové složce."
 ],
 "New owner": [
  null,
  "Nový vlastník"
 ],
 "Overwrite": [
  null,
  "Přepsat"
 ],
 "New filename": [
  null,
  "Nový název souboru"
 ],
 "New name": [
  null,
  "Nový název"
 ],
 "Rename $0?": [
  null,
  "Přejmenovat $0?"
 ],
 "link to $0": [
  null,
  "odkazovat na $0"
 ],
 "Create link to $0": [
  null,
  "Vytvořit odkaz na $0"
 ],
 "Target": [
  null,
  "Cíl"
 ],
 "Symlink name": [
  null,
  "Název symbolického odkazu"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Absolute vs. Relative": [
  null,
  "Absolutní oproti relativním"
 ],
 "Absolute symlinks are ideal when referring to files or directories that won't move, such as system files.": [
  null,
  "Absolutní symbolické odkazy se hodí při odkazování se na soubory či složky, které nejsou přesouvány, jako například systémové soubory."
 ],
 "Relative symlinks are useful when both a symlink and target might move at the same time, such as when renaming or moving a parent directory.": [
  null,
  "Relativní symbolické odkazy se hodí v případech, kdy je možné, že jak odkaz, tak jeho cíl budou společně přesunuty, jako například při přejmenování nebo přesunu jim nadřazené složky."
 ],
 "Absolute": [
  null,
  "Absolutní"
 ],
 "Relative": [
  null,
  "Relativní"
 ],
 "The file has been removed on disk": [
  null,
  "Soubor byl odebrán z úložiště"
 ],
 "The existing file changed unexpectedly": [
  null,
  "Existující soubor byl mezitím neočekávaně změněn"
 ],
 "Edit $0": [
  null,
  "Upravit $0"
 ],
 "View $0": [
  null,
  "Zobrazit $0"
 ],
 "The file has changed on disk": [
  null,
  "Soubor byl na úložišti změněn"
 ],
 "Reload": [
  null,
  "Načíst znovu"
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save changes?": [
  null,
  "Uložit změny?"
 ],
 "The file was deleted after it was opened, saving will recreate it.": [
  null,
  "Zatímco jste měli soubor otevřený zde, něco jiného ho mezitím vymazalo z disku – pokud uložíte, bude znovu vytvořen."
 ],
 "The file has changed on disk between when it was opened and now": [
  null,
  "Zatímco jste měli soubor otevřený zde, něco jiného ho mezitím změnilo na disku"
 ],
 "$0 has unsaved changes and which will be permanently lost if discarded.": [
  null,
  "$0 má neuložené změny a ty budou v případě zahození nevratně ztraceny."
 ],
 "Discard": [
  null,
  "Zahodit"
 ],
 "File name": [
  null,
  "Název souboru"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Cannot create file in current directory": [
  null,
  "Ve stávající složce není možné soubor vytvořit"
 ],
 "Permission denied": [
  null,
  "Přístup zamítnut"
 ],
 "Directory name cannot be empty": [
  null,
  "Složku je třeba nějak nazvat"
 ],
 "Directory name too long": [
  null,
  "Název složky je příliš dlouhý"
 ],
 "Directory name cannot include a /": [
  null,
  "Název složky nemůže obsahovat /"
 ],
 "Directory name": [
  null,
  "Název složky"
 ],
 "Directory owner": [
  null,
  "Vlastník složky"
 ],
 "No matching results": [
  null,
  "Nic nenalezeno"
 ],
 "Clear filter": [
  null,
  "Vyčistit filtr"
 ],
 "Directory is empty": [
  null,
  "Složka je prázdná"
 ],
 "$0 item is hidden": [
  null,
  "$0 položka je skrytá",
  "$0 položky jsou skryté",
  "$0 položek je skrytých"
 ],
 "Folder": [
  null,
  "Složka"
 ],
 "File": [
  null,
  "Soubor"
 ],
 "Others": [
  null,
  "Ostatní"
 ],
 "$0 files selected": [
  null,
  "$0 souborů vybráno"
 ],
 "Directory contains $0 directories, $1 files": [
  null,
  "Složka obsahuje $0 podsložek, $1 souborů"
 ],
 "Directory contains $0 directories, $1 files, $2 hidden": [
  null,
  "Složka obsahuje $0 podsložek, $1 souborů, $2 skrytých"
 ],
 "User": [
  null,
  "Uživatel"
 ]
});
