cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "ja",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "サービス"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "インターフェース"
 ],
 "bridge": [
  null,
  "ブリッジ"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "bond": [
  null,
  "ボンディング"
 ],
 "team": [
  null,
  "チーム"
 ],
 "port": [
  null,
  "ポート"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "firewall": [
  null,
  "ファイアウォール"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "ゾーン"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "udp": [
  null,
  "udp"
 ],
 "Managing networking bonds": [
  null,
  "ネットワークボンディングの管理"
 ],
 "Managing networking teams": [
  null,
  "ネットワークチームの管理"
 ],
 "Managing networking bridges": [
  null,
  "ネットワークブリッジの管理"
 ],
 "Managing VLANs": [
  null,
  "VLAN の管理"
 ],
 "Managing firewall": [
  null,
  "ファイアウォール管理"
 ]
});
