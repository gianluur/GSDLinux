cockpit.locale({
 "": {
  "plural-forms": ((n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5),
  "language": "ar",
  "language-direction": "rtl"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Server": [
  null,
  "خادم"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Firewall": [
  null,
  "الجدار النّاري"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Public key": [
  null,
  "مفتاح عام"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Select": [
  null,
  "تحديد"
 ],
 "Unexpected error": [
  null,
  "خطأ غير متوقع"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "Connect": [
  null,
  "اتصال"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "Disconnected": [
  null,
  "مفصول"
 ],
 "Permission denied": [
  null,
  "الإذن مرفوض"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "You now have administrative access.": [
  null,
  "لديك الآن حق الوصول الإداري."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "الرجاء المصادقة للحصول على صلاحيات إدارية"
 ],
 "Switch to administrative access": [
  null,
  "التبديل إلى الوصول الإداري"
 ],
 "Authenticate": [
  null,
  "مصادقة"
 ],
 "Administrative access": [
  null,
  "صلاحيات المسؤول"
 ],
 "Problem becoming administrator": [
  null,
  "مشكلة في الحصول على صلاحيات المسؤول"
 ],
 "Method": [
  null,
  "الطريقة"
 ],
 "Limit access": [
  null,
  "تقييد الوصول"
 ],
 "Switch to limited access": [
  null,
  "التبديل إلى الوصول محدود الصلاحيات"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "يُقيّد وضع الوصول المقيد الصلاحيات الإدارية. ستكون بعض أجزاء لوحة التحكم عبر الويب محدودة الوظائف."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "سيتذكر متصفحك مستوى وصولك عبر الجلسات."
 ],
 "Limited access": [
  null,
  "وصول مقيَّد"
 ],
 "Turn on administrative access": [
  null,
  "فعّل الوصول الإداري"
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "PackageKit reported error code $0": [
  null,
  "أبلغت PackageKit عن رمز الخطأ $0"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "نوع عامل التصفية"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Show hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Shell script": [
  null,
  "سكريبت الصدفة"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Priority": [
  null,
  "الأولوية"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "Enabled": [
  null,
  "مُفعَّل"
 ],
 "Disabled": [
  null,
  "معطّل"
 ],
 "Generated": [
  null,
  "تم توليده"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Start service": [
  null,
  "بدء الخدمة"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Delete $0": [
  null,
  "حذف $0"
 ],
 "Group": [
  null,
  "مجموعة"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Not available": [
  null,
  "غير متوفر"
 ],
 "Ignore": [
  null,
  "تجاهل"
 ],
 "Permanent": [
  null,
  "دائم"
 ],
 "Preserve": [
  null,
  "احمِ"
 ],
 "Random": [
  null,
  "عشوائي"
 ],
 "Stable": [
  null,
  "مستقر"
 ],
 "Use $0": [
  null,
  "اشتخدم $0"
 ],
 "Failed to save settings": [
  null,
  "فشل في حفظ الإعدادات"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي إنشاء هذا $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Create it": [
  null,
  "قم بإنشائه"
 ],
 "Invalid prefix $0": [
  null,
  "بادئة غير صحيحة $0"
 ],
 "Invalid metric $0": [
  null,
  "مقياس غير صالح $0"
 ],
 "Invalid address $0": [
  null,
  "عنوان غير صالح $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "بادئة أو غطاء شبكة غير صالح $0"
 ],
 "Testing connection": [
  null,
  "فحص الاتصال"
 ],
 "Restoring connection": [
  null,
  "إعادة تخزين الاتصال"
 ],
 "Troubleshoot…": [
  null,
  "استكشاف الأخطاء وإصلاحها…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager لا يعمل"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ليس مثبتاً"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "تتطلب أجهزة الشبكة والرسوم البيانية خدمة NetworkManager"
 ],
 "Enable service": [
  null,
  "تفعيل الخدمة"
 ],
 "Network interface '$0' not found": [
  null,
  ""
 ],
 "Return to overview page": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "أنت غير مخول بتعديل جدار الحماية."
 ],
 "Not authorized to disable the firewall": [
  null,
  "غير مصرَّح بتعطيل جدار الحماية"
 ],
 "Not authorized to enable the firewall": [
  null,
  "غير مصرح بتفعيل جدار الحمايةّ"
 ],
 "Disable the firewall": [
  null,
  "تعطيل الجدار الناري"
 ],
 "Enable the firewall": [
  null,
  "تفعيل الجدار الناري"
 ],
 "Edit service $0": [
  null,
  "تعديل الخدمة $0"
 ],
 "Remove service $0": [
  null,
  "إزالة الخدمة $0"
 ],
 "Additional port": [
  null,
  "منفذ إضافي"
 ],
 "Remove zone $0": [
  null,
  "إزالة المنطقة $0"
 ],
 "Add services to zone $0": [
  null,
  "إضافة خدمات إلى المنطقة $0"
 ],
 "Add services": [
  null,
  "إضافة خدمات"
 ],
 "Service": [
  null,
  "خدمة"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "منطقة $0"
 ],
 "Interface": [
  null,
  "الواجهة",
  "واجهة",
  "واجهتين",
  "واجهات",
  "واجهة",
  "واجهة"
 ],
 "Allowed addresses": [
  null,
  "العناوين المسموح بها"
 ],
 "Entire subnet": [
  null,
  "الشبكة الفرعية بالكامل"
 ],
 "There are no active services in this zone": [
  null,
  "لا توجد خدمات نشطة في هذه المنطقة"
 ],
 "Filter services": [
  null,
  "خدمة التصفية"
 ],
 "Failed to edit service": [
  null,
  "فشل في تعديل الخدمة"
 ],
 "Failed to add port": [
  null,
  "فشل في إضافة منفذ"
 ],
 "Failed to add service": [
  null,
  "فشل في إضافة خدمة"
 ],
 "Unknown service name": [
  null,
  "اسم خدمة غير معروف"
 ],
 "Invalid port number": [
  null,
  "رقم المنفذ غير صالح"
 ],
 "Invalid range": [
  null,
  "مدى غير صالح"
 ],
 "Range must be strictly ordered": [
  null,
  "يجب أن يكون النطاق مرتبًا بدقة"
 ],
 "Edit service": [
  null,
  "تعديل الخدمة"
 ],
 "Edit custom service in $0 zone": [
  null,
  "تعديل خدمة مخصصة في المنطقة $0"
 ],
 "Add ports": [
  null,
  "إضافة منافذ"
 ],
 "Add ports to $0 zone": [
  null,
  "إضافة منافذ للمنطقة $0"
 ],
 "Add services to $0 zone": [
  null,
  "إضافة خدمات للمنطقة $0"
 ],
 "Custom ports": [
  null,
  "منافذ مخصصة"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "مثلاً: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "إدخال المنافذ والنطاقات والخدمات مفصولة بفواصل متاح"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "مثلاً: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "إذا تُرك فارغًا، فسيتم توليد المعرف وفق خدمات المنافذ ، وأرقامها ذات الصلة"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "إضافة منافذ مخصصة سيؤدي إلى إعادة تحميل firewalld ، بالتالي فقدان أي إعدادات مؤقتة!"
 ],
 "Failed to add zone": [
  null,
  "فشل في إضافة منطقة"
 ],
 "Add zone": [
  null,
  "إضافة منطقة"
 ],
 "Trust level": [
  null,
  "مستوى الثقة"
 ],
 "Sorted from least to most trusted": [
  null,
  "مُرتبة من الأقل إلى الأكثر ثقة"
 ],
 "Custom zones": [
  null,
  "مناطق مخصصة"
 ],
 "No description available": [
  null,
  "لا يوجد وصف متاح"
 ],
 "Included services": [
  null,
  "الخدمات المضمّنة"
 ],
 "The cockpit service is automatically included": [
  null,
  "خدمة Cockpit مضمّنة تلقائياً"
 ],
 "Interfaces": [
  null,
  "الواجهات"
 ],
 "Range": [
  null,
  "المدى"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "عنوان IP مع بادئة التوجيه. افصل بين القيم المتعددة بفاصلة. مثال: 192.0.2.0.0/24، 2001:db8:/32"
 ],
 "Confirm removal of $0": [
  null,
  "تأكيد إزالة $0"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "هذه المنطقة تحتوي على خدمة Cockpit. تأكد أنها لا تنطبق على اتصال وحدة التحكم الويب الحالي."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ستؤدي إزالة المنطقة إلى إزالة جميع الخدمات داخلها."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "قد تؤدي إزالة خدمة Cockpit إلى تعذر الوصول إلى وحدة تحكم الويب. تأكد من أن هذه المنطقة لا تنطبق على اتصال وحدة تحكم الويب الحالية."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "أزل الخدمة $0 من المنطقة $1"
 ],
 "Firewall is not available": [
  null,
  "الجدار الناري غير متاح"
 ],
 "Please install the $0 package": [
  null,
  "الرجاء تثبيت الحزمة $0"
 ],
 "Add a new zone": [
  null,
  "إضافة منطقة جديدة"
 ],
 "Add new zone": [
  null,
  "إضافة منطقة جديدة"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "يتم حظر الطلبات الواردة بشكل افتراضي دون الصادرة."
 ],
 "Wireless": [
  null,
  ""
 ],
 "Select a network interface to configure the connection.": [
  null,
  ""
 ],
 "WPA/WPA2 Personal": [
  null,
  ""
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي حذف $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة المستخدم الخاصة بالإدارة غير متاحة."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي تشغيل $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Switch on $0": [
  null,
  "تشغيل $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي إيقاف تشغيل $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Switch off $0": [
  null,
  "إيقاف تشغيل $0"
 ],
 "Bond": [
  null,
  "شبكة وثاقية"
 ],
 "Team": [
  null,
  "الفريق"
 ],
 "VLAN": [
  null,
  "شبكة VLAN"
 ],
 "Bridge": [
  null,
  "جسر"
 ],
 "Unknown \"$0\"": [
  null,
  "\"$0\" غير معروف"
 ],
 "Carrier": [
  null,
  "الناقل"
 ],
 "Yes": [
  null,
  "نعم"
 ],
 "No": [
  null,
  "لا"
 ],
 "Inactive": [
  null,
  "غير مفعَّل"
 ],
 "Unknown configuration": [
  null,
  "تكوين غير معروف"
 ],
 "Additional address $val": [
  null,
  "عناوين إضافية $val"
 ],
 "Address $val": [
  null,
  "العنوان $val"
 ],
 "Gateway $gateway": [
  null,
  "البوّابة $gateway"
 ],
 "Additional DNS $val": [
  null,
  "خادم DNS إضافي: ‎$val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "نطاقات بحث DNS إضافية: ‎$val"
 ],
 "DNS search domains $val": [
  null,
  "البحث في نطاقات DNS $val"
 ],
 "General": [
  null,
  "عام"
 ],
 "Connect automatically": [
  null,
  "غير ممكن آليا"
 ],
 "Automatic": [
  null,
  "تلقائي"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "مراقبة ARP"
 ],
 "Broken configuration": [
  null,
  "تكوين معطل"
 ],
 "Team port": [
  null,
  "منفذ الفريق"
 ],
 "Spanning tree protocol": [
  null,
  "بروتوكول شجرة الامتداد"
 ],
 "Priority $priority": [
  null,
  "الألولوية $priority"
 ],
 "Forward delay $forward_delay": [
  null,
  "التأخير إلى الأمام $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "وقت الترحيب $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "الحد الأقصى لعمر الرسالة $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "تكلفة المسار $path_cost"
 ],
 "Hairpin mode": [
  null,
  "وضع الالتفاف"
 ],
 "Bridge port": [
  null,
  "منفذ الجسر"
 ],
 "Parent $parent": [
  null,
  "الأب $parent"
 ],
 "ID $id": [
  null,
  "المعرف $id"
 ],
 "WireGuard": [
  null,
  "Wireguard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  ""
 ],
 "open": [
  null,
  ""
 ],
 "Signal strength": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "قطع الاتصال"
 ],
 "Refresh": [
  null,
  ""
 ],
 "Network": [
  null,
  "شبكة"
 ],
 "Mode": [
  null,
  "الطور"
 ],
 "Signal": [
  null,
  ""
 ],
 "Rate": [
  null,
  ""
 ],
 "Not permitted to configure network devices": [
  null,
  "غير مسموح بتكوين أجهزة الشبكة"
 ],
 "Enable or disable the device": [
  null,
  "تفعيل أو إلغاء تفعيل الجهاز"
 ],
 "This device cannot be managed here.": [
  null,
  "لا يمكن إدارة هذا الجهاز هنا."
 ],
 "Connection will be lost": [
  null,
  "سيفقد الاتصال"
 ],
 "Keep connection": [
  null,
  "ابقِ الاتصال"
 ],
 "Invalid IP address: $0": [
  null,
  "عنوان IP غير صالح: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "عنوان الوجهة غير صالح: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "عنوان البوابة غير صالح: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "عنوان DNS غير صالح: $0"
 ],
 "Preparing": [
  null,
  "يحضّر"
 ],
 "Configuring": [
  null,
  "التكوين"
 ],
 "Authenticating": [
  null,
  "جار المصادقة"
 ],
 "Configuring IP": [
  null,
  "اضبط IP"
 ],
 "Checking IP": [
  null,
  "التحقق من عنوان الـ IP"
 ],
 "Waiting": [
  null,
  "انتظر"
 ],
 "Active": [
  null,
  "نشط"
 ],
 "Deactivating": [
  null,
  "إلغاء تنشيط"
 ],
 "Adhoc": [
  null,
  ""
 ],
 "Infra": [
  null,
  ""
 ],
 "Mesh": [
  null,
  ""
 ],
 "No carrier": [
  null,
  "لا حامل"
 ],
 "Part of $0": [
  null,
  "جزء من $0"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي تغيير الإعدادات إلى قطع الاتصال مع الخادم وسيجعل واجهة الإدارة الرسومية غير متاحة."
 ],
 "Change the settings": [
  null,
  "تغيير الإعدادات"
 ],
 "Add bridge": [
  null,
  "إضافة جسر"
 ],
 "Edit bridge settings": [
  null,
  "تعديل إعدادات الجسر"
 ],
 "Ports": [
  null,
  "المنافذ"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "بروتوكول شجرة الامتداد (STP)"
 ],
 "STP priority": [
  null,
  "سياسة STP"
 ],
 "STP forward delay": [
  null,
  "التأخير إلى الأمام STP"
 ],
 "STP hello time": [
  null,
  "وقت ترحيب STP"
 ],
 "STP maximum message age": [
  null,
  "الحد الأقصى لعمر رسالة STP"
 ],
 "Round robin": [
  null,
  "جولة روبن"
 ],
 "Active backup": [
  null,
  "النسخ الاحتياطي النشط"
 ],
 "Load balancing": [
  null,
  "موازنة الأحمال"
 ],
 "Broadcast": [
  null,
  "البث"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "سلبي"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "فحص اتصال ARP"
 ],
 "NSNA ping": [
  null,
  "اختبار اتصال NSNA"
 ],
 "Add team": [
  null,
  "إضافة فريق"
 ],
 "Edit team settings": [
  null,
  "تعديل إعدادات الفريق"
 ],
 "Runner": [
  null,
  "مشغِّل"
 ],
 "Balancer": [
  null,
  "الموازِن"
 ],
 "Primary": [
  null,
  "أولي"
 ],
 "Link watch": [
  null,
  "رصد الرابط"
 ],
 "Link up delay": [
  null,
  "تأثير تفعيل الرابط"
 ],
 "Link down delay": [
  null,
  "تأخير تعطل الرابط"
 ],
 "Ping interval": [
  null,
  "فترة اختبار الاتصال"
 ],
 "Ping target": [
  null,
  "هدف اختبار الاتصال"
 ],
 "Automatic (DHCP only)": [
  null,
  "تلقائي ( DHCP فقط )"
 ],
 "Link local": [
  null,
  "عنوان ربط محلي"
 ],
 "Manual": [
  null,
  "يدوي"
 ],
 "Shared": [
  null,
  "مشتركة"
 ],
 "Prefix length or netmask": [
  null,
  "طول البادئة أو قناع الشبكة"
 ],
 "Prefix length": [
  null,
  "طول البادئة"
 ],
 "IPv4 settings": [
  null,
  "إعدادات IPv4"
 ],
 "IPv6 settings": [
  null,
  "إعدادات IPv6"
 ],
 "Addresses": [
  null,
  "العناوين"
 ],
 "Select method": [
  null,
  "تحديد طريقة"
 ],
 "Add address": [
  null,
  "إضافة عناوين"
 ],
 "Address": [
  null,
  "العنوان"
 ],
 "Remove item": [
  null,
  "إزالة العنصر"
 ],
 "Gateway": [
  null,
  "البوّابة"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "أضف خادم DNS"
 ],
 "DNS search domains": [
  null,
  "البحث في نطاقات DNS"
 ],
 "Add search domain": [
  null,
  "إضافة نطاق البحث"
 ],
 "Search domain": [
  null,
  "نطاق البحث"
 ],
 "Routes": [
  null,
  "الطرق"
 ],
 "Add route": [
  null,
  "إضافة توجيه"
 ],
 "Metric": [
  null,
  "مقياس"
 ],
 "Enter a valid MAC address": [
  null,
  "أدخل عنوان MAC صالحاً"
 ],
 "Ethernet MAC": [
  null,
  "عنوان MAC للإيثرنت"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "Add VPN": [
  null,
  "أضف VPN"
 ],
 "Add bond": [
  null,
  "إضافة رابط شبكي"
 ],
 "Add VLAN": [
  null,
  "أضف VLAN"
 ],
 "Edit rules and zones": [
  null,
  "تعدسل القواعد والمناطق"
 ],
 "$0 active zone": [
  null,
  "$0 لا يوجد منطقة نشطة",
  "$0 منطقة نشطة واحدة",
  "$0 منطقتين نشطتين",
  "$0 مناطق نشطة",
  "$0 منطقة نشطة",
  "$0 منطقة نشطة"
 ],
 "Managed interfaces": [
  null,
  "الواجهات المدارة"
 ],
 "IP address": [
  null,
  "عنوان IP"
 ],
 "Sending": [
  null,
  "جاري الإرسال"
 ],
 "Receiving": [
  null,
  "استقبال"
 ],
 "Unmanaged interfaces": [
  null,
  "الواجهات غير المُدارة"
 ],
 "Network logs": [
  null,
  "سجل الشبكة"
 ],
 "Addresses are not formatted correctly": [
  null,
  "تنسيق العناوين غير صحيح"
 ],
 "Invalid IP address '$0'": [
  null,
  "عنوان IP غير صالح '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "حزمة wireguard-tools غير مثبتة"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "النظير #$0 يحتوي على نقطة نهاية غير صالحة. يجب تحديدها بالشكل: مضيف:منفذ، مثل 1.2.3.4:51820، [2001:db8::1]:51820 أو example.com:51820"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "النظير #$0 يحتوي على منفذ نهاية غير صالح. يجب أن يكون المنفذ رقماً."
 ],
 "Listen port must be a number": [
  null,
  "منفذ الاستماع يجب أن يكون رقماً"
 ],
 "Add WireGuard VPN": [
  null,
  "أضف WireGuard VPN"
 ],
 "Edit WireGuard VPN": [
  null,
  "تعديل إعدادات WireGuard VPN"
 ],
 "Private key": [
  null,
  "المفتاح الخاص"
 ],
 "Paste existing key": [
  null,
  "لصق مفتاح موجود"
 ],
 "Regenerate": [
  null,
  "إعادة توليد"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "سيتم توليد المفتاح العام عند إدخال مفتاح خاص صالح"
 ],
 "Listen port": [
  null,
  "منفذ الاستماع"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "سيتم ضبطه على \"تلقائي\""
 ],
 "IP addresses": [
  null,
  "عنوانين الـ IP"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "يمكن تحديد عناوين متعددة باستخدام فواصل أو مسافات كمحددات."
 ],
 "Peers": [
  null,
  "النظائر"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "النظائر هي أجهزة أخرى تتصل بهذا الجهاز. سيتم تبادل المفاتيح العامة بين الأجهزة."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "ينبغي تحديد نقطة النهاية التي تعمل كـ ”خادم“ كمضيف:منفذ، وإلا يمكن تركها فارغة."
 ],
 "Add peer": [
  null,
  "إضافة نظير"
 ],
 "Endpoint": [
  null,
  "نقطة نهاية"
 ],
 "Allowed IPs": [
  null,
  "عناوين الـ IP المسموح بها"
 ],
 "No peers added.": [
  null,
  "لا نظائر تم إضافتهم."
 ],
 "Edit VLAN settings": [
  null,
  "تعديل إعدادات VLAN"
 ],
 "Parent": [
  null,
  "الأصل"
 ],
 "VLAN ID": [
  null,
  "معرّف شبكة VLAN"
 ],
 "Transmitting": [
  null,
  "النقل"
 ],
 "MTU must be a positive number": [
  null,
  "يجب أن يكون MTU عدداً موجباً"
 ],
 "Ethernet MTU": [
  null,
  "إيثرنت MTU"
 ],
 "Set to": [
  null,
  "تعيين لـ"
 ],
 "Team port settings": [
  null,
  "إعدادات منفذ الفريق"
 ],
 "Sticky": [
  null,
  "لاصق"
 ],
 "LACP key": [
  null,
  "مفتاح LACP"
 ],
 "Bridge port settings": [
  null,
  "إعدادات منفذ الجسر"
 ],
 "Path cost": [
  null,
  "تكلفة المسار"
 ],
 "Hair pin mode": [
  null,
  "وضعية الالتفاف"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "موازنة حمل إرسال تكيفية"
 ],
 "Adaptive load balancing": [
  null,
  "موازنة حمل إرسال تكيفية"
 ],
 "MII (recommended)": [
  null,
  "MII (مستحسن)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "تعديل إعدادات الربط الشبكي"
 ],
 "Network bond": [
  null,
  "رابطة الشبكة"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "يجمع رابِط الشبكة (Bond) عدة واجهات شبكية في واجهة منطقية واحدة لزيادة الإنتاجية أو تحقيق التكرار."
 ],
 "Link monitoring": [
  null,
  "مراقبة الرابط"
 ],
 "Monitoring interval": [
  null,
  "فترة المراقبة"
 ],
 "Monitoring targets": [
  null,
  "أهداف المراقبة"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ستؤدي إزالة $0 إلى قطع الاتصال بالخادم، وستجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Remove $0": [
  null,
  "إزالة $0"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "إضافة $0 ستؤدي إلى قطع الاتصال بالخادم، وسيجعل واجهة الإدارة غير متاحة."
 ],
 "Add member": [
  null,
  "إضافة عضو"
 ],
 "Interface members": [
  null,
  "واجهة الأعضاء"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ]
});
