cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "id",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Jaringan"
 ],
 "Kernel dump": [
  null,
  "Dump kernel"
 ],
 "Storage": [
  null,
  "Penyimpanan"
 ],
 "Diagnostic reports": [
  null,
  "Laporan diagnostik"
 ],
 "Accounts": [
  null,
  "Akun"
 ],
 "user": [
  null,
  "pengguna"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "kata sandi"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "nama pengguna"
 ],
 "login": [
  null,
  "login"
 ],
 "access": [
  null,
  "akses"
 ],
 "roles": [
  null,
  "peran"
 ],
 "keys": [
  null,
  "kunci"
 ],
 "Managing user accounts": [
  null,
  "Mengelola akun pengguna"
 ]
});
