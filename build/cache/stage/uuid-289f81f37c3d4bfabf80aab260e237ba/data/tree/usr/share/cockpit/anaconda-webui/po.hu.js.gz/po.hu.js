cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "hu",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 telepítés"
 ],
 "$0 installer": [
  null,
  "$0 telepítő"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "A(z) $0 egy MBR kiterjesztett partíció, amely logikai partíciókat tartalmaz. Az összes logikai partíció eltávolítása a kiterjesztett partíciót törlését is magával vonja."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "A(z) $0 szükséges, de csak a(z) $1 érhető el."
 ],
 "$0 warning": [
  null,
  "$0 figyelmeztetés",
  "$0 figyelmeztetés"
 ],
 "$0 will be deleted": [
  null,
  "A(z) $0 törölve lesz"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "A(z) „$0” fájlrendszer nem lehet titkosított blokkeszközön"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "A(z) „$0” csatolási pontnak „$1” formázású eszközön kell lennie"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "„$0” partíció található a(z) $1. MDRAID eszközön. Az MDRAID eszközökön lévő rendszerbetöltő partíciók nem támogatottak."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Egy standard felhasználói fiók rendszergazdai hozzáféréssel a rendszerszintű változtatásokhoz."
 ],
 "About": [
  null,
  "Névjegy"
 ],
 "Account": [
  null,
  "Fiók"
 ],
 "Actions": [
  null,
  "Műveletek"
 ],
 "Add another server...": [
  null,
  "Másik kiszolgáló hozzáadása…"
 ],
 "Add mount": [
  null,
  "Csatolási pont hozzáadása"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Kiegészítők a kiválasztott környezethez"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Nem környezetfüggő kiegészítők"
 ],
 "Additional languages": [
  null,
  "További nyelvek"
 ],
 "Additional software for the selected environment": [
  null,
  "További szoftverek a kiválasztott környezethez"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "A tárolószerkesztőben végzett változások azonnal életbe lépnek."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Az összes, ezt a jelmondatot használó eszköz zárolása fel lesz oldva"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda webes felület"
 ],
 "Anaconda project page": [
  null,
  "Az Anaconda projekt oldala"
 ],
 "Apply mount point assignment and install": [
  null,
  "A csatolási pontok hozzárendelésének alkalmazása és telepítése"
 ],
 "Applying changes...": [
  null,
  "Változtatások alkalmazása…"
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Rendeljen partíciókat a csatolási pontokhoz. Az előre beállított, egyéni elrendezések esetén hasznos."
 ],
 "Automatic log file upload": [
  null,
  "Automatikus naplófájlfeltöltés"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Dátum és idő automatikus beállítása, időkiszolgálók használatával"
 ],
 "Automatically set timezone": [
  null,
  "Időzóna automatikus beállítása"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Elérhető szabad terület: $0. A telepítéshez szükséges: $1."
 ],
 "Back": [
  null,
  "Vissza"
 ],
 "Base environment": [
  null,
  "Alap környezet"
 ],
 "Brief description of the issue": [
  null,
  "A probléma tömör leírása"
 ],
 "Bug report details": [
  null,
  "Hibajelentés részletei"
 ],
 "Bugzilla API key": [
  null,
  "Bugzilla API-kulcs"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "A szoftver használatának folytatásával megérti és elfogadja az előzetes kiadású szoftverrel járó kockázatokat, és kijelenti hogy csak tesztelési és fejlesztési célokra használja, valamint hajlandó bejelenteni az esetleges problémákat, hogy javítson ezen a munkán."
 ],
 "Cancel": [
  null,
  "Mégse"
 ],
 "Change": [
  null,
  "Módosítás"
 ],
 "Change destination": [
  null,
  "Cél módosítása"
 ],
 "Change hostname": [
  null,
  "Gépnév módosítása"
 ],
 "Change partition layout": [
  null,
  "Partíciókiosztás módosítása"
 ],
 "Change system keyboard layout": [
  null,
  "Rendszer billentyűzetkiosztásának módosítása"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Az itt végzett módosítások azonnal életbe lépnek. Nincs „visszavonás”."
 ],
 "Checking storage configuration": [
  null,
  "Tároló-összeállítás ellenőrzése"
 ],
 "Clear search": [
  null,
  "Keresés törlése"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Kattintson a „Következő” gombra, hogy folytassa a figyelmeztetések ellenére."
 ],
 "Close": [
  null,
  "Bezárás"
 ],
 "Close storage editor": [
  null,
  "Tárolószerkesztő bezárása"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "A Cockpit tároló nem biztosított jelmondatot a titkosított eszköz feloldásához."
 ],
 "Completed": [
  null,
  "Kész"
 ],
 "Configure NTP servers": [
  null,
  "NTP-kiszolgálók beállítása"
 ],
 "Configure custom NTP servers": [
  null,
  "Egyéni NTP-kiszolgálók beállítása"
 ],
 "Configure network": [
  null,
  "Hálózat beállítása"
 ],
 "Configure storage": [
  null,
  "Tárolók beállítása"
 ],
 "Configure storage again": [
  null,
  "Tárolók újbóli beállítása"
 ],
 "Confirm passphrase": [
  null,
  "Erősítse meg a jelszavát"
 ],
 "Continue": [
  null,
  "Folytatás"
 ],
 "Continue installation": [
  null,
  "Telepítés folytatása"
 ],
 "Continue with installation": [
  null,
  "A telepítés folytatása"
 ],
 "Create Account": [
  null,
  "Fiók létrehozása"
 ],
 "Create account": [
  null,
  "Fiók létrehozása"
 ],
 "Currently installed: $0": [
  null,
  "Jelenleg telepítve: $0"
 ],
 "Custom": [
  null,
  "Egyéni"
 ],
 "Date": [
  null,
  "Dátum"
 ],
 "Date and time": [
  null,
  "Dátum és idő"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Egyes partíciók törlése megakadályozhatja a(z) $0 indítását: $1"
 ],
 "Description": [
  null,
  "Leírás"
 ],
 "Destination": [
  null,
  "Cél"
 ],
 "Destination is encrypted": [
  null,
  "A cél titkosított"
 ],
 "Detailed description of the issue": [
  null,
  "A probléma részletes leírása"
 ],
 "Detected valid storage layout:": [
  null,
  "Érvényes tárolóelrendezés észlelve:"
 ],
 "Device": [
  null,
  "Eszköz"
 ],
 "Duplicate device.": [
  null,
  "Duplikált eszköz."
 ],
 "Duplicate mount point.": [
  null,
  "Duplikált csatolási pont."
 ],
 "Enable root account": [
  null,
  "Rendszergazdai fiók engedélyezése"
 ],
 "Encrypt my data": [
  null,
  "Saját adatok titkosítása"
 ],
 "Encrypted": [
  null,
  "Titkosítva"
 ],
 "Encryption": [
  null,
  "Titkosítás"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Adja meg a Bugzilla API-kulcsát a hibajelentés létrehozásához. A következő lépésben átnézheti és szerkesztheti a hibajelentés részleteit."
 ],
 "Environment": [
  null,
  "Környezet"
 ],
 "Erase data and install": [
  null,
  "Törölje az adatokat és telepítse"
 ],
 "Error details": [
  null,
  "Hiba részletei"
 ],
 "Exit to live desktop": [
  null,
  "Kilépés az élő asztali környezetbe"
 ],
 "Extended partition": [
  null,
  "Kiterjesztett partíció"
 ],
 "Failed to report issue": [
  null,
  "Nem sikerült a hiba bejelentése"
 ],
 "Failed to save layouts": [
  null,
  "Nem sikerült a kiosztások mentése"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "A Fedora Linuxhoz legalább $0 tárhely szükséges."
 ],
 "Finalization": [
  null,
  "Véglegesítés"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Lezáró műveletek: A rendszerkonfiguráció befejeződött. A telepítés befejezése eltarthat néhány pillanatig."
 ],
 "Find layout": [
  null,
  "Kiosztás keresése"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "A nagyobb biztonság érdekében ne használja közvetlenül a root fiókot. Helyette használja a fenti helyi fiókot a rendszer kezeléséhez."
 ],
 "Full name": [
  null,
  "Teljes név"
 ],
 "Full name cannot contain colon characters": [
  null,
  "A teljes név nem tartalmazhat kettőspontot"
 ],
 "Helper text": [
  null,
  "Súgószöveg"
 ],
 "Hide API key": [
  null,
  "API-kulcs elrejtése"
 ],
 "Hide confirmed password": [
  null,
  "Megerősített jelszó elrejtése"
 ],
 "Hide passphrase": [
  null,
  "Jelmondat elrejtése"
 ],
 "Hide password": [
  null,
  "Jelszó elrejtése"
 ],
 "Hostname": [
  null,
  "Gépnév"
 ],
 "How would you like to install?": [
  null,
  "Hogyan szeretné telepíteni?"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Megértettem, hogy egyes meglévő adatok törölve lesznek"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Megértettem, hogy egy partíciók módosítva lesznek"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Ha üres, a gépnév egy hálózati információk által beállított átmeneti érték lesz."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Ha partíciókat állít be, akkor a következőkre lesz szükség:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Ha nem egyezik bele az automatikus naplófájlfeltöltésbe, akkor helyette $0. A kézi jelentés lehetővé teszi, hogy átnézze, és szelektíven mellékelje a naplófájlokat."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ha nem érti, vagy nem fogadja el a kockázatokat, akkor lépjen ki a programból."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Folyamatban"
 ],
 "Initializing...": [
  null,
  "Előkészítés…"
 ],
 "Install": [
  null,
  "Telepítés"
 ],
 "Installation failed": [
  null,
  "A telepítés sikertelen"
 ],
 "Installation method": [
  null,
  "Telepítési mód"
 ],
 "Installation of the system failed": [
  null,
  "Nem sikerült a rendszer telepítése"
 ],
 "Installation of the system failed: $0": [
  null,
  "Nem sikerült a rendszer telepítése: $0"
 ],
 "Installation type": [
  null,
  "Telepítés típusa"
 ],
 "Installing": [
  null,
  "Telepítés"
 ],
 "Insufficient disk space": [
  null,
  "Elégtelen lemezterület"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Érvénytelen RAID beállítás észlelve. Ha a RAID tömb közvetlenül lemezekből áll, akkor a partíciós táblát a tömbön kell létrehozni. Ha a RAID tömb partíciókból áll, akkor egyetlen fájlrendszert vagy formázást (például LVM PV) tartalmazhat. Az esetlegesen a tömbön található meglévő partíciók figyelmen kívül lesznek hagyva."
 ],
 "Invalid hostname": [
  null,
  "Érvénytelen gépnév"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "A jelenlegi lemezelrendezés megtartása, és telepítés a rendelkezésre álló helyre."
 ],
 "Keyboard": [
  null,
  "Billentyűzet"
 ],
 "Keyboard layout during boot": [
  null,
  "Az indítás során használandó billentyűzetkiosztás"
 ],
 "Language": [
  null,
  "Nyelv"
 ],
 "Launch storage editor": [
  null,
  "Tárhelyszerkesztő indítása"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Tudjon meg többet a korlátozott hozzáférésről a beállításokban"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Hely"
 ],
 "Locked devices": [
  null,
  "Lezárt eszközök"
 ],
 "Make current": [
  null,
  "Jelenlegivé tétel"
 ],
 "Manual disk configuration": [
  null,
  "Kézi lemezkonfiguráció"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Kézi lemezkonfiguráció: Csatolási pontok hozzárendelése"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Betűket, számokat és kötőjeleket tartalmazhat."
 ],
 "May need more free space": [
  null,
  "Lehet, hogy több szabad helyre lesz szükség"
 ],
 "Medium": [
  null,
  "Közepes"
 ],
 "Minimum of $0 required": [
  null,
  "Legalább $0 szükséges"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Nem egyezik a szülőeszköz és a gyermekeszköz újraformázásának kiválasztása."
 ],
 "Mount point": [
  null,
  "Csatolási pont"
 ],
 "Mount point assignment": [
  null,
  "Csatolási pont hozzárendelése"
 ],
 "Move down": [
  null,
  "Lentebb helyezés"
 ],
 "Move up": [
  null,
  "Fentebb helyezés"
 ],
 "Must be at least $0 characters": [
  null,
  "Legalább $0 karakterből kell állnia"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP-kiszolgálók"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Név"
 ],
 "Needs at least $0": [
  null,
  "Legalább $0 szükséges"
 ],
 "Network": [
  null,
  "Hálózat"
 ],
 "Network Configuration": [
  null,
  "Hálózati beállítások"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "A hálózat nem érhető el. A probléma bejelentéséhez állítsa be a hálózatot a felső sáv menüjében."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "A hálózat nem érhető el. A probléma bejelentéséhez állítsa be a hálózatot."
 ],
 "Network plugin failed": [
  null,
  "A hálózati bővítmény sikertelen"
 ],
 "Next": [
  null,
  "Következő"
 ],
 "No devices": [
  null,
  "Nincsenek eszközök"
 ],
 "No disks available": [
  null,
  "Nem érhetőek el lemezek"
 ],
 "No disks selected": [
  null,
  "Nincsenek lemezek kiválasztva"
 ],
 "No layouts selected yet": [
  null,
  "Még nincs kiosztás kiválasztva"
 ],
 "No results found": [
  null,
  "Nincs találat"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Nem szerezhető be érvényes VConsole billentyűleképezés a kiválasztott billentyűzetkiosztásokhoz. Válasszon más billentyűzetkiosztást."
 ],
 "Not enough available free space": [
  null,
  "Nincs elég szabad hely"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Nincs elég szabad hely a kiválasztott lemezeken."
 ],
 "Not enough space on selected disks.": [
  null,
  "Nincs elég hely a kiválasztott lemezeken."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Figyelmeztetés: Ez egy előzetes kiadású szoftver, mely csak fejlesztési és tesztelési célokra készült. NE használja kritikus munkára vagy éles rendszerekhez."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Bugzilla hibajelentési űrlap megnyitása"
 ],
 "Operating system": [
  null,
  "Operációs rendszer"
 ],
 "Options": [
  null,
  "Beállítások"
 ],
 "Other keyboards": [
  null,
  "Egyéb billentyűzetek"
 ],
 "Partitions (advanced)": [
  null,
  "Partíciók (speciális)"
 ],
 "Passphrase": [
  null,
  "Jelmondat"
 ],
 "Passphrase did not match any locked device": [
  null,
  "A jelmondat nem egyezik egyetlen zárolt eszközével sem"
 ],
 "Passphrases must match": [
  null,
  "A jelmondatoknak egyezniük kell"
 ],
 "Pending": [
  null,
  "Folyamatban"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Mellékelje a(z) $0 naplófájlt a problémához."
 ],
 "Please select at least one disk to continue": [
  null,
  "Válasszon legalább egy lemezt a folytatáshoz"
 ],
 "Pool": [
  null,
  "Hálózat"
 ],
 "Powered by Anaconda": [
  null,
  "Az Anaconda használatával"
 ],
 "Pre-release": [
  null,
  "Kiadás előtti verziók"
 ],
 "Prefer to report manually? $0": [
  null,
  "Inkább kézileg jelenti be? $0"
 ],
 "Proceed with installation": [
  null,
  "Telepítés folytatása"
 ],
 "Quit": [
  null,
  "Kilépés"
 ],
 "Quit installer?": [
  null,
  "Kilép a telepítőből?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Nem sikerült beolvasni az operációs rendszerre vonatkozó információkat."
 ],
 "Reading information about the computer failed.": [
  null,
  "Nem sikerült beolvasni a számítógépre vonatkozó információkat."
 ],
 "Reading installer configuration failed.": [
  null,
  "Nem sikerült beolvasni a telepítő konfigurációját."
 ],
 "Reading installer version information failed.": [
  null,
  "Nem sikerült beolvasni a telepítő verzióinformációit."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "A válódi gépnevek csak betűket, számjegyeket, kötőjeleket (nem záró vagy kezdő karakterként) és pontokat tartalmazhatnak"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "A valódi gépnév 64 vagy kevesebb karakter hosszú lehet"
 ],
 "Reboot": [
  null,
  "Újraindítás"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Újraindítás a Windowszal a BitLockerrel titkosított partíció átméretezéséhez. Hagyjon legalább $0 szabad helyet a telepítéshez."
 ],
 "Reboot system?": [
  null,
  "Újraindítja a rendszert?"
 ],
 "Reclaim additional space": [
  null,
  "További terület visszanyerése"
 ],
 "Reclaim space": [
  null,
  "Hely visszanyerése"
 ],
 "Reclaim space (required)": [
  null,
  "Hely visszanyerése (szükséges)"
 ],
 "Recommended": [
  null,
  "Ajánlott"
 ],
 "Recommended partitions:": [
  null,
  "Ajánlott partíciók:"
 ],
 "Reformat": [
  null,
  "Újraformázás"
 ],
 "Reinstall Fedora": [
  null,
  "A Fedora újratelepítése"
 ],
 "Remove": [
  null,
  "Eltávolítás"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Az összes partíció eltávolítása a kiválasztott eszközökről, beleértve a meglévő operációs rendszereket is."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Távolítson el vagy méretezze át a meglévő fájlrendszereket, hogy helyet szabadítson fel a telepítéshez."
 ],
 "Remove server": [
  null,
  "Kiszolgáló eltávolítása"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "A fájlrendszer eltávolítása végleg törli az összes tartalmazott adatot. A partíció átméretezése felszabadíthatja a nem használt helyet, de nem kockázatmentes. A hely visszanyerése előtt győződjön meg arró, hogy minden fontos dologról van biztonsági mentése."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "A jelenlegi telepítés cseréje, de a saját mappákban lévő fájlok megtartása."
 ],
 "Report Issue": [
  null,
  "Probléma bejelentése"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Egy probléma bejelentése vagy visszajelzés adása a Bugzilla hibajelentési űrlap megnyitásával: $0."
 ],
 "Report issue": [
  null,
  "Probléma bejelentése"
 ],
 "Reporting issue...": [
  null,
  "Probléma bejelentése…"
 ],
 "Required": [
  null,
  "Szükséges"
 ],
 "Requirements": [
  null,
  "Követelmények"
 ],
 "Rescan devices": [
  null,
  "Eszközök újraolvasása"
 ],
 "Rescanning of the disks failed.": [
  null,
  "A lemezek újraellenőrzése nem sikerült."
 ],
 "Resize": [
  null,
  "Átméretezés"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "A(z) $0 következő partícióinak átméretezése: $1"
 ],
 "Restrict access to the report": [
  null,
  "Hozzáférés korlátozása a jelentésnél"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "A jelentést a(z) $0 csoportra korlátozza. $1"
 ],
 "Return to installation": [
  null,
  "Visszatérés a telepítéshez"
 ],
 "Return to storage editor": [
  null,
  "Visszatérés a tárolószerkesztőhöz"
 ],
 "Review and install": [
  null,
  "Áttekintés és telepítés"
 ],
 "Root account is enabled": [
  null,
  "Rendszergazdai fiók bekapcsolva"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "A rendszergazdai fiók be van kapcsolva, de felhasználói fiók nem lett beállítva"
 ],
 "Root password has been set.": [
  null,
  "Be lett állítva a rendszergazdai jelszó."
 ],
 "Save": [
  null,
  "Mentés"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Olvassa le a QR-kódot a telefonjával, vagy keresse fel:"
 ],
 "Search for a language": [
  null,
  "Nyelv keresése"
 ],
 "Search for additional software": [
  null,
  "További szoftverek keresése"
 ],
 "Search for an environment": [
  null,
  "Környezet keresése"
 ],
 "Search keyboard layout": [
  null,
  "Billentyűzetkiosztás keresése"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Védje az adatait a lemezalapú titkosítással. Csak az új partíciókra vonatkozik."
 ],
 "Select": [
  null,
  "Válasszon"
 ],
 "Select a device": [
  null,
  "Válasszon egy eszközt"
 ],
 "Select city": [
  null,
  "Válasszon várost"
 ],
 "Select destination": [
  null,
  "Válasszon célt"
 ],
 "Select region": [
  null,
  "Válasszon régiót"
 ],
 "Selected (top = current)": [
  null,
  "Kiválasztva (felső = jelenlegi)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "A kiválasztott eszköz „$0” formátuma nem formázható újra."
 ],
 "Send us feedback on your installation": [
  null,
  "Visszajelzés küldése a telepítéséről"
 ],
 "Server": [
  null,
  "Kiszolgáló"
 ],
 "Server is not reachable": [
  null,
  "A kiszolgáló nem érhető el"
 ],
 "Set custom hostname": [
  null,
  "Egyéni gépnév beállítása"
 ],
 "Share disk with other operating systems": [
  null,
  "Lemez megosztása más operációs rendszerekkel"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Lemez megosztása más operációs rendszerekkel: $0"
 ],
 "Show AM/PM": [
  null,
  "A _de./du. megjelenítése"
 ],
 "Show API key": [
  null,
  "API-kulcs megjelenítése"
 ],
 "Show confirmed password": [
  null,
  "Megerősített jelszó megjelenítése"
 ],
 "Show passphrase": [
  null,
  "Jelmondta megjelenítése"
 ],
 "Show password": [
  null,
  "Jelszó megjelenítése"
 ],
 "Size": [
  null,
  "Méret"
 ],
 "Software installation": [
  null,
  "Szoftver telepítése"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Szoftvertelepítés: A tárhely konfigurálása kész. A szoftver telepítése folyamatban van az eszközre."
 ],
 "Software selection": [
  null,
  "Szoftver kiválasztása"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "Egyes szükséges partíciók hiányoznak: $0"
 ],
 "Space": [
  null,
  "Hely"
 ],
 "Stacktrace": [
  null,
  "Veremkiíratás"
 ],
 "Storage": [
  null,
  "Tárhely"
 ],
 "Storage configuration": [
  null,
  "Tároló-összeállítás"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Tárhely-konfiguráció: A tárhely beállítása folyamatban van."
 ],
 "Storage editor": [
  null,
  "Tárolószerkesztő"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "A tároló a „Tároló módosítása” konfigurációján alapszik."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "A tárolóbővítmény sikertelen"
 ],
 "Storage requirements not met": [
  null,
  "Nem felel meg a tárolókövetelményeknek"
 ],
 "Strong": [
  null,
  "Erős"
 ],
 "Successfully installed": [
  null,
  "Sikeresen telepítve"
 ],
 "Successfully unlocked $0.": [
  null,
  "Sikeresen feloldotta $0."
 ],
 "Suggested keyboards": [
  null,
  "Javasolt billentyűzetek"
 ],
 "Suggested languages": [
  null,
  "Javasolt nyelvek"
 ],
 "System": [
  null,
  "Rendszer"
 ],
 "System configuration": [
  null,
  "Rendszerbeállítások"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Rendszer-konfiguráció: A szoftver telepítése befejeződött. A rendszer konfigurálása folyamatban van."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Az Anaconda telepítő váratlanul leállt."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "A telepítéshez $0 tárterület szükséges; viszont a kiválasztott lemezek kapacitása csak $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "A telepítő nem tudja folytatni egy kritikus hiba miatt."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "A telepítő nem tudja folytatni egy kritikus hiba miatt: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "A megadott jelszó nem ASCII karaktereket tartalmaz. Lehet, hogy fog tudni váltani a billentyűzetkiosztások között, amikor meg kell adnia."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Az alapértelmezett billentyűzetkiosztás nem támogatja az ASCII karaktereket. Alapértelmezettként válasszon egy ASCII-képes kiosztást."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "A tárolószerkesztővel átméretezhet, törölhet és létrehozhat partíciókat. Beállíthat LVM-et, és még sok mindent. Speciális segédprogramként való használatra lett szánva, egy tipikus telepítés során nem szükséges."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Ezek a naplók érzékeny információkat tartalmazhatnak, mint az IP-címek, a felhasználónevek vagy egyéb rendszer-információk."
 ],
 "This hostname can't be submitted": [
  null,
  "Ez a gépnév nem küldhető be"
 ],
 "This is unstable, pre-release software": [
  null,
  "Ez egy instabil, előzetes kiadású szoftver"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Ez az elrendezés lesz használva a feloldáshoz a rendszerindítás során"
 ],
 "This may take a moment": [
  null,
  "Ez eltarthat egy ideig"
 ],
 "This will take a few moments": [
  null,
  "Ez el fog tartani egy ideig"
 ],
 "Time": [
  null,
  "Idő"
 ],
 "Timezone": [
  null,
  "Időzóna"
 ],
 "Title": [
  null,
  "Cím"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "A(z) $0 használatának megkezdéséhez indítsa újra a rendszert."
 ],
 "To continue, select the devices to install to.": [
  null,
  "A folytatáshoz, kérem válassza ki a telepíteni kívánt eszközöket."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Ennek az opciónak a használatához méretezze át vagy távolítsa el a meglévő partíciókat, hogy legalább $0 szabadítson fel."
 ],
 "Type": [
  null,
  "Típus"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "A(z) $0 törlése nem ütemezhető be"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "A(z) $0 átméretezése nem ütemezhető be"
 ],
 "Unlock": [
  null,
  "Feloldás"
 ],
 "Unlock encrypted devices": [
  null,
  "A titkosított eszközök feloldása"
 ],
 "Use configured storage": [
  null,
  "Beállított tároló használata"
 ],
 "Use entire disk": [
  null,
  "Teljes lemez felhasználása"
 ],
 "Use free space": [
  null,
  "Szabad tárhely felhasználása"
 ],
 "Use local account": [
  null,
  "Helyi fiók használata"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "A RAID-eszköz használata az automatikus particionáláshoz"
 ],
 "User creation": [
  null,
  "Felhasználó létrehozása"
 ],
 "User name": [
  null,
  "Felhasználónév"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "A felhasználónév a következőket tartalmazhatja: betűk a-z, számjegyek 0-9, kötőjel $0, pont $1, alulvonás $2"
 ],
 "User name must not be a reserved word": [
  null,
  "A felhasználónév nem tartalmazhat a rendszer számára fenntartott szót"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "A felhasználónévnek 33 karakternél rövidebbnek kell lennie"
 ],
 "Validating...": [
  null,
  "Érvényesítés…"
 ],
 "Weak": [
  null,
  "Gyenge"
 ],
 "Welcome": [
  null,
  "Üdvözöljük"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Üdvözli a Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Üdvözöljük. Kezdődhet a(z) $0 telepítése."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Ha beküldi ezt a hibajelentést, akkor a következő naplófájlok automatikusan fel lesznek töltve: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "A BitLocker-titkosítással rendelkező Windows-partíciók nem méretezhetőek át"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Vagy felszabadíthat itt elég helyett, és hagyhatja, hogy a telepítő intézze a többit, vagy kézileg állíthatja be a partíciókat."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Előállíthat egy API-kulcsot a(z) $0 Bugzilla-fiókjához."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "A folytatáshoz engedélyeznie kell a rendszergazdai fiókot, vagy létre kell hoznia egy helyi felhasználót."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Az automatikus dátum és idő bekapcsolásához kapcsolódnia kell egy hálózathoz."
 ],
 "Your progress will not be saved.": [
  null,
  "A folyamat pillanatnyi állapota nem kerül mentésre."
 ],
 "completed step": [
  null,
  "befejezett lépés"
 ],
 "current step": [
  null,
  "jelenlegi lépés"
 ],
 "delete": [
  null,
  "törlés"
 ],
 "edit": [
  null,
  "szerkesztés"
 ],
 "encrypt": [
  null,
  "titkosítás"
 ],
 "encrypted": [
  null,
  "titkosítva"
 ],
 "extended partition": [
  null,
  "kiterjesztett partíció"
 ],
 "format as $0": [
  null,
  "formázás mint $0"
 ],
 "here": [
  null,
  "itt"
 ],
 "mount": [
  null,
  "csatolás"
 ],
 "pending step": [
  null,
  "függőben lévő lépés"
 ],
 "report the issue manually": [
  null,
  "jelentheti a hibát kézileg"
 ],
 "resized from $0": [
  null,
  "átméretezve erről: $0"
 ],
 "shrink": [
  null,
  "zsugorítás"
 ],
 "shrink to $0": [
  null,
  "zsugorítás erre: $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "visszavonás"
 ]
});
