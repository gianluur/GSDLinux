cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nn",
  "language-direction": "ltr"
 },
 "Anaconda": [
  null,
  ""
 ]
});
