cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Journal": [
  null,
  "Dziennik"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "Hardware information": [
  null,
  "Informacje o sprzęcie"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "active": [
  null,
  "aktywne"
 ],
 "Default": [
  null,
  "Domyślne"
 ],
 "Light": [
  null,
  "Jasny"
 ],
 "Dark": [
  null,
  "Ciemny"
 ],
 "Help": [
  null,
  "Pomoc"
 ],
 "Select": [
  null,
  "Wybierz"
 ],
 "System": [
  null,
  "System"
 ],
 "Search": [
  null,
  "Szukaj"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "Permission denied": [
  null,
  "Odmowa dostępu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "You now have administrative access.": [
  null,
  "Uzyskano dostęp administracyjny."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Proszę się uwierzytelnić, aby uzyskać dostęp administracyjny"
 ],
 "Switch to administrative access": [
  null,
  "Przełącz na dostęp administracyjny"
 ],
 "Authenticate": [
  null,
  "Uwierzytelnij"
 ],
 "Administrative access": [
  null,
  "Dostęp administracyjny"
 ],
 "Problem becoming administrator": [
  null,
  "Problem podczas zostawania administratorem"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Limit access": [
  null,
  "Ogranicz dostęp"
 ],
 "Switch to limited access": [
  null,
  "Przełącz na ograniczony dostęp"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Tryb ograniczonego dostępu ogranicza uprawnienia administracyjne. Część konsoli internetowej będzie miała zmniejszoną funkcjonalność."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Używana przeglądarka będzie pamiętała poziom dostępu użytkownika między sesjami."
 ],
 "Limited access": [
  null,
  "Ograniczony dostęp"
 ],
 "Turn on administrative access": [
  null,
  "Włącz dostęp administracyjny"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "PackageKit reported error code $0": [
  null,
  "Usługa PackageKit zgłosiła kod błędu $0"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Filtrowanie"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "System plików"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Brak wyników"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Plik"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "Font size": [
  null,
  "Rozmiar czcionki"
 ],
 "Decrease by one": [
  null,
  "Zmniejsz o jedną jednostkę"
 ],
 "Increase by one": [
  null,
  "Zwiększ o jedną jednostkę"
 ],
 "Appearance": [
  null,
  "Wygląd"
 ],
 "Black": [
  null,
  "Czarny"
 ],
 "White": [
  null,
  "Biały"
 ],
 "Reset": [
  null,
  "Przywróć"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  ""
 ],
 "unknown": [
  null,
  "nieznane"
 ],
 "Shutdown": [
  null,
  "Wyłącz"
 ],
 "running $0": [
  null,
  "pod kontrolą $0"
 ],
 "Current boot": [
  null,
  "Obecne uruchomienie"
 ],
 "Previous boot": [
  null,
  "Poprzednie uruchomienie"
 ],
 "Last 24 hours": [
  null,
  "Ostatni dzień"
 ],
 "Last 7 days": [
  null,
  "Ostatni tydzień"
 ],
 "Only emergency": [
  null,
  "Tylko awaryjne"
 ],
 "Alert and above": [
  null,
  "Alarmy i powyżej"
 ],
 "Critical and above": [
  null,
  "Krytyczne i powyżej"
 ],
 "Error and above": [
  null,
  "Błędy i powyżej"
 ],
 "Warning and above": [
  null,
  "Ostrzeżenia i powyżej"
 ],
 "Notice and above": [
  null,
  "Uwagi i powyżej"
 ],
 "Info and above": [
  null,
  "Informacje i powyżej"
 ],
 "Debug and above": [
  null,
  "Debugowania i powyżej"
 ],
 "Toggle filters": [
  null,
  "Przełącz filtry"
 ],
 "Time": [
  null,
  "Czas"
 ],
 "Priority": [
  null,
  "Priorytet"
 ],
 "Identifier": [
  null,
  "Identyfikator"
 ],
 "Filters": [
  null,
  "Filtry"
 ],
 "Pause": [
  null,
  "Wstrzymaj"
 ],
 "Resume": [
  null,
  "Wznów"
 ],
 "All": [
  null,
  "Wszystkie"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Określenia dat powinny być w formacie RRRR-MM-DD gg:mm:ss. Dodatkowo obsługiwane są ciągi „yesterday” (wczoraj), „today” (dzisiaj) i „tomorrow” (jutro). „now” odnosi się do obecnego czasu. Można także podać czas względny za pomocą przedrostka „-” lub „+”."
 ],
 "Since": [
  null,
  "Od"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Wyświetlanie wpisów z podanego dnia lub nowszych."
 ],
 "Until": [
  null,
  "Do"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Wyświetlanie wpisów z podanego dnia lub starszych."
 ],
 "Boot": [
  null,
  "Uruchomienie"
 ],
 "Show messages from a specific boot.": [
  null,
  "Wyświetla komunikaty z podanego uruchomienia."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Spowoduje to dodanie dopasowania do „_BOOT_ID=”. Jeśli nie zostanie podane, to zostaną wyświetlone dzienniki dla obecnego uruchomienia. Jeśli identyfikator uruchomienia zostanie pominięty, to dodatnie wyrównanie wyszuka uruchomienia zaczynając od początku zapisów, a równe lub mniejsze niż zero wyrównanie wyszuka uruchomienia zaczynając od końca zapisów. 1 oznacza więc pierwsze uruchomienie odnalezione w zapisach w kolejności chronologicznej, 2 drugie i tak dalej, zaś -0 to ostatnie uruchomienie, -1 przedostatnie uruchomienie i tak dalej."
 ],
 "Unit": [
  null,
  "Jednostka"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Wyświetla komunikaty dla podanej jednostki systemd."
 ],
 "Free-form search": [
  null,
  "Wyszukiwanie dowolnego tekstu"
 ],
 "Show messages containing given string.": [
  null,
  "Wyświetla komunikaty zawierające podany ciąg."
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Można filtrować dowolny ciąg tekstowy w komunikatach dziennika. Ciąg może być także w formie wyrażenia regularnego. Obsługiwane jest także filtrowanie według pól komunikatu dziennika. Są to wartości rozdzielone spacjami w formie POLE=WARTOŚĆ, gdzie wartość może być listą możliwych wartości rozdzielonych przecinkami."
 ],
 "journalctl manpage": [
  null,
  "strona podręcznika journalctl"
 ],
 "Successfully copied to clipboard": [
  null,
  "Pomyślnie skopiowano do schowka"
 ],
 "Create timer": [
  null,
  "Utwórz licznik"
 ],
 "Timer creation failed": [
  null,
  "Utworzenie licznika się nie powiodło"
 ],
 "Failed to get the starting conditions for the timer": [
  null,
  ""
 ],
 "This field cannot be empty": [
  null,
  "To pole nie może być puste"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Dozwolone są tylko litery, liczby i znaki „:”, „_”, „.”, „@”, „-”"
 ],
 "Description": [
  null,
  "Opis"
 ],
 "This command will be executed by /bin/sh.": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "Wyzwalacz"
 ],
 "At specific time": [
  null,
  "O podanym czasie"
 ],
 "After system boot": [
  null,
  "Po uruchomieniu systemu"
 ],
 "Seconds": [
  null,
  "Sekundy"
 ],
 "Minutes": [
  null,
  "Minuty"
 ],
 "Hours": [
  null,
  "Godziny"
 ],
 "Weeks": [
  null,
  "Tygodnie"
 ],
 "Delay must be a number": [
  null,
  "Opóźnienie musi być liczbą"
 ],
 "Repeat": [
  null,
  "Powtarzanie"
 ],
 "Don't repeat": [
  null,
  "Bez powtarzania"
 ],
 "Minutely": [
  null,
  "Co minutę"
 ],
 "Hourly": [
  null,
  "Co godzinę"
 ],
 "Daily": [
  null,
  "Codziennie"
 ],
 "Weekly": [
  null,
  "Co tydzień"
 ],
 "Monthly": [
  null,
  "Co miesiąc"
 ],
 "Yearly": [
  null,
  "Co roku"
 ],
 "Run at": [
  null,
  "Uruchom o"
 ],
 "At second": [
  null,
  "O sekundzie"
 ],
 "At minute": [
  null,
  "O minucie"
 ],
 "Run on": [
  null,
  "Uruchom w dniu"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuta musi być liczbą między 0 a 59"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekunda musi być liczbą między 0 a 59"
 ],
 "Repeat weekly": [
  null,
  "Powtarzanie co tydzień"
 ],
 "Mondays": [
  null,
  "poniedziałki"
 ],
 "Tuesdays": [
  null,
  "wtorki"
 ],
 "Wednesdays": [
  null,
  "środy"
 ],
 "Thursdays": [
  null,
  "czwartki"
 ],
 "Fridays": [
  null,
  "piątki"
 ],
 "Saturdays": [
  null,
  "soboty"
 ],
 "Sundays": [
  null,
  "niedziele"
 ],
 "Repeat monthly": [
  null,
  "Powtarzanie co miesiąc"
 ],
 "1st": [
  null,
  "1."
 ],
 "2nd": [
  null,
  "2."
 ],
 "3rd": [
  null,
  "3."
 ],
 "4th": [
  null,
  "4."
 ],
 "5th": [
  null,
  "5."
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "View logs": [
  null,
  "Wyświetl dzienniki"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Zaplanowane wyłączenie komputera: $0"
 ],
 "Cancel poweroff": [
  null,
  "Anuluj wyłączenie komputera"
 ],
 "Scheduled reboot at $0": [
  null,
  "Zaplanowane ponowne uruchomienie: $0"
 ],
 "Cancel reboot": [
  null,
  "Anuluj ponowne uruchomienie"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "Set hostname": [
  null,
  "Ustaw nazwę komputera"
 ],
 "Configuration": [
  null,
  "Konfiguracja"
 ],
 "Hostname": [
  null,
  "Nazwa komputera"
 ],
 "System time": [
  null,
  "Czas systemowy"
 ],
 "Domain": [
  null,
  "Domena"
 ],
 "Performance profile": [
  null,
  "Profil wydajności"
 ],
 "Secure shell keys": [
  null,
  "Klucze SSH"
 ],
 "Show fingerprints": [
  null,
  "Wyświetl odciski"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "wyświetlenie listy kluczy SSH komputera się nie powiodło: $0"
 ],
 "Loading of SSH keys failed": [
  null,
  "Wczytanie kluczy SSH się nie powiodło"
 ],
 "Error message": [
  null,
  "Komunikat o błędzie"
 ],
 "Loading keys...": [
  null,
  "Wczytywanie kluczy…"
 ],
 "No host keys found.": [
  null,
  "Nie odnaleziono kluczy komputera."
 ],
 "Machine SSH key fingerprints": [
  null,
  "Odciski kluczy SSH komputera"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Prawdziwa nazwa komputera może mieć co najwyżej 64 znaki"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Prawdziwa nazwa komputera może zawierać tylko małe litery, cyfry, myślniki i kropki (z zaludnionymi poddomenami)"
 ],
 "Change host name": [
  null,
  "Zmień nazwę komputera"
 ],
 "Pretty host name": [
  null,
  "Czytelna nazwa komputera"
 ],
 "Real host name": [
  null,
  "Prawdziwa nazwa komputera"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Użytkownik $0 nie ma zezwolenia na zmianę zasad kryptograficznych"
 ],
 "Cryptographic policy": [
  null,
  "Zasady kryptograficzne"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Zalecane, bezpieczne ustawienia wobec obecnych modeli zagrożeń."
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "„Domyślne” z dozwoloną weryfikacją podpisów SHA-1."
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Wyższa interoperacyjność kosztem zwiększonej płaszczyźnie ataku."
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "„Przestarzałe” z interoperacyjnością z Active Directory."
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Użycie tylko zatwierdzonych i dozwolonych algorytmów podczas uruchamiania w trybie FIPS."
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS z dalszymi ograniczeniami Common Criteria."
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chroni przed atakami spodziewanymi w niedalekiej przyszłości kosztem interoperacyjności."
 ],
 "Custom cryptographic policy": [
  null,
  "Niestandardowe zasady kryptograficzne"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Zasady kryptograficzne to składnik systemu konfigurujący główne podsystemy kryptograficzne, w tym protokoły TLS, IPSec, SSH, DNSSec i Kerberos."
 ],
 "Change cryptographic policy": [
  null,
  "Zmień zasady kryptograficzne"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Zastosowywanie nowych zasad… Może to zająć kilka minut."
 ],
 "Reapply and reboot": [
  null,
  "Zastosuj jeszcze raz i uruchom ponownie"
 ],
 "Apply and reboot": [
  null,
  "Zastosuj i uruchom ponownie"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS nie jest poprawnie włączone"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Zasady kryptograficzne są niespójne"
 ],
 "Review cryptographic policy": [
  null,
  "Przejrzyj zasady kryptograficzne"
 ],
 "System information": [
  null,
  "Informacje o systemie"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Asset tag": [
  null,
  "Etykieta zasobu"
 ],
 "Machine ID": [
  null,
  "Identyfikator komputera"
 ],
 "View hardware details": [
  null,
  "Wyświetl informacje o sprzęcie"
 ],
 "Last successful login:": [
  null,
  "Ostatnie udane logowanie:"
 ],
 "$0 failed login attempt": [
  null,
  "$0 próba zalogowania zakończona niepowodzeniem",
  "$0 próby zalogowania zakończone niepowodzeniem",
  "$0 prób zalogowania zakończonych niepowodzeniem"
 ],
 "View login history": [
  null,
  "Wyświetl historię logowania"
 ],
 "recommended": [
  null,
  "zalecane"
 ],
 "inconsistent": [
  null,
  "niespójne"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Dołączenie do domeny wymaga instalacji usługi realmd"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nie można dołączyć do domeny, ponieważ usługa realmd nie jest dostępna w tym systemie"
 ],
 "Joining this domain is not supported": [
  null,
  "Dołączenie do tej domeny jest nieobsługiwane"
 ],
 "Login format": [
  null,
  "Format logowania"
 ],
 "Server software": [
  null,
  "Oprogramowanie serwera"
 ],
 "Client software": [
  null,
  "Oprogramowanie klienta"
 ],
 "Leave domain": [
  null,
  "Opuść domenę"
 ],
 "Leave $0": [
  null,
  "Opuść $0"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opuszczeniu domeny, tylko użytkownicy z lokalnymi danymi uwierzytelniania będą mogli zalogować się do tego komputera. Może to mieć wpływ także na inne usługi, ponieważ ustawienia rozwiązywania DNS i listy zaufanych CA mogą ulec zmianie."
 ],
 "Validating address": [
  null,
  "Sprawdzanie poprawności adresu"
 ],
 "Contacted domain": [
  null,
  "Skontaktowana domena"
 ],
 "Domain could not be contacted": [
  null,
  "Nie można skontaktować się z domeną"
 ],
 "Domain is not supported": [
  null,
  "Domena jest nieobsługiwana"
 ],
 "Domain address": [
  null,
  "Adres domeny"
 ],
 "Domain administrator name": [
  null,
  "Nazwa administratora domeny"
 ],
 "Domain administrator password": [
  null,
  "Hasło administratora domeny"
 ],
 "Joining": [
  null,
  "Dołączanie"
 ],
 "Join": [
  null,
  "Dołącz"
 ],
 "This may take a while": [
  null,
  "Może to chwilę zająć"
 ],
 "Not permitted to configure realms": [
  null,
  "Brak zezwolenia na konfigurowanie obszarów"
 ],
 "Join domain": [
  null,
  "Dołącz do domeny"
 ],
 "Install realmd support": [
  null,
  "Zainstaluj obsługę realmd"
 ],
 "Not connected to Insights": [
  null,
  "Nie połączono z Insights"
 ],
 "Health": [
  null,
  "Stan"
 ],
 "of $0 CPU": [
  null,
  "$0 procesora",
  "$0 procesorów",
  "$0 procesorów"
 ],
 "Usage": [
  null,
  "Użycie"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "Memory": [
  null,
  "Pamięć"
 ],
 "View metrics and history": [
  null,
  "Wyświetl statystyki i historię"
 ],
 "Tuned is not available": [
  null,
  "tuned jest niedostępne"
 ],
 "Tuned is not running": [
  null,
  "tuned nie jest uruchomione"
 ],
 "Tuned is off": [
  null,
  "tuned jest wyłączone"
 ],
 "This system is using the recommended profile": [
  null,
  "Ten system używa zalecanego profilu"
 ],
 "This system is using a custom profile": [
  null,
  "Ten system używa niestandardowego profilu"
 ],
 "none": [
  null,
  "brak"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikacja z tuned się nie powiodła"
 ],
 "Failed to enable tuned": [
  null,
  "Włączenie tuned się nie powiodło"
 ],
 "Failed to disable tuned": [
  null,
  "Wyłączenie tuned się nie powiodło"
 ],
 "Failed to disable tuned profile": [
  null,
  "Wyłączenie profilu tuned się nie powiodło"
 ],
 "Failed to switch profile": [
  null,
  "Przełączenie profilu się nie powiodło"
 ],
 "None": [
  null,
  "Brak"
 ],
 "Disable tuned": [
  null,
  "Wyłącz tuned"
 ],
 "Tuned has failed to start": [
  null,
  "Uruchomienie tuned się nie powiodło"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned to usługa monitorująca komputer i optymalizująca wydajność w pewnych zadaniach. Rdzeniem Tuned są profile, które dostosowują komputer do różnych zastosowań."
 ],
 "Change performance profile": [
  null,
  "Zmień profil wydajności"
 ],
 "Change profile": [
  null,
  "Zmień profil"
 ],
 "Edit /etc/motd": [
  null,
  "Modyfikuj /etc/motd"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Zapisanie zmian w /etc/motd się nie powiodło"
 ],
 "Save changes": [
  null,
  "Zapisz zmiany"
 ],
 "Edit motd": [
  null,
  "Modyfikuj motd"
 ],
 "Stub": [
  null,
  "Pozostałość"
 ],
 "Not found": [
  null,
  "Nie odnaleziono"
 ],
 "Bad setting": [
  null,
  "Błędne ustawienie"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Merged": [
  null,
  "Połączone"
 ],
 "Running": [
  null,
  "Działające"
 ],
 "Reloading": [
  null,
  "Wczytywanie ponownie"
 ],
 "Not running": [
  null,
  "Niedziałające"
 ],
 "Failed to start": [
  null,
  "Uruchomienie się nie powiodło"
 ],
 "Maintenance": [
  null,
  "Konserwacja"
 ],
 "Enabled": [
  null,
  "Włączone"
 ],
 "Disabled": [
  null,
  "Wyłączone"
 ],
 "Linked": [
  null,
  "Powiązane"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "Masked": [
  null,
  "Zamaskowana"
 ],
 "Static": [
  null,
  "Statyczne"
 ],
 "Invalid": [
  null,
  "Nieprawidłowe"
 ],
 "Indirect": [
  null,
  "Niebezpośrednie"
 ],
 "Generated": [
  null,
  "Utworzone"
 ],
 "Transient": [
  null,
  "Przejściowe"
 ],
 "Bad": [
  null,
  "Błędne"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Subskrypcja sygnałów systemd się nie powiodła: $0"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Połączenie z usługą D-Bus się nie powiodło: $0"
 ],
 "Listing units failed: $0": [
  null,
  "Wyświetlenie jednostek się nie powiodło: $0"
 ],
 "$0 service has failed": [
  null,
  "$0 usługa się nie powiodła",
  "$0 usługi się nie powiodły",
  "$0 usług się nie powiodło"
 ],
 "Loading of units failed": [
  null,
  "Wczytanie jednostek się nie powiodło"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "Listing units": [
  null,
  "Wyświetlanie jednostek"
 ],
 "Filter by name or description": [
  null,
  "Filtrowanie według nazwy lub opisu"
 ],
 "Active state": [
  null,
  "Aktywny stan"
 ],
 "File state": [
  null,
  "Stan pliku"
 ],
 "$0 filters applied": [
  null,
  ""
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Użytkownik $0 nie ma zezwolenia na zmianę poprawek zabezpieczeń procesora zmniejszających ryzyko"
 ],
 "Mitigations": [
  null,
  "Poprawki zmniejszające ryzyko"
 ],
 "Version": [
  null,
  "Wersja"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS version": [
  null,
  "Wersja BIOS-u"
 ],
 "BIOS date": [
  null,
  "Data BIOS-u"
 ],
 "CPU security": [
  null,
  "Zabezpieczenia procesora"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Wyłącz wielowątkowość współbieżną"
 ],
 "Read more...": [
  null,
  "Więcej informacji…"
 ],
 "Save and reboot": [
  null,
  "Zapisz i uruchom ponownie"
 ],
 "CPU security toggles": [
  null,
  "Przełączniki zabezpieczeń procesora"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Programowe obejścia błędów pomagają uniknąć problemów bezpieczeństwa procesora. Ich efektem ubocznym jest zmniejszenie wydajności. Należy zmieniać te ustawienia na własne ryzyko."
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Class": [
  null,
  "Klasa"
 ],
 "Vendor": [
  null,
  "Producent"
 ],
 "Slot": [
  null,
  "Gniazdo"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "Memory technology": [
  null,
  "Technologia pamięci"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "State": [
  null,
  "Stan"
 ],
 "Rank": [
  null,
  "Stopień"
 ],
 "Speed": [
  null,
  "Prędkość"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Wyświetlanie informacji o pamięci wymaga dostępu administracyjnego."
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "Failed to fetch logs": [
  null,
  "Pobranie dzienników się nie powiodło"
 ],
 "Clear all filters": [
  null,
  "Wyczyść wszystkie filtry"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nie można odnaleźć żadnych dzienników za pomocą obecnego połączenia filtrów."
 ],
 "No logs found": [
  null,
  "Nie odnaleziono dzienników"
 ],
 "Load earlier entries": [
  null,
  "Wczytaj wcześniejsze wpisy"
 ],
 "You may try to load older entries.": [
  null,
  "Można spróbować wczytać starsze wpisy."
 ],
 "Allow running (unmask)": [
  null,
  "Zezwolenie na uruchamianie (odmaskowanie)"
 ],
 "Reload": [
  null,
  "Wczytaj ponownie"
 ],
 "Restart": [
  null,
  "Uruchom ponownie"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Start": [
  null,
  "Rozpocznij"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Clear 'Failed to start'": [
  null,
  "Wyczyść „Uruchomienie się nie powiodło”"
 ],
 "Mask service": [
  null,
  "Zamaskuj usługę"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Zamaskowanie usługi uniemożliwia uruchomienie wszystkich zależnych usług. Może to mieć większy efekt, niż się wydaje. Proszę potwierdzić, że ta jednostka ma zostać zamaskowana."
 ],
 "Disallow running (mask)": [
  null,
  "Bez zezwolenia na uruchamianie (zamaskowanie)"
 ],
 "Unpin unit": [
  null,
  "Odepnij jednostkę"
 ],
 "Pin unit": [
  null,
  "Przypnij jednostkę"
 ],
 "Additional actions": [
  null,
  "Dodatkowe działania"
 ],
 "Note": [
  null,
  "Uwaga"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Ta jednostka nie została zaprojektowana do bezpośredniego włączania."
 ],
 "Forbidden from running": [
  null,
  "Zabronione uruchamianie"
 ],
 "Start service": [
  null,
  "Uruchom usługę"
 ],
 "Active since ": [
  null,
  "Aktywna od "
 ],
 "Required by ": [
  null,
  "Wymagane przez "
 ],
 "Read-only": [
  null,
  "Tylko do odczytu"
 ],
 "Requires administration access to edit": [
  null,
  "Modyfikacja wymaga dostępu administratora"
 ],
 "Automatically starts": [
  null,
  "Automatycznie się uruchamia"
 ],
 "Updating status...": [
  null,
  "Aktualizowanie stanu…"
 ],
 "Stop and disable": [
  null,
  "Zatrzymaj i wyłącz"
 ],
 "Start and enable": [
  null,
  "Uruchom i włącz"
 ],
 "Failed to load unit": [
  null,
  "Wczytanie jednostki się nie powiodło"
 ],
 "View all services": [
  null,
  "Wszystkie usługi"
 ],
 "Triggers": [
  null,
  "Wyzwalacze"
 ],
 "Triggered by": [
  null,
  "Wyzwalane przez"
 ],
 "Requires": [
  null,
  "Wymaga"
 ],
 "Requisite": [
  null,
  "Potrzebne"
 ],
 "Wants": [
  null,
  "Chce"
 ],
 "Binds to": [
  null,
  "Dowiązuje do"
 ],
 "Part of": [
  null,
  "Część"
 ],
 "Required by": [
  null,
  "Wymagane przez"
 ],
 "Requisite of": [
  null,
  "Potrzebne dla"
 ],
 "Wanted by": [
  null,
  "Chciane przez"
 ],
 "Bound by": [
  null,
  "Dowiązane przez"
 ],
 "Consists of": [
  null,
  "Składa się z"
 ],
 "Conflicts": [
  null,
  "Powoduje konflikt z"
 ],
 "Conflicted by": [
  null,
  "W konflikcie z"
 ],
 "Before": [
  null,
  "Przed"
 ],
 "After": [
  null,
  "Po"
 ],
 "On failure": [
  null,
  "Podczas niepowodzenia"
 ],
 "Propagates reload to": [
  null,
  "Wysyła ponowne wczytanie do"
 ],
 "Reload propagated from": [
  null,
  "Odebrano ponowne wczytanie z"
 ],
 "Joins namespace of": [
  null,
  "Dołącza do przestrzeni nazw"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Warunek $0=$1 nie został spełniony"
 ],
 "Deletion will remove the following files:": [
  null,
  "Usunięcie usunie te pliki:"
 ],
 "Pinned unit": [
  null,
  "Przypięta jednostka"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Path": [
  null,
  "Ścieżka"
 ],
 "Listen": [
  null,
  "Nasłuchiwanie"
 ],
 "Condition failed": [
  null,
  "Warunek się nie powiódł"
 ],
 "Show more relationships": [
  null,
  "Więcej związków"
 ],
 "Show relationships": [
  null,
  "Związki"
 ],
 "Confirm deletion of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Timer deletion failed": [
  null,
  "Usunięcie licznika się nie powiodło"
 ],
 "Targets": [
  null,
  "Cele"
 ],
 "Sockets": [
  null,
  "Gniazda"
 ],
 "Timers": [
  null,
  "Liczniki"
 ],
 "Paths": [
  null,
  "Ścieżki"
 ],
 "Go to $0": [
  null,
  "Przejdź do $0"
 ],
 "Journal entry not found": [
  null,
  "Nie odnaleziono wpisu dziennika"
 ],
 "Journal entry": [
  null,
  "Wpis dziennika"
 ],
 "Entry at $0": [
  null,
  "Wpis o $0"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "Loading unit failed": [
  null,
  "Wczytanie jednostki się nie powiodło"
 ],
 "Service logs": [
  null,
  "Dzienniki serwera"
 ],
 "No log entries": [
  null,
  "Brak wpisów dziennika"
 ],
 "Systemd units": [
  null,
  "Jednostki systemd"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Brak wyników pasujących do filtru. Należy wyczyścić wszystkie filtry, aby wyświetlić wyniki."
 ],
 "Does not automatically start": [
  null,
  "Nie uruchamia się automatycznie"
 ],
 "Cannot be enabled": [
  null,
  "Nie można włączyć"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Konsola internetowa działa w trybie ograniczonego dostępu."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domena"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Dołącz do domeny"
 ]
});
