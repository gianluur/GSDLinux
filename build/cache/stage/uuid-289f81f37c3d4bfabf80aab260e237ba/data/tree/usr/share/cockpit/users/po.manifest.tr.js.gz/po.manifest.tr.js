cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Accounts": [
  null,
  "Hesaplar"
 ],
 "user": [
  null,
  "kullanıcı"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "password": [
  null,
  "parola"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "username": [
  null,
  "kullanıcı adı"
 ],
 "login": [
  null,
  "oturum aç"
 ],
 "access": [
  null,
  "erişim"
 ],
 "roles": [
  null,
  "roller"
 ],
 "keys": [
  null,
  "anahtarlar"
 ],
 "Managing user accounts": [
  null,
  "Kullanıcı hesaplarını yönetme"
 ]
});
