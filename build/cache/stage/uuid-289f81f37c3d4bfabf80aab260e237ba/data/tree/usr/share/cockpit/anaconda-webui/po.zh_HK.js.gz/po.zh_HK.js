cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "zh_HK",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 installation": [
  null,
  "$0 安裝"
 ],
 "$0 installer": [
  null,
  "$0 安裝程式"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 是包含邏輯分割區的 MBR 擴充分割區。刪除所有邏輯分割區也會自動刪除擴充分割區。"
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "需要 $0，但僅有 $1 可用。"
 ],
 "$0 warning": [
  null,
  "$0 個警告"
 ],
 "$0 will be deleted": [
  null,
  "$0將會被刪除"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "'$0' 檔案系統不能位於加密區塊裝置上"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "‘$0’ 必須位於格式化為‘$1’的裝置上"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "在 MDRAID 裝置 $1 上找到「$0」分割區。不支援 MDRAID 裝置上的開機載入程式分割區。"
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "一個擁有管理員權限的標準使用者帳戶，以進行系統範圍變更。"
 ],
 "About": [
  null,
  "關於"
 ],
 "Account": [
  null,
  "帳戶"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Add another server...": [
  null,
  "新增另一台伺服器..."
 ],
 "Add mount": [
  null,
  "新增掛載"
 ],
 "Add-ons for your chosen environment": [
  null,
  ""
 ],
 "Add-ons not specific to your environment": [
  null,
  ""
 ],
 "Additional languages": [
  null,
  "其他語言"
 ],
 "Additional software for the selected environment": [
  null,
  "所選環境的附加軟件"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "在儲存編輯器中所做的所有變更都會立即生效。"
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "所有使用此密碼的裝置都將解鎖"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda 網絡介面"
 ],
 "Anaconda project page": [
  null,
  "Anaconda 專案頁面"
 ],
 "Apply mount point assignment and install": [
  null,
  "應用掛載點分配並安裝"
 ],
 "Applying changes...": [
  null,
  ""
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "將分割區分配給掛載點。對於預先配置的自訂佈局很有用。"
 ],
 "Automatic log file upload": [
  null,
  ""
 ],
 "Automatically set date and time, using time servers": [
  null,
  ""
 ],
 "Automatically set timezone": [
  null,
  ""
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "可用空間：$0。安裝需要：$1。"
 ],
 "Back": [
  null,
  "後退"
 ],
 "Base environment": [
  null,
  ""
 ],
 "Bugzilla API key": [
  null,
  ""
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "繼續使用此軟件，即表示您理解並接受預發布軟體所涉及的風險，且確認僅將此軟件用於測試與開發目的，並願意報告任何錯誤或問題以協助完善此作品。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change": [
  null,
  "改變"
 ],
 "Change destination": [
  null,
  "修改目標位置"
 ],
 "Change hostname": [
  null,
  "更改主機名"
 ],
 "Change partition layout": [
  null,
  "更改磁碟區佈局"
 ],
 "Change system keyboard layout": [
  null,
  "更改系統鍵盤佈局"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "此處所做的變更將立即影響系統。沒有‘撤銷’。"
 ],
 "Checking storage configuration": [
  null,
  "檢查儲存配置"
 ],
 "Clear search": [
  null,
  "清除搜尋"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  ""
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Close storage editor": [
  null,
  "關閉儲存編輯器"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit 儲存沒有提供解鎖加密裝置的密碼。"
 ],
 "Completed": [
  null,
  "完全的"
 ],
 "Configuration is incomplete": [
  null,
  ""
 ],
 "Configure NTP servers": [
  null,
  "配置 NTP 伺服器"
 ],
 "Configure custom NTP servers": [
  null,
  "配置自定義 NTP 伺服器"
 ],
 "Configure storage": [
  null,
  "配置儲存"
 ],
 "Configure storage again": [
  null,
  "再次配置儲存"
 ],
 "Confirm passphrase": [
  null,
  "確認密碼"
 ],
 "Continue": [
  null,
  "繼續"
 ],
 "Continue installation": [
  null,
  "繼續安裝"
 ],
 "Continue with installation": [
  null,
  "繼續安裝"
 ],
 "Create Account": [
  null,
  "建立帳戶"
 ],
 "Create account": [
  null,
  "建立帳戶"
 ],
 "Currently installed: $0": [
  null,
  "目前安裝：$0"
 ],
 "Custom": [
  null,
  "自訂"
 ],
 "Date": [
  null,
  ""
 ],
 "Date and time": [
  null,
  ""
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "刪除某些分割區可能會導致$0無法啟動：$1"
 ],
 "Description": [
  null,
  "細節"
 ],
 "Destination": [
  null,
  "目標位置"
 ],
 "Destination is encrypted": [
  null,
  "目標位置已加密"
 ],
 "Detected valid storage layout:": [
  null,
  "偵測到有效的儲存佈局："
 ],
 "Device": [
  null,
  "設備"
 ],
 "Duplicate device.": [
  null,
  "重複的設備。"
 ],
 "Duplicate mount point.": [
  null,
  "重複的掛載點。"
 ],
 "Enable root account": [
  null,
  "啟用 root 帳戶"
 ],
 "Encrypt my data": [
  null,
  "加密我的數據"
 ],
 "Encrypted": [
  null,
  "已加密"
 ],
 "Encryption": [
  null,
  "加密"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  ""
 ],
 "Environment": [
  null,
  ""
 ],
 "Erase data and install": [
  null,
  "清除資料並安裝"
 ],
 "Error details": [
  null,
  "錯誤詳細訊息"
 ],
 "Exit to live desktop": [
  null,
  "退出到 live 桌面"
 ],
 "Extended partition": [
  null,
  "擴充分區"
 ],
 "Failed to save layouts": [
  null,
  "儲存佈局失敗"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora linux 至少需要 $0 的磁碟空間。"
 ],
 "Finalization": [
  null,
  "完成"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "最終確定：系統配置已完成。完成安裝可能需要一些時間。"
 ],
 "Find layout": [
  null,
  "尋找佈局"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  ""
 ],
 "Full name": [
  null,
  "全名"
 ],
 "Full name cannot contain colon characters": [
  null,
  "全名不能包含冒號"
 ],
 "Helper text": [
  null,
  ""
 ],
 "Hide API key": [
  null,
  ""
 ],
 "Hide PIN": [
  null,
  ""
 ],
 "Hide confirmed password": [
  null,
  "隱藏確認密碼"
 ],
 "Hide passphrase": [
  null,
  "隱藏密碼"
 ],
 "Hide password": [
  null,
  "隱藏密碼"
 ],
 "Hostname": [
  null,
  "主機名稱"
 ],
 "How would you like to install?": [
  null,
  "您想如何安裝？"
 ],
 "I understand that some existing data will be erased": [
  null,
  "我了解部分現有數據將被刪除"
 ],
 "I understand that some partitions will be modified": [
  null,
  "我理解有些分割區會被修改"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "如果為空，主機名將是臨時的並由網路資訊設定。"
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "如果要配置分割區，則需要以下內容："
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  ""
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "如果您不了解或不接受風險，請退出此程序。"
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "進行中"
 ],
 "Initializing...": [
  null,
  "正在初始化..."
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Installation failed": [
  null,
  "安裝失敗"
 ],
 "Installation method": [
  null,
  "安裝方法"
 ],
 "Installation of the system failed": [
  null,
  "系統安裝失敗"
 ],
 "Installation of the system failed: $0": [
  null,
  "系統安裝失敗：$0"
 ],
 "Installation type": [
  null,
  "安裝類型"
 ],
 "Installing": [
  null,
  "正在安裝"
 ],
 "Insufficient disk space": [
  null,
  ""
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "偵測到無效的 RAID 配置。如果您的 RAID 陣列直接在磁碟上建立，則必須在陣列上建立分割區表。如果您的 RAID 陣列是在分割區之上建立的，則它必須包含單一檔案系統或格式（例如，LVM PV）。此陣列上的任何現有分割區都將被忽略。"
 ],
 "Invalid hostname": [
  null,
  "無效的主機名稱"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "保留目前磁碟佈局並使用可用空間，以便與另一個作業系統雙重啟動。"
 ],
 "Keyboard": [
  null,
  "鍵盤"
 ],
 "Keyboard layout during boot": [
  null,
  "啟動期間的鍵盤佈局"
 ],
 "Language": [
  null,
  "語言"
 ],
 "Launch storage editor": [
  null,
  "啟動儲存編輯器"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  ""
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "地點"
 ],
 "Locked devices": [
  null,
  "鎖定的設備"
 ],
 "Log in": [
  null,
  ""
 ],
 "Make current": [
  null,
  ""
 ],
 "Manual disk configuration": [
  null,
  "手動磁碟配置"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "手動磁碟配置：掛載點映射"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "可能包含字母、數字和破折號。"
 ],
 "May need more free space": [
  null,
  "可能需要更多可用空間"
 ],
 "Medium": [
  null,
  "中等的"
 ],
 "Minimum of $0 required": [
  null,
  ""
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "父設備和子設備重新格式化選擇不符。"
 ],
 "Mount point": [
  null,
  "掛載點"
 ],
 "Mount point assignment": [
  null,
  "掛載點分配"
 ],
 "Move down": [
  null,
  ""
 ],
 "Move up": [
  null,
  ""
 ],
 "Must be at least $0 characters": [
  null,
  "必須至少包含 $0 個字符"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  ""
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Needs at least $0": [
  null,
  ""
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "網路不可用。在頂部欄選單中配置網路以報告問題。"
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "網路不可用。配置網路以報告問題。"
 ],
 "Next": [
  null,
  "下一個"
 ],
 "No devices": [
  null,
  "沒有設備"
 ],
 "No disks available": [
  null,
  "沒有可用的磁碟"
 ],
 "No disks selected": [
  null,
  "尚未選取磁碟"
 ],
 "No layouts selected yet": [
  null,
  "尚未選取佈局"
 ],
 "No results found": [
  null,
  "未找到結果"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  ""
 ],
 "Not enough available free space": [
  null,
  "可用空間不足"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "所選磁碟上沒有足夠的可用空間。"
 ],
 "Not enough space on selected disks.": [
  null,
  "所選磁碟上的空間不足。"
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "注意：這是預發布的軟體，僅用於開發和測試目的。請勿將此軟體用於任何關鍵工作或生產環境。"
 ],
 "Open Bugzilla bug entry form": [
  null,
  ""
 ],
 "Operating system": [
  null,
  "作業系統"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Other keyboards": [
  null,
  "其他鍵盤"
 ],
 "Partitions (advanced)": [
  null,
  "分區（高級）"
 ],
 "Passphrase": [
  null,
  "密碼"
 ],
 "Passphrase did not match any locked device": [
  null,
  "密碼與任何鎖定的裝置均不匹配"
 ],
 "Passphrases must match": [
  null,
  "密碼必須匹配"
 ],
 "Pending": [
  null,
  "待辦的"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "請將日誌檔案 $0 附加到該問題。"
 ],
 "Please enter a PIN": [
  null,
  ""
 ],
 "Please select at least one disk to continue": [
  null,
  "請選擇至少一個磁碟以繼續"
 ],
 "Pool": [
  null,
  ""
 ],
 "Potential duplicate bugs found": [
  null,
  ""
 ],
 "Powered by Anaconda": [
  null,
  "由 Anaconda 提供支持"
 ],
 "Pre-release": [
  null,
  "預發布"
 ],
 "Prefer to report manually? $0": [
  null,
  ""
 ],
 "Proceed with installation": [
  null,
  "繼續安裝"
 ],
 "Quit": [
  null,
  "退出"
 ],
 "Quit installer?": [
  null,
  "退出安裝程式？"
 ],
 "Reading information about the OS failed.": [
  null,
  "讀取作業系統的資訊失敗。"
 ],
 "Reading information about the computer failed.": [
  null,
  "讀取有關計算機的資訊失敗。"
 ],
 "Reading installer configuration failed.": [
  null,
  "讀取安裝程式配置失敗。"
 ],
 "Reading installer version information failed.": [
  null,
  "讀取安裝程式版本資訊失敗。"
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "真實主機名稱只能包含字元、數字、破折號（不是開始或結束字元）和點"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "實際主機名稱必須不超過 64 個字符"
 ],
 "Reboot": [
  null,
  "重啟"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "重新啟動 Windows 以調整 BitLocker 加密分割區的大小。提供至少 $0 的可用空間用於安裝。"
 ],
 "Reboot system?": [
  null,
  "重啟系統？"
 ],
 "Reclaim additional space": [
  null,
  "回收更多空間"
 ],
 "Reclaim space": [
  null,
  "回收空間"
 ],
 "Reclaim space (required)": [
  null,
  "回收空間（必需）"
 ],
 "Recommended": [
  null,
  "推薦的"
 ],
 "Recommended partitions:": [
  null,
  "建議的分區："
 ],
 "Reformat": [
  null,
  "重新格式化"
 ],
 "Reinstall Fedora": [
  null,
  "重新安裝 Fedora"
 ],
 "Remove": [
  null,
  "消除"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "刪除所選設備上的所有分割區，包括現有作業系統。"
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "刪除或調整現有檔案系統的大小以釋放安裝空間。"
 ],
 "Remove server": [
  null,
  "移除伺服器"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "刪除檔案系統將永久刪除其中包含的所有資料。調整分割區大小可以釋放未使用的空間，但並非沒有風險。在回收空間之前，請務必備份所有重要內容。"
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "替換目前安裝，但將檔案保留在主目錄中。"
 ],
 "Report Issue": [
  null,
  "報告問題"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  ""
 ],
 "Report issue": [
  null,
  "報告問題"
 ],
 "Required": [
  null,
  "必需的"
 ],
 "Requirements": [
  null,
  "要求"
 ],
 "Rescan devices": [
  null,
  "重新掃描設備"
 ],
 "Rescanning of the disks failed.": [
  null,
  "重新掃描磁碟失敗。"
 ],
 "Resize": [
  null,
  "調整大小"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "從 $0 調整下列分割區的大小：$1"
 ],
 "Restrict access to the report": [
  null,
  ""
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  ""
 ],
 "Return to installation": [
  null,
  "返回安裝"
 ],
 "Return to storage editor": [
  null,
  "返回存儲編輯器"
 ],
 "Review and install": [
  null,
  "查看並安裝"
 ],
 "Root account is enabled": [
  null,
  "Root 帳號已啟用"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  ""
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "使用手機掃描二維碼或存取："
 ],
 "Search for a language": [
  null,
  "搜尋語言"
 ],
 "Search for additional software": [
  null,
  "搜尋附加軟件"
 ],
 "Search for an environment": [
  null,
  "搜尋環境"
 ],
 "Search keyboard layout": [
  null,
  "搜尋鍵盤佈局"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "使用基於磁碟的加密來保護您的資料。僅適用於新分區"
 ],
 "Select": [
  null,
  "選擇"
 ],
 "Select a device": [
  null,
  "選擇設備"
 ],
 "Select city": [
  null,
  "選擇城市"
 ],
 "Select destination": [
  null,
  "選擇目標位置"
 ],
 "Select region": [
  null,
  "選擇地區"
 ],
 "Selected (top = current)": [
  null,
  ""
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "所選設備的格式「$0」無法重新格式化。"
 ],
 "Send us feedback on your installation": [
  null,
  "向我們發送有關您的安裝的回饋"
 ],
 "Server": [
  null,
  "伺服器"
 ],
 "Server is not reachable": [
  null,
  ""
 ],
 "Set custom hostname": [
  null,
  "設定自訂主機名"
 ],
 "Share disk with other operating systems": [
  null,
  "與其他作業系統共享磁碟"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "與其他作業系統共享磁碟：$0"
 ],
 "Show AM/PM": [
  null,
  ""
 ],
 "Show API key": [
  null,
  ""
 ],
 "Show PIN": [
  null,
  ""
 ],
 "Show confirmed password": [
  null,
  "顯示確認密碼"
 ],
 "Show passphrase": [
  null,
  "顯示密碼"
 ],
 "Show password": [
  null,
  "顯示密碼"
 ],
 "Size": [
  null,
  "尺寸"
 ],
 "Software installation": [
  null,
  "軟體安裝"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "軟體安裝：儲存配置完成。軟體現在正在安裝到您的裝置上。"
 ],
 "Software selection": [
  null,
  "軟體選擇"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  ""
 ],
 "Some required partitions are missing: $0": [
  null,
  "缺少一些必需的分區：$0"
 ],
 "Space": [
  null,
  "空間"
 ],
 "Stacktrace": [
  null,
  ""
 ],
 "Storage": [
  null,
  "儲存"
 ],
 "Storage configuration": [
  null,
  "儲存配置"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "儲存配置：目前正在配置儲存。"
 ],
 "Storage editor": [
  null,
  "儲存編輯器"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "儲存基於‘修改儲存’的配置。"
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  ""
 ],
 "Storage plugin failed": [
  null,
  "儲存插件失敗"
 ],
 "Storage requirements not met": [
  null,
  "未滿足儲存要求"
 ],
 "Strong": [
  null,
  "強固"
 ],
 "Successfully installed": [
  null,
  "安裝成功"
 ],
 "Successfully unlocked $0.": [
  null,
  "成功解鎖$0。"
 ],
 "Suggested keyboards": [
  null,
  "建議的鍵盤"
 ],
 "Suggested languages": [
  null,
  "建議語言"
 ],
 "System": [
  null,
  "系統"
 ],
 "System configuration": [
  null,
  "系統配置"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "系統設定：軟體安裝完成。系統正在配置中。"
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  ""
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  ""
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "安裝需要$0的磁碟空間；但所選磁碟的容量僅為$1。"
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "由於嚴重錯誤，安裝程式無法繼續。"
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "由於嚴重錯誤，安裝程式無法繼續：$0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "您提供的密碼包含非 ASCII 字元。打字時您可能無法切換鍵盤佈局。"
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  ""
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "儲存編輯器可讓您調整大小、刪除和建立分割區。它可以設定 LVM 等等。它旨在用作高級實用程序，並不適合在典型的安裝中使用。"
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  ""
 ],
 "This hostname can't be submitted": [
  null,
  "無法提交此主機名"
 ],
 "This is unstable, pre-release software": [
  null,
  "這是不穩定的預發佈軟體"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "此佈局將用於在啟動時解鎖系統"
 ],
 "This may take a moment": [
  null,
  "這可能需要一點時間"
 ],
 "This will take a few moments": [
  null,
  "這需要一些時間"
 ],
 "Time": [
  null,
  ""
 ],
 "Timezone": [
  null,
  "時區"
 ],
 "Title": [
  null,
  ""
 ],
 "To begin using $0, reboot your system.": [
  null,
  "若要開始使用 $0，請重新啟動系統。"
 ],
 "To continue, select the devices to install to.": [
  null,
  "若要繼續，請選擇要安裝的設備。"
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "若要使用此選項，請調整大小或刪除現有分割區以釋放至少 $0。"
 ],
 "Type": [
  null,
  "類型"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "無法安排刪除 $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "無法安排調整 $0 的大小"
 ],
 "Undo last action": [
  null,
  ""
 ],
 "Unlock": [
  null,
  "開鎖"
 ],
 "Unlock encrypted devices": [
  null,
  "解鎖加密設備"
 ],
 "Use configured storage": [
  null,
  "使用配置的存儲"
 ],
 "Use entire disk": [
  null,
  "使用整個磁碟"
 ],
 "Use free space": [
  null,
  "使用可用空間"
 ],
 "Use local account": [
  null,
  "使用本地帳戶"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "使用 RAID 設備進行自動分割區"
 ],
 "User name": [
  null,
  "使用者名稱"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "使用者名稱只能包含：a-z 字母、0-9 數字、破折號 $0、句點 $1、底線 $2"
 ],
 "User name must not be a reserved word": [
  null,
  "使用者名稱不能是保留字"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "使用者名稱必須少於 33 個字符"
 ],
 "Weak": [
  null,
  "脆弱"
 ],
 "Welcome": [
  null,
  "歡迎"
 ],
 "Welcome to Fedora Linux": [
  null,
  "歡迎使用 Fedora Linux"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "歡迎。現在讓我們安裝$0。"
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  ""
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "使用 BitLocker 加密的 Windows 分割區無法調整大小"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "您可以在此處釋放足夠的空間並讓安裝程式處理其餘部分，或手動設定分割區。"
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  ""
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  ""
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "你必須連線至網絡才能啟用自動設置日期與時間。"
 ],
 "Your progress will not be saved.": [
  null,
  "你的進度不會被保存。"
 ],
 "completed step": [
  null,
  "完成步驟"
 ],
 "current step": [
  null,
  "目前步驟"
 ],
 "delete": [
  null,
  "刪除"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "encrypt": [
  null,
  "加密"
 ],
 "encrypted": [
  null,
  "已加密"
 ],
 "extended partition": [
  null,
  "擴充分區"
 ],
 "format as $0": [
  null,
  "格式為 $0"
 ],
 "here": [
  null,
  ""
 ],
 "mount": [
  null,
  "掛載"
 ],
 "pending step": [
  null,
  "待處理步驟"
 ],
 "report the issue manually": [
  null,
  ""
 ],
 "resized from $0": [
  null,
  "從 $0 調整為"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "shrink to $0": [
  null,
  "縮減至 $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "撤銷"
 ]
});
