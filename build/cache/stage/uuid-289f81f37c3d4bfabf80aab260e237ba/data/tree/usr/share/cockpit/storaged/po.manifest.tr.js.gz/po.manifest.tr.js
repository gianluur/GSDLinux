cockpit.locale({
 "": {
  "plural-forms": ((n) => (n>1)),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Networking": [
  null,
  "Ağ"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "unmount": [
  null,
  "bağlantıyı kaldır"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "format": [
  null,
  "biçim"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "filesystem": [
  null,
  "dosya sistemi"
 ],
 "partition": [
  null,
  "bölüm"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "raid": [
  null,
  "raid"
 ],
 "volume": [
  null,
  "birim"
 ],
 "disk": [
  null,
  "disk"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "drive": [
  null,
  "sürücü"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "luks": [
  null,
  "luks"
 ],
 "encryption": [
  null,
  "şifreleme"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "tang": [
  null,
  "tang"
 ],
 "Managing partitions": [
  null,
  "Bölümleri yönetme"
 ],
 "Managing NFS mounts": [
  null,
  "NFS bağlamalarını yönetme"
 ],
 "Managing RAIDs": [
  null,
  "RAID'leri yönetme"
 ],
 "Managing LVMs": [
  null,
  "LVM'leri yönetme"
 ],
 "Managing physical drives": [
  null,
  "Fiziksel sürücüleri yönetme"
 ],
 "Managing VDOs": [
  null,
  "VDO'ları yönetme"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS şifrelemesi kullanma"
 ],
 "Using Tang server": [
  null,
  "Tang sunucusu kullanma"
 ]
});
