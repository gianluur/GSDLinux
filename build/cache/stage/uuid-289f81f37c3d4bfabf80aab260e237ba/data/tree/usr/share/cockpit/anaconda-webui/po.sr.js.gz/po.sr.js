cockpit.locale({
 "": {
  "plural-forms": ((n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "sr",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 грешка",
  "$0 грешке",
  "$0 грешака"
 ],
 "$0 installation": [
  null,
  "$0 инсталација"
 ],
 "$0 installer": [
  null,
  "$0 инсталатер"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 је МБР проширена партиција која садржи логичке партиције. Уклањање свих логичких партиција ће такође аутоматски уклонити проширену партицију."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 је потребно, али је доступно само $1."
 ],
 "$0 warning": [
  null,
  "$0 упозорење",
  "$0 упозорења",
  "$0 упозорења"
 ],
 "$0 will be deleted": [
  null,
  "$0 ће бити обрисано"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Систем датотека „$0“ не може бити на шифрованом блок уређају"
 ],
 "'$0' must be assigned to $1": [
  null,
  "„$0“ мора бити додељен ка „$1“"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "„$0“ мора бити на уређају форматираном као „$1“"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  "„$0“ мора бити ЕФИ системска партиција. Изабрана партиција користи ФАТ систем датотека, али није означена као ЕСП. Поставите врсту партиције на ЕФИ системску и омогућите есп заставицу."
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Пронађена је партиција „$0“ на MDRAID уређају $1. Партиције покретача система на MDRAID уређајима нису подржане."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Уобичајени кориснички налог са админ приступом за вршење измена на нивоу целог система."
 ],
 "Abort installation": [
  null,
  "Прекини инсталирање"
 ],
 "About": [
  null,
  "О програму"
 ],
 "Account": [
  null,
  "Налог"
 ],
 "Actions": [
  null,
  "Радње"
 ],
 "Add another server...": [
  null,
  "Додај још један сервер..."
 ],
 "Add mount": [
  null,
  "Додај тачку качења"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Додаци за ваше изабрано окружење"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Додаци који нису специфични за ваше окружење"
 ],
 "Additional languages": [
  null,
  "Додадни језици"
 ],
 "Additional software for the selected environment": [
  null,
  "Додатни програми за изабрано окружење"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Све измене направљене у уређивачу складишта ступају на снагу одмах."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Сви уређаји који користе ову лозинку биће откључани"
 ],
 "Anaconda Web UI": [
  null,
  "Веб прочеље Анаконде"
 ],
 "Anaconda project page": [
  null,
  "Страница пројекта Анаконда"
 ],
 "Apply mount point assignment and install": [
  null,
  "Примени доделу тачака качења и инсталирај"
 ],
 "Applying changes...": [
  null,
  "Примењујем измене..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Доделите партиције тачкама качења. Корисно за унапред подешене произвољне распореде."
 ],
 "Automatic log file upload": [
  null,
  "Самостално отпремање датотеке дневника"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Самостално постави датум и време, користећи сервере времена"
 ],
 "Automatically set timezone": [
  null,
  "Самостално постави временску зону"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Доступно слободног простора: $0. Инсталација захтева: $1."
 ],
 "Back": [
  null,
  "Назад"
 ],
 "Base environment": [
  null,
  "Основно окружење"
 ],
 "Brief description of the issue": [
  null,
  "Кратак опис проблема"
 ],
 "Bug report details": [
  null,
  "Детаљи извештаја о грешци"
 ],
 "Bugzilla API key": [
  null,
  "Багзила АПИ кључ"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Наставком коришћења овог софтвера, разумете и прихватате ризике повезане са пре-издатим софтвером, да га намеравате користити само за сврхе тестирања и развоја и да сте вољни да пријавите све грешке или проблеме како бисте побољшали овај рад."
 ],
 "Cancel": [
  null,
  "Одустани"
 ],
 "Change": [
  null,
  "Промени"
 ],
 "Change destination": [
  null,
  "Промени одредиште"
 ],
 "Change hostname": [
  null,
  "Промени назив домаћина"
 ],
 "Change partition layout": [
  null,
  "Промени распоред партиција"
 ],
 "Change system keyboard layout": [
  null,
  "Промени системски распоред тастатуре"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Измене направљене овде ће одмах утицати на систем. Нема „опозива“."
 ],
 "Checking installation configuration...": [
  null,
  "Проверавам подешавања инсталације..."
 ],
 "Checking storage configuration": [
  null,
  "Провера подешавања складишта"
 ],
 "Clear search": [
  null,
  "Очисти претрагу"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Кликните поново на „Следеће“ да наставите упркос овим упозорењима."
 ],
 "Close": [
  null,
  "Затвори"
 ],
 "Close storage editor": [
  null,
  "Затвори уређивач складишта"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Кокпит складиште није доставило лозинку за откључавање шифрованог уређаја."
 ],
 "Completed": [
  null,
  "Завршено"
 ],
 "Configuration is incomplete": [
  null,
  "Подешавање није довршено"
 ],
 "Configure NTP servers": [
  null,
  "Подеси NTP сервере"
 ],
 "Configure custom NTP servers": [
  null,
  "Подеси произвољне NTP сервере"
 ],
 "Configure network": [
  null,
  "Подеси мрежу"
 ],
 "Configure storage": [
  null,
  "Подеси складиште"
 ],
 "Configure storage again": [
  null,
  "Поново подеси складиште"
 ],
 "Confirm passphrase": [
  null,
  "Потврди лозинку"
 ],
 "Continue": [
  null,
  "Настави"
 ],
 "Continue installation": [
  null,
  "Настави инсталацију"
 ],
 "Continue installation?": [
  null,
  "Настави инсталирање?"
 ],
 "Continue with installation": [
  null,
  "Настави са инсталацијом"
 ],
 "Correct these issues before continuing.": [
  null,
  "Поправите ове грешке пре наставка."
 ],
 "Create Account": [
  null,
  "Направи налог"
 ],
 "Create account": [
  null,
  "Направи налог"
 ],
 "Currently installed: $0": [
  null,
  "Тренутно инсталирано: $0"
 ],
 "Custom": [
  null,
  "Прилагођено"
 ],
 "Date": [
  null,
  "Датум"
 ],
 "Date and time": [
  null,
  "Датум и време"
 ],
 "Delete partition": [
  null,
  "Обриши партицију"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Брисање одређених партиција може спречити $0 да се покрене: $1"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Destination": [
  null,
  "Одредиште"
 ],
 "Destination is encrypted": [
  null,
  "Одредиште је шифровано"
 ],
 "Detailed description of the issue": [
  null,
  "Детаљан опис проблема"
 ],
 "Detected valid storage layout:": [
  null,
  "Откривен је исправан распоред складишта:"
 ],
 "Device": [
  null,
  "Уређај"
 ],
 "Duplicate device.": [
  null,
  "Удвостручени уређај."
 ],
 "Duplicate mount point.": [
  null,
  "Удвостручена тачка качења."
 ],
 "Enable root account": [
  null,
  "Омогући админ налог"
 ],
 "Encrypt my data": [
  null,
  "Шифруј моје податке"
 ],
 "Encrypted": [
  null,
  "Шифровано"
 ],
 "Encryption": [
  null,
  "Шифровање"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Унесите свој АПИ кључ за Бубаждају (Bugzilla) да бисте направили извештај о грешци. Моћи ћете да прегледате и уредите детаље о грешци у следећем кораку."
 ],
 "Environment": [
  null,
  "Окружење"
 ],
 "Erase data and install": [
  null,
  "Обриши податке и инсталирај"
 ],
 "Error details": [
  null,
  "Појединости грешке"
 ],
 "Exit to live desktop": [
  null,
  "Изађи у живо окружење радне површи"
 ],
 "Extended partition": [
  null,
  "Проширена партиција"
 ],
 "Failed to report issue": [
  null,
  "Није успело пријављивање проблема"
 ],
 "Failed to save layouts": [
  null,
  "Није успело чување распореда"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Федора Линукс захтева најмање $0 простора на диску."
 ],
 "Finalization": [
  null,
  "Довршавање"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Довршавање: Подешавање система је завршено. Довршавање инсталације може потрајати неколико тренутака."
 ],
 "Find layout": [
  null,
  "Пронађи распоред"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Ради боље безбедности, избегавајте директно коришћење админ налога. Уместо тога, користите горњи локални налог за управљање системом."
 ],
 "Full name": [
  null,
  "Име и презиме"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Име и презиме не смеју садржати две тачке"
 ],
 "Helper text": [
  null,
  "Помоћни текст"
 ],
 "Hide API key": [
  null,
  "Сакриј АПИ кључ"
 ],
 "Hide confirmed password": [
  null,
  "Сакриј потврђену лозинку"
 ],
 "Hide passphrase": [
  null,
  "Сакриј лозинку"
 ],
 "Hide password": [
  null,
  "Сакриј лозинку"
 ],
 "Hostname": [
  null,
  "Назив домаћина"
 ],
 "How would you like to install?": [
  null,
  "Како желите да инсталирате?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Разумем да ће сви постојећи подаци бити обрисани",
  "Разумем да ће сви постојећи подаци бити обрисани са изабраних дискова",
  "Разумем да ће сви постојећи подаци бити обрисани са изабраних дискова"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Разумем да ће неки постојећи подаци бити обрисани"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Разумем да ће неке партиције бити измењене"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Ако је празно, назив домаћина ће бити привремен и постављен на основу мрежних података."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Ако подешавате партиције, следеће је потребно:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Ако не пристајете на самостално слање датотека дневника, можете уместо тога $0. Ручно пријављивање вам омогућава да сами прегледате и селективно приложите датотеке дневника."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Ако не разумете или не прихватате ризике, изађите из овог програма."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "У току"
 ],
 "Initializing...": [
  null,
  "Покрећем..."
 ],
 "Install": [
  null,
  "Инсталирај"
 ],
 "Installation failed": [
  null,
  "Инсталирање није успело"
 ],
 "Installation method": [
  null,
  "Начин инсталације"
 ],
 "Installation of the system failed": [
  null,
  "Инсталација система није успела"
 ],
 "Installation of the system failed: $0": [
  null,
  "Инсталација система није успела: $0"
 ],
 "Installation type": [
  null,
  "Врста инсталације"
 ],
 "Installing": [
  null,
  "Инсталирање"
 ],
 "Insufficient disk space": [
  null,
  "Недовољно простора на диску"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Откривено је неисправно RAID подешавање. Ако је ваш RAID низ направљен директно на дисковима, на низу се мора направити партициона табела. Ако је ваш RAID низ направљен на партицијама, он мора да садржи један систем датотека или формат (нпр. LVM PV). Све постојеће партиције на овом низу ће бити занемарене."
 ],
 "Invalid hostname": [
  null,
  "Неисправно име домаћина"
 ],
 "Jump to first incomplete step": [
  null,
  "Скочи на први недовршени корак"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Задржи тренутни распоред диска и користи доступан простор за упоредно покретање са другим ОС."
 ],
 "Keyboard": [
  null,
  "Тастатура"
 ],
 "Keyboard layout during boot": [
  null,
  "Распоред тастатуре током покретања"
 ],
 "Language": [
  null,
  "Језик"
 ],
 "Launch storage editor": [
  null,
  "Покрени уређивач складишта"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Сазнајте више о ограниченом приступу у подешавањима"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  "Оставите оба поља лозинке празним да бисте користили празну лозинку."
 ],
 "Location": [
  null,
  "Локација"
 ],
 "Locked devices": [
  null,
  "Закључани уређаји"
 ],
 "Make current": [
  null,
  "Учини тренутним"
 ],
 "Manual disk configuration": [
  null,
  "Ручно подешавање диска"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Ручно подешавање диска: мапирање тачке качења"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Може да садржи слова, бројеве и цртице."
 ],
 "May need more free space": [
  null,
  "Можда је потребно више слободног простора"
 ],
 "Medium": [
  null,
  "Средња"
 ],
 "Minimum of $0 required": [
  null,
  "Најмање $0 је потребно"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Неподударање између избора поновног форматирања родитељског и садржаног уређаја."
 ],
 "Mount point": [
  null,
  "Тачка качења"
 ],
 "Mount point assignment": [
  null,
  "Додела тачке качења"
 ],
 "Move down": [
  null,
  "Помери доле"
 ],
 "Move up": [
  null,
  "Помери горе"
 ],
 "Must be at least $0 characters": [
  null,
  "Мора имати најмање $0 знакова"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP сервери"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Име"
 ],
 "Needs at least $0": [
  null,
  "Потребно је најмање $0"
 ],
 "Network": [
  null,
  "Мрежа"
 ],
 "Network Configuration": [
  null,
  "Подешавање мреже"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Мрежа није доступна. Подесите мрежу у менију на горњој траци да бисте пријавили проблем."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Мрежа није доступна. Подесите мрежу да бисте пријавили проблем."
 ],
 "Network plugin failed": [
  null,
  "Прикључак за мрежу није успео"
 ],
 "Next": [
  null,
  "Следећа"
 ],
 "No devices": [
  null,
  "Нема уређаја"
 ],
 "No disks available": [
  null,
  "Нема доступних дискова"
 ],
 "No disks selected": [
  null,
  "Нема одабраних дискова"
 ],
 "No layouts selected yet": [
  null,
  "Још увек нема изабраних распореда"
 ],
 "No results found": [
  null,
  "Нема резултата"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Није могуће добити исправну VConsole мапу тастера за изабране распореде тастатуре. Молимо направите другачији избор распореда тастатуре."
 ],
 "Not enough available free space": [
  null,
  "Нема довољно доступног слободног простора"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Нема довољно слободног простора на изабраним дисковима."
 ],
 "Not enough space on selected disks.": [
  null,
  "Нема довољно простора на изабраним дисковима."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Обавештење: Ово је пред-издање софтвера које је намењено само за развој и тестирање. НЕМОЈТЕ користити овај софтвер за било какав критичан рад или за продукциона окружења."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Отвори образац за унос грешке у Бубаждаји"
 ],
 "Operating system": [
  null,
  "Оперативни систем"
 ],
 "Options": [
  null,
  "Опције"
 ],
 "Other keyboards": [
  null,
  "Друге тастатуре"
 ],
 "Partitions (advanced)": [
  null,
  "Партиције (напредно)"
 ],
 "Passphrase": [
  null,
  "Лозинка"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Лозинка се не подудара ни са једним закључаним уређајем"
 ],
 "Passphrases must match": [
  null,
  "Лозинке се морају подударати"
 ],
 "Pending": [
  null,
  "У току"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Приложите датотеку дневника $0 уз овај проблем."
 ],
 "Please select at least one disk to continue": [
  null,
  "Изаберите барем један диск да бисте наставили"
 ],
 "Pool": [
  null,
  "Депо"
 ],
 "Powered by Anaconda": [
  null,
  "Покреће Анаконда"
 ],
 "Pre-release": [
  null,
  "Пред-издање"
 ],
 "Prefer to report manually? $0": [
  null,
  "Желите ли да пријавите ручно? $0"
 ],
 "Proceed with installation": [
  null,
  "Настави са инсталацијом"
 ],
 "Quit": [
  null,
  "Излаз"
 ],
 "Quit installer?": [
  null,
  "Напустити инсталатер?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Читање података о оперативном систему није успело."
 ],
 "Reading information about the computer failed.": [
  null,
  "Читање података о рачунару није успело."
 ],
 "Reading installer configuration failed.": [
  null,
  "Читање подешавања инсталатера није успело."
 ],
 "Reading installer version information failed.": [
  null,
  "Читање података о верзији инсталатера није успело."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Право име домаћина може садржати само слова, цифре, цртице (које не почињу нити завршавају назив) и тачке"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Право име домаћина мора имати 64 знака или мање"
 ],
 "Reboot": [
  null,
  "Поново покрени"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Поново покрените систем у Виндоуз како бисте променили величину партиција шифрованих БитЛокером. Обезбедите барем $0 слободног простора за инсталацију."
 ],
 "Reboot system?": [
  null,
  "Поново покренути систем?"
 ],
 "Reclaim additional space": [
  null,
  "Ослободи додатни простор"
 ],
 "Reclaim space": [
  null,
  "Ослободи простор"
 ],
 "Reclaim space (required)": [
  null,
  "Ослободи простор (обавезно)"
 ],
 "Recommended": [
  null,
  "Препоручено"
 ],
 "Recommended partitions:": [
  null,
  "Препоручене партиције:"
 ],
 "Reformat": [
  null,
  "Поново форматирај"
 ],
 "Reinstall Fedora": [
  null,
  "Поново инсталирај Федору"
 ],
 "Remove": [
  null,
  "Уклони"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Уклоните све партиције на изабраним уређајима, укључујући постојеће оперативне системе."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Уклоните или промените величину постојећих система датотека како бисте ослободили простор за инсталацију."
 ],
 "Remove server": [
  null,
  "Уклони сервер"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Уклањање система датотека ће трајно обрисати све податке које садржи. Промена величине партиције може ослободити некоришћени простор, али није без ризика. Обавезно направите резервне копије свега важног пре ослобађања простора."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Замени тренутну инсталацију, али задржи датотеке у личној фасцикли."
 ],
 "Report Issue": [
  null,
  "Пријави проблем"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Пријавите проблем или пошаљите повратне информације отварањем обрасца за унос грешке у Бугзили $0."
 ],
 "Report issue": [
  null,
  "Пријави проблем"
 ],
 "Reporting issue...": [
  null,
  "Пријављивање проблема..."
 ],
 "Required": [
  null,
  "Обавезно"
 ],
 "Requirements": [
  null,
  "Захтеви"
 ],
 "Rescan devices": [
  null,
  "Поново претражи уређаје"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Поновно претраживање дискова није успело."
 ],
 "Resize": [
  null,
  "Промени величину"
 ],
 "Resize partition": [
  null,
  "Промени величину партиције"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Промена величине следећих партиција са $0: $1"
 ],
 "Restrict access to the report": [
  null,
  "Ограничи приступ извештају"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Ограничава извештај на групу $0. $1"
 ],
 "Return to installation": [
  null,
  "Врати се на инсталацију"
 ],
 "Return to storage editor": [
  null,
  "Врати се у уређивач складишта"
 ],
 "Review and install": [
  null,
  "Прегледај и инсталирај"
 ],
 "Root account is enabled": [
  null,
  "Админ налог је омогућен"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Админ налог је омогућен, али ниједан кориснички налог није подешен"
 ],
 "Root password has been set.": [
  null,
  "Лозинка админа је постављена."
 ],
 "Save": [
  null,
  "Сачувај"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Скенирајте КР код телефоном или посетите:"
 ],
 "Search for a language": [
  null,
  "Претражите језик"
 ],
 "Search for additional software": [
  null,
  "Тражи додатни софтвер"
 ],
 "Search for an environment": [
  null,
  "Тражи окружење"
 ],
 "Search keyboard layout": [
  null,
  "Тражи распоред тастатуре"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Осигурајте своје податке шифровањем диска. Примењује се само на нове партиције"
 ],
 "Select": [
  null,
  "Изабери"
 ],
 "Select a device": [
  null,
  "Изаберите уређај"
 ],
 "Select city": [
  null,
  "Изаберите град"
 ],
 "Select destination": [
  null,
  "Изаберите одредиште"
 ],
 "Select region": [
  null,
  "Изаберите регион"
 ],
 "Selected (top = current)": [
  null,
  "Изабрано (врх = тренутно)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Формат „$0“ изабраног уређаја не може бити поново форматиран."
 ],
 "Send us feedback on your installation": [
  null,
  "Пошаљите нам повратне информације о вашој инсталацији"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server is not reachable": [
  null,
  "Сервер није доступан"
 ],
 "Set custom hostname": [
  null,
  "Поставите произвољно име домаћина"
 ],
 "Share disk with other operating systems": [
  null,
  "Делите диск са другим оперативним системима"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Делите диск са другим оперативним системима: $0"
 ],
 "Show AM/PM": [
  null,
  "Прикажи пре подне/после подне"
 ],
 "Show API key": [
  null,
  "Прикажи АПИ кључ"
 ],
 "Show confirmed password": [
  null,
  "Прикажи потврђену лозинку"
 ],
 "Show passphrase": [
  null,
  "Прикажи фразу"
 ],
 "Show password": [
  null,
  "Прикажи лозинку"
 ],
 "Size": [
  null,
  "Величина"
 ],
 "Software installation": [
  null,
  "Инсталација софтвера"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Инсталација софтвера: Подешавање складишта је завршено. Софтвер се сада инсталира на ваш уређај."
 ],
 "Software selection": [
  null,
  "Избор програма"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Неки кораци у инсталацији морају бити довршени пре наставка."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Неке потребне партиције недостају: $0"
 ],
 "Space": [
  null,
  "Простор"
 ],
 "Stacktrace": [
  null,
  "Траг стека"
 ],
 "Storage": [
  null,
  "Складиште"
 ],
 "Storage configuration": [
  null,
  "Подешавање складишта"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Подешавање складишта: Складиште се тренутно подешава."
 ],
 "Storage editor": [
  null,
  "Уређивач складишта"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Складиште је засновано на подешавању из „Измени складиште“."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Распоред складишта је дефинисан kickstart датотеком. Планирани распоред партиционисања се може прегледати у кораку сажетка."
 ],
 "Storage plugin failed": [
  null,
  "Прикључак за складиште није успео"
 ],
 "Storage requirements not met": [
  null,
  "Захтеви складишта нису испуњени"
 ],
 "Strong": [
  null,
  "Јака"
 ],
 "Successfully installed": [
  null,
  "Успешно инсталирано"
 ],
 "Successfully unlocked $0.": [
  null,
  "Успешно је откључано „$0“."
 ],
 "Suggested keyboards": [
  null,
  "Предложене тастатуре"
 ],
 "Suggested languages": [
  null,
  "Предложени језици"
 ],
 "System": [
  null,
  "Систем"
 ],
 "System configuration": [
  null,
  "Подешавање система"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Подешавање система: Инсталација софтвера је завршена. Систем се сада подешава."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Анаконда инсталатер је неочекивано заустављен."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Следећи корисник ће бити направљен:",
  "Следећи корисници ће бити направљени:",
  "Следећи корисници ће бити направљени:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "За инсталацију је потребно $0 простора на диску; међутим, капацитет изабраних дискова је само $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Инсталатер не може да настави због критичне грешке."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Инсталатер не може да настави због критичне грешке: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Унета фраза садржи знаке изван ASCII кодног распореда. Можда неће бити могућа промена распореда тастатуре када је будете куцали."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Изабрани подразумевани распоред тастатуре не подржава ASCII знакове. Изаберите распоред који подржава ASCII као подразумевани."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Уређивач складишта вам омогућава да мењате величину, бришете и правите партиције. Може да подеси LVM и још много тога. Намењен је за коришћење као напредна алатка и није предвиђен за уобичајену инсталацију."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Ове датотеке дневника могу садржати осетљиве информације као што су ИП адресе, корисничка имена или други детаљи о систему."
 ],
 "This hostname can't be submitted": [
  null,
  "Овај назив домаћина не може бити послат"
 ],
 "This is unstable, pre-release software": [
  null,
  "Ово је нестабилан, пред-издањски софтвер"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Овај распоред ће се користити за откључавање вашег система при покретању"
 ],
 "This may take a moment": [
  null,
  "Ово може потрајати"
 ],
 "This will take a few moments": [
  null,
  "Ово ће потрајати неколико тренутака"
 ],
 "Time": [
  null,
  "Време"
 ],
 "Timezone": [
  null,
  "Временска зона"
 ],
 "Title": [
  null,
  "Наслов"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Да бисте почели да користите $0, поново покрените систем."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Да бисте наставили, изаберите уређаје на које желите инсталацију."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Да бисте користили ову опцију, промените величину или уклоните постојеће партиције како бисте ослободили барем $0."
 ],
 "Type": [
  null,
  "Врста"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "Не могу да закажем брисање за $0"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "Не могу да закажем промену величине за $0"
 ],
 "Undo last action": [
  null,
  "Опозовите последњу радњу"
 ],
 "Unlock": [
  null,
  "Откључај"
 ],
 "Unlock encrypted devices": [
  null,
  "Откључај уређаје са шифровањем"
 ],
 "Use configured storage": [
  null,
  "Користи подешено складиште"
 ],
 "Use entire disk": [
  null,
  "Користи цео диск"
 ],
 "Use free space": [
  null,
  "Користи слободан простор"
 ],
 "Use local account": [
  null,
  "Користи локални налог"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Користи РАИД уређај за самосталну поделу диска"
 ],
 "User creation": [
  null,
  "Прављење корисника"
 ],
 "User name": [
  null,
  "Корисничко име"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Корисничко име може садржати само: мала слова a-z, цифре 0-9, цртицу $0, тачку $1, доњу црту $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Корисничко име не сме бити резервисана реч"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Корисничка имена морају бити краћа од 33 знака"
 ],
 "Validating...": [
  null,
  "Проверавам..."
 ],
 "Weak": [
  null,
  "Слаба"
 ],
 "Welcome": [
  null,
  "Добродошли"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Добро дошли у Федора Линукс"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Добродошли. Хајде да сада инсталирамо $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Када пошаљете овај извештај о грешци, следеће датотеке дневника ће бити самостално отпремљене: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "Виндоуз партиције са БитЛокер шифровањем не могу се променити"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Можете или да ослободите довољно простора овде и пустите инсталатера да одради остало или да ручно подесите партиције."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Можете да направите АПИ кључ за ваш Бубаждаја налог $0."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Морате да омогућите админ налог или да направите локални кориснички налог да бисте наставили."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Морате бити повезани на мрежу да бисте омогућили самостални датум и време."
 ],
 "Your progress will not be saved.": [
  null,
  "Ваш напредак неће бити сачуван."
 ],
 "completed step": [
  null,
  "завршен корак"
 ],
 "current step": [
  null,
  "тренутни корак"
 ],
 "delete": [
  null,
  "обриши"
 ],
 "edit": [
  null,
  "уреди"
 ],
 "encrypt": [
  null,
  "шифровати"
 ],
 "encrypted": [
  null,
  "шифровано"
 ],
 "extended partition": [
  null,
  "проширена партиција"
 ],
 "format as $0": [
  null,
  "форматирај као $0"
 ],
 "here": [
  null,
  "овде"
 ],
 "incomplete": [
  null,
  "недовршено"
 ],
 "mount": [
  null,
  "закачи"
 ],
 "pending step": [
  null,
  "корак на чекању"
 ],
 "report the issue manually": [
  null,
  "ручно пријави проблем"
 ],
 "resized from $0": [
  null,
  "промењена величина са $0"
 ],
 "shrink": [
  null,
  "смањи"
 ],
 "shrink to $0": [
  null,
  "смањи на $0"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "опозови"
 ]
});
