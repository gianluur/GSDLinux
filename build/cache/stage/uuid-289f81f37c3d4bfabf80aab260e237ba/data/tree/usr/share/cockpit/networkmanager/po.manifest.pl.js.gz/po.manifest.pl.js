cockpit.locale({
 "": {
  "plural-forms": ((n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2),
  "language": "pl",
  "language-direction": "ltr"
 },
 "Services": [
  null,
  "Usługi"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "network": [
  null,
  "sieć"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "interface": [
  null,
  "interfejs"
 ],
 "bridge": [
  null,
  "mostek"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "bond": [
  null,
  "wiązanie"
 ],
 "team": [
  null,
  "zespołowe"
 ],
 "port": [
  null,
  "port"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "firewall": [
  null,
  "zapora sieciowa"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "zone": [
  null,
  "strefa"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "Managing networking bonds": [
  null,
  "Zarządzanie wiązaniami sieciowymi"
 ],
 "Managing networking teams": [
  null,
  "Zarządzanie zespołami sieciowymi"
 ],
 "Managing networking bridges": [
  null,
  "Zarządzanie mostkami sieciowymi"
 ],
 "Managing VLANs": [
  null,
  "Zarządzanie VLAN"
 ],
 "Managing firewall": [
  null,
  "Zarządzanie zaporą sieciową"
 ]
});
