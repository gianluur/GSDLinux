cockpit.locale({
 "": {
  "plural-forms": ((n) => 0),
  "language": "lo",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "ຄອນເທນເນີ Podman"
 ],
 "podman": [
  null,
  "podman"
 ],
 "container": [
  null,
  "ຄອນເທນເນີ"
 ],
 "image": [
  null,
  "ອິເມຈ"
 ]
});
