cockpit.locale({
 "": {
  "plural-forms": ((n) => n > 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Delete $0?": [
  null,
  "Excluir $0?"
 ],
 "Force delete": [
  null,
  "Forçar exclusão"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Must be a valid IP address": [
  null,
  "Deve ser um endereço IP válido"
 ],
 "1 to 65535": [
  null,
  "1 para 65535"
 ],
 "Container port must not be empty": [
  null,
  "A porta do contêiner não pode estar vazia"
 ],
 "IP address": [
  null,
  "Endereço IP"
 ],
 "IP address help": [
  null,
  "Ajuda sobre o endereço IP"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Se o IP do host for definido como 0.0.0.0 ou não for definido, a porta será vinculada a todos os IPs no host."
 ],
 "Host port": [
  null,
  "Porta do host"
 ],
 "Host port help": [
  null,
  "Ajuda sobre o caminho do host"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Se a porta do host não estiver definida, a porta do contêiner receberá aleatoriamente uma porta no host."
 ],
 "Container port": [
  null,
  "Porta do contêiner"
 ],
 "Protocol": [
  null,
  "Protocolo"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Remove item": [
  null,
  "Remover item"
 ],
 "Image name is required": [
  null,
  "Nome da imagem é obrigatória"
 ],
 "Image name is not unique": [
  null,
  "O nome da imagem não é único"
 ],
 "Failed to commit container $0": [
  null,
  "Falha ao efetivar contêiner $0"
 ],
 "New image name": [
  null,
  "Nome da nova imagem"
 ],
 "Tag": [
  null,
  "Etiqueta"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exemplo, Seu Nome <seunome@example.com>"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Pause container when creating image": [
  null,
  "Pausar o contêiner ao criar a imagem"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "O formato Docker é útil ao compartilhar a imagem com o Docker ou Moby Engine"
 ],
 "Use legacy Docker format": [
  null,
  "Usar formato legado do Docker"
 ],
 "Commit container": [
  null,
  "Confirmar contêiner"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crie uma nova imagem com base no estado atual do contêiner $0."
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Force commit": [
  null,
  "Forçar confirmação"
 ],
 "Failed to force remove container $0": [
  null,
  "Falha ao forçar a remoção do contêiner $0"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Excluir um contêiner em execução irá apagar todos os dados dentro dele."
 ],
 "Failed to stop container $0": [
  null,
  "Falha ao parar o contêiner $0"
 ],
 "Failed to stop quadlet $0": [
  null,
  "Falha ao parar o quadlet $0"
 ],
 "Failed to start quadlet $0": [
  null,
  "Falha ao iniciar o quadlet $0"
 ],
 "Failed to start container $0": [
  null,
  "Falha ao iniciar o contêiner $0"
 ],
 "Failed to resume container $0": [
  null,
  "Falha ao retomar o contêiner $0"
 ],
 "Failed to pause container $0": [
  null,
  "Falha ao pausar o contêiner $0"
 ],
 "Failed to restart container $0": [
  null,
  "Falha ao reiniciar o contêiner $0"
 ],
 "Failed to restart quadlet $0": [
  null,
  "Falha ao reiniciar o quadlet $0"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Stop": [
  null,
  "Parar"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Force stop": [
  null,
  "Forçar parada"
 ],
 "Force restart": [
  null,
  "Forçar reinicialização"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Resume": [
  null,
  "Continuar"
 ],
 "Checkpoint": [
  null,
  "Criar checkpoint"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Restore": [
  null,
  "Restaurar"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Healthy": [
  null,
  "Íntegra"
 ],
 "Unhealthy": [
  null,
  "Não íntegra"
 ],
 "Checking health": [
  null,
  "Verificando a saúde"
 ],
 "Prune unused containers": [
  null,
  "Expurgar contêineres não usados"
 ],
 "Terminal not available": [
  null,
  "Terminal não disponível"
 ],
 "This browser does not support WebGL2.": [
  null,
  "Este navegador não suporta WebGL2."
 ],
 "View $0 logs": [
  null,
  "Ver logs de $0"
 ],
 "not available": [
  null,
  "não disponível"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "$0% of $1 limit": [
  null,
  "$0% do limite de $1"
 ],
 "service": [
  null,
  "serviço"
 ],
 "system": [
  null,
  "sistema"
 ],
 "user:": [
  null,
  "usuário:"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Integration": [
  null,
  "Integração"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Health check": [
  null,
  "Verificação de integridade"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "Click to see published ports": [
  null,
  "Clique para ver portas publicadas"
 ],
 "ports": [
  null,
  "portas"
 ],
 "Click to see volumes": [
  null,
  "Clique para ver volumes"
 ],
 "volumes": [
  null,
  "volumes"
 ],
 "Container": [
  null,
  "Contêiner"
 ],
 "Owner": [
  null,
  "Proprietário"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "No containers": [
  null,
  "Nenhum contêiner"
 ],
 "No containers in this pod": [
  null,
  "Nenhum contêiner neste pod"
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "No containers that match the current filter": [
  null,
  "Nenhum contêiner corresponde ao filtro atual"
 ],
 "No running containers": [
  null,
  "Nenhum contêiner em execução"
 ],
 "Show": [
  null,
  "Mostrar"
 ],
 "All": [
  null,
  "Todos"
 ],
 "Only running": [
  null,
  "Somente em execução"
 ],
 "Create pod": [
  null,
  "Criar pod"
 ],
 "Create container": [
  null,
  "Criar contêiner"
 ],
 "Containers": [
  null,
  "Contêineres"
 ],
 "Create container in pod": [
  null,
  "Criar contêiner no pod"
 ],
 "pod": [
  null,
  "pod"
 ],
 "Failed to restore container $0": [
  null,
  "Falha ao restaurar o contêiner $0"
 ],
 "Restore container $0": [
  null,
  "Restaurar contêiner $0"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Manter todos os arquivos temporários de checkpoint"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurar com conexões TCP estabelecidas"
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorar endereço IP se definido estaticamente"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorar endereço MAC se definido estaticamente"
 ],
 "Pod failed to be created": [
  null,
  "A criação do pod falhou"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caracteres inválidos. O nome pode conter apenas letras, números e determinadas pontuações (_ . -)."
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Pod name": [
  null,
  "Nome do pod"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "User:": [
  null,
  "Usuário:"
 ],
 "No ports exposed": [
  null,
  "Nenhuma porta exposta"
 ],
 "Port mapping": [
  null,
  "Mapeamento de porta"
 ],
 "Add port mapping": [
  null,
  "Adicionar mapeamento de porta"
 ],
 "No volumes specified": [
  null,
  "Nenhum volume especificado"
 ],
 "Volumes": [
  null,
  "Volumes"
 ],
 "Add volume": [
  null,
  "Adicionar volume"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Type to filter…": [
  null,
  "Digite para filtrar…"
 ],
 "Container path must not be empty": [
  null,
  "O caminho do contêiner não pode estar vazio"
 ],
 "Host path": [
  null,
  "Caminho do host"
 ],
 "Container path": [
  null,
  "Caminho do contêiner"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Writable": [
  null,
  "Gravável"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "No label": [
  null,
  "Nenhum rótulo"
 ],
 "Shared": [
  null,
  "Compartilhado"
 ],
 "Private": [
  null,
  "Privado"
 ],
 "Read-write access": [
  null,
  "Acesso leitura e gravação"
 ],
 "Read-only access": [
  null,
  "Acesso somente leitura"
 ],
 "Show less": [
  null,
  "Mostrar menos"
 ],
 "Show more": [
  null,
  "Mostrar mais"
 ],
 "Loading details...": [
  null,
  "Carregando detalhes..."
 ],
 "Ports": [
  null,
  "Portas"
 ],
 "Environment variables": [
  null,
  "Variáveis de ambiente"
 ],
 "Failed to download image $0:$1": [
  null,
  "Falha ao baixar a imagem $0:$1"
 ],
 "Error message": [
  null,
  "Mensagem de erro"
 ],
 "unused": [
  null,
  "não usada"
 ],
 "$0 container": [
  null,
  "$0 contêiner",
  "$0 contêineres"
 ],
 "History": [
  null,
  "História"
 ],
 "Image": [
  null,
  "Imagem"
 ],
 "Created": [
  null,
  "Criado"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Disk space": [
  null,
  "Espaço em disco"
 ],
 "Used by": [
  null,
  "Usado por"
 ],
 "No images": [
  null,
  "Nenhuma imagem"
 ],
 "No images that match the current filter": [
  null,
  "Nenhuma imagem corresponde ao filtro atual"
 ],
 "Hide intermediate images": [
  null,
  "Ocultar imagens intermediárias"
 ],
 "Show intermediate images": [
  null,
  "Mostrar imagens intermediárias"
 ],
 "Images": [
  null,
  "Imagens"
 ],
 "$0 image total, $1": [
  null,
  "$0 imagem no total, $1",
  "$0 imagens no total, $1"
 ],
 "$0 unused image, $1": [
  null,
  "$0 imagem não usada, $1",
  "$0 imagens não usadas, $1"
 ],
 "Hide images": [
  null,
  "Ocultar imagens"
 ],
 "Show images": [
  null,
  "Mostrar imagens"
 ],
 "Pulling": [
  null,
  "Baixando"
 ],
 "Download new image": [
  null,
  "Baixar nova imagem"
 ],
 "Pull all images": [
  null,
  "Baixar novas imagens"
 ],
 "Prune unused images": [
  null,
  "Expurgar imagens não usadas"
 ],
 "Pull": [
  null,
  "Baixar"
 ],
 "Up since:": [
  null,
  "Ligado desde:"
 ],
 "Exited": [
  null,
  "Encerrado"
 ],
 "systemd service": [
  null,
  "serviço systemd"
 ],
 "View $0": [
  null,
  "Ver $0"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "MAC address": [
  null,
  "Endereço MAC"
 ],
 "Latest checkpoint": [
  null,
  "Último checkpoint"
 ],
 "No containers are using this image": [
  null,
  "Nenhum contêiner está usando está imagem"
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "Loading logs...": [
  null,
  "Carregando logs..."
 ],
 "Delete unused system images:": [
  null,
  "Excluir imagens de sistema não usadas:"
 ],
 "Delete unused images of user $0:": [
  null,
  "Excluir imagens não usadas do usuário $0:"
 ],
 "Failed to prune unused images": [
  null,
  "Falha ao expurgar imagens não usadas"
 ],
 "Pruning images": [
  null,
  "Expurgando imagens"
 ],
 "Prune": [
  null,
  "Expurgar"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Falha ao criar checkpoint do contêiner $0"
 ],
 "Checkpoint container $0": [
  null,
  "Criar checkpoint do contêiner $0"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Deixar em execução após gravar o checkpoint no disco"
 ],
 "Support preserving established TCP connections": [
  null,
  "Adicionar suporte à preservação de conexões TCP estabelecidas"
 ],
 "Failed to search for new images": [
  null,
  "Falha ao buscar novas imagens"
 ],
 "Failed to search for images: $0": [
  null,
  "Falha ao buscar imagens: $0"
 ],
 "Failed to search for images.": [
  null,
  "Falha ao buscar imagens."
 ],
 "Search for an image": [
  null,
  "Pesquisar por uma imagem"
 ],
 "Search for": [
  null,
  "Pesquisar por"
 ],
 "Search by name or description": [
  null,
  "Pesquisar por nome ou descrição"
 ],
 "in": [
  null,
  "em"
 ],
 "All registries": [
  null,
  "Todos os registros"
 ],
 "Searching...": [
  null,
  "Pesquisando..."
 ],
 "No images found": [
  null,
  "Nenhuma imagem encontrada"
 ],
 "Start typing to look for images.": [
  null,
  "Comece a digitar para procurar por imagens."
 ],
 "No results for $0": [
  null,
  "Nenhum resultado para $0"
 ],
 "Retry another term.": [
  null,
  "Tente outro termo."
 ],
 "Download": [
  null,
  "Baixar"
 ],
 "No action": [
  null,
  "Nenhuma ação"
 ],
 "Container failed to be started": [
  null,
  "Inicialização do contêiner falhou"
 ],
 "Failed to clean up container": [
  null,
  "Falha ao limpar o contêiner"
 ],
 "Container failed to be created": [
  null,
  "Criação do contêiner falhou"
 ],
 "downloading": [
  null,
  "baixando"
 ],
 "Failed to run container $0": [
  null,
  "Falha ao executar o contêiner $0"
 ],
 "Failed to create container $0": [
  null,
  "Falha ao criar o contêiner $0"
 ],
 "Failed to pull image $0": [
  null,
  "Falha ao baixar a imagem $0"
 ],
 "Local images": [
  null,
  "Imagens locais"
 ],
 "Name already in use": [
  null,
  "Nome já em uso"
 ],
 "Search by registry": [
  null,
  "Pesquisar por registro"
 ],
 "Local": [
  null,
  "Local"
 ],
 "Container name": [
  null,
  "Nome do contêiner"
 ],
 "Owner help": [
  null,
  "Ajuda sobre o proprietário"
 ],
 "Ideal for running services": [
  null,
  "Ideal para executar serviços"
 ],
 "Resource limits can be set": [
  null,
  "Limites de recursos podem ser definidos"
 ],
 "Checkpoint and restore support": [
  null,
  "Suporte a checkpoint e restauração"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portas sob 1024 podem ser mapeadas"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Ideal for development": [
  null,
  "Ideal para desenvolvimento"
 ],
 "Restricted by user account permissions": [
  null,
  "Restrito pelas permissões da conta do usuário"
 ],
 "Image selection help": [
  null,
  "Ajuda sobre a seleção de imagem"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:porta]/[usuário]/contêiner[:etiqueta]"
 ],
 "Example: $0": [
  null,
  "Exemplo: $0"
 ],
 "Searching: $0": [
  null,
  "Pesquisando: $0"
 ],
 "Search string or container location": [
  null,
  "Pesquisar string ou local do contêiner"
 ],
 "Pull latest image": [
  null,
  "Baixar a última imagem"
 ],
 "Entrypoint": [
  null,
  "Ponto de entrada"
 ],
 "With terminal": [
  null,
  "Com terminal"
 ],
 "Memory limit": [
  null,
  "Limite de memória"
 ],
 "Decrease memory": [
  null,
  "Diminuir a memória"
 ],
 "Increase memory": [
  null,
  "Aumentar a memória"
 ],
 "Memory unit": [
  null,
  "Unidade de memória"
 ],
 "KB": [
  null,
  "KB"
 ],
 "MB": [
  null,
  "MB"
 ],
 "GB": [
  null,
  "GB"
 ],
 "CPU shares": [
  null,
  "Compartilhamento de CPU"
 ],
 "CPU Shares help": [
  null,
  "Ajuda sobre o compartilhamento de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "O compartilhamento de CPU determina a prioridade de execução de contêineres. A prioridade padrão é 1024. Um número maior prioriza este contêiner. Um número menor diminui a prioridade."
 ],
 "Decrease CPU shares": [
  null,
  "Diminuir a divisão de CPU"
 ],
 "Increase CPU shares": [
  null,
  "Aumentar a divisão de CPU"
 ],
 "Restart policy": [
  null,
  "Política de reinicialização"
 ],
 "Restart policy help": [
  null,
  "Ajuda sobre a política de reinicialização"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Política de reinicialização a ser seguida quando os contêineres são encerrados. Usar linger para contêineres de inicialização automática pode não funcionar em algumas circunstâncias, como quando ecryptfs, systemd-homed, NFS ou 2FA são usados em uma conta de usuário."
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Política de reinicialização para seguir quando contêineres são encerrados."
 ],
 "No": [
  null,
  "Não"
 ],
 "On failure": [
  null,
  "Em caso de falha"
 ],
 "Always": [
  null,
  "Sempre"
 ],
 "Maximum retries": [
  null,
  "Número máximo de tentativas"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuir o número máximo de tentativas"
 ],
 "Increase maximum retries": [
  null,
  "Aumentar o número máximo de tentativas"
 ],
 "No environment variables specified": [
  null,
  "Nenhuma variável de ambiente especificada"
 ],
 "Add variable": [
  null,
  "Adicionar variável"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Cole uma ou mais linhas de pares chave=valor em qualquer campo para importação em massa"
 ],
 "Interval": [
  null,
  "Intervalo"
 ],
 "Health check interval help": [
  null,
  "Ajuda sobre o intervalo de verificação de integridade"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervalo com que frequência a verificação de integridade é executada."
 ],
 "Decrease interval": [
  null,
  "Diminuir o intervalo"
 ],
 "Increase interval": [
  null,
  "Aumentar o intervalo"
 ],
 "seconds": [
  null,
  "segundos"
 ],
 "Timeout": [
  null,
  "Tempo de limite"
 ],
 "Health check timeout help": [
  null,
  "Ajuda sobre o tempo limite da verificação de integridade"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "O tempo máximo permitido para concluir a verificação de integridade antes que um intervalo seja considerado reprovado."
 ],
 "Decrease timeout": [
  null,
  "Diminuir o tempo limite"
 ],
 "Increase timeout": [
  null,
  "Aumentar o tempo limite"
 ],
 "Start period": [
  null,
  "Período de início"
 ],
 "Health check start period help": [
  null,
  "Ajuda sobre o período de início de verificação de integridade"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "O tempo de inicialização necessário para um contêiner ser inicializado."
 ],
 "Decrease start period": [
  null,
  "Diminuir o período de início"
 ],
 "Increase start period": [
  null,
  "Aumentar o período de início"
 ],
 "Retries": [
  null,
  "Tentativas"
 ],
 "Health check retries help": [
  null,
  "Ajuda sobre as tentativas de verificação de integridade"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "O número de tentativas permitidas antes que uma verificação de integridade seja considerada não íntegra."
 ],
 "Decrease retries": [
  null,
  "Diminuir as tentativas"
 ],
 "Increase retries": [
  null,
  "Aumentar as tentativas"
 ],
 "When unhealthy": [
  null,
  "Quando não íntegro"
 ],
 "Health failure check action help": [
  null,
  "Ajuda sobre a ação de verificação de falha da saúde"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Ação a ser tomada quando o contêiner passa para um estado não íntegra."
 ],
 "Create container in $0": [
  null,
  "Criar contêiner em $0"
 ],
 "Create and run": [
  null,
  "Criar e executar"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Version": [
  null,
  "Versão"
 ],
 "Links": [
  null,
  "Links"
 ],
 "Documentation": [
  null,
  "Documentação"
 ],
 "Tags": [
  null,
  "Etiquetas"
 ],
 "Created by": [
  null,
  "Criada por"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Comments": [
  null,
  "Comentários"
 ],
 "Unable to load image history": [
  null,
  "Não foi possível carregar o histórico da imagem"
 ],
 "Key must not be empty": [
  null,
  "A chave não pode estar vazia"
 ],
 "Key must not begin with a digit": [
  null,
  "A chave não pode iniciar com um dígito"
 ],
 "Key contains invalid characters": [
  null,
  "A chave contém caracteres inválidos"
 ],
 "Key": [
  null,
  "Chave"
 ],
 "Value": [
  null,
  "Valor"
 ],
 "user": [
  null,
  "usuário"
 ],
 "Podman service failed": [
  null,
  "Serviço do Podman falhou"
 ],
 "Troubleshoot": [
  null,
  "Solução de problemas"
 ],
 "Failed to force remove image $0": [
  null,
  "Falha ao forçar a remoção da imagem $0"
 ],
 "intermediate image": [
  null,
  "imagem intermediária"
 ],
 "Failed to remove image $0": [
  null,
  "Falha ao remover a imagem $0"
 ],
 "intermediate": [
  null,
  "intermediária"
 ],
 "Delete $0 image?": [
  null,
  "Excluir a imagem $0?"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Existem várias tags para esta imagem. Selecione as imagens marcadas para excluir."
 ],
 "Delete image": [
  null,
  "Excluir imagem"
 ],
 "Delete tagged images": [
  null,
  "Excluir imagens com etiquetas"
 ],
 "Container is not running": [
  null,
  "Contêiner não está em execução"
 ],
 "Error occurred while connecting console": [
  null,
  "Ocorreu um erro ao conectar ao console"
 ],
 "Force delete pod $0?": [
  null,
  "Forçar exclusão do pod $0?"
 ],
 "Delete pod $0?": [
  null,
  "Excluir pod $0?"
 ],
 "An error occurred": [
  null,
  "Ocorreu um erro"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "O pod vazio $0 será removido permanentemente."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Excluir este pod irá remover os seguintes contêineres:"
 ],
 "Failed to start pod $0": [
  null,
  "Falha ao iniciar o pod $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Falha ao parar o pod $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Falha ao reiniciar o pod $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Falha ao retomar o pod $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Falha ao pausar o pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Falha ao expurgar contêineres não usados"
 ],
 "Removes selected non-running containers": [
  null,
  "Remove contêineres selecionadas que não estão em execução"
 ],
 "Pruning containers": [
  null,
  "Expurgando contêineres"
 ],
 "Container name is required.": [
  null,
  "Nome do contêiner é requerido."
 ],
 "Failed to rename container $0": [
  null,
  "Falha ao renomear o contêiner $0"
 ],
 "New container name": [
  null,
  "Novo nome do contêiner"
 ],
 "Rename container $0": [
  null,
  "Renomear contêiner $0"
 ],
 "Paused": [
  null,
  "Pausado"
 ],
 "Stopped": [
  null,
  "Parado"
 ],
 "Removing": [
  null,
  "Removendo"
 ],
 "Configured": [
  null,
  "Configurado"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "$0 second": [
  null,
  "$0 segundo",
  "$0 segundos"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Failing streak": [
  null,
  "Sequência de falhas"
 ],
 "Failed to run health check on container $0": [
  null,
  "Falha ao executar uma verificação de integridade do contêiner $0"
 ],
 "Run health check": [
  null,
  "Executar verificação de integridade"
 ],
 "Last 5 runs": [
  null,
  "Últimas 5 verificações"
 ],
 "Started at": [
  null,
  "Iniciado em"
 ],
 "Passed health run": [
  null,
  "Passou na verificação de saúde"
 ],
 "Failed health run": [
  null,
  "Falhou na execução de verificação de saúde"
 ],
 "Failed to remove container $0": [
  null,
  "Falha ao remover o contêiner $0"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Excluir um contêiner irá apagar todos os dados que ele contém."
 ]
});
