cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "nl",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Unlock": [
  null,
  "Ontgrendelen"
 ],
 "Add key": [
  null,
  "Sleutel toevoegen"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Select": [
  null,
  "Selecteren"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "Set": [
  null,
  "Instellen"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Port": [
  null,
  "Poort"
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "Permission denied": [
  null,
  "Toestemming geweigerd"
 ],
 "Clear input value": [
  null,
  "Invoerwaarde wissen"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "Create $0": [
  null,
  "Maak $0 aan"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "You now have administrative access.": [
  null,
  "Je hebt nu administratieve toegang."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Authenticeer om administratieve toegang te krijgen"
 ],
 "Switch to administrative access": [
  null,
  "Schakel om naar beheerderstoegang"
 ],
 "Authenticate": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Administrative access": [
  null,
  "Administratieve toegang"
 ],
 "Problem becoming administrator": [
  null,
  "Probleem om beheerder te worden"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Limit access": [
  null,
  "Beperk toegang"
 ],
 "Switch to limited access": [
  null,
  "Schakel over naar beperkte toegang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "De beperkte toegangsmodus beperkt de beheerdersrechten. Sommige delen van de webconsole hebben een verminderde functionaliteit."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Je browser onthoudt je toegangsniveau tijdens sessies."
 ],
 "Limited access": [
  null,
  "Beperkte toegang"
 ],
 "Turn on administrative access": [
  null,
  "Schakel beheerderstoegang in"
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "less than a minute ago": [
  null,
  "minder dan een minuut geleden"
 ],
 "in less than a minute": [
  null,
  "in minder dan een minuut"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Unknown host: $0": [
  null,
  "Onbekende host: $0"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporteerde foutcode $0"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "Row select": [
  null,
  "Selecteer rij"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Error during initialization": [
  null,
  ""
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Home": [
  null,
  ""
 ],
 "Type to filter": [
  null,
  "Typ om te filteren"
 ],
 "File chooser actions": [
  null,
  ""
 ],
 "Hide hidden files": [
  null,
  ""
 ],
 "Filesystem": [
  null,
  "Bestandssysteem"
 ],
 "Directory has no sub-directories": [
  null,
  ""
 ],
 "This directory contains only hidden files": [
  null,
  ""
 ],
 "No matching results": [
  null,
  "Geen overeenkomende resultaten"
 ],
 "Folder": [
  null,
  ""
 ],
 "File": [
  null,
  "Bestand"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "View logs": [
  null,
  "Bekijk logboeken"
 ],
 "Dismiss": [
  null,
  "Afwijzen"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "none": [
  null,
  "geen"
 ],
 "Not found": [
  null,
  "Niet gevonden"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Running": [
  null,
  "Uitvoeren"
 ],
 "Not running": [
  null,
  "Niet actief"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "User": [
  null,
  "Gebruiker"
 ],
 "Vendor": [
  null,
  "Leverancier"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "State": [
  null,
  "Toestand"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Confirm deletion of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Username": [
  null,
  "Gebruikersnaam"
 ],
 "Actions": [
  null,
  "Acties"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Rename": [
  null,
  "Hernoemen"
 ],
 "Started": [
  null,
  "Gestart"
 ],
 "Delete group": [
  null,
  "Groep verwijderen"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Lock": [
  null,
  "Slot"
 ],
 "Service": [
  null,
  "Service"
 ],
 "Disconnect": [
  null,
  "Verbinding verbreken"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "$0 disk is missing": [
  null,
  "$0 schijf ontbreekt",
  "$0 schijven ontbreken"
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "Compression": [
  null,
  "Compressie"
 ],
 "Storage logs": [
  null,
  "Opslaglogboeken"
 ],
 "Name cannot be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Naam mag niet langer zijn dan 127 lettertekens."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Naam mag het letterteken '$0' niet bevatten."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Naam mag geen spaties bevatten."
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Naam mag niet langer dan $0 lettertekens"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Naam mag niet langer zijn dan $0 bytes"
 ],
 "$name (from $host)": [
  null,
  "$name (van $host)"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool voor dunne logische volumes"
 ],
 "Thin logical volume": [
  null,
  "Dunne logische volume"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logische volume (Snapshot)"
 ],
 "Logical volume": [
  null,
  "Logische volume"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 volumegroep $0"
 ],
 "VDO device $0": [
  null,
  "VDO-apparaat $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Versleutelde logische volume van $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Versleutelde partitie van $0"
 ],
 "Logical volume of $0": [
  null,
  "Logische volume van $0"
 ],
 "Partition of $0": [
  null,
  "Partitie van $0"
 ],
 "Encrypted $0": [
  null,
  "$0 versleuteld"
 ],
 "unpartitioned space on $0": [
  null,
  "niet-gepartitioneerde ruimte op $0"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "stop": [
  null,
  "stop"
 ],
 "remove from LVM2": [
  null,
  "verwijderen uit LVM2"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Naam mag het karakter '/' niet bevatten."
 ],
 "Create and mount": [
  null,
  "Aanmaken en aankoppelen"
 ],
 "Create only": [
  null,
  "Alleen aanmaken"
 ],
 "Create subvolume": [
  null,
  "Maak subvolume aan"
 ],
 "Mount Point": [
  null,
  "Aankoppelpunt"
 ],
 "delete": [
  null,
  "verwijderen"
 ],
 "Unmount": [
  null,
  "Afkoppelen"
 ],
 "Mount": [
  null,
  "Aankoppelen"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Ten minste één sub-volume moet worden gekoppeld"
 ],
 "Mount point": [
  null,
  "Aankoppelpunt"
 ],
 "$0 is in use": [
  null,
  "$0 is in gebruik"
 ],
 "Permanently delete $0?": [
  null,
  "$0 permanent verwijderen?"
 ],
 "Change label": [
  null,
  "Verander label"
 ],
 "Label": [
  null,
  "Label"
 ],
 "Capacity": [
  null,
  "Capaciteit"
 ],
 "Aborted": [
  null,
  "Geannuleerd"
 ],
 "In progress": [
  null,
  "Bezig"
 ],
 "Did not complete": [
  null,
  "Niet voltooid"
 ],
 "Failed (Electrical)": [
  null,
  "Gefaald (Elektrisch)"
 ],
 "Failed (Damaged)": [
  null,
  "Gefaald (Beschadigd)"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Geannuleerd door een Controller Niveau Reset"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Afgebroken vanwege het verwijderen van een naamruimte uit de naamruimte-inventaris"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Afgebroken vanwege de verwerking van een Format NVM-opdracht"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Een fatale fout heeft zich voorgedaan tijdens de zelf test"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Voltooid met een segment dat is mislukt en het segment dat is mislukt is onbekend"
 ],
 "Completed with one or more failed segments": [
  null,
  "Voltooid met één of meer gefaalde segmenten"
 ],
 "Aborted for unknown reason": [
  null,
  "Afgebroken vanwege een onbekende reden"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Afgebroken vanwege een ontsmettingsoperatie"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Reservecapaciteit ligt onder de drempelwaarde"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatuur buiten de aanbevolen drempelwaarde"
 ],
 "Degraded": [
  null,
  "Gedegradeerd"
 ],
 "All media is in read-only mode": [
  null,
  "Alle media staan in de alleen-lezen-modus"
 ],
 "Volatile memory backup failed": [
  null,
  "Vluchtige geheugenback-up mislukt"
 ],
 "Run extended test": [
  null,
  "Start uitgebreide test"
 ],
 "Abort test": [
  null,
  "Test stoppen"
 ],
 "Disk is failing": [
  null,
  "Schijf werkt niet"
 ],
 "Disk is OK": [
  null,
  "Schijf is OK"
 ],
 "Assessment": [
  null,
  "Beoordeling"
 ],
 "Power on hours": [
  null,
  "Aantal uren aan"
 ],
 "$0 hours": [
  null,
  "$0 uren"
 ],
 "Self-test status": [
  null,
  "Zelfteststatus"
 ],
 "Number of bad sectors": [
  null,
  "Aantal slechte sectoren"
 ],
 "Attributes failing": [
  null,
  "Attributen falen"
 ],
 "Drive": [
  null,
  "Station"
 ],
 "Device health (SMART)": [
  null,
  "Apparaat-gezondheid (SMART)"
 ],
 "No media inserted": [
  null,
  "Geen media geplaatst"
 ],
 "Device file": [
  null,
  "Apparaatbestand"
 ],
 "Free space": [
  null,
  "Vrije ruimte"
 ],
 "Create partition": [
  null,
  "Partitie aanmaken"
 ],
 "Extended partition": [
  null,
  "Uitgebreide partitie"
 ],
 "$0 partitions": [
  null,
  "$0 partities"
 ],
 "Partitions": [
  null,
  "Partities"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Partities worden niet ondersteund op dit blokapparaat. Als het als schijf voor een virtuele machine wordt gebruikt, moeten de partities worden beheerd door het besturingssysteem in de virtuele machine."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Verwijderen van een partitie zal alle data erop wissen."
 ],
 "No free space after this partition": [
  null,
  "Geen vrije ruimte na deze partitie"
 ],
 "BIOS boot partition": [
  null,
  "BIOS opstart-partitie"
 ],
 "Partition": [
  null,
  "Partitie"
 ],
 "Shrink": [
  null,
  "Krimpen"
 ],
 "Grow": [
  null,
  "Vergroten"
 ],
 "Linux filesystem data": [
  null,
  "Linux-bestandssysteemgegevens"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Het type moet precies twee hexadecimale tekens bevatten (0 tot en met 9, A tot en met F)."
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Het type mag alleen de tekens 0 tot en met 9, A tot en met F en \"-\" bevatten."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Het type moet in de vorm zijn van NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Het wijzigen van partitie type kan ervoor zorgen dat het systeem niet meer opstart."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Deze partitie wordt niet volledig gebruikt door de inhoud ervan."
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Partitiegrootte is $0. Inhoudsgrootte is $1."
 ],
 "Shrink partition": [
  null,
  "Verklein partitie"
 ],
 "Grow content": [
  null,
  "Vergroot inhoud"
 ],
 "initialize": [
  null,
  "initialiseren"
 ],
 "Initialize disk $0": [
  null,
  "Initialiseren van schijf $0"
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibel met alle systemen en apparaten (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Verenigbaar met moderne systemen en harde schijven > 2TB (GPT)"
 ],
 "No partitioning": [
  null,
  "Geen partitionering"
 ],
 "Overwrite": [
  null,
  "Overschrijven"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Bestaande data overschrijven met nullen (langzamer)"
 ],
 "Initialize": [
  null,
  "Initialiseren"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initialiseren verwijdert alle data op een schijf."
 ],
 "Device is read-only": [
  null,
  "Apparaat is alleen-lezen"
 ],
 "Create partition table": [
  null,
  "Partitietabel aanmaken"
 ],
 "Size must be a number": [
  null,
  "Grootte moet een getal zijn"
 ],
 "Size cannot be zero": [
  null,
  "Grootte mag niet nul zijn"
 ],
 "Size cannot be negative": [
  null,
  "Grootte mag niet negatief zijn"
 ],
 "Size is too large": [
  null,
  "Grootte is te groot"
 ],
 "Size must be at least $0": [
  null,
  "Grootte moet tenminste $0 zijn"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysieke volume van LVM2-volumegroep"
 ],
 "backing device for VDO device": [
  null,
  "steunapparaat voor VDO-apparaat"
 ],
 "member of Stratis pool": [
  null,
  "onderdeel van Stratis-pool"
 ],
 "Filesystem outside the target": [
  null,
  "Bestandssysteem buiten doel"
 ],
 "device of btrfs volume": [
  null,
  "apparaat van btrfs volume"
 ],
 "This device is currently in use.": [
  null,
  "Dit apparaat is momenteel in gebruik."
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Use": [
  null,
  "Gebruik"
 ],
 "Services using the location": [
  null,
  "Services die gebruik maken van de locatie"
 ],
 "Processes using the location": [
  null,
  "Processen die de locatie gebruiken"
 ],
 "Currently in use": [
  null,
  "Momenteel in gebruik"
 ],
 "(Not part of target)": [
  null,
  "Partitie $(Not part of target) aanmaken"
 ],
 "These changes will be made:": [
  null,
  "Deze veranderingen zullen worden gemaakt:"
 ],
 "Action": [
  null,
  "Actie"
 ],
 "Important data might be deleted:": [
  null,
  "Belangrijke gegevens kunnen worden verwijderd:"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Gerelateerde processen en services worden met kracht gestopt."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Gerelateerde processen worden met kracht gestopt."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Gerelateerde services worden met kracht gestopt."
 ],
 "Checking filesystem usage": [
  null,
  "Bestandssysteemgebruik controleren"
 ],
 "$0 used, $1 total": [
  null,
  "$0 gebruikt, $1 totaal"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Ik bevestig dat ik deze data voor eeuwig wil verliezen"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze processen:"
 ],
 "PID": [
  null,
  "PID"
 ],
 "Command": [
  null,
  "Opdracht"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze services:"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De vermelde processen en services worden met kracht gestopt."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De vermelde processen worden met kracht gestopt."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De vermelde services worden met kracht gestopt."
 ],
 "Sorry": [
  null,
  "Excuses"
 ],
 "Usage of $0": [
  null,
  "Gebruik van $0"
 ],
 "Data used": [
  null,
  "Gebruikte data"
 ],
 "Metadata used": [
  null,
  "Gebruikte metadata"
 ],
 "Use compression": [
  null,
  "Gebruik compressie"
 ],
 "Deduplication": [
  null,
  "Deduplicatie"
 ],
 "Use deduplication": [
  null,
  "Gebruik deduplicatie"
 ],
 "Rename volume group": [
  null,
  "Hernoem volumegroep"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Deze volumegroep bevat het rootbestandssysteem. Het hernoemen ervan vereist mogelijk verdere wijzigingen in de bootloaderconfiguratie of de kernelopdrachtregel."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Verwijderen vernietigt alle data op een volumegroep."
 ],
 "Create snapshot": [
  null,
  "Maak snapshot aan"
 ],
 "Add disks": [
  null,
  "Schijven toevoegen"
 ],
 "Disks": [
  null,
  "Schijven"
 ],
 "No disks are available.": [
  null,
  "Geen schijven beschikbaar."
 ],
 "At least one disk is needed.": [
  null,
  "Minimaal een schijf is noodzakelijk."
 ],
 "Volume group is missing physical volumes": [
  null,
  "Volumegroep mist enkele fysieke volumes"
 ],
 "No free space": [
  null,
  "Geen vrije ruimte"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 volumegroep"
 ],
 "Add physical volume": [
  null,
  "Fysiek volume toevoegen"
 ],
 "Create new logical volume": [
  null,
  "Maak nieuwe logische volume aan"
 ],
 "No logical volumes": [
  null,
  "Geen logische volumes"
 ],
 "Remove missing physical volumes?": [
  null,
  "Ontbrekende fysieke volumes verwijderen?"
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Bij deze volumegroep ontbreken enkele fysieke volumes."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Een volumegroep met ontbrekende fysieke volumes kan niet worden hernoemd."
 ],
 "Physical volumes": [
  null,
  "Fysieke volumes"
 ],
 "Rename logical volume": [
  null,
  "Hernoemen logische volume"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Logisch volume $0/$1 permanent verwijderen?"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Verwijderen van een logische volume zal alle data erop wissen."
 ],
 "Unable to repair logical volume $0": [
  null,
  "Kan logische volume $0 niet repareren"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Er is niet voldoende ruimte beschikbaar die kan worden gebruikt voor een reparatie. Er is minimaal $0 nodig voor fysieke volumes die nog niet voor dit logische volume worden gebruikt."
 ],
 "An additional $0 must be selected": [
  null,
  "Er moet een extra $0 worden geselecteerd"
 ],
 "Repair logical volume $0": [
  null,
  "Herstel logische volume $0"
 ],
 "Physical Volumes": [
  null,
  "Fysieke volumes"
 ],
 "Repair": [
  null,
  "Herstellen"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Deactiveer logische volume $0/$1?"
 ],
 "Deactivate": [
  null,
  "Deactiveren"
 ],
 "Not enough space to grow": [
  null,
  "Niet genoeg ruimte om te groeien"
 ],
 "Striped (RAID 0)": [
  null,
  "Gestreept (RAID 0)"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Gespiegeld (RAID 1)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Gestreept en gespiegeld (RAID 10)"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Toegewijde pariteit (RAID 4)"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Gedistribueerde pariteit (RAID 5)"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Dubbel gedistribueerde pariteit (RAID 6)"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dit logische volume wordt niet volledig gebruikt door de inhoud."
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volumegrootte is $0. Inhoudsgrootte is $1."
 ],
 "Shrink volume": [
  null,
  "Krimp volume"
 ],
 "Layout": [
  null,
  "Indeling"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren en kan niet langer worden gebruikt. Je moet het verwijderen en een nieuwe maken om zijn plaats in te nemen."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren, maar nog geen data. Je moet het repareren om de oorspronkelijke redundantie te herstellen."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Dit logische volume heeft een deel van zijn fysieke volumes verloren, maar mogelijk nog geen data. Misschien kun je het repareren."
 ],
 "Stripes": [
  null,
  "Strepen"
 ],
 "$0 synchronized": [
  null,
  "$0 gesynchroniseerd"
 ],
 "Create volume group": [
  null,
  "Maak volumegroep aan"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fysieke volume"
 ],
 "Volume group": [
  null,
  "Volumegroep"
 ],
 "Create thin volume": [
  null,
  "Maak dun volume aan"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Maak nieuw dun logisch volume aan"
 ],
 "Not enough space": [
  null,
  "Niet genoeg ruimte"
 ],
 "Activate": [
  null,
  "Activeren"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "INTERNE ERROR - Dit logische volume is gemarkeerd als actief en zou een bijbehorend blokapparaat moeten hebben. Er kon echter geen dergelijk blokapparaat worden gevonden."
 ],
 "Installing $0 would remove $1.": [
  null,
  "Als je $0 installeert, wordt $1 verwijderd."
 ],
 "Installing packages": [
  null,
  "Pakketten installeren"
 ],
 "Block device for filesystems": [
  null,
  "Blok apparaat voor bestandsystemen"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool voor dun ingerichte volumes"
 ],
 "Linear": [
  null,
  "Lineair"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-bestandssysteemvolume (compressie/deduplicatie)"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes zonder enige extra redundantie of prestatieverbeteringen."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Data wordt afwisselend op de geselecteerde fysieke volumes opgeslagen om de prestaties te verbeteren. Er moeten minimaal twee volumes worden geselecteerd."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Data wordt opgeslagen als twee of meer kopieën op de geselecteerde fysieke volumes, om de betrouwbaarheid te verbeteren. Er moeten minimaal twee volumes worden geselecteerd."
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Data wordt als twee kopieën en ook op afwisselende wijze op de geselecteerde fysieke volumes opgeslagen, om zowel de betrouwbaarheid als de prestaties te verbeteren. Er moeten minimaal vier volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes, zodat een ervan verloren kan gaan zonder de data te beïnvloeden. Er moeten minimaal drie volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Data wordt opgeslagen op de geselecteerde fysieke volumes, zodat een ervan verloren kan gaan zonder de data te beïnvloeden. Data wordt ook afwisselend opgeslagen om de prestaties te verbeteren. Er moeten minimaal drie volumes worden geselecteerd."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Data wordt op de geselecteerde fysieke volumes opgeslagen, zodat er maximaal twee tegelijk verloren kunnen gaan zonder dat dit gevolgen heeft voor de data. Data wordt ook afwisselend opgeslagen om de prestaties te verbeteren. Er moeten minimaal vijf volumes worden geselecteerd."
 ],
 "Create logical volume": [
  null,
  "Maak logische volume aan"
 ],
 "Purpose": [
  null,
  "Doel"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Het $0 pakket zal worden geïnstalleerd om VDO-apparaten aan te maken."
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 heeft een even aantal fysieke volumes nodig"
 ],
 "Logical size": [
  null,
  "Logische grootte"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Bespaar ruimte door afzonderlijke blokken te comprimeren met LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Bespaar ruimte door identieke datablokken slechts één keer op te slaan"
 ],
 "Creating VDO device": [
  null,
  "VDO-apparaat aanmaken"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Deze NFS-mount is in gebruik en alleen de opties kunnen gewijzigd worden."
 ],
 "NFS mount": [
  null,
  "NFS-aankoppeling"
 ],
 "New NFS mount": [
  null,
  "Nieuwe NFS-aankoppeling"
 ],
 "Server address": [
  null,
  "Serveradres"
 ],
 "Server cannot be empty.": [
  null,
  "Server mag niet leeg zijn."
 ],
 "Path on server": [
  null,
  "Pad op server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Pad op server mag niet leeg zijn."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Pad op server moet beginnen met \"/\"."
 ],
 "Local mount point": [
  null,
  "Lokale aankoppelpunten"
 ],
 "Mount point cannot be empty.": [
  null,
  "Aankoppelpunt mag niet leeg zijn."
 ],
 "Mount point must start with \"/\".": [
  null,
  "Aankoppelpunt moet beginnen met \"/\"."
 ],
 "Mount options": [
  null,
  "Aankoppelopties"
 ],
 "Mount at boot": [
  null,
  "Koppel aan tijdens het opstarten"
 ],
 "Mount read only": [
  null,
  "Koppel alleen-lezen aan"
 ],
 "Custom mount options": [
  null,
  "Aangepaste aankoppelopties"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan bestandssysteem niet afkoppelen"
 ],
 "Stop and unmount": [
  null,
  "Stoppen en ontkoppelen"
 ],
 "Unable to remove mount": [
  null,
  "Kan aankoppeling niet verwijderen"
 ],
 "Stop and remove": [
  null,
  "Stop en verwijder"
 ],
 "Start multipath": [
  null,
  "Start multipath"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Er zijn apparaten met meerdere paden op het systeem, maar de multipath-service is niet actief."
 ],
 "Show all $0 rows": [
  null,
  "Toon alle $0 rijen"
 ],
 "Category": [
  null,
  "Categorie"
 ],
 "more info": [
  null,
  "meer info"
 ],
 "Encryption": [
  null,
  "Versleuteling"
 ],
 "Last modified: $0": [
  null,
  "Laatst gewijzigd: $0"
 ],
 "Stored passphrase": [
  null,
  "Opgeslagen wachtzin"
 ],
 "Encryption options": [
  null,
  "Versleutelingsopties"
 ],
 "Encryption type": [
  null,
  "Versleutelingstype"
 ],
 "Cleartext device": [
  null,
  "Cleartext-apparaat"
 ],
 "yes": [
  null,
  "ja"
 ],
 "Disk passphrase": [
  null,
  "Schijf wachtzin"
 ],
 "Passphrase cannot be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Unlocking disk": [
  null,
  "Schijf ontgrendelen"
 ],
 "Checking for $0 package": [
  null,
  "Controleren op $0 pakket"
 ],
 "The $0 package must be installed.": [
  null,
  "Het $0 pakket moet worden geïnstalleerd."
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Het $0 pakket is van geen enkele repository beschikbaar."
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Controleren op NBDE-ondersteuning in de initrd"
 ],
 "The initrd must be regenerated.": [
  null,
  "De initrd moet opnieuw worden gegenereerd."
 ],
 "Regenerating initrd": [
  null,
  "initrd opnieuw genereren"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "rd.neednet=1 toevoegen aan kernelcommandoregel"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "\"$0\" toevoegen aan bestandssysteemopties"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "\"$0\" toevoegen aan versleutelingsopties"
 ],
 "Enabling $0": [
  null,
  "$0 inschakelen"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Voeg netwerkgebonden schijfversleuteling toe"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Het systeem biedt momenteel geen ondersteuning voor het ontgrendelen van het rootbestandssysteem met een Tang-sleutelserver."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Het systeem ondersteunt momenteel niet het ontgrendelen van een bestandssysteem met een Tang-sleutelserver tijdens het opstarten."
 ],
 "These additional steps are necessary:": [
  null,
  "Deze extra stappen zijn nodig:"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Voor het opslaan van een nieuwe wachtzin moet de schijf worden ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Fix NBDE support": [
  null,
  "NBDE-ondersteuning repareren"
 ],
 "Adding key": [
  null,
  "Toevoegen sleutel"
 ],
 "Key source": [
  null,
  "Sleutelbron"
 ],
 "Repeat passphrase": [
  null,
  "Herhaal wachtzin"
 ],
 "Passphrase": [
  null,
  "Wachtzin"
 ],
 "Tang keyserver": [
  null,
  "Tang sleutelserver"
 ],
 "New passphrase": [
  null,
  "Nieuwe wachtzin"
 ],
 "Passphrases do not match": [
  null,
  "Wachtzinnen komen niet overeen"
 ],
 "Keyserver address": [
  null,
  "Sleutelserveradres"
 ],
 "Change passphrase": [
  null,
  "Verander wachtzin"
 ],
 "Old passphrase": [
  null,
  "Oude wachtzin"
 ],
 "Edit Tang keyserver": [
  null,
  "Bewerk Tang sleutelserver"
 ],
 "Verify key": [
  null,
  "Verifieer sleutel"
 ],
 "Trust key": [
  null,
  "Vertrouwenssleutel"
 ],
 "Passphrase can not be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Verwijdering van wachtzin kan voorkomen dat $0 wordt ontgrendeld."
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bevestig verwijderen met een alternatieve wachtzin"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Het verwijderen van een wachtzin zonder bevestiging van een andere wachtzin kan ontgrendeling of sleutelbeheer voorkomen als andere wachtzinnen worden vergeten of verloren gaan."
 ],
 "Passphrase from any other key slot": [
  null,
  "Wachtzin van een ander sleutelslot"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Wachtzin in sleutelslot $0 verwijderen?"
 ],
 "Remove $0?": [
  null,
  "$0 verwijderen?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang-sleutelserver verwijderen?"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "De momenteel ingelogde gebruiker mag geen informatie over sleutels zien."
 ],
 "No keys added": [
  null,
  "Geen sleutels toegevoegd"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Editing a key requires a free slot": [
  null,
  "Een sleutel bewerken vereist een vrij slot"
 ],
 "The last key slot can not be removed": [
  null,
  "De laatste sleutelslot kan niet verwijderd worden"
 ],
 "Keyserver": [
  null,
  "Sleutelserver"
 ],
 "Unknown type": [
  null,
  "Onbekend type"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sleutelslots met onbekende typen kunnen hier niet worden bewerkt"
 ],
 "Keys": [
  null,
  "Sleutels"
 ],
 "$0 slot remains": [
  null,
  "$0 slot blijft over",
  "$0 slots blijven over"
 ],
 "No available slots": [
  null,
  "Geen slots beschikbaar"
 ],
 "No free key slots": [
  null,
  "Geen vrije sleutel slots"
 ],
 "Lock $0?": [
  null,
  "Vergrendel $0?"
 ],
 "Address cannot be empty": [
  null,
  "Adres mag niet leeg zijn"
 ],
 "Address is not a valid URL": [
  null,
  "Adres is geen geldige URL"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Controleer de sleutel-hash met de Tang-server."
 ],
 "How to check": [
  null,
  "Hoe te controleren"
 ],
 "In a terminal, run: ": [
  null,
  "Voer in een terminal uit: "
 ],
 "Successfully copied to clipboard!": [
  null,
  "Succesvol naar kladblok gekopieerd!"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Controleer of de SHA-256- of SHA-1-hash van de opdracht overeenkomt met dit dialoog."
 ],
 "SHA-256": [
  null,
  "SHA256"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs subvolume $0 van $1"
 ],
 "Mount point cannot be empty": [
  null,
  "Aankoppelpunt mag niet leeg zijn"
 ],
 "Mount point is already used for $0": [
  null,
  "Aankoppelpunt wordt al gebruikt voor $0"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Bestandssystemen zijn al aangekoppeld op dit aankoppelpunt."
 ],
 "Please unmount them first.": [
  null,
  "Ontkoppel ze eerst."
 ],
 "read only": [
  null,
  "alleen-lezen"
 ],
 "never mount at boot": [
  null,
  "nooit aankoppelen tijdens opstarten"
 ],
 "after network": [
  null,
  "na netwerk"
 ],
 "ignore failure": [
  null,
  "negeer mislukken"
 ],
 "stop boot on failure": [
  null,
  "stop opstarten bij mislukken"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Het bestandssysteem heeft geen permanent koppelpunt."
 ],
 "The filesystem is not mounted.": [
  null,
  "Het bestandssysteem is niet aangekoppeld."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Het bestandssysteem wordt ontgrendeld en aangekoppeld bij de volgende keer opstarten. Hiervoor moet mogelijk een wachtzin worden ingevoerd."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal worden aangekoppeld op $1 bij de volgende opstart."
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Koppel automatisch aan op $0 tijdens het opstarten"
 ],
 "Mount on $0 now": [
  null,
  "Koppel nu aan op $0"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Het bestandssysteem is momenteel niet aangekoppeld, maar wordt bij de volgende opstart aangekoppeld."
 ],
 "Do not mount automatically on boot": [
  null,
  "Niet automatisch aankoppelen tijdens het opstarten"
 ],
 "Mount now": [
  null,
  "Koppel nu aan"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld, maar wordt niet aangekoppeld na de volgende keer opstarten."
 ],
 "Mount also automatically on boot": [
  null,
  "Koppel ook automatisch aan tijdens het opstarten"
 ],
 "Unmount now": [
  null,
  "Nu afkoppelen"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal niet aangekoppeld worden na de volgende opstart."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Het bestandssysteem is geconfigureerd om automatisch te worden aangekoppeld bij het opstarten, maar de encryptiecontainer wordt op dat moment niet ontgrendeld."
 ],
 "Unlock automatically on boot": [
  null,
  "Automatisch ontgrendelen bij opstarten"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inconsistente bestandssysteemkoppeling"
 ],
 "Filesystem name": [
  null,
  "Bestandssysteemnaam"
 ],
 "Filesystem is locked": [
  null,
  "Bestandssysteem is vergrendeld"
 ],
 "Mounts before services start": [
  null,
  "Aankoppelen voordat services starten"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Geschikt voor kritieke koppelingen, zoals /var"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Opstarten mislukt als het bestandssysteem niet aankoppelt, waardoor toegang op afstand wordt voorkomen"
 ],
 "Mounts in parallel with services": [
  null,
  "Aankoppelen in parallel met services"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Het opstarten lukt nog steeds als het bestandssysteem niet aankoppelt"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Wordt parallel met services gekoppeld, maar nadat het netwerk beschikbaar is"
 ],
 "Does not mount during boot": [
  null,
  "Wordt niet aangekoppeld tijdens het opstarten"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Handig voor aankoppelingen die optioneel zijn of interactie nodig hebben (zoals wachtwoordzinnen)"
 ],
 "At boot": [
  null,
  "Bij opstarten"
 ],
 "Mount before services start": [
  null,
  "Aankoppelen voordat de services starten"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Aankoppelen zonder te wachten, negeer mislukken"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Aankoppelen nadat het netwerk beschikbaar is, negeer de fout"
 ],
 "Do not mount": [
  null,
  "Koppel niet aan"
 ],
 "Mount filesystem": [
  null,
  "Bestandssysteem aankoppelen"
 ],
 "Unmount filesystem $0": [
  null,
  "Bestandssysteem $0 afkoppelen"
 ],
 "Mount configuration": [
  null,
  "Aankoppelconfiguratie"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Used": [
  null,
  "Gebruikt"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Ontgrendel versleutelde Stratis pool"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Geef de wachtzin voor de pool op deze blokapparaten:"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "Block devices": [
  null,
  "Blokapparaten"
 ],
 "Stratis block device": [
  null,
  "Stratis blokapparaat"
 ],
 "data": [
  null,
  "data"
 ],
 "If the keyserver at $0 is not reachable, you can provide an existing passphrase.": [
  null,
  "Als de sleutelserver op $0 niet bereikbaar is, kunt u een bestaande wachtwoordzin opgeven."
 ],
 "If none of the non-interactive unlock methods works, you can provide an existing passphrase.": [
  null,
  "Als geen van de niet-interactieve ontgrendelingsmethoden werkt, kunt u een bestaande wachtwoordzin opgeven."
 ],
 "Pool passphrase": [
  null,
  "Pool wachtzin"
 ],
 "The keyserver at $0 must be reachable.": [
  null,
  "De sleutelserver op $0 moet bereikbaar zijn."
 ],
 "At least one of the non-interactive unlock methods must work.": [
  null,
  "Er moet ten minste één van de niet-interactieve ontgrendelingsmethoden werken."
 ],
 "Create filesystem": [
  null,
  "Bestandssysteem aanmaken"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Verwijderen van een Stratis pool zal alle data die het bevat wissen."
 ],
 "Rename Stratis pool": [
  null,
  "Naam van Stratis pool wijzigen"
 ],
 "Add block devices": [
  null,
  "Voeg blokapparaten toe"
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Adding blockdevices requires unlocking the pool.": [
  null,
  "Om blokapparaten toe te voegen, moet de pool worden ontgrendeld."
 ],
 "Encrypted Stratis pool": [
  null,
  "Versleutelde Stratis pool"
 ],
 "Create new filesystem": [
  null,
  "Nieuw bestandssysteem aanmaken"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Deze pool gebruikt niet alle ruimte op zijn blokapparaten."
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Sommige blokapparaten van deze pool zijn groter geworden nadat de pool is gemaakt. De pool kan veilig worden vergroot om de nieuw beschikbare ruimte te gebruiken."
 ],
 "Grow the pool to take all space": [
  null,
  "Vergroot de pool om alle ruimte in te nemen"
 ],
 "This pool is in a degraded state.": [
  null,
  "Deze pool bevindt zich in een slechte staat."
 ],
 "No filesystems": [
  null,
  "Geen bestandssystemen"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Deze wachtzin is de enige manier om de pool te ontgrendelen en kan niet worden verwijderd."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Deze keyserver is de enige manier om de pool te ontgrendelen en kan niet worden verwijderd."
 ],
 "Add passphrase": [
  null,
  "Voeg wachtzin toe"
 ],
 "Add keyserver": [
  null,
  "Voeg sleutelserver toe"
 ],
 "No more space for passphrases or keyservers.": [
  null,
  "Geen ruimte meer voor wachtwoordzinnen of sleutelservers."
 ],
 "Confirm": [
  null,
  "Bevestigen"
 ],
 "Remove passphrase?": [
  null,
  "Wachtzin verwijderen?"
 ],
 "Add Tang keyserver": [
  null,
  "Voeg Tang sleutelserver toe"
 ],
 "Remove Clevis token?": [
  null,
  "Clevis-token verwijderen?"
 ],
 "Pools with metadata format V1 are restricted to at most one passphrase and at most one keyserver.": [
  null,
  "Pools met metadata-indeling V1 zijn beperkt tot maximaal één wachtwoordzin en maximaal één sleutelserver."
 ],
 "Allow overprovisioning": [
  null,
  "Overprovisioning toestaan"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "De grootte van het virtuele bestandssysteem is groter dan de pool. Overprovisioning kan niet worden uitgeschakeld."
 ],
 "Allocated": [
  null,
  "Toegewezen"
 ],
 "Name can not be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "A pool with this name exists already.": [
  null,
  "Er bestaat al een pool met deze naam."
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Er bestaat al een bestandssysteem met deze naam in deze pool."
 ],
 "Create Stratis pool": [
  null,
  "Maak Stratus pool aan"
 ],
 "No block devices are available.": [
  null,
  "Geen blokapparaten beschikbaar."
 ],
 "At least one block device is needed.": [
  null,
  "Minimaal één blokapparaat is noodzakelijk."
 ],
 "Encrypt data with a passphrase": [
  null,
  "Versleutel data met een wachtzin"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Versleutel data met een Tang sleutelserver"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Snapshot van bestandssysteem $0 aanmaken"
 ],
 "Create snapshot and mount": [
  null,
  "Maak snapshot en koppel aan"
 ],
 "Create snapshot only": [
  null,
  "Maak alleen een snapshot"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Verwijderen van een bestandssysteem zal alle data erop wissen."
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Rename filesystem": [
  null,
  "Bestandssysteem hernoemen"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Stel het limiet in voor de grootte van het virtuele bestandssysteem"
 ],
 "Create RAID device": [
  null,
  "Maak RAID-apparaat aan"
 ],
 "RAID level": [
  null,
  "RAID-niveau"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (spiegel)"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (toegewijde pariteit)"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (gedistribueerde pariteit)"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel gedistribueerde pariteit)"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe van spiegels)"
 ],
 "Chunk size": [
  null,
  "Brok grootte"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "At least $0 disk is needed.": [
  null,
  "Minimaal $0 schijf is noodzakelijk.",
  "Minimaal $0 schijven zijn noodzakelijk."
 ],
 "In sync": [
  null,
  "Synchroon"
 ],
 "Spare": [
  null,
  "Reserve"
 ],
 "Recovering": [
  null,
  "Herstellen"
 ],
 "Write-mostly": [
  null,
  "Meestal-schrijven"
 ],
 "Blocked": [
  null,
  "Geblokkeerd"
 ],
 "Unknown ($0)": [
  null,
  "Onbekend ($0)"
 ],
 "The MDRAID device must be running": [
  null,
  "Het MDRAID apparaat moet actief zijn"
 ],
 "Need a spare disk": [
  null,
  "Reserve schijf nodig"
 ],
 "Confirm stopping of $0": [
  null,
  "Bevestig het stoppen van $0"
 ],
 "Stop device": [
  null,
  "Stop apparaat"
 ],
 "Add disk": [
  null,
  "Schijf toevoegen"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "$0 disks": [
  null,
  "$0 schijven"
 ],
 "$0 chunk size": [
  null,
  "$0 brokgrootte"
 ],
 "Add a bitmap": [
  null,
  "Voeg een bitmap toe"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Verwijderen vernietigt alle data op een VDO-apparaat."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Het aanmaken van dit VDO-apparaat is niet voltooid en het apparaat kan niet gebruikt worden."
 ],
 "Remove device": [
  null,
  "Verwijder apparaat"
 ],
 "Grow to take all space": [
  null,
  "Vergroot om alle ruimte in te nemen"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Dit VDO-apparaat gebruikt niet al zijn achtergrondapparatuur."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Alleen $0 van $1 worden gebruikt."
 ],
 "Grow logical size of $0": [
  null,
  "Vergroot logische grootte van $0"
 ],
 "Physical": [
  null,
  "Fysiek"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 overhead gebruikt van $2 ($3)"
 ],
 "Logical": [
  null,
  "Logisch"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 gebruikt van $1 ($2 opgeslagen)"
 ],
 "Index memory": [
  null,
  "Indexgeheugen"
 ],
 "SMART self-test of $target": [
  null,
  "SMART zelftest van $target"
 ],
 "Ejecting $target": [
  null,
  "$target uitwerpen"
 ],
 "Unlocking $target": [
  null,
  "Ontgrendelen $target"
 ],
 "Locking $target": [
  null,
  "$target vergrendelen"
 ],
 "Modifying $target": [
  null,
  "$target aanpassen"
 ],
 "Resizing $target": [
  null,
  "Grootte van $target wijzigen"
 ],
 "Starting swapspace $target": [
  null,
  "Swapspace $target starten"
 ],
 "Stopping swapspace $target": [
  null,
  "Swapspace $target stoppen"
 ],
 "Mounting $target": [
  null,
  "$target aankoppelen"
 ],
 "Unmounting $target": [
  null,
  "$target afkoppelen"
 ],
 "Checking $target": [
  null,
  "Controleren van $target"
 ],
 "Repairing $target": [
  null,
  "$target repareren"
 ],
 "Erasing $target": [
  null,
  "$target wissen"
 ],
 "Creating filesystem on $target": [
  null,
  "Bestandssysteem op $target aanmaken"
 ],
 "Setting up loop device $target": [
  null,
  "Loop apparaat $target instellen"
 ],
 "Deleting $target": [
  null,
  "Verwijder $target"
 ],
 "Creating partition $target": [
  null,
  "Partitie $target aanmaken"
 ],
 "Cleaning up for $target": [
  null,
  "Opschonen voor $target"
 ],
 "Securely erasing $target": [
  null,
  "$target veilig wissen"
 ],
 "Very securely erasing $target": [
  null,
  "Zeer veilig wissen van $target"
 ],
 "Marking $target as faulty": [
  null,
  "$target als defect markeren"
 ],
 "Checking MDRAID device $target": [
  null,
  "Controleren van RAID-apparaat $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Controleren en repareren van MDRAID-apparaat $target"
 ],
 "Activating $target": [
  null,
  "Activeren $target"
 ],
 "Deactivating $target": [
  null,
  "$target deactiveren"
 ],
 "Creating snapshot of $target": [
  null,
  "Snapshot van $target aanmaken"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2-Volumegroep $target aanmaken"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2-volumegroep $target verwijderen"
 ],
 "Adding physical volume to $target": [
  null,
  "Toevoegen van fysieke volume aan $target"
 ],
 "Removing physical volume from $target": [
  null,
  "Fysiek volume verwijderen uit $target"
 ],
 "Emptying $target": [
  null,
  "$target leegmaken"
 ],
 "Creating logical volume $target": [
  null,
  "Logisch volume $target aanmaken"
 ],
 "Renaming $target": [
  null,
  "Hernoem $target"
 ],
 "Operation '$operation' on $target": [
  null,
  "Bewerking '$operation' op $target"
 ],
 "unknown target": [
  null,
  "onbekend doel"
 ],
 "Jobs": [
  null,
  "Taken"
 ],
 "Reading": [
  null,
  "Lezen"
 ],
 "Writing": [
  null,
  "Schrijven"
 ],
 "Install Stratis support": [
  null,
  "Installeer Stratis-ondersteuning"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Het $0 pakket moet worden geïnstalleerd om Stratis pools aan te maken."
 ],
 "Install NFS support": [
  null,
  "Installeer NFS-ondersteuning"
 ],
 "Create MDRAID device": [
  null,
  "Maak MDRAID-apparaat aan"
 ],
 "Create LVM2 volume group": [
  null,
  "Aanmaken LVM2-volumegroep"
 ],
 "Change iSCSI initiator name": [
  null,
  "Verander naam van de iSCSI-initiator"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI-portaal toevoegen"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradres mag niet leeg zijn."
 ],
 "Next": [
  null,
  "Volgende"
 ],
 "Invalid username or password": [
  null,
  "Ongeldige gebruikersnaam of wachtwoord"
 ],
 "Unknown host name": [
  null,
  "Onbekende hostnaam"
 ],
 "Unable to reach server": [
  null,
  "Kan server niet bereiken"
 ],
 "Available targets on $0": [
  null,
  "Beschikbare doelen op $0"
 ],
 "Authentication required": [
  null,
  "Authenticatie is vereist"
 ],
 "Target": [
  null,
  "Doel"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ondersteuningsapparaten kunnen niet kleiner gemaakt worden"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs kunnen niet kleiner gemaakt worden"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Onbekende data kan hier niet kleiner gemaakt worden."
 ],
 "Unlock before resizing": [
  null,
  "Ontgrendelen voordat het formaat wijzigt"
 ],
 "$0 can not be resized here": [
  null,
  "De grootte van $0 kan hier niet gewijzigd worden"
 ],
 "$0 can not be resized": [
  null,
  "De grootte van $0 kan niet gewijzigd worden"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 kunnen niet worden verkleind"
 ],
 "$0 can not be made larger": [
  null,
  "$0 kunnen niet worden uitgebreid"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Fysieke volumes kunnen hier niet aangepast worden"
 ],
 "Swap can not be resized here": [
  null,
  "Seap kan hier niet gewijzigd worden"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Onbekende data kan hier niet kleiner gemaakt worden"
 ],
 "Activate before resizing": [
  null,
  "Activeren vóór het formaat wijzigen"
 ],
 "Grow logical volume": [
  null,
  "Vergroot logische volume"
 ],
 "Grow partition": [
  null,
  "Laat partitie groeien"
 ],
 "grow": [
  null,
  "toenemen"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Er moeten exact $0 fysieke volumes worden geselecteerd"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Het wijzigen van de grootte van een versleuteld bestandssysteem vereist dat de schijf wordt ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Er moeten exact $0 fysieke volumes worden geselecteerd, één voor elke streep van het logische volume."
 ],
 "Shrink logical volume": [
  null,
  "Krimp logische volume"
 ],
 "shrink": [
  null,
  "krimpen"
 ],
 "Block device": [
  null,
  "Blokkeer apparaat"
 ],
 "Create partition on $0": [
  null,
  "Partitie aanmaken op $0"
 ],
 "Format $0": [
  null,
  "$0 formatteren"
 ],
 "No filesystem": [
  null,
  "Geen bestandssysteem"
 ],
 "(recommended)": [
  null,
  "(aanbevolen)"
 ],
 "No encryption": [
  null,
  "Geen versleuteling"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Hergebruiken van bestaande versleuteling ($0)"
 ],
 "Reuse existing encryption": [
  null,
  "Bestaande versleuteling hergebruiken"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "Format and mount": [
  null,
  "Formatteren en aankoppelen"
 ],
 "Format only": [
  null,
  "Alleen formatteren"
 ],
 "Format": [
  null,
  "Formatteren"
 ],
 "Store passphrase": [
  null,
  "Sla wachtzin op"
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "De schijf moet worden ontgrendeld voor het formatteren. Geef een bestaande wachtzin op."
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatteren verwijdert alle data op een opslagapparaat."
 ],
 "Unrecognized data": [
  null,
  "Onbekende data"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Opslag kan op dit systeem niet beheerd worden."
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
