cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 $1": [
  null,
  "$0 $1"
 ],
 "$0 ($1)": [
  null,
  "$0 ($1)"
 ],
 "$0 error": [
  null,
  "$0 virhe",
  "$0 virhettä"
 ],
 "$0 installation": [
  null,
  "$0:n asennus"
 ],
 "$0 installer": [
  null,
  "$0:n asennusohjelmas"
 ],
 "$0 is an MBR extended partition that contains logical partitions. Removing all logical partitions will also automatically remove the extended partition.": [
  null,
  "$0 on MBR-laajennettu osio, joka sisältää loogisia osioita. Kaikkien loogisten osioiden poistaminen poistaa automaattisesti myös laajennetun osion."
 ],
 "$0 is required, but only $1 is available.": [
  null,
  "$0 vaaditaan, mutta vain $1 on saatavilla."
 ],
 "$0 warning": [
  null,
  "$0 varoitus",
  "$0 varoitusta"
 ],
 "$0 will be deleted": [
  null,
  "$0 poistetaan"
 ],
 "'$0' filesystem cannot be on an encrypted block device": [
  null,
  "Tiedostojärjestelmä '$0' ei voi olla salatussa lohkolaitteessa"
 ],
 "'$0' must be on a device formatted to '$1'": [
  null,
  "'$0':n on oltava '$1':ksi alustetussa laitteessa"
 ],
 "'$0' must be on an EFI System Partition. The selected partition uses a FAT filesystem, but is not marked as an ESP. Set the partition type to EFI System and enable the esp flag.": [
  null,
  ""
 ],
 "'$0' partition on MDRAID device $1 found. Bootloader partitions on MDRAID devices are not supported.": [
  null,
  "Osio '$0' MDRAID-laitteella $1 löytyi. Käynnistyslataimen osiot MDRAID-laitteilla ei tueta."
 ],
 "A standard user account with admin access for making system-wide changes.": [
  null,
  "Tavallinen käyttäjätili, jolla on järjestelmänvalvojan käyttöoikeudet järjestelmän laajuisten muutosten tekemiseen."
 ],
 "About": [
  null,
  "Aiheesta"
 ],
 "Account": [
  null,
  "Tili"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Add another server...": [
  null,
  "Lisää toinen palvelin..."
 ],
 "Add mount": [
  null,
  "Lisää liitos"
 ],
 "Add-ons for your chosen environment": [
  null,
  "Lisäohjelmisto valittuun ympäristöön"
 ],
 "Add-ons not specific to your environment": [
  null,
  "Lisäosat, jotka eivät ole spesifisiä ympäristöllesi"
 ],
 "Additional languages": [
  null,
  "Lisäkielet"
 ],
 "Additional software for the selected environment": [
  null,
  "Lisäohjelmisto valittuun ympäristöön"
 ],
 "All changes made in the storage editor take effect immediately.": [
  null,
  "Kaikki tallennusmuokkaimeen tehdyt muutokset astuvat voimaan välittömästi."
 ],
 "All devices using this passphrase will be unlocked": [
  null,
  "Kaikki tätä tunnuslausetta käyttävät laitteet avataan"
 ],
 "Anaconda Web UI": [
  null,
  "Anaconda-verkkokäyttöliittymä"
 ],
 "Anaconda project page": [
  null,
  "Anaconda-projektin sivu"
 ],
 "Apply mount point assignment and install": [
  null,
  "Sovella liitoskohtien määritystä ja asenna"
 ],
 "Applying changes...": [
  null,
  "Muutoksia sovelletaan..."
 ],
 "Assign partitions to mount points. Useful for pre-configured custom layouts.": [
  null,
  "Määritä osiot liitoskohdille. Hyödyllinen esikonfiguroiduille mukautetuille asetteluille."
 ],
 "Automatic log file upload": [
  null,
  "Lokitiedoston automaattinen lataus"
 ],
 "Automatically set date and time, using time servers": [
  null,
  "Aseta automaattisesti päivämäärä ja aika käyttämällä aikapalvelimia"
 ],
 "Automatically set timezone": [
  null,
  "Aseta aikavyöhyke automaattisesti"
 ],
 "Available free space: $0. Installation requires: $1.": [
  null,
  "Käytettävissä oleva vapaa tila: $0. Asennus vaatii: $1."
 ],
 "Back": [
  null,
  "Takaisin"
 ],
 "Base environment": [
  null,
  "Perusympäristö"
 ],
 "Brief description of the issue": [
  null,
  "Lyhyt kuvaus ongelmasta"
 ],
 "Bug report details": [
  null,
  "Virheraportin tiedot"
 ],
 "Bugzilla API key": [
  null,
  "Bugzillan API-avain"
 ],
 "By continuing to use this software, you understand and accept the risks associated with pre-released software, that you intend to use this for testing and development purposes only and are willing to report any bugs or issues in order to enhance this work.": [
  null,
  "Jatkamalla tämän ohjelman käyttämistä ymmärrät ja hyväksyt esijulkaisuun liittyvät riskit, aiot käyttää ohjelmistoa vain kehitys- ja testaustarkoituksiin, ja olet halukas ilmoittamaan mahdollisista ongelmista parantaaksesi tätä ohjelmistoa."
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change destination": [
  null,
  "Muuta kohdetta"
 ],
 "Change hostname": [
  null,
  "Vaihda isäntänimi"
 ],
 "Change partition layout": [
  null,
  "Muuta osion asettelua"
 ],
 "Change system keyboard layout": [
  null,
  "Vaihda järjestelmän näppäimistön asettelu"
 ],
 "Changes made here will immediately affect the system. There is no 'undo'.": [
  null,
  "Täällä tehdyt muutokset vaikuttavat välittömästi järjestelmään. \"Kumoa\" ei ole."
 ],
 "Checking installation configuration...": [
  null,
  "Tarkistetaan asennuksen kokoonpanoa..."
 ],
 "Checking storage configuration": [
  null,
  "Tarkistetaan tallennustilan asetuksia"
 ],
 "Clear search": [
  null,
  "Tyhjennä haku"
 ],
 "Click 'Next' again to proceed despite these warnings.": [
  null,
  "Jatka näistä varoituksista huolimatta napsauttamalla uudelleen Seuraava."
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Close storage editor": [
  null,
  "Sulje tallennusmuokkkain"
 ],
 "Cockpit storage did not provide the passphrase to unlock encrypted device.": [
  null,
  "Cockpit-tallennustila ei tarjonnut pääsylausetta salatun laitteen lukituksen avaamiseen."
 ],
 "Completed": [
  null,
  "Valmis"
 ],
 "Configuration is incomplete": [
  null,
  "Määritys on keskeneräinen"
 ],
 "Configure NTP servers": [
  null,
  "Määritä NTP-palvelimet"
 ],
 "Configure custom NTP servers": [
  null,
  "Määritä mukautetut NTP-palvelimet"
 ],
 "Configure network": [
  null,
  "Määritä verkko"
 ],
 "Configure storage": [
  null,
  "Määritä tallennustila"
 ],
 "Configure storage again": [
  null,
  "Määritä tallennustila uudelleen"
 ],
 "Confirm passphrase": [
  null,
  "Vahvista salalause"
 ],
 "Continue": [
  null,
  "Jatka"
 ],
 "Continue installation": [
  null,
  "Jatka asennusta"
 ],
 "Continue with installation": [
  null,
  "Jatka asennuksella"
 ],
 "Correct these issues before continuing.": [
  null,
  "Korjaa nämä ongelmat ennen jatkamista."
 ],
 "Create Account": [
  null,
  "Luo tili"
 ],
 "Create account": [
  null,
  "Luo tili"
 ],
 "Currently installed: $0": [
  null,
  "Tällä hetkellä asennettuna: $0"
 ],
 "Custom": [
  null,
  "Mukautettu"
 ],
 "Date": [
  null,
  "Päivämäärä"
 ],
 "Date and time": [
  null,
  "Päivämäärä ja aika"
 ],
 "Delete partition": [
  null,
  "Poista osio"
 ],
 "Deletion of certain partitions may prevent $0 from booting: $1": [
  null,
  "Tiettyjen osioiden poistaminen voi estää $0:n käynnistymisen: $1"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Destination": [
  null,
  "Kohde"
 ],
 "Destination is encrypted": [
  null,
  "Määränpää on salattu"
 ],
 "Detailed description of the issue": [
  null,
  "Yksityiskohtainen kuvaus ongelmasta"
 ],
 "Detected valid storage layout:": [
  null,
  "Havaittu kelvollinen tallennusasettelu:"
 ],
 "Device": [
  null,
  "Laite"
 ],
 "Duplicate device.": [
  null,
  "Laitteen kaksoiskappale."
 ],
 "Duplicate mount point.": [
  null,
  "Monista liitoskohta."
 ],
 "Enable root account": [
  null,
  "Ota root-tili käyttöön"
 ],
 "Encrypt my data": [
  null,
  "Salaa tietoni"
 ],
 "Encrypted": [
  null,
  "Salattu"
 ],
 "Encryption": [
  null,
  "Salaus"
 ],
 "Enter PIN": [
  null,
  ""
 ],
 "Enter PIN to access the installer": [
  null,
  ""
 ],
 "Enter your Bugzilla API key to create a bug report. You will be able to review and edit the bug details in the next step.": [
  null,
  "Syötä Bugzilla API -avaimesi luodaksesi virheraportin. Voit tarkastella ja muokata virheen tietoja seuraavassa vaiheessa."
 ],
 "Environment": [
  null,
  "Ympäristö"
 ],
 "Erase data and install": [
  null,
  "Tyhjennä levyt ja asenna"
 ],
 "Error details": [
  null,
  "Virheen tiedot"
 ],
 "Exit to live desktop": [
  null,
  "Poistu reaaliaikaiseen työpöytään"
 ],
 "Extended partition": [
  null,
  "Laajennettu osio"
 ],
 "Failed to report issue": [
  null,
  "Ongelman ilmoittaminen epäonnistui"
 ],
 "Failed to save layouts": [
  null,
  "Asettelujen tallentaminen epäonnistui"
 ],
 "Fedora linux requires at least $0 of disk space.": [
  null,
  "Fedora Linux vaatii vähintään $0 levytilaa."
 ],
 "Finalization": [
  null,
  "Viimeistely"
 ],
 "Finalizing: The system configuration is complete. Finalizing installation may take a few moments.": [
  null,
  "Viimeistely: Järjestelmän konfigurointi on valmis. Asennuksen viimeistely voi kestää hetken."
 ],
 "Find layout": [
  null,
  "Etsi asettelu"
 ],
 "For better security, avoid using the root account directly. Instead, use the local account above to manage the system.": [
  null,
  "Paremman turvallisuuden takaamiseksi vältä root-tilin käyttöä suoraan. Käytä sen sijaan yllä olevaa paikallista tiliä järjestelmän hallintaan."
 ],
 "Full name": [
  null,
  "Koko nimi"
 ],
 "Full name cannot contain colon characters": [
  null,
  "Koko nimi ei saa sisältää kaksoispisteitä"
 ],
 "Helper text": [
  null,
  "Avustava teksti"
 ],
 "Hide API key": [
  null,
  "Piilota API-avain"
 ],
 "Hide confirmed password": [
  null,
  "Piilota vahvistettu salasana"
 ],
 "Hide passphrase": [
  null,
  "Piilota tunnuslause"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "Hostname": [
  null,
  "Koneen nimi"
 ],
 "How would you like to install?": [
  null,
  "Miten haluaisit asentaa?"
 ],
 "I understand that all existing data will be erased": [
  null,
  "Ymmärrän, että kaikki olemassa olevat tiedot poistetaan valituilta levyiltä",
  "Ymmärrän, että kaikki olemassa olevat tiedot poistetaan"
 ],
 "I understand that some existing data will be erased": [
  null,
  "Ymmärrän, että osa olemassa olevista tiedoista poistetaan"
 ],
 "I understand that some partitions will be modified": [
  null,
  "Ymmärrän, että joitain osioita muutetaan"
 ],
 "If empty, hostname will be transient and set by network information.": [
  null,
  "Jos tyhjänä, isäntänimi on ohimenevä ja verkon tietojen määräämä."
 ],
 "If none of the options above apply, use the storage editor to create a custom partitioning before proceeding.": [
  null,
  ""
 ],
 "If you are configuring partitions the following are required:": [
  null,
  "Jos määrität osioita, seuraavat vaaditaan:"
 ],
 "If you do not consent to automatic log file upload, you can $0 instead. Manual reporting allows you to review and selectively attach log files yourself.": [
  null,
  "Jos et suostu lokitiedostojen automaattiseen lataamiseen, voit sen sijaan $0. Manuaalisen raportoinnin avulla voit tarkastella ja liittää lokitiedostoja itse."
 ],
 "If you do not understand or accept the risks, then please exit this program.": [
  null,
  "Jos et ymmärrä tai hyväksy riskejä, poistu tästä ohjelmasta."
 ],
 "If your issue matches one of the bugs above, you can open it and add your information there instead of creating a duplicate report.": [
  null,
  ""
 ],
 "In progress": [
  null,
  "Meneillään"
 ],
 "Initializing...": [
  null,
  "Alustetaan ..."
 ],
 "Install": [
  null,
  "Asenna"
 ],
 "Installation failed": [
  null,
  "Asennus epäonnistui"
 ],
 "Installation method": [
  null,
  "Asennustapa"
 ],
 "Installation of the system failed": [
  null,
  "Järjestelmän asennus epäonnistui"
 ],
 "Installation of the system failed: $0": [
  null,
  "Järjestelmän asennus epäonnistui: $0"
 ],
 "Installation type": [
  null,
  "Asennustyyppi"
 ],
 "Installing": [
  null,
  "Asennetaan"
 ],
 "Insufficient disk space": [
  null,
  "Riittämätön levytila"
 ],
 "Invalid PIN. Please try again.": [
  null,
  ""
 ],
 "Invalid RAID configuration detected. If your RAID array is created directly on top of disks, a partition table must be created on the array. If your RAID array is created on top of partitions, it must contain a single filesystem or format (e.g., LVM PV). Any existing partitions on this array will be ignored.": [
  null,
  "Epäkelvollinen RAID-kokoonpano havaittu. Jos RAID-ryhmäsi luodaan suoraan levyjen päälle, taulukkoon on luotava osiotaulukko. Jos RAID-ryhmäsi luodaan osioiden päälle, sen on sisällettävä yksi tiedostojärjestelmä tai muoto (esim. LVM PV). Kaikki tässä taulukossa olemassa olevat osiot ohitetaan."
 ],
 "Invalid hostname": [
  null,
  "Ei kelvollinen isäntänimi"
 ],
 "Jump to first incomplete step": [
  null,
  "Siirry ensimmäiseen keskeneräiseen vaiheeseen"
 ],
 "Keep current disk layout and use available space, to dual-boot with another OS.": [
  null,
  "Säilytä nykyinen levyasettelu ja käytä käytettävissä olevaa tilaa kaksoiskäynnistykseen toisen käyttöjärjestelmän kanssa."
 ],
 "Keyboard": [
  null,
  "Näppäimistö"
 ],
 "Keyboard layout during boot": [
  null,
  "Näppäimistön asettelu käynnistyksen aikana"
 ],
 "Language": [
  null,
  "Kieli"
 ],
 "Launch storage editor": [
  null,
  "Käynnistä tallennusmuokkain"
 ],
 "Learn more about restricted access in the configuration": [
  null,
  "Lisätietoja rajoitetusta pääsystä kokoonpanossa"
 ],
 "Leave both passphrase fields empty to use an empty password.": [
  null,
  ""
 ],
 "Location": [
  null,
  "Sijainti"
 ],
 "Locked devices": [
  null,
  "Lukitut laitteet"
 ],
 "Make current": [
  null,
  "Tee nykyiseksi"
 ],
 "Manual disk configuration": [
  null,
  "Manuaalinen levyn konfigurointi"
 ],
 "Manual disk configuration: Mount point mapping": [
  null,
  "Manuaalinen levyjen määritys: Liitoskohtien kartoitus"
 ],
 "May contain letters, numbers, and dashes.": [
  null,
  "Saattaa sisältää kirjaimia, numeroita ja viivoja."
 ],
 "May need more free space": [
  null,
  "Saattaa tarvita lisää vapaata tilaa"
 ],
 "Medium": [
  null,
  "Keskivahva"
 ],
 "Minimum of $0 required": [
  null,
  "Vähintään $0 tarvitaan"
 ],
 "Mismatch between parent device and child device reformat selection.": [
  null,
  "Isäntälaitteen ja alalaitteen uudelleenmuotoilun valinta ei vastaa toisiaan."
 ],
 "Mount point": [
  null,
  "Liitoskohta"
 ],
 "Mount point assignment": [
  null,
  "Liitoskohdan määrittely"
 ],
 "Move down": [
  null,
  "Siirry alaspäin"
 ],
 "Move up": [
  null,
  "Siirry ylöspäin"
 ],
 "Must be at least $0 characters": [
  null,
  "On oltava vähintään $0 merkkiä"
 ],
 "My issue is different, continue": [
  null,
  ""
 ],
 "NTP Servers": [
  null,
  "NTP-palvelimet"
 ],
 "NTS": [
  null,
  "NTS"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Needs at least $0": [
  null,
  "Tarvitsee vähintään $0"
 ],
 "Network": [
  null,
  "Verkko"
 ],
 "Network Configuration": [
  null,
  "Verkkoasetukset"
 ],
 "Network not available. Configure the network in the top bar menu to report the issue.": [
  null,
  "Verkko ei ole käytettävissä. Määritä verkko yläpalkin valikossa ilmoittaaksesi ongelmasta."
 ],
 "Network not available. Configure the network to report the issue.": [
  null,
  "Verkko ei ole käytettävissä. Määritä verkko ilmoittaaksesi viasta."
 ],
 "Network plugin failed": [
  null,
  "verkkolaajennus epäonnistui"
 ],
 "Next": [
  null,
  "Seuraava"
 ],
 "No devices": [
  null,
  "Ei laiteita"
 ],
 "No disks available": [
  null,
  "Levyjä ei saatavilla"
 ],
 "No disks selected": [
  null,
  "Yhtään levyä ei ole valittu"
 ],
 "No layouts selected yet": [
  null,
  "Ei vielä valittuja asetteluja"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "No valid VConsole keymap can be obtained for the selected keyboard layout(s). Please make a different keyboard layout selection.": [
  null,
  "Valitulle näppäimistöasettelulle/asetteluille ei löydy kelvollista VConsole-näppäinkarttaa. Valitse toinen näppäimistöasettelu."
 ],
 "Not enough available free space": [
  null,
  "Ei tarpeeksi levytilaa vapaana"
 ],
 "Not enough free space on the selected disks.": [
  null,
  "Valituilla levyillä ei ole riittävästi vapaata tilaa."
 ],
 "Not enough space on selected disks.": [
  null,
  "Valituilla levyillä ei ole riittävästi vapaata tilaa."
 ],
 "Notice: This is pre-released software that is intended for development and testing purposes only. Do NOT use this software for any critical work or for production environments.": [
  null,
  "Huomautus: Tämä on esijulkaistu ohjelmisto, joka on tarkoitettu vain kehitys- ja testaustarkoituksiin. ÄLÄ käytä tätä ohjelmistoa kriittisissä töissä tai tuotantoympäristöissä."
 ],
 "Open Bugzilla bug entry form": [
  null,
  "Avaa Bugzillan virheilmoituslomake"
 ],
 "Operating system": [
  null,
  "Käyttöjärjestelmä"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Other keyboards": [
  null,
  "Muut näppäimistöt"
 ],
 "Partitions (advanced)": [
  null,
  "Osiot (edistynyt)"
 ],
 "Passphrase": [
  null,
  "Tunnuslause"
 ],
 "Passphrase did not match any locked device": [
  null,
  "Pääsylause ei vastannut mitään lukittua laitetta"
 ],
 "Passphrases must match": [
  null,
  "Tunnuslauseiden on oltava samat"
 ],
 "Pending": [
  null,
  "Odottaa"
 ],
 "Please attach the log file $0 to the issue.": [
  null,
  "Liitä lokitiedosto $0 vikaraporttiin."
 ],
 "Please select at least one disk to continue": [
  null,
  "Valitse vähintään yksi levy jatkaaksesi"
 ],
 "Pool": [
  null,
  "Varanto"
 ],
 "Powered by Anaconda": [
  null,
  "Pellin alla Anaconda"
 ],
 "Pre-release": [
  null,
  "Esijulkaisu"
 ],
 "Prefer to report manually? $0": [
  null,
  "Haluatko mieluummin tehdä raportin manuaalisesti? $0"
 ],
 "Proceed with installation": [
  null,
  "Jatka asentamista"
 ],
 "Quit": [
  null,
  "Lopeta"
 ],
 "Quit installer?": [
  null,
  "_Poistu asennusohjelmasta?"
 ],
 "Reading information about the OS failed.": [
  null,
  "Käyttöjärjestelmää koskevien tietojen lukeminen epäonnistui."
 ],
 "Reading information about the computer failed.": [
  null,
  "Tietokoneen tietojen lukeminen epäonnistui."
 ],
 "Reading installer configuration failed.": [
  null,
  "Asennusohjelman asetusten lukeminen epäonnistui."
 ],
 "Reading installer version information failed.": [
  null,
  "Asennusohjelman versiotietojen lukeminen epäonnistui."
 ],
 "Real hostname can only contain characters, digits, dashes (not starting or ending a character) and dots": [
  null,
  "Oikea isäntänimi voi sisältää vain merkkejä, numeroita, viivoja (ei merkin alkua tai loppua) ja pisteitä"
 ],
 "Real hostname must be 64 characters or less": [
  null,
  "Oikea isäntänimi saa olla enintään 64 merkkiä pitkä"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Reboot into Windows to resize BitLocker-encrypted partitions. Make at least $0 of free space available for installation.": [
  null,
  "Käynnistä Windows uudelleen muuttaaksesi BitLocker-salattujen osioiden kokoa. Varaa vähintään $0 vapaata tilaa asennusta varten."
 ],
 "Reboot system?": [
  null,
  "Käynnistä järjestelmä uudelleen?"
 ],
 "Reclaim additional space": [
  null,
  "Pyydä lisää tilaa takaisin"
 ],
 "Reclaim space": [
  null,
  "Vapauta tilaa"
 ],
 "Reclaim space (required)": [
  null,
  "Pyydä tila takaisin (pakollinen)"
 ],
 "Recommended": [
  null,
  "Suositeltu"
 ],
 "Recommended partitions:": [
  null,
  "Suositellut osiot:"
 ],
 "Reformat": [
  null,
  "Alusta uudelleen"
 ],
 "Reinstall Fedora": [
  null,
  "Asenna Fedora uudelleen"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Remove all partitions on the selected devices, including existing operating systems.": [
  null,
  "Poista kaikki osiot valituista laitteista, mukaan lukien olemassa olevat käyttöjärjestelmät."
 ],
 "Remove or resize existing filesystems to free up space for the installation.": [
  null,
  "Vapauta tilaa asennusta varten poistamalla olemassa olevat tiedostojärjestelmät tai muuttamalla niiden kokoja."
 ],
 "Remove server": [
  null,
  "Poista palvelin"
 ],
 "Removing a filesystem will permanently delete all of the data it contains. Resizing a partition can free up unused space, but is not risk-free. Be sure to have backups of anything important before reclaiming space.": [
  null,
  "Tiedostojärjestelmän poistaminen poistaa pysyvästi kaikki sen sisältämät tiedot. Osion koon muuttaminen voi vapauttaa käyttämätöntä tilaa, mutta se ei välttämättä ole vaaratonta. Varmista, että sinulla on varmuuskopiot kaikesta tärkeästä ennen tilan palauttamista."
 ],
 "Replace current installation, but keep files in home.": [
  null,
  "Korvaa nykyinen asennus, mutta säilytä tiedostot kotona."
 ],
 "Report Issue": [
  null,
  "Ilmoita ongelmasta"
 ],
 "Report an issue or provide feedback by opening the Bugzilla bug entry form $0.": [
  null,
  "Ilmoita ongelmasta tai anna palautetta avaamalla Bugzillan virheilmoituslomake $0."
 ],
 "Report issue": [
  null,
  "Ilmoita ongelmasta"
 ],
 "Reporting issue...": [
  null,
  "Ilmoitetaan ongelmasta..."
 ],
 "Required": [
  null,
  "Vaaditaan"
 ],
 "Requirements": [
  null,
  "Vaatimukset"
 ],
 "Rescan devices": [
  null,
  "tutki laitteet uudelleen"
 ],
 "Rescanning of the disks failed.": [
  null,
  "Levyjen uudelleenskannaus epäonnistui."
 ],
 "Resize": [
  null,
  "Muuta kokoa"
 ],
 "Resize partition": [
  null,
  "Muuta osion kokoa"
 ],
 "Resizing the following partitions from $0: $1": [
  null,
  "Seuraavien osioiden koon muuttaminen $0:sta: $1"
 ],
 "Restrict access to the report": [
  null,
  "Rajoita pääsyä ilmoitukseen"
 ],
 "Restricts the report to the $0 group. $1": [
  null,
  "Rajaa raportin $0-ryhmään. $1"
 ],
 "Return to installation": [
  null,
  "Palaa asennukseen"
 ],
 "Return to storage editor": [
  null,
  "Palaa tallennusmuokkaimeen"
 ],
 "Review and install": [
  null,
  "Arvioi ja asenna"
 ],
 "Root account is enabled": [
  null,
  "Root-tili on otettu käyttöön"
 ],
 "Root account is enabled, but no user account has been configured": [
  null,
  "Root-tili on otettu käyttöön, mutta käyttäjätiliä ei ole määritetty"
 ],
 "Root password has been set.": [
  null,
  "Root-salasana on asetettu."
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Scan the QR code with your phone or visit:": [
  null,
  "Skannaa QR-koodi puhelimellasi tai käy:"
 ],
 "Search for a language": [
  null,
  "Hae kieli"
 ],
 "Search for additional software": [
  null,
  "Hae lisäohjelmistoja"
 ],
 "Search for an environment": [
  null,
  "Hae ympäristöä"
 ],
 "Search keyboard layout": [
  null,
  "Etsi näppäimistöasettelu"
 ],
 "Secure your data using disk-based encryption. Only applies to new partitions": [
  null,
  "Suojaa tietosi levypohjaisella salauksella. Soveltuu vain uusiin osioihin"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "Select a device": [
  null,
  "Valitse laite"
 ],
 "Select city": [
  null,
  "Valitse kaupunki"
 ],
 "Select destination": [
  null,
  "Valitse kohde"
 ],
 "Select region": [
  null,
  "Valitse alue"
 ],
 "Selected (top = current)": [
  null,
  "Valittuna (ylin = nykyinen)"
 ],
 "Selected device's format '$0' cannot be reformatted.": [
  null,
  "Valitun laitteen muotoa '$0' ei voi alustaa uudelleen."
 ],
 "Send us feedback on your installation": [
  null,
  "Lähetä meille palautetta asennuksestasi"
 ],
 "Server": [
  null,
  "Palvelin"
 ],
 "Server is not reachable": [
  null,
  "Palvelin ei ole tavoitettavissa"
 ],
 "Set custom hostname": [
  null,
  "Määritä mukautettu isäntänimi"
 ],
 "Share disk with other operating systems": [
  null,
  "Jaa levy muiden käyttöjärjestelmien kanssa"
 ],
 "Share disk with other operating systems: $0": [
  null,
  "Jaa levy muiden käyttöjärjestelmien kanssa: $0"
 ],
 "Show AM/PM": [
  null,
  "Näytä ap./ip."
 ],
 "Show API key": [
  null,
  "Näytä API-avain"
 ],
 "Show confirmed password": [
  null,
  "Näytä vahvistettu salasana"
 ],
 "Show passphrase": [
  null,
  "Näytä tunnuslause"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Software installation": [
  null,
  "Ohjelmiston asennus"
 ],
 "Software installation: Storage configuration complete. The software is now being installed onto your device.": [
  null,
  "Ohjelmiston asennus: Tallennuskokoonpano on valmis. Ohjelmistoa asennetaan nyt laitteellesi."
 ],
 "Software selection": [
  null,
  "Ohjelmistovalinta"
 ],
 "Some installation steps still need to be completed before you can continue.": [
  null,
  "Jotkin asennusvaiheet on vielä suoritettava ennen kuin voit jatkaa."
 ],
 "Some required partitions are missing: $0": [
  null,
  "Jotkut pakolliset osiot puuttuvat: $0"
 ],
 "Space": [
  null,
  "Tila"
 ],
 "Stacktrace": [
  null,
  "Stacktrace"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Storage configuration": [
  null,
  "Tallennustilan määritykset"
 ],
 "Storage configuration: Storage is currently being configured.": [
  null,
  "Tallennustilan määritys: Tallennustilaa konfiguroidaan parhaillaan."
 ],
 "Storage editor": [
  null,
  "Tallennusmuokkkain"
 ],
 "Storage is based on the configuration from 'Modify storage'.": [
  null,
  "Tallennus perustuu 'Muokkaa tallennustilaa':n kokoonpanoon."
 ],
 "Storage layout is defined by the kickstart file. The planned partitioning layout can be reviewed in the summary step.": [
  null,
  "Tallennustilan asettelu määritellään kickstart-tiedostossa. Suunniteltua osiointiasettelua voidaan tarkastella yhteenvetovaiheessa."
 ],
 "Storage plugin failed": [
  null,
  "Tallennustilalaajennus epäonnistui"
 ],
 "Storage requirements not met": [
  null,
  "Tallennustilavaatimukset eivät täyty"
 ],
 "Strong": [
  null,
  "Vahva"
 ],
 "Successfully installed": [
  null,
  "Asennus onnistui"
 ],
 "Successfully unlocked $0.": [
  null,
  "$0:n lukituksen avattu onnistuneesti."
 ],
 "Suggested keyboards": [
  null,
  "Ehdotetut näppäimistöt"
 ],
 "Suggested languages": [
  null,
  "Ehdotetut kielet"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "System configuration": [
  null,
  "Järjestelmän kokoonpano"
 ],
 "System configuration: Software installation complete. The system is now being configured.": [
  null,
  "Järjestelmän konfigurointi: Ohjelmiston asennus valmis. Järjestelmää konfiguroidaan nyt."
 ],
 "The Anaconda installation has stopped unexpectedly.": [
  null,
  "Anacondan asennus on pysähtynyt odottamatta."
 ],
 "The following open bugs may be related to your issue. Please review them before creating a new report.": [
  null,
  ""
 ],
 "The following user will be created:": [
  null,
  "Seuraava käyttäjä luodaan:",
  "Seuraavat käyttäjät luodaan:"
 ],
 "The installation needs $0 of disk space; however, the capacity of the selected disks is only $1.": [
  null,
  "Asennus vaatii $0 levytilaa; valittujen levyjen kapasiteetti on kuitenkin vain $1."
 ],
 "The installer cannot continue due to a critical error.": [
  null,
  "Asennuksen jatkaminen ei onnistu kriittisen virheen vuoksi."
 ],
 "The installer cannot continue due to a critical error: $0": [
  null,
  "Asennusprosessia ei voi jatkaa kriittisen virheen vuoksi: $0"
 ],
 "The keyboard layout has changed since the disk encryption passphrase was set. Please re-enter the passphrase.": [
  null,
  ""
 ],
 "The passphrase you have provided contains non-ASCII characters. You may not be able to switch between keyboard layouts when typing it.": [
  null,
  "Antamasi salalause sisältää merkkejä, jotka eivät ole ASCII:ta. Jos näppäimistöasettelua vaihdetaan, kirjautuminen ei ehkä onnistu."
 ],
 "The selected default keyboard layout does not support ASCII characters. Please choose an ASCII-capable layout as the default.": [
  null,
  "Valittuna oleva oletusnäppäimistöasettelu ei tue ASCII-merkkejä. Valitse oletukseksi ASCII-kykenevä asettelu."
 ],
 "The storage editor lets you resize, delete, and create partitions. It can set up LVM and much more. It is meant to be used as an advanced utility and not intended to be used in a typical installation.": [
  null,
  "Tallennustilamuokkaimella voidaan muuttaa kokoa, poistaa ja luoda osioita. Sillä voidaan määrittää LVM:n ja paljon muuta. Se on tarkoitettu käytettäväksi edistyneenä apuohjelmana, eikä sitä ole tarkoitettu käytettäväksi tyypillisessä asennuksessa."
 ],
 "These log files may contain sensitive information such as IP addresses, usernames, or other system details.": [
  null,
  "Nämä lokitiedostot voivat sisältää arkaluonteisia tietoja, kuten IP-osoitteita, käyttäjätunnuksia tai muita järjestelmätietoja."
 ],
 "This hostname can't be submitted": [
  null,
  "Tätä isäntänimeä ei voi lähettää"
 ],
 "This is unstable, pre-release software": [
  null,
  "Tämä on epävakaa esijulkaisuversio ohjelmistosta"
 ],
 "This layout will be used for unlocking your system on boot": [
  null,
  "Tätä asettelua käytetään järjestelmän lukituksen avaamiseen käynnistyksen yhteydessä"
 ],
 "This may take a moment": [
  null,
  "Tämä saattaa kestää hetken"
 ],
 "This will take a few moments": [
  null,
  "Tämä kestää hetken"
 ],
 "Time": [
  null,
  "Aika"
 ],
 "Timezone": [
  null,
  "Aikavyöhyke"
 ],
 "Title": [
  null,
  "Otsikko"
 ],
 "To begin using $0, reboot your system.": [
  null,
  "Aloita $0:n käyttö käynnistämällä järjestelmä uudelleen."
 ],
 "To continue, select the devices to install to.": [
  null,
  "Jatka valitsemalla laitteet, joihin haluat asentaa."
 ],
 "To use this option, resize or remove existing partitions to free up at least $0.": [
  null,
  "Tämän vaihtoehdon käyttämiseksi, muuta olemassa olevien osioiden kokoja tai poista ne vapauttaaksesi vähintään $0."
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Unable to schedule deletion of $0": [
  null,
  "$0:n poistoa ei voi ajoittaa"
 ],
 "Unable to schedule resizing of $0": [
  null,
  "$0:n koon muuttamista ei voi ajoittaa"
 ],
 "Undo last action": [
  null,
  "Kumoa viimeisin toiminto"
 ],
 "Unlock": [
  null,
  "Avaa"
 ],
 "Unlock encrypted devices": [
  null,
  "Avaa salatut laitteet"
 ],
 "Use configured storage": [
  null,
  "Käytä määritettyä tallennustilaa"
 ],
 "Use entire disk": [
  null,
  "Käytä koko levyä"
 ],
 "Use free space": [
  null,
  "Käytä vapaata tilaa"
 ],
 "Use local account": [
  null,
  "Käytä paikallista tiliä"
 ],
 "Use the RAID device for automatic partitioning": [
  null,
  "Käytä RAID-laitetta automaattista osiointia varten"
 ],
 "User creation": [
  null,
  "Käyttäjän luominen"
 ],
 "User name": [
  null,
  "Käyttäjätunnus"
 ],
 "User name may only contain: letters from a-z, digits 0-9, dash $0, period $1, underscore $2": [
  null,
  "Käyttäjänimi saa sisältää vain: kirjaimia a–z, numeroita 0–9, viiva $0, piste $1, alaviiva $2"
 ],
 "User name must not be a reserved word": [
  null,
  "Käyttäjänimi ei saa olla varattu sana"
 ],
 "User names must be shorter than 33 characters": [
  null,
  "Käyttäjänimien tulee olla lyhyempiä kuin 33 merkkiä"
 ],
 "Validating...": [
  null,
  "Varmennetaan..."
 ],
 "Weak": [
  null,
  "Heikko"
 ],
 "Welcome": [
  null,
  "Tervetuloa"
 ],
 "Welcome to Fedora Linux": [
  null,
  "Tervetuloa Fedora Linuxiin"
 ],
 "Welcome. Let's install $0 now.": [
  null,
  "Tervetuloa. Asennataan nyt $0."
 ],
 "When you submit this bug report, the following log files will be uploaded automatically: $0": [
  null,
  "Kun lähetät tämän vikailmoituksen, seuraavat lokitiedostot ladataan automaattisesti: $0"
 ],
 "Windows partitions with BitLocker encryption cannot be resized": [
  null,
  "BitLocker-salauksella olevien Windows-osioiden kokoa ei voi muuttaa"
 ],
 "You can close this browser window now.": [
  null,
  ""
 ],
 "You can either free up enough space here and let the installer handle the rest or manually set up partitions.": [
  null,
  "Voit joko vapauttaa tarpeeksi tilaa täällä ja antaa asentajan hoitaa loput tai määrittää osiot manuaalisesti."
 ],
 "You can generate the API key for your Bugzilla account $0.": [
  null,
  "Voit luoda Bugzilla-tilillesi $0 API-avaimen."
 ],
 "You have to enable the root account or create a local user account to proceed.": [
  null,
  "Sinun on otettava root-tili käyttöön tai luotava paikallinen käyttäjätili jatkaaksesi."
 ],
 "You must be connected to a network to enable automatic date and time.": [
  null,
  "Sinun on oltava yhteydessä verkkoon, jotta automaattinen päivämäärä ja aika voidaan ottaa käyttöön."
 ],
 "Your progress will not be saved.": [
  null,
  "Edistymistäsi ei tallenneta."
 ],
 "completed step": [
  null,
  "suoritettu vaihe"
 ],
 "current step": [
  null,
  "nykyinen vaihe"
 ],
 "delete": [
  null,
  "poista"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "encrypt": [
  null,
  "Salaa"
 ],
 "encrypted": [
  null,
  "salattu"
 ],
 "extended partition": [
  null,
  "laajennettu osio"
 ],
 "format as $0": [
  null,
  "alusta $0:ksi"
 ],
 "here": [
  null,
  "täällä"
 ],
 "incomplete": [
  null,
  "keskeneräinen"
 ],
 "mount": [
  null,
  "liitä"
 ],
 "pending step": [
  null,
  "käsittelyä odottava vaihe"
 ],
 "report the issue manually": [
  null,
  "ilmoita ongelmasta manuaalisesti"
 ],
 "resized from $0": [
  null,
  "koko muutettu $0:sta"
 ],
 "shrink": [
  null,
  "kutista"
 ],
 "shrink to $0": [
  null,
  "kutista $0:ksi"
 ],
 "transient, will use DHCP": [
  null,
  ""
 ],
 "undo": [
  null,
  "kumoa"
 ]
});
