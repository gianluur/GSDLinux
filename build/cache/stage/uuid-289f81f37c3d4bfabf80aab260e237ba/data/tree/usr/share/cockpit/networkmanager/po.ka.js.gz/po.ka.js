cockpit.locale({
 "": {
  "plural-forms": ((n) => n != 1),
  "language": "ka",
  "language-direction": "ltr"
 },
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "Firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Public key": [
  null,
  "საჯარო გასაღები"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "Connect": [
  null,
  "დაკავშირება"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "Trust and add host": [
  null,
  "ჰოსტის ნდობა და დამატება"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"ჰოსტის ნდობა და დამატებას\", ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "მიღებული ანაბეჭდის გაზიარება, ელფოსტის ჩათვლით, უსაფრთხოა. თუ თქვენ სხვას სთხოვთ, თქვენი სახელით გადაამოწმოს, მათ, შედეგების გამოგზავნა ნებისმიერი მეთოდით შეუძლიათ."
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "Verify fingerprint": [
  null,
  "ანაბეჭდის გადამოწმება"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "გაუშვით ეს ბრძანება სანდო ქსელით ან ფიზიკურად, დაშორებულ მანქანაზე:"
 ],
 "The fingerprint should match:": [
  null,
  "ანაბეჭდების უნდა ემთხვეოდეს:"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "Disconnected": [
  null,
  "გამომძვრალია"
 ],
 "Permission denied": [
  null,
  "წვდომა აკრძალულია"
 ],
 "Clear input value": [
  null,
  "შეყვანილი მნიშვნელობის გასუფთავება"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using additional NTP servers": [
  null,
  "დამატებითი NTP სერვერების ავტომატური გამოყენება"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "Create $0": [
  null,
  "$0-ის შექმნა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "No methods to gain administrative access are available (sudo -A, pkexec).": [
  null,
  "ადმინისტრატორის წვდომის მიღების მეთოდები (sudo -A, pkexec) ხელმისაწვდომი არაა."
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "less than a minute ago": [
  null,
  "წუთზე ნაკლების წინ"
 ],
 "in less than a minute": [
  null,
  "წუთზე ნაკლებში"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Strong password": [
  null,
  "ძლიერი პაროლი"
 ],
 "Acceptable password": [
  null,
  "მისაღები პაროლი"
 ],
 "Weak password": [
  null,
  "სუსტი პაროლი"
 ],
 "Show password": [
  null,
  "პაროლის ჩვენება"
 ],
 "Hide password": [
  null,
  "პაროლის დამალვა"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "Show confirmation password": [
  null,
  "დადასტურების პაროლის ჩვენება"
 ],
 "Hide confirmation password": [
  null,
  "დადასტურების პაროლის დამალვა"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Unknown host: $0": [
  null,
  "უცნობი ჰოსტი: $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი."
 ],
 "SSH key login": [
  null,
  "SSH გასაღებით შესვლა"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit-ის შეცდომის კოდი $0"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "Row expansion": [
  null,
  "მწკრივის გაფართოება"
 ],
 "Row select": [
  null,
  "მწკრივის არჩევა"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Error during initialization": [
  null,
  "შეცდომა ინიციალიზაციის მიმდინარეობისას"
 ],
 "Failed": [
  null,
  "ჩავარდა"
 ],
 "Home": [
  null,
  "საწყისი"
 ],
 "Downloads": [
  null,
  "გადმოწერები"
 ],
 "Not a directory": [
  null,
  "საქაღალდე არაა"
 ],
 "All files": [
  null,
  "ყველა ფაილი"
 ],
 "Recent": [
  null,
  "უახლესი"
 ],
 "No recent directories": [
  null,
  "უახლესი საქაღალდეების გარეშე"
 ],
 "No recent files": [
  null,
  "უახლესი ფაილების გარეშე"
 ],
 "Type to filter": [
  null,
  "გასაფილტრად აკრიფეთ"
 ],
 "File chooser actions": [
  null,
  "ფაილის ამრჩევის ქმედებები"
 ],
 "Open in file browser": [
  null,
  "გახსნა ფაილების ბრაუზერში"
 ],
 "Hide hidden files": [
  null,
  "დამალული ფაილების დამალვა"
 ],
 "Show hidden files": [
  null,
  "დამალული ფაილების ჩვენება"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Clear filters": [
  null,
  "ფილტრების გასუფთავება"
 ],
 "Directory is empty": [
  null,
  "საქაღალდე ცარიელია"
 ],
 "Directory has no sub-directories": [
  null,
  "საქაღალდეს ქვესაქაღალდეები არ აქვს"
 ],
 "This directory contains only hidden files": [
  null,
  "ეს საქაღალდე, მხოლოდ, დამალულ ფაილებს შეიცავს"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "Folder": [
  null,
  "საქაღალდე"
 ],
 "File": [
  null,
  "ფაილი"
 ],
 "Copy to clipboard": [
  null,
  "ბუფერში კოპირება"
 ],
 "Automation script": [
  null,
  "ავტომატიზაციის სკრიპტი"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Create new task file with this content.": [
  null,
  "ახალი ამოცანის ამ შემცველობით შექმნა."
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-ის როლების დოკუმენტაცია"
 ],
 "Shell script": [
  null,
  "გარსის სკრიპტი"
 ],
 "No system modifications": [
  null,
  "სისტემა შეცვლილი არაა"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "შესულ მომხმარებელს არ აქვს სისტემური ცვლილებების ნახვს უფლება"
 ],
 "Loading system modifications...": [
  null,
  "სისტემის ცვლილებების ჩატვირთვა..."
 ],
 "View automation script": [
  null,
  "ავტომატიზაციის სკრიპტის ნახვა"
 ],
 "Occurrences": [
  null,
  "გამოვლენები"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Select an option": [
  null,
  "აირჩიეთ პარამეტრი"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Generated": [
  null,
  "გენერირებული"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Delete $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Group": [
  null,
  "ჯგუფი"
 ],
 "Actions": [
  null,
  "ქმედებები"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "Ignore": [
  null,
  "იგნორი"
 ],
 "Permanent": [
  null,
  "მუდმივი"
 ],
 "Preserve": [
  null,
  "არ შეცვალო"
 ],
 "Random": [
  null,
  "შემთხვევითი"
 ],
 "Stable": [
  null,
  "სტაბილური"
 ],
 "Use $0": [
  null,
  "$0-ის გამოყენება"
 ],
 "Failed to save settings": [
  null,
  "პარამეტრების შენახვის შეცდომა"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის შექმნა გაწყვეტს სერვერთან კავშირს. ადმინისტრირების ინტერფეისი მიუწვდომელი გახდება."
 ],
 "Create it": [
  null,
  "შექმნა"
 ],
 "Invalid prefix $0": [
  null,
  "არასწორი პრეფიქსი $0"
 ],
 "Invalid metric $0": [
  null,
  "არასწორი მეტრიკა $0"
 ],
 "Invalid address $0": [
  null,
  "არასწორი მისამართი: $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "არასწორი პრეფიქსი ან ქსელის მასკა $0"
 ],
 "Testing connection": [
  null,
  "კავშირის შემოწმება"
 ],
 "Restoring connection": [
  null,
  "კავშირის აღდგენა"
 ],
 "Troubleshoot…": [
  null,
  "პრობლემების გადაწყვეტა…"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager გაშვებული არაა"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager დაყენებული არაა"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "ქსელურ მოწყობილობებს და გრაფიკებს NetworkManager-ი ესაჭიროებათ"
 ],
 "Enable service": [
  null,
  "სერვისის ჩართვა"
 ],
 "Network interface '$0' not found": [
  null,
  "ქსელის ინტერფეისი '$0' აღმოჩენილი არაა"
 ],
 "Return to overview page": [
  null,
  "მიმოხილვის გვერდზე დაბრუნება"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "ბრანდმაუერის ჩასწორების წვდომა აკრძალულია."
 ],
 "Not authorized to disable the firewall": [
  null,
  "ბრანდმაუერის გამოსართავად საჭიროა ავტორიზაცია"
 ],
 "Not authorized to enable the firewall": [
  null,
  "ბრანდმაუერის ჩასართავად საჭიროა ავტორიზაცია"
 ],
 "Disable the firewall": [
  null,
  "ბრანდმაუერის გამორთვა"
 ],
 "Enable the firewall": [
  null,
  "ბრანდმაუერის ჩართვა"
 ],
 "Edit service $0": [
  null,
  "სერვისის ჩასწორება: $0"
 ],
 "Remove service $0": [
  null,
  "სერვისის წაშლა: $0"
 ],
 "Included Services": [
  null,
  "მოყოლილი სერვისები"
 ],
 "Additional port": [
  null,
  "დამატებითი პორტი"
 ],
 "Remove additional port": [
  null,
  "დამატებითი პორტის წაშლა"
 ],
 "Remove zone $0": [
  null,
  "ზონის წაშლა: $0"
 ],
 "Add services to zone $0": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Add services": [
  null,
  "სერვისების დამატება"
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "$0 zone": [
  null,
  "$0 ზონა"
 ],
 "Interface": [
  null,
  "ცალი ინტერფეისი",
  "ინტერფეისი"
 ],
 "Allowed addresses": [
  null,
  "ნებადართული მისამართები"
 ],
 "Entire subnet": [
  null,
  "მთელი ქვექსელი"
 ],
 "There are no active services in this zone": [
  null,
  "ამ ზონაში აქტიური სერვისები არ არსებობს"
 ],
 "Filter services": [
  null,
  "სერვისების ფილტრი"
 ],
 "Failed to edit service": [
  null,
  "სერვისის ჩასწორების შეცდომა"
 ],
 "Failed to add port": [
  null,
  "პორტის დამატების შეცდომა"
 ],
 "Failed to add service": [
  null,
  "სერვისის დამატების შეცდომა"
 ],
 "Unknown service name": [
  null,
  "სერვისის უცნობი სახელი"
 ],
 "Invalid port number": [
  null,
  "პორტის არასწორი ნომერი"
 ],
 "Invalid range": [
  null,
  "არასწორი დიაპაზონი"
 ],
 "Range must be strictly ordered": [
  null,
  "დიაპაზონი მკაცრად უნდა იყოს განსაზღვრული"
 ],
 "Edit service": [
  null,
  "სერვისის ჩასწორება"
 ],
 "Edit custom service in $0 zone": [
  null,
  "ხელით მითითებული სერვისის ჩასწორება ზონაში $0"
 ],
 "Add ports": [
  null,
  "პორტების დამატება"
 ],
 "Add ports to $0 zone": [
  null,
  "პორტების დამატება ზონაში $0"
 ],
 "Add services to $0 zone": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Custom ports": [
  null,
  "ხელით მითითებული პორტები"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "მაგალითად: 22,ssh,8080,5900-5910"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "შესაძლო მნიშვნელობებია მძიმით გამოყოფილი პორტები, დიაპაზონები და სერვისები"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "მაგალითად: 88,2019,nfs,rsync"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "თუ ცარიელია, ID დაგენერირდება შესაბამისი პორტის სერვისებისა და პორტის ნომრებისგან"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "მითითებული პორტების დაატება იწვევს firewalld-ის გადატვირთვას. ეს კი იწვევს გაშვებული კონფიგურაციის(ინახება მეხსიერებაში) დაკარგვას!"
 ],
 "Failed to add zone": [
  null,
  "ზონის დამატების შეცდომა"
 ],
 "Add zone": [
  null,
  "ზონის დამატება"
 ],
 "Trust level": [
  null,
  "ნდობის დონე"
 ],
 "Sorted from least to most trusted": [
  null,
  "დალაგებულია ყველაზე ნაკლებიდან ყველაზე მეტად სანდომდე"
 ],
 "Custom zones": [
  null,
  "ხელით მითითებული ზონები"
 ],
 "No description available": [
  null,
  "აღწერა ხელმიუწვდომელია"
 ],
 "Included services": [
  null,
  "მოყოლილი სერვისები"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cocpit-ის სერვისი ავტომატურად მოჰყვება"
 ],
 "Interfaces": [
  null,
  "ინტერფეისები"
 ],
 "Range": [
  null,
  "დიაპაზონი"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP მისამართი რაუტინგის პრეფიქსით. ერთმანეთისგან გამოიყოფა მძიმით. მაგ: 192.0.2.0, 2001:db8::/32"
 ],
 "Confirm removal of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "ზონა შეიცავს cockpit-ის სერვისს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლის თქვენს მიმდინარე სესიას არ ბლოკავს."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ზონის წაშლა მასში მყოფი სერვისების წაშლასაც გამოიწევევს."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "cockpit-ის სერვისის წაშლამ შეიძლება ვებ კონსოლი მიუწვდომელი გახადოს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლთან კავშირს არ გაწყვეტს."
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$1 ზონიდან $0 სერვისის წაშლა"
 ],
 "Firewall is not available": [
  null,
  "ბრანდმაუერი ხელმიუწვდომელია"
 ],
 "Please install the $0 package": [
  null,
  "დააყენეთ პაკეტი $0"
 ],
 "Add a new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Add new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "შემომავალი მოთხოვნები ნაგულისხმებად იბლოკება. გამავალი მოთხოვნები არ იბლოკება."
 ],
 "Connected": [
  null,
  "დაკავშირებულია"
 ],
 "Wireless": [
  null,
  "უსადენო"
 ],
 "Wired": [
  null,
  "სადენით"
 ],
 "No networks found": [
  null,
  "ქსელები აღმოჩენილი არაა"
 ],
 "No interface selected": [
  null,
  "არჩეული ინტერფეისის გარეშე"
 ],
 "Select a network interface to configure the connection.": [
  null,
  "აირჩიეთ ქსელის ინტერფეისი კავშირის მოსარგებად."
 ],
 "SSID can not be empty": [
  null,
  "SSID არ შეიძლება, ცარიელი იყოს"
 ],
 "Password can not be empty": [
  null,
  "პაროლი არ შეიძლება, ცარიელი იყოს"
 ],
 "Failed to connect": [
  null,
  "დაკავშირების შეცდომა"
 ],
 "Check your password.": [
  null,
  "შეამოწმეთ თქვენი პაროლი."
 ],
 "Connect to hidden network": [
  null,
  "დამალულ ქსელთან დაკავშირება"
 ],
 "Connect to $0": [
  null,
  "$0-ისთან დაკავშირება"
 ],
 "Network name": [
  null,
  "ქსელის სახელი"
 ],
 "Security": [
  null,
  "უსაფრთხოება"
 ],
 "WPA/WPA2 Personal": [
  null,
  "WPA/WPA2 Personal"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა შეწყვეტს კავშირს სერვერთან და ადმინისტრაციის ინტერფეისს მიუწვდომელს გახდის."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის ჩართვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Switch on $0": [
  null,
  "$0-ის ჩართვა"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის გათიშვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Switch off $0": [
  null,
  "$0-ის გამორთვა"
 ],
 "Bond": [
  null,
  "ინტერფეისების გადაბმა"
 ],
 "Team": [
  null,
  "გუნდი"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "Bridge": [
  null,
  "ხიდი"
 ],
 "Unknown \"$0\"": [
  null,
  "უცნობი \"$0\""
 ],
 "Carrier": [
  null,
  "გადამზიდი"
 ],
 "Yes": [
  null,
  "დიახ"
 ],
 "No": [
  null,
  "არა"
 ],
 "Inactive": [
  null,
  "არააქტიური"
 ],
 "Unknown configuration": [
  null,
  "უცნობი კონფიგურაცია"
 ],
 "Additional address $val": [
  null,
  "დამატებითი მისამართი $val"
 ],
 "Address $val": [
  null,
  "მისამართი $val"
 ],
 "Gateway $gateway": [
  null,
  "რაუტერი $gateway"
 ],
 "Additional DNS $val": [
  null,
  "დამატებითი DNS $val"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "DNS-ის დამატებითი საძებნი დომენები $val"
 ],
 "DNS search domains $val": [
  null,
  "DNS-ში საძებნი დომენები $val"
 ],
 "General": [
  null,
  "საერთო"
 ],
 "Connect automatically": [
  null,
  "ავტომატურად დაკავშირება"
 ],
 "Automatic": [
  null,
  "ავტომატური"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "ARP monitoring": [
  null,
  "ARP-ის მონიტორინგი"
 ],
 "Broken configuration": [
  null,
  "გაფუჭებული კონფიგურაცია"
 ],
 "Team port": [
  null,
  "Team-ის პორტები"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Priority $priority": [
  null,
  "$priority პრიორიტეტი"
 ],
 "Forward delay $forward_delay": [
  null,
  "გადაგზავნის დაყოვნება $forward_delay"
 ],
 "Hello time $hello_time": [
  null,
  "მისალმების დრო $hello_time"
 ],
 "Maximum message age $max_age": [
  null,
  "შეტყობინების მაქს. ვადა $max_age"
 ],
 "Path cost $path_cost": [
  null,
  "ბილიკის ფასი $path_cost"
 ],
 "Hairpin mode": [
  null,
  "NAT hairpin რეჟიმი"
 ],
 "Bridge port": [
  null,
  "ხიდის პორტი"
 ],
 "Parent $parent": [
  null,
  "მშობელი $parent"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "Network password is not stored. Please forget and reconnect to this network.": [
  null,
  "ქსელის პაროლის დამახსოვრება არ ხდება. დაივიწყეთ და დაუკავშირდით ამ ქსელს თავიდან."
 ],
 "Failed to connect to $0": [
  null,
  "$0-ისთან დაკავშირების შეცდომა"
 ],
 "secured": [
  null,
  "დაცული"
 ],
 "open": [
  null,
  "ღია"
 ],
 "Last connected: $0": [
  null,
  "ბოლოს დაკავშირება: $0"
 ],
 "Signal strength": [
  null,
  "სიგნალის სიძლიერე"
 ],
 "Not permitted to disconnect network": [
  null,
  "ქსელთან კავშირის გაწყვეტის უფლება არ გაქვთ"
 ],
 "Disconnect": [
  null,
  "გათიშვა"
 ],
 "Not permitted to connect to network": [
  null,
  "ამ ქსელთან დაკავშირების უფლება არ გაქვთ"
 ],
 "Forget": [
  null,
  "დავიწყება"
 ],
 "$0 hidden network": [
  null,
  "$0 დამალული ქსელი",
  "$0 დამალული ქსელი"
 ],
 "Filter": [
  null,
  "ფილტრი"
 ],
 "Refresh": [
  null,
  "განახლება"
 ],
 "Available networks": [
  null,
  "ხელმისაწვდომი ქსელები"
 ],
 "Network": [
  null,
  "ქსელი"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Signal": [
  null,
  "სიგნალი"
 ],
 "Rate": [
  null,
  "სიჩქარე"
 ],
 "Primary action": [
  null,
  "ძირითადი ქმედება"
 ],
 "Secondary actions": [
  null,
  "დამხმარე ქმედება"
 ],
 "Not permitted to configure network devices": [
  null,
  "ქსელური მოწყობილობების მორგების უფლება არ გაქვთ"
 ],
 "Enable or disable the device": [
  null,
  "მოწყობილობის ჩართვა ან გამორთვა"
 ],
 "This device cannot be managed here.": [
  null,
  "მოწყობილობა აქედან ვერ იმართება."
 ],
 "Connection will be lost": [
  null,
  "კავშირი დაიკარგება"
 ],
 "Keep connection": [
  null,
  "კავშირის შენარჩუნება"
 ],
 "Invalid IP address: $0": [
  null,
  "არასწორი IP მისამართი: $0"
 ],
 "Invalid destination address: $0": [
  null,
  "არასწორი სამიზნე მისამართი: $0"
 ],
 "Invalid gateway address: $0": [
  null,
  "არასწორი ნაგულისხმევი რაუტერის მისამართი: $0"
 ],
 "Invalid DNS address: $0": [
  null,
  "არასწორი DNS მისამართი: $0"
 ],
 "Preparing": [
  null,
  "მომზადება"
 ],
 "Configuring": [
  null,
  "მორგება"
 ],
 "Authenticating": [
  null,
  "ავთენტიკაცია"
 ],
 "Configuring IP": [
  null,
  "IP-ის მორგება"
 ],
 "Checking IP": [
  null,
  "IP-ის შემოწმება"
 ],
 "Waiting": [
  null,
  "მოლოდინი"
 ],
 "Active": [
  null,
  "აქტიური"
 ],
 "Deactivating": [
  null,
  "დეაქტივაცია"
 ],
 "Adhoc": [
  null,
  "Adhoc"
 ],
 "Infra": [
  null,
  "ინფრასტრუქტურა"
 ],
 "AP": [
  null,
  "AP"
 ],
 "Mesh": [
  null,
  "ბადე"
 ],
 "No carrier": [
  null,
  "შეამოწმეთ კავშირი"
 ],
 "Part of $0": [
  null,
  "$0-ის ნაწილი"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ამ პარამეტრის ცვლილებები გამოიწვევს კავშირის წვეტას და გათიშავს ადმინისტრირების ინტერფეისს."
 ],
 "Change the settings": [
  null,
  "პარამეტრების შეცვლა"
 ],
 "Add bridge": [
  null,
  "ხიდის დამატება"
 ],
 "Edit bridge settings": [
  null,
  "Bridge-ის პარამეტრების ჩასწორება"
 ],
 "Ports": [
  null,
  "პორტები"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "STP priority": [
  null,
  "STP პრიორიტეტი"
 ],
 "STP forward delay": [
  null,
  "STP გადამისამართების დაყოვნება"
 ],
 "STP hello time": [
  null,
  "STP hello-ის დრო"
 ],
 "STP maximum message age": [
  null,
  "STP შეტყობინების მაქსიმალური ასაკი"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Active backup": [
  null,
  "აქტიური მარქაფი"
 ],
 "Load balancing": [
  null,
  "დატვირთვის გადანაწილება"
 ],
 "Broadcast": [
  null,
  "გადაცემა"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "Passive": [
  null,
  "პასიური"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Add team": [
  null,
  "გუნდის დამატება"
 ],
 "Edit team settings": [
  null,
  "Team-ის პარამეტრების ჩასწორება"
 ],
 "Runner": [
  null,
  "გამშვები"
 ],
 "Balancer": [
  null,
  "ბალანსერი"
 ],
 "Primary": [
  null,
  "ძირითადი"
 ],
 "Link watch": [
  null,
  "კავშირის თვალყურმდევნი"
 ],
 "Link up delay": [
  null,
  "კავშირის აღდგენის დაყოვნება"
 ],
 "Link down delay": [
  null,
  "კავშირის გათიშვის დაყოვნება"
 ],
 "Ping interval": [
  null,
  "Ping-ის დაყოვნება"
 ],
 "Ping target": [
  null,
  "მიზნის დაპინგვა"
 ],
 "Automatic (DHCP only)": [
  null,
  "ავტომატური (მხოლოდ DHCP)"
 ],
 "Link local": [
  null,
  "ლოკალური ბმის მისამართი"
 ],
 "Manual": [
  null,
  "ხელით მითითება"
 ],
 "Shared": [
  null,
  "ზიარი"
 ],
 "Prefix length or netmask": [
  null,
  "პრეფიქსის სიგრძე ან ნეტმასკა"
 ],
 "Prefix length": [
  null,
  "პრეფიქსის სიგრძე"
 ],
 "IPv4 settings": [
  null,
  "IPv4-ის მორგება"
 ],
 "IPv6 settings": [
  null,
  "IPv6-ის მორგება"
 ],
 "Addresses": [
  null,
  "მისამართები"
 ],
 "Select method": [
  null,
  "აირჩიეთ მეთოდი"
 ],
 "Add address": [
  null,
  "მისამართის დამატება"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Remove item": [
  null,
  "ელემენტის წაშლა"
 ],
 "Gateway": [
  null,
  "რაუტერი"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "Add DNS server": [
  null,
  "DNS სერვერის დამატება"
 ],
 "DNS search domains": [
  null,
  "DNS-ში საძებნი დომენები"
 ],
 "Add search domain": [
  null,
  "საძებნი დომენის დამატება"
 ],
 "Search domain": [
  null,
  "ძებნის დომენი"
 ],
 "Routes": [
  null,
  "მარშრუტები"
 ],
 "Add route": [
  null,
  "რაუტის დამატება"
 ],
 "Metric": [
  null,
  "მეტრული"
 ],
 "Enter a valid MAC address": [
  null,
  "შეიყვანეთ სწორი MAC მისამართი"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-ის MAC"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "$0 network": [
  null,
  "$0 ქსელი",
  "$0 ქსელი"
 ],
 "Add VPN": [
  null,
  "VPN-ის დამატება"
 ],
 "Add bond": [
  null,
  "Bond-ის დამატება"
 ],
 "Add VLAN": [
  null,
  "VLAN-ის დამატება"
 ],
 "Edit rules and zones": [
  null,
  "წესებისა და ზონების ჩასწორება"
 ],
 "$0 active zone": [
  null,
  "$0 აქტიური ზონა",
  "$0 ცალი აქტიური ზონა"
 ],
 "Managed interfaces": [
  null,
  "მართული ინტერფეისები"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "Sending": [
  null,
  "გაგზავნა"
 ],
 "Receiving": [
  null,
  "მიღება"
 ],
 "Unmanaged interfaces": [
  null,
  "უმართავი ინტერფეისები"
 ],
 "Network logs": [
  null,
  "ქსელის ჟურნალი"
 ],
 "Addresses are not formatted correctly": [
  null,
  "მისამართის ფორმატი არასწორია"
 ],
 "Invalid IP address '$0'": [
  null,
  "არასწორი IP მისამართი: '$0'"
 ],
 "wireguard-tools package is not installed": [
  null,
  "პაკეტი wireguard-tools დაყენებული არაა"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "პარტნიორის #$0 ბოლოწერტილი არასწორია. ის ჰოსტი:პორტი სახით უნდა იყოს მითითებული. მაგ: 1.3.4.5:41232, [2001:db8::1]:51820 ან example.com:41223"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "პარტნიორის #$0 ბოლოწერტილის პორტი არასწორია. პორტის ნომერი რიცხვი უნდა იყოს."
 ],
 "Listen port must be a number": [
  null,
  "მოსასმენი პორტი რიცხვი უნდა იყოს"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN-ის დამატება"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN-ის ჩასწორება"
 ],
 "Private key": [
  null,
  "პირადი გასაღები"
 ],
 "Paste existing key": [
  null,
  "არსებული გასაღების ჩასმა"
 ],
 "Regenerate": [
  null,
  "თავიდან გენერაცია"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "საჯარო გასაღები დაგენერირდება, როცა სწორ პირად გასაღებს შეიყვანთ"
 ],
 "Listen port": [
  null,
  "პორტის მოსმენა"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "დაყენებული იქნება \"ავტომატურზე\""
 ],
 "IP addresses": [
  null,
  "IP მისამართები"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "ერთზე მეტი მისამართის მითითება მძიმეებით ან გამოტოვებებით შეგიძლიათ."
 ],
 "Peers": [
  null,
  "პარტნიორები"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "პარტნიორები სხვა მანქანებია, რომლებიც ამას უერთდებიან. საჯარო გასაღებები სხვა მანქანებიდან ასევე გაზიარებული იქნება."
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "ბოლოწერტილები, რომლებიც იქცევიან, როგორც \"სერვერი\", ჰოსტი:პორტი სახით უნდა იყოს მითითებული, ან ცარიელი."
 ],
 "Add peer": [
  null,
  "პარტნიორის დამატება"
 ],
 "Endpoint": [
  null,
  "ბოლოწერტილი"
 ],
 "Allowed IPs": [
  null,
  "დაშვებული IP-ები"
 ],
 "No peers added.": [
  null,
  "პარტნიორები დამატებული არაა."
 ],
 "Edit VLAN settings": [
  null,
  "VLAN-ის პარამეტრების ჩასწორება"
 ],
 "Parent": [
  null,
  "მშობელი"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Transmitting": [
  null,
  "გადაცემა"
 ],
 "MTU must be a positive number": [
  null,
  "MTU დადებითი რიცხვი უნდა იყოს"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-ის MTU"
 ],
 "Set to": [
  null,
  "გაგზავნის მიმღები"
 ],
 "Team port settings": [
  null,
  "გუნდური პორტის მორგება"
 ],
 "Sticky": [
  null,
  "წებოვანი"
 ],
 "LACP key": [
  null,
  "LACP გასაღები"
 ],
 "Bridge port settings": [
  null,
  "ხიდის პორტის მორგება"
 ],
 "Path cost": [
  null,
  "ბილიკის ღირებულება"
 ],
 "Hair pin mode": [
  null,
  "NAT Hairpin-ის რეჟიმი"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "Adaptive transmit load balancing": [
  null,
  "გადაცემის დატვირთვის ადაპტაციური გადანაწილება"
 ],
 "Adaptive load balancing": [
  null,
  "დატვირთვის ადაპტიური გადანაწილება"
 ],
 "MII (recommended)": [
  null,
  "MII (რეკომენდებულია)"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "Edit bond settings": [
  null,
  "Bond-ის პარამეტრების ჩასწორება"
 ],
 "Network bond": [
  null,
  "ქსელის ბარათების გაერთიანება"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "ქსელური bond აერთიანებს ქსელის მრავალ ინტერფეისს ერთ ლოგიკურ ინტერფეისში უფრო მაღალი გამტარობის ან წვდომადომის მისაღებად."
 ],
 "Link monitoring": [
  null,
  "კავშირის მონიტორინგი"
 ],
 "Monitoring interval": [
  null,
  "მონიტორინგის ინტერვალი"
 ],
 "Monitoring targets": [
  null,
  "სამიზნეების მონიტორინგი"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა გაწყვეტს კავშირს სერვერთან და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Remove $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის დამატება გაწყვეტს კავშირს სერვერთან და ადმინისტრირების ინტერფეისს ხელმიუწვდომელს გახდის."
 ],
 "No interfaces available": [
  null,
  "ინტერფეისები ხელმისაწვდომი არაა"
 ],
 "Add member": [
  null,
  "წევრის დამატება"
 ],
 "Interface members": [
  null,
  "ინტერფეისის წევრები"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager-ის და Firewalld-ის მორგება Cockpit-ით"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "ეს პროგრამა მართავს ქსელს. bond ინტერფეისების, ხიდების, ჯგუფური ინტერფეისების, VLAN-ების და ბრანდმაუერების მართვა NetworkManager-ისა და FIrewalld-ის საშუალებით. NetworkManager-ი Ubuntu-ის ნაგულისხმებ systemd-networkd და Debian-ის ifupdown სკრიპტებთან შეუთავსებელია."
 ],
 "Manage storage": [
  null,
  "საცავის მართვა"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "ეს პროგრამა ლოკალურ საცავს, როგორიცაა ფაილურ სისტემები, LVM2 ტომის ჯგუფები და NFS მიმაგრებები, მართავს."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "მოაგროვეთ დიაგნოსტიკური და მხარდაჭერის მონაცემები"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "ეს პროგრამა გაშვებული სისტემიდან კონფიგურაცისა და დიაგნოსტიკის მოგროვებაში დაგეხმარებათ. არქივი შეგიძლიათ ლოკალურად შეინახოთ, ან ცენტრალურად, ჩაწერისა და ტრეკინგის მიზნებისთვის, ან შეგიძლიათ გადააგზავნოთ მხარდაჭერის, პროგრამისტებისა და სისტემური ადმინისტრატორების ჯგუფებთან, რათა აპარატურული პრობლემები აღმოაჩინოთ და გადაჭრათ."
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Linux-ის გაფართოებული უსაფრთხოების (SELinux) მორგება და გამართვა"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "ეს პროგრამა როგორც SELinux-ის პოლიტიკის მორგებაში, ასევე მის ბოლომდე გაგებაში და პოლიტიკის დარღვევის გადაწყვეტაში დაგეხმარებათ."
 ],
 "Collect kernel crash dumps": [
  null,
  "ოპერაციული სისტემის ბირთვის ავარიის დამპები"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "ეს პროგრამა სისტემას ბირთვის ავარიის შემთხვევაში დისკზე დამპის ჩაწერის მორგებაში დაგეხმარებათ. დამპის მხარდაჭერილი სამიზნეებია: \"local\" (დისკი), \"ssh\" და \"nfs\"."
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockput ვებ კონსოლით ადმინისტრირება"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit ვებ კონსოლში პრივილეგირებული ამოცანების შესასრულებლად საჭიროა ავთენტიკაცია"
 ]
});
